import {Component} from "angular2/core";

@Component({
    template:`
    <h2>Index controler</h2>
<div class="row">
<div class="col s12">
<h1>Welcome To Home</h1>
</div>
</div>
    `
})
export class indexComponent{
}