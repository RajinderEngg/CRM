import {Component} from "angular2/core";

@Component({
    template:"<h1>Serrings</h1>"
})
export class AmaxEmployeeSettings{

}