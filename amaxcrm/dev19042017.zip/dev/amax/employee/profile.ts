import {Component, OnInit} from "angular2/core";

@Component({
    template:"<h1>Profile</h1>"
})
export class AmaxEmployeeProfile{

}