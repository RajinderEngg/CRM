import {Component, OnInit} from "angular2/core";
//import {ResourceService} from "../services/ResourceService";
@Component({
    template: "<h1>Cleaning user information...</h1>"
    
})
export class AmaxLogoutComponent implements OnInit{
    constructor() {  /*private _resourceService: ResourceService*/
    }


    ngOnInit() {
        //debugger;
        //this._resourceService.deleteCookie("RememberKey");
    }
}