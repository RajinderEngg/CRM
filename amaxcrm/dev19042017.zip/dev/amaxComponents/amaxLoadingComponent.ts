import { Component } from 'angular2/core';

@Component({
    selector:"mx-loading",
    template:`
        <div class="bubblingG">
        
    </div>`
})
export class AmaxLoadingComponent{
}