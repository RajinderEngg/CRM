System.register(["angular2/core", "../amaxUtil"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, amaxUtil_1;
    var AmaxCrmBreadcrumbComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (amaxUtil_1_1) {
                amaxUtil_1 = amaxUtil_1_1;
            }],
        execute: function() {
            AmaxCrmBreadcrumbComponent = (function () {
                function AmaxCrmBreadcrumbComponent() {
                    this.breadcrumbs = [
                        {
                            icon: 'fa-home',
                            name: 'Home'
                        },
                        {
                            icon: 'fa-rocket',
                            name: 'Office'
                        }
                    ];
                    amaxUtil_1.onEvent.listenEvent(amaxUtil_1.crmEvent.breadcrumbChange, this.updateBreadCrum);
                }
                AmaxCrmBreadcrumbComponent.prototype.updateBreadCrum = function (evt) {
                    this.breadcrumbs = evt.evtData;
                };
                AmaxCrmBreadcrumbComponent = __decorate([
                    core_1.Component({
                        selector: 'mx-breadcrumb',
                        templateUrl: './app/amaxComponents/templates/amaxCrmBreadcrumb.html',
                    }), 
                    __metadata('design:paramtypes', [])
                ], AmaxCrmBreadcrumbComponent);
                return AmaxCrmBreadcrumbComponent;
            }());
            exports_1("AmaxCrmBreadcrumbComponent", AmaxCrmBreadcrumbComponent);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFtYXhDb21wb25lbnRzL2FtYXhDcm1CcmVhZGNydW1iQ29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1lBUUE7Z0JBRUk7b0JBQ0ksSUFBSSxDQUFDLFdBQVcsR0FBQzt3QkFDYjs0QkFDSSxJQUFJLEVBQUMsU0FBUzs0QkFDZCxJQUFJLEVBQUMsTUFBTTt5QkFDZDt3QkFDRDs0QkFDSSxJQUFJLEVBQUMsV0FBVzs0QkFDaEIsSUFBSSxFQUFDLFFBQVE7eUJBQ2hCO3FCQUNKLENBQUM7b0JBRUYsa0JBQU8sQ0FBQyxXQUFXLENBQUMsbUJBQVEsQ0FBQyxnQkFBZ0IsRUFBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUE7Z0JBRXZFLENBQUM7Z0JBQ0Qsb0RBQWUsR0FBZixVQUFnQixHQUFHO29CQUNmLElBQUksQ0FBQyxXQUFXLEdBQUcsR0FBRyxDQUFDLE9BQU8sQ0FBQztnQkFDbkMsQ0FBQztnQkF2Qkw7b0JBQUMsZ0JBQVMsQ0FBQzt3QkFDUCxRQUFRLEVBQUMsZUFBZTt3QkFDeEIsV0FBVyxFQUFDLHVEQUF1RDtxQkFDdEUsQ0FBQzs7OENBQUE7Z0JBcUJGLGlDQUFDO1lBQUQsQ0FwQkEsQUFvQkMsSUFBQTtZQXBCRCxtRUFvQkMsQ0FBQSIsImZpbGUiOiJhbWF4Q29tcG9uZW50cy9hbWF4Q3JtQnJlYWRjcnVtYkNvbXBvbmVudC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7Q29tcG9uZW50fSBmcm9tIFwiYW5ndWxhcjIvY29yZVwiO1xyXG5pbXBvcnQge29uRXZlbnQsIGNybUV2ZW50fSBmcm9tIFwiLi4vYW1heFV0aWxcIjtcclxuXHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOidteC1icmVhZGNydW1iJyxcclxuICAgIHRlbXBsYXRlVXJsOicuL2FwcC9hbWF4Q29tcG9uZW50cy90ZW1wbGF0ZXMvYW1heENybUJyZWFkY3J1bWIuaHRtbCcsXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBBbWF4Q3JtQnJlYWRjcnVtYkNvbXBvbmVudHtcclxuICAgIGJyZWFkY3J1bWJzOkFycmF5PGFueT47XHJcbiAgICBjb25zdHJ1Y3Rvcigpe1xyXG4gICAgICAgIHRoaXMuYnJlYWRjcnVtYnM9W1xyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICBpY29uOidmYS1ob21lJyxcclxuICAgICAgICAgICAgICAgIG5hbWU6J0hvbWUnXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIGljb246J2ZhLXJvY2tldCcsXHJcbiAgICAgICAgICAgICAgICBuYW1lOidPZmZpY2UnXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICBdO1xyXG4gICAgICAgIFxyXG4gICAgICAgIG9uRXZlbnQubGlzdGVuRXZlbnQoY3JtRXZlbnQuYnJlYWRjcnVtYkNoYW5nZSx0aGlzLnVwZGF0ZUJyZWFkQ3J1bSlcclxuXHJcbiAgICB9XHJcbiAgICB1cGRhdGVCcmVhZENydW0oZXZ0KXtcclxuICAgICAgICB0aGlzLmJyZWFkY3J1bWJzID0gZXZ0LmV2dERhdGE7XHJcbiAgICB9XHJcbn0iXX0=
