System.register(['angular2/core', "./amaxCrmNavbarComponent", "./amaxCrmSidebarComponent", "./amaxCrmBreadcrumbComponent", "angular2/router"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, amaxCrmNavbarComponent_1, amaxCrmSidebarComponent_1, amaxCrmBreadcrumbComponent_1, router_1;
    var AmaxCrmUIComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (amaxCrmNavbarComponent_1_1) {
                amaxCrmNavbarComponent_1 = amaxCrmNavbarComponent_1_1;
            },
            function (amaxCrmSidebarComponent_1_1) {
                amaxCrmSidebarComponent_1 = amaxCrmSidebarComponent_1_1;
            },
            function (amaxCrmBreadcrumbComponent_1_1) {
                amaxCrmBreadcrumbComponent_1 = amaxCrmBreadcrumbComponent_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            }],
        execute: function() {
            AmaxCrmUIComponent = (function () {
                function AmaxCrmUIComponent() {
                }
                AmaxCrmUIComponent.prototype.ngOnInit = function () {
                    ////var windWidth = jQuery(window).width();
                    ////if (windWidth > 250) {
                    //    var brwidth = screen.width;
                    //    var sideWidth = jQuery("#slide-out").width();
                    //    jQuery(".breadcrumbs").css("width", brwidth - sideWidth );
                    ////}
                };
                AmaxCrmUIComponent = __decorate([
                    core_1.Component({
                        selector: 'mx-ui',
                        templateUrl: './app/amaxComponents/templates/amaxCrmUI.html',
                        directives: [router_1.ROUTER_DIRECTIVES, amaxCrmNavbarComponent_1.AmaxCrmNavbarComponent, amaxCrmSidebarComponent_1.AmaxCrmSidebarComponent, amaxCrmBreadcrumbComponent_1.AmaxCrmBreadcrumbComponent]
                    }), 
                    __metadata('design:paramtypes', [])
                ], AmaxCrmUIComponent);
                return AmaxCrmUIComponent;
            }());
            exports_1("AmaxCrmUIComponent", AmaxCrmUIComponent);
        }
    }
});
// template : `
//     <mx-navbar></mx-navbar>
//     <div class="main-container" id="main-container">
//         <mx-sidebar></mx-sidebar>
//     </div><!-- /.main-container -->
// `,
//directives: [AmaxCrmNavbarComponent, AmaxCrmSidebarComponent] 

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFtYXhDb21wb25lbnRzL2FtYXhDcm1VSUNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztZQVdBO2dCQUFBO2dCQVVBLENBQUM7Z0JBVEcscUNBQVEsR0FBUjtvQkFFSSwyQ0FBMkM7b0JBQzNDLDBCQUEwQjtvQkFDMUIsaUNBQWlDO29CQUNqQyxtREFBbUQ7b0JBQ25ELGdFQUFnRTtvQkFDaEUsS0FBSztnQkFDVCxDQUFDO2dCQWRMO29CQUFDLGdCQUFTLENBQUM7d0JBQ1AsUUFBUSxFQUFFLE9BQU87d0JBQ2pCLFdBQVcsRUFBRywrQ0FBK0M7d0JBQzdELFVBQVUsRUFBQyxDQUFDLDBCQUFpQixFQUFFLCtDQUFzQixFQUFFLGlEQUF1QixFQUFFLHVEQUEwQixDQUFDO3FCQUM5RyxDQUFDOztzQ0FBQTtnQkFXRix5QkFBQztZQUFELENBVkEsQUFVQyxJQUFBO1lBVkQsbURBVUMsQ0FBQTs7OztBQUlHLGVBQWU7QUFDZiw4QkFBOEI7QUFDOUIsdURBQXVEO0FBQ3ZELG9DQUFvQztBQUNwQyxzQ0FBc0M7QUFDdEMsS0FBSztBQUNMLCtEQUErRCIsImZpbGUiOiJhbWF4Q29tcG9uZW50cy9hbWF4Q3JtVUlDb21wb25lbnQuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCB9IGZyb20gJ2FuZ3VsYXIyL2NvcmUnO1xyXG5pbXBvcnQge0FtYXhDcm1OYXZiYXJDb21wb25lbnR9IGZyb20gXCIuL2FtYXhDcm1OYXZiYXJDb21wb25lbnRcIjtcclxuaW1wb3J0IHtBbWF4Q3JtU2lkZWJhckNvbXBvbmVudH0gZnJvbSBcIi4vYW1heENybVNpZGViYXJDb21wb25lbnRcIjtcclxuaW1wb3J0IHtBbWF4Q3JtQnJlYWRjcnVtYkNvbXBvbmVudH0gZnJvbSBcIi4vYW1heENybUJyZWFkY3J1bWJDb21wb25lbnRcIjtcclxuaW1wb3J0IHtST1VURVJfRElSRUNUSVZFU30gZnJvbSBcImFuZ3VsYXIyL3JvdXRlclwiO1xyXG5kZWNsYXJlIHZhciBqUXVlcnk7XHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdteC11aScsXHJcbiAgICB0ZW1wbGF0ZVVybCA6ICcuL2FwcC9hbWF4Q29tcG9uZW50cy90ZW1wbGF0ZXMvYW1heENybVVJLmh0bWwnLFxyXG4gICAgZGlyZWN0aXZlczpbUk9VVEVSX0RJUkVDVElWRVMsIEFtYXhDcm1OYXZiYXJDb21wb25lbnQsIEFtYXhDcm1TaWRlYmFyQ29tcG9uZW50LCBBbWF4Q3JtQnJlYWRjcnVtYkNvbXBvbmVudF1cclxufSlcclxuZXhwb3J0IGNsYXNzIEFtYXhDcm1VSUNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdHtcclxuICAgIG5nT25Jbml0KCkge1xyXG5cclxuICAgICAgICAvLy8vdmFyIHdpbmRXaWR0aCA9IGpRdWVyeSh3aW5kb3cpLndpZHRoKCk7XHJcbiAgICAgICAgLy8vL2lmICh3aW5kV2lkdGggPiAyNTApIHtcclxuICAgICAgICAvLyAgICB2YXIgYnJ3aWR0aCA9IHNjcmVlbi53aWR0aDtcclxuICAgICAgICAvLyAgICB2YXIgc2lkZVdpZHRoID0galF1ZXJ5KFwiI3NsaWRlLW91dFwiKS53aWR0aCgpO1xyXG4gICAgICAgIC8vICAgIGpRdWVyeShcIi5icmVhZGNydW1ic1wiKS5jc3MoXCJ3aWR0aFwiLCBicndpZHRoIC0gc2lkZVdpZHRoICk7XHJcbiAgICAgICAgLy8vL31cclxuICAgIH1cclxufVxyXG5cclxuXHJcblxyXG4gICAgLy8gdGVtcGxhdGUgOiBgXHJcbiAgICAvLyAgICAgPG14LW5hdmJhcj48L214LW5hdmJhcj5cclxuICAgIC8vICAgICA8ZGl2IGNsYXNzPVwibWFpbi1jb250YWluZXJcIiBpZD1cIm1haW4tY29udGFpbmVyXCI+XHJcbiAgICAvLyAgICAgICAgIDxteC1zaWRlYmFyPjwvbXgtc2lkZWJhcj5cclxuICAgIC8vICAgICA8L2Rpdj48IS0tIC8ubWFpbi1jb250YWluZXIgLS0+XHJcbiAgICAvLyBgLFxyXG4gICAgLy9kaXJlY3RpdmVzOiBbQW1heENybU5hdmJhckNvbXBvbmVudCwgQW1heENybVNpZGViYXJDb21wb25lbnRdIl19
