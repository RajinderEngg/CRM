System.register(['angular2/core', "angular2/router", "../services/ResourceService"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1, ResourceService_1;
    var AmaxCrmSidebarComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (ResourceService_1_1) {
                ResourceService_1 = ResourceService_1_1;
            }],
        execute: function() {
            AmaxCrmSidebarComponent = (function () {
                function AmaxCrmSidebarComponent(_resourceService) {
                    this._resourceService = _resourceService;
                    this.UserName = "";
                }
                AmaxCrmSidebarComponent.prototype.LogOut = function () {
                    var empid = localStorage.getItem("employeeid");
                    localStorage.clear();
                    sessionStorage.clear();
                    //debugger;
                    //var data = this._resourceService.getCookie("
                    //    this._resourceService.setCookie("UserDet", data, 10);
                    //var data = this._resourceService.getCookie("RememberKey");  
                    //this._resourceService.setCookie("UserDet", data, 10); 
                    this._resourceService.deleteCookie("RememberKey");
                    this._resourceService.deleteCookie(empid + "cust");
                    this._resourceService.deleteCookie(empid + "emp");
                    this._resourceService.deleteCookie(empid + "src");
                    this._resourceService.deleteCookie(empid + "ccode");
                    this._resourceService.deleteCookie(empid + "SMSDet");
                    this._resourceService.deleteCookie(empid + "SMSMessage");
                    this._resourceService.deleteCookie("TempImageName");
                    window.location.href = "/";
                };
                AmaxCrmSidebarComponent.prototype.ngOnInit = function () {
                    AMAX_CRM.enableSidebar();
                    var Uname = this._resourceService.getCookie("UserName");
                    if (Uname.length > 0 && Uname[0] == "=") {
                        Uname = Uname.substring(1, Uname.length);
                    }
                    this.UserName = Uname;
                    this.SideNav = this._resourceService.GetMenues();
                    //Main Left Sidebar Menu
                    $('.sidebar-collapse').sideNav({
                        edge: 'left',
                    });
                    // FULL SCREEN MENU (Layout 02)
                    $('.menu-sidebar-collapse').sideNav({
                        menuWidth: 240,
                        edge: 'left',
                        //closeOnClick:true, // Set if default menu open is true
                        menuOut: false // Set if default menu open is true
                    });
                    // HORIZONTAL MENU (Layout 03)
                    $('.dropdown-menu').dropdown({
                        inDuration: 300,
                        outDuration: 225,
                        constrain_width: false,
                        hover: true,
                        gutter: 0,
                        belowOrigin: true // Displays dropdown below the button
                    });
                    // Perfect Scrollbar
                    $('select').not('.disabled').material_select();
                    var leftnav = $(".page-topbar").height();
                    var leftnavHeight = window.innerHeight - leftnav;
                    $('.leftside-navigation').height(leftnavHeight).perfectScrollbar({
                        suppressScrollX: true
                    });
                    var righttnav = $("#chat-out").height();
                    $('.rightside-navigation').height(righttnav).perfectScrollbar({
                        suppressScrollX: true
                    });
                };
                AmaxCrmSidebarComponent = __decorate([
                    core_1.Component({
                        selector: 'mx-sidebar',
                        templateUrl: './app/amaxComponents/templates/amaxCrmSidebar.html',
                        directives: [router_1.ROUTER_DIRECTIVES],
                        providers: [ResourceService_1.ResourceService]
                    }), 
                    __metadata('design:paramtypes', [ResourceService_1.ResourceService])
                ], AmaxCrmSidebarComponent);
                return AmaxCrmSidebarComponent;
            }());
            exports_1("AmaxCrmSidebarComponent", AmaxCrmSidebarComponent);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFtYXhDb21wb25lbnRzL2FtYXhDcm1TaWRlYmFyQ29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1lBWUE7Z0JBR0ksaUNBQW9CLGdCQUFnQztvQkFBaEMscUJBQWdCLEdBQWhCLGdCQUFnQixDQUFnQjtvQkFEcEQsYUFBUSxHQUFXLEVBQUUsQ0FBQztnQkFDZ0MsQ0FBQztnQkFDdkQsd0NBQU0sR0FBTjtvQkFDSSxJQUFJLEtBQUssR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDO29CQUMvQyxZQUFZLENBQUMsS0FBSyxFQUFFLENBQUM7b0JBQ3JCLGNBQWMsQ0FBQyxLQUFLLEVBQUUsQ0FBQztvQkFDdkIsV0FBVztvQkFDWCw4Q0FBOEM7b0JBQzlDLDJEQUEyRDtvQkFFM0QsOERBQThEO29CQUM5RCx3REFBd0Q7b0JBQ3hELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLENBQUMsYUFBYSxDQUFDLENBQUM7b0JBQ2xELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLENBQUMsS0FBSyxHQUFHLE1BQU0sQ0FBQyxDQUFDO29CQUNuRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUMsQ0FBQztvQkFDbEQsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDLENBQUM7b0JBQ2xELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLENBQUMsS0FBSyxHQUFHLE9BQU8sQ0FBQyxDQUFDO29CQUNwRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUMsQ0FBQztvQkFDckQsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQyxLQUFLLEdBQUcsWUFBWSxDQUFDLENBQUM7b0JBQ3pELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLENBQUMsZUFBZSxDQUFDLENBQUM7b0JBQ3BELE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztnQkFDL0IsQ0FBQztnQkFDRCwwQ0FBUSxHQUFSO29CQUlJLFFBQVEsQ0FBQyxhQUFhLEVBQUUsQ0FBQztvQkFFekIsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztvQkFDeEQsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLEdBQUcsQ0FBQyxDQUFDLENBQUM7d0JBQ3RDLEtBQUssR0FBRyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQzdDLENBQUM7b0JBQ0QsSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7b0JBQ3RCLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsRUFBRSxDQUFDO29CQUdqRCx3QkFBd0I7b0JBQ3hCLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLE9BQU8sQ0FBQzt3QkFDM0IsSUFBSSxFQUFFLE1BQU07cUJBQ2YsQ0FBQyxDQUFDO29CQUVILCtCQUErQjtvQkFDL0IsQ0FBQyxDQUFDLHdCQUF3QixDQUFDLENBQUMsT0FBTyxDQUFDO3dCQUNoQyxTQUFTLEVBQUUsR0FBRzt3QkFDZCxJQUFJLEVBQUUsTUFBTTt3QkFDWix3REFBd0Q7d0JBQ3hELE9BQU8sRUFBRSxLQUFLLENBQUMsbUNBQW1DO3FCQUVyRCxDQUFDLENBQUM7b0JBRUgsOEJBQThCO29CQUM5QixDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxRQUFRLENBQUM7d0JBQ3pCLFVBQVUsRUFBRSxHQUFHO3dCQUNmLFdBQVcsRUFBRSxHQUFHO3dCQUNoQixlQUFlLEVBQUUsS0FBSzt3QkFDdEIsS0FBSyxFQUFFLElBQUk7d0JBQ1gsTUFBTSxFQUFFLENBQUM7d0JBQ1QsV0FBVyxFQUFFLElBQUksQ0FBQyxxQ0FBcUM7cUJBQzFELENBQUMsQ0FBQztvQkFHSCxvQkFBb0I7b0JBQ3BCLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUMsZUFBZSxFQUFFLENBQUM7b0JBQy9DLElBQUksT0FBTyxHQUFHLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztvQkFDekMsSUFBSSxhQUFhLEdBQUcsTUFBTSxDQUFDLFdBQVcsR0FBRyxPQUFPLENBQUM7b0JBQ2pELENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQzt3QkFDN0QsZUFBZSxFQUFFLElBQUk7cUJBQ3hCLENBQUMsQ0FBQztvQkFDSCxJQUFJLFNBQVMsR0FBRyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUM7b0JBQ3hDLENBQUMsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQzt3QkFDMUQsZUFBZSxFQUFFLElBQUk7cUJBQ3hCLENBQUMsQ0FBQztnQkFHUCxDQUFDO2dCQWxGTDtvQkFBQyxnQkFBUyxDQUFDO3dCQUNQLFFBQVEsRUFBRSxZQUFZO3dCQUN0QixXQUFXLEVBQUMsb0RBQW9EO3dCQUNoRSxVQUFVLEVBQUMsQ0FBQywwQkFBaUIsQ0FBQzt3QkFDOUIsU0FBUyxFQUFDLENBQUMsaUNBQWUsQ0FBQztxQkFDOUIsQ0FBQzs7MkNBQUE7Z0JBOEVGLDhCQUFDO1lBQUQsQ0E3RUEsQUE2RUMsSUFBQTtZQTdFRCw2REE2RUMsQ0FBQSIsImZpbGUiOiJhbWF4Q29tcG9uZW50cy9hbWF4Q3JtU2lkZWJhckNvbXBvbmVudC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7Q29tcG9uZW50LCBPbkluaXR9IGZyb20gJ2FuZ3VsYXIyL2NvcmUnO1xyXG5pbXBvcnQge1JPVVRFUl9ESVJFQ1RJVkVTfSBmcm9tIFwiYW5ndWxhcjIvcm91dGVyXCI7XHJcbmltcG9ydCB7UmVzb3VyY2VTZXJ2aWNlLCBNZW51ZUl0ZW19IGZyb20gXCIuLi9zZXJ2aWNlcy9SZXNvdXJjZVNlcnZpY2VcIjtcclxuXHJcbmRlY2xhcmUgdmFyIEFNQVhfQ1JNO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ214LXNpZGViYXInLFxyXG4gICAgdGVtcGxhdGVVcmw6Jy4vYXBwL2FtYXhDb21wb25lbnRzL3RlbXBsYXRlcy9hbWF4Q3JtU2lkZWJhci5odG1sJyxcclxuICAgIGRpcmVjdGl2ZXM6W1JPVVRFUl9ESVJFQ1RJVkVTXSxcclxuICAgIHByb3ZpZGVyczpbUmVzb3VyY2VTZXJ2aWNlXVxyXG59KVxyXG5leHBvcnQgY2xhc3MgQW1heENybVNpZGViYXJDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXR7XHJcbiAgICBTaWRlTmF2OiBQcm9taXNlPGFueT47XHJcbiAgICBVc2VyTmFtZTogc3RyaW5nID0gXCJcIjtcclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgX3Jlc291cmNlU2VydmljZTpSZXNvdXJjZVNlcnZpY2Upe31cclxuICAgIExvZ091dCgpIHtcclxuICAgICAgICB2YXIgZW1waWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImVtcGxveWVlaWRcIik7XHJcbiAgICAgICAgbG9jYWxTdG9yYWdlLmNsZWFyKCk7XHJcbiAgICAgICAgc2Vzc2lvblN0b3JhZ2UuY2xlYXIoKTtcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgIC8vdmFyIGRhdGEgPSB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZ2V0Q29va2llKFwiXHJcbiAgICAgICAgLy8gICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLnNldENvb2tpZShcIlVzZXJEZXRcIiwgZGF0YSwgMTApO1xyXG5cclxuICAgICAgICAvL3ZhciBkYXRhID0gdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmdldENvb2tpZShcIlJlbWVtYmVyS2V5XCIpOyAgXHJcbiAgICAgICAgLy90aGlzLl9yZXNvdXJjZVNlcnZpY2Uuc2V0Q29va2llKFwiVXNlckRldFwiLCBkYXRhLCAxMCk7IFxyXG4gICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5kZWxldGVDb29raWUoXCJSZW1lbWJlcktleVwiKTtcclxuICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZGVsZXRlQ29va2llKGVtcGlkICsgXCJjdXN0XCIpO1xyXG4gICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5kZWxldGVDb29raWUoZW1waWQgKyBcImVtcFwiKTtcclxuICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZGVsZXRlQ29va2llKGVtcGlkICsgXCJzcmNcIik7XHJcbiAgICAgICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmRlbGV0ZUNvb2tpZShlbXBpZCArIFwiY2NvZGVcIik7XHJcbiAgICAgICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmRlbGV0ZUNvb2tpZShlbXBpZCArIFwiU01TRGV0XCIpO1xyXG4gICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5kZWxldGVDb29raWUoZW1waWQgKyBcIlNNU01lc3NhZ2VcIik7XHJcbiAgICAgICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmRlbGV0ZUNvb2tpZShcIlRlbXBJbWFnZU5hbWVcIik7XHJcbiAgICAgICAgd2luZG93LmxvY2F0aW9uLmhyZWYgPSBcIi9cIjtcclxuICAgIH1cclxuICAgIG5nT25Jbml0KCkge1xyXG5cclxuXHJcbiAgICAgICAgXHJcbiAgICAgICAgQU1BWF9DUk0uZW5hYmxlU2lkZWJhcigpO1xyXG5cclxuICAgICAgICB2YXIgVW5hbWUgPSB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZ2V0Q29va2llKFwiVXNlck5hbWVcIik7XHJcbiAgICAgICAgaWYgKFVuYW1lLmxlbmd0aCA+IDAgJiYgVW5hbWVbMF0gPT0gXCI9XCIpIHtcclxuICAgICAgICAgICAgVW5hbWUgPSBVbmFtZS5zdWJzdHJpbmcoMSwgVW5hbWUubGVuZ3RoKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5Vc2VyTmFtZSA9IFVuYW1lO1xyXG4gICAgICAgIHRoaXMuU2lkZU5hdiA9IHRoaXMuX3Jlc291cmNlU2VydmljZS5HZXRNZW51ZXMoKTtcclxuXHJcblxyXG4gICAgICAgIC8vTWFpbiBMZWZ0IFNpZGViYXIgTWVudVxyXG4gICAgICAgICQoJy5zaWRlYmFyLWNvbGxhcHNlJykuc2lkZU5hdih7XHJcbiAgICAgICAgICAgIGVkZ2U6ICdsZWZ0JywgLy8gQ2hvb3NlIHRoZSBob3Jpem9udGFsIG9yaWdpbiAgICBcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgLy8gRlVMTCBTQ1JFRU4gTUVOVSAoTGF5b3V0IDAyKVxyXG4gICAgICAgICQoJy5tZW51LXNpZGViYXItY29sbGFwc2UnKS5zaWRlTmF2KHtcclxuICAgICAgICAgICAgbWVudVdpZHRoOiAyNDAsXHJcbiAgICAgICAgICAgIGVkZ2U6ICdsZWZ0JywgLy8gQ2hvb3NlIHRoZSBob3Jpem9udGFsIG9yaWdpbiAgICAgXHJcbiAgICAgICAgICAgIC8vY2xvc2VPbkNsaWNrOnRydWUsIC8vIFNldCBpZiBkZWZhdWx0IG1lbnUgb3BlbiBpcyB0cnVlXHJcbiAgICAgICAgICAgIG1lbnVPdXQ6IGZhbHNlIC8vIFNldCBpZiBkZWZhdWx0IG1lbnUgb3BlbiBpcyB0cnVlXHJcbiAgICAgICAgXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIC8vIEhPUklaT05UQUwgTUVOVSAoTGF5b3V0IDAzKVxyXG4gICAgICAgICQoJy5kcm9wZG93bi1tZW51JykuZHJvcGRvd24oe1xyXG4gICAgICAgICAgICBpbkR1cmF0aW9uOiAzMDAsXHJcbiAgICAgICAgICAgIG91dER1cmF0aW9uOiAyMjUsXHJcbiAgICAgICAgICAgIGNvbnN0cmFpbl93aWR0aDogZmFsc2UsIC8vIERvZXMgbm90IGNoYW5nZSB3aWR0aCBvZiBkcm9wZG93biB0byB0aGF0IG9mIHRoZSBhY3RpdmF0b3JcclxuICAgICAgICAgICAgaG92ZXI6IHRydWUsIC8vIEFjdGl2YXRlIG9uIGhvdmVyXHJcbiAgICAgICAgICAgIGd1dHRlcjogMCwgLy8gU3BhY2luZyBmcm9tIGVkZ2VcclxuICAgICAgICAgICAgYmVsb3dPcmlnaW46IHRydWUgLy8gRGlzcGxheXMgZHJvcGRvd24gYmVsb3cgdGhlIGJ1dHRvblxyXG4gICAgICAgIH0pO1xyXG5cclxuXHJcbiAgICAgICAgLy8gUGVyZmVjdCBTY3JvbGxiYXJcclxuICAgICAgICAkKCdzZWxlY3QnKS5ub3QoJy5kaXNhYmxlZCcpLm1hdGVyaWFsX3NlbGVjdCgpO1xyXG4gICAgICAgIHZhciBsZWZ0bmF2ID0gJChcIi5wYWdlLXRvcGJhclwiKS5oZWlnaHQoKTtcclxuICAgICAgICB2YXIgbGVmdG5hdkhlaWdodCA9IHdpbmRvdy5pbm5lckhlaWdodCAtIGxlZnRuYXY7XHJcbiAgICAgICAgJCgnLmxlZnRzaWRlLW5hdmlnYXRpb24nKS5oZWlnaHQobGVmdG5hdkhlaWdodCkucGVyZmVjdFNjcm9sbGJhcih7XHJcbiAgICAgICAgICAgIHN1cHByZXNzU2Nyb2xsWDogdHJ1ZVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHZhciByaWdodHRuYXYgPSAkKFwiI2NoYXQtb3V0XCIpLmhlaWdodCgpO1xyXG4gICAgICAgICQoJy5yaWdodHNpZGUtbmF2aWdhdGlvbicpLmhlaWdodChyaWdodHRuYXYpLnBlcmZlY3RTY3JvbGxiYXIoe1xyXG4gICAgICAgICAgICBzdXBwcmVzc1Njcm9sbFg6IHRydWVcclxuICAgICAgICB9KTsgXHJcblxyXG5cclxuICAgIH1cclxufSJdfQ==
