System.register(['angular2/core', "angular2/router", "../services/ResourceService"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1, ResourceService_1;
    var AmaxCrmNavbarComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (ResourceService_1_1) {
                ResourceService_1 = ResourceService_1_1;
            }],
        execute: function() {
            AmaxCrmNavbarComponent = (function () {
                function AmaxCrmNavbarComponent(_resourceService) {
                    this._resourceService = _resourceService;
                    this.LogoCSS = "";
                    this.toolsCSS = "";
                    this.LangDDCSS = "";
                    this.Lang = "";
                    this.languageArray = [];
                    this.LanguageId = "";
                    this.IsRTL = "";
                    this._userModel = {};
                    var lang = _resourceService.getCookie("lang");
                    if (lang.length > 0)
                        lang = lang.substring(1, lang.length);
                    if (lang == "")
                        lang = "en";
                    this.LanguageId = lang;
                    // alert(this.LanguageId);
                }
                AmaxCrmNavbarComponent.prototype.ChangeLanguage = function () {
                    this.LanguageId = jQuery("#LangDD").val();
                    ////localStorage.setItem("lang", this.LanguageId);
                    ////var lang = localStorage.getItem("lang");
                    //////this._resourceService.deleteCookie("lang");
                    //////localStorage.clear();
                    //////sessionStorage.clear();
                    ////this._resourceService.setCookie("lang", this.LanguageId,10 );
                    //////localStorage.clear();
                    ////window.location.href = "/";
                    //console.log("Changing Language...");
                    //this.logout();
                    //if (this.LanguageId) {
                    //    this._resourceService.GetSelecetdLanguage(this.LanguageId).subscribe(
                    //        data => {
                    //            //localStorage.setItem("langresource", JSON.stringify(data));
                    //            localStorage.setItem("lang", this.LanguageId);
                    //            //this._resourceService.setCookie("lang", this.LanguageId, 10);
                    //        },
                    //        error => console.log("Unable to load Language Data"),
                    //        () => {
                    //            console.log("Language resource loaded");
                    //        }
                    //    );
                    //}
                    localStorage.setItem("lang", this.LanguageId);
                    this._resourceService.setCookie("lang", this.LanguageId, 10);
                    debugger;
                    var UserDet = JSON.parse(sessionStorage.getItem('userInformation'));
                    //this._userModel = {
                    //    userName: UserName,
                    //    password: "",
                    //    orgName: orgName,
                    //    lang: lang,
                    //    rememberMe: rememberMe
                    //}
                    //if (temp != "" && temp != undefined) {
                    //    var dta = $.parseJSON(temp).Data;
                    //    this.LoginData = dta;
                    //    var userdet = JSON.parse(atob(dta["token"].split('.')[1]));
                    //    userdet.Language = lang;
                    //    var stinguserdet = JSON.stringify(userdet);
                    //    dta["token"].split('.')[1] = JSON.stringify(userdet);
                    //    var uts = dta["token"].split('.')[1];
                    //    alert(userdet.Language);
                    //    sessionStorage.setItem('XToken', dta["token"])
                    //    sessionStorage.setItem('sessionInformation', atob(dta["token"].split('.')[0]));
                    //    sessionStorage.setItem('userInformation', atob(dta["token"].split('.')[1]));
                    //    var t = sessionStorage.getItem('sessionInformation');
                    //    var ut = sessionStorage.getItem('userInformation');
                    //    //Featching Userinformation
                    //    this.LoginData = JSON.parse(atob(dta["token"].split('.')[1]));
                    //    //var langres = this.getCookie("langresource");
                    //    this.getlangres(this.LoginData.Language);
                    //    localStorage.setItem("lang", this.LoginData.Language);
                    //    localStorage.setItem("employeeid", this.LoginData.employeeid);
                    //    this.IsLogedIn = true;
                    //}
                    window.location.href = "/";
                };
                AmaxCrmNavbarComponent.prototype.logout = function () {
                    var empid = localStorage.getItem("employeeid");
                    localStorage.clear();
                    sessionStorage.clear();
                    //debugger;
                    //var data = this._resourceService.getCookie("
                    //    this._resourceService.setCookie("UserDet", data, 10);
                    //var data = this._resourceService.getCookie("RememberKey");  
                    //this._resourceService.setCookie("UserDet", data, 10); 
                    this._resourceService.deleteCookie("RememberKey");
                    this._resourceService.deleteCookie(empid + "cust");
                    this._resourceService.deleteCookie(empid + "emp");
                    this._resourceService.deleteCookie(empid + "src");
                    this._resourceService.deleteCookie(empid + "ccode");
                    this._resourceService.deleteCookie(empid + "SMSDet");
                    this._resourceService.deleteCookie(empid + "SMSMessage");
                    window.location.href = "/";
                };
                AmaxCrmNavbarComponent.prototype.ngOnInit = function () {
                    this.languageArray = this._resourceService.GetAvailableLanguages();
                    var lng = this._resourceService.getCookie("lang");
                    if (lng.length > 0)
                        lng = lng.substring(1, lng.length);
                    if (lng == "")
                        lng = "en";
                    this.Lang = lng;
                    //alert(this.Lang+" lang");
                    if (this.Lang == "he") {
                        this.IsRTL = "rtl";
                    }
                    else {
                        this.IsRTL = "ltr";
                    }
                };
                AmaxCrmNavbarComponent = __decorate([
                    core_1.Component({
                        selector: 'mx-navbar',
                        templateUrl: './app/amaxComponents/templates/amaxCrmNavbar.html',
                        directives: [router_1.ROUTER_DIRECTIVES]
                    }), 
                    __metadata('design:paramtypes', [ResourceService_1.ResourceService])
                ], AmaxCrmNavbarComponent);
                return AmaxCrmNavbarComponent;
            }());
            exports_1("AmaxCrmNavbarComponent", AmaxCrmNavbarComponent);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFtYXhDb21wb25lbnRzL2FtYXhDcm1OYXZiYXJDb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7WUFVQTtnQkFTSSxnQ0FBb0IsZ0JBQWlDO29CQUFqQyxxQkFBZ0IsR0FBaEIsZ0JBQWdCLENBQWlCO29CQVJyRCxZQUFPLEdBQVcsRUFBRSxDQUFDO29CQUNyQixhQUFRLEdBQVcsRUFBRSxDQUFDO29CQUN0QixjQUFTLEdBQVcsRUFBRSxDQUFDO29CQUN2QixTQUFJLEdBQVcsRUFBRSxDQUFDO29CQUNsQixrQkFBYSxHQUFHLEVBQUUsQ0FBQztvQkFDbkIsZUFBVSxHQUFXLEVBQUUsQ0FBQztvQkFDeEIsVUFBSyxHQUFXLEVBQUUsQ0FBQztvQkFDbkIsZUFBVSxHQUFHLEVBQUUsQ0FBQztvQkFFWixJQUFJLElBQUksR0FBRyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQzlDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO3dCQUNoQixJQUFJLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUMxQyxFQUFFLENBQUMsQ0FBQyxJQUFJLElBQUksRUFBRSxDQUFDO3dCQUNYLElBQUksR0FBRyxJQUFJLENBQUM7b0JBQ2hCLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO29CQUN4QiwwQkFBMEI7Z0JBQzdCLENBQUM7Z0JBQ0QsK0NBQWMsR0FBZDtvQkFDSSxJQUFJLENBQUMsVUFBVSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQztvQkFDMUMsa0RBQWtEO29CQUNsRCw0Q0FBNEM7b0JBQzVDLGlEQUFpRDtvQkFFakQsMkJBQTJCO29CQUMzQiw2QkFBNkI7b0JBQzdCLGlFQUFpRTtvQkFDakUsMkJBQTJCO29CQUczQiwrQkFBK0I7b0JBQy9CLHNDQUFzQztvQkFFdEMsZ0JBQWdCO29CQUNoQix3QkFBd0I7b0JBQ3hCLDJFQUEyRTtvQkFDM0UsbUJBQW1CO29CQUNuQiwyRUFBMkU7b0JBRTNFLDREQUE0RDtvQkFDNUQsNkVBQTZFO29CQUc3RSxZQUFZO29CQUNaLCtEQUErRDtvQkFDL0QsaUJBQWlCO29CQUNqQixzREFBc0Q7b0JBQ3RELFdBQVc7b0JBQ1gsUUFBUTtvQkFFUixHQUFHO29CQUNILFlBQVksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztvQkFDOUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLFVBQVUsRUFBRSxFQUFFLENBQUMsQ0FBQztvQkFFN0QsUUFBUSxDQUFDO29CQUNULElBQUksT0FBTyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUM7b0JBQ3BFLHFCQUFxQjtvQkFDckIseUJBQXlCO29CQUN6QixtQkFBbUI7b0JBQ25CLHVCQUF1QjtvQkFDdkIsaUJBQWlCO29CQUNqQiw0QkFBNEI7b0JBQzVCLEdBQUc7b0JBQ0gsd0NBQXdDO29CQUN4Qyx1Q0FBdUM7b0JBQ3ZDLDJCQUEyQjtvQkFDM0IsaUVBQWlFO29CQUNqRSw4QkFBOEI7b0JBQzlCLGlEQUFpRDtvQkFDakQsMkRBQTJEO29CQUMzRCwyQ0FBMkM7b0JBQzNDLDhCQUE4QjtvQkFDOUIsb0RBQW9EO29CQUNwRCxxRkFBcUY7b0JBQ3JGLGtGQUFrRjtvQkFDbEYsMkRBQTJEO29CQUMzRCx5REFBeUQ7b0JBQ3pELGlDQUFpQztvQkFDakMsb0VBQW9FO29CQUNwRSxxREFBcUQ7b0JBQ3JELCtDQUErQztvQkFDL0MsNERBQTREO29CQUM1RCxvRUFBb0U7b0JBQ3BFLDRCQUE0QjtvQkFDNUIsR0FBRztvQkFDSCxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUM7Z0JBRS9CLENBQUM7Z0JBQ0QsdUNBQU0sR0FBTjtvQkFDSSxJQUFJLEtBQUssR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDO29CQUMvQyxZQUFZLENBQUMsS0FBSyxFQUFFLENBQUM7b0JBQ3JCLGNBQWMsQ0FBQyxLQUFLLEVBQUUsQ0FBQztvQkFDdkIsV0FBVztvQkFDWCw4Q0FBOEM7b0JBQzlDLDJEQUEyRDtvQkFFM0QsOERBQThEO29CQUM5RCx3REFBd0Q7b0JBQ3hELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLENBQUMsYUFBYSxDQUFDLENBQUM7b0JBQ2xELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLENBQUMsS0FBSyxHQUFHLE1BQU0sQ0FBQyxDQUFDO29CQUNuRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUMsQ0FBQztvQkFDbEQsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDLENBQUM7b0JBQ2xELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLENBQUMsS0FBSyxHQUFHLE9BQU8sQ0FBQyxDQUFDO29CQUNwRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUMsQ0FBQztvQkFDckQsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQyxLQUFLLEdBQUUsWUFBWSxDQUFDLENBQUM7b0JBQ3hELE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxHQUFDLEdBQUcsQ0FBQztnQkFDN0IsQ0FBQztnQkFHRCx5Q0FBUSxHQUFSO29CQUNJLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLHFCQUFxQixFQUFFLENBQUM7b0JBQ25FLElBQUksR0FBRyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQ2xELEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO3dCQUNmLEdBQUcsR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQ3ZDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsSUFBSSxFQUFFLENBQUM7d0JBQ1YsR0FBRyxHQUFHLElBQUksQ0FBQztvQkFDZixJQUFJLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztvQkFDaEIsMkJBQTJCO29CQUMzQixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7d0JBQ3BCLElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO29CQUN2QixDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUNGLElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO29CQUN2QixDQUFDO2dCQUNMLENBQUM7Z0JBaklMO29CQUFDLGdCQUFTLENBQUM7d0JBQ1AsUUFBUSxFQUFFLFdBQVc7d0JBQ3JCLFdBQVcsRUFBQyxtREFBbUQ7d0JBQy9ELFVBQVUsRUFBQyxDQUFDLDBCQUFpQixDQUFDO3FCQUNqQyxDQUFDOzswQ0FBQTtnQkE4SEYsNkJBQUM7WUFBRCxDQTdIQSxBQTZIQyxJQUFBO1lBN0hELDJEQTZIQyxDQUFBIiwiZmlsZSI6ImFtYXhDb21wb25lbnRzL2FtYXhDcm1OYXZiYXJDb21wb25lbnQuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge0NvbXBvbmVudCwgT25Jbml0fSBmcm9tICdhbmd1bGFyMi9jb3JlJztcclxuaW1wb3J0IHtST1VURVJfRElSRUNUSVZFU30gZnJvbSBcImFuZ3VsYXIyL3JvdXRlclwiO1xyXG5pbXBvcnQge1Jlc291cmNlU2VydmljZX0gZnJvbSBcIi4uL3NlcnZpY2VzL1Jlc291cmNlU2VydmljZVwiO1xyXG5cclxuZGVjbGFyZSB2YXIgalF1ZXJ5O1xyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAnbXgtbmF2YmFyJyxcclxuICAgIHRlbXBsYXRlVXJsOicuL2FwcC9hbWF4Q29tcG9uZW50cy90ZW1wbGF0ZXMvYW1heENybU5hdmJhci5odG1sJyxcclxuICAgIGRpcmVjdGl2ZXM6W1JPVVRFUl9ESVJFQ1RJVkVTXVxyXG59KVxyXG5leHBvcnQgY2xhc3MgQW1heENybU5hdmJhckNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdHtcclxuICAgIExvZ29DU1M6IHN0cmluZyA9IFwiXCI7XHJcbiAgICB0b29sc0NTUzogc3RyaW5nID0gXCJcIjtcclxuICAgIExhbmdERENTUzogc3RyaW5nID0gXCJcIjtcclxuICAgIExhbmc6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBsYW5ndWFnZUFycmF5ID0gW107XHJcbiAgICBMYW5ndWFnZUlkOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgSXNSVEw6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBfdXNlck1vZGVsID0ge307XHJcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIF9yZXNvdXJjZVNlcnZpY2U6IFJlc291cmNlU2VydmljZSkge1xyXG4gICAgICAgIHZhciBsYW5nID0gX3Jlc291cmNlU2VydmljZS5nZXRDb29raWUoXCJsYW5nXCIpO1xyXG4gICAgICAgIGlmIChsYW5nLmxlbmd0aCA+IDApXHJcbiAgICAgICAgICAgIGxhbmcgPSBsYW5nLnN1YnN0cmluZygxLCBsYW5nLmxlbmd0aCk7XHJcbiAgICAgICAgaWYgKGxhbmcgPT0gXCJcIilcclxuICAgICAgICAgICAgbGFuZyA9IFwiZW5cIjtcclxuICAgICAgICB0aGlzLkxhbmd1YWdlSWQgPSBsYW5nO1xyXG4gICAgICAgLy8gYWxlcnQodGhpcy5MYW5ndWFnZUlkKTtcclxuICAgIH1cclxuICAgIENoYW5nZUxhbmd1YWdlKCkge1xyXG4gICAgICAgIHRoaXMuTGFuZ3VhZ2VJZCA9IGpRdWVyeShcIiNMYW5nRERcIikudmFsKCk7XHJcbiAgICAgICAgLy8vL2xvY2FsU3RvcmFnZS5zZXRJdGVtKFwibGFuZ1wiLCB0aGlzLkxhbmd1YWdlSWQpO1xyXG4gICAgICAgIC8vLy92YXIgbGFuZyA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwibGFuZ1wiKTtcclxuICAgICAgICAvLy8vLy90aGlzLl9yZXNvdXJjZVNlcnZpY2UuZGVsZXRlQ29va2llKFwibGFuZ1wiKTtcclxuXHJcbiAgICAgICAgLy8vLy8vbG9jYWxTdG9yYWdlLmNsZWFyKCk7XHJcbiAgICAgICAgLy8vLy8vc2Vzc2lvblN0b3JhZ2UuY2xlYXIoKTtcclxuICAgICAgICAvLy8vdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLnNldENvb2tpZShcImxhbmdcIiwgdGhpcy5MYW5ndWFnZUlkLDEwICk7XHJcbiAgICAgICAgLy8vLy8vbG9jYWxTdG9yYWdlLmNsZWFyKCk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgXHJcbiAgICAgICAgLy8vL3dpbmRvdy5sb2NhdGlvbi5ocmVmID0gXCIvXCI7XHJcbiAgICAgICAgLy9jb25zb2xlLmxvZyhcIkNoYW5naW5nIExhbmd1YWdlLi4uXCIpO1xyXG4gICAgICAgIFxyXG4gICAgICAgIC8vdGhpcy5sb2dvdXQoKTtcclxuICAgICAgICAvL2lmICh0aGlzLkxhbmd1YWdlSWQpIHtcclxuICAgICAgICAvLyAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuR2V0U2VsZWNldGRMYW5ndWFnZSh0aGlzLkxhbmd1YWdlSWQpLnN1YnNjcmliZShcclxuICAgICAgICAvLyAgICAgICAgZGF0YSA9PiB7XHJcbiAgICAgICAgLy8gICAgICAgICAgICAvL2xvY2FsU3RvcmFnZS5zZXRJdGVtKFwibGFuZ3Jlc291cmNlXCIsIEpTT04uc3RyaW5naWZ5KGRhdGEpKTtcclxuXHJcbiAgICAgICAgLy8gICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImxhbmdcIiwgdGhpcy5MYW5ndWFnZUlkKTtcclxuICAgICAgICAvLyAgICAgICAgICAgIC8vdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLnNldENvb2tpZShcImxhbmdcIiwgdGhpcy5MYW5ndWFnZUlkLCAxMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcblxyXG4gICAgICAgIC8vICAgICAgICB9LFxyXG4gICAgICAgIC8vICAgICAgICBlcnJvciA9PiBjb25zb2xlLmxvZyhcIlVuYWJsZSB0byBsb2FkIExhbmd1YWdlIERhdGFcIiksXHJcbiAgICAgICAgLy8gICAgICAgICgpID0+IHtcclxuICAgICAgICAvLyAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiTGFuZ3VhZ2UgcmVzb3VyY2UgbG9hZGVkXCIpO1xyXG4gICAgICAgIC8vICAgICAgICB9XHJcbiAgICAgICAgLy8gICAgKTtcclxuXHJcbiAgICAgICAgLy99XHJcbiAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJsYW5nXCIsIHRoaXMuTGFuZ3VhZ2VJZCk7XHJcbiAgICAgICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLnNldENvb2tpZShcImxhbmdcIiwgdGhpcy5MYW5ndWFnZUlkLCAxMCk7XHJcblxyXG4gICAgICAgIGRlYnVnZ2VyO1xyXG4gICAgICAgIHZhciBVc2VyRGV0ID0gSlNPTi5wYXJzZShzZXNzaW9uU3RvcmFnZS5nZXRJdGVtKCd1c2VySW5mb3JtYXRpb24nKSk7XHJcbiAgICAgICAgLy90aGlzLl91c2VyTW9kZWwgPSB7XHJcbiAgICAgICAgLy8gICAgdXNlck5hbWU6IFVzZXJOYW1lLFxyXG4gICAgICAgIC8vICAgIHBhc3N3b3JkOiBcIlwiLFxyXG4gICAgICAgIC8vICAgIG9yZ05hbWU6IG9yZ05hbWUsXHJcbiAgICAgICAgLy8gICAgbGFuZzogbGFuZyxcclxuICAgICAgICAvLyAgICByZW1lbWJlck1lOiByZW1lbWJlck1lXHJcbiAgICAgICAgLy99XHJcbiAgICAgICAgLy9pZiAodGVtcCAhPSBcIlwiICYmIHRlbXAgIT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgLy8gICAgdmFyIGR0YSA9ICQucGFyc2VKU09OKHRlbXApLkRhdGE7XHJcbiAgICAgICAgLy8gICAgdGhpcy5Mb2dpbkRhdGEgPSBkdGE7XHJcbiAgICAgICAgLy8gICAgdmFyIHVzZXJkZXQgPSBKU09OLnBhcnNlKGF0b2IoZHRhW1widG9rZW5cIl0uc3BsaXQoJy4nKVsxXSkpO1xyXG4gICAgICAgIC8vICAgIHVzZXJkZXQuTGFuZ3VhZ2UgPSBsYW5nO1xyXG4gICAgICAgIC8vICAgIHZhciBzdGluZ3VzZXJkZXQgPSBKU09OLnN0cmluZ2lmeSh1c2VyZGV0KTtcclxuICAgICAgICAvLyAgICBkdGFbXCJ0b2tlblwiXS5zcGxpdCgnLicpWzFdID0gSlNPTi5zdHJpbmdpZnkodXNlcmRldCk7XHJcbiAgICAgICAgLy8gICAgdmFyIHV0cyA9IGR0YVtcInRva2VuXCJdLnNwbGl0KCcuJylbMV07XHJcbiAgICAgICAgLy8gICAgYWxlcnQodXNlcmRldC5MYW5ndWFnZSk7XHJcbiAgICAgICAgLy8gICAgc2Vzc2lvblN0b3JhZ2Uuc2V0SXRlbSgnWFRva2VuJywgZHRhW1widG9rZW5cIl0pXHJcbiAgICAgICAgLy8gICAgc2Vzc2lvblN0b3JhZ2Uuc2V0SXRlbSgnc2Vzc2lvbkluZm9ybWF0aW9uJywgYXRvYihkdGFbXCJ0b2tlblwiXS5zcGxpdCgnLicpWzBdKSk7XHJcbiAgICAgICAgLy8gICAgc2Vzc2lvblN0b3JhZ2Uuc2V0SXRlbSgndXNlckluZm9ybWF0aW9uJywgYXRvYihkdGFbXCJ0b2tlblwiXS5zcGxpdCgnLicpWzFdKSk7XHJcbiAgICAgICAgLy8gICAgdmFyIHQgPSBzZXNzaW9uU3RvcmFnZS5nZXRJdGVtKCdzZXNzaW9uSW5mb3JtYXRpb24nKTtcclxuICAgICAgICAvLyAgICB2YXIgdXQgPSBzZXNzaW9uU3RvcmFnZS5nZXRJdGVtKCd1c2VySW5mb3JtYXRpb24nKTtcclxuICAgICAgICAvLyAgICAvL0ZlYXRjaGluZyBVc2VyaW5mb3JtYXRpb25cclxuICAgICAgICAvLyAgICB0aGlzLkxvZ2luRGF0YSA9IEpTT04ucGFyc2UoYXRvYihkdGFbXCJ0b2tlblwiXS5zcGxpdCgnLicpWzFdKSk7XHJcbiAgICAgICAgLy8gICAgLy92YXIgbGFuZ3JlcyA9IHRoaXMuZ2V0Q29va2llKFwibGFuZ3Jlc291cmNlXCIpO1xyXG4gICAgICAgIC8vICAgIHRoaXMuZ2V0bGFuZ3Jlcyh0aGlzLkxvZ2luRGF0YS5MYW5ndWFnZSk7XHJcbiAgICAgICAgLy8gICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJsYW5nXCIsIHRoaXMuTG9naW5EYXRhLkxhbmd1YWdlKTtcclxuICAgICAgICAvLyAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImVtcGxveWVlaWRcIiwgdGhpcy5Mb2dpbkRhdGEuZW1wbG95ZWVpZCk7XHJcbiAgICAgICAgLy8gICAgdGhpcy5Jc0xvZ2VkSW4gPSB0cnVlO1xyXG4gICAgICAgIC8vfVxyXG4gICAgICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmID0gXCIvXCI7XHJcbiAgICAgICAgXHJcbiAgICB9XHJcbiAgICBsb2dvdXQoKSB7XHJcbiAgICAgICAgdmFyIGVtcGlkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJlbXBsb3llZWlkXCIpO1xyXG4gICAgICAgIGxvY2FsU3RvcmFnZS5jbGVhcigpO1xyXG4gICAgICAgIHNlc3Npb25TdG9yYWdlLmNsZWFyKCk7XHJcbiAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAvL3ZhciBkYXRhID0gdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmdldENvb2tpZShcIlxyXG4gICAgICAgIC8vICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5zZXRDb29raWUoXCJVc2VyRGV0XCIsIGRhdGEsIDEwKTtcclxuXHJcbiAgICAgICAgLy92YXIgZGF0YSA9IHRoaXMuX3Jlc291cmNlU2VydmljZS5nZXRDb29raWUoXCJSZW1lbWJlcktleVwiKTsgIFxyXG4gICAgICAgIC8vdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLnNldENvb2tpZShcIlVzZXJEZXRcIiwgZGF0YSwgMTApOyBcclxuICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZGVsZXRlQ29va2llKFwiUmVtZW1iZXJLZXlcIik7ICAgXHJcbiAgICAgICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmRlbGV0ZUNvb2tpZShlbXBpZCArIFwiY3VzdFwiKTsgIFxyXG4gICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5kZWxldGVDb29raWUoZW1waWQgKyBcImVtcFwiKTsgIFxyXG4gICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5kZWxldGVDb29raWUoZW1waWQgKyBcInNyY1wiKTsgIFxyXG4gICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5kZWxldGVDb29raWUoZW1waWQgKyBcImNjb2RlXCIpOyAgXHJcbiAgICAgICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmRlbGV0ZUNvb2tpZShlbXBpZCArIFwiU01TRGV0XCIpO1xyXG4gICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5kZWxldGVDb29raWUoZW1waWQgK1wiU01TTWVzc2FnZVwiKTtcclxuICAgICAgICB3aW5kb3cubG9jYXRpb24uaHJlZj1cIi9cIjtcclxuICAgIH1cclxuXHJcblxyXG4gICAgbmdPbkluaXQoKSB7XHJcbiAgICAgICAgdGhpcy5sYW5ndWFnZUFycmF5ID0gdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLkdldEF2YWlsYWJsZUxhbmd1YWdlcygpO1xyXG4gICAgICAgIHZhciBsbmcgPSB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZ2V0Q29va2llKFwibGFuZ1wiKTtcclxuICAgICAgICBpZiAobG5nLmxlbmd0aCA+IDApXHJcbiAgICAgICAgICAgIGxuZyA9IGxuZy5zdWJzdHJpbmcoMSwgbG5nLmxlbmd0aCk7XHJcbiAgICAgICAgaWYgKGxuZyA9PSBcIlwiKVxyXG4gICAgICAgICAgICBsbmcgPSBcImVuXCI7XHJcbiAgICAgICAgdGhpcy5MYW5nID0gbG5nO1xyXG4gICAgICAgIC8vYWxlcnQodGhpcy5MYW5nK1wiIGxhbmdcIik7XHJcbiAgICAgICAgaWYgKHRoaXMuTGFuZyA9PSBcImhlXCIpIHtcclxuICAgICAgICAgICAgdGhpcy5Jc1JUTCA9IFwicnRsXCI7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLklzUlRMID0gXCJsdHJcIjtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn0iXX0=
