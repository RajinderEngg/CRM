System.register(['angular2/core', './amaxComponents/amaxCrmUIComponent', './amaxComponents/amaxLoginComponent', './services/AmaxService', "./services/ResourceService", "./amax/quickaccess/index", "./amax/quickaccess/default", "angular2/router", "./amax/logout", "./amax/reports/amaxReports", "./amax/forms/amaxForms", "./amax/employee/profile", "./amax/employee/settings", "./amax/sms", "./amax/Customer/addCustomer", "./amax/Customer/SearchCustomer", "./amax/RecieptType/Reciept", "./amax/RecieptType/RecieptTemplate", "./amax/RecieptType/Template", "./amax/GeneralGroups/GeneralGroups", "./amax/Charge_Credit/Terminals", "./amax/Charge_Credit/ChargeCreditCard", "./amax/Receipt/ReceiptSelect", "./amax/Receipt/ReceiptCreate", "./amax/Receipt/SearchProducts", "./amax/Customer/CustomerProfile"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, amaxCrmUIComponent_1, amaxLoginComponent_1, AmaxService_1, ResourceService_1, index_1, default_1, router_1, logout_1, amaxReports_1, amaxForms_1, profile_1, settings_1, sms_1, addCustomer_1, SearchCustomer_1, Reciept_1, RecieptTemplate_1, Template_1, GeneralGroups_1, Terminals_1, ChargeCreditCard_1, ReceiptSelect_1, ReceiptCreate_1, SearchProducts_1, CustomerProfile_1;
    var AmaxAppComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (amaxCrmUIComponent_1_1) {
                amaxCrmUIComponent_1 = amaxCrmUIComponent_1_1;
            },
            function (amaxLoginComponent_1_1) {
                amaxLoginComponent_1 = amaxLoginComponent_1_1;
            },
            function (AmaxService_1_1) {
                AmaxService_1 = AmaxService_1_1;
            },
            function (ResourceService_1_1) {
                ResourceService_1 = ResourceService_1_1;
            },
            function (index_1_1) {
                index_1 = index_1_1;
            },
            function (default_1_1) {
                default_1 = default_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (logout_1_1) {
                logout_1 = logout_1_1;
            },
            function (amaxReports_1_1) {
                amaxReports_1 = amaxReports_1_1;
            },
            function (amaxForms_1_1) {
                amaxForms_1 = amaxForms_1_1;
            },
            function (profile_1_1) {
                profile_1 = profile_1_1;
            },
            function (settings_1_1) {
                settings_1 = settings_1_1;
            },
            function (sms_1_1) {
                sms_1 = sms_1_1;
            },
            function (addCustomer_1_1) {
                addCustomer_1 = addCustomer_1_1;
            },
            function (SearchCustomer_1_1) {
                SearchCustomer_1 = SearchCustomer_1_1;
            },
            function (Reciept_1_1) {
                Reciept_1 = Reciept_1_1;
            },
            function (RecieptTemplate_1_1) {
                RecieptTemplate_1 = RecieptTemplate_1_1;
            },
            function (Template_1_1) {
                Template_1 = Template_1_1;
            },
            function (GeneralGroups_1_1) {
                GeneralGroups_1 = GeneralGroups_1_1;
            },
            function (Terminals_1_1) {
                Terminals_1 = Terminals_1_1;
            },
            function (ChargeCreditCard_1_1) {
                ChargeCreditCard_1 = ChargeCreditCard_1_1;
            },
            function (ReceiptSelect_1_1) {
                ReceiptSelect_1 = ReceiptSelect_1_1;
            },
            function (ReceiptCreate_1_1) {
                ReceiptCreate_1 = ReceiptCreate_1_1;
            },
            function (SearchProducts_1_1) {
                SearchProducts_1 = SearchProducts_1_1;
            },
            function (CustomerProfile_1_1) {
                CustomerProfile_1 = CustomerProfile_1_1;
            }],
        execute: function() {
            AmaxAppComponent = (function () {
                function AmaxAppComponent(_amaxSservice, _languageService) {
                    this._amaxSservice = _amaxSservice;
                    this._languageService = _languageService;
                    this.FormTypeForm = "SCREEN_LOGIN";
                    this.ChangeDialog = "";
                    this.CHANGEDIR = "";
                    this.IsLogedIn = false;
                    this.RES = {};
                    this._userModel = {};
                    this._LoggeduserModel = {};
                    //Loading the language resource
                    this.RES.SCREEN_LOGIN = {};
                    this.FormTypeForm = "SCREEN_LOGIN";
                    this.baseUrl = this._languageService.AppUrl;
                }
                AmaxAppComponent.prototype.loadUserInformation = function () {
                    if (sessionStorage.getItem('userInformation') != null) {
                        this.LoginData = JSON.parse(sessionStorage.getItem('userInformation'));
                        if (this.LoginData)
                            this.IsLogedIn = true;
                    }
                };
                AmaxAppComponent.prototype.getlangres = function (langcode) {
                    var _this = this;
                    this._languageService.GetLangRes(this.FormTypeForm, langcode).subscribe(function (response) {
                        // debugger;
                        response = $.parseJSON(response);
                        if (response.IsError == true) {
                            //alert(response.ErrMsg);
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            localStorage.setItem("langresource", JSON.stringify(response.Data));
                            localStorage.setItem("lang", langcode);
                            _this.RES = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxAppComponent.prototype.validateLogin = function () {
                    var _this = this;
                    //this.IsLogedIn = true; 
                    if (this._userModel["userName"] != undefined && this._userModel["userName"] != null && this._userModel["userName"] != ""
                        && this._userModel["password"] != undefined && this._userModel["password"] != null && this._userModel["password"] != ""
                        && this._userModel["orgName"] != undefined && this._userModel["orgName"] != null && this._userModel["orgName"] != "") {
                        this._amaxSservice.validateLogin(this._userModel["userName"], this._userModel["password"], this._userModel["orgName"], this._userModel["rememberMe"]).subscribe(function (data) {
                            var dta = $.parseJSON(data).Data;
                            //debugger;
                            if (dta.error != undefined && dta.error != null && dta.error != "") {
                                if (dta.error != "") {
                                    //alert(dta.error);
                                    bootbox.alert({ message: dta.error,
                                        className: _this.ChangeDialog,
                                        buttons: {
                                            ok: {
                                                //label: 'Ok',
                                                className: _this.CHANGEDIR
                                            }
                                        }
                                    });
                                }
                            }
                            else {
                                _this.IsLogedIn = true;
                                _this.LoginData = dta;
                                sessionStorage.setItem('XToken', dta["token"]);
                                sessionStorage.setItem('sessionInformation', atob(dta["token"].split('.')[0]));
                                sessionStorage.setItem('userInformation', atob(dta["token"].split('.')[1]));
                                //Featching Userinformation
                                debugger;
                                _this.LoginData = JSON.parse(atob(dta["token"].split('.')[1]));
                                localStorage.setItem("employeeid", _this.LoginData.employeeid);
                                localStorage.setItem(_this.LoginData.employeeid + "_OrgId", _this.LoginData.OrgId);
                                if (localStorage.getItem("lang") == "" || localStorage.getItem("lang") == undefined || localStorage.getItem("lang") == null) {
                                    localStorage.setItem("lang", "en");
                                }
                                //alert(this._userModel["rememberMe"].toString());
                                //  debugger;
                                //alert(this._userModel["rememberMe"]);
                                if (_this._userModel["rememberMe"] == true || _this._userModel["rememberMe"] == "true") {
                                    var lang = localStorage.getItem("lang");
                                    //alert(lang);
                                    //this._languageService.setCookie("langresource", lang,10);
                                    _this._languageService.setCookie("RememberKey", data, 10);
                                    _this._languageService.setCookie("UserName", _this._userModel["userName"], 10);
                                    _this._languageService.setCookie("password", _this._userModel["password"], 10);
                                    _this._languageService.setCookie("orgName", _this._userModel["orgName"], 10);
                                    _this._languageService.setCookie("rememberMe", _this._userModel["rememberMe"], 10);
                                    _this._languageService.setCookie("lang", lang, 10);
                                }
                            }
                        }, function (error) { return console.error(error); }, function () {
                        });
                    }
                    else {
                        if (this._userModel["userName"] == undefined && this._userModel["userName"] == null || this._userModel["userName"] == "") {
                            //alert("Please enter valid username");
                            bootbox.alert({
                                message: "Please enter valid username",
                                className: this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        if (this._userModel["password"] == undefined && this._userModel["password"] == null || this._userModel["password"] == "") {
                            //alert("Please enter valid password");
                            bootbox.alert({
                                message: "Please enter valid password",
                                className: this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        if (this._userModel["orgName"] == undefined && this._userModel["orgName"] == null || this._userModel["orgName"] == "") {
                            //alert("Please enter valid organization");
                            bootbox.alert({
                                message: "Please enter valid password",
                                className: this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: this.CHANGEDIR
                                    }
                                }
                            });
                        }
                    }
                };
                AmaxAppComponent.prototype.validateUser = function (evt) {
                    console.log(evt);
                    this.validateLogin();
                };
                AmaxAppComponent.prototype.changeLanguageByLangId = function (LanguageId) {
                    var _this = this;
                    //debugger;
                    console.log("Changing Language...");
                    if (LanguageId) {
                        this._languageService.GetSelecetdLanguage(LanguageId).subscribe(function (data) {
                            localStorage.setItem("langresource", JSON.stringify(data));
                            localStorage.setItem("lang", LanguageId);
                            _this._userModel["lang"] = LanguageId;
                        }, function (error) { return console.log("Unable to load Language Data"); }, function () {
                            console.log("Language resource loaded");
                        });
                        this._languageService.GetLangRes(this.FormTypeForm, LanguageId).subscribe(function (response) {
                            //debugger;
                            response = $.parseJSON(response);
                            if (response.IsError == true) {
                                //alert(response.ErrMsg);
                                bootbox.alert({
                                    message: response.ErrMsg,
                                    className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                            else {
                                localStorage.setItem("langresource", JSON.stringify(response.Data));
                                localStorage.setItem("lang", LanguageId);
                                _this.RES = response.Data;
                            }
                        }, function (error) {
                            console.log(error);
                        }, function () {
                            console.log("CallCompleted");
                        });
                    }
                    else {
                        console.error("Code not specified");
                    }
                };
                AmaxAppComponent.prototype.changeLanguage = function (evt) {
                    var _this = this;
                    //debugger;
                    console.log("Changing Language...");
                    if (evt.code) {
                        this._languageService.GetSelecetdLanguage(evt.code).subscribe(function (data) {
                            localStorage.setItem("langresource", JSON.stringify(data));
                            localStorage.setItem("lang", evt.code);
                            _this._userModel["lang"] = evt.code;
                        }, function (error) { return console.log("Unable to load Language Data"); }, function () {
                            console.log("Language resource loaded");
                        });
                        this._languageService.GetLangRes(this.FormTypeForm, evt.code).subscribe(function (response) {
                            //debugger;
                            response = $.parseJSON(response);
                            if (response.IsError == true) {
                                //alert(response.ErrMsg);
                                bootbox.alert({
                                    message: response.ErrMsg,
                                    className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                            else {
                                localStorage.setItem("langresource", JSON.stringify(response.Data));
                                localStorage.setItem("lang", evt.code);
                                _this.RES = response.Data;
                            }
                        }, function (error) {
                            console.log(error);
                        }, function () {
                            console.log("CallCompleted");
                        });
                    }
                    else {
                        console.error("Code not specified");
                    }
                };
                AmaxAppComponent.prototype.ngOnInit = function () {
                    //debugger;
                    var _this = this;
                    this.FormTypeForm = "SCREEN_LOGIN";
                    var UserName = this._languageService.getCookie("UserName");
                    //alert(UserName[0]);
                    if (UserName.length > 0 && UserName[0] == "=")
                        var UserName = UserName.substring(1, UserName.length);
                    //var password = this._languageService.getCookie("password");
                    //if (password.length > 0) 
                    //    var password = password.substring(1, password.length);
                    var orgName = this._languageService.getCookie("orgName");
                    if (orgName.length > 0)
                        var orgName = orgName.substring(1, orgName.length);
                    var rememberMe = this._languageService.getCookie("rememberMe");
                    if (rememberMe.length > 0)
                        var rememberMe = rememberMe.substring(1, rememberMe.length);
                    else {
                        rememberMe = "true";
                    }
                    var lang = this._languageService.getCookie("lang");
                    if (lang.length > 0)
                        var lang = lang.substring(1, lang.length);
                    if (lang == "")
                        lang = "en";
                    localStorage.setItem("lang", lang);
                    this._userModel = {
                        userName: UserName,
                        password: "",
                        orgName: orgName,
                        lang: lang,
                        rememberMe: rememberMe
                    };
                    this._languageService.GetLangRes(this.FormTypeForm, lang).subscribe(function (response) {
                        response = $.parseJSON(response);
                        if (response.IsError == true) {
                            //alert(response.ErrMsg);
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            //debugger;
                            localStorage.setItem("langresource", JSON.stringify(response.Data));
                            localStorage.setItem("lang", lang);
                            _this.RES = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //this.RES = {
                    //     "APP_DIR": "ltr",
                    //     "APP_LANG": "en",
                    //     "SCREEN_LOGIN": {
                    //         "COMPANY_NAME": "Amax",
                    //         "APP_TYPE": "C.R.M",
                    //         "APP_BASELINE": "© Amax - software solutions",
                    //         "APP_LBL_INFO": "Please Enter Your Information",
                    //         "APP_LBL_USER": "Username",
                    //         "APP_LBL_PASS": "Password",
                    //         "APP_LBL_ORG": "Organization ID",
                    //         "APP_LBL_REMEMBER": "Remember Me",
                    //         "APP_BTN_LOGIN": "Login",
                    //         "APP_LBL_FORGOTPASS": "I forgot my password",
                    //         "APP_LBL_REGISTER": "I want to register"
                    //     },
                    //     "CUSTOMER_MASTER": {
                    //         "APP_LBL_CUST": "Customer",
                    //         "APP_LBL_CARD": "Card",
                    //         "APP_LBL_NEW_CUST": "Add New Customer",
                    //         "APP_TXT_REQD": "(Required-*)",
                    //         "APP_TXT_PH_LNAME": "Last Name*",
                    //         "APP_TXT_PH_FNAME": "First Name*",
                    //         "APP_TXT_PH_MNAME": "Middle Name",
                    //         "APP_TXT_PH_CNAME": "Company Name*",
                    //         "APP_DP_CTYPE": "Select Customer Type",
                    //         "APP_DP_EMP": "Select Contact Employee",
                    //         "APP_DP_SOURCE": "Select Source",
                    //         "APP_TXT_PH_CCODE": "Customer Code",
                    //         "APP_TXT_PH_BDATE": "Birth Date",
                    //         "APP_TXT_PH_JOB": "Job Title",
                    //         "APP_TXT_PH_TITLE": "Title",
                    //         "APP_DP_SUFFIX": "Select Suffix",
                    //         "APP_DP_GENDER": "Select Gender",
                    //         "APP_DP_GENDER_M": "Male",
                    //         "APP_DP_GENDER_F": "Female",
                    //         "APP_LBL_PHONE": "Phones",
                    //         "APP_LBL_ADD_PH": "Add Phone",
                    //         "APP_DP_PTYPE": "Select Phone Type*",
                    //         "APP_TXT_PH_PREFIX": "Prefix",
                    //         "APP_TXT_PH_AREA": "Area",
                    //         "APP_TXT_PH_PHONE": "Phone*",
                    //         "APP_LBL_SMS": "For SMS",
                    //         "APP_CHK_PH_SMS": "For SMS",
                    //         "APP_TXT_PH_COMMENT": "Comments",
                    //         "APP_BTN_PHADD": "Add",
                    //         "APP_BTN_PHCLOSE": "Close",
                    //         "APP_BTN_EADD": "Add",
                    //         "APP_BTN_ECLOSE": "Close",
                    //         "APP_BTN_ADADD": "Add",
                    //         "APP_BTN_ADCLOSE": "Close",
                    //         "APP_GRD_LBL_PTYPE": "Phone Type",
                    //         "APP_GRD_LBL_PHNO": "Prefix-Area-Phone",
                    //         "APP_GRD_LBL_SMS": "For SMS",
                    //         "APP_GRD_LBL_REM": "Remarks",
                    //         "APP_LNK_EMAIL": "Emails",
                    //         "APP_LBL_EMAIL": "Add Email",
                    //         "APP_TXT_PH_EMAIL": "Email*",
                    //         "APP_TXT_PH_ENAME": "Name*",
                    //         "APP_LBL_NLETTER": "NewsLetter",
                    //         "APP_GRD_LBL_EMAIL": "Email",
                    //         "APP_GRD_LBL_ENAME": "Name",
                    //         "APP_GRD_LBL_NLETTER": "Newsletter",
                    //         "APP_LNK_LBL_ADDRS": "Addresses",
                    //         "APP_LBL_ADDRESS": "Add Address",
                    //         "APP_LBL_PH_STR": "Street*",
                    //         "APP_LBL_PH_ADAREA": "Area*",
                    //         "APP_LBL_PH_CITY": "City*",
                    //         "APP_LBL_PH_ZIP": "Zip*",
                    //         "APP_DP_COUNTRY": "Select Country*",
                    //         "APP_DP_STATE": "Select State",
                    //         "APP_DP_ADDRTYPE": "Select AddressType*",
                    //         "APP_LBL_DELIVERY": "Delivery",
                    //         "APP_LBL_MADDRESS": "Is Main Address",
                    //         "APP_GRD_LBL_STREET": "Street",
                    //         "APP_GRD_LBL_ADAREA": "Area",
                    //         "APP_GRD_LBL_CITY": "CityName",
                    //         "APP_GRD_LBL_ZIP": "Zip",
                    //         "APP_GRD_LBL_COUNTRY": "CountryCode",
                    //         "APP_GRD_LBL_STATE": "StateId",
                    //         "APP_GRD_LBL_ADDRESS": "AddressTypeId",
                    //         "APP_GRD_LBL_DELIVERY": "Delivery",
                    //         "APP_GRD_LBL_MADDRESS": "MainAddress",
                    //         "APP_LBL_GRPS": "Choose Groups",
                    //         "APP_LBL_LOAD": "Loading",
                    //         "APP_BTN_SAVE": "Save Changes",
                    //         "APP_LNK_LBL_MORE": "More",
                    //         "APP_LNK_LBL_LESS": "Less"
                    //     }
                    // }
                    //debugger;    
                    var temp = this._languageService.getCookie("RememberKey");
                    if (temp != "" && temp != undefined) {
                        var password = this._languageService.getCookie("password");
                        if (password.length > 0)
                            var password = password.substring(1, password.length);
                        this._LoggeduserModel = {
                            userName: UserName,
                            password: password,
                            orgName: orgName,
                            lang: lang,
                            rememberMe: rememberMe
                        };
                        this.IsLogedIn = true;
                        if (this._LoggeduserModel["userName"] != undefined && this._LoggeduserModel["userName"] != null && this._LoggeduserModel["userName"] != ""
                            && this._LoggeduserModel["password"] != undefined && this._LoggeduserModel["password"] != null && this._LoggeduserModel["password"] != ""
                            && this._LoggeduserModel["orgName"] != undefined && this._LoggeduserModel["orgName"] != null && this._LoggeduserModel["orgName"] != "") {
                            this._amaxSservice.validateLogin(this._LoggeduserModel["userName"], this._LoggeduserModel["password"], this._LoggeduserModel["orgName"], this._LoggeduserModel["rememberMe"]).subscribe(function (data) {
                                var dta = $.parseJSON(data).Data;
                                //debugger;
                                if (dta.error != undefined && dta.error != null && dta.error != "") {
                                    if (dta.error != "") {
                                        bootbox.alert({
                                            message: dta.error,
                                            className: _this.ChangeDialog,
                                            buttons: {
                                                ok: {
                                                    //label: 'Ok',
                                                    className: _this.CHANGEDIR
                                                }
                                            }
                                        });
                                    }
                                }
                                else {
                                    _this.IsLogedIn = true;
                                    _this.LoginData = dta;
                                    sessionStorage.setItem('XToken', dta["token"]);
                                    sessionStorage.setItem('sessionInformation', atob(dta["token"].split('.')[0]));
                                    sessionStorage.setItem('userInformation', atob(dta["token"].split('.')[1]));
                                    //Featching Userinformation
                                    _this.LoginData = JSON.parse(atob(dta["token"].split('.')[1]));
                                    localStorage.setItem("employeeid", _this.LoginData.employeeid);
                                    localStorage.setItem(_this.LoginData.employeeid + "_OrgId", _this.LoginData.OrgId);
                                    //localStorage.setItem("OrgId", this._LoggeduserModel["orgName"]);
                                    if (localStorage.getItem("lang") == "" || localStorage.getItem("lang") == undefined || localStorage.getItem("lang") == null) {
                                        localStorage.setItem("lang", "en");
                                    }
                                    //alert(this._LoggeduserModel["rememberMe"].toString());
                                    //  debugger;
                                    //alert(this._LoggeduserModel["rememberMe"]);
                                    if (_this._LoggeduserModel["rememberMe"] == true || _this._LoggeduserModel["rememberMe"] == "true") {
                                        var lang = localStorage.getItem("lang");
                                        //alert(lang);
                                        //this._languageService.setCookie("langresource", lang,10);
                                        _this._languageService.setCookie("RememberKey", data, 10);
                                        _this._languageService.setCookie("UserName", _this._LoggeduserModel["userName"], 10);
                                        _this._languageService.setCookie("password", _this._LoggeduserModel["password"], 10);
                                        _this._languageService.setCookie("orgName", _this._LoggeduserModel["orgName"], 10);
                                        _this._languageService.setCookie("rememberMe", _this._LoggeduserModel["rememberMe"], 10);
                                        _this._languageService.setCookie("lang", lang, 10);
                                    }
                                }
                            }, function (error) { return console.error(error); }, function () {
                            });
                        }
                        else {
                            if (this._LoggeduserModel["userName"] == undefined && this._LoggeduserModel["userName"] == null || this._LoggeduserModel["userName"] == "") {
                                //alert("Please enter valid username");
                                bootbox.alert({
                                    message: "Please enter valid username",
                                    className: this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                            if (this._LoggeduserModel["password"] == undefined && this._LoggeduserModel["password"] == null || this._LoggeduserModel["password"] == "") {
                                //alert("Please enter valid password");
                                bootbox.alert({
                                    message: "Please enter valid password",
                                    className: this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                            if (this._LoggeduserModel["orgName"] == undefined && this._LoggeduserModel["orgName"] == null || this._LoggeduserModel["orgName"] == "") {
                                //alert("Please enter valid organization");
                                bootbox.alert({
                                    message: "Please enter valid password",
                                    className: this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                        }
                    }
                    // if(!localStorage.getItem("langresource")) {
                    //     //this._languageService.GetSelecetdLanguage("en").subscribe(
                    //     //    data=>{
                    //     //        console.log(data);
                    //     //        localStorage.setItem("langresource", JSON.stringify(data));
                    //     //        this.RES = data;
                    //     //    },
                    //     //    error=>console.log("Unable to load Language Data"),
                    //     //    ()=> {
                    //     //        console.log("Language resource loaded");
                    //     //    }
                    //     //);
                    //     this.RES = this._languageService.GetSelecetdLanguage("en");
                    // }else{
                    //     //this.RES=JSON.parse(localStorage.getItem('langresource'));
                    // }
                };
                AmaxAppComponent = __decorate([
                    core_1.Component({
                        selector: 'mx-app',
                        template: "\n        <div dir=\"{{ RES.APP_DIR }}\">\n            <mx-login\n                *ngIf=\"!IsLogedIn\"\n                [(res)]=\"RES.SCREEN_LOGIN\"\n                [dataModel]=\"_userModel\" \n                (ondata)=\"validateUser($event)\" \n                (onlanguage)=\"changeLanguage($event)\"\n            ></mx-login>\n            <div *ngIf=\"IsLogedIn\" class=\"no-skin\">\n                <mx-ui></mx-ui>\n            </div>\n        </div>\n\t",
                        directives: [amaxLoginComponent_1.AmaxLoginComponent, amaxCrmUIComponent_1.AmaxCrmUIComponent, logout_1.AmaxLogoutComponent, amaxLoginComponent_1.AmaxLoginComponent],
                        providers: [AmaxService_1.AmaxService, ResourceService_1.ResourceService]
                    }),
                    router_1.RouteConfig([
                        { path: "/index", name: "IndexRouter", component: index_1.indexComponent },
                        { path: "/default", name: "DefaultRouter", component: default_1.defaultComponent },
                        //Reports Routing
                        { path: "/report", name: "Reports", component: amaxReports_1.AmaxReport },
                        //Forms routing
                        //{ path:"/form", name:"Forms", component:AmaxForms },
                        { path: "/form/:frm", name: "Forms", component: amaxForms_1.AmaxForms },
                        //Employee related routing
                        { path: "/employee/profile", name: "Profile", component: profile_1.AmaxEmployeeProfile },
                        { path: "/employee/settings", name: "Settings", component: settings_1.AmaxEmployeeSettings },
                        //Module Routing
                        { path: "/sms", name: "Sms", component: sms_1.AmaxSmsComponent },
                        { path: "/blank", name: "Blank", component: logout_1.AmaxLogoutComponent },
                        //Customer Routing
                        { path: "/Customer/Add/:Id", name: "AddCustomer", component: addCustomer_1.AmaxCustomers },
                        //Customer Routing
                        { path: "/Customer/Search/:ForPopup/:FromPage/:ForBack", name: "SearchCustomer", component: SearchCustomer_1.AmaxSearchCustomers },
                        //Reciept Type
                        { path: "/ReceiptType/:Id", name: "ReceiptType", component: Reciept_1.AmaxReciept },
                        { path: "/ReceiptTemplate/Add/:Id", name: "RecieptTemplate", component: RecieptTemplate_1.AmaxRecieptTemplate },
                        { path: "/Template/Edit/:Id/:FPage", name: "Template", component: Template_1.AmaxTemplate },
                        { path: "/GeneralGroups/View", name: "GeneralGroups", component: GeneralGroups_1.AmaxGeneralGroups },
                        //Templates
                        { path: "/Terminals/Show/:Id", name: "Terminals", component: Terminals_1.AmaxTerminals },
                        //ChargeCredit
                        { path: "/ChargeCredit/:Id/:TermNo", name: "ChargeCreditCard", component: ChargeCreditCard_1.AmaxChargeCredit },
                        //ChargeCredit
                        { path: "/ReceiptSelect/:Id/:CustId", name: "ReceiptSelect", component: ReceiptSelect_1.AmaxReceiptSelect },
                        //ChargeCredit
                        { path: "/ReceiptCreate/:Id/:ReceiptTypeId", name: "ReceiptCreate", component: ReceiptCreate_1.AmaxReceiptCreate },
                        //Product Search
                        { path: "/SearchProducts/:Id/:FromPage", name: "SearchProducts", component: SearchProducts_1.AmaxSearchProducts },
                        //Customer Profile
                        { path: "/Customer/Profile/:Id", name: "CustomerProfile", component: CustomerProfile_1.AmaxCustomerProfiles }
                    ]), 
                    __metadata('design:paramtypes', [AmaxService_1.AmaxService, ResourceService_1.ResourceService])
                ], AmaxAppComponent);
                return AmaxAppComponent;
            }());
            exports_1("AmaxAppComponent", AmaxAppComponent);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFtYXhBcHAuY29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1lBb0dBO2dCQUtJLDBCQUFvQixhQUEwQixFQUFVLGdCQUFpQztvQkFBckUsa0JBQWEsR0FBYixhQUFhLENBQWE7b0JBQVUscUJBQWdCLEdBQWhCLGdCQUFnQixDQUFpQjtvQkFKekYsaUJBQVksR0FBVyxjQUFjLENBQUM7b0JBRXRDLGlCQUFZLEdBQVcsRUFBRSxDQUFDO29CQUMxQixjQUFTLEdBQVcsRUFBRSxDQUFDO29CQVF2QixjQUFTLEdBQVksS0FBSyxDQUFDO29CQUVwQixRQUFHLEdBQVcsRUFBRSxDQUFDO29CQWlKNUIsZUFBVSxHQUFHLEVBQUUsQ0FBQztvQkFDaEIscUJBQWdCLEdBQUcsRUFBRSxDQUFDO29CQTFKZCwrQkFBK0I7b0JBQy9CLElBQUksQ0FBQyxHQUFHLENBQUMsWUFBWSxHQUFHLEVBQUUsQ0FBQztvQkFDM0IsSUFBSSxDQUFDLFlBQVksR0FBRyxjQUFjLENBQUM7b0JBQ25DLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQztnQkFFaEQsQ0FBQztnQkFNRCw4Q0FBbUIsR0FBbkI7b0JBQ0ksRUFBRSxDQUFDLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7d0JBQ3BELElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQzt3QkFDdkUsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQzs0QkFBQyxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQztvQkFDOUMsQ0FBQztnQkFDTCxDQUFDO2dCQUNGLHFDQUFVLEdBQVYsVUFBVyxRQUFRO29CQUFuQixpQkE2QkM7b0JBNUJHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxRQUFRLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUM3RSxZQUFZO3dCQUNYLFFBQVEsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUNqQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLHlCQUF5Qjs0QkFDekIsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBRUYsWUFBWSxDQUFDLE9BQU8sQ0FBQyxjQUFjLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDcEUsWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsUUFBUSxDQUFDLENBQUM7NEJBQ3ZDLEtBQUksQ0FBQyxHQUFHLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzt3QkFFN0IsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztnQkFDUCxDQUFDO2dCQUNKLHdDQUFhLEdBQWI7b0JBQUEsaUJBd0dLO29CQXZHRCx5QkFBeUI7b0JBQ3pCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRTsyQkFDakgsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFOzJCQUNwSCxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7d0JBQ3ZILElBQUksQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQzNKLFVBQUEsSUFBSTs0QkFDQSxJQUFJLEdBQUcsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQzs0QkFDakMsV0FBVzs0QkFDWCxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxJQUFJLFNBQVMsSUFBSSxHQUFHLENBQUMsS0FBSyxJQUFJLElBQUksSUFBSSxHQUFHLENBQUMsS0FBSyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0NBQ2pFLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQztvQ0FDbEIsbUJBQW1CO29DQUNuQixPQUFPLENBQUMsS0FBSyxDQUFDLEVBQUUsT0FBTyxFQUFFLEdBQUcsQ0FBQyxLQUFLO3dDQUM5QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7d0NBQzVCLE9BQU8sRUFBRTs0Q0FDTCxFQUFFLEVBQUU7Z0RBQ0EsY0FBYztnREFDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7NkNBQzVCO3lDQUNKO3FDQUNSLENBQUMsQ0FBQztnQ0FDSCxDQUFDOzRCQUNMLENBQUM7NEJBQ0QsSUFBSSxDQUFDLENBQUM7Z0NBQ0YsS0FBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7Z0NBQ3RCLEtBQUksQ0FBQyxTQUFTLEdBQUcsR0FBRyxDQUFDO2dDQUNyQixjQUFjLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQTtnQ0FDOUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxvQkFBb0IsRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQy9FLGNBQWMsQ0FBQyxPQUFPLENBQUMsaUJBQWlCLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUU1RSwyQkFBMkI7Z0NBQzNCLFFBQVEsQ0FBQztnQ0FDVCxLQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUM5RCxZQUFZLENBQUMsT0FBTyxDQUFDLFlBQVksRUFBRSxLQUFJLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO2dDQUM5RCxZQUFZLENBQUMsT0FBTyxDQUFDLEtBQUksQ0FBQyxTQUFTLENBQUMsVUFBVSxHQUFHLFFBQVEsRUFBRSxLQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDO2dDQUNqRixFQUFFLENBQUMsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsSUFBSSxZQUFZLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxJQUFJLFNBQVMsSUFBSSxZQUFZLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7b0NBQzFILFlBQVksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxDQUFDO2dDQUN2QyxDQUFDO2dDQUNELGtEQUFrRDtnQ0FDbEQsYUFBYTtnQ0FDYix1Q0FBdUM7Z0NBQ3ZDLEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLElBQUksSUFBSSxJQUFJLEtBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLElBQUksTUFBTSxDQUFDLENBQUMsQ0FBQztvQ0FFbkYsSUFBSSxJQUFJLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztvQ0FDeEMsY0FBYztvQ0FDZCwyREFBMkQ7b0NBQzNELEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsYUFBYSxFQUFFLElBQUksRUFBRSxFQUFFLENBQUMsQ0FBQztvQ0FDekQsS0FBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxVQUFVLEVBQUUsS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztvQ0FDN0UsS0FBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxVQUFVLEVBQUUsS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztvQ0FDN0UsS0FBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxTQUFTLEVBQUUsS0FBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztvQ0FDM0UsS0FBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxZQUFZLEVBQUUsS0FBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztvQ0FDakYsS0FBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsSUFBSSxFQUFFLEVBQUUsQ0FBQyxDQUFDO2dDQUN0RCxDQUFDOzRCQUNMLENBQUM7d0JBRUwsQ0FBQyxFQUVELFVBQUEsS0FBSyxJQUFJLE9BQUEsT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsRUFBcEIsQ0FBb0IsRUFDN0I7d0JBRUEsQ0FBQyxDQUNKLENBQUE7b0JBQ0wsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7NEJBQ3ZILHVDQUF1Qzs0QkFDdkMsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsNkJBQTZCO2dDQUN0QyxTQUFTLEVBQUUsSUFBSSxDQUFDLFlBQVk7Z0NBQzVCLE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzs0QkFDdkgsdUNBQXVDOzRCQUN2QyxPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSw2QkFBNkI7Z0NBQ3RDLFNBQVMsRUFBRSxJQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDOzRCQUNwSCwyQ0FBMkM7NEJBQzNDLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLDZCQUE2QjtnQ0FDdEMsU0FBUyxFQUFFLElBQUksQ0FBQyxZQUFZO2dDQUM1QixPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQztvQkFDTCxDQUFDO2dCQUNELENBQUM7Z0JBS0QsdUNBQVksR0FBWixVQUFhLEdBQUc7b0JBQ1osT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztvQkFDakIsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO2dCQUN6QixDQUFDO2dCQUVNLGlEQUFzQixHQUE3QixVQUE4QixVQUFVO29CQUF4QyxpQkFtREM7b0JBbERHLFdBQVc7b0JBQ1gsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO29CQUNwQyxFQUFFLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDO3dCQUNiLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxtQkFBbUIsQ0FBQyxVQUFVLENBQUMsQ0FBQyxTQUFTLENBQzNELFVBQUEsSUFBSTs0QkFDQSxZQUFZLENBQUMsT0FBTyxDQUFDLGNBQWMsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBRTNELFlBQVksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLFVBQVUsQ0FBQyxDQUFDOzRCQUN6QyxLQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxHQUFHLFVBQVUsQ0FBQzt3QkFFekMsQ0FBQyxFQUNELFVBQUEsS0FBSyxJQUFJLE9BQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQyw4QkFBOEIsQ0FBQyxFQUEzQyxDQUEyQyxFQUNwRDs0QkFDSSxPQUFPLENBQUMsR0FBRyxDQUFDLDBCQUEwQixDQUFDLENBQUM7d0JBQzVDLENBQUMsQ0FDSixDQUFDO3dCQUVGLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxVQUFVLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFROzRCQUM5RSxXQUFXOzRCQUNYLFFBQVEsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDOzRCQUNqQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7Z0NBQzNCLHlCQUF5QjtnQ0FDekIsT0FBTyxDQUFDLEtBQUssQ0FBQztvQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07b0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtvQ0FDNUIsT0FBTyxFQUFFO3dDQUNMLEVBQUUsRUFBRTs0Q0FDQSxjQUFjOzRDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUzt5Q0FDNUI7cUNBQ0o7aUNBQ0osQ0FBQyxDQUFDOzRCQUNQLENBQUM7NEJBQ0QsSUFBSSxDQUFDLENBQUM7Z0NBQ0YsWUFBWSxDQUFDLE9BQU8sQ0FBQyxjQUFjLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztnQ0FDcEUsWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsVUFBVSxDQUFDLENBQUM7Z0NBQ3pDLEtBQUksQ0FBQyxHQUFHLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzs0QkFFN0IsQ0FBQzt3QkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLOzRCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7d0JBQ3ZCLENBQUMsRUFBRTs0QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO3dCQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFHUCxDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUNGLE9BQU8sQ0FBQyxLQUFLLENBQUMsb0JBQW9CLENBQUMsQ0FBQztvQkFDeEMsQ0FBQztnQkFDTCxDQUFDO2dCQUdNLHlDQUFjLEdBQXJCLFVBQXNCLEdBQUc7b0JBQXpCLGlCQW1EQztvQkFsREcsV0FBVztvQkFDWCxPQUFPLENBQUMsR0FBRyxDQUFDLHNCQUFzQixDQUFDLENBQUM7b0JBQ3BDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO3dCQUNYLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUN6RCxVQUFBLElBQUk7NEJBQ0EsWUFBWSxDQUFDLE9BQU8sQ0FBQyxjQUFjLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUUzRCxZQUFZLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUM7NEJBQ3ZDLEtBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQzt3QkFFdkMsQ0FBQyxFQUNELFVBQUEsS0FBSyxJQUFJLE9BQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQyw4QkFBOEIsQ0FBQyxFQUEzQyxDQUEyQyxFQUNwRDs0QkFDSSxPQUFPLENBQUMsR0FBRyxDQUFDLDBCQUEwQixDQUFDLENBQUM7d0JBQzVDLENBQUMsQ0FDSixDQUFDO3dCQUVGLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTs0QkFDNUUsV0FBVzs0QkFDWCxRQUFRLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzs0QkFDakMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO2dDQUMzQix5QkFBeUI7Z0NBQ3pCLE9BQU8sQ0FBQyxLQUFLLENBQUM7b0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO29DQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7b0NBQzVCLE9BQU8sRUFBRTt3Q0FDTCxFQUFFLEVBQUU7NENBQ0EsY0FBYzs0Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7eUNBQzVCO3FDQUNKO2lDQUNKLENBQUMsQ0FBQzs0QkFDUCxDQUFDOzRCQUNELElBQUksQ0FBQyxDQUFDO2dDQUNGLFlBQVksQ0FBQyxPQUFPLENBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7Z0NBQ3BFLFlBQVksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztnQ0FDdkMsS0FBSSxDQUFDLEdBQUcsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDOzRCQUU3QixDQUFDO3dCQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7NEJBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQzt3QkFDdkIsQ0FBQyxFQUFFOzRCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7d0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUdQLENBQUM7b0JBQ0QsSUFBSSxDQUFDLENBQUM7d0JBQ0YsT0FBTyxDQUFDLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO29CQUN4QyxDQUFDO2dCQUNMLENBQUM7Z0JBR0QsbUNBQVEsR0FBUjtvQkFDSSxXQUFXO29CQURmLGlCQW1UQztvQkFoVEcsSUFBSSxDQUFDLFlBQVksR0FBRyxjQUFjLENBQUM7b0JBRW5DLElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7b0JBQzNELHFCQUFxQjtvQkFDckIsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxDQUFDLElBQUksUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFFLEdBQUcsQ0FBQzt3QkFDeEMsSUFBSSxRQUFRLEdBQUcsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUN6RCw2REFBNkQ7b0JBRTdELDJCQUEyQjtvQkFDM0IsNERBQTREO29CQUM1RCxJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxDQUFDO29CQUV6RCxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQzt3QkFDbkIsSUFBSSxPQUFPLEdBQUcsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUN2RCxJQUFJLFVBQVUsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQyxDQUFDO29CQUUvRCxFQUFFLENBQUMsQ0FBQyxVQUFVLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQzt3QkFDdEIsSUFBSSxVQUFVLEdBQUcsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUNoRSxJQUFJLENBQUMsQ0FBQzt3QkFDRixVQUFVLEdBQUcsTUFBTSxDQUFDO29CQUN4QixDQUFDO29CQUNELElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBRW5ELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO3dCQUNoQixJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQzlDLEVBQUUsQ0FBQyxDQUFDLElBQUksSUFBSSxFQUFFLENBQUM7d0JBQ1gsSUFBSSxHQUFHLElBQUksQ0FBQztvQkFFaEIsWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUM7b0JBQzNCLElBQUksQ0FBQyxVQUFVLEdBQUc7d0JBQ2QsUUFBUSxFQUFFLFFBQVE7d0JBQ2xCLFFBQVEsRUFBRSxFQUFFO3dCQUNaLE9BQU8sRUFBRSxPQUFPO3dCQUNoQixJQUFJLEVBQUUsSUFBSTt3QkFDVixVQUFVLEVBQUUsVUFBVTtxQkFDakMsQ0FBQTtvQkFDTyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFFeEUsUUFBUSxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQ2pDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IseUJBQXlCOzRCQUN6QixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtnQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUM1QixPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixXQUFXOzRCQUNYLFlBQVksQ0FBQyxPQUFPLENBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQ3BFLFlBQVksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxDQUFDOzRCQUNuQyxLQUFJLENBQUMsR0FBRyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7d0JBRTdCLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBQ1gsY0FBYztvQkFFZCx3QkFBd0I7b0JBQ3hCLHdCQUF3QjtvQkFDeEIsd0JBQXdCO29CQUN4QixrQ0FBa0M7b0JBQ2xDLCtCQUErQjtvQkFDL0IseURBQXlEO29CQUN6RCwyREFBMkQ7b0JBQzNELHNDQUFzQztvQkFDdEMsc0NBQXNDO29CQUN0Qyw0Q0FBNEM7b0JBQzVDLDZDQUE2QztvQkFFN0Msb0NBQW9DO29CQUNwQyx3REFBd0Q7b0JBQ3hELG1EQUFtRDtvQkFDbkQsU0FBUztvQkFDVCwyQkFBMkI7b0JBQzNCLHNDQUFzQztvQkFDdEMsa0NBQWtDO29CQUNsQyxrREFBa0Q7b0JBQ2xELDBDQUEwQztvQkFDMUMsNENBQTRDO29CQUM1Qyw2Q0FBNkM7b0JBQzdDLDZDQUE2QztvQkFDN0MsK0NBQStDO29CQUMvQyxrREFBa0Q7b0JBQ2xELG1EQUFtRDtvQkFDbkQsNENBQTRDO29CQUU1QywrQ0FBK0M7b0JBQy9DLDRDQUE0QztvQkFDNUMseUNBQXlDO29CQUN6Qyx1Q0FBdUM7b0JBQ3ZDLDRDQUE0QztvQkFDNUMsNENBQTRDO29CQUM1QyxxQ0FBcUM7b0JBQ3JDLHVDQUF1QztvQkFDdkMscUNBQXFDO29CQUNyQyx5Q0FBeUM7b0JBQ3pDLGdEQUFnRDtvQkFDaEQseUNBQXlDO29CQUN6QyxxQ0FBcUM7b0JBRXJDLHdDQUF3QztvQkFDeEMsb0NBQW9DO29CQUNwQyx1Q0FBdUM7b0JBQ3ZDLDRDQUE0QztvQkFFNUMsa0NBQWtDO29CQUNsQyxzQ0FBc0M7b0JBRXRDLGlDQUFpQztvQkFDakMscUNBQXFDO29CQUVyQyxrQ0FBa0M7b0JBQ2xDLHNDQUFzQztvQkFFdEMsNkNBQTZDO29CQUM3QyxtREFBbUQ7b0JBQ25ELHdDQUF3QztvQkFDeEMsd0NBQXdDO29CQUN4QyxxQ0FBcUM7b0JBQ3JDLHdDQUF3QztvQkFDeEMsd0NBQXdDO29CQUN4Qyx1Q0FBdUM7b0JBRXZDLDJDQUEyQztvQkFDM0Msd0NBQXdDO29CQUN4Qyx1Q0FBdUM7b0JBQ3ZDLCtDQUErQztvQkFDL0MsNENBQTRDO29CQUM1Qyw0Q0FBNEM7b0JBQzVDLHVDQUF1QztvQkFDdkMsd0NBQXdDO29CQUN4QyxzQ0FBc0M7b0JBQ3RDLG9DQUFvQztvQkFDcEMsK0NBQStDO29CQUMvQywwQ0FBMEM7b0JBQzFDLG9EQUFvRDtvQkFFcEQsMENBQTBDO29CQUMxQyxpREFBaUQ7b0JBQ2pELDBDQUEwQztvQkFDMUMsd0NBQXdDO29CQUN4QywwQ0FBMEM7b0JBQzFDLG9DQUFvQztvQkFDcEMsZ0RBQWdEO29CQUNoRCwwQ0FBMEM7b0JBQzFDLGtEQUFrRDtvQkFDbEQsOENBQThDO29CQUM5QyxpREFBaUQ7b0JBQ2pELDJDQUEyQztvQkFDM0MscUNBQXFDO29CQUNyQywwQ0FBMEM7b0JBQzFDLHNDQUFzQztvQkFDdEMscUNBQXFDO29CQUVyQyxRQUFRO29CQUNBLElBQUk7b0JBQ0osZUFBZTtvQkFDZixJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxDQUFDO29CQUMxRCxFQUFFLENBQUMsQ0FBQyxJQUFJLElBQUksRUFBRSxJQUFJLElBQUksSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDO3dCQUNsQyxJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO3dCQUV2RSxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQzs0QkFDcEIsSUFBSSxRQUFRLEdBQUcsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDO3dCQUM5QyxJQUFJLENBQUMsZ0JBQWdCLEdBQUc7NEJBQzVCLFFBQVEsRUFBRSxRQUFROzRCQUNsQixRQUFRLEVBQUUsUUFBUTs0QkFDbEIsT0FBTyxFQUFFLE9BQU87NEJBQ2hCLElBQUksRUFBRSxJQUFJOzRCQUNWLFVBQVUsRUFBRSxVQUFVO3lCQUN6QixDQUFBO3dCQUdELElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDO3dCQUN0QixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUU7K0JBQ25JLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRTsrQkFDdEksSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDOzRCQUN6SSxJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLEVBQUUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsRUFBRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQ25MLFVBQUEsSUFBSTtnQ0FDQSxJQUFJLEdBQUcsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQztnQ0FDakMsV0FBVztnQ0FDWCxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxJQUFJLFNBQVMsSUFBSSxHQUFHLENBQUMsS0FBSyxJQUFJLElBQUksSUFBSSxHQUFHLENBQUMsS0FBSyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7b0NBQ2pFLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzt3Q0FDbEIsT0FBTyxDQUFDLEtBQUssQ0FBQzs0Q0FDVixPQUFPLEVBQUUsR0FBRyxDQUFDLEtBQUs7NENBQ2xCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTs0Q0FDNUIsT0FBTyxFQUFFO2dEQUNMLEVBQUUsRUFBRTtvREFDQSxjQUFjO29EQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztpREFDNUI7NkNBQ0o7eUNBQ0osQ0FBQyxDQUFDO29DQUNQLENBQUM7Z0NBQ0wsQ0FBQztnQ0FDRCxJQUFJLENBQUMsQ0FBQztvQ0FDRixLQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQztvQ0FDdEIsS0FBSSxDQUFDLFNBQVMsR0FBRyxHQUFHLENBQUM7b0NBQ3JCLGNBQWMsQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFBO29DQUM5QyxjQUFjLENBQUMsT0FBTyxDQUFDLG9CQUFvQixFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQ0FDL0UsY0FBYyxDQUFDLE9BQU8sQ0FBQyxpQkFBaUIsRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7b0NBRTVFLDJCQUEyQjtvQ0FFM0IsS0FBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQ0FDOUQsWUFBWSxDQUFDLE9BQU8sQ0FBQyxZQUFZLEVBQUUsS0FBSSxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztvQ0FDOUQsWUFBWSxDQUFDLE9BQU8sQ0FBQyxLQUFJLENBQUMsU0FBUyxDQUFDLFVBQVUsR0FBRyxRQUFRLEVBQUUsS0FBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQ0FDakYsa0VBQWtFO29DQUNsRSxFQUFFLENBQUMsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsSUFBSSxZQUFZLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxJQUFJLFNBQVMsSUFBSSxZQUFZLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7d0NBQzFILFlBQVksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxDQUFDO29DQUN2QyxDQUFDO29DQUNELHdEQUF3RDtvQ0FDeEQsYUFBYTtvQ0FDYiw2Q0FBNkM7b0NBQzdDLEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLENBQUMsSUFBSSxJQUFJLElBQUksS0FBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQyxJQUFJLE1BQU0sQ0FBQyxDQUFDLENBQUM7d0NBRS9GLElBQUksSUFBSSxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7d0NBQ3hDLGNBQWM7d0NBQ2QsMkRBQTJEO3dDQUMzRCxLQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLGFBQWEsRUFBRSxJQUFJLEVBQUUsRUFBRSxDQUFDLENBQUM7d0NBQ3pELEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsVUFBVSxFQUFFLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQzt3Q0FDbkYsS0FBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxVQUFVLEVBQUUsS0FBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO3dDQUNuRixLQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLFNBQVMsRUFBRSxLQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7d0NBQ2pGLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsWUFBWSxFQUFFLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQzt3Q0FDdkYsS0FBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsSUFBSSxFQUFFLEVBQUUsQ0FBQyxDQUFDO29DQUN0RCxDQUFDO2dDQUNMLENBQUM7NEJBRUwsQ0FBQyxFQUVELFVBQUEsS0FBSyxJQUFJLE9BQUEsT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsRUFBcEIsQ0FBb0IsRUFDN0I7NEJBRUEsQ0FBQyxDQUNKLENBQUE7d0JBQ0wsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0NBQ3pJLHVDQUF1QztnQ0FDdkMsT0FBTyxDQUFDLEtBQUssQ0FBQztvQ0FDVixPQUFPLEVBQUUsNkJBQTZCO29DQUN0QyxTQUFTLEVBQUUsSUFBSSxDQUFDLFlBQVk7b0NBQzVCLE9BQU8sRUFBRTt3Q0FDTCxFQUFFLEVBQUU7NENBQ0EsY0FBYzs0Q0FDZCxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVM7eUNBQzVCO3FDQUNKO2lDQUNKLENBQUMsQ0FBQzs0QkFDUCxDQUFDOzRCQUNELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQztnQ0FDekksdUNBQXVDO2dDQUN2QyxPQUFPLENBQUMsS0FBSyxDQUFDO29DQUNWLE9BQU8sRUFBRSw2QkFBNkI7b0NBQ3RDLFNBQVMsRUFBRSxJQUFJLENBQUMsWUFBWTtvQ0FDNUIsT0FBTyxFQUFFO3dDQUNMLEVBQUUsRUFBRTs0Q0FDQSxjQUFjOzRDQUNkLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUzt5Q0FDNUI7cUNBQ0o7aUNBQ0osQ0FBQyxDQUFDOzRCQUNQLENBQUM7NEJBQ0QsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO2dDQUN0SSwyQ0FBMkM7Z0NBQzNDLE9BQU8sQ0FBQyxLQUFLLENBQUM7b0NBQ1YsT0FBTyxFQUFFLDZCQUE2QjtvQ0FDdEMsU0FBUyxFQUFFLElBQUksQ0FBQyxZQUFZO29DQUM1QixPQUFPLEVBQUU7d0NBQ0wsRUFBRSxFQUFFOzRDQUNBLGNBQWM7NENBQ2QsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO3lDQUM1QjtxQ0FDSjtpQ0FDSixDQUFDLENBQUM7NEJBQ1AsQ0FBQzt3QkFDTCxDQUFDO29CQUdMLENBQUM7b0JBQ0QsOENBQThDO29CQUM5QyxtRUFBbUU7b0JBQ25FLG9CQUFvQjtvQkFDcEIsbUNBQW1DO29CQUNuQyw0RUFBNEU7b0JBQzVFLGlDQUFpQztvQkFDakMsZUFBZTtvQkFDZixnRUFBZ0U7b0JBQ2hFLG1CQUFtQjtvQkFDbkIseURBQXlEO29CQUN6RCxjQUFjO29CQUNkLFdBQVc7b0JBQ1gsa0VBQWtFO29CQUNsRSxTQUFTO29CQUNULG1FQUFtRTtvQkFDbkUsSUFBSTtnQkFDUixDQUFDO2dCQTNvQkw7b0JBQUMsZ0JBQVMsQ0FBQzt3QkFDUCxRQUFRLEVBQUUsUUFBUTt3QkFDbEIsUUFBUSxFQUFFLDRjQWFaO3dCQUNFLFVBQVUsRUFBRSxDQUFDLHVDQUFrQixFQUFFLHVDQUFrQixFQUFFLDRCQUFtQixFQUFFLHVDQUFrQixDQUFDO3dCQUM3RixTQUFTLEVBQUUsQ0FBQyx5QkFBVyxFQUFFLGlDQUFlLENBQUM7cUJBQzVDLENBQUM7b0JBRUQsb0JBQVcsQ0FBQzt3QkFDVCxFQUFFLElBQUksRUFBQyxRQUFRLEVBQXFCLElBQUksRUFBQyxhQUFhLEVBQWMsU0FBUyxFQUFDLHNCQUFjLEVBQUU7d0JBQzlGLEVBQUUsSUFBSSxFQUFDLFVBQVUsRUFBbUIsSUFBSSxFQUFDLGVBQWUsRUFBWSxTQUFTLEVBQUMsMEJBQWdCLEVBQUU7d0JBRWhHLGlCQUFpQjt3QkFDakIsRUFBRSxJQUFJLEVBQUMsU0FBUyxFQUFvQixJQUFJLEVBQUMsU0FBUyxFQUFrQixTQUFTLEVBQUUsd0JBQVUsRUFBRTt3QkFFM0YsZUFBZTt3QkFDZixzREFBc0Q7d0JBQ3RELEVBQUUsSUFBSSxFQUFDLFlBQVksRUFBaUIsSUFBSSxFQUFDLE9BQU8sRUFBb0IsU0FBUyxFQUFDLHFCQUFTLEVBQUU7d0JBRXpGLDBCQUEwQjt3QkFDMUIsRUFBRSxJQUFJLEVBQUMsbUJBQW1CLEVBQVUsSUFBSSxFQUFDLFNBQVMsRUFBa0IsU0FBUyxFQUFFLDZCQUFtQixFQUFFO3dCQUNwRyxFQUFFLElBQUksRUFBQyxvQkFBb0IsRUFBUyxJQUFJLEVBQUMsVUFBVSxFQUFpQixTQUFTLEVBQUUsK0JBQW9CLEVBQUU7d0JBR3JHLGdCQUFnQjt3QkFDZixFQUFFLElBQUksRUFBQyxNQUFNLEVBQXVCLElBQUksRUFBQyxLQUFLLEVBQXNCLFNBQVMsRUFBRSxzQkFBZ0IsRUFBQzt3QkFHakcsRUFBRSxJQUFJLEVBQUMsUUFBUSxFQUFxQixJQUFJLEVBQUMsT0FBTyxFQUFvQixTQUFTLEVBQUUsNEJBQW1CLEVBQUM7d0JBRXRHLGtCQUFrQjt3QkFDZixFQUFFLElBQUksRUFBRSxtQkFBbUIsRUFBRSxJQUFJLEVBQUUsYUFBYSxFQUFFLFNBQVMsRUFBRSwyQkFBYSxFQUFFO3dCQUU1RSxrQkFBa0I7d0JBQ2xCLEVBQUUsSUFBSSxFQUFFLCtDQUErQyxFQUFFLElBQUksRUFBRSxnQkFBZ0IsRUFBRSxTQUFTLEVBQUUsb0NBQW1CLEVBQUU7d0JBRWpILGNBQWM7d0JBQ2QsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUUsSUFBSSxFQUFFLGFBQWEsRUFBRSxTQUFTLEVBQUUscUJBQVcsRUFBRTt3QkFFekUsRUFBRSxJQUFJLEVBQUUsMEJBQTBCLEVBQUUsSUFBSSxFQUFFLGlCQUFpQixFQUFFLFNBQVMsRUFBRSxxQ0FBbUIsRUFBRTt3QkFFN0YsRUFBRSxJQUFJLEVBQUUsMkJBQTJCLEVBQUUsSUFBSSxFQUFFLFVBQVUsRUFBRSxTQUFTLEVBQUUsdUJBQVksRUFBRTt3QkFDaEYsRUFBRSxJQUFJLEVBQUUscUJBQXFCLEVBQUUsSUFBSSxFQUFFLGVBQWUsRUFBRSxTQUFTLEVBQUUsaUNBQWlCLEVBQUU7d0JBQ3BGLFdBQVc7d0JBQ1gsRUFBRSxJQUFJLEVBQUUscUJBQXFCLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRSxTQUFTLEVBQUUseUJBQWEsRUFBRTt3QkFDNUUsY0FBYzt3QkFDZCxFQUFFLElBQUksRUFBRSwyQkFBMkIsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUUsU0FBUyxFQUFFLG1DQUFnQixFQUFFO3dCQUM1RixjQUFjO3dCQUNkLEVBQUUsSUFBSSxFQUFFLDRCQUE0QixFQUFFLElBQUksRUFBRSxlQUFlLEVBQUUsU0FBUyxFQUFFLGlDQUFpQixFQUFFO3dCQUMzRixjQUFjO3dCQUNkLEVBQUUsSUFBSSxFQUFFLG1DQUFtQyxFQUFFLElBQUksRUFBRSxlQUFlLEVBQUUsU0FBUyxFQUFFLGlDQUFpQixFQUFFO3dCQUNsRyxnQkFBZ0I7d0JBQ2hCLEVBQUUsSUFBSSxFQUFFLCtCQUErQixFQUFFLElBQUksRUFBRSxnQkFBZ0IsRUFBRSxTQUFTLEVBQUUsbUNBQWtCLEVBQUU7d0JBQ2hHLGtCQUFrQjt3QkFDbEIsRUFBRSxJQUFJLEVBQUUsdUJBQXVCLEVBQUUsSUFBSSxFQUFFLGlCQUFpQixFQUFFLFNBQVMsRUFBRSxzQ0FBb0IsRUFBRTtxQkFDOUYsQ0FBQzs7b0NBQUE7Z0JBeWtCRix1QkFBQztZQUFELENBdmtCQSxBQXVrQkMsSUFBQTtZQXZrQkQsK0NBdWtCQyxDQUFBIiwiZmlsZSI6ImFtYXhBcHAuY29tcG9uZW50LmpzIiwic291cmNlc0NvbnRlbnQiOlsiLy8vPHJlZmVyZW5jZSBwYXRoPVwic2VydmljZXMvQW1heFNlcnZpY2UudHNcIi8+XHJcbmltcG9ydCB7IENvbXBvbmVudCwgT25Jbml0IH0gZnJvbSAnYW5ndWxhcjIvY29yZSc7XHJcbmltcG9ydCB7IEFtYXhDcm1VSUNvbXBvbmVudCB9IGZyb20gJy4vYW1heENvbXBvbmVudHMvYW1heENybVVJQ29tcG9uZW50JztcclxuaW1wb3J0IHsgQW1heExvZ2luQ29tcG9uZW50IH0gZnJvbSAnLi9hbWF4Q29tcG9uZW50cy9hbWF4TG9naW5Db21wb25lbnQnO1xyXG5pbXBvcnQgeyBBbWF4U2VydmljZSB9IGZyb20gJy4vc2VydmljZXMvQW1heFNlcnZpY2UnO1xyXG5pbXBvcnQge1Jlc291cmNlU2VydmljZX0gZnJvbSBcIi4vc2VydmljZXMvUmVzb3VyY2VTZXJ2aWNlXCI7XHJcbmltcG9ydCB7aW5kZXhDb21wb25lbnR9IGZyb20gXCIuL2FtYXgvcXVpY2thY2Nlc3MvaW5kZXhcIjtcclxuaW1wb3J0IHtkZWZhdWx0Q29tcG9uZW50fSBmcm9tIFwiLi9hbWF4L3F1aWNrYWNjZXNzL2RlZmF1bHRcIjtcclxuaW1wb3J0IHtSb3V0ZUNvbmZpZ30gZnJvbSBcImFuZ3VsYXIyL3JvdXRlclwiO1xyXG5pbXBvcnQge0FtYXhMb2dvdXRDb21wb25lbnR9IGZyb20gXCIuL2FtYXgvbG9nb3V0XCI7XHJcbmltcG9ydCB7QW1heFJlcG9ydH0gZnJvbSBcIi4vYW1heC9yZXBvcnRzL2FtYXhSZXBvcnRzXCI7XHJcbmltcG9ydCB7QW1heEZvcm1zfSBmcm9tIFwiLi9hbWF4L2Zvcm1zL2FtYXhGb3Jtc1wiO1xyXG5pbXBvcnQge09ic2VydmFibGV9IGZyb20gXCJyeGpzL09ic2VydmFibGVcIjtcclxuaW1wb3J0IHtBbWF4RW1wbG95ZWVQcm9maWxlfSBmcm9tIFwiLi9hbWF4L2VtcGxveWVlL3Byb2ZpbGVcIjtcclxuaW1wb3J0IHtBbWF4RW1wbG95ZWVTZXR0aW5nc30gZnJvbSBcIi4vYW1heC9lbXBsb3llZS9zZXR0aW5nc1wiO1xyXG5pbXBvcnQge0FtYXhTbXNDb21wb25lbnR9IGZyb20gXCIuL2FtYXgvc21zXCI7XHJcbmltcG9ydCB7QW1heEN1c3RvbWVyc30gZnJvbSBcIi4vYW1heC9DdXN0b21lci9hZGRDdXN0b21lclwiO1xyXG5cclxuaW1wb3J0IHtBbWF4U2VhcmNoQ3VzdG9tZXJzfSBmcm9tIFwiLi9hbWF4L0N1c3RvbWVyL1NlYXJjaEN1c3RvbWVyXCI7XHJcblxyXG5pbXBvcnQge0FtYXhSZWNpZXB0fSBmcm9tIFwiLi9hbWF4L1JlY2llcHRUeXBlL1JlY2llcHRcIjtcclxuaW1wb3J0IHtBbWF4UmVjaWVwdFRlbXBsYXRlfSBmcm9tIFwiLi9hbWF4L1JlY2llcHRUeXBlL1JlY2llcHRUZW1wbGF0ZVwiO1xyXG5pbXBvcnQge0FtYXhUZW1wbGF0ZX0gZnJvbSBcIi4vYW1heC9SZWNpZXB0VHlwZS9UZW1wbGF0ZVwiO1xyXG5pbXBvcnQge0FtYXhHZW5lcmFsR3JvdXBzfSBmcm9tIFwiLi9hbWF4L0dlbmVyYWxHcm91cHMvR2VuZXJhbEdyb3Vwc1wiO1xyXG5pbXBvcnQge0FtYXhUZXJtaW5hbHN9IGZyb20gXCIuL2FtYXgvQ2hhcmdlX0NyZWRpdC9UZXJtaW5hbHNcIjtcclxuaW1wb3J0IHtBbWF4Q2hhcmdlQ3JlZGl0fSBmcm9tIFwiLi9hbWF4L0NoYXJnZV9DcmVkaXQvQ2hhcmdlQ3JlZGl0Q2FyZFwiO1xyXG5pbXBvcnQge0FtYXhSZWNlaXB0U2VsZWN0fSBmcm9tIFwiLi9hbWF4L1JlY2VpcHQvUmVjZWlwdFNlbGVjdFwiO1xyXG5pbXBvcnQge0FtYXhSZWNlaXB0Q3JlYXRlfSBmcm9tIFwiLi9hbWF4L1JlY2VpcHQvUmVjZWlwdENyZWF0ZVwiO1xyXG5pbXBvcnQge0FtYXhTZWFyY2hQcm9kdWN0c30gZnJvbSBcIi4vYW1heC9SZWNlaXB0L1NlYXJjaFByb2R1Y3RzXCI7XHJcbmltcG9ydCB7QW1heEN1c3RvbWVyUHJvZmlsZXN9IGZyb20gXCIuL2FtYXgvQ3VzdG9tZXIvQ3VzdG9tZXJQcm9maWxlXCI7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAnbXgtYXBwJyxcclxuICAgIHRlbXBsYXRlOiBgXHJcbiAgICAgICAgPGRpdiBkaXI9XCJ7eyBSRVMuQVBQX0RJUiB9fVwiPlxyXG4gICAgICAgICAgICA8bXgtbG9naW5cclxuICAgICAgICAgICAgICAgICpuZ0lmPVwiIUlzTG9nZWRJblwiXHJcbiAgICAgICAgICAgICAgICBbKHJlcyldPVwiUkVTLlNDUkVFTl9MT0dJTlwiXHJcbiAgICAgICAgICAgICAgICBbZGF0YU1vZGVsXT1cIl91c2VyTW9kZWxcIiBcclxuICAgICAgICAgICAgICAgIChvbmRhdGEpPVwidmFsaWRhdGVVc2VyKCRldmVudClcIiBcclxuICAgICAgICAgICAgICAgIChvbmxhbmd1YWdlKT1cImNoYW5nZUxhbmd1YWdlKCRldmVudClcIlxyXG4gICAgICAgICAgICA+PC9teC1sb2dpbj5cclxuICAgICAgICAgICAgPGRpdiAqbmdJZj1cIklzTG9nZWRJblwiIGNsYXNzPVwibm8tc2tpblwiPlxyXG4gICAgICAgICAgICAgICAgPG14LXVpPjwvbXgtdWk+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cdGAsXHJcbiAgICBkaXJlY3RpdmVzOiBbQW1heExvZ2luQ29tcG9uZW50LCBBbWF4Q3JtVUlDb21wb25lbnQsIEFtYXhMb2dvdXRDb21wb25lbnQsIEFtYXhMb2dpbkNvbXBvbmVudF0sXHJcbiAgICBwcm92aWRlcnM6IFtBbWF4U2VydmljZSwgUmVzb3VyY2VTZXJ2aWNlXVxyXG59KVxyXG5cclxuQFJvdXRlQ29uZmlnKFtcclxuICAgIHsgcGF0aDpcIi9pbmRleFwiLCAgICAgICAgICAgICAgICAgICAgbmFtZTpcIkluZGV4Um91dGVyXCIsICAgICAgICAgICAgIGNvbXBvbmVudDppbmRleENvbXBvbmVudCB9LFxyXG4gICAgeyBwYXRoOlwiL2RlZmF1bHRcIiwgICAgICAgICAgICAgICAgICBuYW1lOlwiRGVmYXVsdFJvdXRlclwiLCAgICAgICAgICAgY29tcG9uZW50OmRlZmF1bHRDb21wb25lbnQgfSxcclxuXHJcbiAgICAvL1JlcG9ydHMgUm91dGluZ1xyXG4gICAgeyBwYXRoOlwiL3JlcG9ydFwiLCAgICAgICAgICAgICAgICAgICBuYW1lOlwiUmVwb3J0c1wiLCAgICAgICAgICAgICAgICAgY29tcG9uZW50OiBBbWF4UmVwb3J0IH0sXHJcblxyXG4gICAgLy9Gb3JtcyByb3V0aW5nXHJcbiAgICAvL3sgcGF0aDpcIi9mb3JtXCIsIG5hbWU6XCJGb3Jtc1wiLCBjb21wb25lbnQ6QW1heEZvcm1zIH0sXHJcbiAgICB7IHBhdGg6XCIvZm9ybS86ZnJtXCIsICAgICAgICAgICAgICAgIG5hbWU6XCJGb3Jtc1wiLCAgICAgICAgICAgICAgICAgICBjb21wb25lbnQ6QW1heEZvcm1zIH0sXHJcblxyXG4gICAgLy9FbXBsb3llZSByZWxhdGVkIHJvdXRpbmdcclxuICAgIHsgcGF0aDpcIi9lbXBsb3llZS9wcm9maWxlXCIsICAgICAgICAgbmFtZTpcIlByb2ZpbGVcIiwgICAgICAgICAgICAgICAgIGNvbXBvbmVudDogQW1heEVtcGxveWVlUHJvZmlsZSB9LFxyXG4gICAgeyBwYXRoOlwiL2VtcGxveWVlL3NldHRpbmdzXCIsICAgICAgICBuYW1lOlwiU2V0dGluZ3NcIiwgICAgICAgICAgICAgICAgY29tcG9uZW50OiBBbWF4RW1wbG95ZWVTZXR0aW5ncyB9LFxyXG5cclxuXHJcbiAgICAvL01vZHVsZSBSb3V0aW5nXHJcbiAgICAgeyBwYXRoOlwiL3Ntc1wiLCAgICAgICAgICAgICAgICAgICAgICBuYW1lOlwiU21zXCIsICAgICAgICAgICAgICAgICAgICAgY29tcG9uZW50OiBBbWF4U21zQ29tcG9uZW50fSxcclxuXHJcblxyXG4gICAgeyBwYXRoOlwiL2JsYW5rXCIsICAgICAgICAgICAgICAgICAgICBuYW1lOlwiQmxhbmtcIiwgICAgICAgICAgICAgICAgICAgY29tcG9uZW50OiBBbWF4TG9nb3V0Q29tcG9uZW50fSwgLy9mb3IgdGhlIHRlc3RpbmdcclxuXHRcclxuXHQvL0N1c3RvbWVyIFJvdXRpbmdcclxuICAgIHsgcGF0aDogXCIvQ3VzdG9tZXIvQWRkLzpJZFwiLCBuYW1lOiBcIkFkZEN1c3RvbWVyXCIsIGNvbXBvbmVudDogQW1heEN1c3RvbWVycyB9LFxyXG5cclxuICAgIC8vQ3VzdG9tZXIgUm91dGluZ1xyXG4gICAgeyBwYXRoOiBcIi9DdXN0b21lci9TZWFyY2gvOkZvclBvcHVwLzpGcm9tUGFnZS86Rm9yQmFja1wiLCBuYW1lOiBcIlNlYXJjaEN1c3RvbWVyXCIsIGNvbXBvbmVudDogQW1heFNlYXJjaEN1c3RvbWVycyB9LFxyXG5cclxuICAgIC8vUmVjaWVwdCBUeXBlXHJcbiAgICB7IHBhdGg6IFwiL1JlY2VpcHRUeXBlLzpJZFwiLCBuYW1lOiBcIlJlY2VpcHRUeXBlXCIsIGNvbXBvbmVudDogQW1heFJlY2llcHQgfSxcclxuXHJcbiAgICB7IHBhdGg6IFwiL1JlY2VpcHRUZW1wbGF0ZS9BZGQvOklkXCIsIG5hbWU6IFwiUmVjaWVwdFRlbXBsYXRlXCIsIGNvbXBvbmVudDogQW1heFJlY2llcHRUZW1wbGF0ZSB9LFxyXG4gICAgXHJcbiAgICB7IHBhdGg6IFwiL1RlbXBsYXRlL0VkaXQvOklkLzpGUGFnZVwiLCBuYW1lOiBcIlRlbXBsYXRlXCIsIGNvbXBvbmVudDogQW1heFRlbXBsYXRlIH0sXHJcbiAgICB7IHBhdGg6IFwiL0dlbmVyYWxHcm91cHMvVmlld1wiLCBuYW1lOiBcIkdlbmVyYWxHcm91cHNcIiwgY29tcG9uZW50OiBBbWF4R2VuZXJhbEdyb3VwcyB9LFxyXG4gICAgLy9UZW1wbGF0ZXNcclxuICAgIHsgcGF0aDogXCIvVGVybWluYWxzL1Nob3cvOklkXCIsIG5hbWU6IFwiVGVybWluYWxzXCIsIGNvbXBvbmVudDogQW1heFRlcm1pbmFscyB9LFxyXG4gICAgLy9DaGFyZ2VDcmVkaXRcclxuICAgIHsgcGF0aDogXCIvQ2hhcmdlQ3JlZGl0LzpJZC86VGVybU5vXCIsIG5hbWU6IFwiQ2hhcmdlQ3JlZGl0Q2FyZFwiLCBjb21wb25lbnQ6IEFtYXhDaGFyZ2VDcmVkaXQgfSxcclxuICAgIC8vQ2hhcmdlQ3JlZGl0XHJcbiAgICB7IHBhdGg6IFwiL1JlY2VpcHRTZWxlY3QvOklkLzpDdXN0SWRcIiwgbmFtZTogXCJSZWNlaXB0U2VsZWN0XCIsIGNvbXBvbmVudDogQW1heFJlY2VpcHRTZWxlY3QgfSxcclxuICAgIC8vQ2hhcmdlQ3JlZGl0XHJcbiAgICB7IHBhdGg6IFwiL1JlY2VpcHRDcmVhdGUvOklkLzpSZWNlaXB0VHlwZUlkXCIsIG5hbWU6IFwiUmVjZWlwdENyZWF0ZVwiLCBjb21wb25lbnQ6IEFtYXhSZWNlaXB0Q3JlYXRlIH0sXHJcbiAgICAvL1Byb2R1Y3QgU2VhcmNoXHJcbiAgICB7IHBhdGg6IFwiL1NlYXJjaFByb2R1Y3RzLzpJZC86RnJvbVBhZ2VcIiwgbmFtZTogXCJTZWFyY2hQcm9kdWN0c1wiLCBjb21wb25lbnQ6IEFtYXhTZWFyY2hQcm9kdWN0cyB9LFxyXG4gICAgLy9DdXN0b21lciBQcm9maWxlXHJcbiAgICB7IHBhdGg6IFwiL0N1c3RvbWVyL1Byb2ZpbGUvOklkXCIsIG5hbWU6IFwiQ3VzdG9tZXJQcm9maWxlXCIsIGNvbXBvbmVudDogQW1heEN1c3RvbWVyUHJvZmlsZXMgfVxyXG5dKVxyXG5cclxuZXhwb3J0IGNsYXNzIEFtYXhBcHBDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xyXG4gICAgRm9ybVR5cGVGb3JtOiBzdHJpbmcgPSBcIlNDUkVFTl9MT0dJTlwiO1xyXG4gICAgYmFzZVVybDogc3RyaW5nO1xyXG4gICAgQ2hhbmdlRGlhbG9nOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgQ0hBTkdFRElSOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBfYW1heFNzZXJ2aWNlOiBBbWF4U2VydmljZSwgcHJpdmF0ZSBfbGFuZ3VhZ2VTZXJ2aWNlOiBSZXNvdXJjZVNlcnZpY2UpIHtcclxuICAgICAgICAvL0xvYWRpbmcgdGhlIGxhbmd1YWdlIHJlc291cmNlXHJcbiAgICAgICAgdGhpcy5SRVMuU0NSRUVOX0xPR0lOID0ge307XHJcbiAgICAgICAgdGhpcy5Gb3JtVHlwZUZvcm0gPSBcIlNDUkVFTl9MT0dJTlwiO1xyXG4gICAgICAgIHRoaXMuYmFzZVVybCA9IHRoaXMuX2xhbmd1YWdlU2VydmljZS5BcHBVcmw7XHJcbiAgICAgICAgXHJcbiAgICB9XHJcbiAgICBJc0xvZ2VkSW46IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHB1YmxpYyBMb2dpbkRhdGE6IE9iamVjdDtcclxuICAgIHB1YmxpYyBSRVM6IE9iamVjdCA9IHt9O1xyXG4gICAgICAgIFxyXG5cclxuICAgIGxvYWRVc2VySW5mb3JtYXRpb24oKSB7XHJcbiAgICAgICAgaWYgKHNlc3Npb25TdG9yYWdlLmdldEl0ZW0oJ3VzZXJJbmZvcm1hdGlvbicpICE9IG51bGwpIHtcclxuICAgICAgICAgICAgdGhpcy5Mb2dpbkRhdGEgPSBKU09OLnBhcnNlKHNlc3Npb25TdG9yYWdlLmdldEl0ZW0oJ3VzZXJJbmZvcm1hdGlvbicpKTtcclxuICAgICAgICAgICAgaWYgKHRoaXMuTG9naW5EYXRhKSB0aGlzLklzTG9nZWRJbiA9IHRydWU7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICBnZXRsYW5ncmVzKGxhbmdjb2RlKSB7XHJcbiAgICAgICB0aGlzLl9sYW5ndWFnZVNlcnZpY2UuR2V0TGFuZ1Jlcyh0aGlzLkZvcm1UeXBlRm9ybSwgbGFuZ2NvZGUpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgIC8vIGRlYnVnZ2VyO1xyXG4gICAgICAgICAgIHJlc3BvbnNlID0gJC5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgLy9hbGVydChyZXNwb25zZS5FcnJNc2cpO1xyXG4gICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJsYW5ncmVzb3VyY2VcIiwgSlNPTi5zdHJpbmdpZnkocmVzcG9uc2UuRGF0YSkpO1xyXG4gICAgICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImxhbmdcIiwgbGFuZ2NvZGUpO1xyXG4gICAgICAgICAgICAgICB0aGlzLlJFUyA9IHJlc3BvbnNlLkRhdGE7XHJcblxyXG4gICAgICAgICAgIH1cclxuICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgIH0pO1xyXG4gICB9XHJcbnZhbGlkYXRlTG9naW4oKSB7XHJcbiAgICAvL3RoaXMuSXNMb2dlZEluID0gdHJ1ZTsgXHJcbiAgICBpZiAodGhpcy5fdXNlck1vZGVsW1widXNlck5hbWVcIl0gIT0gdW5kZWZpbmVkICYmIHRoaXMuX3VzZXJNb2RlbFtcInVzZXJOYW1lXCJdICE9IG51bGwgJiYgdGhpcy5fdXNlck1vZGVsW1widXNlck5hbWVcIl0gIT0gXCJcIlxyXG4gICAgICAgICYmIHRoaXMuX3VzZXJNb2RlbFtcInBhc3N3b3JkXCJdICE9IHVuZGVmaW5lZCAmJiB0aGlzLl91c2VyTW9kZWxbXCJwYXNzd29yZFwiXSAhPSBudWxsICYmIHRoaXMuX3VzZXJNb2RlbFtcInBhc3N3b3JkXCJdICE9IFwiXCJcclxuICAgICAgICAmJiB0aGlzLl91c2VyTW9kZWxbXCJvcmdOYW1lXCJdICE9IHVuZGVmaW5lZCAmJiB0aGlzLl91c2VyTW9kZWxbXCJvcmdOYW1lXCJdICE9IG51bGwgJiYgdGhpcy5fdXNlck1vZGVsW1wib3JnTmFtZVwiXSAhPSBcIlwiKSB7XHJcbiAgICAgICAgdGhpcy5fYW1heFNzZXJ2aWNlLnZhbGlkYXRlTG9naW4odGhpcy5fdXNlck1vZGVsW1widXNlck5hbWVcIl0sIHRoaXMuX3VzZXJNb2RlbFtcInBhc3N3b3JkXCJdLCB0aGlzLl91c2VyTW9kZWxbXCJvcmdOYW1lXCJdLCB0aGlzLl91c2VyTW9kZWxbXCJyZW1lbWJlck1lXCJdKS5zdWJzY3JpYmUoXHJcbiAgICAgICAgICAgIGRhdGEgPT4ge1xyXG4gICAgICAgICAgICAgICAgdmFyIGR0YSA9ICQucGFyc2VKU09OKGRhdGEpLkRhdGE7XHJcbiAgICAgICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgaWYgKGR0YS5lcnJvciAhPSB1bmRlZmluZWQgJiYgZHRhLmVycm9yICE9IG51bGwgJiYgZHRhLmVycm9yICE9IFwiXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoZHRhLmVycm9yICE9IFwiXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9hbGVydChkdGEuZXJyb3IpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHsgbWVzc2FnZTogZHRhLmVycm9yLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuSXNMb2dlZEluID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLkxvZ2luRGF0YSA9IGR0YTtcclxuICAgICAgICAgICAgICAgICAgICBzZXNzaW9uU3RvcmFnZS5zZXRJdGVtKCdYVG9rZW4nLCBkdGFbXCJ0b2tlblwiXSlcclxuICAgICAgICAgICAgICAgICAgICBzZXNzaW9uU3RvcmFnZS5zZXRJdGVtKCdzZXNzaW9uSW5mb3JtYXRpb24nLCBhdG9iKGR0YVtcInRva2VuXCJdLnNwbGl0KCcuJylbMF0pKTtcclxuICAgICAgICAgICAgICAgICAgICBzZXNzaW9uU3RvcmFnZS5zZXRJdGVtKCd1c2VySW5mb3JtYXRpb24nLCBhdG9iKGR0YVtcInRva2VuXCJdLnNwbGl0KCcuJylbMV0pKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgLy9GZWF0Y2hpbmcgVXNlcmluZm9ybWF0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5Mb2dpbkRhdGEgPSBKU09OLnBhcnNlKGF0b2IoZHRhW1widG9rZW5cIl0uc3BsaXQoJy4nKVsxXSkpO1xyXG4gICAgICAgICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwiZW1wbG95ZWVpZFwiLCB0aGlzLkxvZ2luRGF0YS5lbXBsb3llZWlkKTtcclxuICAgICAgICAgICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSh0aGlzLkxvZ2luRGF0YS5lbXBsb3llZWlkICsgXCJfT3JnSWRcIiwgdGhpcy5Mb2dpbkRhdGEuT3JnSWQpO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImxhbmdcIikgPT0gXCJcIiB8fCBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImxhbmdcIikgPT0gdW5kZWZpbmVkIHx8IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwibGFuZ1wiKSA9PSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwibGFuZ1wiLCBcImVuXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAvL2FsZXJ0KHRoaXMuX3VzZXJNb2RlbFtcInJlbWVtYmVyTWVcIl0udG9TdHJpbmcoKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gIGRlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vYWxlcnQodGhpcy5fdXNlck1vZGVsW1wicmVtZW1iZXJNZVwiXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX3VzZXJNb2RlbFtcInJlbWVtYmVyTWVcIl0gPT0gdHJ1ZSB8fCB0aGlzLl91c2VyTW9kZWxbXCJyZW1lbWJlck1lXCJdID09IFwidHJ1ZVwiKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgbGFuZyA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwibGFuZ1wiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9hbGVydChsYW5nKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy90aGlzLl9sYW5ndWFnZVNlcnZpY2Uuc2V0Q29va2llKFwibGFuZ3Jlc291cmNlXCIsIGxhbmcsMTApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9sYW5ndWFnZVNlcnZpY2Uuc2V0Q29va2llKFwiUmVtZW1iZXJLZXlcIiwgZGF0YSwgMTApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9sYW5ndWFnZVNlcnZpY2Uuc2V0Q29va2llKFwiVXNlck5hbWVcIiwgdGhpcy5fdXNlck1vZGVsW1widXNlck5hbWVcIl0sIDEwKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fbGFuZ3VhZ2VTZXJ2aWNlLnNldENvb2tpZShcInBhc3N3b3JkXCIsIHRoaXMuX3VzZXJNb2RlbFtcInBhc3N3b3JkXCJdLCAxMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2xhbmd1YWdlU2VydmljZS5zZXRDb29raWUoXCJvcmdOYW1lXCIsIHRoaXMuX3VzZXJNb2RlbFtcIm9yZ05hbWVcIl0sIDEwKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fbGFuZ3VhZ2VTZXJ2aWNlLnNldENvb2tpZShcInJlbWVtYmVyTWVcIiwgdGhpcy5fdXNlck1vZGVsW1wicmVtZW1iZXJNZVwiXSwgMTApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9sYW5ndWFnZVNlcnZpY2Uuc2V0Q29va2llKFwibGFuZ1wiLCBsYW5nLCAxMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIGVycm9yID0+IGNvbnNvbGUuZXJyb3IoZXJyb3IpLFxyXG4gICAgICAgICAgICAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIClcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICAgIGlmICh0aGlzLl91c2VyTW9kZWxbXCJ1c2VyTmFtZVwiXSA9PSB1bmRlZmluZWQgJiYgdGhpcy5fdXNlck1vZGVsW1widXNlck5hbWVcIl0gPT0gbnVsbCB8fCB0aGlzLl91c2VyTW9kZWxbXCJ1c2VyTmFtZVwiXSA9PSBcIlwiKSB7XHJcbiAgICAgICAgICAgIC8vYWxlcnQoXCJQbGVhc2UgZW50ZXIgdmFsaWQgdXNlcm5hbWVcIik7XHJcbiAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgbWVzc2FnZTogXCJQbGVhc2UgZW50ZXIgdmFsaWQgdXNlcm5hbWVcIixcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICh0aGlzLl91c2VyTW9kZWxbXCJwYXNzd29yZFwiXSA9PSB1bmRlZmluZWQgJiYgdGhpcy5fdXNlck1vZGVsW1wicGFzc3dvcmRcIl0gPT0gbnVsbCB8fCB0aGlzLl91c2VyTW9kZWxbXCJwYXNzd29yZFwiXSA9PSBcIlwiKSB7XHJcbiAgICAgICAgICAgIC8vYWxlcnQoXCJQbGVhc2UgZW50ZXIgdmFsaWQgcGFzc3dvcmRcIik7XHJcbiAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgbWVzc2FnZTogXCJQbGVhc2UgZW50ZXIgdmFsaWQgcGFzc3dvcmRcIixcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICh0aGlzLl91c2VyTW9kZWxbXCJvcmdOYW1lXCJdID09IHVuZGVmaW5lZCAmJiB0aGlzLl91c2VyTW9kZWxbXCJvcmdOYW1lXCJdID09IG51bGwgfHwgdGhpcy5fdXNlck1vZGVsW1wib3JnTmFtZVwiXSA9PSBcIlwiKSB7XHJcbiAgICAgICAgICAgIC8vYWxlcnQoXCJQbGVhc2UgZW50ZXIgdmFsaWQgb3JnYW5pemF0aW9uXCIpO1xyXG4gICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiUGxlYXNlIGVudGVyIHZhbGlkIHBhc3N3b3JkXCIsXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIH1cclxuXHJcbl91c2VyTW9kZWwgPSB7fTtcclxuX0xvZ2dlZHVzZXJNb2RlbCA9IHt9O1xyXG5cclxuICAgIHZhbGlkYXRlVXNlcihldnQpIHtcclxuICAgICAgICBjb25zb2xlLmxvZyhldnQpO1xyXG4gICAgICAgIHRoaXMudmFsaWRhdGVMb2dpbigpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBjaGFuZ2VMYW5ndWFnZUJ5TGFuZ0lkKExhbmd1YWdlSWQpIHtcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwiQ2hhbmdpbmcgTGFuZ3VhZ2UuLi5cIik7XHJcbiAgICAgICAgaWYgKExhbmd1YWdlSWQpIHtcclxuICAgICAgICAgICAgdGhpcy5fbGFuZ3VhZ2VTZXJ2aWNlLkdldFNlbGVjZXRkTGFuZ3VhZ2UoTGFuZ3VhZ2VJZCkuc3Vic2NyaWJlKFxyXG4gICAgICAgICAgICAgICAgZGF0YSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJsYW5ncmVzb3VyY2VcIiwgSlNPTi5zdHJpbmdpZnkoZGF0YSkpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImxhbmdcIiwgTGFuZ3VhZ2VJZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fdXNlck1vZGVsW1wibGFuZ1wiXSA9IExhbmd1YWdlSWQ7XHJcblxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIGVycm9yID0+IGNvbnNvbGUubG9nKFwiVW5hYmxlIHRvIGxvYWQgTGFuZ3VhZ2UgRGF0YVwiKSxcclxuICAgICAgICAgICAgICAgICgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkxhbmd1YWdlIHJlc291cmNlIGxvYWRlZFwiKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuX2xhbmd1YWdlU2VydmljZS5HZXRMYW5nUmVzKHRoaXMuRm9ybVR5cGVGb3JtLCBMYW5ndWFnZUlkKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgcmVzcG9uc2UgPSAkLnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9hbGVydChyZXNwb25zZS5FcnJNc2cpO1xyXG4gICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwibGFuZ3Jlc291cmNlXCIsIEpTT04uc3RyaW5naWZ5KHJlc3BvbnNlLkRhdGEpKTtcclxuICAgICAgICAgICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImxhbmdcIiwgTGFuZ3VhZ2VJZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5SRVMgPSByZXNwb25zZS5EYXRhO1xyXG5cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgICAgICB9KTtcclxuXHJcblxyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIkNvZGUgbm90IHNwZWNpZmllZFwiKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG5cclxuICAgIHB1YmxpYyBjaGFuZ2VMYW5ndWFnZShldnQpIHtcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwiQ2hhbmdpbmcgTGFuZ3VhZ2UuLi5cIik7XHJcbiAgICAgICAgaWYgKGV2dC5jb2RlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2xhbmd1YWdlU2VydmljZS5HZXRTZWxlY2V0ZExhbmd1YWdlKGV2dC5jb2RlKS5zdWJzY3JpYmUoXHJcbiAgICAgICAgICAgICAgICBkYXRhID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImxhbmdyZXNvdXJjZVwiLCBKU09OLnN0cmluZ2lmeShkYXRhKSk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwibGFuZ1wiLCBldnQuY29kZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fdXNlck1vZGVsW1wibGFuZ1wiXSA9IGV2dC5jb2RlO1xyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIGVycm9yID0+IGNvbnNvbGUubG9nKFwiVW5hYmxlIHRvIGxvYWQgTGFuZ3VhZ2UgRGF0YVwiKSxcclxuICAgICAgICAgICAgICAgICgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkxhbmd1YWdlIHJlc291cmNlIGxvYWRlZFwiKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuX2xhbmd1YWdlU2VydmljZS5HZXRMYW5nUmVzKHRoaXMuRm9ybVR5cGVGb3JtLCBldnQuY29kZSkuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgIHJlc3BvbnNlID0gJC5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIC8vYWxlcnQocmVzcG9uc2UuRXJyTXNnKTtcclxuICAgICAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImxhbmdyZXNvdXJjZVwiLCBKU09OLnN0cmluZ2lmeShyZXNwb25zZS5EYXRhKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJsYW5nXCIsIGV2dC5jb2RlKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLlJFUyA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICAgICAgfSk7XHJcblxyXG5cclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJDb2RlIG5vdCBzcGVjaWZpZWRcIik7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuXHJcbiAgICBuZ09uSW5pdCgpIHtcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG5cclxuICAgICAgICB0aGlzLkZvcm1UeXBlRm9ybSA9IFwiU0NSRUVOX0xPR0lOXCI7XHJcblxyXG4gICAgICAgIHZhciBVc2VyTmFtZSA9IHRoaXMuX2xhbmd1YWdlU2VydmljZS5nZXRDb29raWUoXCJVc2VyTmFtZVwiKTtcclxuICAgICAgICAvL2FsZXJ0KFVzZXJOYW1lWzBdKTtcclxuICAgICAgICBpZiAoVXNlck5hbWUubGVuZ3RoID4gMCAmJiBVc2VyTmFtZVswXT09XCI9XCIpIFxyXG4gICAgICAgICAgICB2YXIgVXNlck5hbWUgPSBVc2VyTmFtZS5zdWJzdHJpbmcoMSxVc2VyTmFtZS5sZW5ndGgpO1xyXG4gICAgICAgIC8vdmFyIHBhc3N3b3JkID0gdGhpcy5fbGFuZ3VhZ2VTZXJ2aWNlLmdldENvb2tpZShcInBhc3N3b3JkXCIpO1xyXG5cclxuICAgICAgICAvL2lmIChwYXNzd29yZC5sZW5ndGggPiAwKSBcclxuICAgICAgICAvLyAgICB2YXIgcGFzc3dvcmQgPSBwYXNzd29yZC5zdWJzdHJpbmcoMSwgcGFzc3dvcmQubGVuZ3RoKTtcclxuICAgICAgICB2YXIgb3JnTmFtZSA9IHRoaXMuX2xhbmd1YWdlU2VydmljZS5nZXRDb29raWUoXCJvcmdOYW1lXCIpO1xyXG5cclxuICAgICAgICBpZiAob3JnTmFtZS5sZW5ndGggPiAwKSBcclxuICAgICAgICAgICAgdmFyIG9yZ05hbWUgPSBvcmdOYW1lLnN1YnN0cmluZygxLCBvcmdOYW1lLmxlbmd0aCk7XHJcbiAgICAgICAgdmFyIHJlbWVtYmVyTWUgPSB0aGlzLl9sYW5ndWFnZVNlcnZpY2UuZ2V0Q29va2llKFwicmVtZW1iZXJNZVwiKTtcclxuXHJcbiAgICAgICAgaWYgKHJlbWVtYmVyTWUubGVuZ3RoID4gMClcclxuICAgICAgICAgICAgdmFyIHJlbWVtYmVyTWUgPSByZW1lbWJlck1lLnN1YnN0cmluZygxLCByZW1lbWJlck1lLmxlbmd0aCk7XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHJlbWVtYmVyTWUgPSBcInRydWVcIjtcclxuICAgICAgICB9XHJcbiAgICAgICAgdmFyIGxhbmcgPSB0aGlzLl9sYW5ndWFnZVNlcnZpY2UuZ2V0Q29va2llKFwibGFuZ1wiKTtcclxuICAgICAgICBcclxuICAgICAgICBpZiAobGFuZy5sZW5ndGggPiAwKVxyXG4gICAgICAgICAgICB2YXIgbGFuZyA9IGxhbmcuc3Vic3RyaW5nKDEsIGxhbmcubGVuZ3RoKTtcclxuICAgICAgICBpZiAobGFuZyA9PSBcIlwiKVxyXG4gICAgICAgICAgICBsYW5nID0gXCJlblwiO1xyXG4gICAgICAgXHJcbiAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJsYW5nXCIsIGxhbmcpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fdXNlck1vZGVsID0ge1xyXG4gICAgICAgICAgICAgICAgICAgIHVzZXJOYW1lOiBVc2VyTmFtZSxcclxuICAgICAgICAgICAgICAgICAgICBwYXNzd29yZDogXCJcIixcclxuICAgICAgICAgICAgICAgICAgICBvcmdOYW1lOiBvcmdOYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgIGxhbmc6IGxhbmcsXHJcbiAgICAgICAgICAgICAgICAgICAgcmVtZW1iZXJNZTogcmVtZW1iZXJNZVxyXG4gICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHRoaXMuX2xhbmd1YWdlU2VydmljZS5HZXRMYW5nUmVzKHRoaXMuRm9ybVR5cGVGb3JtLCBsYW5nKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgcmVzcG9uc2UgPSAkLnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2FsZXJ0KHJlc3BvbnNlLkVyck1zZyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwibGFuZ3Jlc291cmNlXCIsIEpTT04uc3RyaW5naWZ5KHJlc3BvbnNlLkRhdGEpKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJsYW5nXCIsIGxhbmcpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLlJFUyA9IHJlc3BvbnNlLkRhdGE7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICAgICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIC8vdGhpcy5SRVMgPSB7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgIC8vICAgICBcIkFQUF9ESVJcIjogXCJsdHJcIixcclxuICAgICAgICAvLyAgICAgXCJBUFBfTEFOR1wiOiBcImVuXCIsXHJcbiAgICAgICAgLy8gICAgIFwiU0NSRUVOX0xPR0lOXCI6IHtcclxuICAgICAgICAvLyAgICAgICAgIFwiQ09NUEFOWV9OQU1FXCI6IFwiQW1heFwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfVFlQRVwiOiBcIkMuUi5NXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9CQVNFTElORVwiOiBcIsKpIEFtYXggLSBzb2Z0d2FyZSBzb2x1dGlvbnNcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0xCTF9JTkZPXCI6IFwiUGxlYXNlIEVudGVyIFlvdXIgSW5mb3JtYXRpb25cIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0xCTF9VU0VSXCI6IFwiVXNlcm5hbWVcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0xCTF9QQVNTXCI6IFwiUGFzc3dvcmRcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0xCTF9PUkdcIjogXCJPcmdhbml6YXRpb24gSURcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0xCTF9SRU1FTUJFUlwiOiBcIlJlbWVtYmVyIE1lXCIsXHJcblxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfQlROX0xPR0lOXCI6IFwiTG9naW5cIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0xCTF9GT1JHT1RQQVNTXCI6IFwiSSBmb3Jnb3QgbXkgcGFzc3dvcmRcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0xCTF9SRUdJU1RFUlwiOiBcIkkgd2FudCB0byByZWdpc3RlclwiXHJcbiAgICAgICAgLy8gICAgIH0sXHJcbiAgICAgICAgLy8gICAgIFwiQ1VTVE9NRVJfTUFTVEVSXCI6IHtcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0xCTF9DVVNUXCI6IFwiQ3VzdG9tZXJcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0xCTF9DQVJEXCI6IFwiQ2FyZFwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfTEJMX05FV19DVVNUXCI6IFwiQWRkIE5ldyBDdXN0b21lclwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfVFhUX1JFUURcIjogXCIoUmVxdWlyZWQtKilcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX1RYVF9QSF9MTkFNRVwiOiBcIkxhc3QgTmFtZSpcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX1RYVF9QSF9GTkFNRVwiOiBcIkZpcnN0IE5hbWUqXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9UWFRfUEhfTU5BTUVcIjogXCJNaWRkbGUgTmFtZVwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfVFhUX1BIX0NOQU1FXCI6IFwiQ29tcGFueSBOYW1lKlwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfRFBfQ1RZUEVcIjogXCJTZWxlY3QgQ3VzdG9tZXIgVHlwZVwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfRFBfRU1QXCI6IFwiU2VsZWN0IENvbnRhY3QgRW1wbG95ZWVcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0RQX1NPVVJDRVwiOiBcIlNlbGVjdCBTb3VyY2VcIixcclxuXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9UWFRfUEhfQ0NPREVcIjogXCJDdXN0b21lciBDb2RlXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9UWFRfUEhfQkRBVEVcIjogXCJCaXJ0aCBEYXRlXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9UWFRfUEhfSk9CXCI6IFwiSm9iIFRpdGxlXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9UWFRfUEhfVElUTEVcIjogXCJUaXRsZVwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfRFBfU1VGRklYXCI6IFwiU2VsZWN0IFN1ZmZpeFwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfRFBfR0VOREVSXCI6IFwiU2VsZWN0IEdlbmRlclwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfRFBfR0VOREVSX01cIjogXCJNYWxlXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9EUF9HRU5ERVJfRlwiOiBcIkZlbWFsZVwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfTEJMX1BIT05FXCI6IFwiUGhvbmVzXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9MQkxfQUREX1BIXCI6IFwiQWRkIFBob25lXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9EUF9QVFlQRVwiOiBcIlNlbGVjdCBQaG9uZSBUeXBlKlwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfVFhUX1BIX1BSRUZJWFwiOiBcIlByZWZpeFwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfVFhUX1BIX0FSRUFcIjogXCJBcmVhXCIsXHJcblxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfVFhUX1BIX1BIT05FXCI6IFwiUGhvbmUqXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9MQkxfU01TXCI6IFwiRm9yIFNNU1wiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfQ0hLX1BIX1NNU1wiOiBcIkZvciBTTVNcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX1RYVF9QSF9DT01NRU5UXCI6IFwiQ29tbWVudHNcIixcclxuXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9CVE5fUEhBRERcIjogXCJBZGRcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0JUTl9QSENMT1NFXCI6IFwiQ2xvc2VcIixcclxuXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9CVE5fRUFERFwiOiBcIkFkZFwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfQlROX0VDTE9TRVwiOiBcIkNsb3NlXCIsXHJcblxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfQlROX0FEQUREXCI6IFwiQWRkXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9CVE5fQURDTE9TRVwiOiBcIkNsb3NlXCIsXHJcblxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfR1JEX0xCTF9QVFlQRVwiOiBcIlBob25lIFR5cGVcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0dSRF9MQkxfUEhOT1wiOiBcIlByZWZpeC1BcmVhLVBob25lXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9HUkRfTEJMX1NNU1wiOiBcIkZvciBTTVNcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0dSRF9MQkxfUkVNXCI6IFwiUmVtYXJrc1wiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfTE5LX0VNQUlMXCI6IFwiRW1haWxzXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9MQkxfRU1BSUxcIjogXCJBZGQgRW1haWxcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX1RYVF9QSF9FTUFJTFwiOiBcIkVtYWlsKlwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfVFhUX1BIX0VOQU1FXCI6IFwiTmFtZSpcIixcclxuXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9MQkxfTkxFVFRFUlwiOiBcIk5ld3NMZXR0ZXJcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0dSRF9MQkxfRU1BSUxcIjogXCJFbWFpbFwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfR1JEX0xCTF9FTkFNRVwiOiBcIk5hbWVcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0dSRF9MQkxfTkxFVFRFUlwiOiBcIk5ld3NsZXR0ZXJcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0xOS19MQkxfQUREUlNcIjogXCJBZGRyZXNzZXNcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0xCTF9BRERSRVNTXCI6IFwiQWRkIEFkZHJlc3NcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0xCTF9QSF9TVFJcIjogXCJTdHJlZXQqXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9MQkxfUEhfQURBUkVBXCI6IFwiQXJlYSpcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0xCTF9QSF9DSVRZXCI6IFwiQ2l0eSpcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0xCTF9QSF9aSVBcIjogXCJaaXAqXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9EUF9DT1VOVFJZXCI6IFwiU2VsZWN0IENvdW50cnkqXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9EUF9TVEFURVwiOiBcIlNlbGVjdCBTdGF0ZVwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfRFBfQUREUlRZUEVcIjogXCJTZWxlY3QgQWRkcmVzc1R5cGUqXCIsXHJcblxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfTEJMX0RFTElWRVJZXCI6IFwiRGVsaXZlcnlcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0xCTF9NQUREUkVTU1wiOiBcIklzIE1haW4gQWRkcmVzc1wiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfR1JEX0xCTF9TVFJFRVRcIjogXCJTdHJlZXRcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0dSRF9MQkxfQURBUkVBXCI6IFwiQXJlYVwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfR1JEX0xCTF9DSVRZXCI6IFwiQ2l0eU5hbWVcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0dSRF9MQkxfWklQXCI6IFwiWmlwXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9HUkRfTEJMX0NPVU5UUllcIjogXCJDb3VudHJ5Q29kZVwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfR1JEX0xCTF9TVEFURVwiOiBcIlN0YXRlSWRcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0dSRF9MQkxfQUREUkVTU1wiOiBcIkFkZHJlc3NUeXBlSWRcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0dSRF9MQkxfREVMSVZFUllcIjogXCJEZWxpdmVyeVwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfR1JEX0xCTF9NQUREUkVTU1wiOiBcIk1haW5BZGRyZXNzXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9MQkxfR1JQU1wiOiBcIkNob29zZSBHcm91cHNcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0xCTF9MT0FEXCI6IFwiTG9hZGluZ1wiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfQlROX1NBVkVcIjogXCJTYXZlIENoYW5nZXNcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0xOS19MQkxfTU9SRVwiOiBcIk1vcmVcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0xOS19MQkxfTEVTU1wiOiBcIkxlc3NcIlxyXG5cclxuICAgICAgICAvLyAgICAgfVxyXG4gICAgICAgICAgICAgICAgLy8gfVxyXG4gICAgICAgICAgICAgICAgLy9kZWJ1Z2dlcjsgICAgXHJcbiAgICAgICAgICAgICAgICB2YXIgdGVtcCA9IHRoaXMuX2xhbmd1YWdlU2VydmljZS5nZXRDb29raWUoXCJSZW1lbWJlcktleVwiKTtcclxuICAgICAgICAgICAgICAgIGlmICh0ZW1wICE9IFwiXCIgJiYgdGVtcCAhPSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgcGFzc3dvcmQgPSB0aGlzLl9sYW5ndWFnZVNlcnZpY2UuZ2V0Q29va2llKFwicGFzc3dvcmRcIik7XHJcblxyXG4gICAgICAgIGlmIChwYXNzd29yZC5sZW5ndGggPiAwKSBcclxuICAgICAgICAgICAgdmFyIHBhc3N3b3JkID0gcGFzc3dvcmQuc3Vic3RyaW5nKDEsIHBhc3N3b3JkLmxlbmd0aCk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fTG9nZ2VkdXNlck1vZGVsID0ge1xyXG4gICAgICAgICAgICAgICAgdXNlck5hbWU6IFVzZXJOYW1lLFxyXG4gICAgICAgICAgICAgICAgcGFzc3dvcmQ6IHBhc3N3b3JkLFxyXG4gICAgICAgICAgICAgICAgb3JnTmFtZTogb3JnTmFtZSxcclxuICAgICAgICAgICAgICAgIGxhbmc6IGxhbmcsXHJcbiAgICAgICAgICAgICAgICByZW1lbWJlck1lOiByZW1lbWJlck1lXHJcbiAgICAgICAgICAgIH1cclxuXHJcblxyXG4gICAgICAgICAgICB0aGlzLklzTG9nZWRJbiA9IHRydWU7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLl9Mb2dnZWR1c2VyTW9kZWxbXCJ1c2VyTmFtZVwiXSAhPSB1bmRlZmluZWQgJiYgdGhpcy5fTG9nZ2VkdXNlck1vZGVsW1widXNlck5hbWVcIl0gIT0gbnVsbCAmJiB0aGlzLl9Mb2dnZWR1c2VyTW9kZWxbXCJ1c2VyTmFtZVwiXSAhPSBcIlwiXHJcbiAgICAgICAgICAgICAgICAmJiB0aGlzLl9Mb2dnZWR1c2VyTW9kZWxbXCJwYXNzd29yZFwiXSAhPSB1bmRlZmluZWQgJiYgdGhpcy5fTG9nZ2VkdXNlck1vZGVsW1wicGFzc3dvcmRcIl0gIT0gbnVsbCAmJiB0aGlzLl9Mb2dnZWR1c2VyTW9kZWxbXCJwYXNzd29yZFwiXSAhPSBcIlwiXHJcbiAgICAgICAgICAgICAgICAmJiB0aGlzLl9Mb2dnZWR1c2VyTW9kZWxbXCJvcmdOYW1lXCJdICE9IHVuZGVmaW5lZCAmJiB0aGlzLl9Mb2dnZWR1c2VyTW9kZWxbXCJvcmdOYW1lXCJdICE9IG51bGwgJiYgdGhpcy5fTG9nZ2VkdXNlck1vZGVsW1wib3JnTmFtZVwiXSAhPSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9hbWF4U3NlcnZpY2UudmFsaWRhdGVMb2dpbih0aGlzLl9Mb2dnZWR1c2VyTW9kZWxbXCJ1c2VyTmFtZVwiXSwgdGhpcy5fTG9nZ2VkdXNlck1vZGVsW1wicGFzc3dvcmRcIl0sIHRoaXMuX0xvZ2dlZHVzZXJNb2RlbFtcIm9yZ05hbWVcIl0sIHRoaXMuX0xvZ2dlZHVzZXJNb2RlbFtcInJlbWVtYmVyTWVcIl0pLnN1YnNjcmliZShcclxuICAgICAgICAgICAgICAgICAgICBkYXRhID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGR0YSA9ICQucGFyc2VKU09OKGRhdGEpLkRhdGE7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChkdGEuZXJyb3IgIT0gdW5kZWZpbmVkICYmIGR0YS5lcnJvciAhPSBudWxsICYmIGR0YS5lcnJvciAhPSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZHRhLmVycm9yICE9IFwiXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogZHRhLmVycm9yLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLklzTG9nZWRJbiA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLkxvZ2luRGF0YSA9IGR0YTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlc3Npb25TdG9yYWdlLnNldEl0ZW0oJ1hUb2tlbicsIGR0YVtcInRva2VuXCJdKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2Vzc2lvblN0b3JhZ2Uuc2V0SXRlbSgnc2Vzc2lvbkluZm9ybWF0aW9uJywgYXRvYihkdGFbXCJ0b2tlblwiXS5zcGxpdCgnLicpWzBdKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXNzaW9uU3RvcmFnZS5zZXRJdGVtKCd1c2VySW5mb3JtYXRpb24nLCBhdG9iKGR0YVtcInRva2VuXCJdLnNwbGl0KCcuJylbMV0pKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL0ZlYXRjaGluZyBVc2VyaW5mb3JtYXRpb25cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5Mb2dpbkRhdGEgPSBKU09OLnBhcnNlKGF0b2IoZHRhW1widG9rZW5cIl0uc3BsaXQoJy4nKVsxXSkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJlbXBsb3llZWlkXCIsIHRoaXMuTG9naW5EYXRhLmVtcGxveWVlaWQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0odGhpcy5Mb2dpbkRhdGEuZW1wbG95ZWVpZCArIFwiX09yZ0lkXCIsIHRoaXMuTG9naW5EYXRhLk9yZ0lkKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJPcmdJZFwiLCB0aGlzLl9Mb2dnZWR1c2VyTW9kZWxbXCJvcmdOYW1lXCJdKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImxhbmdcIikgPT0gXCJcIiB8fCBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImxhbmdcIikgPT0gdW5kZWZpbmVkIHx8IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwibGFuZ1wiKSA9PSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJsYW5nXCIsIFwiZW5cIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2FsZXJ0KHRoaXMuX0xvZ2dlZHVzZXJNb2RlbFtcInJlbWVtYmVyTWVcIl0udG9TdHJpbmcoKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyAgZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2FsZXJ0KHRoaXMuX0xvZ2dlZHVzZXJNb2RlbFtcInJlbWVtYmVyTWVcIl0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX0xvZ2dlZHVzZXJNb2RlbFtcInJlbWVtYmVyTWVcIl0gPT0gdHJ1ZSB8fCB0aGlzLl9Mb2dnZWR1c2VyTW9kZWxbXCJyZW1lbWJlck1lXCJdID09IFwidHJ1ZVwiKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBsYW5nID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJsYW5nXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vYWxlcnQobGFuZyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy90aGlzLl9sYW5ndWFnZVNlcnZpY2Uuc2V0Q29va2llKFwibGFuZ3Jlc291cmNlXCIsIGxhbmcsMTApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2xhbmd1YWdlU2VydmljZS5zZXRDb29raWUoXCJSZW1lbWJlcktleVwiLCBkYXRhLCAxMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fbGFuZ3VhZ2VTZXJ2aWNlLnNldENvb2tpZShcIlVzZXJOYW1lXCIsIHRoaXMuX0xvZ2dlZHVzZXJNb2RlbFtcInVzZXJOYW1lXCJdLCAxMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fbGFuZ3VhZ2VTZXJ2aWNlLnNldENvb2tpZShcInBhc3N3b3JkXCIsIHRoaXMuX0xvZ2dlZHVzZXJNb2RlbFtcInBhc3N3b3JkXCJdLCAxMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fbGFuZ3VhZ2VTZXJ2aWNlLnNldENvb2tpZShcIm9yZ05hbWVcIiwgdGhpcy5fTG9nZ2VkdXNlck1vZGVsW1wib3JnTmFtZVwiXSwgMTApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2xhbmd1YWdlU2VydmljZS5zZXRDb29raWUoXCJyZW1lbWJlck1lXCIsIHRoaXMuX0xvZ2dlZHVzZXJNb2RlbFtcInJlbWVtYmVyTWVcIl0sIDEwKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9sYW5ndWFnZVNlcnZpY2Uuc2V0Q29va2llKFwibGFuZ1wiLCBsYW5nLCAxMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgZXJyb3IgPT4gY29uc29sZS5lcnJvcihlcnJvciksXHJcbiAgICAgICAgICAgICAgICAgICAgKCkgPT4ge1xyXG5cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5fTG9nZ2VkdXNlck1vZGVsW1widXNlck5hbWVcIl0gPT0gdW5kZWZpbmVkICYmIHRoaXMuX0xvZ2dlZHVzZXJNb2RlbFtcInVzZXJOYW1lXCJdID09IG51bGwgfHwgdGhpcy5fTG9nZ2VkdXNlck1vZGVsW1widXNlck5hbWVcIl0gPT0gXCJcIikge1xyXG4gICAgICAgICAgICAgICAgICAgIC8vYWxlcnQoXCJQbGVhc2UgZW50ZXIgdmFsaWQgdXNlcm5hbWVcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiUGxlYXNlIGVudGVyIHZhbGlkIHVzZXJuYW1lXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9Mb2dnZWR1c2VyTW9kZWxbXCJwYXNzd29yZFwiXSA9PSB1bmRlZmluZWQgJiYgdGhpcy5fTG9nZ2VkdXNlck1vZGVsW1wicGFzc3dvcmRcIl0gPT0gbnVsbCB8fCB0aGlzLl9Mb2dnZWR1c2VyTW9kZWxbXCJwYXNzd29yZFwiXSA9PSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9hbGVydChcIlBsZWFzZSBlbnRlciB2YWxpZCBwYXNzd29yZFwiKTtcclxuICAgICAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogXCJQbGVhc2UgZW50ZXIgdmFsaWQgcGFzc3dvcmRcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX0xvZ2dlZHVzZXJNb2RlbFtcIm9yZ05hbWVcIl0gPT0gdW5kZWZpbmVkICYmIHRoaXMuX0xvZ2dlZHVzZXJNb2RlbFtcIm9yZ05hbWVcIl0gPT0gbnVsbCB8fCB0aGlzLl9Mb2dnZWR1c2VyTW9kZWxbXCJvcmdOYW1lXCJdID09IFwiXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICAvL2FsZXJ0KFwiUGxlYXNlIGVudGVyIHZhbGlkIG9yZ2FuaXphdGlvblwiKTtcclxuICAgICAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogXCJQbGVhc2UgZW50ZXIgdmFsaWQgcGFzc3dvcmRcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcblxyXG5cclxuICAgICAgICB9XHJcbiAgICAgICAgLy8gaWYoIWxvY2FsU3RvcmFnZS5nZXRJdGVtKFwibGFuZ3Jlc291cmNlXCIpKSB7XHJcbiAgICAgICAgLy8gICAgIC8vdGhpcy5fbGFuZ3VhZ2VTZXJ2aWNlLkdldFNlbGVjZXRkTGFuZ3VhZ2UoXCJlblwiKS5zdWJzY3JpYmUoXHJcbiAgICAgICAgLy8gICAgIC8vICAgIGRhdGE9PntcclxuICAgICAgICAvLyAgICAgLy8gICAgICAgIGNvbnNvbGUubG9nKGRhdGEpO1xyXG4gICAgICAgIC8vICAgICAvLyAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJsYW5ncmVzb3VyY2VcIiwgSlNPTi5zdHJpbmdpZnkoZGF0YSkpO1xyXG4gICAgICAgIC8vICAgICAvLyAgICAgICAgdGhpcy5SRVMgPSBkYXRhO1xyXG4gICAgICAgIC8vICAgICAvLyAgICB9LFxyXG4gICAgICAgIC8vICAgICAvLyAgICBlcnJvcj0+Y29uc29sZS5sb2coXCJVbmFibGUgdG8gbG9hZCBMYW5ndWFnZSBEYXRhXCIpLFxyXG4gICAgICAgIC8vICAgICAvLyAgICAoKT0+IHtcclxuICAgICAgICAvLyAgICAgLy8gICAgICAgIGNvbnNvbGUubG9nKFwiTGFuZ3VhZ2UgcmVzb3VyY2UgbG9hZGVkXCIpO1xyXG4gICAgICAgIC8vICAgICAvLyAgICB9XHJcbiAgICAgICAgLy8gICAgIC8vKTtcclxuICAgICAgICAvLyAgICAgdGhpcy5SRVMgPSB0aGlzLl9sYW5ndWFnZVNlcnZpY2UuR2V0U2VsZWNldGRMYW5ndWFnZShcImVuXCIpO1xyXG4gICAgICAgIC8vIH1lbHNle1xyXG4gICAgICAgIC8vICAgICAvL3RoaXMuUkVTPUpTT04ucGFyc2UobG9jYWxTdG9yYWdlLmdldEl0ZW0oJ2xhbmdyZXNvdXJjZScpKTtcclxuICAgICAgICAvLyB9XHJcbiAgICB9XHJcbn0iXX0=
