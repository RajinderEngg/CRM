System.register(['angular2/core', './amaxComponents/amaxCrmUIComponent', './amaxComponents/amaxLoginComponent', './services/AmaxService', "./services/ResourceService", "./amax/quickaccess/index", "./amax/quickaccess/default", "angular2/router", "./amax/logout", "./amax/reports/amaxReports", "./amax/forms/amaxForms", "./amax/employee/profile", "./amax/employee/settings", "./amax/sms", "./amax/Customer/addCustomer", "./amax/Customer/SearchCustomer", "./amax/RecieptType/Reciept", "./amax/RecieptType/RecieptTemplate", "./amax/RecieptType/Template", "./amax/GeneralGroups/GeneralGroups", "./amax/Charge_Credit/Terminals", "./amax/Charge_Credit/ChargeCreditCard", "./amax/Receipt/ReceiptSelect", "./amax/Receipt/ReceiptCreate", "./amax/Receipt/SearchProducts"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, amaxCrmUIComponent_1, amaxLoginComponent_1, AmaxService_1, ResourceService_1, index_1, default_1, router_1, logout_1, amaxReports_1, amaxForms_1, profile_1, settings_1, sms_1, addCustomer_1, SearchCustomer_1, Reciept_1, RecieptTemplate_1, Template_1, GeneralGroups_1, Terminals_1, ChargeCreditCard_1, ReceiptSelect_1, ReceiptCreate_1, SearchProducts_1;
    var AmaxAppComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (amaxCrmUIComponent_1_1) {
                amaxCrmUIComponent_1 = amaxCrmUIComponent_1_1;
            },
            function (amaxLoginComponent_1_1) {
                amaxLoginComponent_1 = amaxLoginComponent_1_1;
            },
            function (AmaxService_1_1) {
                AmaxService_1 = AmaxService_1_1;
            },
            function (ResourceService_1_1) {
                ResourceService_1 = ResourceService_1_1;
            },
            function (index_1_1) {
                index_1 = index_1_1;
            },
            function (default_1_1) {
                default_1 = default_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (logout_1_1) {
                logout_1 = logout_1_1;
            },
            function (amaxReports_1_1) {
                amaxReports_1 = amaxReports_1_1;
            },
            function (amaxForms_1_1) {
                amaxForms_1 = amaxForms_1_1;
            },
            function (profile_1_1) {
                profile_1 = profile_1_1;
            },
            function (settings_1_1) {
                settings_1 = settings_1_1;
            },
            function (sms_1_1) {
                sms_1 = sms_1_1;
            },
            function (addCustomer_1_1) {
                addCustomer_1 = addCustomer_1_1;
            },
            function (SearchCustomer_1_1) {
                SearchCustomer_1 = SearchCustomer_1_1;
            },
            function (Reciept_1_1) {
                Reciept_1 = Reciept_1_1;
            },
            function (RecieptTemplate_1_1) {
                RecieptTemplate_1 = RecieptTemplate_1_1;
            },
            function (Template_1_1) {
                Template_1 = Template_1_1;
            },
            function (GeneralGroups_1_1) {
                GeneralGroups_1 = GeneralGroups_1_1;
            },
            function (Terminals_1_1) {
                Terminals_1 = Terminals_1_1;
            },
            function (ChargeCreditCard_1_1) {
                ChargeCreditCard_1 = ChargeCreditCard_1_1;
            },
            function (ReceiptSelect_1_1) {
                ReceiptSelect_1 = ReceiptSelect_1_1;
            },
            function (ReceiptCreate_1_1) {
                ReceiptCreate_1 = ReceiptCreate_1_1;
            },
            function (SearchProducts_1_1) {
                SearchProducts_1 = SearchProducts_1_1;
            }],
        execute: function() {
            AmaxAppComponent = (function () {
                function AmaxAppComponent(_amaxSservice, _languageService) {
                    this._amaxSservice = _amaxSservice;
                    this._languageService = _languageService;
                    this.FormTypeForm = "SCREEN_LOGIN";
                    this.ChangeDialog = "";
                    this.CHANGEDIR = "";
                    this.IsLogedIn = false;
                    this.RES = {};
                    this._userModel = {};
                    this._LoggeduserModel = {};
                    //Loading the language resource
                    this.RES.SCREEN_LOGIN = {};
                    this.FormTypeForm = "SCREEN_LOGIN";
                    this.baseUrl = this._languageService.AppUrl;
                }
                AmaxAppComponent.prototype.loadUserInformation = function () {
                    if (sessionStorage.getItem('userInformation') != null) {
                        this.LoginData = JSON.parse(sessionStorage.getItem('userInformation'));
                        if (this.LoginData)
                            this.IsLogedIn = true;
                    }
                };
                AmaxAppComponent.prototype.getlangres = function (langcode) {
                    var _this = this;
                    this._languageService.GetLangRes(this.FormTypeForm, langcode).subscribe(function (response) {
                        // debugger;
                        response = $.parseJSON(response);
                        if (response.IsError == true) {
                            //alert(response.ErrMsg);
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            localStorage.setItem("langresource", JSON.stringify(response.Data));
                            localStorage.setItem("lang", langcode);
                            _this.RES = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxAppComponent.prototype.validateLogin = function () {
                    var _this = this;
                    //this.IsLogedIn = true; 
                    if (this._userModel["userName"] != undefined && this._userModel["userName"] != null && this._userModel["userName"] != ""
                        && this._userModel["password"] != undefined && this._userModel["password"] != null && this._userModel["password"] != ""
                        && this._userModel["orgName"] != undefined && this._userModel["orgName"] != null && this._userModel["orgName"] != "") {
                        this._amaxSservice.validateLogin(this._userModel["userName"], this._userModel["password"], this._userModel["orgName"], this._userModel["rememberMe"]).subscribe(function (data) {
                            var dta = $.parseJSON(data).Data;
                            //debugger;
                            if (dta.error != undefined && dta.error != null && dta.error != "") {
                                if (dta.error != "") {
                                    //alert(dta.error);
                                    bootbox.alert({ message: dta.error,
                                        className: _this.ChangeDialog,
                                        buttons: {
                                            ok: {
                                                //label: 'Ok',
                                                className: _this.CHANGEDIR
                                            }
                                        }
                                    });
                                }
                            }
                            else {
                                _this.IsLogedIn = true;
                                _this.LoginData = dta;
                                sessionStorage.setItem('XToken', dta["token"]);
                                sessionStorage.setItem('sessionInformation', atob(dta["token"].split('.')[0]));
                                sessionStorage.setItem('userInformation', atob(dta["token"].split('.')[1]));
                                //Featching Userinformation
                                _this.LoginData = JSON.parse(atob(dta["token"].split('.')[1]));
                                localStorage.setItem("employeeid", _this.LoginData.employeeid);
                                //localStorage.setItem("OrgId", this._userModel["orgName"]);
                                if (localStorage.getItem("lang") == "" || localStorage.getItem("lang") == undefined || localStorage.getItem("lang") == null) {
                                    localStorage.setItem("lang", "en");
                                }
                                //alert(this._userModel["rememberMe"].toString());
                                //  debugger;
                                //alert(this._userModel["rememberMe"]);
                                if (_this._userModel["rememberMe"] == true || _this._userModel["rememberMe"] == "true") {
                                    var lang = localStorage.getItem("lang");
                                    //alert(lang);
                                    //this._languageService.setCookie("langresource", lang,10);
                                    _this._languageService.setCookie("RememberKey", data, 10);
                                    _this._languageService.setCookie("UserName", _this._userModel["userName"], 10);
                                    _this._languageService.setCookie("password", _this._userModel["password"], 10);
                                    _this._languageService.setCookie("orgName", _this._userModel["orgName"], 10);
                                    _this._languageService.setCookie("rememberMe", _this._userModel["rememberMe"], 10);
                                    _this._languageService.setCookie("lang", lang, 10);
                                }
                            }
                        }, function (error) { return console.error(error); }, function () {
                        });
                    }
                    else {
                        if (this._userModel["userName"] == undefined && this._userModel["userName"] == null || this._userModel["userName"] == "") {
                            //alert("Please enter valid username");
                            bootbox.alert({
                                message: "Please enter valid username",
                                className: this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        if (this._userModel["password"] == undefined && this._userModel["password"] == null || this._userModel["password"] == "") {
                            //alert("Please enter valid password");
                            bootbox.alert({
                                message: "Please enter valid password",
                                className: this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        if (this._userModel["orgName"] == undefined && this._userModel["orgName"] == null || this._userModel["orgName"] == "") {
                            //alert("Please enter valid organization");
                            bootbox.alert({
                                message: "Please enter valid password",
                                className: this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: this.CHANGEDIR
                                    }
                                }
                            });
                        }
                    }
                };
                AmaxAppComponent.prototype.validateUser = function (evt) {
                    console.log(evt);
                    this.validateLogin();
                };
                AmaxAppComponent.prototype.changeLanguageByLangId = function (LanguageId) {
                    var _this = this;
                    //debugger;
                    console.log("Changing Language...");
                    if (LanguageId) {
                        this._languageService.GetSelecetdLanguage(LanguageId).subscribe(function (data) {
                            localStorage.setItem("langresource", JSON.stringify(data));
                            localStorage.setItem("lang", LanguageId);
                            _this._userModel["lang"] = LanguageId;
                        }, function (error) { return console.log("Unable to load Language Data"); }, function () {
                            console.log("Language resource loaded");
                        });
                        this._languageService.GetLangRes(this.FormTypeForm, LanguageId).subscribe(function (response) {
                            //debugger;
                            response = $.parseJSON(response);
                            if (response.IsError == true) {
                                //alert(response.ErrMsg);
                                bootbox.alert({
                                    message: response.ErrMsg,
                                    className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                            else {
                                localStorage.setItem("langresource", JSON.stringify(response.Data));
                                localStorage.setItem("lang", LanguageId);
                                _this.RES = response.Data;
                            }
                        }, function (error) {
                            console.log(error);
                        }, function () {
                            console.log("CallCompleted");
                        });
                    }
                    else {
                        console.error("Code not specified");
                    }
                };
                AmaxAppComponent.prototype.changeLanguage = function (evt) {
                    var _this = this;
                    //debugger;
                    console.log("Changing Language...");
                    if (evt.code) {
                        this._languageService.GetSelecetdLanguage(evt.code).subscribe(function (data) {
                            localStorage.setItem("langresource", JSON.stringify(data));
                            localStorage.setItem("lang", evt.code);
                            _this._userModel["lang"] = evt.code;
                        }, function (error) { return console.log("Unable to load Language Data"); }, function () {
                            console.log("Language resource loaded");
                        });
                        this._languageService.GetLangRes(this.FormTypeForm, evt.code).subscribe(function (response) {
                            //debugger;
                            response = $.parseJSON(response);
                            if (response.IsError == true) {
                                //alert(response.ErrMsg);
                                bootbox.alert({
                                    message: response.ErrMsg,
                                    className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                            else {
                                localStorage.setItem("langresource", JSON.stringify(response.Data));
                                localStorage.setItem("lang", evt.code);
                                _this.RES = response.Data;
                            }
                        }, function (error) {
                            console.log(error);
                        }, function () {
                            console.log("CallCompleted");
                        });
                    }
                    else {
                        console.error("Code not specified");
                    }
                };
                AmaxAppComponent.prototype.ngOnInit = function () {
                    //debugger;
                    var _this = this;
                    this.FormTypeForm = "SCREEN_LOGIN";
                    var UserName = this._languageService.getCookie("UserName");
                    //alert(UserName[0]);
                    if (UserName.length > 0 && UserName[0] == "=")
                        var UserName = UserName.substring(1, UserName.length);
                    //var password = this._languageService.getCookie("password");
                    //if (password.length > 0) 
                    //    var password = password.substring(1, password.length);
                    var orgName = this._languageService.getCookie("orgName");
                    if (orgName.length > 0)
                        var orgName = orgName.substring(1, orgName.length);
                    var rememberMe = this._languageService.getCookie("rememberMe");
                    if (rememberMe.length > 0)
                        var rememberMe = rememberMe.substring(1, rememberMe.length);
                    else {
                        rememberMe = "true";
                    }
                    var lang = this._languageService.getCookie("lang");
                    if (lang.length > 0)
                        var lang = lang.substring(1, lang.length);
                    if (lang == "")
                        lang = "en";
                    localStorage.setItem("lang", lang);
                    this._userModel = {
                        userName: UserName,
                        password: "",
                        orgName: orgName,
                        lang: lang,
                        rememberMe: rememberMe
                    };
                    this._languageService.GetLangRes(this.FormTypeForm, lang).subscribe(function (response) {
                        response = $.parseJSON(response);
                        if (response.IsError == true) {
                            //alert(response.ErrMsg);
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            //debugger;
                            localStorage.setItem("langresource", JSON.stringify(response.Data));
                            localStorage.setItem("lang", lang);
                            _this.RES = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //this.RES = {
                    //     "APP_DIR": "ltr",
                    //     "APP_LANG": "en",
                    //     "SCREEN_LOGIN": {
                    //         "COMPANY_NAME": "Amax",
                    //         "APP_TYPE": "C.R.M",
                    //         "APP_BASELINE": "© Amax - software solutions",
                    //         "APP_LBL_INFO": "Please Enter Your Information",
                    //         "APP_LBL_USER": "Username",
                    //         "APP_LBL_PASS": "Password",
                    //         "APP_LBL_ORG": "Organization ID",
                    //         "APP_LBL_REMEMBER": "Remember Me",
                    //         "APP_BTN_LOGIN": "Login",
                    //         "APP_LBL_FORGOTPASS": "I forgot my password",
                    //         "APP_LBL_REGISTER": "I want to register"
                    //     },
                    //     "CUSTOMER_MASTER": {
                    //         "APP_LBL_CUST": "Customer",
                    //         "APP_LBL_CARD": "Card",
                    //         "APP_LBL_NEW_CUST": "Add New Customer",
                    //         "APP_TXT_REQD": "(Required-*)",
                    //         "APP_TXT_PH_LNAME": "Last Name*",
                    //         "APP_TXT_PH_FNAME": "First Name*",
                    //         "APP_TXT_PH_MNAME": "Middle Name",
                    //         "APP_TXT_PH_CNAME": "Company Name*",
                    //         "APP_DP_CTYPE": "Select Customer Type",
                    //         "APP_DP_EMP": "Select Contact Employee",
                    //         "APP_DP_SOURCE": "Select Source",
                    //         "APP_TXT_PH_CCODE": "Customer Code",
                    //         "APP_TXT_PH_BDATE": "Birth Date",
                    //         "APP_TXT_PH_JOB": "Job Title",
                    //         "APP_TXT_PH_TITLE": "Title",
                    //         "APP_DP_SUFFIX": "Select Suffix",
                    //         "APP_DP_GENDER": "Select Gender",
                    //         "APP_DP_GENDER_M": "Male",
                    //         "APP_DP_GENDER_F": "Female",
                    //         "APP_LBL_PHONE": "Phones",
                    //         "APP_LBL_ADD_PH": "Add Phone",
                    //         "APP_DP_PTYPE": "Select Phone Type*",
                    //         "APP_TXT_PH_PREFIX": "Prefix",
                    //         "APP_TXT_PH_AREA": "Area",
                    //         "APP_TXT_PH_PHONE": "Phone*",
                    //         "APP_LBL_SMS": "For SMS",
                    //         "APP_CHK_PH_SMS": "For SMS",
                    //         "APP_TXT_PH_COMMENT": "Comments",
                    //         "APP_BTN_PHADD": "Add",
                    //         "APP_BTN_PHCLOSE": "Close",
                    //         "APP_BTN_EADD": "Add",
                    //         "APP_BTN_ECLOSE": "Close",
                    //         "APP_BTN_ADADD": "Add",
                    //         "APP_BTN_ADCLOSE": "Close",
                    //         "APP_GRD_LBL_PTYPE": "Phone Type",
                    //         "APP_GRD_LBL_PHNO": "Prefix-Area-Phone",
                    //         "APP_GRD_LBL_SMS": "For SMS",
                    //         "APP_GRD_LBL_REM": "Remarks",
                    //         "APP_LNK_EMAIL": "Emails",
                    //         "APP_LBL_EMAIL": "Add Email",
                    //         "APP_TXT_PH_EMAIL": "Email*",
                    //         "APP_TXT_PH_ENAME": "Name*",
                    //         "APP_LBL_NLETTER": "NewsLetter",
                    //         "APP_GRD_LBL_EMAIL": "Email",
                    //         "APP_GRD_LBL_ENAME": "Name",
                    //         "APP_GRD_LBL_NLETTER": "Newsletter",
                    //         "APP_LNK_LBL_ADDRS": "Addresses",
                    //         "APP_LBL_ADDRESS": "Add Address",
                    //         "APP_LBL_PH_STR": "Street*",
                    //         "APP_LBL_PH_ADAREA": "Area*",
                    //         "APP_LBL_PH_CITY": "City*",
                    //         "APP_LBL_PH_ZIP": "Zip*",
                    //         "APP_DP_COUNTRY": "Select Country*",
                    //         "APP_DP_STATE": "Select State",
                    //         "APP_DP_ADDRTYPE": "Select AddressType*",
                    //         "APP_LBL_DELIVERY": "Delivery",
                    //         "APP_LBL_MADDRESS": "Is Main Address",
                    //         "APP_GRD_LBL_STREET": "Street",
                    //         "APP_GRD_LBL_ADAREA": "Area",
                    //         "APP_GRD_LBL_CITY": "CityName",
                    //         "APP_GRD_LBL_ZIP": "Zip",
                    //         "APP_GRD_LBL_COUNTRY": "CountryCode",
                    //         "APP_GRD_LBL_STATE": "StateId",
                    //         "APP_GRD_LBL_ADDRESS": "AddressTypeId",
                    //         "APP_GRD_LBL_DELIVERY": "Delivery",
                    //         "APP_GRD_LBL_MADDRESS": "MainAddress",
                    //         "APP_LBL_GRPS": "Choose Groups",
                    //         "APP_LBL_LOAD": "Loading",
                    //         "APP_BTN_SAVE": "Save Changes",
                    //         "APP_LNK_LBL_MORE": "More",
                    //         "APP_LNK_LBL_LESS": "Less"
                    //     }
                    // }
                    //debugger;    
                    var temp = this._languageService.getCookie("RememberKey");
                    if (temp != "" && temp != undefined) {
                        var password = this._languageService.getCookie("password");
                        if (password.length > 0)
                            var password = password.substring(1, password.length);
                        this._LoggeduserModel = {
                            userName: UserName,
                            password: password,
                            orgName: orgName,
                            lang: lang,
                            rememberMe: rememberMe
                        };
                        this.IsLogedIn = true;
                        if (this._LoggeduserModel["userName"] != undefined && this._LoggeduserModel["userName"] != null && this._LoggeduserModel["userName"] != ""
                            && this._LoggeduserModel["password"] != undefined && this._LoggeduserModel["password"] != null && this._LoggeduserModel["password"] != ""
                            && this._LoggeduserModel["orgName"] != undefined && this._LoggeduserModel["orgName"] != null && this._LoggeduserModel["orgName"] != "") {
                            this._amaxSservice.validateLogin(this._LoggeduserModel["userName"], this._LoggeduserModel["password"], this._LoggeduserModel["orgName"], this._LoggeduserModel["rememberMe"]).subscribe(function (data) {
                                var dta = $.parseJSON(data).Data;
                                //debugger;
                                if (dta.error != undefined && dta.error != null && dta.error != "") {
                                    if (dta.error != "") {
                                        bootbox.alert({
                                            message: dta.error,
                                            className: _this.ChangeDialog,
                                            buttons: {
                                                ok: {
                                                    //label: 'Ok',
                                                    className: _this.CHANGEDIR
                                                }
                                            }
                                        });
                                    }
                                }
                                else {
                                    _this.IsLogedIn = true;
                                    _this.LoginData = dta;
                                    sessionStorage.setItem('XToken', dta["token"]);
                                    sessionStorage.setItem('sessionInformation', atob(dta["token"].split('.')[0]));
                                    sessionStorage.setItem('userInformation', atob(dta["token"].split('.')[1]));
                                    //Featching Userinformation
                                    _this.LoginData = JSON.parse(atob(dta["token"].split('.')[1]));
                                    localStorage.setItem("employeeid", _this.LoginData.employeeid);
                                    //localStorage.setItem("OrgId", this._LoggeduserModel["orgName"]);
                                    if (localStorage.getItem("lang") == "" || localStorage.getItem("lang") == undefined || localStorage.getItem("lang") == null) {
                                        localStorage.setItem("lang", "en");
                                    }
                                    //alert(this._LoggeduserModel["rememberMe"].toString());
                                    //  debugger;
                                    //alert(this._LoggeduserModel["rememberMe"]);
                                    if (_this._LoggeduserModel["rememberMe"] == true || _this._LoggeduserModel["rememberMe"] == "true") {
                                        var lang = localStorage.getItem("lang");
                                        //alert(lang);
                                        //this._languageService.setCookie("langresource", lang,10);
                                        _this._languageService.setCookie("RememberKey", data, 10);
                                        _this._languageService.setCookie("UserName", _this._LoggeduserModel["userName"], 10);
                                        _this._languageService.setCookie("password", _this._LoggeduserModel["password"], 10);
                                        _this._languageService.setCookie("orgName", _this._LoggeduserModel["orgName"], 10);
                                        _this._languageService.setCookie("rememberMe", _this._LoggeduserModel["rememberMe"], 10);
                                        _this._languageService.setCookie("lang", lang, 10);
                                    }
                                }
                            }, function (error) { return console.error(error); }, function () {
                            });
                        }
                        else {
                            if (this._LoggeduserModel["userName"] == undefined && this._LoggeduserModel["userName"] == null || this._LoggeduserModel["userName"] == "") {
                                //alert("Please enter valid username");
                                bootbox.alert({
                                    message: "Please enter valid username",
                                    className: this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                            if (this._LoggeduserModel["password"] == undefined && this._LoggeduserModel["password"] == null || this._LoggeduserModel["password"] == "") {
                                //alert("Please enter valid password");
                                bootbox.alert({
                                    message: "Please enter valid password",
                                    className: this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                            if (this._LoggeduserModel["orgName"] == undefined && this._LoggeduserModel["orgName"] == null || this._LoggeduserModel["orgName"] == "") {
                                //alert("Please enter valid organization");
                                bootbox.alert({
                                    message: "Please enter valid password",
                                    className: this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                        }
                    }
                    // if(!localStorage.getItem("langresource")) {
                    //     //this._languageService.GetSelecetdLanguage("en").subscribe(
                    //     //    data=>{
                    //     //        console.log(data);
                    //     //        localStorage.setItem("langresource", JSON.stringify(data));
                    //     //        this.RES = data;
                    //     //    },
                    //     //    error=>console.log("Unable to load Language Data"),
                    //     //    ()=> {
                    //     //        console.log("Language resource loaded");
                    //     //    }
                    //     //);
                    //     this.RES = this._languageService.GetSelecetdLanguage("en");
                    // }else{
                    //     //this.RES=JSON.parse(localStorage.getItem('langresource'));
                    // }
                };
                AmaxAppComponent = __decorate([
                    core_1.Component({
                        selector: 'mx-app',
                        template: "\n        <div dir=\"{{ RES.APP_DIR }}\">\n            <mx-login\n                *ngIf=\"!IsLogedIn\"\n                [(res)]=\"RES.SCREEN_LOGIN\"\n                [dataModel]=\"_userModel\" \n                (ondata)=\"validateUser($event)\" \n                (onlanguage)=\"changeLanguage($event)\"\n            ></mx-login>\n            <div *ngIf=\"IsLogedIn\" class=\"no-skin\">\n                <mx-ui></mx-ui>\n            </div>\n        </div>\n\t",
                        directives: [amaxLoginComponent_1.AmaxLoginComponent, amaxCrmUIComponent_1.AmaxCrmUIComponent, logout_1.AmaxLogoutComponent, amaxLoginComponent_1.AmaxLoginComponent],
                        providers: [AmaxService_1.AmaxService, ResourceService_1.ResourceService]
                    }),
                    router_1.RouteConfig([
                        { path: "/index", name: "IndexRouter", component: index_1.indexComponent },
                        { path: "/default", name: "DefaultRouter", component: default_1.defaultComponent },
                        //Reports Routing
                        { path: "/report", name: "Reports", component: amaxReports_1.AmaxReport },
                        //Forms routing
                        //{ path:"/form", name:"Forms", component:AmaxForms },
                        { path: "/form/:frm", name: "Forms", component: amaxForms_1.AmaxForms },
                        //Employee related routing
                        { path: "/employee/profile", name: "Profile", component: profile_1.AmaxEmployeeProfile },
                        { path: "/employee/settings", name: "Settings", component: settings_1.AmaxEmployeeSettings },
                        //Module Routing
                        { path: "/sms", name: "Sms", component: sms_1.AmaxSmsComponent },
                        { path: "/blank", name: "Blank", component: logout_1.AmaxLogoutComponent },
                        //Customer Routing
                        { path: "/Customer/Add/:Id", name: "AddCustomer", component: addCustomer_1.AmaxCustomers },
                        //Customer Routing
                        { path: "/Customer/Search/:ForPopup/:FromPage/:ForBack", name: "SearchCustomer", component: SearchCustomer_1.AmaxSearchCustomers },
                        //Reciept Type
                        { path: "/ReceiptType/:Id", name: "ReceiptType", component: Reciept_1.AmaxReciept },
                        { path: "/ReceiptTemplate/Add/:Id", name: "RecieptTemplate", component: RecieptTemplate_1.AmaxRecieptTemplate },
                        { path: "/Template/Edit/:Id/:FPage", name: "Template", component: Template_1.AmaxTemplate },
                        { path: "/GeneralGroups/View", name: "GeneralGroups", component: GeneralGroups_1.AmaxGeneralGroups },
                        //Templates
                        { path: "/Terminals/Show/:Id", name: "Terminals", component: Terminals_1.AmaxTerminals },
                        //ChargeCredit
                        { path: "/ChargeCredit/:Id/:TermNo", name: "ChargeCreditCard", component: ChargeCreditCard_1.AmaxChargeCredit },
                        //ChargeCredit
                        { path: "/ReceiptSelect/:Id/:CustId", name: "ReceiptSelect", component: ReceiptSelect_1.AmaxReceiptSelect },
                        //ChargeCredit
                        { path: "/ReceiptCreate/:Id/:ReceiptTypeId", name: "ReceiptCreate", component: ReceiptCreate_1.AmaxReceiptCreate },
                        //Product Search
                        { path: "/SearchProducts/:Id/:FromPage", name: "SearchProducts", component: SearchProducts_1.AmaxSearchProducts }
                    ]), 
                    __metadata('design:paramtypes', [AmaxService_1.AmaxService, ResourceService_1.ResourceService])
                ], AmaxAppComponent);
                return AmaxAppComponent;
            }());
            exports_1("AmaxAppComponent", AmaxAppComponent);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFtYXhBcHAuY29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1lBaUdBO2dCQUtJLDBCQUFvQixhQUEwQixFQUFVLGdCQUFpQztvQkFBckUsa0JBQWEsR0FBYixhQUFhLENBQWE7b0JBQVUscUJBQWdCLEdBQWhCLGdCQUFnQixDQUFpQjtvQkFKekYsaUJBQVksR0FBVyxjQUFjLENBQUM7b0JBRXRDLGlCQUFZLEdBQVcsRUFBRSxDQUFDO29CQUMxQixjQUFTLEdBQVcsRUFBRSxDQUFDO29CQVF2QixjQUFTLEdBQVksS0FBSyxDQUFDO29CQUVwQixRQUFHLEdBQVcsRUFBRSxDQUFDO29CQWlKNUIsZUFBVSxHQUFHLEVBQUUsQ0FBQztvQkFDaEIscUJBQWdCLEdBQUcsRUFBRSxDQUFDO29CQTFKZCwrQkFBK0I7b0JBQy9CLElBQUksQ0FBQyxHQUFHLENBQUMsWUFBWSxHQUFHLEVBQUUsQ0FBQztvQkFDM0IsSUFBSSxDQUFDLFlBQVksR0FBRyxjQUFjLENBQUM7b0JBQ25DLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQztnQkFFaEQsQ0FBQztnQkFNRCw4Q0FBbUIsR0FBbkI7b0JBQ0ksRUFBRSxDQUFDLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7d0JBQ3BELElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQzt3QkFDdkUsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQzs0QkFBQyxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQztvQkFDOUMsQ0FBQztnQkFDTCxDQUFDO2dCQUNGLHFDQUFVLEdBQVYsVUFBVyxRQUFRO29CQUFuQixpQkE2QkM7b0JBNUJHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxRQUFRLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUM3RSxZQUFZO3dCQUNYLFFBQVEsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUNqQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLHlCQUF5Qjs0QkFDekIsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBRUYsWUFBWSxDQUFDLE9BQU8sQ0FBQyxjQUFjLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDcEUsWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsUUFBUSxDQUFDLENBQUM7NEJBQ3ZDLEtBQUksQ0FBQyxHQUFHLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzt3QkFFN0IsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztnQkFDUCxDQUFDO2dCQUNKLHdDQUFhLEdBQWI7b0JBQUEsaUJBd0dLO29CQXZHRCx5QkFBeUI7b0JBQ3pCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRTsyQkFDakgsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFOzJCQUNwSCxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7d0JBQ3ZILElBQUksQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQzNKLFVBQUEsSUFBSTs0QkFDQSxJQUFJLEdBQUcsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQzs0QkFDakMsV0FBVzs0QkFDWCxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxJQUFJLFNBQVMsSUFBSSxHQUFHLENBQUMsS0FBSyxJQUFJLElBQUksSUFBSSxHQUFHLENBQUMsS0FBSyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0NBQ2pFLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQztvQ0FDbEIsbUJBQW1CO29DQUNuQixPQUFPLENBQUMsS0FBSyxDQUFDLEVBQUUsT0FBTyxFQUFFLEdBQUcsQ0FBQyxLQUFLO3dDQUM5QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7d0NBQzVCLE9BQU8sRUFBRTs0Q0FDTCxFQUFFLEVBQUU7Z0RBQ0EsY0FBYztnREFDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7NkNBQzVCO3lDQUNKO3FDQUNSLENBQUMsQ0FBQztnQ0FDSCxDQUFDOzRCQUNMLENBQUM7NEJBQ0QsSUFBSSxDQUFDLENBQUM7Z0NBQ0YsS0FBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7Z0NBQ3RCLEtBQUksQ0FBQyxTQUFTLEdBQUcsR0FBRyxDQUFDO2dDQUNyQixjQUFjLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQTtnQ0FDOUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxvQkFBb0IsRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQy9FLGNBQWMsQ0FBQyxPQUFPLENBQUMsaUJBQWlCLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUU1RSwyQkFBMkI7Z0NBRTNCLEtBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQzlELFlBQVksQ0FBQyxPQUFPLENBQUMsWUFBWSxFQUFFLEtBQUksQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7Z0NBQzlELDREQUE0RDtnQ0FDNUQsRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLElBQUksWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsSUFBSSxTQUFTLElBQUksWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO29DQUMxSCxZQUFZLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQztnQ0FDdkMsQ0FBQztnQ0FDRCxrREFBa0Q7Z0NBQ2xELGFBQWE7Z0NBQ2IsdUNBQXVDO2dDQUN2QyxFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxJQUFJLElBQUksSUFBSSxLQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxJQUFJLE1BQU0sQ0FBQyxDQUFDLENBQUM7b0NBRW5GLElBQUksSUFBSSxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7b0NBQ3hDLGNBQWM7b0NBQ2QsMkRBQTJEO29DQUMzRCxLQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLGFBQWEsRUFBRSxJQUFJLEVBQUUsRUFBRSxDQUFDLENBQUM7b0NBQ3pELEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsVUFBVSxFQUFFLEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7b0NBQzdFLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsVUFBVSxFQUFFLEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7b0NBQzdFLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsU0FBUyxFQUFFLEtBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7b0NBQzNFLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsWUFBWSxFQUFFLEtBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7b0NBQ2pGLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLElBQUksRUFBRSxFQUFFLENBQUMsQ0FBQztnQ0FDdEQsQ0FBQzs0QkFDTCxDQUFDO3dCQUVMLENBQUMsRUFFRCxVQUFBLEtBQUssSUFBSSxPQUFBLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEVBQXBCLENBQW9CLEVBQzdCO3dCQUVBLENBQUMsQ0FDSixDQUFBO29CQUNMLENBQUM7b0JBQ0QsSUFBSSxDQUFDLENBQUM7d0JBQ0YsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDOzRCQUN2SCx1Q0FBdUM7NEJBQ3ZDLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLDZCQUE2QjtnQ0FDdEMsU0FBUyxFQUFFLElBQUksQ0FBQyxZQUFZO2dDQUM1QixPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7NEJBQ3ZILHVDQUF1Qzs0QkFDdkMsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsNkJBQTZCO2dDQUN0QyxTQUFTLEVBQUUsSUFBSSxDQUFDLFlBQVk7Z0NBQzVCLE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzs0QkFDcEgsMkNBQTJDOzRCQUMzQyxPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSw2QkFBNkI7Z0NBQ3RDLFNBQVMsRUFBRSxJQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7b0JBQ0wsQ0FBQztnQkFDRCxDQUFDO2dCQUtELHVDQUFZLEdBQVosVUFBYSxHQUFHO29CQUNaLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7b0JBQ2pCLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztnQkFDekIsQ0FBQztnQkFFTSxpREFBc0IsR0FBN0IsVUFBOEIsVUFBVTtvQkFBeEMsaUJBbURDO29CQWxERyxXQUFXO29CQUNYLE9BQU8sQ0FBQyxHQUFHLENBQUMsc0JBQXNCLENBQUMsQ0FBQztvQkFDcEMsRUFBRSxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQzt3QkFDYixJQUFJLENBQUMsZ0JBQWdCLENBQUMsbUJBQW1CLENBQUMsVUFBVSxDQUFDLENBQUMsU0FBUyxDQUMzRCxVQUFBLElBQUk7NEJBQ0EsWUFBWSxDQUFDLE9BQU8sQ0FBQyxjQUFjLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUUzRCxZQUFZLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxVQUFVLENBQUMsQ0FBQzs0QkFDekMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsR0FBRyxVQUFVLENBQUM7d0JBRXpDLENBQUMsRUFDRCxVQUFBLEtBQUssSUFBSSxPQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsOEJBQThCLENBQUMsRUFBM0MsQ0FBMkMsRUFDcEQ7NEJBQ0ksT0FBTyxDQUFDLEdBQUcsQ0FBQywwQkFBMEIsQ0FBQyxDQUFDO3dCQUM1QyxDQUFDLENBQ0osQ0FBQzt3QkFFRixJQUFJLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsVUFBVSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTs0QkFDOUUsV0FBVzs0QkFDWCxRQUFRLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzs0QkFDakMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO2dDQUMzQix5QkFBeUI7Z0NBQ3pCLE9BQU8sQ0FBQyxLQUFLLENBQUM7b0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO29DQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7b0NBQzVCLE9BQU8sRUFBRTt3Q0FDTCxFQUFFLEVBQUU7NENBQ0EsY0FBYzs0Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7eUNBQzVCO3FDQUNKO2lDQUNKLENBQUMsQ0FBQzs0QkFDUCxDQUFDOzRCQUNELElBQUksQ0FBQyxDQUFDO2dDQUNGLFlBQVksQ0FBQyxPQUFPLENBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7Z0NBQ3BFLFlBQVksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLFVBQVUsQ0FBQyxDQUFDO2dDQUN6QyxLQUFJLENBQUMsR0FBRyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7NEJBRTdCLENBQUM7d0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzs0QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO3dCQUN2QixDQUFDLEVBQUU7NEJBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTt3QkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBR1AsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixPQUFPLENBQUMsS0FBSyxDQUFDLG9CQUFvQixDQUFDLENBQUM7b0JBQ3hDLENBQUM7Z0JBQ0wsQ0FBQztnQkFHTSx5Q0FBYyxHQUFyQixVQUFzQixHQUFHO29CQUF6QixpQkFtREM7b0JBbERHLFdBQVc7b0JBQ1gsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO29CQUNwQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQzt3QkFDWCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsbUJBQW1CLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLFNBQVMsQ0FDekQsVUFBQSxJQUFJOzRCQUNBLFlBQVksQ0FBQyxPQUFPLENBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFFM0QsWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDOzRCQUN2QyxLQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUM7d0JBRXZDLENBQUMsRUFDRCxVQUFBLEtBQUssSUFBSSxPQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsOEJBQThCLENBQUMsRUFBM0MsQ0FBMkMsRUFDcEQ7NEJBQ0ksT0FBTyxDQUFDLEdBQUcsQ0FBQywwQkFBMEIsQ0FBQyxDQUFDO3dCQUM1QyxDQUFDLENBQ0osQ0FBQzt3QkFFRixJQUFJLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7NEJBQzVFLFdBQVc7NEJBQ1gsUUFBUSxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7NEJBQ2pDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQztnQ0FDM0IseUJBQXlCO2dDQUN6QixPQUFPLENBQUMsS0FBSyxDQUFDO29DQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtvQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO29DQUM1QixPQUFPLEVBQUU7d0NBQ0wsRUFBRSxFQUFFOzRDQUNBLGNBQWM7NENBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3lDQUM1QjtxQ0FDSjtpQ0FDSixDQUFDLENBQUM7NEJBQ1AsQ0FBQzs0QkFDRCxJQUFJLENBQUMsQ0FBQztnQ0FDRixZQUFZLENBQUMsT0FBTyxDQUFDLGNBQWMsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dDQUNwRSxZQUFZLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUM7Z0NBQ3ZDLEtBQUksQ0FBQyxHQUFHLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzs0QkFFN0IsQ0FBQzt3QkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLOzRCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7d0JBQ3ZCLENBQUMsRUFBRTs0QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO3dCQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFHUCxDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUNGLE9BQU8sQ0FBQyxLQUFLLENBQUMsb0JBQW9CLENBQUMsQ0FBQztvQkFDeEMsQ0FBQztnQkFDTCxDQUFDO2dCQUdELG1DQUFRLEdBQVI7b0JBQ0ksV0FBVztvQkFEZixpQkFrVEM7b0JBL1NHLElBQUksQ0FBQyxZQUFZLEdBQUcsY0FBYyxDQUFDO29CQUVuQyxJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO29CQUMzRCxxQkFBcUI7b0JBQ3JCLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxJQUFJLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBRSxHQUFHLENBQUM7d0JBQ3hDLElBQUksUUFBUSxHQUFHLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDekQsNkRBQTZEO29CQUU3RCwyQkFBMkI7b0JBQzNCLDREQUE0RDtvQkFDNUQsSUFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsQ0FBQztvQkFFekQsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7d0JBQ25CLElBQUksT0FBTyxHQUFHLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDdkQsSUFBSSxVQUFVLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUMsQ0FBQztvQkFFL0QsRUFBRSxDQUFDLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7d0JBQ3RCLElBQUksVUFBVSxHQUFHLFVBQVUsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDaEUsSUFBSSxDQUFDLENBQUM7d0JBQ0YsVUFBVSxHQUFHLE1BQU0sQ0FBQztvQkFDeEIsQ0FBQztvQkFDRCxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUVuRCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQzt3QkFDaEIsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUM5QyxFQUFFLENBQUMsQ0FBQyxJQUFJLElBQUksRUFBRSxDQUFDO3dCQUNYLElBQUksR0FBRyxJQUFJLENBQUM7b0JBRWhCLFlBQVksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxDQUFDO29CQUMzQixJQUFJLENBQUMsVUFBVSxHQUFHO3dCQUNkLFFBQVEsRUFBRSxRQUFRO3dCQUNsQixRQUFRLEVBQUUsRUFBRTt3QkFDWixPQUFPLEVBQUUsT0FBTzt3QkFDaEIsSUFBSSxFQUFFLElBQUk7d0JBQ1YsVUFBVSxFQUFFLFVBQVU7cUJBQ2pDLENBQUE7b0JBQ08sSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7d0JBRXhFLFFBQVEsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUNqQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLHlCQUF5Qjs0QkFDekIsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsV0FBVzs0QkFDWCxZQUFZLENBQUMsT0FBTyxDQUFDLGNBQWMsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUNwRSxZQUFZLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQzs0QkFDbkMsS0FBSSxDQUFDLEdBQUcsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO3dCQUU3QixDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUNYLGNBQWM7b0JBRWQsd0JBQXdCO29CQUN4Qix3QkFBd0I7b0JBQ3hCLHdCQUF3QjtvQkFDeEIsa0NBQWtDO29CQUNsQywrQkFBK0I7b0JBQy9CLHlEQUF5RDtvQkFDekQsMkRBQTJEO29CQUMzRCxzQ0FBc0M7b0JBQ3RDLHNDQUFzQztvQkFDdEMsNENBQTRDO29CQUM1Qyw2Q0FBNkM7b0JBRTdDLG9DQUFvQztvQkFDcEMsd0RBQXdEO29CQUN4RCxtREFBbUQ7b0JBQ25ELFNBQVM7b0JBQ1QsMkJBQTJCO29CQUMzQixzQ0FBc0M7b0JBQ3RDLGtDQUFrQztvQkFDbEMsa0RBQWtEO29CQUNsRCwwQ0FBMEM7b0JBQzFDLDRDQUE0QztvQkFDNUMsNkNBQTZDO29CQUM3Qyw2Q0FBNkM7b0JBQzdDLCtDQUErQztvQkFDL0Msa0RBQWtEO29CQUNsRCxtREFBbUQ7b0JBQ25ELDRDQUE0QztvQkFFNUMsK0NBQStDO29CQUMvQyw0Q0FBNEM7b0JBQzVDLHlDQUF5QztvQkFDekMsdUNBQXVDO29CQUN2Qyw0Q0FBNEM7b0JBQzVDLDRDQUE0QztvQkFDNUMscUNBQXFDO29CQUNyQyx1Q0FBdUM7b0JBQ3ZDLHFDQUFxQztvQkFDckMseUNBQXlDO29CQUN6QyxnREFBZ0Q7b0JBQ2hELHlDQUF5QztvQkFDekMscUNBQXFDO29CQUVyQyx3Q0FBd0M7b0JBQ3hDLG9DQUFvQztvQkFDcEMsdUNBQXVDO29CQUN2Qyw0Q0FBNEM7b0JBRTVDLGtDQUFrQztvQkFDbEMsc0NBQXNDO29CQUV0QyxpQ0FBaUM7b0JBQ2pDLHFDQUFxQztvQkFFckMsa0NBQWtDO29CQUNsQyxzQ0FBc0M7b0JBRXRDLDZDQUE2QztvQkFDN0MsbURBQW1EO29CQUNuRCx3Q0FBd0M7b0JBQ3hDLHdDQUF3QztvQkFDeEMscUNBQXFDO29CQUNyQyx3Q0FBd0M7b0JBQ3hDLHdDQUF3QztvQkFDeEMsdUNBQXVDO29CQUV2QywyQ0FBMkM7b0JBQzNDLHdDQUF3QztvQkFDeEMsdUNBQXVDO29CQUN2QywrQ0FBK0M7b0JBQy9DLDRDQUE0QztvQkFDNUMsNENBQTRDO29CQUM1Qyx1Q0FBdUM7b0JBQ3ZDLHdDQUF3QztvQkFDeEMsc0NBQXNDO29CQUN0QyxvQ0FBb0M7b0JBQ3BDLCtDQUErQztvQkFDL0MsMENBQTBDO29CQUMxQyxvREFBb0Q7b0JBRXBELDBDQUEwQztvQkFDMUMsaURBQWlEO29CQUNqRCwwQ0FBMEM7b0JBQzFDLHdDQUF3QztvQkFDeEMsMENBQTBDO29CQUMxQyxvQ0FBb0M7b0JBQ3BDLGdEQUFnRDtvQkFDaEQsMENBQTBDO29CQUMxQyxrREFBa0Q7b0JBQ2xELDhDQUE4QztvQkFDOUMsaURBQWlEO29CQUNqRCwyQ0FBMkM7b0JBQzNDLHFDQUFxQztvQkFDckMsMENBQTBDO29CQUMxQyxzQ0FBc0M7b0JBQ3RDLHFDQUFxQztvQkFFckMsUUFBUTtvQkFDQSxJQUFJO29CQUNKLGVBQWU7b0JBQ2YsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxhQUFhLENBQUMsQ0FBQztvQkFDMUQsRUFBRSxDQUFDLENBQUMsSUFBSSxJQUFJLEVBQUUsSUFBSSxJQUFJLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQzt3QkFDbEMsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQzt3QkFFdkUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7NEJBQ3BCLElBQUksUUFBUSxHQUFHLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQzt3QkFDOUMsSUFBSSxDQUFDLGdCQUFnQixHQUFHOzRCQUM1QixRQUFRLEVBQUUsUUFBUTs0QkFDbEIsUUFBUSxFQUFFLFFBQVE7NEJBQ2xCLE9BQU8sRUFBRSxPQUFPOzRCQUNoQixJQUFJLEVBQUUsSUFBSTs0QkFDVixVQUFVLEVBQUUsVUFBVTt5QkFDekIsQ0FBQTt3QkFHRCxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQzt3QkFDdEIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFOytCQUNuSSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUU7K0JBQ3RJLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzs0QkFDekksSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsRUFBRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEVBQUUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUNuTCxVQUFBLElBQUk7Z0NBQ0EsSUFBSSxHQUFHLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0NBQ2pDLFdBQVc7Z0NBQ1gsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssSUFBSSxTQUFTLElBQUksR0FBRyxDQUFDLEtBQUssSUFBSSxJQUFJLElBQUksR0FBRyxDQUFDLEtBQUssSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO29DQUNqRSxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7d0NBQ2xCLE9BQU8sQ0FBQyxLQUFLLENBQUM7NENBQ1YsT0FBTyxFQUFFLEdBQUcsQ0FBQyxLQUFLOzRDQUNsQixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7NENBQzVCLE9BQU8sRUFBRTtnREFDTCxFQUFFLEVBQUU7b0RBQ0EsY0FBYztvREFDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7aURBQzVCOzZDQUNKO3lDQUNKLENBQUMsQ0FBQztvQ0FDUCxDQUFDO2dDQUNMLENBQUM7Z0NBQ0QsSUFBSSxDQUFDLENBQUM7b0NBQ0YsS0FBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7b0NBQ3RCLEtBQUksQ0FBQyxTQUFTLEdBQUcsR0FBRyxDQUFDO29DQUNyQixjQUFjLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQTtvQ0FDOUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxvQkFBb0IsRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7b0NBQy9FLGNBQWMsQ0FBQyxPQUFPLENBQUMsaUJBQWlCLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO29DQUU1RSwyQkFBMkI7b0NBRTNCLEtBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7b0NBQzlELFlBQVksQ0FBQyxPQUFPLENBQUMsWUFBWSxFQUFFLEtBQUksQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7b0NBQzlELGtFQUFrRTtvQ0FDbEUsRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLElBQUksWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsSUFBSSxTQUFTLElBQUksWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO3dDQUMxSCxZQUFZLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQztvQ0FDdkMsQ0FBQztvQ0FDRCx3REFBd0Q7b0NBQ3hELGFBQWE7b0NBQ2IsNkNBQTZDO29DQUM3QyxFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxDQUFDLElBQUksSUFBSSxJQUFJLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLENBQUMsSUFBSSxNQUFNLENBQUMsQ0FBQyxDQUFDO3dDQUUvRixJQUFJLElBQUksR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO3dDQUN4QyxjQUFjO3dDQUNkLDJEQUEyRDt3Q0FDM0QsS0FBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxhQUFhLEVBQUUsSUFBSSxFQUFFLEVBQUUsQ0FBQyxDQUFDO3dDQUN6RCxLQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSxLQUFJLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7d0NBQ25GLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsVUFBVSxFQUFFLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQzt3Q0FDbkYsS0FBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxTQUFTLEVBQUUsS0FBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO3dDQUNqRixLQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLFlBQVksRUFBRSxLQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7d0NBQ3ZGLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLElBQUksRUFBRSxFQUFFLENBQUMsQ0FBQztvQ0FDdEQsQ0FBQztnQ0FDTCxDQUFDOzRCQUVMLENBQUMsRUFFRCxVQUFBLEtBQUssSUFBSSxPQUFBLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEVBQXBCLENBQW9CLEVBQzdCOzRCQUVBLENBQUMsQ0FDSixDQUFBO3dCQUNMLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO2dDQUN6SSx1Q0FBdUM7Z0NBQ3ZDLE9BQU8sQ0FBQyxLQUFLLENBQUM7b0NBQ1YsT0FBTyxFQUFFLDZCQUE2QjtvQ0FDdEMsU0FBUyxFQUFFLElBQUksQ0FBQyxZQUFZO29DQUM1QixPQUFPLEVBQUU7d0NBQ0wsRUFBRSxFQUFFOzRDQUNBLGNBQWM7NENBQ2QsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO3lDQUM1QjtxQ0FDSjtpQ0FDSixDQUFDLENBQUM7NEJBQ1AsQ0FBQzs0QkFDRCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0NBQ3pJLHVDQUF1QztnQ0FDdkMsT0FBTyxDQUFDLEtBQUssQ0FBQztvQ0FDVixPQUFPLEVBQUUsNkJBQTZCO29DQUN0QyxTQUFTLEVBQUUsSUFBSSxDQUFDLFlBQVk7b0NBQzVCLE9BQU8sRUFBRTt3Q0FDTCxFQUFFLEVBQUU7NENBQ0EsY0FBYzs0Q0FDZCxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVM7eUNBQzVCO3FDQUNKO2lDQUNKLENBQUMsQ0FBQzs0QkFDUCxDQUFDOzRCQUNELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQztnQ0FDdEksMkNBQTJDO2dDQUMzQyxPQUFPLENBQUMsS0FBSyxDQUFDO29DQUNWLE9BQU8sRUFBRSw2QkFBNkI7b0NBQ3RDLFNBQVMsRUFBRSxJQUFJLENBQUMsWUFBWTtvQ0FDNUIsT0FBTyxFQUFFO3dDQUNMLEVBQUUsRUFBRTs0Q0FDQSxjQUFjOzRDQUNkLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUzt5Q0FDNUI7cUNBQ0o7aUNBQ0osQ0FBQyxDQUFDOzRCQUNQLENBQUM7d0JBQ0wsQ0FBQztvQkFHTCxDQUFDO29CQUNELDhDQUE4QztvQkFDOUMsbUVBQW1FO29CQUNuRSxvQkFBb0I7b0JBQ3BCLG1DQUFtQztvQkFDbkMsNEVBQTRFO29CQUM1RSxpQ0FBaUM7b0JBQ2pDLGVBQWU7b0JBQ2YsZ0VBQWdFO29CQUNoRSxtQkFBbUI7b0JBQ25CLHlEQUF5RDtvQkFDekQsY0FBYztvQkFDZCxXQUFXO29CQUNYLGtFQUFrRTtvQkFDbEUsU0FBUztvQkFDVCxtRUFBbUU7b0JBQ25FLElBQUk7Z0JBQ1IsQ0FBQztnQkF4b0JMO29CQUFDLGdCQUFTLENBQUM7d0JBQ1AsUUFBUSxFQUFFLFFBQVE7d0JBQ2xCLFFBQVEsRUFBRSw0Y0FhWjt3QkFDRSxVQUFVLEVBQUUsQ0FBQyx1Q0FBa0IsRUFBRSx1Q0FBa0IsRUFBRSw0QkFBbUIsRUFBRSx1Q0FBa0IsQ0FBQzt3QkFDN0YsU0FBUyxFQUFFLENBQUMseUJBQVcsRUFBRSxpQ0FBZSxDQUFDO3FCQUM1QyxDQUFDO29CQUVELG9CQUFXLENBQUM7d0JBQ1QsRUFBRSxJQUFJLEVBQUMsUUFBUSxFQUFxQixJQUFJLEVBQUMsYUFBYSxFQUFjLFNBQVMsRUFBQyxzQkFBYyxFQUFFO3dCQUM5RixFQUFFLElBQUksRUFBQyxVQUFVLEVBQW1CLElBQUksRUFBQyxlQUFlLEVBQVksU0FBUyxFQUFDLDBCQUFnQixFQUFFO3dCQUVoRyxpQkFBaUI7d0JBQ2pCLEVBQUUsSUFBSSxFQUFDLFNBQVMsRUFBb0IsSUFBSSxFQUFDLFNBQVMsRUFBa0IsU0FBUyxFQUFFLHdCQUFVLEVBQUU7d0JBRTNGLGVBQWU7d0JBQ2Ysc0RBQXNEO3dCQUN0RCxFQUFFLElBQUksRUFBQyxZQUFZLEVBQWlCLElBQUksRUFBQyxPQUFPLEVBQW9CLFNBQVMsRUFBQyxxQkFBUyxFQUFFO3dCQUV6RiwwQkFBMEI7d0JBQzFCLEVBQUUsSUFBSSxFQUFDLG1CQUFtQixFQUFVLElBQUksRUFBQyxTQUFTLEVBQWtCLFNBQVMsRUFBRSw2QkFBbUIsRUFBRTt3QkFDcEcsRUFBRSxJQUFJLEVBQUMsb0JBQW9CLEVBQVMsSUFBSSxFQUFDLFVBQVUsRUFBaUIsU0FBUyxFQUFFLCtCQUFvQixFQUFFO3dCQUdyRyxnQkFBZ0I7d0JBQ2YsRUFBRSxJQUFJLEVBQUMsTUFBTSxFQUF1QixJQUFJLEVBQUMsS0FBSyxFQUFzQixTQUFTLEVBQUUsc0JBQWdCLEVBQUM7d0JBR2pHLEVBQUUsSUFBSSxFQUFDLFFBQVEsRUFBcUIsSUFBSSxFQUFDLE9BQU8sRUFBb0IsU0FBUyxFQUFFLDRCQUFtQixFQUFDO3dCQUV0RyxrQkFBa0I7d0JBQ2YsRUFBRSxJQUFJLEVBQUUsbUJBQW1CLEVBQUUsSUFBSSxFQUFFLGFBQWEsRUFBRSxTQUFTLEVBQUUsMkJBQWEsRUFBRTt3QkFFNUUsa0JBQWtCO3dCQUNsQixFQUFFLElBQUksRUFBRSwrQ0FBK0MsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUUsU0FBUyxFQUFFLG9DQUFtQixFQUFFO3dCQUVqSCxjQUFjO3dCQUNkLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFLElBQUksRUFBRSxhQUFhLEVBQUUsU0FBUyxFQUFFLHFCQUFXLEVBQUU7d0JBRXpFLEVBQUUsSUFBSSxFQUFFLDBCQUEwQixFQUFFLElBQUksRUFBRSxpQkFBaUIsRUFBRSxTQUFTLEVBQUUscUNBQW1CLEVBQUU7d0JBRTdGLEVBQUUsSUFBSSxFQUFFLDJCQUEyQixFQUFFLElBQUksRUFBRSxVQUFVLEVBQUUsU0FBUyxFQUFFLHVCQUFZLEVBQUU7d0JBQ2hGLEVBQUUsSUFBSSxFQUFFLHFCQUFxQixFQUFFLElBQUksRUFBRSxlQUFlLEVBQUUsU0FBUyxFQUFFLGlDQUFpQixFQUFFO3dCQUNwRixXQUFXO3dCQUNYLEVBQUUsSUFBSSxFQUFFLHFCQUFxQixFQUFFLElBQUksRUFBRSxXQUFXLEVBQUUsU0FBUyxFQUFFLHlCQUFhLEVBQUU7d0JBQzVFLGNBQWM7d0JBQ2QsRUFBRSxJQUFJLEVBQUUsMkJBQTJCLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFLFNBQVMsRUFBRSxtQ0FBZ0IsRUFBRTt3QkFDNUYsY0FBYzt3QkFDZCxFQUFFLElBQUksRUFBRSw0QkFBNEIsRUFBRSxJQUFJLEVBQUUsZUFBZSxFQUFFLFNBQVMsRUFBRSxpQ0FBaUIsRUFBRTt3QkFDM0YsY0FBYzt3QkFDZCxFQUFFLElBQUksRUFBRSxtQ0FBbUMsRUFBRSxJQUFJLEVBQUUsZUFBZSxFQUFFLFNBQVMsRUFBRSxpQ0FBaUIsRUFBRTt3QkFDbEcsZ0JBQWdCO3dCQUNoQixFQUFFLElBQUksRUFBRSwrQkFBK0IsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUUsU0FBUyxFQUFFLG1DQUFrQixFQUFFO3FCQUNuRyxDQUFDOztvQ0FBQTtnQkF3a0JGLHVCQUFDO1lBQUQsQ0F0a0JBLEFBc2tCQyxJQUFBO1lBdGtCRCwrQ0Fza0JDLENBQUEiLCJmaWxlIjoiYW1heEFwcC5jb21wb25lbnQuanMiLCJzb3VyY2VzQ29udGVudCI6WyIvLy88cmVmZXJlbmNlIHBhdGg9XCJzZXJ2aWNlcy9BbWF4U2VydmljZS50c1wiLz5cclxuaW1wb3J0IHsgQ29tcG9uZW50LCBPbkluaXQgfSBmcm9tICdhbmd1bGFyMi9jb3JlJztcclxuaW1wb3J0IHsgQW1heENybVVJQ29tcG9uZW50IH0gZnJvbSAnLi9hbWF4Q29tcG9uZW50cy9hbWF4Q3JtVUlDb21wb25lbnQnO1xyXG5pbXBvcnQgeyBBbWF4TG9naW5Db21wb25lbnQgfSBmcm9tICcuL2FtYXhDb21wb25lbnRzL2FtYXhMb2dpbkNvbXBvbmVudCc7XHJcbmltcG9ydCB7IEFtYXhTZXJ2aWNlIH0gZnJvbSAnLi9zZXJ2aWNlcy9BbWF4U2VydmljZSc7XHJcbmltcG9ydCB7UmVzb3VyY2VTZXJ2aWNlfSBmcm9tIFwiLi9zZXJ2aWNlcy9SZXNvdXJjZVNlcnZpY2VcIjtcclxuaW1wb3J0IHtpbmRleENvbXBvbmVudH0gZnJvbSBcIi4vYW1heC9xdWlja2FjY2Vzcy9pbmRleFwiO1xyXG5pbXBvcnQge2RlZmF1bHRDb21wb25lbnR9IGZyb20gXCIuL2FtYXgvcXVpY2thY2Nlc3MvZGVmYXVsdFwiO1xyXG5pbXBvcnQge1JvdXRlQ29uZmlnfSBmcm9tIFwiYW5ndWxhcjIvcm91dGVyXCI7XHJcbmltcG9ydCB7QW1heExvZ291dENvbXBvbmVudH0gZnJvbSBcIi4vYW1heC9sb2dvdXRcIjtcclxuaW1wb3J0IHtBbWF4UmVwb3J0fSBmcm9tIFwiLi9hbWF4L3JlcG9ydHMvYW1heFJlcG9ydHNcIjtcclxuaW1wb3J0IHtBbWF4Rm9ybXN9IGZyb20gXCIuL2FtYXgvZm9ybXMvYW1heEZvcm1zXCI7XHJcbmltcG9ydCB7T2JzZXJ2YWJsZX0gZnJvbSBcInJ4anMvT2JzZXJ2YWJsZVwiO1xyXG5pbXBvcnQge0FtYXhFbXBsb3llZVByb2ZpbGV9IGZyb20gXCIuL2FtYXgvZW1wbG95ZWUvcHJvZmlsZVwiO1xyXG5pbXBvcnQge0FtYXhFbXBsb3llZVNldHRpbmdzfSBmcm9tIFwiLi9hbWF4L2VtcGxveWVlL3NldHRpbmdzXCI7XHJcbmltcG9ydCB7QW1heFNtc0NvbXBvbmVudH0gZnJvbSBcIi4vYW1heC9zbXNcIjtcclxuaW1wb3J0IHtBbWF4Q3VzdG9tZXJzfSBmcm9tIFwiLi9hbWF4L0N1c3RvbWVyL2FkZEN1c3RvbWVyXCI7XHJcblxyXG5pbXBvcnQge0FtYXhTZWFyY2hDdXN0b21lcnN9IGZyb20gXCIuL2FtYXgvQ3VzdG9tZXIvU2VhcmNoQ3VzdG9tZXJcIjtcclxuXHJcbmltcG9ydCB7QW1heFJlY2llcHR9IGZyb20gXCIuL2FtYXgvUmVjaWVwdFR5cGUvUmVjaWVwdFwiO1xyXG5pbXBvcnQge0FtYXhSZWNpZXB0VGVtcGxhdGV9IGZyb20gXCIuL2FtYXgvUmVjaWVwdFR5cGUvUmVjaWVwdFRlbXBsYXRlXCI7XHJcbmltcG9ydCB7QW1heFRlbXBsYXRlfSBmcm9tIFwiLi9hbWF4L1JlY2llcHRUeXBlL1RlbXBsYXRlXCI7XHJcbmltcG9ydCB7QW1heEdlbmVyYWxHcm91cHN9IGZyb20gXCIuL2FtYXgvR2VuZXJhbEdyb3Vwcy9HZW5lcmFsR3JvdXBzXCI7XHJcbmltcG9ydCB7QW1heFRlcm1pbmFsc30gZnJvbSBcIi4vYW1heC9DaGFyZ2VfQ3JlZGl0L1Rlcm1pbmFsc1wiO1xyXG5pbXBvcnQge0FtYXhDaGFyZ2VDcmVkaXR9IGZyb20gXCIuL2FtYXgvQ2hhcmdlX0NyZWRpdC9DaGFyZ2VDcmVkaXRDYXJkXCI7XHJcbmltcG9ydCB7QW1heFJlY2VpcHRTZWxlY3R9IGZyb20gXCIuL2FtYXgvUmVjZWlwdC9SZWNlaXB0U2VsZWN0XCI7XHJcbmltcG9ydCB7QW1heFJlY2VpcHRDcmVhdGV9IGZyb20gXCIuL2FtYXgvUmVjZWlwdC9SZWNlaXB0Q3JlYXRlXCI7XHJcbmltcG9ydCB7QW1heFNlYXJjaFByb2R1Y3RzfSBmcm9tIFwiLi9hbWF4L1JlY2VpcHQvU2VhcmNoUHJvZHVjdHNcIjtcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdteC1hcHAnLFxyXG4gICAgdGVtcGxhdGU6IGBcclxuICAgICAgICA8ZGl2IGRpcj1cInt7IFJFUy5BUFBfRElSIH19XCI+XHJcbiAgICAgICAgICAgIDxteC1sb2dpblxyXG4gICAgICAgICAgICAgICAgKm5nSWY9XCIhSXNMb2dlZEluXCJcclxuICAgICAgICAgICAgICAgIFsocmVzKV09XCJSRVMuU0NSRUVOX0xPR0lOXCJcclxuICAgICAgICAgICAgICAgIFtkYXRhTW9kZWxdPVwiX3VzZXJNb2RlbFwiIFxyXG4gICAgICAgICAgICAgICAgKG9uZGF0YSk9XCJ2YWxpZGF0ZVVzZXIoJGV2ZW50KVwiIFxyXG4gICAgICAgICAgICAgICAgKG9ubGFuZ3VhZ2UpPVwiY2hhbmdlTGFuZ3VhZ2UoJGV2ZW50KVwiXHJcbiAgICAgICAgICAgID48L214LWxvZ2luPlxyXG4gICAgICAgICAgICA8ZGl2ICpuZ0lmPVwiSXNMb2dlZEluXCIgY2xhc3M9XCJuby1za2luXCI+XHJcbiAgICAgICAgICAgICAgICA8bXgtdWk+PC9teC11aT5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblx0YCxcclxuICAgIGRpcmVjdGl2ZXM6IFtBbWF4TG9naW5Db21wb25lbnQsIEFtYXhDcm1VSUNvbXBvbmVudCwgQW1heExvZ291dENvbXBvbmVudCwgQW1heExvZ2luQ29tcG9uZW50XSxcclxuICAgIHByb3ZpZGVyczogW0FtYXhTZXJ2aWNlLCBSZXNvdXJjZVNlcnZpY2VdXHJcbn0pXHJcblxyXG5AUm91dGVDb25maWcoW1xyXG4gICAgeyBwYXRoOlwiL2luZGV4XCIsICAgICAgICAgICAgICAgICAgICBuYW1lOlwiSW5kZXhSb3V0ZXJcIiwgICAgICAgICAgICAgY29tcG9uZW50OmluZGV4Q29tcG9uZW50IH0sXHJcbiAgICB7IHBhdGg6XCIvZGVmYXVsdFwiLCAgICAgICAgICAgICAgICAgIG5hbWU6XCJEZWZhdWx0Um91dGVyXCIsICAgICAgICAgICBjb21wb25lbnQ6ZGVmYXVsdENvbXBvbmVudCB9LFxyXG5cclxuICAgIC8vUmVwb3J0cyBSb3V0aW5nXHJcbiAgICB7IHBhdGg6XCIvcmVwb3J0XCIsICAgICAgICAgICAgICAgICAgIG5hbWU6XCJSZXBvcnRzXCIsICAgICAgICAgICAgICAgICBjb21wb25lbnQ6IEFtYXhSZXBvcnQgfSxcclxuXHJcbiAgICAvL0Zvcm1zIHJvdXRpbmdcclxuICAgIC8veyBwYXRoOlwiL2Zvcm1cIiwgbmFtZTpcIkZvcm1zXCIsIGNvbXBvbmVudDpBbWF4Rm9ybXMgfSxcclxuICAgIHsgcGF0aDpcIi9mb3JtLzpmcm1cIiwgICAgICAgICAgICAgICAgbmFtZTpcIkZvcm1zXCIsICAgICAgICAgICAgICAgICAgIGNvbXBvbmVudDpBbWF4Rm9ybXMgfSxcclxuXHJcbiAgICAvL0VtcGxveWVlIHJlbGF0ZWQgcm91dGluZ1xyXG4gICAgeyBwYXRoOlwiL2VtcGxveWVlL3Byb2ZpbGVcIiwgICAgICAgICBuYW1lOlwiUHJvZmlsZVwiLCAgICAgICAgICAgICAgICAgY29tcG9uZW50OiBBbWF4RW1wbG95ZWVQcm9maWxlIH0sXHJcbiAgICB7IHBhdGg6XCIvZW1wbG95ZWUvc2V0dGluZ3NcIiwgICAgICAgIG5hbWU6XCJTZXR0aW5nc1wiLCAgICAgICAgICAgICAgICBjb21wb25lbnQ6IEFtYXhFbXBsb3llZVNldHRpbmdzIH0sXHJcblxyXG5cclxuICAgIC8vTW9kdWxlIFJvdXRpbmdcclxuICAgICB7IHBhdGg6XCIvc21zXCIsICAgICAgICAgICAgICAgICAgICAgIG5hbWU6XCJTbXNcIiwgICAgICAgICAgICAgICAgICAgICBjb21wb25lbnQ6IEFtYXhTbXNDb21wb25lbnR9LFxyXG5cclxuXHJcbiAgICB7IHBhdGg6XCIvYmxhbmtcIiwgICAgICAgICAgICAgICAgICAgIG5hbWU6XCJCbGFua1wiLCAgICAgICAgICAgICAgICAgICBjb21wb25lbnQ6IEFtYXhMb2dvdXRDb21wb25lbnR9LCAvL2ZvciB0aGUgdGVzdGluZ1xyXG5cdFxyXG5cdC8vQ3VzdG9tZXIgUm91dGluZ1xyXG4gICAgeyBwYXRoOiBcIi9DdXN0b21lci9BZGQvOklkXCIsIG5hbWU6IFwiQWRkQ3VzdG9tZXJcIiwgY29tcG9uZW50OiBBbWF4Q3VzdG9tZXJzIH0sXHJcblxyXG4gICAgLy9DdXN0b21lciBSb3V0aW5nXHJcbiAgICB7IHBhdGg6IFwiL0N1c3RvbWVyL1NlYXJjaC86Rm9yUG9wdXAvOkZyb21QYWdlLzpGb3JCYWNrXCIsIG5hbWU6IFwiU2VhcmNoQ3VzdG9tZXJcIiwgY29tcG9uZW50OiBBbWF4U2VhcmNoQ3VzdG9tZXJzIH0sXHJcblxyXG4gICAgLy9SZWNpZXB0IFR5cGVcclxuICAgIHsgcGF0aDogXCIvUmVjZWlwdFR5cGUvOklkXCIsIG5hbWU6IFwiUmVjZWlwdFR5cGVcIiwgY29tcG9uZW50OiBBbWF4UmVjaWVwdCB9LFxyXG5cclxuICAgIHsgcGF0aDogXCIvUmVjZWlwdFRlbXBsYXRlL0FkZC86SWRcIiwgbmFtZTogXCJSZWNpZXB0VGVtcGxhdGVcIiwgY29tcG9uZW50OiBBbWF4UmVjaWVwdFRlbXBsYXRlIH0sXHJcbiAgICBcclxuICAgIHsgcGF0aDogXCIvVGVtcGxhdGUvRWRpdC86SWQvOkZQYWdlXCIsIG5hbWU6IFwiVGVtcGxhdGVcIiwgY29tcG9uZW50OiBBbWF4VGVtcGxhdGUgfSxcclxuICAgIHsgcGF0aDogXCIvR2VuZXJhbEdyb3Vwcy9WaWV3XCIsIG5hbWU6IFwiR2VuZXJhbEdyb3Vwc1wiLCBjb21wb25lbnQ6IEFtYXhHZW5lcmFsR3JvdXBzIH0sXHJcbiAgICAvL1RlbXBsYXRlc1xyXG4gICAgeyBwYXRoOiBcIi9UZXJtaW5hbHMvU2hvdy86SWRcIiwgbmFtZTogXCJUZXJtaW5hbHNcIiwgY29tcG9uZW50OiBBbWF4VGVybWluYWxzIH0sXHJcbiAgICAvL0NoYXJnZUNyZWRpdFxyXG4gICAgeyBwYXRoOiBcIi9DaGFyZ2VDcmVkaXQvOklkLzpUZXJtTm9cIiwgbmFtZTogXCJDaGFyZ2VDcmVkaXRDYXJkXCIsIGNvbXBvbmVudDogQW1heENoYXJnZUNyZWRpdCB9LFxyXG4gICAgLy9DaGFyZ2VDcmVkaXRcclxuICAgIHsgcGF0aDogXCIvUmVjZWlwdFNlbGVjdC86SWQvOkN1c3RJZFwiLCBuYW1lOiBcIlJlY2VpcHRTZWxlY3RcIiwgY29tcG9uZW50OiBBbWF4UmVjZWlwdFNlbGVjdCB9LFxyXG4gICAgLy9DaGFyZ2VDcmVkaXRcclxuICAgIHsgcGF0aDogXCIvUmVjZWlwdENyZWF0ZS86SWQvOlJlY2VpcHRUeXBlSWRcIiwgbmFtZTogXCJSZWNlaXB0Q3JlYXRlXCIsIGNvbXBvbmVudDogQW1heFJlY2VpcHRDcmVhdGUgfSxcclxuICAgIC8vUHJvZHVjdCBTZWFyY2hcclxuICAgIHsgcGF0aDogXCIvU2VhcmNoUHJvZHVjdHMvOklkLzpGcm9tUGFnZVwiLCBuYW1lOiBcIlNlYXJjaFByb2R1Y3RzXCIsIGNvbXBvbmVudDogQW1heFNlYXJjaFByb2R1Y3RzIH1cclxuXSlcclxuXHJcbmV4cG9ydCBjbGFzcyBBbWF4QXBwQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcclxuICAgIEZvcm1UeXBlRm9ybTogc3RyaW5nID0gXCJTQ1JFRU5fTE9HSU5cIjtcclxuICAgIGJhc2VVcmw6IHN0cmluZztcclxuICAgIENoYW5nZURpYWxvZzogc3RyaW5nID0gXCJcIjtcclxuICAgIENIQU5HRURJUjogc3RyaW5nID0gXCJcIjtcclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgX2FtYXhTc2VydmljZTogQW1heFNlcnZpY2UsIHByaXZhdGUgX2xhbmd1YWdlU2VydmljZTogUmVzb3VyY2VTZXJ2aWNlKSB7XHJcbiAgICAgICAgLy9Mb2FkaW5nIHRoZSBsYW5ndWFnZSByZXNvdXJjZVxyXG4gICAgICAgIHRoaXMuUkVTLlNDUkVFTl9MT0dJTiA9IHt9O1xyXG4gICAgICAgIHRoaXMuRm9ybVR5cGVGb3JtID0gXCJTQ1JFRU5fTE9HSU5cIjtcclxuICAgICAgICB0aGlzLmJhc2VVcmwgPSB0aGlzLl9sYW5ndWFnZVNlcnZpY2UuQXBwVXJsO1xyXG4gICAgICAgIFxyXG4gICAgfVxyXG4gICAgSXNMb2dlZEluOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwdWJsaWMgTG9naW5EYXRhOiBPYmplY3Q7XHJcbiAgICBwdWJsaWMgUkVTOiBPYmplY3QgPSB7fTtcclxuICAgICAgICBcclxuXHJcbiAgICBsb2FkVXNlckluZm9ybWF0aW9uKCkge1xyXG4gICAgICAgIGlmIChzZXNzaW9uU3RvcmFnZS5nZXRJdGVtKCd1c2VySW5mb3JtYXRpb24nKSAhPSBudWxsKSB7XHJcbiAgICAgICAgICAgIHRoaXMuTG9naW5EYXRhID0gSlNPTi5wYXJzZShzZXNzaW9uU3RvcmFnZS5nZXRJdGVtKCd1c2VySW5mb3JtYXRpb24nKSk7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLkxvZ2luRGF0YSkgdGhpcy5Jc0xvZ2VkSW4gPSB0cnVlO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgZ2V0bGFuZ3JlcyhsYW5nY29kZSkge1xyXG4gICAgICAgdGhpcy5fbGFuZ3VhZ2VTZXJ2aWNlLkdldExhbmdSZXModGhpcy5Gb3JtVHlwZUZvcm0sIGxhbmdjb2RlKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICAgICByZXNwb25zZSA9ICQucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgIC8vYWxlcnQocmVzcG9uc2UuRXJyTXNnKTtcclxuICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgIH1cclxuICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwibGFuZ3Jlc291cmNlXCIsIEpTT04uc3RyaW5naWZ5KHJlc3BvbnNlLkRhdGEpKTtcclxuICAgICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJsYW5nXCIsIGxhbmdjb2RlKTtcclxuICAgICAgICAgICAgICAgdGhpcy5SRVMgPSByZXNwb25zZS5EYXRhO1xyXG5cclxuICAgICAgICAgICB9XHJcbiAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICB9KTtcclxuICAgfVxyXG52YWxpZGF0ZUxvZ2luKCkge1xyXG4gICAgLy90aGlzLklzTG9nZWRJbiA9IHRydWU7IFxyXG4gICAgaWYgKHRoaXMuX3VzZXJNb2RlbFtcInVzZXJOYW1lXCJdICE9IHVuZGVmaW5lZCAmJiB0aGlzLl91c2VyTW9kZWxbXCJ1c2VyTmFtZVwiXSAhPSBudWxsICYmIHRoaXMuX3VzZXJNb2RlbFtcInVzZXJOYW1lXCJdICE9IFwiXCJcclxuICAgICAgICAmJiB0aGlzLl91c2VyTW9kZWxbXCJwYXNzd29yZFwiXSAhPSB1bmRlZmluZWQgJiYgdGhpcy5fdXNlck1vZGVsW1wicGFzc3dvcmRcIl0gIT0gbnVsbCAmJiB0aGlzLl91c2VyTW9kZWxbXCJwYXNzd29yZFwiXSAhPSBcIlwiXHJcbiAgICAgICAgJiYgdGhpcy5fdXNlck1vZGVsW1wib3JnTmFtZVwiXSAhPSB1bmRlZmluZWQgJiYgdGhpcy5fdXNlck1vZGVsW1wib3JnTmFtZVwiXSAhPSBudWxsICYmIHRoaXMuX3VzZXJNb2RlbFtcIm9yZ05hbWVcIl0gIT0gXCJcIikge1xyXG4gICAgICAgIHRoaXMuX2FtYXhTc2VydmljZS52YWxpZGF0ZUxvZ2luKHRoaXMuX3VzZXJNb2RlbFtcInVzZXJOYW1lXCJdLCB0aGlzLl91c2VyTW9kZWxbXCJwYXNzd29yZFwiXSwgdGhpcy5fdXNlck1vZGVsW1wib3JnTmFtZVwiXSwgdGhpcy5fdXNlck1vZGVsW1wicmVtZW1iZXJNZVwiXSkuc3Vic2NyaWJlKFxyXG4gICAgICAgICAgICBkYXRhID0+IHtcclxuICAgICAgICAgICAgICAgIHZhciBkdGEgPSAkLnBhcnNlSlNPTihkYXRhKS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgIGlmIChkdGEuZXJyb3IgIT0gdW5kZWZpbmVkICYmIGR0YS5lcnJvciAhPSBudWxsICYmIGR0YS5lcnJvciAhPSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGR0YS5lcnJvciAhPSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vYWxlcnQoZHRhLmVycm9yKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7IG1lc3NhZ2U6IGR0YS5lcnJvcixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLklzTG9nZWRJbiA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5Mb2dpbkRhdGEgPSBkdGE7XHJcbiAgICAgICAgICAgICAgICAgICAgc2Vzc2lvblN0b3JhZ2Uuc2V0SXRlbSgnWFRva2VuJywgZHRhW1widG9rZW5cIl0pXHJcbiAgICAgICAgICAgICAgICAgICAgc2Vzc2lvblN0b3JhZ2Uuc2V0SXRlbSgnc2Vzc2lvbkluZm9ybWF0aW9uJywgYXRvYihkdGFbXCJ0b2tlblwiXS5zcGxpdCgnLicpWzBdKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgc2Vzc2lvblN0b3JhZ2Uuc2V0SXRlbSgndXNlckluZm9ybWF0aW9uJywgYXRvYihkdGFbXCJ0b2tlblwiXS5zcGxpdCgnLicpWzFdKSk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIC8vRmVhdGNoaW5nIFVzZXJpbmZvcm1hdGlvblxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5Mb2dpbkRhdGEgPSBKU09OLnBhcnNlKGF0b2IoZHRhW1widG9rZW5cIl0uc3BsaXQoJy4nKVsxXSkpO1xyXG4gICAgICAgICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwiZW1wbG95ZWVpZFwiLCB0aGlzLkxvZ2luRGF0YS5lbXBsb3llZWlkKTtcclxuICAgICAgICAgICAgICAgICAgICAvL2xvY2FsU3RvcmFnZS5zZXRJdGVtKFwiT3JnSWRcIiwgdGhpcy5fdXNlck1vZGVsW1wib3JnTmFtZVwiXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwibGFuZ1wiKSA9PSBcIlwiIHx8IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwibGFuZ1wiKSA9PSB1bmRlZmluZWQgfHwgbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJsYW5nXCIpID09IG51bGwpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJsYW5nXCIsIFwiZW5cIik7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8vYWxlcnQodGhpcy5fdXNlck1vZGVsW1wicmVtZW1iZXJNZVwiXS50b1N0cmluZygpKTtcclxuICAgICAgICAgICAgICAgICAgICAvLyAgZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9hbGVydCh0aGlzLl91c2VyTW9kZWxbXCJyZW1lbWJlck1lXCJdKTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5fdXNlck1vZGVsW1wicmVtZW1iZXJNZVwiXSA9PSB0cnVlIHx8IHRoaXMuX3VzZXJNb2RlbFtcInJlbWVtYmVyTWVcIl0gPT0gXCJ0cnVlXCIpIHtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBsYW5nID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJsYW5nXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2FsZXJ0KGxhbmcpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL3RoaXMuX2xhbmd1YWdlU2VydmljZS5zZXRDb29raWUoXCJsYW5ncmVzb3VyY2VcIiwgbGFuZywxMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2xhbmd1YWdlU2VydmljZS5zZXRDb29raWUoXCJSZW1lbWJlcktleVwiLCBkYXRhLCAxMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2xhbmd1YWdlU2VydmljZS5zZXRDb29raWUoXCJVc2VyTmFtZVwiLCB0aGlzLl91c2VyTW9kZWxbXCJ1c2VyTmFtZVwiXSwgMTApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9sYW5ndWFnZVNlcnZpY2Uuc2V0Q29va2llKFwicGFzc3dvcmRcIiwgdGhpcy5fdXNlck1vZGVsW1wicGFzc3dvcmRcIl0sIDEwKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fbGFuZ3VhZ2VTZXJ2aWNlLnNldENvb2tpZShcIm9yZ05hbWVcIiwgdGhpcy5fdXNlck1vZGVsW1wib3JnTmFtZVwiXSwgMTApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9sYW5ndWFnZVNlcnZpY2Uuc2V0Q29va2llKFwicmVtZW1iZXJNZVwiLCB0aGlzLl91c2VyTW9kZWxbXCJyZW1lbWJlck1lXCJdLCAxMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2xhbmd1YWdlU2VydmljZS5zZXRDb29raWUoXCJsYW5nXCIsIGxhbmcsIDEwKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgZXJyb3IgPT4gY29uc29sZS5lcnJvcihlcnJvciksXHJcbiAgICAgICAgICAgICgpID0+IHtcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgKVxyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgICAgaWYgKHRoaXMuX3VzZXJNb2RlbFtcInVzZXJOYW1lXCJdID09IHVuZGVmaW5lZCAmJiB0aGlzLl91c2VyTW9kZWxbXCJ1c2VyTmFtZVwiXSA9PSBudWxsIHx8IHRoaXMuX3VzZXJNb2RlbFtcInVzZXJOYW1lXCJdID09IFwiXCIpIHtcclxuICAgICAgICAgICAgLy9hbGVydChcIlBsZWFzZSBlbnRlciB2YWxpZCB1c2VybmFtZVwiKTtcclxuICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICBtZXNzYWdlOiBcIlBsZWFzZSBlbnRlciB2YWxpZCB1c2VybmFtZVwiLFxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHRoaXMuX3VzZXJNb2RlbFtcInBhc3N3b3JkXCJdID09IHVuZGVmaW5lZCAmJiB0aGlzLl91c2VyTW9kZWxbXCJwYXNzd29yZFwiXSA9PSBudWxsIHx8IHRoaXMuX3VzZXJNb2RlbFtcInBhc3N3b3JkXCJdID09IFwiXCIpIHtcclxuICAgICAgICAgICAgLy9hbGVydChcIlBsZWFzZSBlbnRlciB2YWxpZCBwYXNzd29yZFwiKTtcclxuICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICBtZXNzYWdlOiBcIlBsZWFzZSBlbnRlciB2YWxpZCBwYXNzd29yZFwiLFxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHRoaXMuX3VzZXJNb2RlbFtcIm9yZ05hbWVcIl0gPT0gdW5kZWZpbmVkICYmIHRoaXMuX3VzZXJNb2RlbFtcIm9yZ05hbWVcIl0gPT0gbnVsbCB8fCB0aGlzLl91c2VyTW9kZWxbXCJvcmdOYW1lXCJdID09IFwiXCIpIHtcclxuICAgICAgICAgICAgLy9hbGVydChcIlBsZWFzZSBlbnRlciB2YWxpZCBvcmdhbml6YXRpb25cIik7XHJcbiAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgbWVzc2FnZTogXCJQbGVhc2UgZW50ZXIgdmFsaWQgcGFzc3dvcmRcIixcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgfVxyXG5cclxuX3VzZXJNb2RlbCA9IHt9O1xyXG5fTG9nZ2VkdXNlck1vZGVsID0ge307XHJcblxyXG4gICAgdmFsaWRhdGVVc2VyKGV2dCkge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGV2dCk7XHJcbiAgICAgICAgdGhpcy52YWxpZGF0ZUxvZ2luKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGNoYW5nZUxhbmd1YWdlQnlMYW5nSWQoTGFuZ3VhZ2VJZCkge1xyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCJDaGFuZ2luZyBMYW5ndWFnZS4uLlwiKTtcclxuICAgICAgICBpZiAoTGFuZ3VhZ2VJZCkge1xyXG4gICAgICAgICAgICB0aGlzLl9sYW5ndWFnZVNlcnZpY2UuR2V0U2VsZWNldGRMYW5ndWFnZShMYW5ndWFnZUlkKS5zdWJzY3JpYmUoXHJcbiAgICAgICAgICAgICAgICBkYXRhID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImxhbmdyZXNvdXJjZVwiLCBKU09OLnN0cmluZ2lmeShkYXRhKSk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwibGFuZ1wiLCBMYW5ndWFnZUlkKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl91c2VyTW9kZWxbXCJsYW5nXCJdID0gTGFuZ3VhZ2VJZDtcclxuXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgZXJyb3IgPT4gY29uc29sZS5sb2coXCJVbmFibGUgdG8gbG9hZCBMYW5ndWFnZSBEYXRhXCIpLFxyXG4gICAgICAgICAgICAgICAgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiTGFuZ3VhZ2UgcmVzb3VyY2UgbG9hZGVkXCIpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgICAgdGhpcy5fbGFuZ3VhZ2VTZXJ2aWNlLkdldExhbmdSZXModGhpcy5Gb3JtVHlwZUZvcm0sIExhbmd1YWdlSWQpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICByZXNwb25zZSA9ICQucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAvL2FsZXJ0KHJlc3BvbnNlLkVyck1zZyk7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJsYW5ncmVzb3VyY2VcIiwgSlNPTi5zdHJpbmdpZnkocmVzcG9uc2UuRGF0YSkpO1xyXG4gICAgICAgICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwibGFuZ1wiLCBMYW5ndWFnZUlkKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLlJFUyA9IHJlc3BvbnNlLkRhdGE7XHJcblxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgICAgIH0pO1xyXG5cclxuXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiQ29kZSBub3Qgc3BlY2lmaWVkXCIpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcblxyXG4gICAgcHVibGljIGNoYW5nZUxhbmd1YWdlKGV2dCkge1xyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCJDaGFuZ2luZyBMYW5ndWFnZS4uLlwiKTtcclxuICAgICAgICBpZiAoZXZ0LmNvZGUpIHtcclxuICAgICAgICAgICAgdGhpcy5fbGFuZ3VhZ2VTZXJ2aWNlLkdldFNlbGVjZXRkTGFuZ3VhZ2UoZXZ0LmNvZGUpLnN1YnNjcmliZShcclxuICAgICAgICAgICAgICAgIGRhdGEgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwibGFuZ3Jlc291cmNlXCIsIEpTT04uc3RyaW5naWZ5KGRhdGEpKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJsYW5nXCIsIGV2dC5jb2RlKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl91c2VyTW9kZWxbXCJsYW5nXCJdID0gZXZ0LmNvZGU7XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgZXJyb3IgPT4gY29uc29sZS5sb2coXCJVbmFibGUgdG8gbG9hZCBMYW5ndWFnZSBEYXRhXCIpLFxyXG4gICAgICAgICAgICAgICAgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiTGFuZ3VhZ2UgcmVzb3VyY2UgbG9hZGVkXCIpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgICAgdGhpcy5fbGFuZ3VhZ2VTZXJ2aWNlLkdldExhbmdSZXModGhpcy5Gb3JtVHlwZUZvcm0sIGV2dC5jb2RlKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgcmVzcG9uc2UgPSAkLnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9hbGVydChyZXNwb25zZS5FcnJNc2cpO1xyXG4gICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwibGFuZ3Jlc291cmNlXCIsIEpTT04uc3RyaW5naWZ5KHJlc3BvbnNlLkRhdGEpKTtcclxuICAgICAgICAgICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImxhbmdcIiwgZXZ0LmNvZGUpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuUkVTID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgICAgICB9KTtcclxuXHJcblxyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIkNvZGUgbm90IHNwZWNpZmllZFwiKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG5cclxuICAgIG5nT25Jbml0KCkge1xyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcblxyXG4gICAgICAgIHRoaXMuRm9ybVR5cGVGb3JtID0gXCJTQ1JFRU5fTE9HSU5cIjtcclxuXHJcbiAgICAgICAgdmFyIFVzZXJOYW1lID0gdGhpcy5fbGFuZ3VhZ2VTZXJ2aWNlLmdldENvb2tpZShcIlVzZXJOYW1lXCIpO1xyXG4gICAgICAgIC8vYWxlcnQoVXNlck5hbWVbMF0pO1xyXG4gICAgICAgIGlmIChVc2VyTmFtZS5sZW5ndGggPiAwICYmIFVzZXJOYW1lWzBdPT1cIj1cIikgXHJcbiAgICAgICAgICAgIHZhciBVc2VyTmFtZSA9IFVzZXJOYW1lLnN1YnN0cmluZygxLFVzZXJOYW1lLmxlbmd0aCk7XHJcbiAgICAgICAgLy92YXIgcGFzc3dvcmQgPSB0aGlzLl9sYW5ndWFnZVNlcnZpY2UuZ2V0Q29va2llKFwicGFzc3dvcmRcIik7XHJcblxyXG4gICAgICAgIC8vaWYgKHBhc3N3b3JkLmxlbmd0aCA+IDApIFxyXG4gICAgICAgIC8vICAgIHZhciBwYXNzd29yZCA9IHBhc3N3b3JkLnN1YnN0cmluZygxLCBwYXNzd29yZC5sZW5ndGgpO1xyXG4gICAgICAgIHZhciBvcmdOYW1lID0gdGhpcy5fbGFuZ3VhZ2VTZXJ2aWNlLmdldENvb2tpZShcIm9yZ05hbWVcIik7XHJcblxyXG4gICAgICAgIGlmIChvcmdOYW1lLmxlbmd0aCA+IDApIFxyXG4gICAgICAgICAgICB2YXIgb3JnTmFtZSA9IG9yZ05hbWUuc3Vic3RyaW5nKDEsIG9yZ05hbWUubGVuZ3RoKTtcclxuICAgICAgICB2YXIgcmVtZW1iZXJNZSA9IHRoaXMuX2xhbmd1YWdlU2VydmljZS5nZXRDb29raWUoXCJyZW1lbWJlck1lXCIpO1xyXG5cclxuICAgICAgICBpZiAocmVtZW1iZXJNZS5sZW5ndGggPiAwKVxyXG4gICAgICAgICAgICB2YXIgcmVtZW1iZXJNZSA9IHJlbWVtYmVyTWUuc3Vic3RyaW5nKDEsIHJlbWVtYmVyTWUubGVuZ3RoKTtcclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgcmVtZW1iZXJNZSA9IFwidHJ1ZVwiO1xyXG4gICAgICAgIH1cclxuICAgICAgICB2YXIgbGFuZyA9IHRoaXMuX2xhbmd1YWdlU2VydmljZS5nZXRDb29raWUoXCJsYW5nXCIpO1xyXG4gICAgICAgIFxyXG4gICAgICAgIGlmIChsYW5nLmxlbmd0aCA+IDApXHJcbiAgICAgICAgICAgIHZhciBsYW5nID0gbGFuZy5zdWJzdHJpbmcoMSwgbGFuZy5sZW5ndGgpO1xyXG4gICAgICAgIGlmIChsYW5nID09IFwiXCIpXHJcbiAgICAgICAgICAgIGxhbmcgPSBcImVuXCI7XHJcbiAgICAgICBcclxuICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImxhbmdcIiwgbGFuZyk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl91c2VyTW9kZWwgPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdXNlck5hbWU6IFVzZXJOYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgIHBhc3N3b3JkOiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICAgIG9yZ05hbWU6IG9yZ05hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgbGFuZzogbGFuZyxcclxuICAgICAgICAgICAgICAgICAgICByZW1lbWJlck1lOiByZW1lbWJlck1lXHJcbiAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgdGhpcy5fbGFuZ3VhZ2VTZXJ2aWNlLkdldExhbmdSZXModGhpcy5Gb3JtVHlwZUZvcm0sIGxhbmcpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICByZXNwb25zZSA9ICQucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vYWxlcnQocmVzcG9uc2UuRXJyTXNnKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJsYW5ncmVzb3VyY2VcIiwgSlNPTi5zdHJpbmdpZnkocmVzcG9uc2UuRGF0YSkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImxhbmdcIiwgbGFuZyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuUkVTID0gcmVzcG9uc2UuRGF0YTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgICAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgLy90aGlzLlJFUyA9IHtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgLy8gICAgIFwiQVBQX0RJUlwiOiBcImx0clwiLFxyXG4gICAgICAgIC8vICAgICBcIkFQUF9MQU5HXCI6IFwiZW5cIixcclxuICAgICAgICAvLyAgICAgXCJTQ1JFRU5fTE9HSU5cIjoge1xyXG4gICAgICAgIC8vICAgICAgICAgXCJDT01QQU5ZX05BTUVcIjogXCJBbWF4XCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9UWVBFXCI6IFwiQy5SLk1cIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0JBU0VMSU5FXCI6IFwiwqkgQW1heCAtIHNvZnR3YXJlIHNvbHV0aW9uc1wiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfTEJMX0lORk9cIjogXCJQbGVhc2UgRW50ZXIgWW91ciBJbmZvcm1hdGlvblwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfTEJMX1VTRVJcIjogXCJVc2VybmFtZVwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfTEJMX1BBU1NcIjogXCJQYXNzd29yZFwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfTEJMX09SR1wiOiBcIk9yZ2FuaXphdGlvbiBJRFwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfTEJMX1JFTUVNQkVSXCI6IFwiUmVtZW1iZXIgTWVcIixcclxuXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9CVE5fTE9HSU5cIjogXCJMb2dpblwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfTEJMX0ZPUkdPVFBBU1NcIjogXCJJIGZvcmdvdCBteSBwYXNzd29yZFwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfTEJMX1JFR0lTVEVSXCI6IFwiSSB3YW50IHRvIHJlZ2lzdGVyXCJcclxuICAgICAgICAvLyAgICAgfSxcclxuICAgICAgICAvLyAgICAgXCJDVVNUT01FUl9NQVNURVJcIjoge1xyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfTEJMX0NVU1RcIjogXCJDdXN0b21lclwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfTEJMX0NBUkRcIjogXCJDYXJkXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9MQkxfTkVXX0NVU1RcIjogXCJBZGQgTmV3IEN1c3RvbWVyXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9UWFRfUkVRRFwiOiBcIihSZXF1aXJlZC0qKVwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfVFhUX1BIX0xOQU1FXCI6IFwiTGFzdCBOYW1lKlwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfVFhUX1BIX0ZOQU1FXCI6IFwiRmlyc3QgTmFtZSpcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX1RYVF9QSF9NTkFNRVwiOiBcIk1pZGRsZSBOYW1lXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9UWFRfUEhfQ05BTUVcIjogXCJDb21wYW55IE5hbWUqXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9EUF9DVFlQRVwiOiBcIlNlbGVjdCBDdXN0b21lciBUeXBlXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9EUF9FTVBcIjogXCJTZWxlY3QgQ29udGFjdCBFbXBsb3llZVwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfRFBfU09VUkNFXCI6IFwiU2VsZWN0IFNvdXJjZVwiLFxyXG5cclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX1RYVF9QSF9DQ09ERVwiOiBcIkN1c3RvbWVyIENvZGVcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX1RYVF9QSF9CREFURVwiOiBcIkJpcnRoIERhdGVcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX1RYVF9QSF9KT0JcIjogXCJKb2IgVGl0bGVcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX1RYVF9QSF9USVRMRVwiOiBcIlRpdGxlXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9EUF9TVUZGSVhcIjogXCJTZWxlY3QgU3VmZml4XCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9EUF9HRU5ERVJcIjogXCJTZWxlY3QgR2VuZGVyXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9EUF9HRU5ERVJfTVwiOiBcIk1hbGVcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0RQX0dFTkRFUl9GXCI6IFwiRmVtYWxlXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9MQkxfUEhPTkVcIjogXCJQaG9uZXNcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0xCTF9BRERfUEhcIjogXCJBZGQgUGhvbmVcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0RQX1BUWVBFXCI6IFwiU2VsZWN0IFBob25lIFR5cGUqXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9UWFRfUEhfUFJFRklYXCI6IFwiUHJlZml4XCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9UWFRfUEhfQVJFQVwiOiBcIkFyZWFcIixcclxuXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9UWFRfUEhfUEhPTkVcIjogXCJQaG9uZSpcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0xCTF9TTVNcIjogXCJGb3IgU01TXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9DSEtfUEhfU01TXCI6IFwiRm9yIFNNU1wiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfVFhUX1BIX0NPTU1FTlRcIjogXCJDb21tZW50c1wiLFxyXG5cclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0JUTl9QSEFERFwiOiBcIkFkZFwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfQlROX1BIQ0xPU0VcIjogXCJDbG9zZVwiLFxyXG5cclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0JUTl9FQUREXCI6IFwiQWRkXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9CVE5fRUNMT1NFXCI6IFwiQ2xvc2VcIixcclxuXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9CVE5fQURBRERcIjogXCJBZGRcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0JUTl9BRENMT1NFXCI6IFwiQ2xvc2VcIixcclxuXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9HUkRfTEJMX1BUWVBFXCI6IFwiUGhvbmUgVHlwZVwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfR1JEX0xCTF9QSE5PXCI6IFwiUHJlZml4LUFyZWEtUGhvbmVcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0dSRF9MQkxfU01TXCI6IFwiRm9yIFNNU1wiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfR1JEX0xCTF9SRU1cIjogXCJSZW1hcmtzXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9MTktfRU1BSUxcIjogXCJFbWFpbHNcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0xCTF9FTUFJTFwiOiBcIkFkZCBFbWFpbFwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfVFhUX1BIX0VNQUlMXCI6IFwiRW1haWwqXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9UWFRfUEhfRU5BTUVcIjogXCJOYW1lKlwiLFxyXG5cclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0xCTF9OTEVUVEVSXCI6IFwiTmV3c0xldHRlclwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfR1JEX0xCTF9FTUFJTFwiOiBcIkVtYWlsXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9HUkRfTEJMX0VOQU1FXCI6IFwiTmFtZVwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfR1JEX0xCTF9OTEVUVEVSXCI6IFwiTmV3c2xldHRlclwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfTE5LX0xCTF9BRERSU1wiOiBcIkFkZHJlc3Nlc1wiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfTEJMX0FERFJFU1NcIjogXCJBZGQgQWRkcmVzc1wiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfTEJMX1BIX1NUUlwiOiBcIlN0cmVldCpcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0xCTF9QSF9BREFSRUFcIjogXCJBcmVhKlwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfTEJMX1BIX0NJVFlcIjogXCJDaXR5KlwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfTEJMX1BIX1pJUFwiOiBcIlppcCpcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0RQX0NPVU5UUllcIjogXCJTZWxlY3QgQ291bnRyeSpcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0RQX1NUQVRFXCI6IFwiU2VsZWN0IFN0YXRlXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9EUF9BRERSVFlQRVwiOiBcIlNlbGVjdCBBZGRyZXNzVHlwZSpcIixcclxuXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9MQkxfREVMSVZFUllcIjogXCJEZWxpdmVyeVwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfTEJMX01BRERSRVNTXCI6IFwiSXMgTWFpbiBBZGRyZXNzXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9HUkRfTEJMX1NUUkVFVFwiOiBcIlN0cmVldFwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfR1JEX0xCTF9BREFSRUFcIjogXCJBcmVhXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9HUkRfTEJMX0NJVFlcIjogXCJDaXR5TmFtZVwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfR1JEX0xCTF9aSVBcIjogXCJaaXBcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0dSRF9MQkxfQ09VTlRSWVwiOiBcIkNvdW50cnlDb2RlXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9HUkRfTEJMX1NUQVRFXCI6IFwiU3RhdGVJZFwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfR1JEX0xCTF9BRERSRVNTXCI6IFwiQWRkcmVzc1R5cGVJZFwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfR1JEX0xCTF9ERUxJVkVSWVwiOiBcIkRlbGl2ZXJ5XCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9HUkRfTEJMX01BRERSRVNTXCI6IFwiTWFpbkFkZHJlc3NcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0xCTF9HUlBTXCI6IFwiQ2hvb3NlIEdyb3Vwc1wiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfTEJMX0xPQURcIjogXCJMb2FkaW5nXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9CVE5fU0FWRVwiOiBcIlNhdmUgQ2hhbmdlc1wiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfTE5LX0xCTF9NT1JFXCI6IFwiTW9yZVwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfTE5LX0xCTF9MRVNTXCI6IFwiTGVzc1wiXHJcblxyXG4gICAgICAgIC8vICAgICB9XHJcbiAgICAgICAgICAgICAgICAvLyB9XHJcbiAgICAgICAgICAgICAgICAvL2RlYnVnZ2VyOyAgICBcclxuICAgICAgICAgICAgICAgIHZhciB0ZW1wID0gdGhpcy5fbGFuZ3VhZ2VTZXJ2aWNlLmdldENvb2tpZShcIlJlbWVtYmVyS2V5XCIpO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRlbXAgIT0gXCJcIiAmJiB0ZW1wICE9IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBwYXNzd29yZCA9IHRoaXMuX2xhbmd1YWdlU2VydmljZS5nZXRDb29raWUoXCJwYXNzd29yZFwiKTtcclxuXHJcbiAgICAgICAgaWYgKHBhc3N3b3JkLmxlbmd0aCA+IDApIFxyXG4gICAgICAgICAgICB2YXIgcGFzc3dvcmQgPSBwYXNzd29yZC5zdWJzdHJpbmcoMSwgcGFzc3dvcmQubGVuZ3RoKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9Mb2dnZWR1c2VyTW9kZWwgPSB7XHJcbiAgICAgICAgICAgICAgICB1c2VyTmFtZTogVXNlck5hbWUsXHJcbiAgICAgICAgICAgICAgICBwYXNzd29yZDogcGFzc3dvcmQsXHJcbiAgICAgICAgICAgICAgICBvcmdOYW1lOiBvcmdOYW1lLFxyXG4gICAgICAgICAgICAgICAgbGFuZzogbGFuZyxcclxuICAgICAgICAgICAgICAgIHJlbWVtYmVyTWU6IHJlbWVtYmVyTWVcclxuICAgICAgICAgICAgfVxyXG5cclxuXHJcbiAgICAgICAgICAgIHRoaXMuSXNMb2dlZEluID0gdHJ1ZTtcclxuICAgICAgICAgICAgaWYgKHRoaXMuX0xvZ2dlZHVzZXJNb2RlbFtcInVzZXJOYW1lXCJdICE9IHVuZGVmaW5lZCAmJiB0aGlzLl9Mb2dnZWR1c2VyTW9kZWxbXCJ1c2VyTmFtZVwiXSAhPSBudWxsICYmIHRoaXMuX0xvZ2dlZHVzZXJNb2RlbFtcInVzZXJOYW1lXCJdICE9IFwiXCJcclxuICAgICAgICAgICAgICAgICYmIHRoaXMuX0xvZ2dlZHVzZXJNb2RlbFtcInBhc3N3b3JkXCJdICE9IHVuZGVmaW5lZCAmJiB0aGlzLl9Mb2dnZWR1c2VyTW9kZWxbXCJwYXNzd29yZFwiXSAhPSBudWxsICYmIHRoaXMuX0xvZ2dlZHVzZXJNb2RlbFtcInBhc3N3b3JkXCJdICE9IFwiXCJcclxuICAgICAgICAgICAgICAgICYmIHRoaXMuX0xvZ2dlZHVzZXJNb2RlbFtcIm9yZ05hbWVcIl0gIT0gdW5kZWZpbmVkICYmIHRoaXMuX0xvZ2dlZHVzZXJNb2RlbFtcIm9yZ05hbWVcIl0gIT0gbnVsbCAmJiB0aGlzLl9Mb2dnZWR1c2VyTW9kZWxbXCJvcmdOYW1lXCJdICE9IFwiXCIpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2FtYXhTc2VydmljZS52YWxpZGF0ZUxvZ2luKHRoaXMuX0xvZ2dlZHVzZXJNb2RlbFtcInVzZXJOYW1lXCJdLCB0aGlzLl9Mb2dnZWR1c2VyTW9kZWxbXCJwYXNzd29yZFwiXSwgdGhpcy5fTG9nZ2VkdXNlck1vZGVsW1wib3JnTmFtZVwiXSwgdGhpcy5fTG9nZ2VkdXNlck1vZGVsW1wicmVtZW1iZXJNZVwiXSkuc3Vic2NyaWJlKFxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGEgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgZHRhID0gJC5wYXJzZUpTT04oZGF0YSkuRGF0YTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGR0YS5lcnJvciAhPSB1bmRlZmluZWQgJiYgZHRhLmVycm9yICE9IG51bGwgJiYgZHRhLmVycm9yICE9IFwiXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChkdGEuZXJyb3IgIT0gXCJcIikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBkdGEuZXJyb3IsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuSXNMb2dlZEluID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuTG9naW5EYXRhID0gZHRhO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2Vzc2lvblN0b3JhZ2Uuc2V0SXRlbSgnWFRva2VuJywgZHRhW1widG9rZW5cIl0pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXNzaW9uU3RvcmFnZS5zZXRJdGVtKCdzZXNzaW9uSW5mb3JtYXRpb24nLCBhdG9iKGR0YVtcInRva2VuXCJdLnNwbGl0KCcuJylbMF0pKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlc3Npb25TdG9yYWdlLnNldEl0ZW0oJ3VzZXJJbmZvcm1hdGlvbicsIGF0b2IoZHRhW1widG9rZW5cIl0uc3BsaXQoJy4nKVsxXSkpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vRmVhdGNoaW5nIFVzZXJpbmZvcm1hdGlvblxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLkxvZ2luRGF0YSA9IEpTT04ucGFyc2UoYXRvYihkdGFbXCJ0b2tlblwiXS5zcGxpdCgnLicpWzFdKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImVtcGxveWVlaWRcIiwgdGhpcy5Mb2dpbkRhdGEuZW1wbG95ZWVpZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xvY2FsU3RvcmFnZS5zZXRJdGVtKFwiT3JnSWRcIiwgdGhpcy5fTG9nZ2VkdXNlck1vZGVsW1wib3JnTmFtZVwiXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAobG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJsYW5nXCIpID09IFwiXCIgfHwgbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJsYW5nXCIpID09IHVuZGVmaW5lZCB8fCBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImxhbmdcIikgPT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwibGFuZ1wiLCBcImVuXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9hbGVydCh0aGlzLl9Mb2dnZWR1c2VyTW9kZWxbXCJyZW1lbWJlck1lXCJdLnRvU3RyaW5nKCkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gIGRlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9hbGVydCh0aGlzLl9Mb2dnZWR1c2VyTW9kZWxbXCJyZW1lbWJlck1lXCJdKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLl9Mb2dnZWR1c2VyTW9kZWxbXCJyZW1lbWJlck1lXCJdID09IHRydWUgfHwgdGhpcy5fTG9nZ2VkdXNlck1vZGVsW1wicmVtZW1iZXJNZVwiXSA9PSBcInRydWVcIikge1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgbGFuZyA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwibGFuZ1wiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2FsZXJ0KGxhbmcpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vdGhpcy5fbGFuZ3VhZ2VTZXJ2aWNlLnNldENvb2tpZShcImxhbmdyZXNvdXJjZVwiLCBsYW5nLDEwKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9sYW5ndWFnZVNlcnZpY2Uuc2V0Q29va2llKFwiUmVtZW1iZXJLZXlcIiwgZGF0YSwgMTApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2xhbmd1YWdlU2VydmljZS5zZXRDb29raWUoXCJVc2VyTmFtZVwiLCB0aGlzLl9Mb2dnZWR1c2VyTW9kZWxbXCJ1c2VyTmFtZVwiXSwgMTApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2xhbmd1YWdlU2VydmljZS5zZXRDb29raWUoXCJwYXNzd29yZFwiLCB0aGlzLl9Mb2dnZWR1c2VyTW9kZWxbXCJwYXNzd29yZFwiXSwgMTApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2xhbmd1YWdlU2VydmljZS5zZXRDb29raWUoXCJvcmdOYW1lXCIsIHRoaXMuX0xvZ2dlZHVzZXJNb2RlbFtcIm9yZ05hbWVcIl0sIDEwKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9sYW5ndWFnZVNlcnZpY2Uuc2V0Q29va2llKFwicmVtZW1iZXJNZVwiLCB0aGlzLl9Mb2dnZWR1c2VyTW9kZWxbXCJyZW1lbWJlck1lXCJdLCAxMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fbGFuZ3VhZ2VTZXJ2aWNlLnNldENvb2tpZShcImxhbmdcIiwgbGFuZywgMTApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGVycm9yID0+IGNvbnNvbGUuZXJyb3IoZXJyb3IpLFxyXG4gICAgICAgICAgICAgICAgICAgICgpID0+IHtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX0xvZ2dlZHVzZXJNb2RlbFtcInVzZXJOYW1lXCJdID09IHVuZGVmaW5lZCAmJiB0aGlzLl9Mb2dnZWR1c2VyTW9kZWxbXCJ1c2VyTmFtZVwiXSA9PSBudWxsIHx8IHRoaXMuX0xvZ2dlZHVzZXJNb2RlbFtcInVzZXJOYW1lXCJdID09IFwiXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICAvL2FsZXJ0KFwiUGxlYXNlIGVudGVyIHZhbGlkIHVzZXJuYW1lXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBcIlBsZWFzZSBlbnRlciB2YWxpZCB1c2VybmFtZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5fTG9nZ2VkdXNlck1vZGVsW1wicGFzc3dvcmRcIl0gPT0gdW5kZWZpbmVkICYmIHRoaXMuX0xvZ2dlZHVzZXJNb2RlbFtcInBhc3N3b3JkXCJdID09IG51bGwgfHwgdGhpcy5fTG9nZ2VkdXNlck1vZGVsW1wicGFzc3dvcmRcIl0gPT0gXCJcIikge1xyXG4gICAgICAgICAgICAgICAgICAgIC8vYWxlcnQoXCJQbGVhc2UgZW50ZXIgdmFsaWQgcGFzc3dvcmRcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiUGxlYXNlIGVudGVyIHZhbGlkIHBhc3N3b3JkXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9Mb2dnZWR1c2VyTW9kZWxbXCJvcmdOYW1lXCJdID09IHVuZGVmaW5lZCAmJiB0aGlzLl9Mb2dnZWR1c2VyTW9kZWxbXCJvcmdOYW1lXCJdID09IG51bGwgfHwgdGhpcy5fTG9nZ2VkdXNlck1vZGVsW1wib3JnTmFtZVwiXSA9PSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9hbGVydChcIlBsZWFzZSBlbnRlciB2YWxpZCBvcmdhbml6YXRpb25cIik7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiUGxlYXNlIGVudGVyIHZhbGlkIHBhc3N3b3JkXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG5cclxuXHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vIGlmKCFsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImxhbmdyZXNvdXJjZVwiKSkge1xyXG4gICAgICAgIC8vICAgICAvL3RoaXMuX2xhbmd1YWdlU2VydmljZS5HZXRTZWxlY2V0ZExhbmd1YWdlKFwiZW5cIikuc3Vic2NyaWJlKFxyXG4gICAgICAgIC8vICAgICAvLyAgICBkYXRhPT57XHJcbiAgICAgICAgLy8gICAgIC8vICAgICAgICBjb25zb2xlLmxvZyhkYXRhKTtcclxuICAgICAgICAvLyAgICAgLy8gICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwibGFuZ3Jlc291cmNlXCIsIEpTT04uc3RyaW5naWZ5KGRhdGEpKTtcclxuICAgICAgICAvLyAgICAgLy8gICAgICAgIHRoaXMuUkVTID0gZGF0YTtcclxuICAgICAgICAvLyAgICAgLy8gICAgfSxcclxuICAgICAgICAvLyAgICAgLy8gICAgZXJyb3I9PmNvbnNvbGUubG9nKFwiVW5hYmxlIHRvIGxvYWQgTGFuZ3VhZ2UgRGF0YVwiKSxcclxuICAgICAgICAvLyAgICAgLy8gICAgKCk9PiB7XHJcbiAgICAgICAgLy8gICAgIC8vICAgICAgICBjb25zb2xlLmxvZyhcIkxhbmd1YWdlIHJlc291cmNlIGxvYWRlZFwiKTtcclxuICAgICAgICAvLyAgICAgLy8gICAgfVxyXG4gICAgICAgIC8vICAgICAvLyk7XHJcbiAgICAgICAgLy8gICAgIHRoaXMuUkVTID0gdGhpcy5fbGFuZ3VhZ2VTZXJ2aWNlLkdldFNlbGVjZXRkTGFuZ3VhZ2UoXCJlblwiKTtcclxuICAgICAgICAvLyB9ZWxzZXtcclxuICAgICAgICAvLyAgICAgLy90aGlzLlJFUz1KU09OLnBhcnNlKGxvY2FsU3RvcmFnZS5nZXRJdGVtKCdsYW5ncmVzb3VyY2UnKSk7XHJcbiAgICAgICAgLy8gfVxyXG4gICAgfVxyXG59Il19
