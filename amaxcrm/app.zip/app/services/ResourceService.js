System.register(["angular2/core", "angular2/http", 'rxjs/add/operator/map', "../crmconfig"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, http_1, crmconfig_1;
    var ResourceService;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (http_1_1) {
                http_1 = http_1_1;
            },
            function (_1) {},
            function (crmconfig_1_1) {
                crmconfig_1 = crmconfig_1_1;
            }],
        execute: function() {
            ResourceService = (function () {
                function ResourceService(_http) {
                    this._http = _http;
                    this.headers = new http_1.Headers();
                    this.headers.append("Content-Type", "application/json");
                    this.baseUrl = crmconfig_1.serviceConfig.serviceApiUrl;
                    this.AppUrl = crmconfig_1.serviceConfig.AppUrl;
                    this.ImageUrl = crmconfig_1.serviceConfig.ImageUrl;
                }
                ResourceService.prototype.getHeader = function () {
                    var header = new http_1.Headers();
                    header.append("Content-Type", "application/json");
                    //if (sessionStorage.getItem(serviceConfig.accesTokenStoreName)) {
                    //    header.append(serviceConfig.accesTokenRequestHeader, sessionStorage.getItem(serviceConfig.accesTokenStoreName));
                    //} else {
                    //    throw 'Access token not available';
                    //}
                    return header;
                };
                ResourceService.prototype.setCookie = function (name, value, expireDays, path) {
                    if (path === void 0) { path = ""; }
                    //debugger;
                    var d = new Date();
                    d.setTime(d.getTime() + expireDays * 24 * 60 * 60 * 1000);
                    var expires = "expires=" + d.toUTCString();
                    document.cookie = name + "=" + value + "; " + expires + (path.length > 0 ? "; path=" + path : "");
                    //document.cookie = name + "=" + value + "; path=" + path;
                };
                ResourceService.prototype.getCookie = function (name) {
                    //debugger;
                    var ca = document.cookie.split(';');
                    var caLen = ca.length;
                    var cookieName = name + "=";
                    var c;
                    for (var i = 0; i < caLen; i += 1) {
                        c = ca[i].replace(/^\s\+/g, "");
                        var index = c.indexOf(cookieName);
                        if (c.indexOf(cookieName) == 0) {
                            return c.substring(cookieName.length, c.length);
                        }
                        if (c.indexOf(cookieName) == 1 && cookieName == name + "=") {
                            return c.substring(cookieName.length, c.length);
                        }
                    }
                    return "";
                };
                ResourceService.prototype.deleteCookie = function (name) {
                    this.setCookie(name, "", -1);
                };
                ResourceService.prototype.LoadLanguageResource = function (code) {
                    if (code === void 0) { code = "he"; }
                    // the function is not in use
                };
                ResourceService.prototype.GetSelecetdLanguage = function (code) {
                    //debugger;
                    if (!code)
                        code = "en";
                    code = code.trim();
                    // debugger;
                    //,
                    //{ headers: this.headers }
                    return this._http.get("/src/lang/" + code + ".json")
                        .map(function (res) { return res.json(); });
                };
                ResourceService.prototype.GetAvailableLanguages = function () {
                    return [
                        { name: "English", code: "en" },
                        { name: "עִברִית", code: "he" }
                    ];
                };
                ResourceService.prototype.GetMenues = function () {
                    var _this = this;
                    var lang = this.getCookie("lang");
                    //alert(lang);
                    if (lang.length > 0)
                        lang = lang.substring(1, lang.length);
                    if (lang == "")
                        lang = "en";
                    return new Promise(function (resolve) {
                        return _this._http.get("/src/menu-" + lang + ".json", { headers: _this.headers })
                            .map(function (res) { return res.json().menu; })
                            .subscribe(function (menudata) {
                            resolve(menudata);
                        });
                    });
                };
                ResourceService.prototype.GetFormByName = function (formName) {
                    return this._http.get("/src/forms/" + formName + ".json", { headers: this.headers })
                        .map(function (res) { return res.json(); });
                    //return new Promise(resolve=>{
                    //    this._http.get("/src/forms/"+formName+".json",{headers:this.headers})
                    //        .map(res=>res.json())
                    //        .subscribe(data=>resolve(data));
                    //})
                };
                //localstorage utility
                ResourceService.prototype.GetLocalStorage = function (key) {
                    var data = localStorage.getItem(key);
                    return JSON.parse(data);
                };
                ResourceService.prototype.SetLocalStorage = function (key, data) {
                    localStorage.setItem(key, JSON.stringify(data));
                };
                //sessionStorage utility
                ResourceService.prototype.GetSessionStorage = function (key) {
                    var data = sessionStorage.getItem(key);
                    return JSON.parse(data);
                };
                ResourceService.prototype.SetSessionStorage = function (key, data) {
                    sessionStorage.setItem(key, JSON.stringify(data));
                };
                ResourceService.prototype.GetLangRes = function (FormType, Lang) {
                    //alert(FormType);
                    //debugger;
                    //var Lang = localStorage.getItem("lang");
                    return this._http.get(this.baseUrl + "Dropdown/GetLangRes?FormType=" + FormType + "&Lang=" + Lang, { headers: this.getHeader() }).map(function (res) { return res.text(); });
                };
                ResourceService = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [http_1.Http])
                ], ResourceService);
                return ResourceService;
            }());
            exports_1("ResourceService", ResourceService);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNlcnZpY2VzL1Jlc291cmNlU2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7WUFZQTtnQkFLSSx5QkFBb0IsS0FBVztvQkFBWCxVQUFLLEdBQUwsS0FBSyxDQUFNO29CQUMzQixJQUFJLENBQUMsT0FBTyxHQUFDLElBQUksY0FBTyxFQUFFLENBQUM7b0JBQzNCLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLGNBQWMsRUFBRSxrQkFBa0IsQ0FBQyxDQUFDO29CQUN4RCxJQUFJLENBQUMsT0FBTyxHQUFHLHlCQUFhLENBQUMsYUFBYSxDQUFDO29CQUMzQyxJQUFJLENBQUMsTUFBTSxHQUFHLHlCQUFhLENBQUMsTUFBTSxDQUFDO29CQUNuQyxJQUFJLENBQUMsUUFBUSxHQUFHLHlCQUFhLENBQUMsUUFBUSxDQUFDO2dCQUMzQyxDQUFDO2dCQUtPLG1DQUFTLEdBQWpCO29CQUNJLElBQUksTUFBTSxHQUFHLElBQUksY0FBTyxFQUFFLENBQUM7b0JBQzNCLE1BQU0sQ0FBQyxNQUFNLENBQUMsY0FBYyxFQUFFLGtCQUFrQixDQUFDLENBQUM7b0JBQ2xELGtFQUFrRTtvQkFDbEUsc0hBQXNIO29CQUN0SCxVQUFVO29CQUNWLHlDQUF5QztvQkFDekMsR0FBRztvQkFDSCxNQUFNLENBQUMsTUFBTSxDQUFDO2dCQUNsQixDQUFDO2dCQUdNLG1DQUFTLEdBQWhCLFVBQWlCLElBQVksRUFBRSxLQUFhLEVBQUUsVUFBa0IsRUFBRSxJQUFpQjtvQkFBakIsb0JBQWlCLEdBQWpCLFNBQWlCO29CQUMvRSxXQUFXO29CQUNYLElBQUksQ0FBQyxHQUFTLElBQUksSUFBSSxFQUFFLENBQUM7b0JBQ3pCLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sRUFBRSxHQUFHLFVBQVUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUMsQ0FBQztvQkFDMUQsSUFBSSxPQUFPLEdBQVcsVUFBVSxHQUFHLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztvQkFDbkQsUUFBUSxDQUFDLE1BQU0sR0FBRyxJQUFJLEdBQUcsR0FBRyxHQUFHLEtBQUssR0FBRyxJQUFJLEdBQUcsT0FBTyxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLEdBQUcsU0FBUyxHQUFHLElBQUksR0FBRyxFQUFFLENBQUMsQ0FBQztvQkFFbEcsMERBQTBEO2dCQUM5RCxDQUFDO2dCQUVNLG1DQUFTLEdBQWhCLFVBQWlCLElBQVk7b0JBQ3pCLFdBQVc7b0JBQ1gsSUFBSSxFQUFFLEdBQWtCLFFBQVEsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUNuRCxJQUFJLEtBQUssR0FBVyxFQUFFLENBQUMsTUFBTSxDQUFDO29CQUM5QixJQUFJLFVBQVUsR0FBRyxJQUFJLEdBQUcsR0FBRyxDQUFDO29CQUM1QixJQUFJLENBQVMsQ0FBQztvQkFFZCxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUssRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7d0JBQ3hDLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQzt3QkFDaEMsSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQzt3QkFDbEMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDOzRCQUM3QixNQUFNLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQzt3QkFDcEQsQ0FBQzt3QkFDRCxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxVQUFVLElBQUksSUFBSSxHQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7NEJBQ3ZELE1BQU0sQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO3dCQUNwRCxDQUFDO29CQUNMLENBQUM7b0JBQ0QsTUFBTSxDQUFDLEVBQUUsQ0FBQztnQkFDZCxDQUFDO2dCQUVNLHNDQUFZLEdBQW5CLFVBQW9CLElBQUk7b0JBQ3BCLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNqQyxDQUFDO2dCQUdNLDhDQUFvQixHQUEzQixVQUE0QixJQUFtQjtvQkFBbkIsb0JBQW1CLEdBQW5CLFdBQW1CO29CQUMzQyw2QkFBNkI7Z0JBQ2pDLENBQUM7Z0JBR00sNkNBQW1CLEdBQTFCLFVBQTJCLElBQWE7b0JBQ3BDLFdBQVc7b0JBQ1gsRUFBRSxDQUFBLENBQUMsQ0FBQyxJQUFJLENBQUM7d0JBQUEsSUFBSSxHQUFDLElBQUksQ0FBQztvQkFDbkIsSUFBSSxHQUFHLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztvQkFDcEIsWUFBWTtvQkFDWCxHQUFHO29CQUNILDJCQUEyQjtvQkFDM0IsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUNqQixZQUFZLEdBQUMsSUFBSSxHQUFDLE9BQU8sQ0FBQzt5QkFDekIsR0FBRyxDQUNKLFVBQUEsR0FBRyxJQUFJLE9BQUEsR0FBRyxDQUFDLElBQUksRUFBRSxFQUFWLENBQVUsQ0FDaEIsQ0FBQztnQkFDVixDQUFDO2dCQUVNLCtDQUFxQixHQUE1QjtvQkFDSSxNQUFNLENBQUM7d0JBQ0gsRUFBQyxJQUFJLEVBQUMsU0FBUyxFQUFFLElBQUksRUFBQyxJQUFJLEVBQUM7d0JBQzNCLEVBQUMsSUFBSSxFQUFDLFNBQVMsRUFBRSxJQUFJLEVBQUMsSUFBSSxFQUFDO3FCQUM5QixDQUFDO2dCQUNOLENBQUM7Z0JBRU0sbUNBQVMsR0FBaEI7b0JBQUEsaUJBa0JDO29CQWhCRyxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUNsQyxjQUFjO29CQUNkLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO3dCQUNoQixJQUFJLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUMxQyxFQUFFLENBQUMsQ0FBQyxJQUFJLElBQUksRUFBRSxDQUFDO3dCQUNYLElBQUksR0FBRyxJQUFJLENBQUM7b0JBQ2hCLE1BQU0sQ0FBQyxJQUFJLE9BQU8sQ0FBQyxVQUFBLE9BQU87d0JBQ3RCLE9BQUEsS0FBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQ1YsWUFBWSxHQUFHLElBQUksR0FBQyxPQUFPLEVBQzNCLEVBQUUsT0FBTyxFQUFFLEtBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQzs2QkFDekIsR0FBRyxDQUFDLFVBQUEsR0FBRyxJQUFHLE9BQUEsR0FBRyxDQUFDLElBQUksRUFBRSxDQUFDLElBQUksRUFBZixDQUFlLENBQUM7NkJBQzFCLFNBQVMsQ0FBQyxVQUFBLFFBQVE7NEJBRWYsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUN0QixDQUFDLENBQUM7b0JBUE4sQ0FPTSxDQUNULENBQUE7Z0JBQ0wsQ0FBQztnQkFFTSx1Q0FBYSxHQUFwQixVQUFxQixRQUFlO29CQUNoQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsYUFBYSxHQUFDLFFBQVEsR0FBQyxPQUFPLEVBQUMsRUFBQyxPQUFPLEVBQUMsSUFBSSxDQUFDLE9BQU8sRUFBQyxDQUFDO3lCQUN2RSxHQUFHLENBQUMsVUFBQSxHQUFHLElBQUUsT0FBQSxHQUFHLENBQUMsSUFBSSxFQUFFLEVBQVYsQ0FBVSxDQUFDLENBQUM7b0JBRTFCLCtCQUErQjtvQkFDL0IsMkVBQTJFO29CQUMzRSwrQkFBK0I7b0JBQy9CLDBDQUEwQztvQkFDMUMsSUFBSTtnQkFDUixDQUFDO2dCQUVELHNCQUFzQjtnQkFDZix5Q0FBZSxHQUF0QixVQUF1QixHQUFXO29CQUM5QixJQUFJLElBQUksR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUNyQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDNUIsQ0FBQztnQkFDTSx5Q0FBZSxHQUF0QixVQUF1QixHQUFXLEVBQUUsSUFBUztvQkFDekMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUNwRCxDQUFDO2dCQUVELHdCQUF3QjtnQkFDakIsMkNBQWlCLEdBQXhCLFVBQXlCLEdBQVc7b0JBQ2hDLElBQUksSUFBSSxHQUFHLGNBQWMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUM7b0JBQ3ZDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUM1QixDQUFDO2dCQUNNLDJDQUFpQixHQUF4QixVQUF5QixHQUFXLEVBQUUsSUFBUztvQkFDM0MsY0FBYyxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUN0RCxDQUFDO2dCQUNNLG9DQUFVLEdBQWpCLFVBQWtCLFFBQWdCLEVBQUUsSUFBWTtvQkFDNUMsa0JBQWtCO29CQUNsQixXQUFXO29CQUNYLDBDQUEwQztvQkFDMUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUNqQixJQUFJLENBQUMsT0FBTyxHQUFHLCtCQUErQixHQUFHLFFBQVEsR0FBRyxRQUFRLEdBQUcsSUFBSSxFQUMzRSxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsU0FBUyxFQUFFLEVBQUUsQ0FDaEMsQ0FBQyxHQUFHLENBQUMsVUFBQSxHQUFHLElBQUcsT0FBQSxHQUFHLENBQUMsSUFBSSxFQUFFLEVBQVYsQ0FBVSxDQUFDLENBQUM7Z0JBQzVCLENBQUM7Z0JBbEpMO29CQUFDLGlCQUFVLEVBQUU7O21DQUFBO2dCQW1KYixzQkFBQztZQUFELENBbEpBLEFBa0pDLElBQUE7WUFsSkQsNkNBa0pDLENBQUEiLCJmaWxlIjoic2VydmljZXMvUmVzb3VyY2VTZXJ2aWNlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtJbmplY3RhYmxlfSBmcm9tIFwiYW5ndWxhcjIvY29yZVwiO1xyXG5pbXBvcnQge0h0dHAsIEhlYWRlcnN9IGZyb20gXCJhbmd1bGFyMi9odHRwXCI7XHJcbmltcG9ydCAncnhqcy9hZGQvb3BlcmF0b3IvbWFwJztcclxuaW1wb3J0IHtMb2NhbERpY3QsIGNybUNvbmZpZywgc2VydmljZUNvbmZpZ30gZnJvbSBcIi4uL2NybWNvbmZpZ1wiO1xyXG5leHBvcnQgaW50ZXJmYWNlIE1lbnVlSXRlbXtcclxuICAgIGxhYmVsOnN0cmluZyxcclxuICAgIHJvdXRlclVybDpzdHJpbmcsXHJcbiAgICBmYWljb24/OnN0cmluZyxcclxuICAgIHN1Yk1lbnVzPzpBcnJheTxNZW51ZUl0ZW0+XHJcbn1cclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIFJlc291cmNlU2VydmljZSB7XHJcbiAgICBoZWFkZXJzOiBIZWFkZXJzO1xyXG4gICAgQXBwVXJsOiBzdHJpbmc7XHJcbiAgICBiYXNlVXJsOiBzdHJpbmc7XHJcbiAgICBJbWFnZVVybDogc3RyaW5nO1xyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBfaHR0cDogSHR0cCkge1xyXG4gICAgICAgIHRoaXMuaGVhZGVycz1uZXcgSGVhZGVycygpO1xyXG4gICAgICAgIHRoaXMuaGVhZGVycy5hcHBlbmQoXCJDb250ZW50LVR5cGVcIiwgXCJhcHBsaWNhdGlvbi9qc29uXCIpO1xyXG4gICAgICAgIHRoaXMuYmFzZVVybCA9IHNlcnZpY2VDb25maWcuc2VydmljZUFwaVVybDtcclxuICAgICAgICB0aGlzLkFwcFVybCA9IHNlcnZpY2VDb25maWcuQXBwVXJsO1xyXG4gICAgICAgIHRoaXMuSW1hZ2VVcmwgPSBzZXJ2aWNlQ29uZmlnLkltYWdlVXJsO1xyXG4gICAgfVxyXG5cclxuXHJcblxyXG5cclxuICAgIHByaXZhdGUgZ2V0SGVhZGVyKCk6IEhlYWRlcnMge1xyXG4gICAgICAgIHZhciBoZWFkZXIgPSBuZXcgSGVhZGVycygpO1xyXG4gICAgICAgIGhlYWRlci5hcHBlbmQoXCJDb250ZW50LVR5cGVcIiwgXCJhcHBsaWNhdGlvbi9qc29uXCIpO1xyXG4gICAgICAgIC8vaWYgKHNlc3Npb25TdG9yYWdlLmdldEl0ZW0oc2VydmljZUNvbmZpZy5hY2Nlc1Rva2VuU3RvcmVOYW1lKSkge1xyXG4gICAgICAgIC8vICAgIGhlYWRlci5hcHBlbmQoc2VydmljZUNvbmZpZy5hY2Nlc1Rva2VuUmVxdWVzdEhlYWRlciwgc2Vzc2lvblN0b3JhZ2UuZ2V0SXRlbShzZXJ2aWNlQ29uZmlnLmFjY2VzVG9rZW5TdG9yZU5hbWUpKTtcclxuICAgICAgICAvL30gZWxzZSB7XHJcbiAgICAgICAgLy8gICAgdGhyb3cgJ0FjY2VzcyB0b2tlbiBub3QgYXZhaWxhYmxlJztcclxuICAgICAgICAvL31cclxuICAgICAgICByZXR1cm4gaGVhZGVyO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICBwdWJsaWMgc2V0Q29va2llKG5hbWU6IHN0cmluZywgdmFsdWU6IE9iamVjdCwgZXhwaXJlRGF5czogbnVtYmVyLCBwYXRoOiBzdHJpbmcgPSBcIlwiKSB7ICAgICAgIC8qZXhwaXJlRGF5czogbnVtYmVyLCovXHJcbiAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICBsZXQgZDogRGF0ZSA9IG5ldyBEYXRlKCk7XHJcbiAgICAgICAgZC5zZXRUaW1lKGQuZ2V0VGltZSgpICsgZXhwaXJlRGF5cyAqIDI0ICogNjAgKiA2MCAqIDEwMDApO1xyXG4gICAgICAgIGxldCBleHBpcmVzOiBzdHJpbmcgPSBcImV4cGlyZXM9XCIgKyBkLnRvVVRDU3RyaW5nKCk7XHJcbiAgICAgICAgZG9jdW1lbnQuY29va2llID0gbmFtZSArIFwiPVwiICsgdmFsdWUgKyBcIjsgXCIgKyBleHBpcmVzICsgKHBhdGgubGVuZ3RoID4gMCA/IFwiOyBwYXRoPVwiICsgcGF0aCA6IFwiXCIpO1xyXG5cclxuICAgICAgICAvL2RvY3VtZW50LmNvb2tpZSA9IG5hbWUgKyBcIj1cIiArIHZhbHVlICsgXCI7IHBhdGg9XCIgKyBwYXRoO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZXRDb29raWUobmFtZTogc3RyaW5nKSB7XHJcbiAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICBsZXQgY2E6IEFycmF5PHN0cmluZz4gPSBkb2N1bWVudC5jb29raWUuc3BsaXQoJzsnKTtcclxuICAgICAgICBsZXQgY2FMZW46IG51bWJlciA9IGNhLmxlbmd0aDtcclxuICAgICAgICBsZXQgY29va2llTmFtZSA9IG5hbWUgKyBcIj1cIjtcclxuICAgICAgICBsZXQgYzogc3RyaW5nO1xyXG5cclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgY2FMZW47IGkgKz0gMSkge1xyXG4gICAgICAgICAgICBjID0gY2FbaV0ucmVwbGFjZSgvXlxcc1xcKy9nLCBcIlwiKTtcclxuICAgICAgICAgICAgdmFyIGluZGV4ID0gYy5pbmRleE9mKGNvb2tpZU5hbWUpO1xyXG4gICAgICAgICAgICBpZiAoYy5pbmRleE9mKGNvb2tpZU5hbWUpID09IDApIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBjLnN1YnN0cmluZyhjb29raWVOYW1lLmxlbmd0aCwgYy5sZW5ndGgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChjLmluZGV4T2YoY29va2llTmFtZSkgPT0gMSAmJiBjb29raWVOYW1lID09IG5hbWUrXCI9XCIpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBjLnN1YnN0cmluZyhjb29raWVOYW1lLmxlbmd0aCwgYy5sZW5ndGgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBcIlwiO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBkZWxldGVDb29raWUobmFtZSkge1xyXG4gICAgICAgIHRoaXMuc2V0Q29va2llKG5hbWUsIFwiXCIsIC0xKTtcclxuICAgIH1cclxuXHJcblxyXG4gICAgcHVibGljIExvYWRMYW5ndWFnZVJlc291cmNlKGNvZGU6IHN0cmluZyA9IFwiaGVcIikge1xyXG4gICAgICAgIC8vIHRoZSBmdW5jdGlvbiBpcyBub3QgaW4gdXNlXHJcbiAgICB9XHJcblxyXG5cclxuICAgIHB1YmxpYyBHZXRTZWxlY2V0ZExhbmd1YWdlKGNvZGU/OiBzdHJpbmcpIHtcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgIGlmKCFjb2RlKWNvZGU9XCJlblwiO1xyXG4gICAgICAgIGNvZGUgPSBjb2RlLnRyaW0oKTtcclxuICAgICAgIC8vIGRlYnVnZ2VyO1xyXG4gICAgICAgIC8vLFxyXG4gICAgICAgIC8veyBoZWFkZXJzOiB0aGlzLmhlYWRlcnMgfVxyXG4gICAgICAgIHJldHVybiB0aGlzLl9odHRwLmdldChcclxuICAgICAgICAgICAgXCIvc3JjL2xhbmcvXCIrY29kZStcIi5qc29uXCIpXHJcbiAgICAgICAgICAgIC5tYXAoXHJcbiAgICAgICAgICAgIHJlcyA9PiByZXMuanNvbigpXHJcbiAgICAgICAgICAgICk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIEdldEF2YWlsYWJsZUxhbmd1YWdlcygpOltPYmplY3Rde1xyXG4gICAgICAgIHJldHVybiBbXHJcbiAgICAgICAgICAgIHtuYW1lOlwiRW5nbGlzaFwiLCBjb2RlOlwiZW5cIn0sXHJcbiAgICAgICAgICAgIHtuYW1lOlwi16LWtNeR16jWtNeZ16pcIiwgY29kZTpcImhlXCJ9XHJcbiAgICAgICAgXTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgR2V0TWVudWVzKCkge1xyXG4gICAgICAgXHJcbiAgICAgICAgdmFyIGxhbmcgPSB0aGlzLmdldENvb2tpZShcImxhbmdcIik7XHJcbiAgICAgICAgLy9hbGVydChsYW5nKTtcclxuICAgICAgICBpZiAobGFuZy5sZW5ndGggPiAwKVxyXG4gICAgICAgICAgICBsYW5nID0gbGFuZy5zdWJzdHJpbmcoMSwgbGFuZy5sZW5ndGgpO1xyXG4gICAgICAgIGlmIChsYW5nID09IFwiXCIpXHJcbiAgICAgICAgICAgIGxhbmcgPSBcImVuXCI7XHJcbiAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKHJlc29sdmU9PlxyXG4gICAgICAgICAgICB0aGlzLl9odHRwLmdldChcclxuICAgICAgICAgICAgICAgIFwiL3NyYy9tZW51LVwiICsgbGFuZytcIi5qc29uXCIsXHJcbiAgICAgICAgICAgICAgICB7IGhlYWRlcnM6IHRoaXMuaGVhZGVycyB9KVxyXG4gICAgICAgICAgICAgICAgLm1hcChyZXMgPT5yZXMuanNvbigpLm1lbnUpXHJcbiAgICAgICAgICAgICAgICAuc3Vic2NyaWJlKG1lbnVkYXRhPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIHJlc29sdmUobWVudWRhdGEpO1xyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICApXHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIEdldEZvcm1CeU5hbWUoZm9ybU5hbWU6c3RyaW5nKXtcclxuICAgICAgICByZXR1cm4gdGhpcy5faHR0cC5nZXQoXCIvc3JjL2Zvcm1zL1wiK2Zvcm1OYW1lK1wiLmpzb25cIix7aGVhZGVyczp0aGlzLmhlYWRlcnN9KVxyXG4gICAgICAgICAgICAubWFwKHJlcz0+cmVzLmpzb24oKSk7XHJcblxyXG4gICAgICAgIC8vcmV0dXJuIG5ldyBQcm9taXNlKHJlc29sdmU9PntcclxuICAgICAgICAvLyAgICB0aGlzLl9odHRwLmdldChcIi9zcmMvZm9ybXMvXCIrZm9ybU5hbWUrXCIuanNvblwiLHtoZWFkZXJzOnRoaXMuaGVhZGVyc30pXHJcbiAgICAgICAgLy8gICAgICAgIC5tYXAocmVzPT5yZXMuanNvbigpKVxyXG4gICAgICAgIC8vICAgICAgICAuc3Vic2NyaWJlKGRhdGE9PnJlc29sdmUoZGF0YSkpO1xyXG4gICAgICAgIC8vfSlcclxuICAgIH1cclxuXHJcbiAgICAvL2xvY2Fsc3RvcmFnZSB1dGlsaXR5XHJcbiAgICBwdWJsaWMgR2V0TG9jYWxTdG9yYWdlKGtleTogc3RyaW5nKTogYW55IHtcclxuICAgICAgICB2YXIgZGF0YSA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKGtleSk7XHJcbiAgICAgICAgcmV0dXJuIEpTT04ucGFyc2UoZGF0YSk7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgU2V0TG9jYWxTdG9yYWdlKGtleTogc3RyaW5nLCBkYXRhOiBhbnkpIHtcclxuICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShrZXksIEpTT04uc3RyaW5naWZ5KGRhdGEpKTtcclxuICAgIH1cclxuXHJcbiAgICAvL3Nlc3Npb25TdG9yYWdlIHV0aWxpdHlcclxuICAgIHB1YmxpYyBHZXRTZXNzaW9uU3RvcmFnZShrZXk6IHN0cmluZyk6IGFueSB7XHJcbiAgICAgICAgdmFyIGRhdGEgPSBzZXNzaW9uU3RvcmFnZS5nZXRJdGVtKGtleSk7XHJcbiAgICAgICAgcmV0dXJuIEpTT04ucGFyc2UoZGF0YSk7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgU2V0U2Vzc2lvblN0b3JhZ2Uoa2V5OiBzdHJpbmcsIGRhdGE6IGFueSkge1xyXG4gICAgICAgIHNlc3Npb25TdG9yYWdlLnNldEl0ZW0oa2V5LCBKU09OLnN0cmluZ2lmeShkYXRhKSk7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgR2V0TGFuZ1JlcyhGb3JtVHlwZTogc3RyaW5nLCBMYW5nOiBzdHJpbmcpOiBPYnNlcnZhYmxlIHtcclxuICAgICAgICAvL2FsZXJ0KEZvcm1UeXBlKTtcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgIC8vdmFyIExhbmcgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImxhbmdcIik7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2h0dHAuZ2V0KFxyXG4gICAgICAgICAgICB0aGlzLmJhc2VVcmwgKyBcIkRyb3Bkb3duL0dldExhbmdSZXM/Rm9ybVR5cGU9XCIgKyBGb3JtVHlwZSArIFwiJkxhbmc9XCIgKyBMYW5nLFxyXG4gICAgICAgICAgICB7IGhlYWRlcnM6IHRoaXMuZ2V0SGVhZGVyKCkgfVxyXG4gICAgICAgICkubWFwKHJlcz0+IHJlcy50ZXh0KCkpO1xyXG4gICAgfVxyXG59Il19
