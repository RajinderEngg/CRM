System.register(["angular2/core", "angular2/http", 'rxjs/add/operator/map', "../crmconfig"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, http_1, crmconfig_1;
    var ResourceService;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (http_1_1) {
                http_1 = http_1_1;
            },
            function (_1) {},
            function (crmconfig_1_1) {
                crmconfig_1 = crmconfig_1_1;
            }],
        execute: function() {
            ResourceService = (function () {
                function ResourceService(_http) {
                    this._http = _http;
                    this.headers = new http_1.Headers();
                    this.headers.append("Content-Type", "application/json");
                    this.baseUrl = crmconfig_1.serviceConfig.serviceApiUrl;
                    this.AppUrl = crmconfig_1.serviceConfig.AppUrl;
                }
                ResourceService.prototype.getHeader = function () {
                    var header = new http_1.Headers();
                    header.append("Content-Type", "application/json");
                    //if (sessionStorage.getItem(serviceConfig.accesTokenStoreName)) {
                    //    header.append(serviceConfig.accesTokenRequestHeader, sessionStorage.getItem(serviceConfig.accesTokenStoreName));
                    //} else {
                    //    throw 'Access token not available';
                    //}
                    return header;
                };
                ResourceService.prototype.setCookie = function (name, value, expireDays, path) {
                    if (path === void 0) { path = ""; }
                    //debugger;
                    var d = new Date();
                    d.setTime(d.getTime() + expireDays * 24 * 60 * 60 * 1000);
                    var expires = "expires=" + d.toUTCString();
                    document.cookie = name + "=" + value + "; " + expires + (path.length > 0 ? "; path=" + path : "");
                    //document.cookie = name + "=" + value + "; path=" + path;
                };
                ResourceService.prototype.getCookie = function (name) {
                    //debugger;
                    var ca = document.cookie.split(';');
                    var caLen = ca.length;
                    var cookieName = name + "=";
                    var c;
                    for (var i = 0; i < caLen; i += 1) {
                        c = ca[i].replace(/^\s\+/g, "");
                        var index = c.indexOf(cookieName);
                        if (c.indexOf(cookieName) == 0) {
                            return c.substring(cookieName.length, c.length);
                        }
                        if (c.indexOf(cookieName) == 1 && cookieName == name + "=") {
                            return c.substring(cookieName.length, c.length);
                        }
                    }
                    return "";
                };
                ResourceService.prototype.deleteCookie = function (name) {
                    this.setCookie(name, "", -1);
                };
                ResourceService.prototype.LoadLanguageResource = function (code) {
                    if (code === void 0) { code = "he"; }
                    // the function is not in use
                };
                ResourceService.prototype.GetSelecetdLanguage = function (code) {
                    //debugger;
                    if (!code)
                        code = "en";
                    code = code.trim();
                    // debugger;
                    //,
                    //{ headers: this.headers }
                    return this._http.get("/src/lang/" + code + ".json")
                        .map(function (res) { return res.json(); });
                };
                ResourceService.prototype.GetAvailableLanguages = function () {
                    return [
                        { name: "English", code: "en" },
                        { name: "עִברִית", code: "he" }
                    ];
                };
                ResourceService.prototype.GetMenues = function () {
                    var _this = this;
                    var lang = this.getCookie("lang");
                    //alert(lang);
                    if (lang.length > 0)
                        lang = lang.substring(1, lang.length);
                    if (lang == "")
                        lang = "en";
                    return new Promise(function (resolve) {
                        return _this._http.get("/src/menu-" + lang + ".json", { headers: _this.headers })
                            .map(function (res) { return res.json().menu; })
                            .subscribe(function (menudata) {
                            resolve(menudata);
                        });
                    });
                };
                ResourceService.prototype.GetFormByName = function (formName) {
                    return this._http.get("/src/forms/" + formName + ".json", { headers: this.headers })
                        .map(function (res) { return res.json(); });
                    //return new Promise(resolve=>{
                    //    this._http.get("/src/forms/"+formName+".json",{headers:this.headers})
                    //        .map(res=>res.json())
                    //        .subscribe(data=>resolve(data));
                    //})
                };
                //localstorage utility
                ResourceService.prototype.GetLocalStorage = function (key) {
                    var data = localStorage.getItem(key);
                    return JSON.parse(data);
                };
                ResourceService.prototype.SetLocalStorage = function (key, data) {
                    localStorage.setItem(key, JSON.stringify(data));
                };
                //sessionStorage utility
                ResourceService.prototype.GetSessionStorage = function (key) {
                    var data = sessionStorage.getItem(key);
                    return JSON.parse(data);
                };
                ResourceService.prototype.SetSessionStorage = function (key, data) {
                    sessionStorage.setItem(key, JSON.stringify(data));
                };
                ResourceService.prototype.GetLangRes = function (FormType, Lang) {
                    //alert(FormType);
                    //debugger;
                    //var Lang = localStorage.getItem("lang");
                    return this._http.get(this.baseUrl + "Dropdown/GetLangRes?FormType=" + FormType + "&Lang=" + Lang, { headers: this.getHeader() }).map(function (res) { return res.text(); });
                };
                ResourceService = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [http_1.Http])
                ], ResourceService);
                return ResourceService;
            }());
            exports_1("ResourceService", ResourceService);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNlcnZpY2VzL1Jlc291cmNlU2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7WUFZQTtnQkFJSSx5QkFBb0IsS0FBVztvQkFBWCxVQUFLLEdBQUwsS0FBSyxDQUFNO29CQUMzQixJQUFJLENBQUMsT0FBTyxHQUFDLElBQUksY0FBTyxFQUFFLENBQUM7b0JBQzNCLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLGNBQWMsRUFBRSxrQkFBa0IsQ0FBQyxDQUFDO29CQUN4RCxJQUFJLENBQUMsT0FBTyxHQUFHLHlCQUFhLENBQUMsYUFBYSxDQUFDO29CQUMzQyxJQUFJLENBQUMsTUFBTSxHQUFHLHlCQUFhLENBQUMsTUFBTSxDQUFDO2dCQUN2QyxDQUFDO2dCQUtPLG1DQUFTLEdBQWpCO29CQUNJLElBQUksTUFBTSxHQUFHLElBQUksY0FBTyxFQUFFLENBQUM7b0JBQzNCLE1BQU0sQ0FBQyxNQUFNLENBQUMsY0FBYyxFQUFFLGtCQUFrQixDQUFDLENBQUM7b0JBQ2xELGtFQUFrRTtvQkFDbEUsc0hBQXNIO29CQUN0SCxVQUFVO29CQUNWLHlDQUF5QztvQkFDekMsR0FBRztvQkFDSCxNQUFNLENBQUMsTUFBTSxDQUFDO2dCQUNsQixDQUFDO2dCQUdNLG1DQUFTLEdBQWhCLFVBQWlCLElBQVksRUFBRSxLQUFhLEVBQUUsVUFBa0IsRUFBRSxJQUFpQjtvQkFBakIsb0JBQWlCLEdBQWpCLFNBQWlCO29CQUMvRSxXQUFXO29CQUNYLElBQUksQ0FBQyxHQUFTLElBQUksSUFBSSxFQUFFLENBQUM7b0JBQ3pCLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sRUFBRSxHQUFHLFVBQVUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUMsQ0FBQztvQkFDMUQsSUFBSSxPQUFPLEdBQVcsVUFBVSxHQUFHLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztvQkFDbkQsUUFBUSxDQUFDLE1BQU0sR0FBRyxJQUFJLEdBQUcsR0FBRyxHQUFHLEtBQUssR0FBRyxJQUFJLEdBQUcsT0FBTyxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLEdBQUcsU0FBUyxHQUFHLElBQUksR0FBRyxFQUFFLENBQUMsQ0FBQztvQkFFbEcsMERBQTBEO2dCQUM5RCxDQUFDO2dCQUVNLG1DQUFTLEdBQWhCLFVBQWlCLElBQVk7b0JBQ3pCLFdBQVc7b0JBQ1gsSUFBSSxFQUFFLEdBQWtCLFFBQVEsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUNuRCxJQUFJLEtBQUssR0FBVyxFQUFFLENBQUMsTUFBTSxDQUFDO29CQUM5QixJQUFJLFVBQVUsR0FBRyxJQUFJLEdBQUcsR0FBRyxDQUFDO29CQUM1QixJQUFJLENBQVMsQ0FBQztvQkFFZCxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUssRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7d0JBQ3hDLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQzt3QkFDaEMsSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQzt3QkFDbEMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDOzRCQUM3QixNQUFNLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQzt3QkFDcEQsQ0FBQzt3QkFDRCxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxVQUFVLElBQUksSUFBSSxHQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7NEJBQ3ZELE1BQU0sQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO3dCQUNwRCxDQUFDO29CQUNMLENBQUM7b0JBQ0QsTUFBTSxDQUFDLEVBQUUsQ0FBQztnQkFDZCxDQUFDO2dCQUVNLHNDQUFZLEdBQW5CLFVBQW9CLElBQUk7b0JBQ3BCLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNqQyxDQUFDO2dCQUdNLDhDQUFvQixHQUEzQixVQUE0QixJQUFtQjtvQkFBbkIsb0JBQW1CLEdBQW5CLFdBQW1CO29CQUMzQyw2QkFBNkI7Z0JBQ2pDLENBQUM7Z0JBR00sNkNBQW1CLEdBQTFCLFVBQTJCLElBQWE7b0JBQ3BDLFdBQVc7b0JBQ1gsRUFBRSxDQUFBLENBQUMsQ0FBQyxJQUFJLENBQUM7d0JBQUEsSUFBSSxHQUFDLElBQUksQ0FBQztvQkFDbkIsSUFBSSxHQUFHLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztvQkFDcEIsWUFBWTtvQkFDWCxHQUFHO29CQUNILDJCQUEyQjtvQkFDM0IsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUNqQixZQUFZLEdBQUMsSUFBSSxHQUFDLE9BQU8sQ0FBQzt5QkFDekIsR0FBRyxDQUNKLFVBQUEsR0FBRyxJQUFJLE9BQUEsR0FBRyxDQUFDLElBQUksRUFBRSxFQUFWLENBQVUsQ0FDaEIsQ0FBQztnQkFDVixDQUFDO2dCQUVNLCtDQUFxQixHQUE1QjtvQkFDSSxNQUFNLENBQUM7d0JBQ0gsRUFBQyxJQUFJLEVBQUMsU0FBUyxFQUFFLElBQUksRUFBQyxJQUFJLEVBQUM7d0JBQzNCLEVBQUMsSUFBSSxFQUFDLFNBQVMsRUFBRSxJQUFJLEVBQUMsSUFBSSxFQUFDO3FCQUM5QixDQUFDO2dCQUNOLENBQUM7Z0JBRU0sbUNBQVMsR0FBaEI7b0JBQUEsaUJBa0JDO29CQWhCRyxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUNsQyxjQUFjO29CQUNkLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO3dCQUNoQixJQUFJLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUMxQyxFQUFFLENBQUMsQ0FBQyxJQUFJLElBQUksRUFBRSxDQUFDO3dCQUNYLElBQUksR0FBRyxJQUFJLENBQUM7b0JBQ2hCLE1BQU0sQ0FBQyxJQUFJLE9BQU8sQ0FBQyxVQUFBLE9BQU87d0JBQ3RCLE9BQUEsS0FBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQ1YsWUFBWSxHQUFHLElBQUksR0FBQyxPQUFPLEVBQzNCLEVBQUUsT0FBTyxFQUFFLEtBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQzs2QkFDekIsR0FBRyxDQUFDLFVBQUEsR0FBRyxJQUFHLE9BQUEsR0FBRyxDQUFDLElBQUksRUFBRSxDQUFDLElBQUksRUFBZixDQUFlLENBQUM7NkJBQzFCLFNBQVMsQ0FBQyxVQUFBLFFBQVE7NEJBRWYsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUN0QixDQUFDLENBQUM7b0JBUE4sQ0FPTSxDQUNULENBQUE7Z0JBQ0wsQ0FBQztnQkFFTSx1Q0FBYSxHQUFwQixVQUFxQixRQUFlO29CQUNoQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsYUFBYSxHQUFDLFFBQVEsR0FBQyxPQUFPLEVBQUMsRUFBQyxPQUFPLEVBQUMsSUFBSSxDQUFDLE9BQU8sRUFBQyxDQUFDO3lCQUN2RSxHQUFHLENBQUMsVUFBQSxHQUFHLElBQUUsT0FBQSxHQUFHLENBQUMsSUFBSSxFQUFFLEVBQVYsQ0FBVSxDQUFDLENBQUM7b0JBRTFCLCtCQUErQjtvQkFDL0IsMkVBQTJFO29CQUMzRSwrQkFBK0I7b0JBQy9CLDBDQUEwQztvQkFDMUMsSUFBSTtnQkFDUixDQUFDO2dCQUVELHNCQUFzQjtnQkFDZix5Q0FBZSxHQUF0QixVQUF1QixHQUFXO29CQUM5QixJQUFJLElBQUksR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUNyQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDNUIsQ0FBQztnQkFDTSx5Q0FBZSxHQUF0QixVQUF1QixHQUFXLEVBQUUsSUFBUztvQkFDekMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUNwRCxDQUFDO2dCQUVELHdCQUF3QjtnQkFDakIsMkNBQWlCLEdBQXhCLFVBQXlCLEdBQVc7b0JBQ2hDLElBQUksSUFBSSxHQUFHLGNBQWMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUM7b0JBQ3ZDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUM1QixDQUFDO2dCQUNNLDJDQUFpQixHQUF4QixVQUF5QixHQUFXLEVBQUUsSUFBUztvQkFDM0MsY0FBYyxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUN0RCxDQUFDO2dCQUNNLG9DQUFVLEdBQWpCLFVBQWtCLFFBQWdCLEVBQUUsSUFBWTtvQkFDNUMsa0JBQWtCO29CQUNsQixXQUFXO29CQUNYLDBDQUEwQztvQkFDMUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUNqQixJQUFJLENBQUMsT0FBTyxHQUFHLCtCQUErQixHQUFHLFFBQVEsR0FBRyxRQUFRLEdBQUcsSUFBSSxFQUMzRSxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsU0FBUyxFQUFFLEVBQUUsQ0FDaEMsQ0FBQyxHQUFHLENBQUMsVUFBQSxHQUFHLElBQUcsT0FBQSxHQUFHLENBQUMsSUFBSSxFQUFFLEVBQVYsQ0FBVSxDQUFDLENBQUM7Z0JBQzVCLENBQUM7Z0JBaEpMO29CQUFDLGlCQUFVLEVBQUU7O21DQUFBO2dCQWlKYixzQkFBQztZQUFELENBaEpBLEFBZ0pDLElBQUE7WUFoSkQsNkNBZ0pDLENBQUEiLCJmaWxlIjoic2VydmljZXMvUmVzb3VyY2VTZXJ2aWNlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtJbmplY3RhYmxlfSBmcm9tIFwiYW5ndWxhcjIvY29yZVwiO1xyXG5pbXBvcnQge0h0dHAsIEhlYWRlcnN9IGZyb20gXCJhbmd1bGFyMi9odHRwXCI7XHJcbmltcG9ydCAncnhqcy9hZGQvb3BlcmF0b3IvbWFwJztcclxuaW1wb3J0IHtMb2NhbERpY3QsIGNybUNvbmZpZywgc2VydmljZUNvbmZpZ30gZnJvbSBcIi4uL2NybWNvbmZpZ1wiO1xyXG5leHBvcnQgaW50ZXJmYWNlIE1lbnVlSXRlbXtcclxuICAgIGxhYmVsOnN0cmluZyxcclxuICAgIHJvdXRlclVybDpzdHJpbmcsXHJcbiAgICBmYWljb24/OnN0cmluZyxcclxuICAgIHN1Yk1lbnVzPzpBcnJheTxNZW51ZUl0ZW0+XHJcbn1cclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIFJlc291cmNlU2VydmljZSB7XHJcbiAgICBoZWFkZXJzOiBIZWFkZXJzO1xyXG4gICAgQXBwVXJsOiBzdHJpbmc7XHJcbiAgICBiYXNlVXJsOiBzdHJpbmc7XHJcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIF9odHRwOiBIdHRwKSB7XHJcbiAgICAgICAgdGhpcy5oZWFkZXJzPW5ldyBIZWFkZXJzKCk7XHJcbiAgICAgICAgdGhpcy5oZWFkZXJzLmFwcGVuZChcIkNvbnRlbnQtVHlwZVwiLCBcImFwcGxpY2F0aW9uL2pzb25cIik7XHJcbiAgICAgICAgdGhpcy5iYXNlVXJsID0gc2VydmljZUNvbmZpZy5zZXJ2aWNlQXBpVXJsO1xyXG4gICAgICAgIHRoaXMuQXBwVXJsID0gc2VydmljZUNvbmZpZy5BcHBVcmw7XHJcbiAgICB9XHJcblxyXG5cclxuXHJcblxyXG4gICAgcHJpdmF0ZSBnZXRIZWFkZXIoKTogSGVhZGVycyB7XHJcbiAgICAgICAgdmFyIGhlYWRlciA9IG5ldyBIZWFkZXJzKCk7XHJcbiAgICAgICAgaGVhZGVyLmFwcGVuZChcIkNvbnRlbnQtVHlwZVwiLCBcImFwcGxpY2F0aW9uL2pzb25cIik7XHJcbiAgICAgICAgLy9pZiAoc2Vzc2lvblN0b3JhZ2UuZ2V0SXRlbShzZXJ2aWNlQ29uZmlnLmFjY2VzVG9rZW5TdG9yZU5hbWUpKSB7XHJcbiAgICAgICAgLy8gICAgaGVhZGVyLmFwcGVuZChzZXJ2aWNlQ29uZmlnLmFjY2VzVG9rZW5SZXF1ZXN0SGVhZGVyLCBzZXNzaW9uU3RvcmFnZS5nZXRJdGVtKHNlcnZpY2VDb25maWcuYWNjZXNUb2tlblN0b3JlTmFtZSkpO1xyXG4gICAgICAgIC8vfSBlbHNlIHtcclxuICAgICAgICAvLyAgICB0aHJvdyAnQWNjZXNzIHRva2VuIG5vdCBhdmFpbGFibGUnO1xyXG4gICAgICAgIC8vfVxyXG4gICAgICAgIHJldHVybiBoZWFkZXI7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIHB1YmxpYyBzZXRDb29raWUobmFtZTogc3RyaW5nLCB2YWx1ZTogT2JqZWN0LCBleHBpcmVEYXlzOiBudW1iZXIsIHBhdGg6IHN0cmluZyA9IFwiXCIpIHsgICAgICAgLypleHBpcmVEYXlzOiBudW1iZXIsKi9cclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgIGxldCBkOiBEYXRlID0gbmV3IERhdGUoKTtcclxuICAgICAgICBkLnNldFRpbWUoZC5nZXRUaW1lKCkgKyBleHBpcmVEYXlzICogMjQgKiA2MCAqIDYwICogMTAwMCk7XHJcbiAgICAgICAgbGV0IGV4cGlyZXM6IHN0cmluZyA9IFwiZXhwaXJlcz1cIiArIGQudG9VVENTdHJpbmcoKTtcclxuICAgICAgICBkb2N1bWVudC5jb29raWUgPSBuYW1lICsgXCI9XCIgKyB2YWx1ZSArIFwiOyBcIiArIGV4cGlyZXMgKyAocGF0aC5sZW5ndGggPiAwID8gXCI7IHBhdGg9XCIgKyBwYXRoIDogXCJcIik7XHJcblxyXG4gICAgICAgIC8vZG9jdW1lbnQuY29va2llID0gbmFtZSArIFwiPVwiICsgdmFsdWUgKyBcIjsgcGF0aD1cIiArIHBhdGg7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldENvb2tpZShuYW1lOiBzdHJpbmcpIHtcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgIGxldCBjYTogQXJyYXk8c3RyaW5nPiA9IGRvY3VtZW50LmNvb2tpZS5zcGxpdCgnOycpO1xyXG4gICAgICAgIGxldCBjYUxlbjogbnVtYmVyID0gY2EubGVuZ3RoO1xyXG4gICAgICAgIGxldCBjb29raWVOYW1lID0gbmFtZSArIFwiPVwiO1xyXG4gICAgICAgIGxldCBjOiBzdHJpbmc7XHJcblxyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBjYUxlbjsgaSArPSAxKSB7XHJcbiAgICAgICAgICAgIGMgPSBjYVtpXS5yZXBsYWNlKC9eXFxzXFwrL2csIFwiXCIpO1xyXG4gICAgICAgICAgICB2YXIgaW5kZXggPSBjLmluZGV4T2YoY29va2llTmFtZSk7XHJcbiAgICAgICAgICAgIGlmIChjLmluZGV4T2YoY29va2llTmFtZSkgPT0gMCkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGMuc3Vic3RyaW5nKGNvb2tpZU5hbWUubGVuZ3RoLCBjLmxlbmd0aCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKGMuaW5kZXhPZihjb29raWVOYW1lKSA9PSAxICYmIGNvb2tpZU5hbWUgPT0gbmFtZStcIj1cIikge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGMuc3Vic3RyaW5nKGNvb2tpZU5hbWUubGVuZ3RoLCBjLmxlbmd0aCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIFwiXCI7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGRlbGV0ZUNvb2tpZShuYW1lKSB7XHJcbiAgICAgICAgdGhpcy5zZXRDb29raWUobmFtZSwgXCJcIiwgLTEpO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICBwdWJsaWMgTG9hZExhbmd1YWdlUmVzb3VyY2UoY29kZTogc3RyaW5nID0gXCJoZVwiKSB7XHJcbiAgICAgICAgLy8gdGhlIGZ1bmN0aW9uIGlzIG5vdCBpbiB1c2VcclxuICAgIH1cclxuXHJcblxyXG4gICAgcHVibGljIEdldFNlbGVjZXRkTGFuZ3VhZ2UoY29kZT86IHN0cmluZykge1xyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgaWYoIWNvZGUpY29kZT1cImVuXCI7XHJcbiAgICAgICAgY29kZSA9IGNvZGUudHJpbSgpO1xyXG4gICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAgLy8sXHJcbiAgICAgICAgLy97IGhlYWRlcnM6IHRoaXMuaGVhZGVycyB9XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2h0dHAuZ2V0KFxyXG4gICAgICAgICAgICBcIi9zcmMvbGFuZy9cIitjb2RlK1wiLmpzb25cIilcclxuICAgICAgICAgICAgLm1hcChcclxuICAgICAgICAgICAgcmVzID0+IHJlcy5qc29uKClcclxuICAgICAgICAgICAgKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgR2V0QXZhaWxhYmxlTGFuZ3VhZ2VzKCk6W09iamVjdF17XHJcbiAgICAgICAgcmV0dXJuIFtcclxuICAgICAgICAgICAge25hbWU6XCJFbmdsaXNoXCIsIGNvZGU6XCJlblwifSxcclxuICAgICAgICAgICAge25hbWU6XCLXota015HXqNa015nXqlwiLCBjb2RlOlwiaGVcIn1cclxuICAgICAgICBdO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBHZXRNZW51ZXMoKSB7XHJcbiAgICAgICBcclxuICAgICAgICB2YXIgbGFuZyA9IHRoaXMuZ2V0Q29va2llKFwibGFuZ1wiKTtcclxuICAgICAgICAvL2FsZXJ0KGxhbmcpO1xyXG4gICAgICAgIGlmIChsYW5nLmxlbmd0aCA+IDApXHJcbiAgICAgICAgICAgIGxhbmcgPSBsYW5nLnN1YnN0cmluZygxLCBsYW5nLmxlbmd0aCk7XHJcbiAgICAgICAgaWYgKGxhbmcgPT0gXCJcIilcclxuICAgICAgICAgICAgbGFuZyA9IFwiZW5cIjtcclxuICAgICAgICByZXR1cm4gbmV3IFByb21pc2UocmVzb2x2ZT0+XHJcbiAgICAgICAgICAgIHRoaXMuX2h0dHAuZ2V0KFxyXG4gICAgICAgICAgICAgICAgXCIvc3JjL21lbnUtXCIgKyBsYW5nK1wiLmpzb25cIixcclxuICAgICAgICAgICAgICAgIHsgaGVhZGVyczogdGhpcy5oZWFkZXJzIH0pXHJcbiAgICAgICAgICAgICAgICAubWFwKHJlcyA9PnJlcy5qc29uKCkubWVudSlcclxuICAgICAgICAgICAgICAgIC5zdWJzY3JpYmUobWVudWRhdGE9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZShtZW51ZGF0YSk7XHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgIClcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgR2V0Rm9ybUJ5TmFtZShmb3JtTmFtZTpzdHJpbmcpe1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9odHRwLmdldChcIi9zcmMvZm9ybXMvXCIrZm9ybU5hbWUrXCIuanNvblwiLHtoZWFkZXJzOnRoaXMuaGVhZGVyc30pXHJcbiAgICAgICAgICAgIC5tYXAocmVzPT5yZXMuanNvbigpKTtcclxuXHJcbiAgICAgICAgLy9yZXR1cm4gbmV3IFByb21pc2UocmVzb2x2ZT0+e1xyXG4gICAgICAgIC8vICAgIHRoaXMuX2h0dHAuZ2V0KFwiL3NyYy9mb3Jtcy9cIitmb3JtTmFtZStcIi5qc29uXCIse2hlYWRlcnM6dGhpcy5oZWFkZXJzfSlcclxuICAgICAgICAvLyAgICAgICAgLm1hcChyZXM9PnJlcy5qc29uKCkpXHJcbiAgICAgICAgLy8gICAgICAgIC5zdWJzY3JpYmUoZGF0YT0+cmVzb2x2ZShkYXRhKSk7XHJcbiAgICAgICAgLy99KVxyXG4gICAgfVxyXG5cclxuICAgIC8vbG9jYWxzdG9yYWdlIHV0aWxpdHlcclxuICAgIHB1YmxpYyBHZXRMb2NhbFN0b3JhZ2Uoa2V5OiBzdHJpbmcpOiBhbnkge1xyXG4gICAgICAgIHZhciBkYXRhID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oa2V5KTtcclxuICAgICAgICByZXR1cm4gSlNPTi5wYXJzZShkYXRhKTtcclxuICAgIH1cclxuICAgIHB1YmxpYyBTZXRMb2NhbFN0b3JhZ2Uoa2V5OiBzdHJpbmcsIGRhdGE6IGFueSkge1xyXG4gICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKGtleSwgSlNPTi5zdHJpbmdpZnkoZGF0YSkpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vc2Vzc2lvblN0b3JhZ2UgdXRpbGl0eVxyXG4gICAgcHVibGljIEdldFNlc3Npb25TdG9yYWdlKGtleTogc3RyaW5nKTogYW55IHtcclxuICAgICAgICB2YXIgZGF0YSA9IHNlc3Npb25TdG9yYWdlLmdldEl0ZW0oa2V5KTtcclxuICAgICAgICByZXR1cm4gSlNPTi5wYXJzZShkYXRhKTtcclxuICAgIH1cclxuICAgIHB1YmxpYyBTZXRTZXNzaW9uU3RvcmFnZShrZXk6IHN0cmluZywgZGF0YTogYW55KSB7XHJcbiAgICAgICAgc2Vzc2lvblN0b3JhZ2Uuc2V0SXRlbShrZXksIEpTT04uc3RyaW5naWZ5KGRhdGEpKTtcclxuICAgIH1cclxuICAgIHB1YmxpYyBHZXRMYW5nUmVzKEZvcm1UeXBlOiBzdHJpbmcsIExhbmc6IHN0cmluZyk6IE9ic2VydmFibGUge1xyXG4gICAgICAgIC8vYWxlcnQoRm9ybVR5cGUpO1xyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgLy92YXIgTGFuZyA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwibGFuZ1wiKTtcclxuICAgICAgICByZXR1cm4gdGhpcy5faHR0cC5nZXQoXHJcbiAgICAgICAgICAgIHRoaXMuYmFzZVVybCArIFwiRHJvcGRvd24vR2V0TGFuZ1Jlcz9Gb3JtVHlwZT1cIiArIEZvcm1UeXBlICsgXCImTGFuZz1cIiArIExhbmcsXHJcbiAgICAgICAgICAgIHsgaGVhZGVyczogdGhpcy5nZXRIZWFkZXIoKSB9XHJcbiAgICAgICAgKS5tYXAocmVzPT4gcmVzLnRleHQoKSk7XHJcbiAgICB9XHJcbn0iXX0=
