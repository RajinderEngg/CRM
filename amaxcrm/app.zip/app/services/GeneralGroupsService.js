System.register(['angular2/core', 'angular2/http', 'rxjs/add/operator/map', '../crmconfig'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, http_1, crmconfig_1;
    var GeneralGroupsService;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (http_1_1) {
                http_1 = http_1_1;
            },
            function (_1) {},
            function (crmconfig_1_1) {
                crmconfig_1 = crmconfig_1_1;
            }],
        execute: function() {
            GeneralGroupsService = (function () {
                function GeneralGroupsService(http) {
                    this.http = http;
                    this.baseUrl = crmconfig_1.serviceConfig.serviceApiUrl;
                }
                GeneralGroupsService.prototype.getHeader = function () {
                    var header = new http_1.Headers();
                    header.append("Content-Type", "application/json");
                    if (sessionStorage.getItem(crmconfig_1.serviceConfig.accesTokenStoreName)) {
                        header.append(crmconfig_1.serviceConfig.accesTokenRequestHeader, sessionStorage.getItem(crmconfig_1.serviceConfig.accesTokenStoreName));
                    }
                    else {
                        throw 'Access token not available';
                    }
                    return header;
                };
                GeneralGroupsService.prototype.GetCompleteCustDet = function (GroupIds) {
                    //var Lang = localStorage.getItem("lang");
                    return this.http.get(this.baseUrl + "GeneralGroups/GetCustomersListOfGroups?GroupIds=" + GroupIds, { headers: this.getHeader() }).map(function (res) { return res.text(); });
                };
                GeneralGroupsService = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [http_1.Http])
                ], GeneralGroupsService);
                return GeneralGroupsService;
            }());
            exports_1("GeneralGroupsService", GeneralGroupsService);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNlcnZpY2VzL0dlbmVyYWxHcm91cHNTZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztZQU9BO2dCQUVJLDhCQUFvQixJQUFVO29CQUFWLFNBQUksR0FBSixJQUFJLENBQU07b0JBQzFCLElBQUksQ0FBQyxPQUFPLEdBQUcseUJBQWEsQ0FBQyxhQUFhLENBQUM7Z0JBQy9DLENBQUM7Z0JBRU8sd0NBQVMsR0FBakI7b0JBQ0ksSUFBSSxNQUFNLEdBQUcsSUFBSSxjQUFPLEVBQUUsQ0FBQztvQkFDM0IsTUFBTSxDQUFDLE1BQU0sQ0FBQyxjQUFjLEVBQUUsa0JBQWtCLENBQUMsQ0FBQztvQkFDbEQsRUFBRSxDQUFBLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyx5QkFBYSxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQSxDQUFDO3dCQUMxRCxNQUFNLENBQUMsTUFBTSxDQUFDLHlCQUFhLENBQUMsdUJBQXVCLEVBQUUsY0FBYyxDQUFDLE9BQU8sQ0FBQyx5QkFBYSxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQztvQkFDcEgsQ0FBQztvQkFBQSxJQUFJLENBQUMsQ0FBQzt3QkFDSCxNQUFNLDRCQUE0QixDQUFDO29CQUN2QyxDQUFDO29CQUNELE1BQU0sQ0FBQyxNQUFNLENBQUM7Z0JBQ2xCLENBQUM7Z0JBQ00saURBQWtCLEdBQXpCLFVBQTBCLFFBQVE7b0JBQzlCLDBDQUEwQztvQkFFMUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUNoQixJQUFJLENBQUMsT0FBTyxHQUFHLGtEQUFrRCxHQUFHLFFBQVEsRUFDNUUsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLFNBQVMsRUFBRSxFQUFFLENBQ2hDLENBQUMsR0FBRyxDQUFDLFVBQUEsR0FBRyxJQUFHLE9BQUEsR0FBRyxDQUFDLElBQUksRUFBRSxFQUFWLENBQVUsQ0FBQyxDQUFDO2dCQUM1QixDQUFDO2dCQXhCTDtvQkFBQyxpQkFBVSxFQUFFOzt3Q0FBQTtnQkF5QmIsMkJBQUM7WUFBRCxDQXhCQSxBQXdCQyxJQUFBO1lBeEJELHVEQXdCQyxDQUFBIiwiZmlsZSI6InNlcnZpY2VzL0dlbmVyYWxHcm91cHNTZXJ2aWNlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ2FuZ3VsYXIyL2NvcmUnO1xyXG5pbXBvcnQgeyBIdHRwLCBIZWFkZXJzICB9IGZyb20gJ2FuZ3VsYXIyL2h0dHAnO1xyXG5pbXBvcnQgJ3J4anMvYWRkL29wZXJhdG9yL21hcCc7XHJcbmltcG9ydCB7T2JzZXJ2YWJsZX0gZnJvbSBcInJ4anMvT2JzZXJ2YWJsZVwiO1xyXG5pbXBvcnQge3NlcnZpY2VDb25maWd9IGZyb20gJy4uL2NybWNvbmZpZyc7XHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBHZW5lcmFsR3JvdXBzU2VydmljZSB7XHJcbiAgICBiYXNlVXJsOiBzdHJpbmc7XHJcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIGh0dHA6IEh0dHApIHtcclxuICAgICAgICB0aGlzLmJhc2VVcmwgPSBzZXJ2aWNlQ29uZmlnLnNlcnZpY2VBcGlVcmw7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBnZXRIZWFkZXIoKTpIZWFkZXJze1xyXG4gICAgICAgIHZhciBoZWFkZXIgPSBuZXcgSGVhZGVycygpO1xyXG4gICAgICAgIGhlYWRlci5hcHBlbmQoXCJDb250ZW50LVR5cGVcIiwgXCJhcHBsaWNhdGlvbi9qc29uXCIpO1xyXG4gICAgICAgIGlmKHNlc3Npb25TdG9yYWdlLmdldEl0ZW0oc2VydmljZUNvbmZpZy5hY2Nlc1Rva2VuU3RvcmVOYW1lKSl7XHJcbiAgICAgICAgICAgIGhlYWRlci5hcHBlbmQoc2VydmljZUNvbmZpZy5hY2Nlc1Rva2VuUmVxdWVzdEhlYWRlciwgc2Vzc2lvblN0b3JhZ2UuZ2V0SXRlbShzZXJ2aWNlQ29uZmlnLmFjY2VzVG9rZW5TdG9yZU5hbWUpKTtcclxuICAgICAgICB9ZWxzZSB7XHJcbiAgICAgICAgICAgIHRocm93ICdBY2Nlc3MgdG9rZW4gbm90IGF2YWlsYWJsZSc7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBoZWFkZXI7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgR2V0Q29tcGxldGVDdXN0RGV0KEdyb3VwSWRzKTogT2JzZXJ2YWJsZSB7XHJcbiAgICAgICAgLy92YXIgTGFuZyA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwibGFuZ1wiKTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5nZXQoXHJcbiAgICAgICAgICAgIHRoaXMuYmFzZVVybCArIFwiR2VuZXJhbEdyb3Vwcy9HZXRDdXN0b21lcnNMaXN0T2ZHcm91cHM/R3JvdXBJZHM9XCIgKyBHcm91cElkcyxcclxuICAgICAgICAgICAgeyBoZWFkZXJzOiB0aGlzLmdldEhlYWRlcigpIH1cclxuICAgICAgICApLm1hcChyZXM9PiByZXMudGV4dCgpKTtcclxuICAgIH1cclxufSJdfQ==
