System.register(['angular2/core', "./ResourceService", "../crmconfig"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, ResourceService_1, crmconfig_1;
    var AmaxCrmSyinc;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (ResourceService_1_1) {
                ResourceService_1 = ResourceService_1_1;
            },
            function (crmconfig_1_1) {
                crmconfig_1 = crmconfig_1_1;
            }],
        execute: function() {
            AmaxCrmSyinc = (function () {
                function AmaxCrmSyinc(_resourceService) {
                    this._resourceService = _resourceService;
                    this.FormType = "SCREEN_SMS";
                }
                AmaxCrmSyinc.prototype.on = function (eventName, handler) {
                    document.addEventListener(eventName, function (e) { return handler(e['detail']); });
                };
                AmaxCrmSyinc.prototype.off = function (eventName, handler) {
                    document.removeEventListener(eventName, function (e) { return handler(e['detail']); });
                };
                AmaxCrmSyinc.prototype.emit = function (eventName, eventData) {
                    var evt = new CustomEvent(eventName, eventData);
                    evt.initCustomEvent(eventName, true, true, eventData);
                    document.dispatchEvent(evt);
                };
                AmaxCrmSyinc.prototype.storeLocal = function (key, value) {
                    localStorage.setItem(key, JSON.stringify(value));
                    this.emit('lsset.' + key, value);
                };
                AmaxCrmSyinc.prototype.storeSession = function (key, value) {
                    sessionStorage.setItem(key, JSON.stringify(value));
                    this.emit('ssset.' + key, value);
                };
                AmaxCrmSyinc.prototype.fetchLocal = function (key) {
                    return localStorage.getItem(key);
                };
                AmaxCrmSyinc.prototype.fetchSession = function (key) {
                    return localStorage.getItem(key);
                };
                AmaxCrmSyinc.prototype.fetchLocalJSON = function (key) {
                    return JSON.parse(this.fetchLocal(key));
                };
                AmaxCrmSyinc.prototype.fetchLocalEval = function (key) {
                    return eval(this.fetchLocal(key));
                };
                AmaxCrmSyinc.prototype.fetchLanguageResource = function (resourceName) {
                    //debugger;
                    var _resource; //= this.fetchLocalJSON(LocalDict.languageResource);
                    var languageCode = localStorage.getItem("lang");
                    this._resourceService.GetLangRes("SCREEN_SMS", languageCode).subscribe(function (response) {
                        //debugger;
                        response = $.parseJSON(response);
                        if (response.IsError == true) {
                            alert(response.ErrMsg);
                        }
                        else {
                            //localStorage.setItem("langresource", JSON.stringify(response.Data));
                            //localStorage.setItem("lang", evt.code);
                            _resource = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    if (_resource) {
                        try {
                            return _resource[resourceName];
                        }
                        catch (ex) {
                            console.error("Error while parsing resource!");
                            console.error(ex);
                            return false;
                        }
                    }
                    else {
                        var selectedLanguage = localStorage.getItem(crmconfig_1.LocalDict.selectedLanguage) || crmconfig_1.crmConfig.falbackLanguage;
                        localStorage.setItem(crmconfig_1.LocalDict.selectedLanguage, selectedLanguage);
                        this.loadLanguageResource(selectedLanguage);
                        return false;
                    }
                };
                AmaxCrmSyinc.prototype.loadLanguageResource = function (languageCode) {
                    var _this = this;
                    //this._resourceService.GetSelecetdLanguage(languageCode).subscribe(
                    //    data=> {
                    //        debugger;
                    //        this.storeLocal(LocalDict.languageResource,data);
                    //        localStorage.setItem(LocalDict.selectedLanguage,languageCode);
                    //    },
                    //    error=>{
                    //        console.error("Error while featching language json");
                    //        console.error(error);
                    //    },
                    //    ()=>{
                    //        console.log('Language resource compleate');
                    //    }
                    //);
                    languageCode = localStorage.getItem("lang");
                    this._resourceService.GetLangRes(this.FormType, languageCode).subscribe(function (response) {
                        // debugger;
                        response = $.parseJSON(response);
                        if (response.IsError == true) {
                            alert(response.ErrMsg);
                        }
                        else {
                            //localStorage.setItem("langresource", JSON.stringify(response.Data));
                            //localStorage.setItem("lang", evt.code);
                            //this.RES = response.Data;
                            _this.storeLocal(crmconfig_1.LocalDict.languageResource, response.Data);
                            localStorage.setItem(crmconfig_1.LocalDict.selectedLanguage, languageCode);
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxCrmSyinc.prototype.isRtl = function () {
                    //debugger;
                    var selectedLanguage = localStorage.getItem(crmconfig_1.LocalDict.selectedLanguage) || crmconfig_1.crmConfig.falbackLanguage;
                    switch (selectedLanguage) {
                        case "he":
                            return false;
                        default:
                            return true;
                    }
                    return true;
                };
                AmaxCrmSyinc = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [ResourceService_1.ResourceService])
                ], AmaxCrmSyinc);
                return AmaxCrmSyinc;
            }());
            exports_1("AmaxCrmSyinc", AmaxCrmSyinc);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNlcnZpY2VzL0FtYXhDcm1TeWluYy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztZQUtBO2dCQUNJLHNCQUFvQixnQkFBaUM7b0JBQWpDLHFCQUFnQixHQUFoQixnQkFBZ0IsQ0FBaUI7b0JBQ3JELGFBQVEsR0FBVyxZQUFZLENBQUM7Z0JBRHlCLENBQUM7Z0JBRTFELHlCQUFFLEdBQUYsVUFBRyxTQUFnQixFQUFFLE9BQVc7b0JBQzVCLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLEVBQUMsVUFBQyxDQUFDLElBQUksT0FBQSxPQUFPLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQXBCLENBQW9CLENBQUMsQ0FBQztnQkFDcEUsQ0FBQztnQkFFRCwwQkFBRyxHQUFILFVBQUksU0FBZ0IsRUFBRSxPQUFXO29CQUM3QixRQUFRLENBQUMsbUJBQW1CLENBQUMsU0FBUyxFQUFDLFVBQUMsQ0FBQyxJQUFJLE9BQUEsT0FBTyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFwQixDQUFvQixDQUFDLENBQUM7Z0JBQ3ZFLENBQUM7Z0JBRUQsMkJBQUksR0FBSixVQUFLLFNBQWdCLEVBQUUsU0FBYTtvQkFDaEMsSUFBSSxHQUFHLEdBQUcsSUFBSSxXQUFXLENBQUMsU0FBUyxFQUFFLFNBQVMsQ0FBQyxDQUFDO29CQUNoRCxHQUFHLENBQUMsZUFBZSxDQUFDLFNBQVMsRUFBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLFNBQVMsQ0FBQyxDQUFDO29CQUNuRCxRQUFRLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUNoQyxDQUFDO2dCQUVELGlDQUFVLEdBQVYsVUFBVyxHQUFVLEVBQUUsS0FBUztvQkFDNUIsWUFBWSxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO29CQUNqRCxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsR0FBQyxHQUFHLEVBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ2xDLENBQUM7Z0JBQ0QsbUNBQVksR0FBWixVQUFhLEdBQVUsRUFBRSxLQUFTO29CQUM5QixjQUFjLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7b0JBQ25ELElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxHQUFDLEdBQUcsRUFBQyxLQUFLLENBQUMsQ0FBQztnQkFDbEMsQ0FBQztnQkFFRCxpQ0FBVSxHQUFWLFVBQVcsR0FBVztvQkFFbEIsTUFBTSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ3JDLENBQUM7Z0JBQ0QsbUNBQVksR0FBWixVQUFhLEdBQVc7b0JBRXBCLE1BQU0sQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUNyQyxDQUFDO2dCQUVELHFDQUFjLEdBQWQsVUFBZSxHQUFXO29CQUV0QixNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7Z0JBQzVDLENBQUM7Z0JBQ0QscUNBQWMsR0FBZCxVQUFlLEdBQVU7b0JBQ3JCLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO2dCQUN0QyxDQUFDO2dCQUdELDRDQUFxQixHQUFyQixVQUFzQixZQUFvQjtvQkFDdEMsV0FBVztvQkFDWCxJQUFJLFNBQVMsQ0FBQyxDQUFDLG9EQUFvRDtvQkFDbkUsSUFBSSxZQUFZLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDaEQsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxZQUFZLEVBQUUsWUFBWSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFDM0UsV0FBVzt3QkFDWCxRQUFRLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDakMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDO3dCQUMzQixDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLHNFQUFzRTs0QkFDdEUseUNBQXlDOzRCQUN6QyxTQUFTLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzt3QkFHOUIsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFFSCxFQUFFLENBQUEsQ0FBQyxTQUFTLENBQUMsQ0FBQSxDQUFDO3dCQUNWLElBQUcsQ0FBQzs0QkFDQSxNQUFNLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQyxDQUFDO3dCQUNuQyxDQUFDO3dCQUFBLEtBQUssQ0FBQSxDQUFDLEVBQUUsQ0FBQyxDQUFBLENBQUM7NEJBQ1AsT0FBTyxDQUFDLEtBQUssQ0FBQywrQkFBK0IsQ0FBQyxDQUFDOzRCQUMvQyxPQUFPLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDOzRCQUNsQixNQUFNLENBQUMsS0FBSyxDQUFDO3dCQUNqQixDQUFDO29CQUNMLENBQUM7b0JBQ0QsSUFBSSxDQUFBLENBQUM7d0JBQ0QsSUFBSSxnQkFBZ0IsR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLHFCQUFTLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxxQkFBUyxDQUFDLGVBQWUsQ0FBQzt3QkFDckcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxxQkFBUyxDQUFDLGdCQUFnQixFQUFDLGdCQUFnQixDQUFDLENBQUM7d0JBRWxFLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO3dCQUM1QyxNQUFNLENBQUMsS0FBSyxDQUFBO29CQUNoQixDQUFDO2dCQUNMLENBQUM7Z0JBQ0QsMkNBQW9CLEdBQXBCLFVBQXFCLFlBQW1CO29CQUF4QyxpQkFrQ0M7b0JBakNHLG9FQUFvRTtvQkFDcEUsY0FBYztvQkFDZCxtQkFBbUI7b0JBQ25CLDJEQUEyRDtvQkFDM0Qsd0VBQXdFO29CQUN4RSxRQUFRO29CQUNSLGNBQWM7b0JBQ2QsK0RBQStEO29CQUMvRCwrQkFBK0I7b0JBQy9CLFFBQVE7b0JBQ1IsV0FBVztvQkFDWCxxREFBcUQ7b0JBQ3JELE9BQU87b0JBQ1AsSUFBSTtvQkFDSixZQUFZLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDNUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLFlBQVksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7d0JBQzdFLFlBQVk7d0JBQ1gsUUFBUSxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQ2pDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQzt3QkFDM0IsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixzRUFBc0U7NEJBQ3RFLHlDQUF5Qzs0QkFDekMsMkJBQTJCOzRCQUMzQixLQUFJLENBQUMsVUFBVSxDQUFDLHFCQUFTLENBQUMsZ0JBQWdCLEVBQUUsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDOzRCQUMzRCxZQUFZLENBQUMsT0FBTyxDQUFDLHFCQUFTLENBQUMsZ0JBQWdCLEVBQUUsWUFBWSxDQUFDLENBQUM7d0JBQ25FLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7Z0JBQ1AsQ0FBQztnQkFFRCw0QkFBSyxHQUFMO29CQUNJLFdBQVc7b0JBQ1gsSUFBSSxnQkFBZ0IsR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLHFCQUFTLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxxQkFBUyxDQUFDLGVBQWUsQ0FBQTtvQkFDcEcsTUFBTSxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQSxDQUFDO3dCQUN0QixLQUFLLElBQUk7NEJBQ0wsTUFBTSxDQUFDLEtBQUssQ0FBQzt3QkFDakI7NEJBQ0ksTUFBTSxDQUFDLElBQUksQ0FBQztvQkFDcEIsQ0FBQztvQkFDRCxNQUFNLENBQUMsSUFBSSxDQUFDO2dCQUNoQixDQUFDO2dCQW5JTDtvQkFBQyxpQkFBVSxFQUFFOztnQ0FBQTtnQkFvSWIsbUJBQUM7WUFBRCxDQW5JQSxBQW1JQyxJQUFBO1lBbklELHVDQW1JQyxDQUFBIiwiZmlsZSI6InNlcnZpY2VzL0FtYXhDcm1TeWluYy5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7SW5qZWN0YWJsZX0gZnJvbSAnYW5ndWxhcjIvY29yZSc7XHJcbmltcG9ydCB7UmVzb3VyY2VTZXJ2aWNlfSBmcm9tIFwiLi9SZXNvdXJjZVNlcnZpY2VcIjtcclxuaW1wb3J0IHtMb2NhbERpY3QsIGNybUNvbmZpZ30gZnJvbSBcIi4uL2NybWNvbmZpZ1wiO1xyXG5cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgQW1heENybVN5aW5jIHtcclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgX3Jlc291cmNlU2VydmljZTogUmVzb3VyY2VTZXJ2aWNlKSB7IH1cclxuICAgIEZvcm1UeXBlOiBzdHJpbmcgPSBcIlNDUkVFTl9TTVNcIjtcclxuICAgIG9uKGV2ZW50TmFtZTpzdHJpbmcsIGhhbmRsZXI6YW55KSB7XHJcbiAgICAgICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihldmVudE5hbWUsKGUpPT4gaGFuZGxlcihlWydkZXRhaWwnXSkpO1xyXG4gICAgfVxyXG5cclxuICAgIG9mZihldmVudE5hbWU6c3RyaW5nLCBoYW5kbGVyOmFueSkge1xyXG4gICAgICAgIGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoZXZlbnROYW1lLChlKT0+IGhhbmRsZXIoZVsnZGV0YWlsJ10pKTtcclxuICAgIH1cclxuXHJcbiAgICBlbWl0KGV2ZW50TmFtZTpzdHJpbmcsIGV2ZW50RGF0YTphbnkpIHtcclxuICAgICAgICB2YXIgZXZ0ID0gbmV3IEN1c3RvbUV2ZW50KGV2ZW50TmFtZSwgZXZlbnREYXRhKTtcclxuICAgICAgICBldnQuaW5pdEN1c3RvbUV2ZW50KGV2ZW50TmFtZSx0cnVlLHRydWUsZXZlbnREYXRhKTtcclxuICAgICAgICBkb2N1bWVudC5kaXNwYXRjaEV2ZW50KGV2dCk7XHJcbiAgICB9XHJcblxyXG4gICAgc3RvcmVMb2NhbChrZXk6c3RyaW5nLCB2YWx1ZTphbnkpe1xyXG4gICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKGtleSwgSlNPTi5zdHJpbmdpZnkodmFsdWUpKTtcclxuICAgICAgICB0aGlzLmVtaXQoJ2xzc2V0Licra2V5LHZhbHVlKTtcclxuICAgIH1cclxuICAgIHN0b3JlU2Vzc2lvbihrZXk6c3RyaW5nLCB2YWx1ZTphbnkpe1xyXG4gICAgICAgIHNlc3Npb25TdG9yYWdlLnNldEl0ZW0oa2V5LCBKU09OLnN0cmluZ2lmeSh2YWx1ZSkpO1xyXG4gICAgICAgIHRoaXMuZW1pdCgnc3NzZXQuJytrZXksdmFsdWUpO1xyXG4gICAgfVxyXG5cclxuICAgIGZldGNoTG9jYWwoa2V5OiBzdHJpbmcpOiBzdHJpbmd7XHJcbiAgICAgICAgXHJcbiAgICAgICAgcmV0dXJuIGxvY2FsU3RvcmFnZS5nZXRJdGVtKGtleSk7XHJcbiAgICB9XHJcbiAgICBmZXRjaFNlc3Npb24oa2V5OiBzdHJpbmcpOiBzdHJpbmd7XHJcbiAgICAgICAgXHJcbiAgICAgICAgcmV0dXJuIGxvY2FsU3RvcmFnZS5nZXRJdGVtKGtleSk7XHJcbiAgICB9XHJcblxyXG4gICAgZmV0Y2hMb2NhbEpTT04oa2V5OiBzdHJpbmcpOiBhbnl7XHJcbiAgICAgICAgXHJcbiAgICAgICAgcmV0dXJuIEpTT04ucGFyc2UodGhpcy5mZXRjaExvY2FsKGtleSkpO1xyXG4gICAgfVxyXG4gICAgZmV0Y2hMb2NhbEV2YWwoa2V5OnN0cmluZyk6YW55e1xyXG4gICAgICAgIHJldHVybiBldmFsKHRoaXMuZmV0Y2hMb2NhbChrZXkpKTtcclxuICAgIH1cclxuXHJcblxyXG4gICAgZmV0Y2hMYW5ndWFnZVJlc291cmNlKHJlc291cmNlTmFtZTogc3RyaW5nKTogYW55e1xyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgdmFyIF9yZXNvdXJjZTsgLy89IHRoaXMuZmV0Y2hMb2NhbEpTT04oTG9jYWxEaWN0Lmxhbmd1YWdlUmVzb3VyY2UpO1xyXG4gICAgICAgIHZhciBsYW5ndWFnZUNvZGUgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImxhbmdcIik7XHJcbiAgICAgICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLkdldExhbmdSZXMoXCJTQ1JFRU5fU01TXCIsIGxhbmd1YWdlQ29kZSkuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICByZXNwb25zZSA9ICQucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYWxlcnQocmVzcG9uc2UuRXJyTXNnKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIC8vbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJsYW5ncmVzb3VyY2VcIiwgSlNPTi5zdHJpbmdpZnkocmVzcG9uc2UuRGF0YSkpO1xyXG4gICAgICAgICAgICAgICAgLy9sb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImxhbmdcIiwgZXZ0LmNvZGUpO1xyXG4gICAgICAgICAgICAgICAgX3Jlc291cmNlID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgIC8vdGhpcy5zdG9yZUxvY2FsKExvY2FsRGljdC5sYW5ndWFnZVJlc291cmNlLCByZXNwb25zZS5EYXRhKTtcclxuICAgICAgICAgICAgICAgIC8vbG9jYWxTdG9yYWdlLnNldEl0ZW0oTG9jYWxEaWN0LnNlbGVjdGVkTGFuZ3VhZ2UsIGxhbmd1YWdlQ29kZSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGlmKF9yZXNvdXJjZSl7XHJcbiAgICAgICAgICAgIHRyeXtcclxuICAgICAgICAgICAgICAgIHJldHVybiBfcmVzb3VyY2VbcmVzb3VyY2VOYW1lXTtcclxuICAgICAgICAgICAgfWNhdGNoKGV4KXtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciB3aGlsZSBwYXJzaW5nIHJlc291cmNlIVwiKTtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZXgpO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2V7XHJcbiAgICAgICAgICAgIHZhciBzZWxlY3RlZExhbmd1YWdlID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oTG9jYWxEaWN0LnNlbGVjdGVkTGFuZ3VhZ2UpIHx8IGNybUNvbmZpZy5mYWxiYWNrTGFuZ3VhZ2U7XHJcbiAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKExvY2FsRGljdC5zZWxlY3RlZExhbmd1YWdlLHNlbGVjdGVkTGFuZ3VhZ2UpO1xyXG5cclxuICAgICAgICAgICAgdGhpcy5sb2FkTGFuZ3VhZ2VSZXNvdXJjZShzZWxlY3RlZExhbmd1YWdlKTtcclxuICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgbG9hZExhbmd1YWdlUmVzb3VyY2UobGFuZ3VhZ2VDb2RlOnN0cmluZyl7XHJcbiAgICAgICAgLy90aGlzLl9yZXNvdXJjZVNlcnZpY2UuR2V0U2VsZWNldGRMYW5ndWFnZShsYW5ndWFnZUNvZGUpLnN1YnNjcmliZShcclxuICAgICAgICAvLyAgICBkYXRhPT4ge1xyXG4gICAgICAgIC8vICAgICAgICBkZWJ1Z2dlcjtcclxuICAgICAgICAvLyAgICAgICAgdGhpcy5zdG9yZUxvY2FsKExvY2FsRGljdC5sYW5ndWFnZVJlc291cmNlLGRhdGEpO1xyXG4gICAgICAgIC8vICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShMb2NhbERpY3Quc2VsZWN0ZWRMYW5ndWFnZSxsYW5ndWFnZUNvZGUpO1xyXG4gICAgICAgIC8vICAgIH0sXHJcbiAgICAgICAgLy8gICAgZXJyb3I9PntcclxuICAgICAgICAvLyAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHdoaWxlIGZlYXRjaGluZyBsYW5ndWFnZSBqc29uXCIpO1xyXG4gICAgICAgIC8vICAgICAgICBjb25zb2xlLmVycm9yKGVycm9yKTtcclxuICAgICAgICAvLyAgICB9LFxyXG4gICAgICAgIC8vICAgICgpPT57XHJcbiAgICAgICAgLy8gICAgICAgIGNvbnNvbGUubG9nKCdMYW5ndWFnZSByZXNvdXJjZSBjb21wbGVhdGUnKTtcclxuICAgICAgICAvLyAgICB9XHJcbiAgICAgICAgLy8pO1xyXG4gICAgICAgIGxhbmd1YWdlQ29kZSA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwibGFuZ1wiKTtcclxuICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuR2V0TGFuZ1Jlcyh0aGlzLkZvcm1UeXBlLCBsYW5ndWFnZUNvZGUpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICAgICAgcmVzcG9uc2UgPSAkLnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGFsZXJ0KHJlc3BvbnNlLkVyck1zZyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAvL2xvY2FsU3RvcmFnZS5zZXRJdGVtKFwibGFuZ3Jlc291cmNlXCIsIEpTT04uc3RyaW5naWZ5KHJlc3BvbnNlLkRhdGEpKTtcclxuICAgICAgICAgICAgICAgIC8vbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJsYW5nXCIsIGV2dC5jb2RlKTtcclxuICAgICAgICAgICAgICAgIC8vdGhpcy5SRVMgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zdG9yZUxvY2FsKExvY2FsRGljdC5sYW5ndWFnZVJlc291cmNlLCByZXNwb25zZS5EYXRhKTtcclxuICAgICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKExvY2FsRGljdC5zZWxlY3RlZExhbmd1YWdlLCBsYW5ndWFnZUNvZGUpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIGlzUnRsKCk6IGJvb2xlYW57XHJcbiAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICB2YXIgc2VsZWN0ZWRMYW5ndWFnZSA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKExvY2FsRGljdC5zZWxlY3RlZExhbmd1YWdlKSB8fCBjcm1Db25maWcuZmFsYmFja0xhbmd1YWdlXHJcbiAgICAgICAgc3dpdGNoIChzZWxlY3RlZExhbmd1YWdlKXtcclxuICAgICAgICAgICAgY2FzZSBcImhlXCI6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICB9XHJcbn0iXX0=
