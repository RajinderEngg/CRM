System.register(['angular2/core', 'angular2/http', 'rxjs/add/operator/map', '../crmconfig'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, http_1, crmconfig_1;
    var ChargeCreditService;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (http_1_1) {
                http_1 = http_1_1;
            },
            function (_1) {},
            function (crmconfig_1_1) {
                crmconfig_1 = crmconfig_1_1;
            }],
        execute: function() {
            ChargeCreditService = (function () {
                function ChargeCreditService(http) {
                    this.http = http;
                    this.baseUrl = crmconfig_1.serviceConfig.serviceApiUrl;
                }
                ChargeCreditService.prototype.getHeader = function () {
                    var header = new http_1.Headers();
                    header.append("Content-Type", "application/json");
                    if (sessionStorage.getItem(crmconfig_1.serviceConfig.accesTokenStoreName)) {
                        header.append(crmconfig_1.serviceConfig.accesTokenRequestHeader, sessionStorage.getItem(crmconfig_1.serviceConfig.accesTokenStoreName));
                    }
                    else {
                        throw 'Access token not available';
                    }
                    return header;
                };
                ChargeCreditService.prototype.Save = function (SaveObject) {
                    return this.http.post(this.baseUrl + "CheargeCredit/GetChargeAshrait", //URL for the request
                    SaveObject, { headers: this.getHeader() } //{ headers: header }
                    ).map(function (res) { return res.text(); });
                };
                ChargeCreditService.prototype.BindTermDet = function (TermNo) {
                    return this.http.get(this.baseUrl + "CheargeCredit/GetTerminalDetByTermNo?TerminalNo=" + TermNo, { headers: this.getHeader() }).map(function (res) { return res.text(); });
                };
                ChargeCreditService.prototype.BindCurrencyList = function () {
                    return this.http.get(this.baseUrl + "Dropdown/BindCurrencyList", { headers: this.getHeader() }).map(function (res) { return res.text(); });
                };
                ChargeCreditService.prototype.BindCreditTypeList = function () {
                    return this.http.get(this.baseUrl + "Dropdown/BindCreditTypeList", { headers: this.getHeader() }).map(function (res) { return res.text(); });
                };
                ChargeCreditService.prototype.BindChargeTypeList = function () {
                    return this.http.get(this.baseUrl + "Dropdown/BindChargeTypeList", { headers: this.getHeader() }).map(function (res) { return res.text(); });
                };
                ChargeCreditService.prototype.BindYears = function () {
                    return this.http.get(this.baseUrl + "Dropdown/BindYears", { headers: this.getHeader() }).map(function (res) { return res.text(); });
                };
                ChargeCreditService.prototype.BindMonths = function () {
                    return this.http.get(this.baseUrl + "Dropdown/BindMonths", { headers: this.getHeader() }).map(function (res) { return res.text(); });
                };
                ChargeCreditService.prototype.GetWebServiceResponce = function (Url) {
                    return this.http.get(this.baseUrl + "CheargeCredit/GetWebServiceResponce?Url=" + url, { headers: this.getHeader() }).map(function (res) { return res.text(); });
                };
                ChargeCreditService.prototype.IsInsertTotblLastUpdate = function (CustomerId) {
                    return this.http.get(this.baseUrl + "CheargeCredit/IsInsertTotblLastUpdate?CustomerId=" + CustomerId, { headers: this.getHeader() }).map(function (res) { return res.text(); });
                };
                ChargeCreditService.prototype.InsertTotblLastUpdate = function (CustomerId, SumtoBill) {
                    return this.http.get(this.baseUrl + "CheargeCredit/InsertTotblLastUpdate?CustomerId=" + CustomerId + "&SumtoBill=" + SumtoBill, { headers: this.getHeader() }).map(function (res) { return res.text(); });
                };
                ChargeCreditService.prototype.UpdateOwnerId = function (CustomerId, OwnerId) {
                    return this.http.get(this.baseUrl + "CheargeCredit/UpdateOwnerId?CustomerId=" + CustomerId + "&OwnerId=" + OwnerId, { headers: this.getHeader() }).map(function (res) { return res.text(); });
                };
                ChargeCreditService.prototype.getPrint = function (DealNumber, TermNo) {
                    return this.http.get(this.baseUrl + "CheargeCredit/getPrint?DealNumber=" + DealNumber + "&TerminalNo=" + TermNo, { headers: this.getHeader() }).map(function (res) { return res.text(); });
                };
                ChargeCreditService = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [http_1.Http])
                ], ChargeCreditService);
                return ChargeCreditService;
            }());
            exports_1("ChargeCreditService", ChargeCreditService);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNlcnZpY2VzL0NoYXJnZUNyZWRpdFNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1lBT0E7Z0JBRUksNkJBQW9CLElBQVU7b0JBQVYsU0FBSSxHQUFKLElBQUksQ0FBTTtvQkFDMUIsSUFBSSxDQUFDLE9BQU8sR0FBRyx5QkFBYSxDQUFDLGFBQWEsQ0FBQztnQkFDL0MsQ0FBQztnQkFFTyx1Q0FBUyxHQUFqQjtvQkFDSSxJQUFJLE1BQU0sR0FBRyxJQUFJLGNBQU8sRUFBRSxDQUFDO29CQUMzQixNQUFNLENBQUMsTUFBTSxDQUFDLGNBQWMsRUFBRSxrQkFBa0IsQ0FBQyxDQUFDO29CQUNsRCxFQUFFLENBQUEsQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLHlCQUFhLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFBLENBQUM7d0JBQzFELE1BQU0sQ0FBQyxNQUFNLENBQUMseUJBQWEsQ0FBQyx1QkFBdUIsRUFBRSxjQUFjLENBQUMsT0FBTyxDQUFDLHlCQUFhLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDO29CQUNwSCxDQUFDO29CQUFBLElBQUksQ0FBQyxDQUFDO3dCQUNILE1BQU0sNEJBQTRCLENBQUM7b0JBQ3ZDLENBQUM7b0JBQ0QsTUFBTSxDQUFDLE1BQU0sQ0FBQztnQkFDbEIsQ0FBQztnQkFJTSxrQ0FBSSxHQUFYLFVBQVksVUFBa0I7b0JBQzFCLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FDakIsSUFBSSxDQUFDLE9BQU8sR0FBRyxnQ0FBZ0MsRUFBb0IscUJBQXFCO29CQUN4RixVQUFVLEVBQ1YsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLFNBQVMsRUFBRSxFQUFFLENBQWdDLHFCQUFxQjtxQkFFckYsQ0FBQyxHQUFHLENBQUMsVUFBQSxHQUFHLElBQUksT0FBQSxHQUFHLENBQUMsSUFBSSxFQUFFLEVBQVYsQ0FBVSxDQUFDLENBQUM7Z0JBQzdCLENBQUM7Z0JBTU0seUNBQVcsR0FBbEIsVUFBbUIsTUFBYztvQkFDN0IsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUNoQixJQUFJLENBQUMsT0FBTyxHQUFHLGtEQUFrRCxHQUFHLE1BQU0sRUFDMUUsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLFNBQVMsRUFBRSxFQUFFLENBQ2hDLENBQUMsR0FBRyxDQUFDLFVBQUEsR0FBRyxJQUFHLE9BQUEsR0FBRyxDQUFDLElBQUksRUFBRSxFQUFWLENBQVUsQ0FBQyxDQUFDO2dCQUM1QixDQUFDO2dCQUVNLDhDQUFnQixHQUF2QjtvQkFDSSxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQ2hCLElBQUksQ0FBQyxPQUFPLEdBQUcsMkJBQTJCLEVBQzFDLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxTQUFTLEVBQUUsRUFBRSxDQUNoQyxDQUFDLEdBQUcsQ0FBQyxVQUFBLEdBQUcsSUFBRyxPQUFBLEdBQUcsQ0FBQyxJQUFJLEVBQUUsRUFBVixDQUFVLENBQUMsQ0FBQztnQkFDNUIsQ0FBQztnQkFFTSxnREFBa0IsR0FBekI7b0JBQ0ksTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUNoQixJQUFJLENBQUMsT0FBTyxHQUFHLDZCQUE2QixFQUM1QyxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsU0FBUyxFQUFFLEVBQUUsQ0FDaEMsQ0FBQyxHQUFHLENBQUMsVUFBQSxHQUFHLElBQUcsT0FBQSxHQUFHLENBQUMsSUFBSSxFQUFFLEVBQVYsQ0FBVSxDQUFDLENBQUM7Z0JBQzVCLENBQUM7Z0JBQ00sZ0RBQWtCLEdBQXpCO29CQUNJLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FDaEIsSUFBSSxDQUFDLE9BQU8sR0FBRyw2QkFBNkIsRUFDNUMsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLFNBQVMsRUFBRSxFQUFFLENBQ2hDLENBQUMsR0FBRyxDQUFDLFVBQUEsR0FBRyxJQUFHLE9BQUEsR0FBRyxDQUFDLElBQUksRUFBRSxFQUFWLENBQVUsQ0FBQyxDQUFDO2dCQUM1QixDQUFDO2dCQUVNLHVDQUFTLEdBQWhCO29CQUNJLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FDaEIsSUFBSSxDQUFDLE9BQU8sR0FBRyxvQkFBb0IsRUFDbkMsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLFNBQVMsRUFBRSxFQUFFLENBQ2hDLENBQUMsR0FBRyxDQUFDLFVBQUEsR0FBRyxJQUFHLE9BQUEsR0FBRyxDQUFDLElBQUksRUFBRSxFQUFWLENBQVUsQ0FBQyxDQUFDO2dCQUM1QixDQUFDO2dCQUNNLHdDQUFVLEdBQWpCO29CQUNJLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FDaEIsSUFBSSxDQUFDLE9BQU8sR0FBRyxxQkFBcUIsRUFDcEMsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLFNBQVMsRUFBRSxFQUFFLENBQ2hDLENBQUMsR0FBRyxDQUFDLFVBQUEsR0FBRyxJQUFHLE9BQUEsR0FBRyxDQUFDLElBQUksRUFBRSxFQUFWLENBQVUsQ0FBQyxDQUFDO2dCQUM1QixDQUFDO2dCQUNNLG1EQUFxQixHQUE1QixVQUE2QixHQUFHO29CQUM1QixNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQ2hCLElBQUksQ0FBQyxPQUFPLEdBQUcsMENBQTBDLEdBQUMsR0FBRyxFQUM3RCxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsU0FBUyxFQUFFLEVBQUUsQ0FDaEMsQ0FBQyxHQUFHLENBQUMsVUFBQSxHQUFHLElBQUcsT0FBQSxHQUFHLENBQUMsSUFBSSxFQUFFLEVBQVYsQ0FBVSxDQUFDLENBQUM7Z0JBQzVCLENBQUM7Z0JBQ00scURBQXVCLEdBQTlCLFVBQStCLFVBQVU7b0JBQ3JDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FDaEIsSUFBSSxDQUFDLE9BQU8sR0FBRyxtREFBbUQsR0FBRyxVQUFVLEVBQy9FLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxTQUFTLEVBQUUsRUFBRSxDQUNoQyxDQUFDLEdBQUcsQ0FBQyxVQUFBLEdBQUcsSUFBRyxPQUFBLEdBQUcsQ0FBQyxJQUFJLEVBQUUsRUFBVixDQUFVLENBQUMsQ0FBQztnQkFDNUIsQ0FBQztnQkFDTSxtREFBcUIsR0FBNUIsVUFBNkIsVUFBVSxFQUFFLFNBQVM7b0JBQzlDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FDaEIsSUFBSSxDQUFDLE9BQU8sR0FBRyxpREFBaUQsR0FBRyxVQUFVLEdBQUcsYUFBYSxHQUFHLFNBQVMsRUFDekcsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLFNBQVMsRUFBRSxFQUFFLENBQ2hDLENBQUMsR0FBRyxDQUFDLFVBQUEsR0FBRyxJQUFHLE9BQUEsR0FBRyxDQUFDLElBQUksRUFBRSxFQUFWLENBQVUsQ0FBQyxDQUFDO2dCQUM1QixDQUFDO2dCQUNNLDJDQUFhLEdBQXBCLFVBQXFCLFVBQVUsRUFBRSxPQUFPO29CQUNwQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQ2hCLElBQUksQ0FBQyxPQUFPLEdBQUcseUNBQXlDLEdBQUcsVUFBVSxHQUFHLFdBQVcsR0FBRyxPQUFPLEVBQzdGLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxTQUFTLEVBQUUsRUFBRSxDQUNoQyxDQUFDLEdBQUcsQ0FBQyxVQUFBLEdBQUcsSUFBRyxPQUFBLEdBQUcsQ0FBQyxJQUFJLEVBQUUsRUFBVixDQUFVLENBQUMsQ0FBQztnQkFDNUIsQ0FBQztnQkFDTSxzQ0FBUSxHQUFmLFVBQWdCLFVBQVUsRUFBQyxNQUFNO29CQUM3QixNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQ2hCLElBQUksQ0FBQyxPQUFPLEdBQUcsb0NBQW9DLEdBQUcsVUFBVSxHQUFHLGNBQWMsR0FBRyxNQUFNLEVBQzFGLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxTQUFTLEVBQUUsRUFBRSxDQUNoQyxDQUFDLEdBQUcsQ0FBQyxVQUFBLEdBQUcsSUFBRyxPQUFBLEdBQUcsQ0FBQyxJQUFJLEVBQUUsRUFBVixDQUFVLENBQUMsQ0FBQztnQkFDNUIsQ0FBQztnQkFyR0w7b0JBQUMsaUJBQVUsRUFBRTs7dUNBQUE7Z0JBc0diLDBCQUFDO1lBQUQsQ0FyR0EsQUFxR0MsSUFBQTtZQXJHRCxxREFxR0MsQ0FBQSIsImZpbGUiOiJzZXJ2aWNlcy9DaGFyZ2VDcmVkaXRTZXJ2aWNlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ2FuZ3VsYXIyL2NvcmUnO1xyXG5pbXBvcnQgeyBIdHRwLCBIZWFkZXJzICB9IGZyb20gJ2FuZ3VsYXIyL2h0dHAnO1xyXG5pbXBvcnQgJ3J4anMvYWRkL29wZXJhdG9yL21hcCc7XHJcbmltcG9ydCB7T2JzZXJ2YWJsZX0gZnJvbSBcInJ4anMvT2JzZXJ2YWJsZVwiO1xyXG5pbXBvcnQge3NlcnZpY2VDb25maWd9IGZyb20gJy4uL2NybWNvbmZpZyc7XHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBDaGFyZ2VDcmVkaXRTZXJ2aWNlIHtcclxuICAgIGJhc2VVcmw6IHN0cmluZztcclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgaHR0cDogSHR0cCkge1xyXG4gICAgICAgIHRoaXMuYmFzZVVybCA9IHNlcnZpY2VDb25maWcuc2VydmljZUFwaVVybDtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIGdldEhlYWRlcigpOkhlYWRlcnN7XHJcbiAgICAgICAgdmFyIGhlYWRlciA9IG5ldyBIZWFkZXJzKCk7XHJcbiAgICAgICAgaGVhZGVyLmFwcGVuZChcIkNvbnRlbnQtVHlwZVwiLCBcImFwcGxpY2F0aW9uL2pzb25cIik7XHJcbiAgICAgICAgaWYoc2Vzc2lvblN0b3JhZ2UuZ2V0SXRlbShzZXJ2aWNlQ29uZmlnLmFjY2VzVG9rZW5TdG9yZU5hbWUpKXtcclxuICAgICAgICAgICAgaGVhZGVyLmFwcGVuZChzZXJ2aWNlQ29uZmlnLmFjY2VzVG9rZW5SZXF1ZXN0SGVhZGVyLCBzZXNzaW9uU3RvcmFnZS5nZXRJdGVtKHNlcnZpY2VDb25maWcuYWNjZXNUb2tlblN0b3JlTmFtZSkpO1xyXG4gICAgICAgIH1lbHNlIHtcclxuICAgICAgICAgICAgdGhyb3cgJ0FjY2VzcyB0b2tlbiBub3QgYXZhaWxhYmxlJztcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIGhlYWRlcjtcclxuICAgIH1cclxuXHJcbiAgICBcclxuXHJcbiAgICBwdWJsaWMgU2F2ZShTYXZlT2JqZWN0OiBzdHJpbmcpIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3QoXHJcbiAgICAgICAgICAgIHRoaXMuYmFzZVVybCArIFwiQ2hlYXJnZUNyZWRpdC9HZXRDaGFyZ2VBc2hyYWl0XCIsICAgICAgICAgICAgICAgICAgIC8vVVJMIGZvciB0aGUgcmVxdWVzdFxyXG4gICAgICAgICAgICBTYXZlT2JqZWN0LFxyXG4gICAgICAgICAgICB7IGhlYWRlcnM6IHRoaXMuZ2V0SGVhZGVyKCkgfSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy97IGhlYWRlcnM6IGhlYWRlciB9XHJcbiAgICAgICAgICAgIC8vSEVBREVSUyBmb3IgdGhlIHJlcXVlc3RcclxuICAgICAgICApLm1hcChyZXMgPT4gcmVzLnRleHQoKSk7XHJcbiAgICB9XHJcblxyXG4gICAgXHJcbiAgICBcclxuICAgIFxyXG5cclxuICAgIHB1YmxpYyBCaW5kVGVybURldChUZXJtTm86IHN0cmluZyk6IE9ic2VydmFibGUge1xyXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0KFxyXG4gICAgICAgICAgICB0aGlzLmJhc2VVcmwgKyBcIkNoZWFyZ2VDcmVkaXQvR2V0VGVybWluYWxEZXRCeVRlcm1Obz9UZXJtaW5hbE5vPVwiICsgVGVybU5vLFxyXG4gICAgICAgICAgICB7IGhlYWRlcnM6IHRoaXMuZ2V0SGVhZGVyKCkgfVxyXG4gICAgICAgICkubWFwKHJlcz0+IHJlcy50ZXh0KCkpO1xyXG4gICAgfVxyXG4gICBcclxuICAgIHB1YmxpYyBCaW5kQ3VycmVuY3lMaXN0KCk6IE9ic2VydmFibGUge1xyXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0KFxyXG4gICAgICAgICAgICB0aGlzLmJhc2VVcmwgKyBcIkRyb3Bkb3duL0JpbmRDdXJyZW5jeUxpc3RcIixcclxuICAgICAgICAgICAgeyBoZWFkZXJzOiB0aGlzLmdldEhlYWRlcigpIH1cclxuICAgICAgICApLm1hcChyZXM9PiByZXMudGV4dCgpKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgQmluZENyZWRpdFR5cGVMaXN0KCk6IE9ic2VydmFibGUge1xyXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0KFxyXG4gICAgICAgICAgICB0aGlzLmJhc2VVcmwgKyBcIkRyb3Bkb3duL0JpbmRDcmVkaXRUeXBlTGlzdFwiLFxyXG4gICAgICAgICAgICB7IGhlYWRlcnM6IHRoaXMuZ2V0SGVhZGVyKCkgfVxyXG4gICAgICAgICkubWFwKHJlcz0+IHJlcy50ZXh0KCkpO1xyXG4gICAgfVxyXG4gICAgcHVibGljIEJpbmRDaGFyZ2VUeXBlTGlzdCgpOiBPYnNlcnZhYmxlIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLmdldChcclxuICAgICAgICAgICAgdGhpcy5iYXNlVXJsICsgXCJEcm9wZG93bi9CaW5kQ2hhcmdlVHlwZUxpc3RcIixcclxuICAgICAgICAgICAgeyBoZWFkZXJzOiB0aGlzLmdldEhlYWRlcigpIH1cclxuICAgICAgICApLm1hcChyZXM9PiByZXMudGV4dCgpKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgQmluZFllYXJzKCk6IE9ic2VydmFibGUge1xyXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0KFxyXG4gICAgICAgICAgICB0aGlzLmJhc2VVcmwgKyBcIkRyb3Bkb3duL0JpbmRZZWFyc1wiLFxyXG4gICAgICAgICAgICB7IGhlYWRlcnM6IHRoaXMuZ2V0SGVhZGVyKCkgfVxyXG4gICAgICAgICkubWFwKHJlcz0+IHJlcy50ZXh0KCkpO1xyXG4gICAgfVxyXG4gICAgcHVibGljIEJpbmRNb250aHMoKTogT2JzZXJ2YWJsZSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5nZXQoXHJcbiAgICAgICAgICAgIHRoaXMuYmFzZVVybCArIFwiRHJvcGRvd24vQmluZE1vbnRoc1wiLFxyXG4gICAgICAgICAgICB7IGhlYWRlcnM6IHRoaXMuZ2V0SGVhZGVyKCkgfVxyXG4gICAgICAgICkubWFwKHJlcz0+IHJlcy50ZXh0KCkpO1xyXG4gICAgfVxyXG4gICAgcHVibGljIEdldFdlYlNlcnZpY2VSZXNwb25jZShVcmwpOiBPYnNlcnZhYmxlIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLmdldChcclxuICAgICAgICAgICAgdGhpcy5iYXNlVXJsICsgXCJDaGVhcmdlQ3JlZGl0L0dldFdlYlNlcnZpY2VSZXNwb25jZT9Vcmw9XCIrdXJsLFxyXG4gICAgICAgICAgICB7IGhlYWRlcnM6IHRoaXMuZ2V0SGVhZGVyKCkgfVxyXG4gICAgICAgICkubWFwKHJlcz0+IHJlcy50ZXh0KCkpO1xyXG4gICAgfVxyXG4gICAgcHVibGljIElzSW5zZXJ0VG90YmxMYXN0VXBkYXRlKEN1c3RvbWVySWQpOiBPYnNlcnZhYmxlIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLmdldChcclxuICAgICAgICAgICAgdGhpcy5iYXNlVXJsICsgXCJDaGVhcmdlQ3JlZGl0L0lzSW5zZXJ0VG90YmxMYXN0VXBkYXRlP0N1c3RvbWVySWQ9XCIgKyBDdXN0b21lcklkLFxyXG4gICAgICAgICAgICB7IGhlYWRlcnM6IHRoaXMuZ2V0SGVhZGVyKCkgfVxyXG4gICAgICAgICkubWFwKHJlcz0+IHJlcy50ZXh0KCkpO1xyXG4gICAgfVxyXG4gICAgcHVibGljIEluc2VydFRvdGJsTGFzdFVwZGF0ZShDdXN0b21lcklkLCBTdW10b0JpbGwpOiBPYnNlcnZhYmxlIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLmdldChcclxuICAgICAgICAgICAgdGhpcy5iYXNlVXJsICsgXCJDaGVhcmdlQ3JlZGl0L0luc2VydFRvdGJsTGFzdFVwZGF0ZT9DdXN0b21lcklkPVwiICsgQ3VzdG9tZXJJZCArIFwiJlN1bXRvQmlsbD1cIiArIFN1bXRvQmlsbCxcclxuICAgICAgICAgICAgeyBoZWFkZXJzOiB0aGlzLmdldEhlYWRlcigpIH1cclxuICAgICAgICApLm1hcChyZXM9PiByZXMudGV4dCgpKTtcclxuICAgIH1cclxuICAgIHB1YmxpYyBVcGRhdGVPd25lcklkKEN1c3RvbWVySWQsIE93bmVySWQpOiBPYnNlcnZhYmxlIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLmdldChcclxuICAgICAgICAgICAgdGhpcy5iYXNlVXJsICsgXCJDaGVhcmdlQ3JlZGl0L1VwZGF0ZU93bmVySWQ/Q3VzdG9tZXJJZD1cIiArIEN1c3RvbWVySWQgKyBcIiZPd25lcklkPVwiICsgT3duZXJJZCxcclxuICAgICAgICAgICAgeyBoZWFkZXJzOiB0aGlzLmdldEhlYWRlcigpIH1cclxuICAgICAgICApLm1hcChyZXM9PiByZXMudGV4dCgpKTtcclxuICAgIH1cclxuICAgIHB1YmxpYyBnZXRQcmludChEZWFsTnVtYmVyLFRlcm1Obyk6IE9ic2VydmFibGUge1xyXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0KFxyXG4gICAgICAgICAgICB0aGlzLmJhc2VVcmwgKyBcIkNoZWFyZ2VDcmVkaXQvZ2V0UHJpbnQ/RGVhbE51bWJlcj1cIiArIERlYWxOdW1iZXIgKyBcIiZUZXJtaW5hbE5vPVwiICsgVGVybU5vLFxyXG4gICAgICAgICAgICB7IGhlYWRlcnM6IHRoaXMuZ2V0SGVhZGVyKCkgfVxyXG4gICAgICAgICkubWFwKHJlcz0+IHJlcy50ZXh0KCkpO1xyXG4gICAgfVxyXG59Il19
