System.register(['angular2/core', 'angular2/http', 'rxjs/add/operator/map', '../crmconfig'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, http_1, crmconfig_1;
    var AmaxService;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (http_1_1) {
                http_1 = http_1_1;
            },
            function (_1) {},
            function (crmconfig_1_1) {
                crmconfig_1 = crmconfig_1_1;
            }],
        execute: function() {
            AmaxService = (function () {
                function AmaxService(http) {
                    this.http = http;
                    this.baseUrl = crmconfig_1.serviceConfig.serviceApiUrl;
                }
                AmaxService.prototype.getHeader = function () {
                    //debugger;
                    var header = new http_1.Headers();
                    header.append("Content-Type", "application/json; charset=utf-8");
                    if (sessionStorage.getItem(crmconfig_1.serviceConfig.accesTokenStoreName)) {
                        header.append(crmconfig_1.serviceConfig.accesTokenRequestHeader, sessionStorage.getItem(crmconfig_1.serviceConfig.accesTokenStoreName));
                    }
                    else {
                        throw 'Access token not available';
                    }
                    return header;
                };
                AmaxService.prototype.validateLogin = function (UserID, Password, OrganizationName, rememberMe) {
                    //debugger;
                    var lang = "en";
                    var Language = localStorage.getItem("lang");
                    if (Language != "" && Language != null)
                        lang = Language;
                    var userInfo = {
                        OrgId: OrganizationName,
                        UserName: UserID,
                        Password: Password,
                        Language: lang
                    };
                    var header = new http_1.Headers();
                    header.append("Content-Type", "application/x-www-form-urlencoded");
                    // header.append("Data-Type", "json");
                    //header.append("Content-Type", "text/plain");
                    var jdata = jQuery.param(userInfo);
                    //debugger;
                    return this.http.post((this.baseUrl + "Service/Login"), //URL for the request
                    jdata, //Data for the request
                    { headers: header } //HEADERS for the request
                    ).map(function (res) { return res.text(); });
                };
                AmaxService.prototype.GetReport = function (ReportName, parameters) {
                    var header = new http_1.Headers();
                    header.append("Content-Type", "application/x-www-form-urlencoded");
                    var reportinfo = {
                        ReportName: ReportName,
                        Parameters: parameters
                    };
                    var jdata = jQuery.param(reportinfo);
                    return this.http.post(this.baseUrl + "Service/AmaxReportingService", jdata, { headers: header }).map(function (res) { return res.json().data; });
                };
                AmaxService.prototype.ExecuteJson = function (jsonQData) {
                    var header = new http_1.Headers();
                    header.append("Content-Type", "application/x-www-form-urlencoded");
                    var jdata = jQuery.param(jsonQData);
                    return this.http.post(this.baseUrl + "Service/ExecuteJson", jdata, { headers: header }).map(function (res) { return res.json().data; });
                };
                //Queryes
                AmaxService.prototype.GetDataFromServer = function (query) {
                    // debugger;
                    var params = JSON.stringify(query);
                    return this.http.post(this.baseUrl + "Service/DevQuery", params, { headers: this.getHeader() }).map(function (res) { return res.text(); });
                };
                AmaxService.prototype.GetGeneralGroupData = function () {
                    //debugger;
                    var GetGeneralGroupData = {
                        uqery: "SELECT GroupId, GroupName, GroupNameEng, GroupParenCategory FROM CustomerGroupsGeneral WHERE ( IsSupport = 0 and Ishide = 0 and SecurityLevel <= 10) ORDER BY GroupName",
                        parameters: {}
                    };
                    var jdata = JSON.stringify(GetGeneralGroupData);
                    return this.http.post(this.baseUrl + "Service/DevQuery", jdata, { headers: this.getHeader() }).map(function (res) { return res.json().data; });
                };
                AmaxService.prototype.GetGeneralGroupTree = function () {
                    //debugger;
                    var lang = localStorage.getItem("lang");
                    var req = '{"Lang":"' + lang + '"}';
                    return this.http.post(this.baseUrl + "Service/GetTreeData", req, { headers: this.getHeader() }).map(function (res) { return res.text(); });
                    //alert(rest);
                    //return rest.kendoTree;
                };
                //public SendSms(username: string, company: string, message: string, groups: Array<number>, phoneTypeId: number) {
                //    //debugger;
                //    var header = new Headers();
                //    header.append("Content-Type", "application/x-www-form-urlencoded");
                //    var smsdet = {
                //        username: username,
                //        company: company,
                //        message: message,
                //        groups: groups,
                //        phoneType: phoneTypeId
                //    }
                //    var jdata = JSON.stringify(smsdet);
                //    return this.http.post(
                //        this.baseUrl + "Service/SendSms",
                //        //jQuery.param({
                //        //    username: username,
                //        //    company: company,
                //        //    message: message,
                //        //    groups: groups,
                //        //    phoneType: phoneTypeId
                //        //}),
                //        jdata,
                //        { headers: this.getHeader()  }
                //    ).map(res=> res.text());
                //}
                AmaxService.prototype.SendSms = function (username, company, message, groups, phoneTypeId, providerId, returnBalanceAndCustomerCount, isConfirmed, SenderPhoneNumber, sendlater) {
                    if (isConfirmed === void 0) { isConfirmed = false; }
                    if (SenderPhoneNumber === void 0) { SenderPhoneNumber = ""; }
                    if (sendlater === void 0) { sendlater = ""; }
                    var IsBranchEnabled = localStorage.getItem("IsBranchEnabled");
                    var Branchid = localStorage.getItem("Branchid");
                    return this.http.post(this.baseUrl + "Service/SendSms", JSON.stringify({
                        username: username,
                        company: company,
                        message: message,
                        groups: groups,
                        phoneType: phoneTypeId,
                        providerId: providerId,
                        returnBalanceAndCustomerCount: returnBalanceAndCustomerCount,
                        isConfirmed: isConfirmed,
                        SenderPhoneNumber: SenderPhoneNumber,
                        sendlater: sendlater,
                        IsBranchEnabled: IsBranchEnabled,
                        Branchid: Branchid
                    }), { headers: this.getHeader() }).map(function (res) { return res.text(); });
                };
                AmaxService.prototype.ExecuteDataService = function (query, parameters) {
                    return this.http.post(this.baseUrl + "Service/ExecuteDataService", JSON.stringify({ query: query, parameters: parameters }), { headers: this.getHeader() }).map(function (res) { return res.text(); });
                };
                //Utility service
                AmaxService.prototype.CreateCatche = function () {
                    this.ExecuteDataService("InitalizeCRM", {}).subscribe(function (initialData) {
                        localStorage.setItem('SmsCompanyList', JSON.stringify(initialData["SmsCompanyList"]));
                        localStorage.setItem('CellPhoneTypeList', JSON.stringify(initialData["CellPhoneTypeList"]));
                        localStorage.setItem('PhoneTypeList', JSON.stringify(initialData["PhoneTypeList"]));
                        localStorage.setItem('GeneralGroupData', JSON.stringify(initialData["GeneralGroupData"]));
                    }, function (error) {
                        console.log(error);
                        localStorage.clear();
                        sessionStorage.clear();
                    }, function () { });
                };
                AmaxService = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [http_1.Http])
                ], AmaxService);
                return AmaxService;
            }());
            exports_1("AmaxService", AmaxService);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNlcnZpY2VzL0FtYXhTZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztZQVNBO2dCQUVJLHFCQUFvQixJQUFVO29CQUFWLFNBQUksR0FBSixJQUFJLENBQU07b0JBQzFCLElBQUksQ0FBQyxPQUFPLEdBQUcseUJBQWEsQ0FBQyxhQUFhLENBQUM7Z0JBQy9DLENBQUM7Z0JBRU8sK0JBQVMsR0FBakI7b0JBQ0ksV0FBVztvQkFDWCxJQUFJLE1BQU0sR0FBRyxJQUFJLGNBQU8sRUFBRSxDQUFDO29CQUMzQixNQUFNLENBQUMsTUFBTSxDQUFDLGNBQWMsRUFBRSxpQ0FBaUMsQ0FBQyxDQUFDO29CQUNqRSxFQUFFLENBQUMsQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLHlCQUFhLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQzVELE1BQU0sQ0FBQyxNQUFNLENBQUMseUJBQWEsQ0FBQyx1QkFBdUIsRUFBRSxjQUFjLENBQUMsT0FBTyxDQUFDLHlCQUFhLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDO29CQUNwSCxDQUFDO29CQUFDLElBQUksQ0FBQyxDQUFDO3dCQUNKLE1BQU0sNEJBQTRCLENBQUM7b0JBQ3ZDLENBQUM7b0JBQ0QsTUFBTSxDQUFDLE1BQU0sQ0FBQztnQkFDbEIsQ0FBQztnQkFFTSxtQ0FBYSxHQUFwQixVQUFxQixNQUFjLEVBQUUsUUFBZ0IsRUFBRSxnQkFBd0IsRUFBRSxVQUFvQjtvQkFDakcsV0FBVztvQkFDWCxJQUFJLElBQUksR0FBRyxJQUFJLENBQUM7b0JBQ2hCLElBQUksUUFBUSxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQzVDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsSUFBSSxFQUFFLElBQUksUUFBUSxJQUFJLElBQUksQ0FBQzt3QkFDbkMsSUFBSSxHQUFHLFFBQVEsQ0FBQztvQkFDcEIsSUFBSSxRQUFRLEdBQUc7d0JBQ1gsS0FBSyxFQUFFLGdCQUFnQjt3QkFDdkIsUUFBUSxFQUFFLE1BQU07d0JBQ2hCLFFBQVEsRUFBRSxRQUFRO3dCQUNsQixRQUFRLEVBQUUsSUFBSTtxQkFFakIsQ0FBQTtvQkFDRCxJQUFJLE1BQU0sR0FBRyxJQUFJLGNBQU8sRUFBRSxDQUFDO29CQUMzQixNQUFNLENBQUMsTUFBTSxDQUFDLGNBQWMsRUFBRSxtQ0FBbUMsQ0FBQyxDQUFDO29CQUNuRSxzQ0FBc0M7b0JBQ3RDLDhDQUE4QztvQkFHOUMsSUFBSSxLQUFLLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFDbkMsV0FBVztvQkFDWCxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQ2pCLENBQUMsSUFBSSxDQUFDLE9BQU8sR0FBRyxlQUFlLENBQUMsRUFBc0IscUJBQXFCO29CQUMzRSxLQUFLLEVBQW9CLHNCQUFzQjtvQkFDL0MsRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLENBQXlCLHlCQUF5QjtxQkFDeEUsQ0FBQyxHQUFHLENBQUMsVUFBQSxHQUFHLElBQUksT0FBQSxHQUFHLENBQUMsSUFBSSxFQUFFLEVBQVYsQ0FBVSxDQUFDLENBQUM7Z0JBSTdCLENBQUM7Z0JBRU0sK0JBQVMsR0FBaEIsVUFBaUIsVUFBa0IsRUFBRSxVQUFrQjtvQkFDbkQsSUFBSSxNQUFNLEdBQUcsSUFBSSxjQUFPLEVBQUUsQ0FBQztvQkFDM0IsTUFBTSxDQUFDLE1BQU0sQ0FBQyxjQUFjLEVBQUUsbUNBQW1DLENBQUMsQ0FBQztvQkFDbkUsSUFBSSxVQUFVLEdBQUc7d0JBQ2IsVUFBVSxFQUFFLFVBQVU7d0JBQ3RCLFVBQVUsRUFBRSxVQUFVO3FCQUN6QixDQUFBO29CQUNELElBQUksS0FBSyxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUM7b0JBQ3JDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FDakIsSUFBSSxDQUFDLE9BQU8sR0FBRyw4QkFBOEIsRUFDN0MsS0FBSyxFQUNMLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxDQUN0QixDQUFDLEdBQUcsQ0FBQyxVQUFBLEdBQUcsSUFBRyxPQUFBLEdBQUcsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxJQUFJLEVBQWYsQ0FBZSxDQUFDLENBQUM7Z0JBQ2pDLENBQUM7Z0JBRU0saUNBQVcsR0FBbEIsVUFBbUIsU0FBYztvQkFDN0IsSUFBSSxNQUFNLEdBQUcsSUFBSSxjQUFPLEVBQUUsQ0FBQztvQkFDM0IsTUFBTSxDQUFDLE1BQU0sQ0FBQyxjQUFjLEVBQUUsbUNBQW1DLENBQUMsQ0FBQztvQkFDbkUsSUFBSSxLQUFLLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQztvQkFDcEMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUNqQixJQUFJLENBQUMsT0FBTyxHQUFHLHFCQUFxQixFQUNwQyxLQUFLLEVBQ0wsRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLENBQ3RCLENBQUMsR0FBRyxDQUFDLFVBQUEsR0FBRyxJQUFHLE9BQUEsR0FBRyxDQUFDLElBQUksRUFBRSxDQUFDLElBQUksRUFBZixDQUFlLENBQUMsQ0FBQztnQkFDakMsQ0FBQztnQkFHRCxTQUFTO2dCQUNGLHVDQUFpQixHQUF4QixVQUF5QixLQUFLO29CQUMxQixZQUFZO29CQUVaLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBRW5DLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FDakIsSUFBSSxDQUFDLE9BQU8sR0FBRyxrQkFBa0IsRUFDakMsTUFBTSxFQUNOLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxTQUFTLEVBQUUsRUFBRSxDQUNoQyxDQUFDLEdBQUcsQ0FBQyxVQUFBLEdBQUcsSUFBRyxPQUFBLEdBQUcsQ0FBQyxJQUFJLEVBQUUsRUFBVixDQUFVLENBQUMsQ0FBQztnQkFDNUIsQ0FBQztnQkFFTSx5Q0FBbUIsR0FBMUI7b0JBQ0ksV0FBVztvQkFDWCxJQUFJLG1CQUFtQixHQUFHO3dCQUN0QixLQUFLLEVBQUUseUtBQXlLO3dCQUNoTCxVQUFVLEVBQUUsRUFBRTtxQkFDakIsQ0FBQTtvQkFDRCxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLG1CQUFtQixDQUFDLENBQUM7b0JBQ2hELE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FDakIsSUFBSSxDQUFDLE9BQU8sR0FBRyxrQkFBa0IsRUFDakMsS0FBSyxFQUNMLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxTQUFTLEVBQUUsRUFBRSxDQUNoQyxDQUFDLEdBQUcsQ0FBQyxVQUFBLEdBQUcsSUFBRyxPQUFBLEdBQUcsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxJQUFJLEVBQWYsQ0FBZSxDQUFDLENBQUM7Z0JBQ2pDLENBQUM7Z0JBRU0seUNBQW1CLEdBQTFCO29CQUNJLFdBQVc7b0JBQ1gsSUFBSSxJQUFJLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDeEMsSUFBSSxHQUFHLEdBQUcsV0FBVyxHQUFHLElBQUksR0FBRyxJQUFJLENBQUM7b0JBRXBDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FDakIsSUFBSSxDQUFDLE9BQU8sR0FBRyxxQkFBcUIsRUFDcEMsR0FBRyxFQUNILEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxTQUFTLEVBQUUsRUFBRSxDQUNoQyxDQUFDLEdBQUcsQ0FBQyxVQUFBLEdBQUcsSUFBRyxPQUFBLEdBQUcsQ0FBQyxJQUFJLEVBQUUsRUFBVixDQUFVLENBQUMsQ0FBQztvQkFDeEIsY0FBYztvQkFDZCx3QkFBd0I7Z0JBQzVCLENBQUM7Z0JBRUQsa0hBQWtIO2dCQUNsSCxpQkFBaUI7Z0JBQ2pCLGlDQUFpQztnQkFDakMseUVBQXlFO2dCQUN6RSxvQkFBb0I7Z0JBQ3BCLDZCQUE2QjtnQkFDN0IsMkJBQTJCO2dCQUMzQiwyQkFBMkI7Z0JBQzNCLHlCQUF5QjtnQkFDekIsZ0NBQWdDO2dCQUNoQyxPQUFPO2dCQUNQLHlDQUF5QztnQkFDekMsNEJBQTRCO2dCQUM1QiwyQ0FBMkM7Z0JBQzNDLDBCQUEwQjtnQkFDMUIsbUNBQW1DO2dCQUNuQyxpQ0FBaUM7Z0JBQ2pDLGlDQUFpQztnQkFDakMsK0JBQStCO2dCQUMvQixzQ0FBc0M7Z0JBQ3RDLGVBQWU7Z0JBQ2YsZ0JBQWdCO2dCQUNoQix3Q0FBd0M7Z0JBQ3hDLDhCQUE4QjtnQkFDOUIsR0FBRztnQkFFSSw2QkFBTyxHQUFkLFVBQWUsUUFBZ0IsRUFBRSxPQUFlLEVBQUUsT0FBZSxFQUFFLE1BQXFCLEVBQUUsV0FBbUIsRUFBRSxVQUFrQixFQUFFLDZCQUFzQyxFQUFFLFdBQTZCLEVBQUUsaUJBQThCLEVBQUUsU0FBc0I7b0JBQXJGLDJCQUE2QixHQUE3QixtQkFBNkI7b0JBQUUsaUNBQThCLEdBQTlCLHNCQUE4QjtvQkFBRSx5QkFBc0IsR0FBdEIsY0FBc0I7b0JBQzVQLElBQUksZUFBZSxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FBQztvQkFDOUQsSUFBSSxRQUFRLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztvQkFDaEQsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUNqQixJQUFJLENBQUMsT0FBTyxHQUFHLGlCQUFpQixFQUNoQyxJQUFJLENBQUMsU0FBUyxDQUFDO3dCQUNYLFFBQVEsRUFBRSxRQUFRO3dCQUNsQixPQUFPLEVBQUUsT0FBTzt3QkFDaEIsT0FBTyxFQUFFLE9BQU87d0JBQ2hCLE1BQU0sRUFBRSxNQUFNO3dCQUNkLFNBQVMsRUFBRSxXQUFXO3dCQUN0QixVQUFVLEVBQUUsVUFBVTt3QkFDdEIsNkJBQTZCLEVBQUUsNkJBQTZCO3dCQUM1RCxXQUFXLEVBQUUsV0FBVzt3QkFDeEIsaUJBQWlCLEVBQUUsaUJBQWlCO3dCQUNwQyxTQUFTLEVBQUUsU0FBUzt3QkFDcEIsZUFBZSxFQUFFLGVBQWU7d0JBQ2hDLFFBQVEsRUFBRSxRQUFRO3FCQUNyQixDQUFDLEVBQ0YsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLFNBQVMsRUFBRSxFQUFFLENBQ2hDLENBQUMsR0FBRyxDQUFDLFVBQUEsR0FBRyxJQUFHLE9BQUEsR0FBRyxDQUFDLElBQUksRUFBRSxFQUFWLENBQVUsQ0FBQyxDQUFDO2dCQUM1QixDQUFDO2dCQUVNLHdDQUFrQixHQUF6QixVQUEwQixLQUFhLEVBQUUsVUFBZTtvQkFDcEQsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUNqQixJQUFJLENBQUMsT0FBTyxHQUFHLDRCQUE0QixFQUMzQyxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxVQUFVLEVBQUUsVUFBVSxFQUFFLENBQUMsRUFDeEQsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLFNBQVMsRUFBRSxFQUFFLENBQ2hDLENBQUMsR0FBRyxDQUFDLFVBQUEsR0FBRyxJQUFHLE9BQUEsR0FBRyxDQUFDLElBQUksRUFBRSxFQUFWLENBQVUsQ0FBQyxDQUFDO2dCQUM1QixDQUFDO2dCQUVELGlCQUFpQjtnQkFDVixrQ0FBWSxHQUFuQjtvQkFDSSxJQUFJLENBQUMsa0JBQWtCLENBQUMsY0FBYyxFQUFFLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FDakQsVUFBQSxXQUFXO3dCQUNQLFlBQVksQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ3RGLFlBQVksQ0FBQyxPQUFPLENBQUMsbUJBQW1CLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQzVGLFlBQVksQ0FBQyxPQUFPLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDcEYsWUFBWSxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDOUYsQ0FBQyxFQUNELFVBQUEsS0FBSzt3QkFDRCxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO3dCQUNuQixZQUFZLENBQUMsS0FBSyxFQUFFLENBQUM7d0JBQ3JCLGNBQWMsQ0FBQyxLQUFLLEVBQUUsQ0FBQztvQkFDM0IsQ0FBQyxFQUNELGNBQVEsQ0FBQyxDQUFDLENBQUM7Z0JBQ25CLENBQUM7Z0JBOUxMO29CQUFDLGlCQUFVLEVBQUU7OytCQUFBO2dCQWlNYixrQkFBQztZQUFELENBaE1BLEFBZ01DLElBQUE7WUFoTUQscUNBZ01DLENBQUEiLCJmaWxlIjoic2VydmljZXMvQW1heFNlcnZpY2UuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnYW5ndWxhcjIvY29yZSc7XHJcbmltcG9ydCB7IEh0dHAsIEhlYWRlcnMgIH0gZnJvbSAnYW5ndWxhcjIvaHR0cCc7XHJcbmltcG9ydCAncnhqcy9hZGQvb3BlcmF0b3IvbWFwJztcclxuaW1wb3J0IHtPYnNlcnZhYmxlfSBmcm9tIFwicnhqcy9PYnNlcnZhYmxlXCI7XHJcbmltcG9ydCB7c2VydmljZUNvbmZpZ30gZnJvbSAnLi4vY3JtY29uZmlnJztcclxuXHJcblxyXG5kZWNsYXJlIHZhciBqUXVlcnk7XHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIEFtYXhTZXJ2aWNlIHtcclxuICAgIGJhc2VVcmw6IHN0cmluZztcclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgaHR0cDogSHR0cCkge1xyXG4gICAgICAgIHRoaXMuYmFzZVVybCA9IHNlcnZpY2VDb25maWcuc2VydmljZUFwaVVybDtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIGdldEhlYWRlcigpOiBIZWFkZXJzIHtcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgIHZhciBoZWFkZXIgPSBuZXcgSGVhZGVycygpO1xyXG4gICAgICAgIGhlYWRlci5hcHBlbmQoXCJDb250ZW50LVR5cGVcIiwgXCJhcHBsaWNhdGlvbi9qc29uOyBjaGFyc2V0PXV0Zi04XCIpO1xyXG4gICAgICAgIGlmIChzZXNzaW9uU3RvcmFnZS5nZXRJdGVtKHNlcnZpY2VDb25maWcuYWNjZXNUb2tlblN0b3JlTmFtZSkpIHtcclxuICAgICAgICAgICAgaGVhZGVyLmFwcGVuZChzZXJ2aWNlQ29uZmlnLmFjY2VzVG9rZW5SZXF1ZXN0SGVhZGVyLCBzZXNzaW9uU3RvcmFnZS5nZXRJdGVtKHNlcnZpY2VDb25maWcuYWNjZXNUb2tlblN0b3JlTmFtZSkpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRocm93ICdBY2Nlc3MgdG9rZW4gbm90IGF2YWlsYWJsZSc7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBoZWFkZXI7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHZhbGlkYXRlTG9naW4oVXNlcklEOiBzdHJpbmcsIFBhc3N3b3JkOiBzdHJpbmcsIE9yZ2FuaXphdGlvbk5hbWU6IHN0cmluZywgcmVtZW1iZXJNZT86IGJvb2xlYW4pIHtcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgIHZhciBsYW5nID0gXCJlblwiO1xyXG4gICAgICAgIHZhciBMYW5ndWFnZSA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwibGFuZ1wiKTtcclxuICAgICAgICBpZiAoTGFuZ3VhZ2UgIT0gXCJcIiAmJiBMYW5ndWFnZSAhPSBudWxsKVxyXG4gICAgICAgICAgICBsYW5nID0gTGFuZ3VhZ2U7XHJcbiAgICAgICAgdmFyIHVzZXJJbmZvID0ge1xyXG4gICAgICAgICAgICBPcmdJZDogT3JnYW5pemF0aW9uTmFtZSxcclxuICAgICAgICAgICAgVXNlck5hbWU6IFVzZXJJRCxcclxuICAgICAgICAgICAgUGFzc3dvcmQ6IFBhc3N3b3JkLFxyXG4gICAgICAgICAgICBMYW5ndWFnZTogbGFuZ1xyXG5cclxuICAgICAgICB9XHJcbiAgICAgICAgdmFyIGhlYWRlciA9IG5ldyBIZWFkZXJzKCk7XHJcbiAgICAgICAgaGVhZGVyLmFwcGVuZChcIkNvbnRlbnQtVHlwZVwiLCBcImFwcGxpY2F0aW9uL3gtd3d3LWZvcm0tdXJsZW5jb2RlZFwiKTtcclxuICAgICAgICAvLyBoZWFkZXIuYXBwZW5kKFwiRGF0YS1UeXBlXCIsIFwianNvblwiKTtcclxuICAgICAgICAvL2hlYWRlci5hcHBlbmQoXCJDb250ZW50LVR5cGVcIiwgXCJ0ZXh0L3BsYWluXCIpO1xyXG4gICAgICAgIFxyXG5cclxuICAgICAgICB2YXIgamRhdGEgPSBqUXVlcnkucGFyYW0odXNlckluZm8pO1xyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0KFxyXG4gICAgICAgICAgICAodGhpcy5iYXNlVXJsICsgXCJTZXJ2aWNlL0xvZ2luXCIpLCAgICAgICAgICAgICAgICAgICAgIC8vVVJMIGZvciB0aGUgcmVxdWVzdFxyXG4gICAgICAgICAgICBqZGF0YSwgICAgICAgICAgICAgICAgICAgLy9EYXRhIGZvciB0aGUgcmVxdWVzdFxyXG4gICAgICAgICAgICB7IGhlYWRlcnM6IGhlYWRlciB9ICAgICAgICAgICAgICAgICAgICAgICAgIC8vSEVBREVSUyBmb3IgdGhlIHJlcXVlc3RcclxuICAgICAgICApLm1hcChyZXMgPT4gcmVzLnRleHQoKSk7XHJcblxyXG5cclxuXHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIEdldFJlcG9ydChSZXBvcnROYW1lOiBzdHJpbmcsIHBhcmFtZXRlcnM6IE9iamVjdCk6IE9ic2VydmFibGUge1xyXG4gICAgICAgIHZhciBoZWFkZXIgPSBuZXcgSGVhZGVycygpO1xyXG4gICAgICAgIGhlYWRlci5hcHBlbmQoXCJDb250ZW50LVR5cGVcIiwgXCJhcHBsaWNhdGlvbi94LXd3dy1mb3JtLXVybGVuY29kZWRcIik7XHJcbiAgICAgICAgdmFyIHJlcG9ydGluZm8gPSB7XHJcbiAgICAgICAgICAgIFJlcG9ydE5hbWU6IFJlcG9ydE5hbWUsXHJcbiAgICAgICAgICAgIFBhcmFtZXRlcnM6IHBhcmFtZXRlcnNcclxuICAgICAgICB9XHJcbiAgICAgICAgdmFyIGpkYXRhID0galF1ZXJ5LnBhcmFtKHJlcG9ydGluZm8pO1xyXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdChcclxuICAgICAgICAgICAgdGhpcy5iYXNlVXJsICsgXCJTZXJ2aWNlL0FtYXhSZXBvcnRpbmdTZXJ2aWNlXCIsXHJcbiAgICAgICAgICAgIGpkYXRhLFxyXG4gICAgICAgICAgICB7IGhlYWRlcnM6IGhlYWRlciB9XHJcbiAgICAgICAgKS5tYXAocmVzPT4gcmVzLmpzb24oKS5kYXRhKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgRXhlY3V0ZUpzb24oanNvblFEYXRhOiBhbnkpOiBPYnNlcnZhYmxlIHtcclxuICAgICAgICB2YXIgaGVhZGVyID0gbmV3IEhlYWRlcnMoKTtcclxuICAgICAgICBoZWFkZXIuYXBwZW5kKFwiQ29udGVudC1UeXBlXCIsIFwiYXBwbGljYXRpb24veC13d3ctZm9ybS11cmxlbmNvZGVkXCIpO1xyXG4gICAgICAgIHZhciBqZGF0YSA9IGpRdWVyeS5wYXJhbShqc29uUURhdGEpO1xyXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdChcclxuICAgICAgICAgICAgdGhpcy5iYXNlVXJsICsgXCJTZXJ2aWNlL0V4ZWN1dGVKc29uXCIsXHJcbiAgICAgICAgICAgIGpkYXRhLFxyXG4gICAgICAgICAgICB7IGhlYWRlcnM6IGhlYWRlciB9XHJcbiAgICAgICAgKS5tYXAocmVzPT4gcmVzLmpzb24oKS5kYXRhKTtcclxuICAgIH1cclxuXHJcblxyXG4gICAgLy9RdWVyeWVzXHJcbiAgICBwdWJsaWMgR2V0RGF0YUZyb21TZXJ2ZXIocXVlcnkpOiBPYnNlcnZhYmxlIHtcclxuICAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICBcclxuICAgICAgICB2YXIgcGFyYW1zID0gSlNPTi5zdHJpbmdpZnkocXVlcnkpO1xyXG4gICAgICAgIFxyXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdChcclxuICAgICAgICAgICAgdGhpcy5iYXNlVXJsICsgXCJTZXJ2aWNlL0RldlF1ZXJ5XCIsXHJcbiAgICAgICAgICAgIHBhcmFtcyxcclxuICAgICAgICAgICAgeyBoZWFkZXJzOiB0aGlzLmdldEhlYWRlcigpIH1cclxuICAgICAgICApLm1hcChyZXM9PiByZXMudGV4dCgpKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgR2V0R2VuZXJhbEdyb3VwRGF0YSgpOiBPYnNlcnZhYmxlIHtcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgIHZhciBHZXRHZW5lcmFsR3JvdXBEYXRhID0ge1xyXG4gICAgICAgICAgICB1cWVyeTogXCJTRUxFQ1QgR3JvdXBJZCwgR3JvdXBOYW1lLCBHcm91cE5hbWVFbmcsIEdyb3VwUGFyZW5DYXRlZ29yeSBGUk9NIEN1c3RvbWVyR3JvdXBzR2VuZXJhbCBXSEVSRSAoIElzU3VwcG9ydCA9IDAgYW5kIElzaGlkZSA9IDAgYW5kIFNlY3VyaXR5TGV2ZWwgPD0gMTApIE9SREVSIEJZIEdyb3VwTmFtZVwiLFxyXG4gICAgICAgICAgICBwYXJhbWV0ZXJzOiB7fVxyXG4gICAgICAgIH1cclxuICAgICAgICB2YXIgamRhdGEgPSBKU09OLnN0cmluZ2lmeShHZXRHZW5lcmFsR3JvdXBEYXRhKTtcclxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3QoXHJcbiAgICAgICAgICAgIHRoaXMuYmFzZVVybCArIFwiU2VydmljZS9EZXZRdWVyeVwiLFxyXG4gICAgICAgICAgICBqZGF0YSxcclxuICAgICAgICAgICAgeyBoZWFkZXJzOiB0aGlzLmdldEhlYWRlcigpIH1cclxuICAgICAgICApLm1hcChyZXM9PiByZXMuanNvbigpLmRhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBHZXRHZW5lcmFsR3JvdXBUcmVlKCk6IE9ic2VydmFibGUge1xyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgdmFyIGxhbmcgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImxhbmdcIik7XHJcbiAgICAgICAgdmFyIHJlcSA9ICd7XCJMYW5nXCI6XCInICsgbGFuZyArICdcIn0nO1xyXG5cclxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3QoXHJcbiAgICAgICAgICAgIHRoaXMuYmFzZVVybCArIFwiU2VydmljZS9HZXRUcmVlRGF0YVwiLFxyXG4gICAgICAgICAgICByZXEsXHJcbiAgICAgICAgICAgIHsgaGVhZGVyczogdGhpcy5nZXRIZWFkZXIoKSB9XHJcbiAgICAgICAgKS5tYXAocmVzPT4gcmVzLnRleHQoKSk7XHJcbiAgICAgICAgLy9hbGVydChyZXN0KTtcclxuICAgICAgICAvL3JldHVybiByZXN0LmtlbmRvVHJlZTtcclxuICAgIH1cclxuXHJcbiAgICAvL3B1YmxpYyBTZW5kU21zKHVzZXJuYW1lOiBzdHJpbmcsIGNvbXBhbnk6IHN0cmluZywgbWVzc2FnZTogc3RyaW5nLCBncm91cHM6IEFycmF5PG51bWJlcj4sIHBob25lVHlwZUlkOiBudW1iZXIpIHtcclxuICAgIC8vICAgIC8vZGVidWdnZXI7XHJcbiAgICAvLyAgICB2YXIgaGVhZGVyID0gbmV3IEhlYWRlcnMoKTtcclxuICAgIC8vICAgIGhlYWRlci5hcHBlbmQoXCJDb250ZW50LVR5cGVcIiwgXCJhcHBsaWNhdGlvbi94LXd3dy1mb3JtLXVybGVuY29kZWRcIik7XHJcbiAgICAvLyAgICB2YXIgc21zZGV0ID0ge1xyXG4gICAgLy8gICAgICAgIHVzZXJuYW1lOiB1c2VybmFtZSxcclxuICAgIC8vICAgICAgICBjb21wYW55OiBjb21wYW55LFxyXG4gICAgLy8gICAgICAgIG1lc3NhZ2U6IG1lc3NhZ2UsXHJcbiAgICAvLyAgICAgICAgZ3JvdXBzOiBncm91cHMsXHJcbiAgICAvLyAgICAgICAgcGhvbmVUeXBlOiBwaG9uZVR5cGVJZFxyXG4gICAgLy8gICAgfVxyXG4gICAgLy8gICAgdmFyIGpkYXRhID0gSlNPTi5zdHJpbmdpZnkoc21zZGV0KTtcclxuICAgIC8vICAgIHJldHVybiB0aGlzLmh0dHAucG9zdChcclxuICAgIC8vICAgICAgICB0aGlzLmJhc2VVcmwgKyBcIlNlcnZpY2UvU2VuZFNtc1wiLFxyXG4gICAgLy8gICAgICAgIC8valF1ZXJ5LnBhcmFtKHtcclxuICAgIC8vICAgICAgICAvLyAgICB1c2VybmFtZTogdXNlcm5hbWUsXHJcbiAgICAvLyAgICAgICAgLy8gICAgY29tcGFueTogY29tcGFueSxcclxuICAgIC8vICAgICAgICAvLyAgICBtZXNzYWdlOiBtZXNzYWdlLFxyXG4gICAgLy8gICAgICAgIC8vICAgIGdyb3VwczogZ3JvdXBzLFxyXG4gICAgLy8gICAgICAgIC8vICAgIHBob25lVHlwZTogcGhvbmVUeXBlSWRcclxuICAgIC8vICAgICAgICAvL30pLFxyXG4gICAgLy8gICAgICAgIGpkYXRhLFxyXG4gICAgLy8gICAgICAgIHsgaGVhZGVyczogdGhpcy5nZXRIZWFkZXIoKSAgfVxyXG4gICAgLy8gICAgKS5tYXAocmVzPT4gcmVzLnRleHQoKSk7XHJcbiAgICAvL31cclxuXHJcbiAgICBwdWJsaWMgU2VuZFNtcyh1c2VybmFtZTogc3RyaW5nLCBjb21wYW55OiBzdHJpbmcsIG1lc3NhZ2U6IHN0cmluZywgZ3JvdXBzOiBBcnJheTxudW1iZXI+LCBwaG9uZVR5cGVJZDogbnVtYmVyLCBwcm92aWRlcklkOiBudW1iZXIsIHJldHVybkJhbGFuY2VBbmRDdXN0b21lckNvdW50OiBib29sZWFuLCBpc0NvbmZpcm1lZD86IGJvb2xlYW4gPSBmYWxzZSwgU2VuZGVyUGhvbmVOdW1iZXI6IHN0cmluZyA9IFwiXCIsIHNlbmRsYXRlcjogc3RyaW5nID0gXCJcIikge1xyXG4gICAgICAgIHZhciBJc0JyYW5jaEVuYWJsZWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcIklzQnJhbmNoRW5hYmxlZFwiKTtcclxuICAgICAgICB2YXIgQnJhbmNoaWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcIkJyYW5jaGlkXCIpO1xyXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdChcclxuICAgICAgICAgICAgdGhpcy5iYXNlVXJsICsgXCJTZXJ2aWNlL1NlbmRTbXNcIixcclxuICAgICAgICAgICAgSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgICAgICAgICAgdXNlcm5hbWU6IHVzZXJuYW1lLFxyXG4gICAgICAgICAgICAgICAgY29tcGFueTogY29tcGFueSxcclxuICAgICAgICAgICAgICAgIG1lc3NhZ2U6IG1lc3NhZ2UsXHJcbiAgICAgICAgICAgICAgICBncm91cHM6IGdyb3VwcyxcclxuICAgICAgICAgICAgICAgIHBob25lVHlwZTogcGhvbmVUeXBlSWQsXHJcbiAgICAgICAgICAgICAgICBwcm92aWRlcklkOiBwcm92aWRlcklkLFxyXG4gICAgICAgICAgICAgICAgcmV0dXJuQmFsYW5jZUFuZEN1c3RvbWVyQ291bnQ6IHJldHVybkJhbGFuY2VBbmRDdXN0b21lckNvdW50LFxyXG4gICAgICAgICAgICAgICAgaXNDb25maXJtZWQ6IGlzQ29uZmlybWVkLFxyXG4gICAgICAgICAgICAgICAgU2VuZGVyUGhvbmVOdW1iZXI6IFNlbmRlclBob25lTnVtYmVyLFxyXG4gICAgICAgICAgICAgICAgc2VuZGxhdGVyOiBzZW5kbGF0ZXIsXHJcbiAgICAgICAgICAgICAgICBJc0JyYW5jaEVuYWJsZWQ6IElzQnJhbmNoRW5hYmxlZCxcclxuICAgICAgICAgICAgICAgIEJyYW5jaGlkOiBCcmFuY2hpZFxyXG4gICAgICAgICAgICB9KSxcclxuICAgICAgICAgICAgeyBoZWFkZXJzOiB0aGlzLmdldEhlYWRlcigpIH1cclxuICAgICAgICApLm1hcChyZXM9PiByZXMudGV4dCgpKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgRXhlY3V0ZURhdGFTZXJ2aWNlKHF1ZXJ5OiBzdHJpbmcsIHBhcmFtZXRlcnM6IGFueSkge1xyXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdChcclxuICAgICAgICAgICAgdGhpcy5iYXNlVXJsICsgXCJTZXJ2aWNlL0V4ZWN1dGVEYXRhU2VydmljZVwiLFxyXG4gICAgICAgICAgICBKU09OLnN0cmluZ2lmeSh7IHF1ZXJ5OiBxdWVyeSwgcGFyYW1ldGVyczogcGFyYW1ldGVycyB9KSxcclxuICAgICAgICAgICAgeyBoZWFkZXJzOiB0aGlzLmdldEhlYWRlcigpIH1cclxuICAgICAgICApLm1hcChyZXM9PiByZXMudGV4dCgpKTtcclxuICAgIH1cclxuXHJcbiAgICAvL1V0aWxpdHkgc2VydmljZVxyXG4gICAgcHVibGljIENyZWF0ZUNhdGNoZSgpIHtcclxuICAgICAgICB0aGlzLkV4ZWN1dGVEYXRhU2VydmljZShcIkluaXRhbGl6ZUNSTVwiLCB7fSkuc3Vic2NyaWJlKFxyXG4gICAgICAgICAgICBpbml0aWFsRGF0YT0+IHtcclxuICAgICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCdTbXNDb21wYW55TGlzdCcsIEpTT04uc3RyaW5naWZ5KGluaXRpYWxEYXRhW1wiU21zQ29tcGFueUxpc3RcIl0pKTtcclxuICAgICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCdDZWxsUGhvbmVUeXBlTGlzdCcsIEpTT04uc3RyaW5naWZ5KGluaXRpYWxEYXRhW1wiQ2VsbFBob25lVHlwZUxpc3RcIl0pKTtcclxuICAgICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCdQaG9uZVR5cGVMaXN0JywgSlNPTi5zdHJpbmdpZnkoaW5pdGlhbERhdGFbXCJQaG9uZVR5cGVMaXN0XCJdKSk7XHJcbiAgICAgICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnR2VuZXJhbEdyb3VwRGF0YScsIEpTT04uc3RyaW5naWZ5KGluaXRpYWxEYXRhW1wiR2VuZXJhbEdyb3VwRGF0YVwiXSkpO1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBlcnJvcj0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5jbGVhcigpO1xyXG4gICAgICAgICAgICAgICAgc2Vzc2lvblN0b3JhZ2UuY2xlYXIoKTtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgKCkgPT4geyB9KTtcclxuICAgIH1cclxuXHJcblxyXG59Il19
