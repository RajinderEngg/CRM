System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var crmConfig, serviceConfig, LocalDict, SessionlDict;
    return {
        setters:[],
        execute: function() {
            crmConfig = {
                version: "1.0.0.22",
                minSvcVersion: "",
                minDbsVersion: "",
                falbackLanguage: "he"
            };
            serviceConfig = {
                serviceBaseUrl: "http://localhost/amaxweb/Api.svc/",
                serviceApiUrl: "http://localhost:57998/API/",
                accesTokenStoreName: "XToken",
                accesTokenRequestHeader: "X-Token",
                accesTokenResponceHeader: "XToken",
                authenticationMode: "JWT-Token"
            };
            exports_1("LocalDict", LocalDict = {
                userCredential: "userCredential",
                selectedLanguage: "preferedLanguage",
                languageResource: "languageResource",
                SmsSettings: "smsSettings"
            });
            exports_1("SessionlDict", SessionlDict = {});
            if (window.location.href.indexOf("127.0.0.1") > -1)
                serviceConfig.serviceBaseUrl = "http://localhost:57998/Api.svc/";
            exports_1("serviceConfig", serviceConfig);
            exports_1("crmConfig", crmConfig);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNybWNvbmZpZyAtIENvcHkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O1FBQUksU0FBUyxFQU1ULGFBQWEsRUFVTixTQUFTLEVBT1QsWUFBWTs7OztZQXZCbkIsU0FBUyxHQUFHO2dCQUNaLE9BQU8sRUFBRSxVQUFVO2dCQUNuQixhQUFhLEVBQUUsRUFBRTtnQkFDakIsYUFBYSxFQUFFLEVBQUU7Z0JBQ2pCLGVBQWUsRUFBRSxJQUFJO2FBQ3hCLENBQUM7WUFDRSxhQUFhLEdBQUc7Z0JBQ2hCLGNBQWMsRUFBRSxtQ0FBbUM7Z0JBQ25ELGFBQWEsRUFBRSw2QkFBNkI7Z0JBQzVDLG1CQUFtQixFQUFDLFFBQVE7Z0JBQzVCLHVCQUF1QixFQUFDLFNBQVM7Z0JBQ2pDLHdCQUF3QixFQUFDLFFBQVE7Z0JBR2pDLGtCQUFrQixFQUFDLFdBQVc7YUFDakMsQ0FBQTtZQUNVLHVCQUFBLFNBQVMsR0FBRztnQkFDbkIsY0FBYyxFQUFFLGdCQUFnQjtnQkFDaEMsZ0JBQWdCLEVBQUUsa0JBQWtCO2dCQUNwQyxnQkFBZ0IsRUFBRSxrQkFBa0I7Z0JBQ3BDLFdBQVcsRUFBRSxhQUFhO2FBQzdCLENBQUEsQ0FBQTtZQUVVLDBCQUFBLFlBQVksR0FBRyxFQUV6QixDQUFBLENBQUE7WUFDRCxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7Z0JBQ25ELGFBQWEsQ0FBQyxjQUFjLEdBQUMsaUNBQWlDLENBQUM7WUFFL0QseUNBQWE7WUFDYixpQ0FBUyIsImZpbGUiOiJjcm1jb25maWcgLSBDb3B5LmpzIiwic291cmNlc0NvbnRlbnQiOlsibGV0IGNybUNvbmZpZyA9IHtcclxuICAgIHZlcnNpb246IFwiMS4wLjAuMjJcIixcclxuICAgIG1pblN2Y1ZlcnNpb246IFwiXCIsXHJcbiAgICBtaW5EYnNWZXJzaW9uOiBcIlwiLFxyXG4gICAgZmFsYmFja0xhbmd1YWdlOiBcImhlXCJcclxufTtcclxubGV0IHNlcnZpY2VDb25maWcgPSB7XHJcbiAgICBzZXJ2aWNlQmFzZVVybDogXCJodHRwOi8vbG9jYWxob3N0L2FtYXh3ZWIvQXBpLnN2Yy9cIixcclxuICAgIHNlcnZpY2VBcGlVcmw6IFwiaHR0cDovL2xvY2FsaG9zdDo1Nzk5OC9BUEkvXCIsXHJcbiAgICBhY2Nlc1Rva2VuU3RvcmVOYW1lOlwiWFRva2VuXCIsXHJcbiAgICBhY2Nlc1Rva2VuUmVxdWVzdEhlYWRlcjpcIlgtVG9rZW5cIixcclxuICAgIGFjY2VzVG9rZW5SZXNwb25jZUhlYWRlcjpcIlhUb2tlblwiLFxyXG4gICAgXHJcblxyXG4gICAgYXV0aGVudGljYXRpb25Nb2RlOlwiSldULVRva2VuXCJcclxufVxyXG5leHBvcnQgdmFyIExvY2FsRGljdCA9IHtcclxuICAgIHVzZXJDcmVkZW50aWFsOiBcInVzZXJDcmVkZW50aWFsXCIsXHJcbiAgICBzZWxlY3RlZExhbmd1YWdlOiBcInByZWZlcmVkTGFuZ3VhZ2VcIixcclxuICAgIGxhbmd1YWdlUmVzb3VyY2U6IFwibGFuZ3VhZ2VSZXNvdXJjZVwiLFxyXG4gICAgU21zU2V0dGluZ3M6IFwic21zU2V0dGluZ3NcIlxyXG59XHJcblxyXG5leHBvcnQgdmFyIFNlc3Npb25sRGljdCA9IHtcclxuXHJcbn1cclxuaWYgKHdpbmRvdy5sb2NhdGlvbi5ocmVmLmluZGV4T2YoXCIxMjcuMC4wLjFcIikgPiAtMSlcclxuc2VydmljZUNvbmZpZy5zZXJ2aWNlQmFzZVVybD1cImh0dHA6Ly9sb2NhbGhvc3Q6NTc5OTgvQXBpLnN2Yy9cIjtcclxuZXhwb3J0IHtcclxuc2VydmljZUNvbmZpZyxcclxuY3JtQ29uZmlnXHJcbn0iXX0=
