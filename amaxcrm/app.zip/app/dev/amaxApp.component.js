System.register(['angular2/core', './amaxComponents/amaxCrmUIComponent', './amaxComponents/amaxLoginComponent', './services/AmaxService', "./services/ResourceService", "./amax/quickaccess/index", "./amax/quickaccess/default", "angular2/router", "./amax/logout", "./amax/reports/amaxReports", "./amax/forms/amaxForms", "./amax/employee/profile", "./amax/employee/settings", "./amax/sms", "./amax/Customer/addCustomer", "./amax/RecieptType/Reciept", "./amax/RecieptType/RecieptTemplate", "./amax/RecieptType/Template", "./amax/GeneralGroups/GeneralGroups", "./amax/Charge_Credit/Terminals", "./amax/Charge_Credit/ChargeCreditCard", "./amax/Receipt/ReceiptSelect", "./amax/Receipt/ReceiptCreate"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, amaxCrmUIComponent_1, amaxLoginComponent_1, AmaxService_1, ResourceService_1, index_1, default_1, router_1, logout_1, amaxReports_1, amaxForms_1, profile_1, settings_1, sms_1, addCustomer_1, Reciept_1, RecieptTemplate_1, Template_1, GeneralGroups_1, Terminals_1, ChargeCreditCard_1, ReceiptSelect_1, ReceiptCreate_1;
    var AmaxAppComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (amaxCrmUIComponent_1_1) {
                amaxCrmUIComponent_1 = amaxCrmUIComponent_1_1;
            },
            function (amaxLoginComponent_1_1) {
                amaxLoginComponent_1 = amaxLoginComponent_1_1;
            },
            function (AmaxService_1_1) {
                AmaxService_1 = AmaxService_1_1;
            },
            function (ResourceService_1_1) {
                ResourceService_1 = ResourceService_1_1;
            },
            function (index_1_1) {
                index_1 = index_1_1;
            },
            function (default_1_1) {
                default_1 = default_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (logout_1_1) {
                logout_1 = logout_1_1;
            },
            function (amaxReports_1_1) {
                amaxReports_1 = amaxReports_1_1;
            },
            function (amaxForms_1_1) {
                amaxForms_1 = amaxForms_1_1;
            },
            function (profile_1_1) {
                profile_1 = profile_1_1;
            },
            function (settings_1_1) {
                settings_1 = settings_1_1;
            },
            function (sms_1_1) {
                sms_1 = sms_1_1;
            },
            function (addCustomer_1_1) {
                addCustomer_1 = addCustomer_1_1;
            },
            function (Reciept_1_1) {
                Reciept_1 = Reciept_1_1;
            },
            function (RecieptTemplate_1_1) {
                RecieptTemplate_1 = RecieptTemplate_1_1;
            },
            function (Template_1_1) {
                Template_1 = Template_1_1;
            },
            function (GeneralGroups_1_1) {
                GeneralGroups_1 = GeneralGroups_1_1;
            },
            function (Terminals_1_1) {
                Terminals_1 = Terminals_1_1;
            },
            function (ChargeCreditCard_1_1) {
                ChargeCreditCard_1 = ChargeCreditCard_1_1;
            },
            function (ReceiptSelect_1_1) {
                ReceiptSelect_1 = ReceiptSelect_1_1;
            },
            function (ReceiptCreate_1_1) {
                ReceiptCreate_1 = ReceiptCreate_1_1;
            }],
        execute: function() {
            AmaxAppComponent = (function () {
                function AmaxAppComponent(_amaxSservice, _languageService) {
                    this._amaxSservice = _amaxSservice;
                    this._languageService = _languageService;
                    this.FormTypeForm = "SCREEN_LOGIN";
                    this.ChangeDialog = "";
                    this.CHANGEDIR = "";
                    this.IsLogedIn = false;
                    this.RES = {};
                    this._userModel = {};
                    this._LoggeduserModel = {};
                    //Loading the language resource
                    this.RES.SCREEN_LOGIN = {};
                    this.FormTypeForm = "SCREEN_LOGIN";
                    this.baseUrl = this._languageService.AppUrl;
                }
                AmaxAppComponent.prototype.loadUserInformation = function () {
                    if (sessionStorage.getItem('userInformation') != null) {
                        this.LoginData = JSON.parse(sessionStorage.getItem('userInformation'));
                        if (this.LoginData)
                            this.IsLogedIn = true;
                    }
                };
                AmaxAppComponent.prototype.getlangres = function (langcode) {
                    var _this = this;
                    this._languageService.GetLangRes(this.FormTypeForm, langcode).subscribe(function (response) {
                        // debugger;
                        response = $.parseJSON(response);
                        if (response.IsError == true) {
                            //alert(response.ErrMsg);
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            localStorage.setItem("langresource", JSON.stringify(response.Data));
                            localStorage.setItem("lang", langcode);
                            _this.RES = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxAppComponent.prototype.validateLogin = function () {
                    var _this = this;
                    //this.IsLogedIn = true; 
                    if (this._userModel["userName"] != undefined && this._userModel["userName"] != null && this._userModel["userName"] != ""
                        && this._userModel["password"] != undefined && this._userModel["password"] != null && this._userModel["password"] != ""
                        && this._userModel["orgName"] != undefined && this._userModel["orgName"] != null && this._userModel["orgName"] != "") {
                        this._amaxSservice.validateLogin(this._userModel["userName"], this._userModel["password"], this._userModel["orgName"], this._userModel["rememberMe"]).subscribe(function (data) {
                            var dta = $.parseJSON(data).Data;
                            //debugger;
                            if (dta.error != undefined && dta.error != null && dta.error != "") {
                                if (dta.error != "") {
                                    //alert(dta.error);
                                    bootbox.alert({ message: dta.error,
                                        className: _this.ChangeDialog,
                                        buttons: {
                                            ok: {
                                                //label: 'Ok',
                                                className: _this.CHANGEDIR
                                            }
                                        }
                                    });
                                }
                            }
                            else {
                                _this.IsLogedIn = true;
                                _this.LoginData = dta;
                                sessionStorage.setItem('XToken', dta["token"]);
                                sessionStorage.setItem('sessionInformation', atob(dta["token"].split('.')[0]));
                                sessionStorage.setItem('userInformation', atob(dta["token"].split('.')[1]));
                                //Featching Userinformation
                                _this.LoginData = JSON.parse(atob(dta["token"].split('.')[1]));
                                localStorage.setItem("employeeid", _this.LoginData.employeeid);
                                //localStorage.setItem("OrgId", this._userModel["orgName"]);
                                if (localStorage.getItem("lang") == "" || localStorage.getItem("lang") == undefined || localStorage.getItem("lang") == null) {
                                    localStorage.setItem("lang", "en");
                                }
                                //alert(this._userModel["rememberMe"].toString());
                                //  debugger;
                                //alert(this._userModel["rememberMe"]);
                                if (_this._userModel["rememberMe"] == true || _this._userModel["rememberMe"] == "true") {
                                    var lang = localStorage.getItem("lang");
                                    //alert(lang);
                                    //this._languageService.setCookie("langresource", lang,10);
                                    _this._languageService.setCookie("RememberKey", data, 10);
                                    _this._languageService.setCookie("UserName", _this._userModel["userName"], 10);
                                    _this._languageService.setCookie("password", _this._userModel["password"], 10);
                                    _this._languageService.setCookie("orgName", _this._userModel["orgName"], 10);
                                    _this._languageService.setCookie("rememberMe", _this._userModel["rememberMe"], 10);
                                    _this._languageService.setCookie("lang", lang, 10);
                                }
                            }
                        }, function (error) { return console.error(error); }, function () {
                        });
                    }
                    else {
                        if (this._userModel["userName"] == undefined && this._userModel["userName"] == null || this._userModel["userName"] == "") {
                            //alert("Please enter valid username");
                            bootbox.alert({
                                message: "Please enter valid username",
                                className: this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        if (this._userModel["password"] == undefined && this._userModel["password"] == null || this._userModel["password"] == "") {
                            //alert("Please enter valid password");
                            bootbox.alert({
                                message: "Please enter valid password",
                                className: this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        if (this._userModel["orgName"] == undefined && this._userModel["orgName"] == null || this._userModel["orgName"] == "") {
                            //alert("Please enter valid organization");
                            bootbox.alert({
                                message: "Please enter valid password",
                                className: this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: this.CHANGEDIR
                                    }
                                }
                            });
                        }
                    }
                };
                AmaxAppComponent.prototype.validateUser = function (evt) {
                    console.log(evt);
                    this.validateLogin();
                };
                AmaxAppComponent.prototype.changeLanguageByLangId = function (LanguageId) {
                    var _this = this;
                    //debugger;
                    console.log("Changing Language...");
                    if (LanguageId) {
                        this._languageService.GetSelecetdLanguage(LanguageId).subscribe(function (data) {
                            localStorage.setItem("langresource", JSON.stringify(data));
                            localStorage.setItem("lang", LanguageId);
                            _this._userModel["lang"] = LanguageId;
                        }, function (error) { return console.log("Unable to load Language Data"); }, function () {
                            console.log("Language resource loaded");
                        });
                        this._languageService.GetLangRes(this.FormTypeForm, LanguageId).subscribe(function (response) {
                            //debugger;
                            response = $.parseJSON(response);
                            if (response.IsError == true) {
                                //alert(response.ErrMsg);
                                bootbox.alert({
                                    message: response.ErrMsg,
                                    className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                            else {
                                localStorage.setItem("langresource", JSON.stringify(response.Data));
                                localStorage.setItem("lang", LanguageId);
                                _this.RES = response.Data;
                            }
                        }, function (error) {
                            console.log(error);
                        }, function () {
                            console.log("CallCompleted");
                        });
                    }
                    else {
                        console.error("Code not specified");
                    }
                };
                AmaxAppComponent.prototype.changeLanguage = function (evt) {
                    var _this = this;
                    //debugger;
                    console.log("Changing Language...");
                    if (evt.code) {
                        this._languageService.GetSelecetdLanguage(evt.code).subscribe(function (data) {
                            localStorage.setItem("langresource", JSON.stringify(data));
                            localStorage.setItem("lang", evt.code);
                            _this._userModel["lang"] = evt.code;
                        }, function (error) { return console.log("Unable to load Language Data"); }, function () {
                            console.log("Language resource loaded");
                        });
                        this._languageService.GetLangRes(this.FormTypeForm, evt.code).subscribe(function (response) {
                            //debugger;
                            response = $.parseJSON(response);
                            if (response.IsError == true) {
                                //alert(response.ErrMsg);
                                bootbox.alert({
                                    message: response.ErrMsg,
                                    className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                            else {
                                localStorage.setItem("langresource", JSON.stringify(response.Data));
                                localStorage.setItem("lang", evt.code);
                                _this.RES = response.Data;
                            }
                        }, function (error) {
                            console.log(error);
                        }, function () {
                            console.log("CallCompleted");
                        });
                    }
                    else {
                        console.error("Code not specified");
                    }
                };
                AmaxAppComponent.prototype.ngOnInit = function () {
                    //debugger;
                    var _this = this;
                    this.FormTypeForm = "SCREEN_LOGIN";
                    var UserName = this._languageService.getCookie("UserName");
                    //alert(UserName[0]);
                    if (UserName.length > 0 && UserName[0] == "=")
                        var UserName = UserName.substring(1, UserName.length);
                    //var password = this._languageService.getCookie("password");
                    //if (password.length > 0) 
                    //    var password = password.substring(1, password.length);
                    var orgName = this._languageService.getCookie("orgName");
                    if (orgName.length > 0)
                        var orgName = orgName.substring(1, orgName.length);
                    var rememberMe = this._languageService.getCookie("rememberMe");
                    if (rememberMe.length > 0)
                        var rememberMe = rememberMe.substring(1, rememberMe.length);
                    else {
                        rememberMe = "true";
                    }
                    var lang = this._languageService.getCookie("lang");
                    if (lang.length > 0)
                        var lang = lang.substring(1, lang.length);
                    if (lang == "")
                        lang = "en";
                    localStorage.setItem("lang", lang);
                    this._userModel = {
                        userName: UserName,
                        password: "",
                        orgName: orgName,
                        lang: lang,
                        rememberMe: rememberMe
                    };
                    this._languageService.GetLangRes(this.FormTypeForm, lang).subscribe(function (response) {
                        response = $.parseJSON(response);
                        if (response.IsError == true) {
                            //alert(response.ErrMsg);
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            //debugger;
                            localStorage.setItem("langresource", JSON.stringify(response.Data));
                            localStorage.setItem("lang", lang);
                            _this.RES = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //this.RES = {
                    //     "APP_DIR": "ltr",
                    //     "APP_LANG": "en",
                    //     "SCREEN_LOGIN": {
                    //         "COMPANY_NAME": "Amax",
                    //         "APP_TYPE": "C.R.M",
                    //         "APP_BASELINE": "© Amax - software solutions",
                    //         "APP_LBL_INFO": "Please Enter Your Information",
                    //         "APP_LBL_USER": "Username",
                    //         "APP_LBL_PASS": "Password",
                    //         "APP_LBL_ORG": "Organization ID",
                    //         "APP_LBL_REMEMBER": "Remember Me",
                    //         "APP_BTN_LOGIN": "Login",
                    //         "APP_LBL_FORGOTPASS": "I forgot my password",
                    //         "APP_LBL_REGISTER": "I want to register"
                    //     },
                    //     "CUSTOMER_MASTER": {
                    //         "APP_LBL_CUST": "Customer",
                    //         "APP_LBL_CARD": "Card",
                    //         "APP_LBL_NEW_CUST": "Add New Customer",
                    //         "APP_TXT_REQD": "(Required-*)",
                    //         "APP_TXT_PH_LNAME": "Last Name*",
                    //         "APP_TXT_PH_FNAME": "First Name*",
                    //         "APP_TXT_PH_MNAME": "Middle Name",
                    //         "APP_TXT_PH_CNAME": "Company Name*",
                    //         "APP_DP_CTYPE": "Select Customer Type",
                    //         "APP_DP_EMP": "Select Contact Employee",
                    //         "APP_DP_SOURCE": "Select Source",
                    //         "APP_TXT_PH_CCODE": "Customer Code",
                    //         "APP_TXT_PH_BDATE": "Birth Date",
                    //         "APP_TXT_PH_JOB": "Job Title",
                    //         "APP_TXT_PH_TITLE": "Title",
                    //         "APP_DP_SUFFIX": "Select Suffix",
                    //         "APP_DP_GENDER": "Select Gender",
                    //         "APP_DP_GENDER_M": "Male",
                    //         "APP_DP_GENDER_F": "Female",
                    //         "APP_LBL_PHONE": "Phones",
                    //         "APP_LBL_ADD_PH": "Add Phone",
                    //         "APP_DP_PTYPE": "Select Phone Type*",
                    //         "APP_TXT_PH_PREFIX": "Prefix",
                    //         "APP_TXT_PH_AREA": "Area",
                    //         "APP_TXT_PH_PHONE": "Phone*",
                    //         "APP_LBL_SMS": "For SMS",
                    //         "APP_CHK_PH_SMS": "For SMS",
                    //         "APP_TXT_PH_COMMENT": "Comments",
                    //         "APP_BTN_PHADD": "Add",
                    //         "APP_BTN_PHCLOSE": "Close",
                    //         "APP_BTN_EADD": "Add",
                    //         "APP_BTN_ECLOSE": "Close",
                    //         "APP_BTN_ADADD": "Add",
                    //         "APP_BTN_ADCLOSE": "Close",
                    //         "APP_GRD_LBL_PTYPE": "Phone Type",
                    //         "APP_GRD_LBL_PHNO": "Prefix-Area-Phone",
                    //         "APP_GRD_LBL_SMS": "For SMS",
                    //         "APP_GRD_LBL_REM": "Remarks",
                    //         "APP_LNK_EMAIL": "Emails",
                    //         "APP_LBL_EMAIL": "Add Email",
                    //         "APP_TXT_PH_EMAIL": "Email*",
                    //         "APP_TXT_PH_ENAME": "Name*",
                    //         "APP_LBL_NLETTER": "NewsLetter",
                    //         "APP_GRD_LBL_EMAIL": "Email",
                    //         "APP_GRD_LBL_ENAME": "Name",
                    //         "APP_GRD_LBL_NLETTER": "Newsletter",
                    //         "APP_LNK_LBL_ADDRS": "Addresses",
                    //         "APP_LBL_ADDRESS": "Add Address",
                    //         "APP_LBL_PH_STR": "Street*",
                    //         "APP_LBL_PH_ADAREA": "Area*",
                    //         "APP_LBL_PH_CITY": "City*",
                    //         "APP_LBL_PH_ZIP": "Zip*",
                    //         "APP_DP_COUNTRY": "Select Country*",
                    //         "APP_DP_STATE": "Select State",
                    //         "APP_DP_ADDRTYPE": "Select AddressType*",
                    //         "APP_LBL_DELIVERY": "Delivery",
                    //         "APP_LBL_MADDRESS": "Is Main Address",
                    //         "APP_GRD_LBL_STREET": "Street",
                    //         "APP_GRD_LBL_ADAREA": "Area",
                    //         "APP_GRD_LBL_CITY": "CityName",
                    //         "APP_GRD_LBL_ZIP": "Zip",
                    //         "APP_GRD_LBL_COUNTRY": "CountryCode",
                    //         "APP_GRD_LBL_STATE": "StateId",
                    //         "APP_GRD_LBL_ADDRESS": "AddressTypeId",
                    //         "APP_GRD_LBL_DELIVERY": "Delivery",
                    //         "APP_GRD_LBL_MADDRESS": "MainAddress",
                    //         "APP_LBL_GRPS": "Choose Groups",
                    //         "APP_LBL_LOAD": "Loading",
                    //         "APP_BTN_SAVE": "Save Changes",
                    //         "APP_LNK_LBL_MORE": "More",
                    //         "APP_LNK_LBL_LESS": "Less"
                    //     }
                    // }
                    //debugger;    
                    var temp = this._languageService.getCookie("RememberKey");
                    if (temp != "" && temp != undefined) {
                        var password = this._languageService.getCookie("password");
                        if (password.length > 0)
                            var password = password.substring(1, password.length);
                        this._LoggeduserModel = {
                            userName: UserName,
                            password: password,
                            orgName: orgName,
                            lang: lang,
                            rememberMe: rememberMe
                        };
                        this.IsLogedIn = true;
                        if (this._LoggeduserModel["userName"] != undefined && this._LoggeduserModel["userName"] != null && this._LoggeduserModel["userName"] != ""
                            && this._LoggeduserModel["password"] != undefined && this._LoggeduserModel["password"] != null && this._LoggeduserModel["password"] != ""
                            && this._LoggeduserModel["orgName"] != undefined && this._LoggeduserModel["orgName"] != null && this._LoggeduserModel["orgName"] != "") {
                            this._amaxSservice.validateLogin(this._LoggeduserModel["userName"], this._LoggeduserModel["password"], this._LoggeduserModel["orgName"], this._LoggeduserModel["rememberMe"]).subscribe(function (data) {
                                var dta = $.parseJSON(data).Data;
                                //debugger;
                                if (dta.error != undefined && dta.error != null && dta.error != "") {
                                    if (dta.error != "") {
                                        bootbox.alert({
                                            message: dta.error,
                                            className: _this.ChangeDialog,
                                            buttons: {
                                                ok: {
                                                    //label: 'Ok',
                                                    className: _this.CHANGEDIR
                                                }
                                            }
                                        });
                                    }
                                }
                                else {
                                    _this.IsLogedIn = true;
                                    _this.LoginData = dta;
                                    sessionStorage.setItem('XToken', dta["token"]);
                                    sessionStorage.setItem('sessionInformation', atob(dta["token"].split('.')[0]));
                                    sessionStorage.setItem('userInformation', atob(dta["token"].split('.')[1]));
                                    //Featching Userinformation
                                    _this.LoginData = JSON.parse(atob(dta["token"].split('.')[1]));
                                    localStorage.setItem("employeeid", _this.LoginData.employeeid);
                                    //localStorage.setItem("OrgId", this._LoggeduserModel["orgName"]);
                                    if (localStorage.getItem("lang") == "" || localStorage.getItem("lang") == undefined || localStorage.getItem("lang") == null) {
                                        localStorage.setItem("lang", "en");
                                    }
                                    //alert(this._LoggeduserModel["rememberMe"].toString());
                                    //  debugger;
                                    //alert(this._LoggeduserModel["rememberMe"]);
                                    if (_this._LoggeduserModel["rememberMe"] == true || _this._LoggeduserModel["rememberMe"] == "true") {
                                        var lang = localStorage.getItem("lang");
                                        //alert(lang);
                                        //this._languageService.setCookie("langresource", lang,10);
                                        _this._languageService.setCookie("RememberKey", data, 10);
                                        _this._languageService.setCookie("UserName", _this._LoggeduserModel["userName"], 10);
                                        _this._languageService.setCookie("password", _this._LoggeduserModel["password"], 10);
                                        _this._languageService.setCookie("orgName", _this._LoggeduserModel["orgName"], 10);
                                        _this._languageService.setCookie("rememberMe", _this._LoggeduserModel["rememberMe"], 10);
                                        _this._languageService.setCookie("lang", lang, 10);
                                    }
                                }
                            }, function (error) { return console.error(error); }, function () {
                            });
                        }
                        else {
                            if (this._LoggeduserModel["userName"] == undefined && this._LoggeduserModel["userName"] == null || this._LoggeduserModel["userName"] == "") {
                                //alert("Please enter valid username");
                                bootbox.alert({
                                    message: "Please enter valid username",
                                    className: this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                            if (this._LoggeduserModel["password"] == undefined && this._LoggeduserModel["password"] == null || this._LoggeduserModel["password"] == "") {
                                //alert("Please enter valid password");
                                bootbox.alert({
                                    message: "Please enter valid password",
                                    className: this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                            if (this._LoggeduserModel["orgName"] == undefined && this._LoggeduserModel["orgName"] == null || this._LoggeduserModel["orgName"] == "") {
                                //alert("Please enter valid organization");
                                bootbox.alert({
                                    message: "Please enter valid password",
                                    className: this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                        }
                    }
                    // if(!localStorage.getItem("langresource")) {
                    //     //this._languageService.GetSelecetdLanguage("en").subscribe(
                    //     //    data=>{
                    //     //        console.log(data);
                    //     //        localStorage.setItem("langresource", JSON.stringify(data));
                    //     //        this.RES = data;
                    //     //    },
                    //     //    error=>console.log("Unable to load Language Data"),
                    //     //    ()=> {
                    //     //        console.log("Language resource loaded");
                    //     //    }
                    //     //);
                    //     this.RES = this._languageService.GetSelecetdLanguage("en");
                    // }else{
                    //     //this.RES=JSON.parse(localStorage.getItem('langresource'));
                    // }
                };
                AmaxAppComponent = __decorate([
                    core_1.Component({
                        selector: 'mx-app',
                        template: "\n        <div dir=\"{{ RES.APP_DIR }}\">\n            <mx-login\n                *ngIf=\"!IsLogedIn\"\n                [(res)]=\"RES.SCREEN_LOGIN\"\n                [dataModel]=\"_userModel\" \n                (ondata)=\"validateUser($event)\" \n                (onlanguage)=\"changeLanguage($event)\"\n            ></mx-login>\n            <div *ngIf=\"IsLogedIn\" class=\"no-skin\">\n                <mx-ui></mx-ui>\n            </div>\n        </div>\n\t",
                        directives: [amaxLoginComponent_1.AmaxLoginComponent, amaxCrmUIComponent_1.AmaxCrmUIComponent, logout_1.AmaxLogoutComponent, amaxLoginComponent_1.AmaxLoginComponent],
                        providers: [AmaxService_1.AmaxService, ResourceService_1.ResourceService]
                    }),
                    router_1.RouteConfig([
                        { path: "/index", name: "IndexRouter", component: index_1.indexComponent },
                        { path: "/default", name: "DefaultRouter", component: default_1.defaultComponent },
                        //Reports Routing
                        { path: "/report", name: "Reports", component: amaxReports_1.AmaxReport },
                        //Forms routing
                        //{ path:"/form", name:"Forms", component:AmaxForms },
                        { path: "/form/:frm", name: "Forms", component: amaxForms_1.AmaxForms },
                        //Employee related routing
                        { path: "/employee/profile", name: "Profile", component: profile_1.AmaxEmployeeProfile },
                        { path: "/employee/settings", name: "Settings", component: settings_1.AmaxEmployeeSettings },
                        //Module Routing
                        { path: "/sms", name: "Sms", component: sms_1.AmaxSmsComponent },
                        { path: "/blank", name: "Blank", component: logout_1.AmaxLogoutComponent },
                        //Customer Routing
                        { path: "/Customer/Add/:Id", name: "AddCustomer", component: addCustomer_1.AmaxCustomers },
                        //Reciept Type
                        { path: "/ReceiptType/:Id", name: "ReceiptType", component: Reciept_1.AmaxReciept },
                        { path: "/ReceiptTemplate/Add/:Id", name: "RecieptTemplate", component: RecieptTemplate_1.AmaxRecieptTemplate },
                        { path: "/Template/Edit/:Id/:FPage", name: "Template", component: Template_1.AmaxTemplate },
                        { path: "/GeneralGroups/View", name: "GeneralGroups", component: GeneralGroups_1.AmaxGeneralGroups },
                        //Templates
                        { path: "/Terminals/Show/:Id", name: "Terminals", component: Terminals_1.AmaxTerminals },
                        //ChargeCredit
                        { path: "/ChargeCredit/:Id/:TermNo", name: "ChargeCreditCard", component: ChargeCreditCard_1.AmaxChargeCredit },
                        //ChargeCredit
                        { path: "/ReceiptSelect/:Id/:CustId", name: "ReceiptSelect", component: ReceiptSelect_1.AmaxReceiptSelect },
                        //ChargeCredit
                        { path: "/ReceiptCreate/:Id/:ReceiptTypeId", name: "ReceiptCreate", component: ReceiptCreate_1.AmaxReceiptCreate }
                    ]), 
                    __metadata('design:paramtypes', [AmaxService_1.AmaxService, ResourceService_1.ResourceService])
                ], AmaxAppComponent);
                return AmaxAppComponent;
            }());
            exports_1("AmaxAppComponent", AmaxAppComponent);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldi9hbWF4QXBwLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztZQXVGQTtnQkFLSSwwQkFBb0IsYUFBMEIsRUFBVSxnQkFBaUM7b0JBQXJFLGtCQUFhLEdBQWIsYUFBYSxDQUFhO29CQUFVLHFCQUFnQixHQUFoQixnQkFBZ0IsQ0FBaUI7b0JBSnpGLGlCQUFZLEdBQVcsY0FBYyxDQUFDO29CQUV0QyxpQkFBWSxHQUFXLEVBQUUsQ0FBQztvQkFDMUIsY0FBUyxHQUFXLEVBQUUsQ0FBQztvQkFRdkIsY0FBUyxHQUFZLEtBQUssQ0FBQztvQkFFcEIsUUFBRyxHQUFXLEVBQUUsQ0FBQztvQkFpSjVCLGVBQVUsR0FBRyxFQUFFLENBQUM7b0JBQ2hCLHFCQUFnQixHQUFHLEVBQUUsQ0FBQztvQkExSmQsK0JBQStCO29CQUMvQixJQUFJLENBQUMsR0FBRyxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUM7b0JBQzNCLElBQUksQ0FBQyxZQUFZLEdBQUcsY0FBYyxDQUFDO29CQUNuQyxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUM7Z0JBRWhELENBQUM7Z0JBTUQsOENBQW1CLEdBQW5CO29CQUNJLEVBQUUsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsaUJBQWlCLENBQUMsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO3dCQUNwRCxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUM7d0JBQ3ZFLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUM7NEJBQUMsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7b0JBQzlDLENBQUM7Z0JBQ0wsQ0FBQztnQkFDRixxQ0FBVSxHQUFWLFVBQVcsUUFBUTtvQkFBbkIsaUJBNkJDO29CQTVCRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsUUFBUSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFDN0UsWUFBWTt3QkFDWCxRQUFRLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDakMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQix5QkFBeUI7NEJBQ3pCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO2dDQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQzVCLE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUVGLFlBQVksQ0FBQyxPQUFPLENBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQ3BFLFlBQVksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLFFBQVEsQ0FBQyxDQUFDOzRCQUN2QyxLQUFJLENBQUMsR0FBRyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7d0JBRTdCLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7Z0JBQ1AsQ0FBQztnQkFDSix3Q0FBYSxHQUFiO29CQUFBLGlCQXdHSztvQkF2R0QseUJBQXlCO29CQUN6QixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUU7MkJBQ2pILElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRTsyQkFDcEgsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO3dCQUN2SCxJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUMzSixVQUFBLElBQUk7NEJBQ0EsSUFBSSxHQUFHLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUM7NEJBQ2pDLFdBQVc7NEJBQ1gsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssSUFBSSxTQUFTLElBQUksR0FBRyxDQUFDLEtBQUssSUFBSSxJQUFJLElBQUksR0FBRyxDQUFDLEtBQUssSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO2dDQUNqRSxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7b0NBQ2xCLG1CQUFtQjtvQ0FDbkIsT0FBTyxDQUFDLEtBQUssQ0FBQyxFQUFFLE9BQU8sRUFBRSxHQUFHLENBQUMsS0FBSzt3Q0FDOUIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO3dDQUM1QixPQUFPLEVBQUU7NENBQ0wsRUFBRSxFQUFFO2dEQUNBLGNBQWM7Z0RBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTOzZDQUM1Qjt5Q0FDSjtxQ0FDUixDQUFDLENBQUM7Z0NBQ0gsQ0FBQzs0QkFDTCxDQUFDOzRCQUNELElBQUksQ0FBQyxDQUFDO2dDQUNGLEtBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDO2dDQUN0QixLQUFJLENBQUMsU0FBUyxHQUFHLEdBQUcsQ0FBQztnQ0FDckIsY0FBYyxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUE7Z0NBQzlDLGNBQWMsQ0FBQyxPQUFPLENBQUMsb0JBQW9CLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUMvRSxjQUFjLENBQUMsT0FBTyxDQUFDLGlCQUFpQixFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FFNUUsMkJBQTJCO2dDQUUzQixLQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUM5RCxZQUFZLENBQUMsT0FBTyxDQUFDLFlBQVksRUFBRSxLQUFJLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO2dDQUM5RCw0REFBNEQ7Z0NBQzVELEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSxJQUFJLFlBQVksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLElBQUksU0FBUyxJQUFJLFlBQVksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQztvQ0FDMUgsWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0NBQ3ZDLENBQUM7Z0NBQ0Qsa0RBQWtEO2dDQUNsRCxhQUFhO2dDQUNiLHVDQUF1QztnQ0FDdkMsRUFBRSxDQUFDLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsSUFBSSxJQUFJLElBQUksS0FBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsSUFBSSxNQUFNLENBQUMsQ0FBQyxDQUFDO29DQUVuRixJQUFJLElBQUksR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO29DQUN4QyxjQUFjO29DQUNkLDJEQUEyRDtvQ0FDM0QsS0FBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxhQUFhLEVBQUUsSUFBSSxFQUFFLEVBQUUsQ0FBQyxDQUFDO29DQUN6RCxLQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSxLQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO29DQUM3RSxLQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSxLQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO29DQUM3RSxLQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLFNBQVMsRUFBRSxLQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO29DQUMzRSxLQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLFlBQVksRUFBRSxLQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO29DQUNqRixLQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsRUFBRSxDQUFDLENBQUM7Z0NBQ3RELENBQUM7NEJBQ0wsQ0FBQzt3QkFFTCxDQUFDLEVBRUQsVUFBQSxLQUFLLElBQUksT0FBQSxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFwQixDQUFvQixFQUM3Qjt3QkFFQSxDQUFDLENBQ0osQ0FBQTtvQkFDTCxDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUNGLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzs0QkFDdkgsdUNBQXVDOzRCQUN2QyxPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSw2QkFBNkI7Z0NBQ3RDLFNBQVMsRUFBRSxJQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDOzRCQUN2SCx1Q0FBdUM7NEJBQ3ZDLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLDZCQUE2QjtnQ0FDdEMsU0FBUyxFQUFFLElBQUksQ0FBQyxZQUFZO2dDQUM1QixPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7NEJBQ3BILDJDQUEyQzs0QkFDM0MsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsNkJBQTZCO2dDQUN0QyxTQUFTLEVBQUUsSUFBSSxDQUFDLFlBQVk7Z0NBQzVCLE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO29CQUNMLENBQUM7Z0JBQ0QsQ0FBQztnQkFLRCx1Q0FBWSxHQUFaLFVBQWEsR0FBRztvQkFDWixPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUNqQixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7Z0JBQ3pCLENBQUM7Z0JBRU0saURBQXNCLEdBQTdCLFVBQThCLFVBQVU7b0JBQXhDLGlCQW1EQztvQkFsREcsV0FBVztvQkFDWCxPQUFPLENBQUMsR0FBRyxDQUFDLHNCQUFzQixDQUFDLENBQUM7b0JBQ3BDLEVBQUUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7d0JBQ2IsSUFBSSxDQUFDLGdCQUFnQixDQUFDLG1CQUFtQixDQUFDLFVBQVUsQ0FBQyxDQUFDLFNBQVMsQ0FDM0QsVUFBQSxJQUFJOzRCQUNBLFlBQVksQ0FBQyxPQUFPLENBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFFM0QsWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsVUFBVSxDQUFDLENBQUM7NEJBQ3pDLEtBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLEdBQUcsVUFBVSxDQUFDO3dCQUV6QyxDQUFDLEVBQ0QsVUFBQSxLQUFLLElBQUksT0FBQSxPQUFPLENBQUMsR0FBRyxDQUFDLDhCQUE4QixDQUFDLEVBQTNDLENBQTJDLEVBQ3BEOzRCQUNJLE9BQU8sQ0FBQyxHQUFHLENBQUMsMEJBQTBCLENBQUMsQ0FBQzt3QkFDNUMsQ0FBQyxDQUNKLENBQUM7d0JBRUYsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLFVBQVUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7NEJBQzlFLFdBQVc7NEJBQ1gsUUFBUSxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7NEJBQ2pDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQztnQ0FDM0IseUJBQXlCO2dDQUN6QixPQUFPLENBQUMsS0FBSyxDQUFDO29DQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtvQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO29DQUM1QixPQUFPLEVBQUU7d0NBQ0wsRUFBRSxFQUFFOzRDQUNBLGNBQWM7NENBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3lDQUM1QjtxQ0FDSjtpQ0FDSixDQUFDLENBQUM7NEJBQ1AsQ0FBQzs0QkFDRCxJQUFJLENBQUMsQ0FBQztnQ0FDRixZQUFZLENBQUMsT0FBTyxDQUFDLGNBQWMsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dDQUNwRSxZQUFZLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxVQUFVLENBQUMsQ0FBQztnQ0FDekMsS0FBSSxDQUFDLEdBQUcsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDOzRCQUU3QixDQUFDO3dCQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7NEJBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQzt3QkFDdkIsQ0FBQyxFQUFFOzRCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7d0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUdQLENBQUM7b0JBQ0QsSUFBSSxDQUFDLENBQUM7d0JBQ0YsT0FBTyxDQUFDLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO29CQUN4QyxDQUFDO2dCQUNMLENBQUM7Z0JBR00seUNBQWMsR0FBckIsVUFBc0IsR0FBRztvQkFBekIsaUJBbURDO29CQWxERyxXQUFXO29CQUNYLE9BQU8sQ0FBQyxHQUFHLENBQUMsc0JBQXNCLENBQUMsQ0FBQztvQkFDcEMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7d0JBQ1gsSUFBSSxDQUFDLGdCQUFnQixDQUFDLG1CQUFtQixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxTQUFTLENBQ3pELFVBQUEsSUFBSTs0QkFDQSxZQUFZLENBQUMsT0FBTyxDQUFDLGNBQWMsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBRTNELFlBQVksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQzs0QkFDdkMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFDO3dCQUV2QyxDQUFDLEVBQ0QsVUFBQSxLQUFLLElBQUksT0FBQSxPQUFPLENBQUMsR0FBRyxDQUFDLDhCQUE4QixDQUFDLEVBQTNDLENBQTJDLEVBQ3BEOzRCQUNJLE9BQU8sQ0FBQyxHQUFHLENBQUMsMEJBQTBCLENBQUMsQ0FBQzt3QkFDNUMsQ0FBQyxDQUNKLENBQUM7d0JBRUYsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFROzRCQUM1RSxXQUFXOzRCQUNYLFFBQVEsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDOzRCQUNqQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7Z0NBQzNCLHlCQUF5QjtnQ0FDekIsT0FBTyxDQUFDLEtBQUssQ0FBQztvQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07b0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtvQ0FDNUIsT0FBTyxFQUFFO3dDQUNMLEVBQUUsRUFBRTs0Q0FDQSxjQUFjOzRDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUzt5Q0FDNUI7cUNBQ0o7aUNBQ0osQ0FBQyxDQUFDOzRCQUNQLENBQUM7NEJBQ0QsSUFBSSxDQUFDLENBQUM7Z0NBQ0YsWUFBWSxDQUFDLE9BQU8sQ0FBQyxjQUFjLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztnQ0FDcEUsWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDO2dDQUN2QyxLQUFJLENBQUMsR0FBRyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7NEJBRTdCLENBQUM7d0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzs0QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO3dCQUN2QixDQUFDLEVBQUU7NEJBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTt3QkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBR1AsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixPQUFPLENBQUMsS0FBSyxDQUFDLG9CQUFvQixDQUFDLENBQUM7b0JBQ3hDLENBQUM7Z0JBQ0wsQ0FBQztnQkFHRCxtQ0FBUSxHQUFSO29CQUNJLFdBQVc7b0JBRGYsaUJBa1RDO29CQS9TRyxJQUFJLENBQUMsWUFBWSxHQUFHLGNBQWMsQ0FBQztvQkFFbkMsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztvQkFDM0QscUJBQXFCO29CQUNyQixFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsSUFBSSxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUUsR0FBRyxDQUFDO3dCQUN4QyxJQUFJLFFBQVEsR0FBRyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQ3pELDZEQUE2RDtvQkFFN0QsMkJBQTJCO29CQUMzQiw0REFBNEQ7b0JBQzVELElBQUksT0FBTyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUM7b0JBRXpELEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO3dCQUNuQixJQUFJLE9BQU8sR0FBRyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQ3ZELElBQUksVUFBVSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDLENBQUM7b0JBRS9ELEVBQUUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO3dCQUN0QixJQUFJLFVBQVUsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQ2hFLElBQUksQ0FBQyxDQUFDO3dCQUNGLFVBQVUsR0FBRyxNQUFNLENBQUM7b0JBQ3hCLENBQUM7b0JBQ0QsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFFbkQsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7d0JBQ2hCLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDOUMsRUFBRSxDQUFDLENBQUMsSUFBSSxJQUFJLEVBQUUsQ0FBQzt3QkFDWCxJQUFJLEdBQUcsSUFBSSxDQUFDO29CQUVoQixZQUFZLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQztvQkFDM0IsSUFBSSxDQUFDLFVBQVUsR0FBRzt3QkFDZCxRQUFRLEVBQUUsUUFBUTt3QkFDbEIsUUFBUSxFQUFFLEVBQUU7d0JBQ1osT0FBTyxFQUFFLE9BQU87d0JBQ2hCLElBQUksRUFBRSxJQUFJO3dCQUNWLFVBQVUsRUFBRSxVQUFVO3FCQUNqQyxDQUFBO29CQUNPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUV4RSxRQUFRLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDakMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQix5QkFBeUI7NEJBQ3pCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO2dDQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQzVCLE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLFdBQVc7NEJBQ1gsWUFBWSxDQUFDLE9BQU8sQ0FBQyxjQUFjLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDcEUsWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUM7NEJBQ25DLEtBQUksQ0FBQyxHQUFHLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzt3QkFFN0IsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFDWCxjQUFjO29CQUVkLHdCQUF3QjtvQkFDeEIsd0JBQXdCO29CQUN4Qix3QkFBd0I7b0JBQ3hCLGtDQUFrQztvQkFDbEMsK0JBQStCO29CQUMvQix5REFBeUQ7b0JBQ3pELDJEQUEyRDtvQkFDM0Qsc0NBQXNDO29CQUN0QyxzQ0FBc0M7b0JBQ3RDLDRDQUE0QztvQkFDNUMsNkNBQTZDO29CQUU3QyxvQ0FBb0M7b0JBQ3BDLHdEQUF3RDtvQkFDeEQsbURBQW1EO29CQUNuRCxTQUFTO29CQUNULDJCQUEyQjtvQkFDM0Isc0NBQXNDO29CQUN0QyxrQ0FBa0M7b0JBQ2xDLGtEQUFrRDtvQkFDbEQsMENBQTBDO29CQUMxQyw0Q0FBNEM7b0JBQzVDLDZDQUE2QztvQkFDN0MsNkNBQTZDO29CQUM3QywrQ0FBK0M7b0JBQy9DLGtEQUFrRDtvQkFDbEQsbURBQW1EO29CQUNuRCw0Q0FBNEM7b0JBRTVDLCtDQUErQztvQkFDL0MsNENBQTRDO29CQUM1Qyx5Q0FBeUM7b0JBQ3pDLHVDQUF1QztvQkFDdkMsNENBQTRDO29CQUM1Qyw0Q0FBNEM7b0JBQzVDLHFDQUFxQztvQkFDckMsdUNBQXVDO29CQUN2QyxxQ0FBcUM7b0JBQ3JDLHlDQUF5QztvQkFDekMsZ0RBQWdEO29CQUNoRCx5Q0FBeUM7b0JBQ3pDLHFDQUFxQztvQkFFckMsd0NBQXdDO29CQUN4QyxvQ0FBb0M7b0JBQ3BDLHVDQUF1QztvQkFDdkMsNENBQTRDO29CQUU1QyxrQ0FBa0M7b0JBQ2xDLHNDQUFzQztvQkFFdEMsaUNBQWlDO29CQUNqQyxxQ0FBcUM7b0JBRXJDLGtDQUFrQztvQkFDbEMsc0NBQXNDO29CQUV0Qyw2Q0FBNkM7b0JBQzdDLG1EQUFtRDtvQkFDbkQsd0NBQXdDO29CQUN4Qyx3Q0FBd0M7b0JBQ3hDLHFDQUFxQztvQkFDckMsd0NBQXdDO29CQUN4Qyx3Q0FBd0M7b0JBQ3hDLHVDQUF1QztvQkFFdkMsMkNBQTJDO29CQUMzQyx3Q0FBd0M7b0JBQ3hDLHVDQUF1QztvQkFDdkMsK0NBQStDO29CQUMvQyw0Q0FBNEM7b0JBQzVDLDRDQUE0QztvQkFDNUMsdUNBQXVDO29CQUN2Qyx3Q0FBd0M7b0JBQ3hDLHNDQUFzQztvQkFDdEMsb0NBQW9DO29CQUNwQywrQ0FBK0M7b0JBQy9DLDBDQUEwQztvQkFDMUMsb0RBQW9EO29CQUVwRCwwQ0FBMEM7b0JBQzFDLGlEQUFpRDtvQkFDakQsMENBQTBDO29CQUMxQyx3Q0FBd0M7b0JBQ3hDLDBDQUEwQztvQkFDMUMsb0NBQW9DO29CQUNwQyxnREFBZ0Q7b0JBQ2hELDBDQUEwQztvQkFDMUMsa0RBQWtEO29CQUNsRCw4Q0FBOEM7b0JBQzlDLGlEQUFpRDtvQkFDakQsMkNBQTJDO29CQUMzQyxxQ0FBcUM7b0JBQ3JDLDBDQUEwQztvQkFDMUMsc0NBQXNDO29CQUN0QyxxQ0FBcUM7b0JBRXJDLFFBQVE7b0JBQ0EsSUFBSTtvQkFDSixlQUFlO29CQUNmLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsYUFBYSxDQUFDLENBQUM7b0JBQzFELEVBQUUsQ0FBQyxDQUFDLElBQUksSUFBSSxFQUFFLElBQUksSUFBSSxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUM7d0JBQ2xDLElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7d0JBRXZFLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDOzRCQUNwQixJQUFJLFFBQVEsR0FBRyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUM7d0JBQzlDLElBQUksQ0FBQyxnQkFBZ0IsR0FBRzs0QkFDNUIsUUFBUSxFQUFFLFFBQVE7NEJBQ2xCLFFBQVEsRUFBRSxRQUFROzRCQUNsQixPQUFPLEVBQUUsT0FBTzs0QkFDaEIsSUFBSSxFQUFFLElBQUk7NEJBQ1YsVUFBVSxFQUFFLFVBQVU7eUJBQ3pCLENBQUE7d0JBR0QsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7d0JBQ3RCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRTsrQkFDbkksSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFOytCQUN0SSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7NEJBQ3pJLElBQUksQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsRUFBRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLEVBQUUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FDbkwsVUFBQSxJQUFJO2dDQUNBLElBQUksR0FBRyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDO2dDQUNqQyxXQUFXO2dDQUNYLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLElBQUksU0FBUyxJQUFJLEdBQUcsQ0FBQyxLQUFLLElBQUksSUFBSSxJQUFJLEdBQUcsQ0FBQyxLQUFLLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQztvQ0FDakUsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO3dDQUNsQixPQUFPLENBQUMsS0FBSyxDQUFDOzRDQUNWLE9BQU8sRUFBRSxHQUFHLENBQUMsS0FBSzs0Q0FDbEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZOzRDQUM1QixPQUFPLEVBQUU7Z0RBQ0wsRUFBRSxFQUFFO29EQUNBLGNBQWM7b0RBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO2lEQUM1Qjs2Q0FDSjt5Q0FDSixDQUFDLENBQUM7b0NBQ1AsQ0FBQztnQ0FDTCxDQUFDO2dDQUNELElBQUksQ0FBQyxDQUFDO29DQUNGLEtBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDO29DQUN0QixLQUFJLENBQUMsU0FBUyxHQUFHLEdBQUcsQ0FBQztvQ0FDckIsY0FBYyxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUE7b0NBQzlDLGNBQWMsQ0FBQyxPQUFPLENBQUMsb0JBQW9CLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO29DQUMvRSxjQUFjLENBQUMsT0FBTyxDQUFDLGlCQUFpQixFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQ0FFNUUsMkJBQTJCO29DQUUzQixLQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO29DQUM5RCxZQUFZLENBQUMsT0FBTyxDQUFDLFlBQVksRUFBRSxLQUFJLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO29DQUM5RCxrRUFBa0U7b0NBQ2xFLEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSxJQUFJLFlBQVksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLElBQUksU0FBUyxJQUFJLFlBQVksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzt3Q0FDMUgsWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUM7b0NBQ3ZDLENBQUM7b0NBQ0Qsd0RBQXdEO29DQUN4RCxhQUFhO29DQUNiLDZDQUE2QztvQ0FDN0MsRUFBRSxDQUFDLENBQUMsS0FBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQyxJQUFJLElBQUksSUFBSSxLQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxDQUFDLElBQUksTUFBTSxDQUFDLENBQUMsQ0FBQzt3Q0FFL0YsSUFBSSxJQUFJLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQzt3Q0FDeEMsY0FBYzt3Q0FDZCwyREFBMkQ7d0NBQzNELEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsYUFBYSxFQUFFLElBQUksRUFBRSxFQUFFLENBQUMsQ0FBQzt3Q0FDekQsS0FBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxVQUFVLEVBQUUsS0FBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO3dDQUNuRixLQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSxLQUFJLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7d0NBQ25GLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsU0FBUyxFQUFFLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQzt3Q0FDakYsS0FBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxZQUFZLEVBQUUsS0FBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO3dDQUN2RixLQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsRUFBRSxDQUFDLENBQUM7b0NBQ3RELENBQUM7Z0NBQ0wsQ0FBQzs0QkFFTCxDQUFDLEVBRUQsVUFBQSxLQUFLLElBQUksT0FBQSxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFwQixDQUFvQixFQUM3Qjs0QkFFQSxDQUFDLENBQ0osQ0FBQTt3QkFDTCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQztnQ0FDekksdUNBQXVDO2dDQUN2QyxPQUFPLENBQUMsS0FBSyxDQUFDO29DQUNWLE9BQU8sRUFBRSw2QkFBNkI7b0NBQ3RDLFNBQVMsRUFBRSxJQUFJLENBQUMsWUFBWTtvQ0FDNUIsT0FBTyxFQUFFO3dDQUNMLEVBQUUsRUFBRTs0Q0FDQSxjQUFjOzRDQUNkLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUzt5Q0FDNUI7cUNBQ0o7aUNBQ0osQ0FBQyxDQUFDOzRCQUNQLENBQUM7NEJBQ0QsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO2dDQUN6SSx1Q0FBdUM7Z0NBQ3ZDLE9BQU8sQ0FBQyxLQUFLLENBQUM7b0NBQ1YsT0FBTyxFQUFFLDZCQUE2QjtvQ0FDdEMsU0FBUyxFQUFFLElBQUksQ0FBQyxZQUFZO29DQUM1QixPQUFPLEVBQUU7d0NBQ0wsRUFBRSxFQUFFOzRDQUNBLGNBQWM7NENBQ2QsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO3lDQUM1QjtxQ0FDSjtpQ0FDSixDQUFDLENBQUM7NEJBQ1AsQ0FBQzs0QkFDRCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0NBQ3RJLDJDQUEyQztnQ0FDM0MsT0FBTyxDQUFDLEtBQUssQ0FBQztvQ0FDVixPQUFPLEVBQUUsNkJBQTZCO29DQUN0QyxTQUFTLEVBQUUsSUFBSSxDQUFDLFlBQVk7b0NBQzVCLE9BQU8sRUFBRTt3Q0FDTCxFQUFFLEVBQUU7NENBQ0EsY0FBYzs0Q0FDZCxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVM7eUNBQzVCO3FDQUNKO2lDQUNKLENBQUMsQ0FBQzs0QkFDUCxDQUFDO3dCQUNMLENBQUM7b0JBR0wsQ0FBQztvQkFDRCw4Q0FBOEM7b0JBQzlDLG1FQUFtRTtvQkFDbkUsb0JBQW9CO29CQUNwQixtQ0FBbUM7b0JBQ25DLDRFQUE0RTtvQkFDNUUsaUNBQWlDO29CQUNqQyxlQUFlO29CQUNmLGdFQUFnRTtvQkFDaEUsbUJBQW1CO29CQUNuQix5REFBeUQ7b0JBQ3pELGNBQWM7b0JBQ2QsV0FBVztvQkFDWCxrRUFBa0U7b0JBQ2xFLFNBQVM7b0JBQ1QsbUVBQW1FO29CQUNuRSxJQUFJO2dCQUNSLENBQUM7Z0JBbG9CTDtvQkFBQyxnQkFBUyxDQUFDO3dCQUNQLFFBQVEsRUFBRSxRQUFRO3dCQUNsQixRQUFRLEVBQUUsNGNBYVo7d0JBQ0UsVUFBVSxFQUFFLENBQUMsdUNBQWtCLEVBQUUsdUNBQWtCLEVBQUUsNEJBQW1CLEVBQUUsdUNBQWtCLENBQUM7d0JBQzdGLFNBQVMsRUFBRSxDQUFDLHlCQUFXLEVBQUUsaUNBQWUsQ0FBQztxQkFDNUMsQ0FBQztvQkFFRCxvQkFBVyxDQUFDO3dCQUNULEVBQUUsSUFBSSxFQUFDLFFBQVEsRUFBcUIsSUFBSSxFQUFDLGFBQWEsRUFBYyxTQUFTLEVBQUMsc0JBQWMsRUFBRTt3QkFDOUYsRUFBRSxJQUFJLEVBQUMsVUFBVSxFQUFtQixJQUFJLEVBQUMsZUFBZSxFQUFZLFNBQVMsRUFBQywwQkFBZ0IsRUFBRTt3QkFFaEcsaUJBQWlCO3dCQUNqQixFQUFFLElBQUksRUFBQyxTQUFTLEVBQW9CLElBQUksRUFBQyxTQUFTLEVBQWtCLFNBQVMsRUFBRSx3QkFBVSxFQUFFO3dCQUUzRixlQUFlO3dCQUNmLHNEQUFzRDt3QkFDdEQsRUFBRSxJQUFJLEVBQUMsWUFBWSxFQUFpQixJQUFJLEVBQUMsT0FBTyxFQUFvQixTQUFTLEVBQUMscUJBQVMsRUFBRTt3QkFFekYsMEJBQTBCO3dCQUMxQixFQUFFLElBQUksRUFBQyxtQkFBbUIsRUFBVSxJQUFJLEVBQUMsU0FBUyxFQUFrQixTQUFTLEVBQUUsNkJBQW1CLEVBQUU7d0JBQ3BHLEVBQUUsSUFBSSxFQUFDLG9CQUFvQixFQUFTLElBQUksRUFBQyxVQUFVLEVBQWlCLFNBQVMsRUFBRSwrQkFBb0IsRUFBRTt3QkFHckcsZ0JBQWdCO3dCQUNmLEVBQUUsSUFBSSxFQUFDLE1BQU0sRUFBdUIsSUFBSSxFQUFDLEtBQUssRUFBc0IsU0FBUyxFQUFFLHNCQUFnQixFQUFDO3dCQUdqRyxFQUFFLElBQUksRUFBQyxRQUFRLEVBQXFCLElBQUksRUFBQyxPQUFPLEVBQW9CLFNBQVMsRUFBRSw0QkFBbUIsRUFBQzt3QkFFdEcsa0JBQWtCO3dCQUNmLEVBQUUsSUFBSSxFQUFFLG1CQUFtQixFQUFFLElBQUksRUFBRSxhQUFhLEVBQUUsU0FBUyxFQUFFLDJCQUFhLEVBQUU7d0JBQzVFLGNBQWM7d0JBQ2QsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUUsSUFBSSxFQUFFLGFBQWEsRUFBRSxTQUFTLEVBQUUscUJBQVcsRUFBRTt3QkFFekUsRUFBRSxJQUFJLEVBQUUsMEJBQTBCLEVBQUUsSUFBSSxFQUFFLGlCQUFpQixFQUFFLFNBQVMsRUFBRSxxQ0FBbUIsRUFBRTt3QkFFN0YsRUFBRSxJQUFJLEVBQUUsMkJBQTJCLEVBQUUsSUFBSSxFQUFFLFVBQVUsRUFBRSxTQUFTLEVBQUUsdUJBQVksRUFBRTt3QkFDaEYsRUFBRSxJQUFJLEVBQUUscUJBQXFCLEVBQUUsSUFBSSxFQUFFLGVBQWUsRUFBRSxTQUFTLEVBQUUsaUNBQWlCLEVBQUU7d0JBQ3BGLFdBQVc7d0JBQ1gsRUFBRSxJQUFJLEVBQUUscUJBQXFCLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRSxTQUFTLEVBQUUseUJBQWEsRUFBRTt3QkFDNUUsY0FBYzt3QkFDZCxFQUFFLElBQUksRUFBRSwyQkFBMkIsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUUsU0FBUyxFQUFFLG1DQUFnQixFQUFFO3dCQUM1RixjQUFjO3dCQUNkLEVBQUUsSUFBSSxFQUFFLDRCQUE0QixFQUFFLElBQUksRUFBRSxlQUFlLEVBQUUsU0FBUyxFQUFFLGlDQUFpQixFQUFFO3dCQUMzRixjQUFjO3dCQUNkLEVBQUUsSUFBSSxFQUFFLG1DQUFtQyxFQUFFLElBQUksRUFBRSxlQUFlLEVBQUUsU0FBUyxFQUFFLGlDQUFpQixFQUFFO3FCQUNyRyxDQUFDOztvQ0FBQTtnQkF3a0JGLHVCQUFDO1lBQUQsQ0F0a0JBLEFBc2tCQyxJQUFBO1lBdGtCRCwrQ0Fza0JDLENBQUEiLCJmaWxlIjoiZGV2L2FtYXhBcHAuY29tcG9uZW50LmpzIiwic291cmNlc0NvbnRlbnQiOlsiLy8vPHJlZmVyZW5jZSBwYXRoPVwic2VydmljZXMvQW1heFNlcnZpY2UudHNcIi8+XHJcbmltcG9ydCB7IENvbXBvbmVudCwgT25Jbml0IH0gZnJvbSAnYW5ndWxhcjIvY29yZSc7XHJcbmltcG9ydCB7IEFtYXhDcm1VSUNvbXBvbmVudCB9IGZyb20gJy4vYW1heENvbXBvbmVudHMvYW1heENybVVJQ29tcG9uZW50JztcclxuaW1wb3J0IHsgQW1heExvZ2luQ29tcG9uZW50IH0gZnJvbSAnLi9hbWF4Q29tcG9uZW50cy9hbWF4TG9naW5Db21wb25lbnQnO1xyXG5pbXBvcnQgeyBBbWF4U2VydmljZSB9IGZyb20gJy4vc2VydmljZXMvQW1heFNlcnZpY2UnO1xyXG5pbXBvcnQge1Jlc291cmNlU2VydmljZX0gZnJvbSBcIi4vc2VydmljZXMvUmVzb3VyY2VTZXJ2aWNlXCI7XHJcbmltcG9ydCB7aW5kZXhDb21wb25lbnR9IGZyb20gXCIuL2FtYXgvcXVpY2thY2Nlc3MvaW5kZXhcIjtcclxuaW1wb3J0IHtkZWZhdWx0Q29tcG9uZW50fSBmcm9tIFwiLi9hbWF4L3F1aWNrYWNjZXNzL2RlZmF1bHRcIjtcclxuaW1wb3J0IHtSb3V0ZUNvbmZpZ30gZnJvbSBcImFuZ3VsYXIyL3JvdXRlclwiO1xyXG5pbXBvcnQge0FtYXhMb2dvdXRDb21wb25lbnR9IGZyb20gXCIuL2FtYXgvbG9nb3V0XCI7XHJcbmltcG9ydCB7QW1heFJlcG9ydH0gZnJvbSBcIi4vYW1heC9yZXBvcnRzL2FtYXhSZXBvcnRzXCI7XHJcbmltcG9ydCB7QW1heEZvcm1zfSBmcm9tIFwiLi9hbWF4L2Zvcm1zL2FtYXhGb3Jtc1wiO1xyXG5pbXBvcnQge09ic2VydmFibGV9IGZyb20gXCJyeGpzL09ic2VydmFibGVcIjtcclxuaW1wb3J0IHtBbWF4RW1wbG95ZWVQcm9maWxlfSBmcm9tIFwiLi9hbWF4L2VtcGxveWVlL3Byb2ZpbGVcIjtcclxuaW1wb3J0IHtBbWF4RW1wbG95ZWVTZXR0aW5nc30gZnJvbSBcIi4vYW1heC9lbXBsb3llZS9zZXR0aW5nc1wiO1xyXG5pbXBvcnQge0FtYXhTbXNDb21wb25lbnR9IGZyb20gXCIuL2FtYXgvc21zXCI7XHJcbmltcG9ydCB7QW1heEN1c3RvbWVyc30gZnJvbSBcIi4vYW1heC9DdXN0b21lci9hZGRDdXN0b21lclwiO1xyXG5pbXBvcnQge0FtYXhSZWNpZXB0fSBmcm9tIFwiLi9hbWF4L1JlY2llcHRUeXBlL1JlY2llcHRcIjtcclxuaW1wb3J0IHtBbWF4UmVjaWVwdFRlbXBsYXRlfSBmcm9tIFwiLi9hbWF4L1JlY2llcHRUeXBlL1JlY2llcHRUZW1wbGF0ZVwiO1xyXG5pbXBvcnQge0FtYXhUZW1wbGF0ZX0gZnJvbSBcIi4vYW1heC9SZWNpZXB0VHlwZS9UZW1wbGF0ZVwiO1xyXG5pbXBvcnQge0FtYXhHZW5lcmFsR3JvdXBzfSBmcm9tIFwiLi9hbWF4L0dlbmVyYWxHcm91cHMvR2VuZXJhbEdyb3Vwc1wiO1xyXG5pbXBvcnQge0FtYXhUZXJtaW5hbHN9IGZyb20gXCIuL2FtYXgvQ2hhcmdlX0NyZWRpdC9UZXJtaW5hbHNcIjtcclxuaW1wb3J0IHtBbWF4Q2hhcmdlQ3JlZGl0fSBmcm9tIFwiLi9hbWF4L0NoYXJnZV9DcmVkaXQvQ2hhcmdlQ3JlZGl0Q2FyZFwiO1xyXG5pbXBvcnQge0FtYXhSZWNlaXB0U2VsZWN0fSBmcm9tIFwiLi9hbWF4L1JlY2VpcHQvUmVjZWlwdFNlbGVjdFwiO1xyXG5pbXBvcnQge0FtYXhSZWNlaXB0Q3JlYXRlfSBmcm9tIFwiLi9hbWF4L1JlY2VpcHQvUmVjZWlwdENyZWF0ZVwiO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ214LWFwcCcsXHJcbiAgICB0ZW1wbGF0ZTogYFxyXG4gICAgICAgIDxkaXYgZGlyPVwie3sgUkVTLkFQUF9ESVIgfX1cIj5cclxuICAgICAgICAgICAgPG14LWxvZ2luXHJcbiAgICAgICAgICAgICAgICAqbmdJZj1cIiFJc0xvZ2VkSW5cIlxyXG4gICAgICAgICAgICAgICAgWyhyZXMpXT1cIlJFUy5TQ1JFRU5fTE9HSU5cIlxyXG4gICAgICAgICAgICAgICAgW2RhdGFNb2RlbF09XCJfdXNlck1vZGVsXCIgXHJcbiAgICAgICAgICAgICAgICAob25kYXRhKT1cInZhbGlkYXRlVXNlcigkZXZlbnQpXCIgXHJcbiAgICAgICAgICAgICAgICAob25sYW5ndWFnZSk9XCJjaGFuZ2VMYW5ndWFnZSgkZXZlbnQpXCJcclxuICAgICAgICAgICAgPjwvbXgtbG9naW4+XHJcbiAgICAgICAgICAgIDxkaXYgKm5nSWY9XCJJc0xvZ2VkSW5cIiBjbGFzcz1cIm5vLXNraW5cIj5cclxuICAgICAgICAgICAgICAgIDxteC11aT48L214LXVpPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHRgLFxyXG4gICAgZGlyZWN0aXZlczogW0FtYXhMb2dpbkNvbXBvbmVudCwgQW1heENybVVJQ29tcG9uZW50LCBBbWF4TG9nb3V0Q29tcG9uZW50LCBBbWF4TG9naW5Db21wb25lbnRdLFxyXG4gICAgcHJvdmlkZXJzOiBbQW1heFNlcnZpY2UsIFJlc291cmNlU2VydmljZV1cclxufSlcclxuXHJcbkBSb3V0ZUNvbmZpZyhbXHJcbiAgICB7IHBhdGg6XCIvaW5kZXhcIiwgICAgICAgICAgICAgICAgICAgIG5hbWU6XCJJbmRleFJvdXRlclwiLCAgICAgICAgICAgICBjb21wb25lbnQ6aW5kZXhDb21wb25lbnQgfSxcclxuICAgIHsgcGF0aDpcIi9kZWZhdWx0XCIsICAgICAgICAgICAgICAgICAgbmFtZTpcIkRlZmF1bHRSb3V0ZXJcIiwgICAgICAgICAgIGNvbXBvbmVudDpkZWZhdWx0Q29tcG9uZW50IH0sXHJcblxyXG4gICAgLy9SZXBvcnRzIFJvdXRpbmdcclxuICAgIHsgcGF0aDpcIi9yZXBvcnRcIiwgICAgICAgICAgICAgICAgICAgbmFtZTpcIlJlcG9ydHNcIiwgICAgICAgICAgICAgICAgIGNvbXBvbmVudDogQW1heFJlcG9ydCB9LFxyXG5cclxuICAgIC8vRm9ybXMgcm91dGluZ1xyXG4gICAgLy97IHBhdGg6XCIvZm9ybVwiLCBuYW1lOlwiRm9ybXNcIiwgY29tcG9uZW50OkFtYXhGb3JtcyB9LFxyXG4gICAgeyBwYXRoOlwiL2Zvcm0vOmZybVwiLCAgICAgICAgICAgICAgICBuYW1lOlwiRm9ybXNcIiwgICAgICAgICAgICAgICAgICAgY29tcG9uZW50OkFtYXhGb3JtcyB9LFxyXG5cclxuICAgIC8vRW1wbG95ZWUgcmVsYXRlZCByb3V0aW5nXHJcbiAgICB7IHBhdGg6XCIvZW1wbG95ZWUvcHJvZmlsZVwiLCAgICAgICAgIG5hbWU6XCJQcm9maWxlXCIsICAgICAgICAgICAgICAgICBjb21wb25lbnQ6IEFtYXhFbXBsb3llZVByb2ZpbGUgfSxcclxuICAgIHsgcGF0aDpcIi9lbXBsb3llZS9zZXR0aW5nc1wiLCAgICAgICAgbmFtZTpcIlNldHRpbmdzXCIsICAgICAgICAgICAgICAgIGNvbXBvbmVudDogQW1heEVtcGxveWVlU2V0dGluZ3MgfSxcclxuXHJcblxyXG4gICAgLy9Nb2R1bGUgUm91dGluZ1xyXG4gICAgIHsgcGF0aDpcIi9zbXNcIiwgICAgICAgICAgICAgICAgICAgICAgbmFtZTpcIlNtc1wiLCAgICAgICAgICAgICAgICAgICAgIGNvbXBvbmVudDogQW1heFNtc0NvbXBvbmVudH0sXHJcblxyXG5cclxuICAgIHsgcGF0aDpcIi9ibGFua1wiLCAgICAgICAgICAgICAgICAgICAgbmFtZTpcIkJsYW5rXCIsICAgICAgICAgICAgICAgICAgIGNvbXBvbmVudDogQW1heExvZ291dENvbXBvbmVudH0sIC8vZm9yIHRoZSB0ZXN0aW5nXHJcblx0XHJcblx0Ly9DdXN0b21lciBSb3V0aW5nXHJcbiAgICB7IHBhdGg6IFwiL0N1c3RvbWVyL0FkZC86SWRcIiwgbmFtZTogXCJBZGRDdXN0b21lclwiLCBjb21wb25lbnQ6IEFtYXhDdXN0b21lcnMgfSxcclxuICAgIC8vUmVjaWVwdCBUeXBlXHJcbiAgICB7IHBhdGg6IFwiL1JlY2VpcHRUeXBlLzpJZFwiLCBuYW1lOiBcIlJlY2VpcHRUeXBlXCIsIGNvbXBvbmVudDogQW1heFJlY2llcHQgfSxcclxuXHJcbiAgICB7IHBhdGg6IFwiL1JlY2VpcHRUZW1wbGF0ZS9BZGQvOklkXCIsIG5hbWU6IFwiUmVjaWVwdFRlbXBsYXRlXCIsIGNvbXBvbmVudDogQW1heFJlY2llcHRUZW1wbGF0ZSB9LFxyXG4gICAgXHJcbiAgICB7IHBhdGg6IFwiL1RlbXBsYXRlL0VkaXQvOklkLzpGUGFnZVwiLCBuYW1lOiBcIlRlbXBsYXRlXCIsIGNvbXBvbmVudDogQW1heFRlbXBsYXRlIH0sXHJcbiAgICB7IHBhdGg6IFwiL0dlbmVyYWxHcm91cHMvVmlld1wiLCBuYW1lOiBcIkdlbmVyYWxHcm91cHNcIiwgY29tcG9uZW50OiBBbWF4R2VuZXJhbEdyb3VwcyB9LFxyXG4gICAgLy9UZW1wbGF0ZXNcclxuICAgIHsgcGF0aDogXCIvVGVybWluYWxzL1Nob3cvOklkXCIsIG5hbWU6IFwiVGVybWluYWxzXCIsIGNvbXBvbmVudDogQW1heFRlcm1pbmFscyB9LFxyXG4gICAgLy9DaGFyZ2VDcmVkaXRcclxuICAgIHsgcGF0aDogXCIvQ2hhcmdlQ3JlZGl0LzpJZC86VGVybU5vXCIsIG5hbWU6IFwiQ2hhcmdlQ3JlZGl0Q2FyZFwiLCBjb21wb25lbnQ6IEFtYXhDaGFyZ2VDcmVkaXQgfSxcclxuICAgIC8vQ2hhcmdlQ3JlZGl0XHJcbiAgICB7IHBhdGg6IFwiL1JlY2VpcHRTZWxlY3QvOklkLzpDdXN0SWRcIiwgbmFtZTogXCJSZWNlaXB0U2VsZWN0XCIsIGNvbXBvbmVudDogQW1heFJlY2VpcHRTZWxlY3QgfSxcclxuICAgIC8vQ2hhcmdlQ3JlZGl0XHJcbiAgICB7IHBhdGg6IFwiL1JlY2VpcHRDcmVhdGUvOklkLzpSZWNlaXB0VHlwZUlkXCIsIG5hbWU6IFwiUmVjZWlwdENyZWF0ZVwiLCBjb21wb25lbnQ6IEFtYXhSZWNlaXB0Q3JlYXRlIH1cclxuXSlcclxuXHJcbmV4cG9ydCBjbGFzcyBBbWF4QXBwQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcclxuICAgIEZvcm1UeXBlRm9ybTogc3RyaW5nID0gXCJTQ1JFRU5fTE9HSU5cIjtcclxuICAgIGJhc2VVcmw6IHN0cmluZztcclxuICAgIENoYW5nZURpYWxvZzogc3RyaW5nID0gXCJcIjtcclxuICAgIENIQU5HRURJUjogc3RyaW5nID0gXCJcIjtcclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgX2FtYXhTc2VydmljZTogQW1heFNlcnZpY2UsIHByaXZhdGUgX2xhbmd1YWdlU2VydmljZTogUmVzb3VyY2VTZXJ2aWNlKSB7XHJcbiAgICAgICAgLy9Mb2FkaW5nIHRoZSBsYW5ndWFnZSByZXNvdXJjZVxyXG4gICAgICAgIHRoaXMuUkVTLlNDUkVFTl9MT0dJTiA9IHt9O1xyXG4gICAgICAgIHRoaXMuRm9ybVR5cGVGb3JtID0gXCJTQ1JFRU5fTE9HSU5cIjtcclxuICAgICAgICB0aGlzLmJhc2VVcmwgPSB0aGlzLl9sYW5ndWFnZVNlcnZpY2UuQXBwVXJsO1xyXG4gICAgICAgIFxyXG4gICAgfVxyXG4gICAgSXNMb2dlZEluOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwdWJsaWMgTG9naW5EYXRhOiBPYmplY3Q7XHJcbiAgICBwdWJsaWMgUkVTOiBPYmplY3QgPSB7fTtcclxuICAgICAgICBcclxuXHJcbiAgICBsb2FkVXNlckluZm9ybWF0aW9uKCkge1xyXG4gICAgICAgIGlmIChzZXNzaW9uU3RvcmFnZS5nZXRJdGVtKCd1c2VySW5mb3JtYXRpb24nKSAhPSBudWxsKSB7XHJcbiAgICAgICAgICAgIHRoaXMuTG9naW5EYXRhID0gSlNPTi5wYXJzZShzZXNzaW9uU3RvcmFnZS5nZXRJdGVtKCd1c2VySW5mb3JtYXRpb24nKSk7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLkxvZ2luRGF0YSkgdGhpcy5Jc0xvZ2VkSW4gPSB0cnVlO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgZ2V0bGFuZ3JlcyhsYW5nY29kZSkge1xyXG4gICAgICAgdGhpcy5fbGFuZ3VhZ2VTZXJ2aWNlLkdldExhbmdSZXModGhpcy5Gb3JtVHlwZUZvcm0sIGxhbmdjb2RlKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICAgICByZXNwb25zZSA9ICQucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgIC8vYWxlcnQocmVzcG9uc2UuRXJyTXNnKTtcclxuICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgIH1cclxuICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwibGFuZ3Jlc291cmNlXCIsIEpTT04uc3RyaW5naWZ5KHJlc3BvbnNlLkRhdGEpKTtcclxuICAgICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJsYW5nXCIsIGxhbmdjb2RlKTtcclxuICAgICAgICAgICAgICAgdGhpcy5SRVMgPSByZXNwb25zZS5EYXRhO1xyXG5cclxuICAgICAgICAgICB9XHJcbiAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICB9KTtcclxuICAgfVxyXG52YWxpZGF0ZUxvZ2luKCkge1xyXG4gICAgLy90aGlzLklzTG9nZWRJbiA9IHRydWU7IFxyXG4gICAgaWYgKHRoaXMuX3VzZXJNb2RlbFtcInVzZXJOYW1lXCJdICE9IHVuZGVmaW5lZCAmJiB0aGlzLl91c2VyTW9kZWxbXCJ1c2VyTmFtZVwiXSAhPSBudWxsICYmIHRoaXMuX3VzZXJNb2RlbFtcInVzZXJOYW1lXCJdICE9IFwiXCJcclxuICAgICAgICAmJiB0aGlzLl91c2VyTW9kZWxbXCJwYXNzd29yZFwiXSAhPSB1bmRlZmluZWQgJiYgdGhpcy5fdXNlck1vZGVsW1wicGFzc3dvcmRcIl0gIT0gbnVsbCAmJiB0aGlzLl91c2VyTW9kZWxbXCJwYXNzd29yZFwiXSAhPSBcIlwiXHJcbiAgICAgICAgJiYgdGhpcy5fdXNlck1vZGVsW1wib3JnTmFtZVwiXSAhPSB1bmRlZmluZWQgJiYgdGhpcy5fdXNlck1vZGVsW1wib3JnTmFtZVwiXSAhPSBudWxsICYmIHRoaXMuX3VzZXJNb2RlbFtcIm9yZ05hbWVcIl0gIT0gXCJcIikge1xyXG4gICAgICAgIHRoaXMuX2FtYXhTc2VydmljZS52YWxpZGF0ZUxvZ2luKHRoaXMuX3VzZXJNb2RlbFtcInVzZXJOYW1lXCJdLCB0aGlzLl91c2VyTW9kZWxbXCJwYXNzd29yZFwiXSwgdGhpcy5fdXNlck1vZGVsW1wib3JnTmFtZVwiXSwgdGhpcy5fdXNlck1vZGVsW1wicmVtZW1iZXJNZVwiXSkuc3Vic2NyaWJlKFxyXG4gICAgICAgICAgICBkYXRhID0+IHtcclxuICAgICAgICAgICAgICAgIHZhciBkdGEgPSAkLnBhcnNlSlNPTihkYXRhKS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgIGlmIChkdGEuZXJyb3IgIT0gdW5kZWZpbmVkICYmIGR0YS5lcnJvciAhPSBudWxsICYmIGR0YS5lcnJvciAhPSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGR0YS5lcnJvciAhPSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vYWxlcnQoZHRhLmVycm9yKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7IG1lc3NhZ2U6IGR0YS5lcnJvcixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLklzTG9nZWRJbiA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5Mb2dpbkRhdGEgPSBkdGE7XHJcbiAgICAgICAgICAgICAgICAgICAgc2Vzc2lvblN0b3JhZ2Uuc2V0SXRlbSgnWFRva2VuJywgZHRhW1widG9rZW5cIl0pXHJcbiAgICAgICAgICAgICAgICAgICAgc2Vzc2lvblN0b3JhZ2Uuc2V0SXRlbSgnc2Vzc2lvbkluZm9ybWF0aW9uJywgYXRvYihkdGFbXCJ0b2tlblwiXS5zcGxpdCgnLicpWzBdKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgc2Vzc2lvblN0b3JhZ2Uuc2V0SXRlbSgndXNlckluZm9ybWF0aW9uJywgYXRvYihkdGFbXCJ0b2tlblwiXS5zcGxpdCgnLicpWzFdKSk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIC8vRmVhdGNoaW5nIFVzZXJpbmZvcm1hdGlvblxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5Mb2dpbkRhdGEgPSBKU09OLnBhcnNlKGF0b2IoZHRhW1widG9rZW5cIl0uc3BsaXQoJy4nKVsxXSkpO1xyXG4gICAgICAgICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwiZW1wbG95ZWVpZFwiLCB0aGlzLkxvZ2luRGF0YS5lbXBsb3llZWlkKTtcclxuICAgICAgICAgICAgICAgICAgICAvL2xvY2FsU3RvcmFnZS5zZXRJdGVtKFwiT3JnSWRcIiwgdGhpcy5fdXNlck1vZGVsW1wib3JnTmFtZVwiXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwibGFuZ1wiKSA9PSBcIlwiIHx8IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwibGFuZ1wiKSA9PSB1bmRlZmluZWQgfHwgbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJsYW5nXCIpID09IG51bGwpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJsYW5nXCIsIFwiZW5cIik7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8vYWxlcnQodGhpcy5fdXNlck1vZGVsW1wicmVtZW1iZXJNZVwiXS50b1N0cmluZygpKTtcclxuICAgICAgICAgICAgICAgICAgICAvLyAgZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9hbGVydCh0aGlzLl91c2VyTW9kZWxbXCJyZW1lbWJlck1lXCJdKTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5fdXNlck1vZGVsW1wicmVtZW1iZXJNZVwiXSA9PSB0cnVlIHx8IHRoaXMuX3VzZXJNb2RlbFtcInJlbWVtYmVyTWVcIl0gPT0gXCJ0cnVlXCIpIHtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBsYW5nID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJsYW5nXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2FsZXJ0KGxhbmcpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL3RoaXMuX2xhbmd1YWdlU2VydmljZS5zZXRDb29raWUoXCJsYW5ncmVzb3VyY2VcIiwgbGFuZywxMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2xhbmd1YWdlU2VydmljZS5zZXRDb29raWUoXCJSZW1lbWJlcktleVwiLCBkYXRhLCAxMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2xhbmd1YWdlU2VydmljZS5zZXRDb29raWUoXCJVc2VyTmFtZVwiLCB0aGlzLl91c2VyTW9kZWxbXCJ1c2VyTmFtZVwiXSwgMTApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9sYW5ndWFnZVNlcnZpY2Uuc2V0Q29va2llKFwicGFzc3dvcmRcIiwgdGhpcy5fdXNlck1vZGVsW1wicGFzc3dvcmRcIl0sIDEwKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fbGFuZ3VhZ2VTZXJ2aWNlLnNldENvb2tpZShcIm9yZ05hbWVcIiwgdGhpcy5fdXNlck1vZGVsW1wib3JnTmFtZVwiXSwgMTApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9sYW5ndWFnZVNlcnZpY2Uuc2V0Q29va2llKFwicmVtZW1iZXJNZVwiLCB0aGlzLl91c2VyTW9kZWxbXCJyZW1lbWJlck1lXCJdLCAxMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2xhbmd1YWdlU2VydmljZS5zZXRDb29raWUoXCJsYW5nXCIsIGxhbmcsIDEwKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgZXJyb3IgPT4gY29uc29sZS5lcnJvcihlcnJvciksXHJcbiAgICAgICAgICAgICgpID0+IHtcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgKVxyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgICAgaWYgKHRoaXMuX3VzZXJNb2RlbFtcInVzZXJOYW1lXCJdID09IHVuZGVmaW5lZCAmJiB0aGlzLl91c2VyTW9kZWxbXCJ1c2VyTmFtZVwiXSA9PSBudWxsIHx8IHRoaXMuX3VzZXJNb2RlbFtcInVzZXJOYW1lXCJdID09IFwiXCIpIHtcclxuICAgICAgICAgICAgLy9hbGVydChcIlBsZWFzZSBlbnRlciB2YWxpZCB1c2VybmFtZVwiKTtcclxuICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICBtZXNzYWdlOiBcIlBsZWFzZSBlbnRlciB2YWxpZCB1c2VybmFtZVwiLFxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHRoaXMuX3VzZXJNb2RlbFtcInBhc3N3b3JkXCJdID09IHVuZGVmaW5lZCAmJiB0aGlzLl91c2VyTW9kZWxbXCJwYXNzd29yZFwiXSA9PSBudWxsIHx8IHRoaXMuX3VzZXJNb2RlbFtcInBhc3N3b3JkXCJdID09IFwiXCIpIHtcclxuICAgICAgICAgICAgLy9hbGVydChcIlBsZWFzZSBlbnRlciB2YWxpZCBwYXNzd29yZFwiKTtcclxuICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICBtZXNzYWdlOiBcIlBsZWFzZSBlbnRlciB2YWxpZCBwYXNzd29yZFwiLFxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHRoaXMuX3VzZXJNb2RlbFtcIm9yZ05hbWVcIl0gPT0gdW5kZWZpbmVkICYmIHRoaXMuX3VzZXJNb2RlbFtcIm9yZ05hbWVcIl0gPT0gbnVsbCB8fCB0aGlzLl91c2VyTW9kZWxbXCJvcmdOYW1lXCJdID09IFwiXCIpIHtcclxuICAgICAgICAgICAgLy9hbGVydChcIlBsZWFzZSBlbnRlciB2YWxpZCBvcmdhbml6YXRpb25cIik7XHJcbiAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgbWVzc2FnZTogXCJQbGVhc2UgZW50ZXIgdmFsaWQgcGFzc3dvcmRcIixcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgfVxyXG5cclxuX3VzZXJNb2RlbCA9IHt9O1xyXG5fTG9nZ2VkdXNlck1vZGVsID0ge307XHJcblxyXG4gICAgdmFsaWRhdGVVc2VyKGV2dCkge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGV2dCk7XHJcbiAgICAgICAgdGhpcy52YWxpZGF0ZUxvZ2luKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGNoYW5nZUxhbmd1YWdlQnlMYW5nSWQoTGFuZ3VhZ2VJZCkge1xyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCJDaGFuZ2luZyBMYW5ndWFnZS4uLlwiKTtcclxuICAgICAgICBpZiAoTGFuZ3VhZ2VJZCkge1xyXG4gICAgICAgICAgICB0aGlzLl9sYW5ndWFnZVNlcnZpY2UuR2V0U2VsZWNldGRMYW5ndWFnZShMYW5ndWFnZUlkKS5zdWJzY3JpYmUoXHJcbiAgICAgICAgICAgICAgICBkYXRhID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImxhbmdyZXNvdXJjZVwiLCBKU09OLnN0cmluZ2lmeShkYXRhKSk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwibGFuZ1wiLCBMYW5ndWFnZUlkKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl91c2VyTW9kZWxbXCJsYW5nXCJdID0gTGFuZ3VhZ2VJZDtcclxuXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgZXJyb3IgPT4gY29uc29sZS5sb2coXCJVbmFibGUgdG8gbG9hZCBMYW5ndWFnZSBEYXRhXCIpLFxyXG4gICAgICAgICAgICAgICAgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiTGFuZ3VhZ2UgcmVzb3VyY2UgbG9hZGVkXCIpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgICAgdGhpcy5fbGFuZ3VhZ2VTZXJ2aWNlLkdldExhbmdSZXModGhpcy5Gb3JtVHlwZUZvcm0sIExhbmd1YWdlSWQpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICByZXNwb25zZSA9ICQucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAvL2FsZXJ0KHJlc3BvbnNlLkVyck1zZyk7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJsYW5ncmVzb3VyY2VcIiwgSlNPTi5zdHJpbmdpZnkocmVzcG9uc2UuRGF0YSkpO1xyXG4gICAgICAgICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwibGFuZ1wiLCBMYW5ndWFnZUlkKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLlJFUyA9IHJlc3BvbnNlLkRhdGE7XHJcblxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgICAgIH0pO1xyXG5cclxuXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiQ29kZSBub3Qgc3BlY2lmaWVkXCIpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcblxyXG4gICAgcHVibGljIGNoYW5nZUxhbmd1YWdlKGV2dCkge1xyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCJDaGFuZ2luZyBMYW5ndWFnZS4uLlwiKTtcclxuICAgICAgICBpZiAoZXZ0LmNvZGUpIHtcclxuICAgICAgICAgICAgdGhpcy5fbGFuZ3VhZ2VTZXJ2aWNlLkdldFNlbGVjZXRkTGFuZ3VhZ2UoZXZ0LmNvZGUpLnN1YnNjcmliZShcclxuICAgICAgICAgICAgICAgIGRhdGEgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwibGFuZ3Jlc291cmNlXCIsIEpTT04uc3RyaW5naWZ5KGRhdGEpKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJsYW5nXCIsIGV2dC5jb2RlKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl91c2VyTW9kZWxbXCJsYW5nXCJdID0gZXZ0LmNvZGU7XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgZXJyb3IgPT4gY29uc29sZS5sb2coXCJVbmFibGUgdG8gbG9hZCBMYW5ndWFnZSBEYXRhXCIpLFxyXG4gICAgICAgICAgICAgICAgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiTGFuZ3VhZ2UgcmVzb3VyY2UgbG9hZGVkXCIpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgICAgdGhpcy5fbGFuZ3VhZ2VTZXJ2aWNlLkdldExhbmdSZXModGhpcy5Gb3JtVHlwZUZvcm0sIGV2dC5jb2RlKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgcmVzcG9uc2UgPSAkLnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9hbGVydChyZXNwb25zZS5FcnJNc2cpO1xyXG4gICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwibGFuZ3Jlc291cmNlXCIsIEpTT04uc3RyaW5naWZ5KHJlc3BvbnNlLkRhdGEpKTtcclxuICAgICAgICAgICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImxhbmdcIiwgZXZ0LmNvZGUpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuUkVTID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgICAgICB9KTtcclxuXHJcblxyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIkNvZGUgbm90IHNwZWNpZmllZFwiKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG5cclxuICAgIG5nT25Jbml0KCkge1xyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcblxyXG4gICAgICAgIHRoaXMuRm9ybVR5cGVGb3JtID0gXCJTQ1JFRU5fTE9HSU5cIjtcclxuXHJcbiAgICAgICAgdmFyIFVzZXJOYW1lID0gdGhpcy5fbGFuZ3VhZ2VTZXJ2aWNlLmdldENvb2tpZShcIlVzZXJOYW1lXCIpO1xyXG4gICAgICAgIC8vYWxlcnQoVXNlck5hbWVbMF0pO1xyXG4gICAgICAgIGlmIChVc2VyTmFtZS5sZW5ndGggPiAwICYmIFVzZXJOYW1lWzBdPT1cIj1cIikgXHJcbiAgICAgICAgICAgIHZhciBVc2VyTmFtZSA9IFVzZXJOYW1lLnN1YnN0cmluZygxLFVzZXJOYW1lLmxlbmd0aCk7XHJcbiAgICAgICAgLy92YXIgcGFzc3dvcmQgPSB0aGlzLl9sYW5ndWFnZVNlcnZpY2UuZ2V0Q29va2llKFwicGFzc3dvcmRcIik7XHJcblxyXG4gICAgICAgIC8vaWYgKHBhc3N3b3JkLmxlbmd0aCA+IDApIFxyXG4gICAgICAgIC8vICAgIHZhciBwYXNzd29yZCA9IHBhc3N3b3JkLnN1YnN0cmluZygxLCBwYXNzd29yZC5sZW5ndGgpO1xyXG4gICAgICAgIHZhciBvcmdOYW1lID0gdGhpcy5fbGFuZ3VhZ2VTZXJ2aWNlLmdldENvb2tpZShcIm9yZ05hbWVcIik7XHJcblxyXG4gICAgICAgIGlmIChvcmdOYW1lLmxlbmd0aCA+IDApIFxyXG4gICAgICAgICAgICB2YXIgb3JnTmFtZSA9IG9yZ05hbWUuc3Vic3RyaW5nKDEsIG9yZ05hbWUubGVuZ3RoKTtcclxuICAgICAgICB2YXIgcmVtZW1iZXJNZSA9IHRoaXMuX2xhbmd1YWdlU2VydmljZS5nZXRDb29raWUoXCJyZW1lbWJlck1lXCIpO1xyXG5cclxuICAgICAgICBpZiAocmVtZW1iZXJNZS5sZW5ndGggPiAwKVxyXG4gICAgICAgICAgICB2YXIgcmVtZW1iZXJNZSA9IHJlbWVtYmVyTWUuc3Vic3RyaW5nKDEsIHJlbWVtYmVyTWUubGVuZ3RoKTtcclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgcmVtZW1iZXJNZSA9IFwidHJ1ZVwiO1xyXG4gICAgICAgIH1cclxuICAgICAgICB2YXIgbGFuZyA9IHRoaXMuX2xhbmd1YWdlU2VydmljZS5nZXRDb29raWUoXCJsYW5nXCIpO1xyXG4gICAgICAgIFxyXG4gICAgICAgIGlmIChsYW5nLmxlbmd0aCA+IDApXHJcbiAgICAgICAgICAgIHZhciBsYW5nID0gbGFuZy5zdWJzdHJpbmcoMSwgbGFuZy5sZW5ndGgpO1xyXG4gICAgICAgIGlmIChsYW5nID09IFwiXCIpXHJcbiAgICAgICAgICAgIGxhbmcgPSBcImVuXCI7XHJcbiAgICAgICBcclxuICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImxhbmdcIiwgbGFuZyk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl91c2VyTW9kZWwgPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdXNlck5hbWU6IFVzZXJOYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgIHBhc3N3b3JkOiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICAgIG9yZ05hbWU6IG9yZ05hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgbGFuZzogbGFuZyxcclxuICAgICAgICAgICAgICAgICAgICByZW1lbWJlck1lOiByZW1lbWJlck1lXHJcbiAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgdGhpcy5fbGFuZ3VhZ2VTZXJ2aWNlLkdldExhbmdSZXModGhpcy5Gb3JtVHlwZUZvcm0sIGxhbmcpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICByZXNwb25zZSA9ICQucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vYWxlcnQocmVzcG9uc2UuRXJyTXNnKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJsYW5ncmVzb3VyY2VcIiwgSlNPTi5zdHJpbmdpZnkocmVzcG9uc2UuRGF0YSkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImxhbmdcIiwgbGFuZyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuUkVTID0gcmVzcG9uc2UuRGF0YTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgICAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgLy90aGlzLlJFUyA9IHtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgLy8gICAgIFwiQVBQX0RJUlwiOiBcImx0clwiLFxyXG4gICAgICAgIC8vICAgICBcIkFQUF9MQU5HXCI6IFwiZW5cIixcclxuICAgICAgICAvLyAgICAgXCJTQ1JFRU5fTE9HSU5cIjoge1xyXG4gICAgICAgIC8vICAgICAgICAgXCJDT01QQU5ZX05BTUVcIjogXCJBbWF4XCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9UWVBFXCI6IFwiQy5SLk1cIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0JBU0VMSU5FXCI6IFwiwqkgQW1heCAtIHNvZnR3YXJlIHNvbHV0aW9uc1wiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfTEJMX0lORk9cIjogXCJQbGVhc2UgRW50ZXIgWW91ciBJbmZvcm1hdGlvblwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfTEJMX1VTRVJcIjogXCJVc2VybmFtZVwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfTEJMX1BBU1NcIjogXCJQYXNzd29yZFwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfTEJMX09SR1wiOiBcIk9yZ2FuaXphdGlvbiBJRFwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfTEJMX1JFTUVNQkVSXCI6IFwiUmVtZW1iZXIgTWVcIixcclxuXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9CVE5fTE9HSU5cIjogXCJMb2dpblwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfTEJMX0ZPUkdPVFBBU1NcIjogXCJJIGZvcmdvdCBteSBwYXNzd29yZFwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfTEJMX1JFR0lTVEVSXCI6IFwiSSB3YW50IHRvIHJlZ2lzdGVyXCJcclxuICAgICAgICAvLyAgICAgfSxcclxuICAgICAgICAvLyAgICAgXCJDVVNUT01FUl9NQVNURVJcIjoge1xyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfTEJMX0NVU1RcIjogXCJDdXN0b21lclwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfTEJMX0NBUkRcIjogXCJDYXJkXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9MQkxfTkVXX0NVU1RcIjogXCJBZGQgTmV3IEN1c3RvbWVyXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9UWFRfUkVRRFwiOiBcIihSZXF1aXJlZC0qKVwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfVFhUX1BIX0xOQU1FXCI6IFwiTGFzdCBOYW1lKlwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfVFhUX1BIX0ZOQU1FXCI6IFwiRmlyc3QgTmFtZSpcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX1RYVF9QSF9NTkFNRVwiOiBcIk1pZGRsZSBOYW1lXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9UWFRfUEhfQ05BTUVcIjogXCJDb21wYW55IE5hbWUqXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9EUF9DVFlQRVwiOiBcIlNlbGVjdCBDdXN0b21lciBUeXBlXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9EUF9FTVBcIjogXCJTZWxlY3QgQ29udGFjdCBFbXBsb3llZVwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfRFBfU09VUkNFXCI6IFwiU2VsZWN0IFNvdXJjZVwiLFxyXG5cclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX1RYVF9QSF9DQ09ERVwiOiBcIkN1c3RvbWVyIENvZGVcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX1RYVF9QSF9CREFURVwiOiBcIkJpcnRoIERhdGVcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX1RYVF9QSF9KT0JcIjogXCJKb2IgVGl0bGVcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX1RYVF9QSF9USVRMRVwiOiBcIlRpdGxlXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9EUF9TVUZGSVhcIjogXCJTZWxlY3QgU3VmZml4XCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9EUF9HRU5ERVJcIjogXCJTZWxlY3QgR2VuZGVyXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9EUF9HRU5ERVJfTVwiOiBcIk1hbGVcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0RQX0dFTkRFUl9GXCI6IFwiRmVtYWxlXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9MQkxfUEhPTkVcIjogXCJQaG9uZXNcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0xCTF9BRERfUEhcIjogXCJBZGQgUGhvbmVcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0RQX1BUWVBFXCI6IFwiU2VsZWN0IFBob25lIFR5cGUqXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9UWFRfUEhfUFJFRklYXCI6IFwiUHJlZml4XCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9UWFRfUEhfQVJFQVwiOiBcIkFyZWFcIixcclxuXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9UWFRfUEhfUEhPTkVcIjogXCJQaG9uZSpcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0xCTF9TTVNcIjogXCJGb3IgU01TXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9DSEtfUEhfU01TXCI6IFwiRm9yIFNNU1wiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfVFhUX1BIX0NPTU1FTlRcIjogXCJDb21tZW50c1wiLFxyXG5cclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0JUTl9QSEFERFwiOiBcIkFkZFwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfQlROX1BIQ0xPU0VcIjogXCJDbG9zZVwiLFxyXG5cclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0JUTl9FQUREXCI6IFwiQWRkXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9CVE5fRUNMT1NFXCI6IFwiQ2xvc2VcIixcclxuXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9CVE5fQURBRERcIjogXCJBZGRcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0JUTl9BRENMT1NFXCI6IFwiQ2xvc2VcIixcclxuXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9HUkRfTEJMX1BUWVBFXCI6IFwiUGhvbmUgVHlwZVwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfR1JEX0xCTF9QSE5PXCI6IFwiUHJlZml4LUFyZWEtUGhvbmVcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0dSRF9MQkxfU01TXCI6IFwiRm9yIFNNU1wiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfR1JEX0xCTF9SRU1cIjogXCJSZW1hcmtzXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9MTktfRU1BSUxcIjogXCJFbWFpbHNcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0xCTF9FTUFJTFwiOiBcIkFkZCBFbWFpbFwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfVFhUX1BIX0VNQUlMXCI6IFwiRW1haWwqXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9UWFRfUEhfRU5BTUVcIjogXCJOYW1lKlwiLFxyXG5cclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0xCTF9OTEVUVEVSXCI6IFwiTmV3c0xldHRlclwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfR1JEX0xCTF9FTUFJTFwiOiBcIkVtYWlsXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9HUkRfTEJMX0VOQU1FXCI6IFwiTmFtZVwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfR1JEX0xCTF9OTEVUVEVSXCI6IFwiTmV3c2xldHRlclwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfTE5LX0xCTF9BRERSU1wiOiBcIkFkZHJlc3Nlc1wiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfTEJMX0FERFJFU1NcIjogXCJBZGQgQWRkcmVzc1wiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfTEJMX1BIX1NUUlwiOiBcIlN0cmVldCpcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0xCTF9QSF9BREFSRUFcIjogXCJBcmVhKlwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfTEJMX1BIX0NJVFlcIjogXCJDaXR5KlwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfTEJMX1BIX1pJUFwiOiBcIlppcCpcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0RQX0NPVU5UUllcIjogXCJTZWxlY3QgQ291bnRyeSpcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0RQX1NUQVRFXCI6IFwiU2VsZWN0IFN0YXRlXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9EUF9BRERSVFlQRVwiOiBcIlNlbGVjdCBBZGRyZXNzVHlwZSpcIixcclxuXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9MQkxfREVMSVZFUllcIjogXCJEZWxpdmVyeVwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfTEJMX01BRERSRVNTXCI6IFwiSXMgTWFpbiBBZGRyZXNzXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9HUkRfTEJMX1NUUkVFVFwiOiBcIlN0cmVldFwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfR1JEX0xCTF9BREFSRUFcIjogXCJBcmVhXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9HUkRfTEJMX0NJVFlcIjogXCJDaXR5TmFtZVwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfR1JEX0xCTF9aSVBcIjogXCJaaXBcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0dSRF9MQkxfQ09VTlRSWVwiOiBcIkNvdW50cnlDb2RlXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9HUkRfTEJMX1NUQVRFXCI6IFwiU3RhdGVJZFwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfR1JEX0xCTF9BRERSRVNTXCI6IFwiQWRkcmVzc1R5cGVJZFwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfR1JEX0xCTF9ERUxJVkVSWVwiOiBcIkRlbGl2ZXJ5XCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9HUkRfTEJMX01BRERSRVNTXCI6IFwiTWFpbkFkZHJlc3NcIixcclxuICAgICAgICAvLyAgICAgICAgIFwiQVBQX0xCTF9HUlBTXCI6IFwiQ2hvb3NlIEdyb3Vwc1wiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfTEJMX0xPQURcIjogXCJMb2FkaW5nXCIsXHJcbiAgICAgICAgLy8gICAgICAgICBcIkFQUF9CVE5fU0FWRVwiOiBcIlNhdmUgQ2hhbmdlc1wiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfTE5LX0xCTF9NT1JFXCI6IFwiTW9yZVwiLFxyXG4gICAgICAgIC8vICAgICAgICAgXCJBUFBfTE5LX0xCTF9MRVNTXCI6IFwiTGVzc1wiXHJcblxyXG4gICAgICAgIC8vICAgICB9XHJcbiAgICAgICAgICAgICAgICAvLyB9XHJcbiAgICAgICAgICAgICAgICAvL2RlYnVnZ2VyOyAgICBcclxuICAgICAgICAgICAgICAgIHZhciB0ZW1wID0gdGhpcy5fbGFuZ3VhZ2VTZXJ2aWNlLmdldENvb2tpZShcIlJlbWVtYmVyS2V5XCIpO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRlbXAgIT0gXCJcIiAmJiB0ZW1wICE9IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBwYXNzd29yZCA9IHRoaXMuX2xhbmd1YWdlU2VydmljZS5nZXRDb29raWUoXCJwYXNzd29yZFwiKTtcclxuXHJcbiAgICAgICAgaWYgKHBhc3N3b3JkLmxlbmd0aCA+IDApIFxyXG4gICAgICAgICAgICB2YXIgcGFzc3dvcmQgPSBwYXNzd29yZC5zdWJzdHJpbmcoMSwgcGFzc3dvcmQubGVuZ3RoKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9Mb2dnZWR1c2VyTW9kZWwgPSB7XHJcbiAgICAgICAgICAgICAgICB1c2VyTmFtZTogVXNlck5hbWUsXHJcbiAgICAgICAgICAgICAgICBwYXNzd29yZDogcGFzc3dvcmQsXHJcbiAgICAgICAgICAgICAgICBvcmdOYW1lOiBvcmdOYW1lLFxyXG4gICAgICAgICAgICAgICAgbGFuZzogbGFuZyxcclxuICAgICAgICAgICAgICAgIHJlbWVtYmVyTWU6IHJlbWVtYmVyTWVcclxuICAgICAgICAgICAgfVxyXG5cclxuXHJcbiAgICAgICAgICAgIHRoaXMuSXNMb2dlZEluID0gdHJ1ZTtcclxuICAgICAgICAgICAgaWYgKHRoaXMuX0xvZ2dlZHVzZXJNb2RlbFtcInVzZXJOYW1lXCJdICE9IHVuZGVmaW5lZCAmJiB0aGlzLl9Mb2dnZWR1c2VyTW9kZWxbXCJ1c2VyTmFtZVwiXSAhPSBudWxsICYmIHRoaXMuX0xvZ2dlZHVzZXJNb2RlbFtcInVzZXJOYW1lXCJdICE9IFwiXCJcclxuICAgICAgICAgICAgICAgICYmIHRoaXMuX0xvZ2dlZHVzZXJNb2RlbFtcInBhc3N3b3JkXCJdICE9IHVuZGVmaW5lZCAmJiB0aGlzLl9Mb2dnZWR1c2VyTW9kZWxbXCJwYXNzd29yZFwiXSAhPSBudWxsICYmIHRoaXMuX0xvZ2dlZHVzZXJNb2RlbFtcInBhc3N3b3JkXCJdICE9IFwiXCJcclxuICAgICAgICAgICAgICAgICYmIHRoaXMuX0xvZ2dlZHVzZXJNb2RlbFtcIm9yZ05hbWVcIl0gIT0gdW5kZWZpbmVkICYmIHRoaXMuX0xvZ2dlZHVzZXJNb2RlbFtcIm9yZ05hbWVcIl0gIT0gbnVsbCAmJiB0aGlzLl9Mb2dnZWR1c2VyTW9kZWxbXCJvcmdOYW1lXCJdICE9IFwiXCIpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2FtYXhTc2VydmljZS52YWxpZGF0ZUxvZ2luKHRoaXMuX0xvZ2dlZHVzZXJNb2RlbFtcInVzZXJOYW1lXCJdLCB0aGlzLl9Mb2dnZWR1c2VyTW9kZWxbXCJwYXNzd29yZFwiXSwgdGhpcy5fTG9nZ2VkdXNlck1vZGVsW1wib3JnTmFtZVwiXSwgdGhpcy5fTG9nZ2VkdXNlck1vZGVsW1wicmVtZW1iZXJNZVwiXSkuc3Vic2NyaWJlKFxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGEgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgZHRhID0gJC5wYXJzZUpTT04oZGF0YSkuRGF0YTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGR0YS5lcnJvciAhPSB1bmRlZmluZWQgJiYgZHRhLmVycm9yICE9IG51bGwgJiYgZHRhLmVycm9yICE9IFwiXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChkdGEuZXJyb3IgIT0gXCJcIikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBkdGEuZXJyb3IsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuSXNMb2dlZEluID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuTG9naW5EYXRhID0gZHRhO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2Vzc2lvblN0b3JhZ2Uuc2V0SXRlbSgnWFRva2VuJywgZHRhW1widG9rZW5cIl0pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXNzaW9uU3RvcmFnZS5zZXRJdGVtKCdzZXNzaW9uSW5mb3JtYXRpb24nLCBhdG9iKGR0YVtcInRva2VuXCJdLnNwbGl0KCcuJylbMF0pKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlc3Npb25TdG9yYWdlLnNldEl0ZW0oJ3VzZXJJbmZvcm1hdGlvbicsIGF0b2IoZHRhW1widG9rZW5cIl0uc3BsaXQoJy4nKVsxXSkpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vRmVhdGNoaW5nIFVzZXJpbmZvcm1hdGlvblxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLkxvZ2luRGF0YSA9IEpTT04ucGFyc2UoYXRvYihkdGFbXCJ0b2tlblwiXS5zcGxpdCgnLicpWzFdKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImVtcGxveWVlaWRcIiwgdGhpcy5Mb2dpbkRhdGEuZW1wbG95ZWVpZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xvY2FsU3RvcmFnZS5zZXRJdGVtKFwiT3JnSWRcIiwgdGhpcy5fTG9nZ2VkdXNlck1vZGVsW1wib3JnTmFtZVwiXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAobG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJsYW5nXCIpID09IFwiXCIgfHwgbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJsYW5nXCIpID09IHVuZGVmaW5lZCB8fCBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImxhbmdcIikgPT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwibGFuZ1wiLCBcImVuXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9hbGVydCh0aGlzLl9Mb2dnZWR1c2VyTW9kZWxbXCJyZW1lbWJlck1lXCJdLnRvU3RyaW5nKCkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gIGRlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9hbGVydCh0aGlzLl9Mb2dnZWR1c2VyTW9kZWxbXCJyZW1lbWJlck1lXCJdKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLl9Mb2dnZWR1c2VyTW9kZWxbXCJyZW1lbWJlck1lXCJdID09IHRydWUgfHwgdGhpcy5fTG9nZ2VkdXNlck1vZGVsW1wicmVtZW1iZXJNZVwiXSA9PSBcInRydWVcIikge1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgbGFuZyA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwibGFuZ1wiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2FsZXJ0KGxhbmcpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vdGhpcy5fbGFuZ3VhZ2VTZXJ2aWNlLnNldENvb2tpZShcImxhbmdyZXNvdXJjZVwiLCBsYW5nLDEwKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9sYW5ndWFnZVNlcnZpY2Uuc2V0Q29va2llKFwiUmVtZW1iZXJLZXlcIiwgZGF0YSwgMTApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2xhbmd1YWdlU2VydmljZS5zZXRDb29raWUoXCJVc2VyTmFtZVwiLCB0aGlzLl9Mb2dnZWR1c2VyTW9kZWxbXCJ1c2VyTmFtZVwiXSwgMTApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2xhbmd1YWdlU2VydmljZS5zZXRDb29raWUoXCJwYXNzd29yZFwiLCB0aGlzLl9Mb2dnZWR1c2VyTW9kZWxbXCJwYXNzd29yZFwiXSwgMTApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2xhbmd1YWdlU2VydmljZS5zZXRDb29raWUoXCJvcmdOYW1lXCIsIHRoaXMuX0xvZ2dlZHVzZXJNb2RlbFtcIm9yZ05hbWVcIl0sIDEwKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9sYW5ndWFnZVNlcnZpY2Uuc2V0Q29va2llKFwicmVtZW1iZXJNZVwiLCB0aGlzLl9Mb2dnZWR1c2VyTW9kZWxbXCJyZW1lbWJlck1lXCJdLCAxMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fbGFuZ3VhZ2VTZXJ2aWNlLnNldENvb2tpZShcImxhbmdcIiwgbGFuZywgMTApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGVycm9yID0+IGNvbnNvbGUuZXJyb3IoZXJyb3IpLFxyXG4gICAgICAgICAgICAgICAgICAgICgpID0+IHtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX0xvZ2dlZHVzZXJNb2RlbFtcInVzZXJOYW1lXCJdID09IHVuZGVmaW5lZCAmJiB0aGlzLl9Mb2dnZWR1c2VyTW9kZWxbXCJ1c2VyTmFtZVwiXSA9PSBudWxsIHx8IHRoaXMuX0xvZ2dlZHVzZXJNb2RlbFtcInVzZXJOYW1lXCJdID09IFwiXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICAvL2FsZXJ0KFwiUGxlYXNlIGVudGVyIHZhbGlkIHVzZXJuYW1lXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBcIlBsZWFzZSBlbnRlciB2YWxpZCB1c2VybmFtZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5fTG9nZ2VkdXNlck1vZGVsW1wicGFzc3dvcmRcIl0gPT0gdW5kZWZpbmVkICYmIHRoaXMuX0xvZ2dlZHVzZXJNb2RlbFtcInBhc3N3b3JkXCJdID09IG51bGwgfHwgdGhpcy5fTG9nZ2VkdXNlck1vZGVsW1wicGFzc3dvcmRcIl0gPT0gXCJcIikge1xyXG4gICAgICAgICAgICAgICAgICAgIC8vYWxlcnQoXCJQbGVhc2UgZW50ZXIgdmFsaWQgcGFzc3dvcmRcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiUGxlYXNlIGVudGVyIHZhbGlkIHBhc3N3b3JkXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9Mb2dnZWR1c2VyTW9kZWxbXCJvcmdOYW1lXCJdID09IHVuZGVmaW5lZCAmJiB0aGlzLl9Mb2dnZWR1c2VyTW9kZWxbXCJvcmdOYW1lXCJdID09IG51bGwgfHwgdGhpcy5fTG9nZ2VkdXNlck1vZGVsW1wib3JnTmFtZVwiXSA9PSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9hbGVydChcIlBsZWFzZSBlbnRlciB2YWxpZCBvcmdhbml6YXRpb25cIik7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiUGxlYXNlIGVudGVyIHZhbGlkIHBhc3N3b3JkXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG5cclxuXHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vIGlmKCFsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImxhbmdyZXNvdXJjZVwiKSkge1xyXG4gICAgICAgIC8vICAgICAvL3RoaXMuX2xhbmd1YWdlU2VydmljZS5HZXRTZWxlY2V0ZExhbmd1YWdlKFwiZW5cIikuc3Vic2NyaWJlKFxyXG4gICAgICAgIC8vICAgICAvLyAgICBkYXRhPT57XHJcbiAgICAgICAgLy8gICAgIC8vICAgICAgICBjb25zb2xlLmxvZyhkYXRhKTtcclxuICAgICAgICAvLyAgICAgLy8gICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwibGFuZ3Jlc291cmNlXCIsIEpTT04uc3RyaW5naWZ5KGRhdGEpKTtcclxuICAgICAgICAvLyAgICAgLy8gICAgICAgIHRoaXMuUkVTID0gZGF0YTtcclxuICAgICAgICAvLyAgICAgLy8gICAgfSxcclxuICAgICAgICAvLyAgICAgLy8gICAgZXJyb3I9PmNvbnNvbGUubG9nKFwiVW5hYmxlIHRvIGxvYWQgTGFuZ3VhZ2UgRGF0YVwiKSxcclxuICAgICAgICAvLyAgICAgLy8gICAgKCk9PiB7XHJcbiAgICAgICAgLy8gICAgIC8vICAgICAgICBjb25zb2xlLmxvZyhcIkxhbmd1YWdlIHJlc291cmNlIGxvYWRlZFwiKTtcclxuICAgICAgICAvLyAgICAgLy8gICAgfVxyXG4gICAgICAgIC8vICAgICAvLyk7XHJcbiAgICAgICAgLy8gICAgIHRoaXMuUkVTID0gdGhpcy5fbGFuZ3VhZ2VTZXJ2aWNlLkdldFNlbGVjZXRkTGFuZ3VhZ2UoXCJlblwiKTtcclxuICAgICAgICAvLyB9ZWxzZXtcclxuICAgICAgICAvLyAgICAgLy90aGlzLlJFUz1KU09OLnBhcnNlKGxvY2FsU3RvcmFnZS5nZXRJdGVtKCdsYW5ncmVzb3VyY2UnKSk7XHJcbiAgICAgICAgLy8gfVxyXG4gICAgfVxyXG59Il19
