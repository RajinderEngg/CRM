System.register(["angular2/core"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1;
    var AmaxTreeView;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            }],
        execute: function() {
            AmaxTreeView = (function () {
                function AmaxTreeView() {
                }
                AmaxTreeView = __decorate([
                    core_1.Component({
                        name: "mx-treeview",
                        template: "\n        <h1>Hello World</h1>\n        <ul id=\"mx-treeview\">\n            <li data-expanded=\"true\">\n                <span class=\"k-sprite folder\"></span>\n                My Web Site\n                <ul>\n                    <li data-expanded=\"true\">\n                        <span class=\"k-sprite folder\"></span>images\n                        <ul>\n                            <li><span class=\"k-sprite image\"></span>logo.png</li>\n                            <li><span class=\"k-sprite image\"></span>body-back.png</li>\n                            <li><span class=\"k-sprite image\"></span>my-photo.jpg</li>\n                        </ul>\n                    </li>\n                    <li data-expanded=\"true\">\n                        <span class=\"k-sprite folder\"></span>resources\n                        <ul>\n                            <li data-expanded=\"true\">\n                                <span class=\"k-sprite folder\"></span>pdf\n                                <ul>\n                                    <li><span class=\"k-sprite pdf\"></span>brochure.pdf</li>\n                                    <li><span class=\"k-sprite pdf\"></span>prices.pdf</li>\n                                </ul>\n                            </li>\n                            <li><span class=\"k-sprite folder\"></span>zip</li>\n                        </ul>\n                    </li>\n                    <li><span class=\"k-sprite html\"></span>about.html</li>\n                    <li><span class=\"k-sprite html\"></span>contacts.html</li>\n                    <li><span class=\"k-sprite html\"></span>index.html</li>\n                    <li><span class=\"k-sprite html\"></span>portfolio.html</li>\n                </ul>\n            </li>\n        </ul>\n    "
                    }), 
                    __metadata('design:paramtypes', [])
                ], AmaxTreeView);
                return AmaxTreeView;
            }());
            exports_1("AmaxTreeView", AmaxTreeView);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldi9jb21vbkNvbXBvbmVudHMvYmFzaWNDb21wb25lbnRzL3RyZWV2aWV3LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1lBMENBO2dCQUNJO2dCQUFjLENBQUM7Z0JBeENuQjtvQkFBQyxnQkFBUyxDQUFDO3dCQUNQLElBQUksRUFBQyxhQUFhO3dCQUNsQixRQUFRLEVBQUMsaXdEQW1DUjtxQkFDSixDQUFDOztnQ0FBQTtnQkFHRixtQkFBQztZQUFELENBRkEsQUFFQyxJQUFBO1lBRkQsdUNBRUMsQ0FBQSIsImZpbGUiOiJkZXYvY29tb25Db21wb25lbnRzL2Jhc2ljQ29tcG9uZW50cy90cmVldmlldy5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7Q29tcG9uZW50fSBmcm9tIFwiYW5ndWxhcjIvY29yZVwiO1xuXG5cbkBDb21wb25lbnQoe1xuICAgIG5hbWU6XCJteC10cmVldmlld1wiLFxuICAgIHRlbXBsYXRlOmBcbiAgICAgICAgPGgxPkhlbGxvIFdvcmxkPC9oMT5cbiAgICAgICAgPHVsIGlkPVwibXgtdHJlZXZpZXdcIj5cbiAgICAgICAgICAgIDxsaSBkYXRhLWV4cGFuZGVkPVwidHJ1ZVwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiay1zcHJpdGUgZm9sZGVyXCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgIE15IFdlYiBTaXRlXG4gICAgICAgICAgICAgICAgPHVsPlxuICAgICAgICAgICAgICAgICAgICA8bGkgZGF0YS1leHBhbmRlZD1cInRydWVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiay1zcHJpdGUgZm9sZGVyXCI+PC9zcGFuPmltYWdlc1xuICAgICAgICAgICAgICAgICAgICAgICAgPHVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsaT48c3BhbiBjbGFzcz1cImstc3ByaXRlIGltYWdlXCI+PC9zcGFuPmxvZ28ucG5nPC9saT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGk+PHNwYW4gY2xhc3M9XCJrLXNwcml0ZSBpbWFnZVwiPjwvc3Bhbj5ib2R5LWJhY2sucG5nPC9saT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGk+PHNwYW4gY2xhc3M9XCJrLXNwcml0ZSBpbWFnZVwiPjwvc3Bhbj5teS1waG90by5qcGc8L2xpPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICAgICAgPGxpIGRhdGEtZXhwYW5kZWQ9XCJ0cnVlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImstc3ByaXRlIGZvbGRlclwiPjwvc3Bhbj5yZXNvdXJjZXNcbiAgICAgICAgICAgICAgICAgICAgICAgIDx1bD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGkgZGF0YS1leHBhbmRlZD1cInRydWVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJrLXNwcml0ZSBmb2xkZXJcIj48L3NwYW4+cGRmXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx1bD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsaT48c3BhbiBjbGFzcz1cImstc3ByaXRlIHBkZlwiPjwvc3Bhbj5icm9jaHVyZS5wZGY8L2xpPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpPjxzcGFuIGNsYXNzPVwiay1zcHJpdGUgcGRmXCI+PC9zcGFuPnByaWNlcy5wZGY8L2xpPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3VsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpPjxzcGFuIGNsYXNzPVwiay1zcHJpdGUgZm9sZGVyXCI+PC9zcGFuPnppcDwvbGk+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3VsPlxuICAgICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICAgICA8bGk+PHNwYW4gY2xhc3M9XCJrLXNwcml0ZSBodG1sXCI+PC9zcGFuPmFib3V0Lmh0bWw8L2xpPlxuICAgICAgICAgICAgICAgICAgICA8bGk+PHNwYW4gY2xhc3M9XCJrLXNwcml0ZSBodG1sXCI+PC9zcGFuPmNvbnRhY3RzLmh0bWw8L2xpPlxuICAgICAgICAgICAgICAgICAgICA8bGk+PHNwYW4gY2xhc3M9XCJrLXNwcml0ZSBodG1sXCI+PC9zcGFuPmluZGV4Lmh0bWw8L2xpPlxuICAgICAgICAgICAgICAgICAgICA8bGk+PHNwYW4gY2xhc3M9XCJrLXNwcml0ZSBodG1sXCI+PC9zcGFuPnBvcnRmb2xpby5odG1sPC9saT5cbiAgICAgICAgICAgICAgICA8L3VsPlxuICAgICAgICAgICAgPC9saT5cbiAgICAgICAgPC91bD5cbiAgICBgXG59KVxuZXhwb3J0IGNsYXNzIEFtYXhUcmVlVmlld3tcbiAgICBjb25zdHJ1Y3Rvcigpe31cbn0iXX0=
