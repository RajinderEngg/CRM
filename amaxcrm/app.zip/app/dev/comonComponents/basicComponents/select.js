System.register(['angular2/core'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1;
    var SelectInputComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            }],
        execute: function() {
            SelectInputComponent = (function () {
                function SelectInputComponent() {
                    this.onData = new core_1.EventEmitter();
                }
                SelectInputComponent.prototype.lblValue = function (item) {
                    return item[this.label];
                };
                SelectInputComponent.prototype.changeSelection = function (selectedOption) {
                    //alert(selectedOption.value);
                    // debugger;
                    localStorage.setItem('lang', selectedOption.value);
                    for (var index = 0; index < this.data.length; index++) {
                        if (this.data[index][this.label] == selectedOption.value) {
                            this.onData.emit(this.data[index]);
                            return true;
                        }
                    }
                    this.onData.emit({});
                    return false;
                };
                SelectInputComponent.prototype.ngOnInit = function () {
                    if (this.selectedval != "" && this.selectedval != undefined && this.selectedval != null)
                        this.default = this.selectedval;
                };
                __decorate([
                    core_1.Input("data"), 
                    __metadata('design:type', Array)
                ], SelectInputComponent.prototype, "data", void 0);
                __decorate([
                    core_1.Input("label"), 
                    __metadata('design:type', String)
                ], SelectInputComponent.prototype, "label", void 0);
                __decorate([
                    core_1.Input("selectedval"), 
                    __metadata('design:type', String)
                ], SelectInputComponent.prototype, "selectedval", void 0);
                __decorate([
                    core_1.Input("firstvalue"), 
                    __metadata('design:type', String)
                ], SelectInputComponent.prototype, "firstvalue", void 0);
                __decorate([
                    core_1.Input("cssclass"), 
                    __metadata('design:type', String)
                ], SelectInputComponent.prototype, "cssclass", void 0);
                __decorate([
                    core_1.Output("onData"), 
                    __metadata('design:type', Object)
                ], SelectInputComponent.prototype, "onData", void 0);
                SelectInputComponent = __decorate([
                    core_1.Component({
                        selector: 'mx-select',
                        template: "\n        <select #opt (change)=\"changeSelection(opt)\" [(ngModel)]=\"default\" class=\"{{cssclass}}\">\n            <option value=\"{{firstvalue}}\">{{firstvalue}}</option>\n            <option *ngFor=\"#item of data\" value=\"{{lblValue(item)}}\">{{lblValue(item)}}</option>\n        </select>\n    "
                    }), 
                    __metadata('design:paramtypes', [])
                ], SelectInputComponent);
                return SelectInputComponent;
            }());
            exports_1("SelectInputComponent", SelectInputComponent);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldi9jb21vbkNvbXBvbmVudHMvYmFzaWNDb21wb25lbnRzL3NlbGVjdC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztZQVdBO2dCQUFBO29CQWNzQixXQUFNLEdBQUcsSUFBSSxtQkFBWSxFQUFVLENBQUM7Z0JBc0IxRCxDQUFDO2dCQTNCRyx1Q0FBUSxHQUFSLFVBQVMsSUFBSTtvQkFDVCxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDNUIsQ0FBQztnQkFLRCw4Q0FBZSxHQUFmLFVBQWdCLGNBQWM7b0JBQzFCLDhCQUE4QjtvQkFDOUIsWUFBWTtvQkFDWixZQUFZLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUE7b0JBQ2xELEdBQUcsQ0FBQyxDQUFDLElBQUksS0FBSyxHQUFHLENBQUMsRUFBRSxLQUFLLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsS0FBSyxFQUFFLEVBQUUsQ0FBQzt3QkFDcEQsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7NEJBQ3ZELElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQzs0QkFDbkMsTUFBTSxDQUFDLElBQUksQ0FBQzt3QkFDaEIsQ0FBQztvQkFDTCxDQUFDO29CQUNELElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO29CQUNyQixNQUFNLENBQUMsS0FBSyxDQUFDO2dCQUNqQixDQUFDO2dCQUVELHVDQUFRLEdBQVI7b0JBQ0ksRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFdBQVcsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLFdBQVcsSUFBSSxJQUFJLENBQUM7d0JBQ3BGLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQztnQkFHeEMsQ0FBQztnQkFsQ0Q7b0JBQUMsWUFBSyxDQUFDLE1BQU0sQ0FBQzs7a0VBQUE7Z0JBQ2Q7b0JBQUMsWUFBSyxDQUFDLE9BQU8sQ0FBQzs7bUVBQUE7Z0JBQ2Y7b0JBQUMsWUFBSyxDQUFDLGFBQWEsQ0FBQzs7eUVBQUE7Z0JBQ3JCO29CQUFDLFlBQUssQ0FBQyxZQUFZLENBQUM7O3dFQUFBO2dCQUNwQjtvQkFBQyxZQUFLLENBQUMsVUFBVSxDQUFDOztzRUFBQTtnQkFTbEI7b0JBQUMsYUFBTSxDQUFDLFFBQVEsQ0FBQzs7b0VBQUE7Z0JBdkJyQjtvQkFBQyxnQkFBUyxDQUFDO3dCQUNQLFFBQVEsRUFBRSxXQUFXO3dCQUNyQixRQUFRLEVBQUUsZ1RBS1Q7cUJBQ0osQ0FBQzs7d0NBQUE7Z0JBcUNGLDJCQUFDO1lBQUQsQ0FwQ0EsQUFvQ0MsSUFBQTtZQXBDRCx1REFvQ0MsQ0FBQSIsImZpbGUiOiJkZXYvY29tb25Db21wb25lbnRzL2Jhc2ljQ29tcG9uZW50cy9zZWxlY3QuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge0NvbXBvbmVudCwgSW5wdXQsIE91dHB1dCwgRXZlbnRFbWl0dGVyLCBPbkluaXR9IGZyb20gJ2FuZ3VsYXIyL2NvcmUnO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ214LXNlbGVjdCcsXG4gICAgdGVtcGxhdGU6IGBcbiAgICAgICAgPHNlbGVjdCAjb3B0IChjaGFuZ2UpPVwiY2hhbmdlU2VsZWN0aW9uKG9wdClcIiBbKG5nTW9kZWwpXT1cImRlZmF1bHRcIiBjbGFzcz1cInt7Y3NzY2xhc3N9fVwiPlxuICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cInt7Zmlyc3R2YWx1ZX19XCI+e3tmaXJzdHZhbHVlfX08L29wdGlvbj5cbiAgICAgICAgICAgIDxvcHRpb24gKm5nRm9yPVwiI2l0ZW0gb2YgZGF0YVwiIHZhbHVlPVwie3tsYmxWYWx1ZShpdGVtKX19XCI+e3tsYmxWYWx1ZShpdGVtKX19PC9vcHRpb24+XG4gICAgICAgIDwvc2VsZWN0PlxuICAgIGBcbn0pXG5leHBvcnQgY2xhc3MgU2VsZWN0SW5wdXRDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xuICAgIEBJbnB1dChcImRhdGFcIikgZGF0YTogW09iamVjdF07XG4gICAgQElucHV0KFwibGFiZWxcIikgbGFiZWw6IHN0cmluZztcbiAgICBASW5wdXQoXCJzZWxlY3RlZHZhbFwiKSBzZWxlY3RlZHZhbDogc3RyaW5nO1xuICAgIEBJbnB1dChcImZpcnN0dmFsdWVcIikgZmlyc3R2YWx1ZTogc3RyaW5nO1xuICAgIEBJbnB1dChcImNzc2NsYXNzXCIpIGNzc2NsYXNzOiBzdHJpbmc7XG4gICAgLy9ASW5wdXQoXCJzZWxlY3RlZHZhbFwiKSBzZWxlY3RlZHZhbDogc3RyaW5nO1xuXG4gICAgZGVmYXVsdDogc3RyaW5nO1xuICAgIGxibFZhbHVlKGl0ZW0pOiBzdHJpbmcge1xuICAgICAgICByZXR1cm4gaXRlbVt0aGlzLmxhYmVsXTtcbiAgICB9XG5cblxuICAgIEBPdXRwdXQoXCJvbkRhdGFcIikgb25EYXRhID0gbmV3IEV2ZW50RW1pdHRlcjxPYmplY3Q+KCk7XG5cbiAgICBjaGFuZ2VTZWxlY3Rpb24oc2VsZWN0ZWRPcHRpb24pOiBib29sZWFuIHtcbiAgICAgICAgLy9hbGVydChzZWxlY3RlZE9wdGlvbi52YWx1ZSk7XG4gICAgICAgIC8vIGRlYnVnZ2VyO1xuICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnbGFuZycsIHNlbGVjdGVkT3B0aW9uLnZhbHVlKVxuICAgICAgICBmb3IgKHZhciBpbmRleCA9IDA7IGluZGV4IDwgdGhpcy5kYXRhLmxlbmd0aDsgaW5kZXgrKykge1xuICAgICAgICAgICAgaWYgKHRoaXMuZGF0YVtpbmRleF1bdGhpcy5sYWJlbF0gPT0gc2VsZWN0ZWRPcHRpb24udmFsdWUpIHtcbiAgICAgICAgICAgICAgICB0aGlzLm9uRGF0YS5lbWl0KHRoaXMuZGF0YVtpbmRleF0pO1xuICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHRoaXMub25EYXRhLmVtaXQoe30pO1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuXG4gICAgbmdPbkluaXQoKTogYW55IHtcbiAgICAgICAgaWYgKHRoaXMuc2VsZWN0ZWR2YWwgIT0gXCJcIiAmJiB0aGlzLnNlbGVjdGVkdmFsICE9IHVuZGVmaW5lZCAmJiB0aGlzLnNlbGVjdGVkdmFsICE9IG51bGwpXG4gICAgICAgICAgICB0aGlzLmRlZmF1bHQgPSB0aGlzLnNlbGVjdGVkdmFsO1xuICAgICAgIFxuXG4gICAgfVxufSJdfQ==
