System.register(['./basicComponents/select', './basicComponents/treeview', './basicComponents/DateCtl'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var select_1, treeview_1, DateCtl_1;
    return {
        setters:[
            function (select_1_1) {
                select_1 = select_1_1;
            },
            function (treeview_1_1) {
                treeview_1 = treeview_1_1;
            },
            function (DateCtl_1_1) {
                DateCtl_1 = DateCtl_1_1;
            }],
        execute: function() {
            exports_1("SelectInputComponent", select_1.SelectInputComponent);
            exports_1("AmaxTreeView", treeview_1.AmaxTreeView);
            exports_1("AmaxDate", DateCtl_1.AmaxDate);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldi9jb21vbkNvbXBvbmVudHMvYmFzaWNDb21wb25lbnRzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7WUFLSSxnRUFBb0I7WUFDcEIsa0RBQVk7WUFDWix5Q0FBUSIsImZpbGUiOiJkZXYvY29tb25Db21wb25lbnRzL2Jhc2ljQ29tcG9uZW50cy5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFNlbGVjdElucHV0Q29tcG9uZW50IH0gZnJvbSAnLi9iYXNpY0NvbXBvbmVudHMvc2VsZWN0JztcbmltcG9ydCB7IEFtYXhUcmVlVmlldyB9IGZyb20gJy4vYmFzaWNDb21wb25lbnRzL3RyZWV2aWV3J1xuaW1wb3J0IHsgQW1heERhdGUgfSBmcm9tICcuL2Jhc2ljQ29tcG9uZW50cy9EYXRlQ3RsJ1xuXG5leHBvcnQge1xuICAgIFNlbGVjdElucHV0Q29tcG9uZW50LFxuICAgIEFtYXhUcmVlVmlldyxcbiAgICBBbWF4RGF0ZVxufSJdfQ==
