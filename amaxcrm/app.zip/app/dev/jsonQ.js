System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var jsonQ;
    return {
        setters:[],
        execute: function() {
            jsonQ = (function () {
                function jsonQ(_TransationName, _SHash) {
                    this._TransationName = _TransationName;
                    this._SHash = _SHash;
                    this.jqlsArr = null;
                    this.jqlsObject = null;
                    this.jqlsObject = {
                        TransationName: _TransationName,
                        SHash: _SHash,
                        Jqls: []
                    };
                }
                jsonQ.prototype.addToList = function () {
                    if (this.jqlsArr != null) {
                        this.jqlsObject.Jqls.push(this.jqlsArr);
                        this.jqlsArr = null;
                        return true;
                    }
                    else
                        return false;
                };
                jsonQ.prototype.toJsonQObject = function () {
                    this.addToList();
                    return this.jqlsObject;
                };
                jsonQ.prototype.throwIfInvalidOperation = function (Operation) {
                    if (this.jqlsArr == null || this.jqlsArr["Type"] != Operation)
                        throw 'Invalid operation';
                };
                //For Insert Statement
                jsonQ.prototype.addNewInsert = function (TableName, PrimaryField, PKeyName) {
                    if (PKeyName === void 0) { PKeyName = ""; }
                    if (this.jqlsArr == null) {
                        this.jqlsArr = {
                            Type: 1,
                            Table: TableName,
                            PrimaryField: PrimaryField,
                            PKeyName: PKeyName,
                            Condictions: {},
                            Fields: {}
                        };
                        return true;
                    }
                    else
                        return false;
                };
                jsonQ.prototype.Insert = function (FieldName, Value) {
                    this.throwIfInvalidOperation(1);
                    this.jqlsArr["Fields"][FieldName] = {
                        Value: Value,
                        IsFkey: false
                    };
                };
                jsonQ.prototype.InsertForignKey = function (FieldName, Value) {
                    this.throwIfInvalidOperation(1);
                    this.jqlsArr["Fields"][FieldName] = {
                        Value: Value,
                        IsFkey: true
                    };
                };
                //For Update Statement
                jsonQ.prototype.addNewUpdate = function (TableName) {
                    throw 'Not Implemented';
                };
                jsonQ.prototype.Update = function (FieldName, Value) {
                    throw 'Not implemented';
                };
                //For select data fro server
                jsonQ.prototype.addNewSelect = function (TableName) {
                    if (this.jqlsArr == null) {
                        this.jqlsArr = {
                            Type: 6,
                            Table: TableName,
                            PrimaryField: "",
                            PKeyName: "",
                            Condictions: new Object(),
                            Fields: new Object()
                        };
                        return true;
                    }
                    else
                        return false;
                };
                jsonQ.prototype.select = function (FieldName, AsAlies) {
                    this.throwIfInvalidOperation(6);
                    this.jqlsArr["Fields"][FieldName] = {
                        Value: AsAlies || FieldName
                    };
                };
                jsonQ.prototype.Condiction = function (FieldName, AsAlies) {
                    this.throwIfInvalidOperation(6);
                    this.jqlsArr["Fields"][FieldName] = {
                        Value: AsAlies || FieldName
                    };
                };
                return jsonQ;
            }());
            exports_1("jsonQ", jsonQ);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldi9qc29uUS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7O1lBQUE7Z0JBSUksZUFBb0IsZUFBc0IsRUFBUyxNQUFhO29CQUE1QyxvQkFBZSxHQUFmLGVBQWUsQ0FBTztvQkFBUyxXQUFNLEdBQU4sTUFBTSxDQUFPO29CQUM1RCxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQztvQkFDcEIsSUFBSSxDQUFDLFVBQVUsR0FBQyxJQUFJLENBQUM7b0JBQ3JCLElBQUksQ0FBQyxVQUFVLEdBQUM7d0JBQ1osY0FBYyxFQUFFLGVBQWU7d0JBQy9CLEtBQUssRUFBRSxNQUFNO3dCQUNiLElBQUksRUFBRSxFQUFFO3FCQUNYLENBQUE7Z0JBQ0wsQ0FBQztnQkFFTSx5QkFBUyxHQUFoQjtvQkFDSSxFQUFFLENBQUEsQ0FBQyxJQUFJLENBQUMsT0FBTyxJQUFFLElBQUksQ0FBQyxDQUFBLENBQUM7d0JBQ25CLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7d0JBQ3hDLElBQUksQ0FBQyxPQUFPLEdBQUMsSUFBSSxDQUFDO3dCQUNsQixNQUFNLENBQUMsSUFBSSxDQUFDO29CQUNoQixDQUFDO29CQUFBLElBQUk7d0JBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztnQkFDdkIsQ0FBQztnQkFDTSw2QkFBYSxHQUFwQjtvQkFDSSxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7b0JBQ2pCLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDO2dCQUMzQixDQUFDO2dCQUNPLHVDQUF1QixHQUEvQixVQUFnQyxTQUFnQjtvQkFDNUMsRUFBRSxDQUFBLENBQUMsSUFBSSxDQUFDLE9BQU8sSUFBRSxJQUFJLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsSUFBRSxTQUFTLENBQUM7d0JBQUMsTUFBTSxtQkFBbUIsQ0FBQztnQkFDeEYsQ0FBQztnQkFHRCxzQkFBc0I7Z0JBQ2YsNEJBQVksR0FBbkIsVUFBb0IsU0FBZ0IsRUFBQyxZQUFtQixFQUFDLFFBQWtCO29CQUFsQix3QkFBa0IsR0FBbEIsYUFBa0I7b0JBQ3ZFLEVBQUUsQ0FBQSxDQUFDLElBQUksQ0FBQyxPQUFPLElBQUUsSUFBSSxDQUFDLENBQUEsQ0FBQzt3QkFDbkIsSUFBSSxDQUFDLE9BQU8sR0FBRzs0QkFDWCxJQUFJLEVBQUUsQ0FBQzs0QkFDUCxLQUFLLEVBQUUsU0FBUzs0QkFDaEIsWUFBWSxFQUFFLFlBQVk7NEJBQzFCLFFBQVEsRUFBRSxRQUFROzRCQUNsQixXQUFXLEVBQUUsRUFBRzs0QkFDaEIsTUFBTSxFQUFFLEVBQUc7eUJBQ2QsQ0FBQTt3QkFDRCxNQUFNLENBQUMsSUFBSSxDQUFDO29CQUNoQixDQUFDO29CQUFBLElBQUk7d0JBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztnQkFDdkIsQ0FBQztnQkFDTSxzQkFBTSxHQUFiLFVBQWMsU0FBZ0IsRUFBQyxLQUFZO29CQUN2QyxJQUFJLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ2hDLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQUM7d0JBQzlCLEtBQUssRUFBRSxLQUFLO3dCQUNaLE1BQU0sRUFBRSxLQUFLO3FCQUNoQixDQUFBO2dCQUNMLENBQUM7Z0JBQ00sK0JBQWUsR0FBdEIsVUFBdUIsU0FBZ0IsRUFBQyxLQUFZO29CQUNoRCxJQUFJLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ2hDLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQUM7d0JBQzlCLEtBQUssRUFBRSxLQUFLO3dCQUNaLE1BQU0sRUFBRSxJQUFJO3FCQUNmLENBQUE7Z0JBQ0wsQ0FBQztnQkFFRCxzQkFBc0I7Z0JBQ2YsNEJBQVksR0FBbkIsVUFBb0IsU0FBZ0I7b0JBQ2hDLE1BQU0saUJBQWlCLENBQUM7Z0JBQzVCLENBQUM7Z0JBQ00sc0JBQU0sR0FBYixVQUFjLFNBQWdCLEVBQUMsS0FBWTtvQkFDdkMsTUFBTSxpQkFBaUIsQ0FBQztnQkFDNUIsQ0FBQztnQkFHRCw0QkFBNEI7Z0JBQ3JCLDRCQUFZLEdBQW5CLFVBQW9CLFNBQWdCO29CQUNoQyxFQUFFLENBQUEsQ0FBQyxJQUFJLENBQUMsT0FBTyxJQUFFLElBQUksQ0FBQyxDQUFBLENBQUM7d0JBQ25CLElBQUksQ0FBQyxPQUFPLEdBQUc7NEJBQ1gsSUFBSSxFQUFFLENBQUM7NEJBQ1AsS0FBSyxFQUFFLFNBQVM7NEJBQ2hCLFlBQVksRUFBRSxFQUFFOzRCQUNoQixRQUFRLEVBQUUsRUFBRTs0QkFDWixXQUFXLEVBQUUsSUFBSSxNQUFNLEVBQUU7NEJBQ3pCLE1BQU0sRUFBRSxJQUFJLE1BQU0sRUFBRTt5QkFDdkIsQ0FBQTt3QkFDRCxNQUFNLENBQUMsSUFBSSxDQUFDO29CQUNoQixDQUFDO29CQUFBLElBQUk7d0JBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztnQkFDdkIsQ0FBQztnQkFDTSxzQkFBTSxHQUFiLFVBQWMsU0FBZ0IsRUFBQyxPQUFjO29CQUN6QyxJQUFJLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ2hDLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQUM7d0JBQzlCLEtBQUssRUFBRSxPQUFPLElBQUUsU0FBUztxQkFDNUIsQ0FBQTtnQkFDTCxDQUFDO2dCQUNNLDBCQUFVLEdBQWpCLFVBQWtCLFNBQWdCLEVBQUMsT0FBYztvQkFDN0MsSUFBSSxDQUFDLHVCQUF1QixDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUNoQyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFDO3dCQUM5QixLQUFLLEVBQUUsT0FBTyxJQUFFLFNBQVM7cUJBQzVCLENBQUE7Z0JBQ0wsQ0FBQztnQkFDTCxZQUFDO1lBQUQsQ0E5RkEsQUE4RkMsSUFBQTtZQUVPLHlCQUFLIiwiZmlsZSI6ImRldi9qc29uUS5qcyIsInNvdXJjZXNDb250ZW50IjpbImNsYXNzIGpzb25Re1xuICAgIHByaXZhdGUganFsc0FycjpPYmplY3Q7XG4gICAgcHJpdmF0ZSBqcWxzT2JqZWN0OmFueTtcblxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgX1RyYW5zYXRpb25OYW1lOnN0cmluZyxwcml2YXRlIF9TSGFzaDpzdHJpbmcpe1xuICAgICAgICB0aGlzLmpxbHNBcnIgPSBudWxsO1xuICAgICAgICB0aGlzLmpxbHNPYmplY3Q9bnVsbDtcbiAgICAgICAgdGhpcy5qcWxzT2JqZWN0PXtcbiAgICAgICAgICAgIFRyYW5zYXRpb25OYW1lOiBfVHJhbnNhdGlvbk5hbWUsXG4gICAgICAgICAgICBTSGFzaDogX1NIYXNoLFxuICAgICAgICAgICAgSnFsczogW11cbiAgICAgICAgfVxuICAgIH1cblxuICAgIHB1YmxpYyBhZGRUb0xpc3QoKXtcbiAgICAgICAgaWYodGhpcy5qcWxzQXJyIT1udWxsKXtcbiAgICAgICAgICAgIHRoaXMuanFsc09iamVjdC5KcWxzLnB1c2godGhpcy5qcWxzQXJyKTtcbiAgICAgICAgICAgIHRoaXMuanFsc0Fycj1udWxsO1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1lbHNlIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgcHVibGljIHRvSnNvblFPYmplY3QoKTphbnl7XG4gICAgICAgIHRoaXMuYWRkVG9MaXN0KCk7XG4gICAgICAgIHJldHVybiB0aGlzLmpxbHNPYmplY3Q7XG4gICAgfVxuICAgIHByaXZhdGUgdGhyb3dJZkludmFsaWRPcGVyYXRpb24oT3BlcmF0aW9uOm51bWJlcil7XG4gICAgICAgIGlmKHRoaXMuanFsc0Fycj09bnVsbCB8fCB0aGlzLmpxbHNBcnJbXCJUeXBlXCJdIT1PcGVyYXRpb24pIHRocm93ICdJbnZhbGlkIG9wZXJhdGlvbic7XG4gICAgfVxuXG5cbiAgICAvL0ZvciBJbnNlcnQgU3RhdGVtZW50XG4gICAgcHVibGljIGFkZE5ld0luc2VydChUYWJsZU5hbWU6c3RyaW5nLFByaW1hcnlGaWVsZDpzdHJpbmcsUEtleU5hbWU6c3RyaW5nPVwiXCIpOmJvb2xlYW57XG4gICAgICAgIGlmKHRoaXMuanFsc0Fycj09bnVsbCl7XG4gICAgICAgICAgICB0aGlzLmpxbHNBcnIgPSB7XG4gICAgICAgICAgICAgICAgVHlwZTogMSxcbiAgICAgICAgICAgICAgICBUYWJsZTogVGFibGVOYW1lLFxuICAgICAgICAgICAgICAgIFByaW1hcnlGaWVsZDogUHJpbWFyeUZpZWxkLFxuICAgICAgICAgICAgICAgIFBLZXlOYW1lOiBQS2V5TmFtZSxcbiAgICAgICAgICAgICAgICBDb25kaWN0aW9uczogeyB9LFxuICAgICAgICAgICAgICAgIEZpZWxkczogeyB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfWVsc2UgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBwdWJsaWMgSW5zZXJ0KEZpZWxkTmFtZTpzdHJpbmcsVmFsdWU6c3RyaW5nKXtcbiAgICAgICAgdGhpcy50aHJvd0lmSW52YWxpZE9wZXJhdGlvbigxKTtcbiAgICAgICAgdGhpcy5qcWxzQXJyW1wiRmllbGRzXCJdW0ZpZWxkTmFtZV09e1xuICAgICAgICAgICAgVmFsdWU6IFZhbHVlLFxuICAgICAgICAgICAgSXNGa2V5OiBmYWxzZVxuICAgICAgICB9XG4gICAgfVxuICAgIHB1YmxpYyBJbnNlcnRGb3JpZ25LZXkoRmllbGROYW1lOnN0cmluZyxWYWx1ZTpzdHJpbmcpe1xuICAgICAgICB0aGlzLnRocm93SWZJbnZhbGlkT3BlcmF0aW9uKDEpO1xuICAgICAgICB0aGlzLmpxbHNBcnJbXCJGaWVsZHNcIl1bRmllbGROYW1lXT17XG4gICAgICAgICAgICBWYWx1ZTogVmFsdWUsXG4gICAgICAgICAgICBJc0ZrZXk6IHRydWVcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8vRm9yIFVwZGF0ZSBTdGF0ZW1lbnRcbiAgICBwdWJsaWMgYWRkTmV3VXBkYXRlKFRhYmxlTmFtZTpzdHJpbmcpe1xuICAgICAgICB0aHJvdyAnTm90IEltcGxlbWVudGVkJztcbiAgICB9XG4gICAgcHVibGljIFVwZGF0ZShGaWVsZE5hbWU6c3RyaW5nLFZhbHVlOnN0cmluZyl7XG4gICAgICAgIHRocm93ICdOb3QgaW1wbGVtZW50ZWQnO1xuICAgIH1cblxuXG4gICAgLy9Gb3Igc2VsZWN0IGRhdGEgZnJvIHNlcnZlclxuICAgIHB1YmxpYyBhZGROZXdTZWxlY3QoVGFibGVOYW1lOnN0cmluZyl7XG4gICAgICAgIGlmKHRoaXMuanFsc0Fycj09bnVsbCl7XG4gICAgICAgICAgICB0aGlzLmpxbHNBcnIgPSB7XG4gICAgICAgICAgICAgICAgVHlwZTogNixcbiAgICAgICAgICAgICAgICBUYWJsZTogVGFibGVOYW1lLFxuICAgICAgICAgICAgICAgIFByaW1hcnlGaWVsZDogXCJcIixcbiAgICAgICAgICAgICAgICBQS2V5TmFtZTogXCJcIixcbiAgICAgICAgICAgICAgICBDb25kaWN0aW9uczogbmV3IE9iamVjdCgpLFxuICAgICAgICAgICAgICAgIEZpZWxkczogbmV3IE9iamVjdCgpXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfWVsc2UgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBwdWJsaWMgc2VsZWN0KEZpZWxkTmFtZTpzdHJpbmcsQXNBbGllczpzdHJpbmcpe1xuICAgICAgICB0aGlzLnRocm93SWZJbnZhbGlkT3BlcmF0aW9uKDYpO1xuICAgICAgICB0aGlzLmpxbHNBcnJbXCJGaWVsZHNcIl1bRmllbGROYW1lXT17XG4gICAgICAgICAgICBWYWx1ZTogQXNBbGllc3x8RmllbGROYW1lXG4gICAgICAgIH1cbiAgICB9XG4gICAgcHVibGljIENvbmRpY3Rpb24oRmllbGROYW1lOnN0cmluZyxBc0FsaWVzOnN0cmluZyl7XG4gICAgICAgIHRoaXMudGhyb3dJZkludmFsaWRPcGVyYXRpb24oNik7XG4gICAgICAgIHRoaXMuanFsc0FycltcIkZpZWxkc1wiXVtGaWVsZE5hbWVdPXtcbiAgICAgICAgICAgIFZhbHVlOiBBc0FsaWVzfHxGaWVsZE5hbWVcbiAgICAgICAgfVxuICAgIH1cbn1cblxuZXhwb3J0IHtqc29uUX0iXX0=
