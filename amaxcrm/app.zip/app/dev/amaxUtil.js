System.register(["angular2/core"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1;
    var onEvent, crmEvent, Kendo_utility, GroupFilterPipe, GroupParenFilterPipe;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            }],
        execute: function() {
            onEvent = {
                riceEvent: function (evtName, eventData) {
                    var evt = new Event(evtName);
                    evt["evtData"] = eventData;
                    document.dispatchEvent(evt);
                    console.log(evtName + " event rice");
                },
                listenEvent: function (eventName, callback) {
                    console.log(eventName + " is binded");
                    document.addEventListener(eventName, callback);
                },
                removeEvtListner: function (eventName, callback) {
                    console.log(eventName + " is unbinde");
                    document.removeEventListener(eventName, callback);
                }
            };
            crmEvent = {
                breadcrumbChange: "crm.breadcrumb.change"
            };
            Kendo_utility = {
                checkingNodeIds: function (nodes, checkedNodes) {
                    var checkinnodes = checkedNodes.split(';');
                    for (var i = 0; i < nodes.length; i++) {
                        for (var j = 0; j < checkinnodes.length; j++) {
                            if (nodes[i].id == checkinnodes[j]) {
                                nodes[i].set("checked", true);
                            }
                        }
                        if (nodes[i].hasChildren) {
                            Kendo_utility.checkingNodeIds(nodes[i].children.view(), checkedNodes);
                        }
                    }
                },
                checkedNodeIds: function (nodes, checkedNodes) {
                    for (var i = 0; i < nodes.length; i++) {
                        //console.log(nodes[i]);
                        if (nodes[i].checked) {
                            checkedNodes.push(nodes[i].id);
                        }
                        if (nodes[i].hasChildren) {
                            Kendo_utility.checkedNodeIds(nodes[i].children.view(), checkedNodes);
                        }
                    }
                },
                checkedNodetexts: function (nodes, checkedNodes) {
                    for (var i = 0; i < nodes.length; i++) {
                        console.log(nodes[i].text);
                        if (nodes[i].checked) {
                            checkedNodes.push(nodes[i].text);
                        }
                        if (nodes[i].hasChildren) {
                            Kendo_utility.checkedNodeIds(nodes[i].children.view(), checkedNodes);
                        }
                    }
                },
                getTree: function (inptData, groupId) {
                    var x = inptData.filter(function (e) {
                        return e.GroupParenCategory == groupId && e.GroupId != 0;
                    });
                    var outputData = [];
                    for (var i = 0; i < x.length; i++) {
                        outputData.push({
                            id: x[i].GroupId,
                            text: x[i].GroupName,
                            expanded: false,
                            items: Kendo_utility.getTree(inptData, x[i].GroupId)
                        });
                    }
                    return outputData;
                }
            };
            //pipes start
            GroupFilterPipe = (function () {
                function GroupFilterPipe() {
                }
                GroupFilterPipe.prototype.transform = function (value, _a) {
                    var groupId = _a[0];
                    return value.filter(function (o) {
                        return o.GroupId == groupId;
                    });
                };
                GroupFilterPipe = __decorate([
                    core_1.Pipe({
                        name: 'filterbygroup'
                    }), 
                    __metadata('design:paramtypes', [])
                ], GroupFilterPipe);
                return GroupFilterPipe;
            }());
            GroupParenFilterPipe = (function () {
                function GroupParenFilterPipe() {
                }
                GroupParenFilterPipe.prototype.transform = function (value, _a) {
                    var parentgroupid = _a[0];
                    return value.filter(function (o) {
                        return o.GroupParenCategory == parentgroupid;
                    });
                };
                GroupParenFilterPipe = __decorate([
                    core_1.Pipe({
                        name: 'filterbygroupparent'
                    }), 
                    __metadata('design:paramtypes', [])
                ], GroupParenFilterPipe);
                return GroupParenFilterPipe;
            }());
            exports_1("onEvent", onEvent);
            exports_1("crmEvent", crmEvent);
            exports_1("GroupFilterPipe", GroupFilterPipe);
            exports_1("GroupParenFilterPipe", GroupParenFilterPipe);
            exports_1("Kendo_utility", Kendo_utility);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldi9hbWF4VXRpbC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7O1FBRUksT0FBTyxFQW1CUCxRQUFRLEVBSVIsYUFBYTs7Ozs7OztZQXZCYixPQUFPLEdBQUc7Z0JBQ1YsU0FBUyxFQUFFLFVBQUMsT0FBYyxFQUFFLFNBQWE7b0JBQ3JDLElBQUksR0FBRyxHQUFHLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO29CQUM3QixHQUFHLENBQUMsU0FBUyxDQUFDLEdBQUcsU0FBUyxDQUFDO29CQUMzQixRQUFRLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUM1QixPQUFPLENBQUMsR0FBRyxDQUFDLE9BQU8sR0FBRSxhQUFhLENBQUMsQ0FBQztnQkFDeEMsQ0FBQztnQkFFRCxXQUFXLEVBQUMsVUFBQyxTQUFnQixFQUFFLFFBQVk7b0JBQ3ZDLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxHQUFDLFlBQVksQ0FBQyxDQUFDO29CQUNwQyxRQUFRLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxFQUFDLFFBQVEsQ0FBQyxDQUFDO2dCQUNsRCxDQUFDO2dCQUVELGdCQUFnQixFQUFDLFVBQUMsU0FBZ0IsRUFBRSxRQUFZO29CQUM1QyxPQUFPLENBQUMsR0FBRyxDQUFDLFNBQVMsR0FBQyxhQUFhLENBQUMsQ0FBQztvQkFDckMsUUFBUSxDQUFDLG1CQUFtQixDQUFDLFNBQVMsRUFBQyxRQUFRLENBQUMsQ0FBQztnQkFDckQsQ0FBQzthQUNKLENBQUM7WUFFRSxRQUFRLEdBQUM7Z0JBQ1QsZ0JBQWdCLEVBQUMsdUJBQXVCO2FBQzNDLENBQUE7WUFFRyxhQUFhLEdBQUc7Z0JBQ2hCLGVBQWUsRUFBRSxVQUFVLEtBQUssRUFBRSxZQUFZO29CQUUxQyxJQUFJLFlBQVksR0FBRyxZQUFZLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUMzQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQzt3QkFDcEMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxZQUFZLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUM7NEJBQzNDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLElBQUksWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDakMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7NEJBQ2xDLENBQUM7d0JBQ0wsQ0FBQzt3QkFDRCxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQzs0QkFFdkIsYUFBYSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxFQUFFLFlBQVksQ0FBQyxDQUFDO3dCQUMxRSxDQUFDO29CQUNMLENBQUM7Z0JBQ0wsQ0FBQztnQkFDRCxjQUFjLEVBQUUsVUFBVSxLQUFLLEVBQUUsWUFBWTtvQkFHekMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUM7d0JBQ3BDLHdCQUF3Qjt3QkFDeEIsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7NEJBQ25CLFlBQVksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO3dCQUNuQyxDQUFDO3dCQUVELEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDOzRCQUN2QixhQUFhLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLEVBQUUsWUFBWSxDQUFDLENBQUM7d0JBQ3pFLENBQUM7b0JBQ0wsQ0FBQztnQkFDTCxDQUFDO2dCQUNELGdCQUFnQixFQUFFLFVBQVUsS0FBSyxFQUFFLFlBQVk7b0JBRzNDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDO3dCQUNwQyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFDM0IsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7NEJBQ25CLFlBQVksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUNyQyxDQUFDO3dCQUVELEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDOzRCQUN2QixhQUFhLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLEVBQUUsWUFBWSxDQUFDLENBQUM7d0JBQ3pFLENBQUM7b0JBQ0wsQ0FBQztnQkFDTCxDQUFDO2dCQUNELE9BQU8sRUFBRSxVQUFVLFFBQVEsRUFBRSxPQUFPO29CQUNoQyxJQUFJLENBQUMsR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQzt3QkFDL0IsTUFBTSxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsSUFBSSxPQUFPLElBQUksQ0FBQyxDQUFDLE9BQU8sSUFBSSxDQUFDLENBQUM7b0JBQzdELENBQUMsQ0FBQyxDQUFDO29CQUNILElBQUksVUFBVSxHQUFHLEVBQUUsQ0FBQztvQkFDcEIsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUM7d0JBQ2hDLFVBQVUsQ0FBQyxJQUFJLENBQUM7NEJBQ1osRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPOzRCQUNoQixJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVM7NEJBQ3BCLFFBQVEsRUFBRSxLQUFLOzRCQUNmLEtBQUssRUFBRSxhQUFhLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO3lCQUN2RCxDQUFDLENBQUM7b0JBQ1AsQ0FBQztvQkFDRCxNQUFNLENBQUMsVUFBVSxDQUFDO2dCQUN0QixDQUFDO2FBQ0osQ0FBQTtZQUNELGFBQWE7WUFJYjtnQkFBQTtnQkFNQSxDQUFDO2dCQUxHLG1DQUFTLEdBQVQsVUFBVSxLQUFLLEVBQUMsRUFBUzt3QkFBUixlQUFPO29CQUNwQixNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxVQUFDLENBQUM7d0JBQ2xCLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxJQUFJLE9BQU8sQ0FBQztvQkFDaEMsQ0FBQyxDQUFDLENBQUM7Z0JBQ1AsQ0FBQztnQkFSTDtvQkFBQyxXQUFJLENBQUM7d0JBQ0YsSUFBSSxFQUFDLGVBQWU7cUJBQ3ZCLENBQUM7O21DQUFBO2dCQU9GLHNCQUFDO1lBQUQsQ0FOQSxBQU1DLElBQUE7WUFJRDtnQkFBQTtnQkFNQSxDQUFDO2dCQUxHLHdDQUFTLEdBQVQsVUFBVSxLQUFLLEVBQUMsRUFBZTt3QkFBZCxxQkFBYTtvQkFDMUIsTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsVUFBQyxDQUFDO3dCQUNsQixNQUFNLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixJQUFJLGFBQWEsQ0FBQztvQkFDakQsQ0FBQyxDQUFDLENBQUM7Z0JBQ1AsQ0FBQztnQkFSTDtvQkFBQyxXQUFJLENBQUM7d0JBQ0YsSUFBSSxFQUFDLHFCQUFxQjtxQkFDN0IsQ0FBQzs7d0NBQUE7Z0JBT0YsMkJBQUM7WUFBRCxDQU5BLEFBTUMsSUFBQTtZQUtHLDZCQUFPO1lBQUUsK0JBQVE7WUFBRSw2Q0FBZTtZQUFDLHVEQUFvQjtZQUFDLHlDQUFhIiwiZmlsZSI6ImRldi9hbWF4VXRpbC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7UGlwZX0gZnJvbSBcImFuZ3VsYXIyL2NvcmVcIjtcblxubGV0IG9uRXZlbnQgPSB7XG4gICAgcmljZUV2ZW50OiAoZXZ0TmFtZTpzdHJpbmcsIGV2ZW50RGF0YTphbnkpPT57XG4gICAgICAgIHZhciBldnQgPSBuZXcgRXZlbnQoZXZ0TmFtZSk7XG4gICAgICAgIGV2dFtcImV2dERhdGFcIl0gPSBldmVudERhdGE7XG4gICAgICAgIGRvY3VtZW50LmRpc3BhdGNoRXZlbnQoZXZ0KTtcbiAgICAgICAgY29uc29sZS5sb2coZXZ0TmFtZSsgXCIgZXZlbnQgcmljZVwiKTtcbiAgICB9LFxuXG4gICAgbGlzdGVuRXZlbnQ6KGV2ZW50TmFtZTpzdHJpbmcsIGNhbGxiYWNrOmFueSk9PntcbiAgICAgICAgY29uc29sZS5sb2coZXZlbnROYW1lK1wiIGlzIGJpbmRlZFwiKTtcbiAgICAgICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihldmVudE5hbWUsY2FsbGJhY2spO1xuICAgIH0sXG5cbiAgICByZW1vdmVFdnRMaXN0bmVyOihldmVudE5hbWU6c3RyaW5nLCBjYWxsYmFjazphbnkpPT57XG4gICAgICAgIGNvbnNvbGUubG9nKGV2ZW50TmFtZStcIiBpcyB1bmJpbmRlXCIpO1xuICAgICAgICBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKGV2ZW50TmFtZSxjYWxsYmFjayk7XG4gICAgfVxufTtcblxubGV0IGNybUV2ZW50PXtcbiAgICBicmVhZGNydW1iQ2hhbmdlOlwiY3JtLmJyZWFkY3J1bWIuY2hhbmdlXCJcbn1cblxubGV0IEtlbmRvX3V0aWxpdHkgPSB7XG4gICAgY2hlY2tpbmdOb2RlSWRzOiBmdW5jdGlvbiAobm9kZXMsIGNoZWNrZWROb2Rlcykge1xuICAgICAgICBcbiAgICAgICAgdmFyIGNoZWNraW5ub2RlcyA9IGNoZWNrZWROb2Rlcy5zcGxpdCgnOycpO1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IG5vZGVzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBmb3IgKHZhciBqID0gMDsgaiA8IGNoZWNraW5ub2Rlcy5sZW5ndGg7IGorKykge1xuICAgICAgICAgICAgICAgIGlmIChub2Rlc1tpXS5pZCA9PSBjaGVja2lubm9kZXNbal0pIHtcbiAgICAgICAgICAgICAgICAgICAgbm9kZXNbaV0uc2V0KFwiY2hlY2tlZFwiLCB0cnVlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAobm9kZXNbaV0uaGFzQ2hpbGRyZW4pIHtcblxuICAgICAgICAgICAgICAgIEtlbmRvX3V0aWxpdHkuY2hlY2tpbmdOb2RlSWRzKG5vZGVzW2ldLmNoaWxkcmVuLnZpZXcoKSwgY2hlY2tlZE5vZGVzKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH0sXG4gICAgY2hlY2tlZE5vZGVJZHM6IGZ1bmN0aW9uIChub2RlcywgY2hlY2tlZE5vZGVzKSB7XG4gICAgICAgIFxuICAgICAgICBcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBub2Rlcy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgLy9jb25zb2xlLmxvZyhub2Rlc1tpXSk7XG4gICAgICAgICAgICBpZiAobm9kZXNbaV0uY2hlY2tlZCkge1xuICAgICAgICAgICAgICAgIGNoZWNrZWROb2Rlcy5wdXNoKG5vZGVzW2ldLmlkKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKG5vZGVzW2ldLmhhc0NoaWxkcmVuKSB7XG4gICAgICAgICAgICAgICAgS2VuZG9fdXRpbGl0eS5jaGVja2VkTm9kZUlkcyhub2Rlc1tpXS5jaGlsZHJlbi52aWV3KCksIGNoZWNrZWROb2Rlcyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9LFxuICAgIGNoZWNrZWROb2RldGV4dHM6IGZ1bmN0aW9uIChub2RlcywgY2hlY2tlZE5vZGVzKSB7XG5cblxuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IG5vZGVzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhub2Rlc1tpXS50ZXh0KTtcbiAgICAgICAgICAgIGlmIChub2Rlc1tpXS5jaGVja2VkKSB7XG4gICAgICAgICAgICAgICAgY2hlY2tlZE5vZGVzLnB1c2gobm9kZXNbaV0udGV4dCk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmIChub2Rlc1tpXS5oYXNDaGlsZHJlbikge1xuICAgICAgICAgICAgICAgIEtlbmRvX3V0aWxpdHkuY2hlY2tlZE5vZGVJZHMobm9kZXNbaV0uY2hpbGRyZW4udmlldygpLCBjaGVja2VkTm9kZXMpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSxcbiAgICBnZXRUcmVlOiBmdW5jdGlvbiAoaW5wdERhdGEsIGdyb3VwSWQpIHtcclxuICAgICAgICB2YXIgeCA9IGlucHREYXRhLmZpbHRlcihmdW5jdGlvbiAoZSkge1xyXG4gICAgICAgICAgICByZXR1cm4gZS5Hcm91cFBhcmVuQ2F0ZWdvcnkgPT0gZ3JvdXBJZCAmJiBlLkdyb3VwSWQgIT0gMDtcclxuICAgICAgICB9KTtcclxuICAgICAgICB2YXIgb3V0cHV0RGF0YSA9IFtdO1xyXG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgeC5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBvdXRwdXREYXRhLnB1c2goe1xyXG4gICAgICAgICAgICAgICAgaWQ6IHhbaV0uR3JvdXBJZCxcclxuICAgICAgICAgICAgICAgIHRleHQ6IHhbaV0uR3JvdXBOYW1lLFxyXG4gICAgICAgICAgICAgICAgZXhwYW5kZWQ6IGZhbHNlLFxyXG4gICAgICAgICAgICAgICAgaXRlbXM6IEtlbmRvX3V0aWxpdHkuZ2V0VHJlZShpbnB0RGF0YSwgeFtpXS5Hcm91cElkKVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIG91dHB1dERhdGE7XHJcbiAgICB9XG59XG4vL3BpcGVzIHN0YXJ0XG5AUGlwZSh7XG4gICAgbmFtZTonZmlsdGVyYnlncm91cCdcbn0pXG5jbGFzcyBHcm91cEZpbHRlclBpcGV7XG4gICAgdHJhbnNmb3JtKHZhbHVlLFtncm91cElkXSl7XG4gICAgICAgIHJldHVybiB2YWx1ZS5maWx0ZXIoKG8pPT57XG4gICAgICAgICAgICByZXR1cm4gby5Hcm91cElkID09IGdyb3VwSWQ7XG4gICAgICAgIH0pO1xuICAgIH1cbn1cbkBQaXBlKHtcbiAgICBuYW1lOidmaWx0ZXJieWdyb3VwcGFyZW50J1xufSlcbmNsYXNzIEdyb3VwUGFyZW5GaWx0ZXJQaXBle1xuICAgIHRyYW5zZm9ybSh2YWx1ZSxbcGFyZW50Z3JvdXBpZF0pe1xuICAgICAgICByZXR1cm4gdmFsdWUuZmlsdGVyKChvKT0+e1xuICAgICAgICAgICAgcmV0dXJuIG8uR3JvdXBQYXJlbkNhdGVnb3J5ID09IHBhcmVudGdyb3VwaWQ7XG4gICAgICAgIH0pO1xuICAgIH1cbn1cbi8vcGlwZXMgZW5kXG5cblxuZXhwb3J0IHtcbiAgICBvbkV2ZW50LCBjcm1FdmVudCwgR3JvdXBGaWx0ZXJQaXBlLEdyb3VwUGFyZW5GaWx0ZXJQaXBlLEtlbmRvX3V0aWxpdHlcbn0iXX0=
