System.register(['angular2/core', "angular2/router", "../services/ResourceService"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1, ResourceService_1;
    var AmaxCrmNavbarComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (ResourceService_1_1) {
                ResourceService_1 = ResourceService_1_1;
            }],
        execute: function() {
            AmaxCrmNavbarComponent = (function () {
                function AmaxCrmNavbarComponent(_resourceService) {
                    this._resourceService = _resourceService;
                    this.LogoCSS = "";
                    this.toolsCSS = "";
                    this.LangDDCSS = "";
                    this.Lang = "";
                    this.languageArray = [];
                    this.LanguageId = "";
                    this.IsRTL = "";
                    this._userModel = {};
                    var lang = _resourceService.getCookie("lang");
                    if (lang.length > 0)
                        lang = lang.substring(1, lang.length);
                    if (lang == "")
                        lang = "en";
                    this.LanguageId = lang;
                    // alert(this.LanguageId);
                }
                AmaxCrmNavbarComponent.prototype.ChangeLanguage = function () {
                    this.LanguageId = jQuery("#LangDD").val();
                    ////localStorage.setItem("lang", this.LanguageId);
                    ////var lang = localStorage.getItem("lang");
                    //////this._resourceService.deleteCookie("lang");
                    //////localStorage.clear();
                    //////sessionStorage.clear();
                    ////this._resourceService.setCookie("lang", this.LanguageId,10 );
                    //////localStorage.clear();
                    ////window.location.href = "/";
                    //console.log("Changing Language...");
                    //this.logout();
                    //if (this.LanguageId) {
                    //    this._resourceService.GetSelecetdLanguage(this.LanguageId).subscribe(
                    //        data => {
                    //            //localStorage.setItem("langresource", JSON.stringify(data));
                    //            localStorage.setItem("lang", this.LanguageId);
                    //            //this._resourceService.setCookie("lang", this.LanguageId, 10);
                    //        },
                    //        error => console.log("Unable to load Language Data"),
                    //        () => {
                    //            console.log("Language resource loaded");
                    //        }
                    //    );
                    //}
                    localStorage.setItem("lang", this.LanguageId);
                    this._resourceService.setCookie("lang", this.LanguageId, 10);
                    debugger;
                    var UserDet = JSON.parse(sessionStorage.getItem('userInformation'));
                    //this._userModel = {
                    //    userName: UserName,
                    //    password: "",
                    //    orgName: orgName,
                    //    lang: lang,
                    //    rememberMe: rememberMe
                    //}
                    //if (temp != "" && temp != undefined) {
                    //    var dta = $.parseJSON(temp).Data;
                    //    this.LoginData = dta;
                    //    var userdet = JSON.parse(atob(dta["token"].split('.')[1]));
                    //    userdet.Language = lang;
                    //    var stinguserdet = JSON.stringify(userdet);
                    //    dta["token"].split('.')[1] = JSON.stringify(userdet);
                    //    var uts = dta["token"].split('.')[1];
                    //    alert(userdet.Language);
                    //    sessionStorage.setItem('XToken', dta["token"])
                    //    sessionStorage.setItem('sessionInformation', atob(dta["token"].split('.')[0]));
                    //    sessionStorage.setItem('userInformation', atob(dta["token"].split('.')[1]));
                    //    var t = sessionStorage.getItem('sessionInformation');
                    //    var ut = sessionStorage.getItem('userInformation');
                    //    //Featching Userinformation
                    //    this.LoginData = JSON.parse(atob(dta["token"].split('.')[1]));
                    //    //var langres = this.getCookie("langresource");
                    //    this.getlangres(this.LoginData.Language);
                    //    localStorage.setItem("lang", this.LoginData.Language);
                    //    localStorage.setItem("employeeid", this.LoginData.employeeid);
                    //    this.IsLogedIn = true;
                    //}
                    window.location.href = "/";
                };
                AmaxCrmNavbarComponent.prototype.logout = function () {
                    var empid = localStorage.getItem("employeeid");
                    localStorage.clear();
                    sessionStorage.clear();
                    //debugger;
                    //var data = this._resourceService.getCookie("
                    //    this._resourceService.setCookie("UserDet", data, 10);
                    //var data = this._resourceService.getCookie("RememberKey");  
                    //this._resourceService.setCookie("UserDet", data, 10); 
                    this._resourceService.deleteCookie("RememberKey");
                    this._resourceService.deleteCookie(empid + "cust");
                    this._resourceService.deleteCookie(empid + "emp");
                    this._resourceService.deleteCookie(empid + "src");
                    this._resourceService.deleteCookie(empid + "ccode");
                    this._resourceService.deleteCookie(empid + "SMSDet");
                    this._resourceService.deleteCookie(empid + "SMSMessage");
                    window.location.href = "/";
                };
                AmaxCrmNavbarComponent.prototype.ngOnInit = function () {
                    this.languageArray = this._resourceService.GetAvailableLanguages();
                    var lng = this._resourceService.getCookie("lang");
                    if (lng.length > 0)
                        lng = lng.substring(1, lng.length);
                    if (lng == "")
                        lng = "en";
                    this.Lang = lng;
                    //alert(this.Lang+" lang");
                    if (this.Lang == "he") {
                        this.IsRTL = "rtl";
                    }
                    else {
                        this.IsRTL = "ltr";
                    }
                };
                AmaxCrmNavbarComponent = __decorate([
                    core_1.Component({
                        selector: 'mx-navbar',
                        templateUrl: './app/amaxComponents/templates/amaxCrmNavbar.html',
                        directives: [router_1.ROUTER_DIRECTIVES]
                    }), 
                    __metadata('design:paramtypes', [ResourceService_1.ResourceService])
                ], AmaxCrmNavbarComponent);
                return AmaxCrmNavbarComponent;
            }());
            exports_1("AmaxCrmNavbarComponent", AmaxCrmNavbarComponent);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldi9hbWF4Q29tcG9uZW50cy9hbWF4Q3JtTmF2YmFyQ29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1lBVUE7Z0JBU0ksZ0NBQW9CLGdCQUFpQztvQkFBakMscUJBQWdCLEdBQWhCLGdCQUFnQixDQUFpQjtvQkFSckQsWUFBTyxHQUFXLEVBQUUsQ0FBQztvQkFDckIsYUFBUSxHQUFXLEVBQUUsQ0FBQztvQkFDdEIsY0FBUyxHQUFXLEVBQUUsQ0FBQztvQkFDdkIsU0FBSSxHQUFXLEVBQUUsQ0FBQztvQkFDbEIsa0JBQWEsR0FBRyxFQUFFLENBQUM7b0JBQ25CLGVBQVUsR0FBVyxFQUFFLENBQUM7b0JBQ3hCLFVBQUssR0FBVyxFQUFFLENBQUM7b0JBQ25CLGVBQVUsR0FBRyxFQUFFLENBQUM7b0JBRVosSUFBSSxJQUFJLEdBQUcsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUM5QyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQzt3QkFDaEIsSUFBSSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDMUMsRUFBRSxDQUFDLENBQUMsSUFBSSxJQUFJLEVBQUUsQ0FBQzt3QkFDWCxJQUFJLEdBQUcsSUFBSSxDQUFDO29CQUNoQixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztvQkFDeEIsMEJBQTBCO2dCQUM3QixDQUFDO2dCQUNELCtDQUFjLEdBQWQ7b0JBQ0ksSUFBSSxDQUFDLFVBQVUsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUM7b0JBQzFDLGtEQUFrRDtvQkFDbEQsNENBQTRDO29CQUM1QyxpREFBaUQ7b0JBRWpELDJCQUEyQjtvQkFDM0IsNkJBQTZCO29CQUM3QixpRUFBaUU7b0JBQ2pFLDJCQUEyQjtvQkFHM0IsK0JBQStCO29CQUMvQixzQ0FBc0M7b0JBRXRDLGdCQUFnQjtvQkFDaEIsd0JBQXdCO29CQUN4QiwyRUFBMkU7b0JBQzNFLG1CQUFtQjtvQkFDbkIsMkVBQTJFO29CQUUzRSw0REFBNEQ7b0JBQzVELDZFQUE2RTtvQkFHN0UsWUFBWTtvQkFDWiwrREFBK0Q7b0JBQy9ELGlCQUFpQjtvQkFDakIsc0RBQXNEO29CQUN0RCxXQUFXO29CQUNYLFFBQVE7b0JBRVIsR0FBRztvQkFDSCxZQUFZLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7b0JBQzlDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxVQUFVLEVBQUUsRUFBRSxDQUFDLENBQUM7b0JBRTdELFFBQVEsQ0FBQztvQkFDVCxJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDO29CQUNwRSxxQkFBcUI7b0JBQ3JCLHlCQUF5QjtvQkFDekIsbUJBQW1CO29CQUNuQix1QkFBdUI7b0JBQ3ZCLGlCQUFpQjtvQkFDakIsNEJBQTRCO29CQUM1QixHQUFHO29CQUNILHdDQUF3QztvQkFDeEMsdUNBQXVDO29CQUN2QywyQkFBMkI7b0JBQzNCLGlFQUFpRTtvQkFDakUsOEJBQThCO29CQUM5QixpREFBaUQ7b0JBQ2pELDJEQUEyRDtvQkFDM0QsMkNBQTJDO29CQUMzQyw4QkFBOEI7b0JBQzlCLG9EQUFvRDtvQkFDcEQscUZBQXFGO29CQUNyRixrRkFBa0Y7b0JBQ2xGLDJEQUEyRDtvQkFDM0QseURBQXlEO29CQUN6RCxpQ0FBaUM7b0JBQ2pDLG9FQUFvRTtvQkFDcEUscURBQXFEO29CQUNyRCwrQ0FBK0M7b0JBQy9DLDREQUE0RDtvQkFDNUQsb0VBQW9FO29CQUNwRSw0QkFBNEI7b0JBQzVCLEdBQUc7b0JBQ0gsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDO2dCQUUvQixDQUFDO2dCQUNELHVDQUFNLEdBQU47b0JBQ0ksSUFBSSxLQUFLLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQztvQkFDL0MsWUFBWSxDQUFDLEtBQUssRUFBRSxDQUFDO29CQUNyQixjQUFjLENBQUMsS0FBSyxFQUFFLENBQUM7b0JBQ3ZCLFdBQVc7b0JBQ1gsOENBQThDO29CQUM5QywyREFBMkQ7b0JBRTNELDhEQUE4RDtvQkFDOUQsd0RBQXdEO29CQUN4RCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxDQUFDLGFBQWEsQ0FBQyxDQUFDO29CQUNsRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxDQUFDLEtBQUssR0FBRyxNQUFNLENBQUMsQ0FBQztvQkFDbkQsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDLENBQUM7b0JBQ2xELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQyxDQUFDO29CQUNsRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxDQUFDLEtBQUssR0FBRyxPQUFPLENBQUMsQ0FBQztvQkFDcEQsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQyxLQUFLLEdBQUcsUUFBUSxDQUFDLENBQUM7b0JBQ3JELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLENBQUMsS0FBSyxHQUFFLFlBQVksQ0FBQyxDQUFDO29CQUN4RCxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksR0FBQyxHQUFHLENBQUM7Z0JBQzdCLENBQUM7Z0JBR0QseUNBQVEsR0FBUjtvQkFDSSxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO29CQUNuRSxJQUFJLEdBQUcsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUNsRCxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQzt3QkFDZixHQUFHLEdBQUcsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUN2QyxFQUFFLENBQUMsQ0FBQyxHQUFHLElBQUksRUFBRSxDQUFDO3dCQUNWLEdBQUcsR0FBRyxJQUFJLENBQUM7b0JBQ2YsSUFBSSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUM7b0JBQ2hCLDJCQUEyQjtvQkFDM0IsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO3dCQUNwQixJQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztvQkFDdkIsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixJQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztvQkFDdkIsQ0FBQztnQkFDTCxDQUFDO2dCQWpJTDtvQkFBQyxnQkFBUyxDQUFDO3dCQUNQLFFBQVEsRUFBRSxXQUFXO3dCQUNyQixXQUFXLEVBQUMsbURBQW1EO3dCQUMvRCxVQUFVLEVBQUMsQ0FBQywwQkFBaUIsQ0FBQztxQkFDakMsQ0FBQzs7MENBQUE7Z0JBOEhGLDZCQUFDO1lBQUQsQ0E3SEEsQUE2SEMsSUFBQTtZQTdIRCwyREE2SEMsQ0FBQSIsImZpbGUiOiJkZXYvYW1heENvbXBvbmVudHMvYW1heENybU5hdmJhckNvbXBvbmVudC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7Q29tcG9uZW50LCBPbkluaXR9IGZyb20gJ2FuZ3VsYXIyL2NvcmUnO1xuaW1wb3J0IHtST1VURVJfRElSRUNUSVZFU30gZnJvbSBcImFuZ3VsYXIyL3JvdXRlclwiO1xuaW1wb3J0IHtSZXNvdXJjZVNlcnZpY2V9IGZyb20gXCIuLi9zZXJ2aWNlcy9SZXNvdXJjZVNlcnZpY2VcIjtcblxuZGVjbGFyZSB2YXIgalF1ZXJ5O1xuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdteC1uYXZiYXInLFxuICAgIHRlbXBsYXRlVXJsOicuL2FwcC9hbWF4Q29tcG9uZW50cy90ZW1wbGF0ZXMvYW1heENybU5hdmJhci5odG1sJyxcbiAgICBkaXJlY3RpdmVzOltST1VURVJfRElSRUNUSVZFU11cbn0pXG5leHBvcnQgY2xhc3MgQW1heENybU5hdmJhckNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdHtcbiAgICBMb2dvQ1NTOiBzdHJpbmcgPSBcIlwiO1xuICAgIHRvb2xzQ1NTOiBzdHJpbmcgPSBcIlwiO1xuICAgIExhbmdERENTUzogc3RyaW5nID0gXCJcIjtcbiAgICBMYW5nOiBzdHJpbmcgPSBcIlwiO1xuICAgIGxhbmd1YWdlQXJyYXkgPSBbXTtcbiAgICBMYW5ndWFnZUlkOiBzdHJpbmcgPSBcIlwiO1xuICAgIElzUlRMOiBzdHJpbmcgPSBcIlwiO1xuICAgIF91c2VyTW9kZWwgPSB7fTtcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIF9yZXNvdXJjZVNlcnZpY2U6IFJlc291cmNlU2VydmljZSkge1xuICAgICAgICB2YXIgbGFuZyA9IF9yZXNvdXJjZVNlcnZpY2UuZ2V0Q29va2llKFwibGFuZ1wiKTtcbiAgICAgICAgaWYgKGxhbmcubGVuZ3RoID4gMClcbiAgICAgICAgICAgIGxhbmcgPSBsYW5nLnN1YnN0cmluZygxLCBsYW5nLmxlbmd0aCk7XG4gICAgICAgIGlmIChsYW5nID09IFwiXCIpXG4gICAgICAgICAgICBsYW5nID0gXCJlblwiO1xuICAgICAgICB0aGlzLkxhbmd1YWdlSWQgPSBsYW5nO1xuICAgICAgIC8vIGFsZXJ0KHRoaXMuTGFuZ3VhZ2VJZCk7XG4gICAgfVxuICAgIENoYW5nZUxhbmd1YWdlKCkge1xuICAgICAgICB0aGlzLkxhbmd1YWdlSWQgPSBqUXVlcnkoXCIjTGFuZ0REXCIpLnZhbCgpO1xuICAgICAgICAvLy8vbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJsYW5nXCIsIHRoaXMuTGFuZ3VhZ2VJZCk7XG4gICAgICAgIC8vLy92YXIgbGFuZyA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwibGFuZ1wiKTtcbiAgICAgICAgLy8vLy8vdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmRlbGV0ZUNvb2tpZShcImxhbmdcIik7XG5cbiAgICAgICAgLy8vLy8vbG9jYWxTdG9yYWdlLmNsZWFyKCk7XG4gICAgICAgIC8vLy8vL3Nlc3Npb25TdG9yYWdlLmNsZWFyKCk7XG4gICAgICAgIC8vLy90aGlzLl9yZXNvdXJjZVNlcnZpY2Uuc2V0Q29va2llKFwibGFuZ1wiLCB0aGlzLkxhbmd1YWdlSWQsMTAgKTtcbiAgICAgICAgLy8vLy8vbG9jYWxTdG9yYWdlLmNsZWFyKCk7XG4gICAgICAgIFxuICAgICAgICBcbiAgICAgICAgLy8vL3dpbmRvdy5sb2NhdGlvbi5ocmVmID0gXCIvXCI7XG4gICAgICAgIC8vY29uc29sZS5sb2coXCJDaGFuZ2luZyBMYW5ndWFnZS4uLlwiKTtcclxuICAgICAgICBcbiAgICAgICAgLy90aGlzLmxvZ291dCgpO1xuICAgICAgICAvL2lmICh0aGlzLkxhbmd1YWdlSWQpIHtcclxuICAgICAgICAvLyAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuR2V0U2VsZWNldGRMYW5ndWFnZSh0aGlzLkxhbmd1YWdlSWQpLnN1YnNjcmliZShcclxuICAgICAgICAvLyAgICAgICAgZGF0YSA9PiB7XHJcbiAgICAgICAgLy8gICAgICAgICAgICAvL2xvY2FsU3RvcmFnZS5zZXRJdGVtKFwibGFuZ3Jlc291cmNlXCIsIEpTT04uc3RyaW5naWZ5KGRhdGEpKTtcclxuXHJcbiAgICAgICAgLy8gICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImxhbmdcIiwgdGhpcy5MYW5ndWFnZUlkKTtcclxuICAgICAgICAvLyAgICAgICAgICAgIC8vdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLnNldENvb2tpZShcImxhbmdcIiwgdGhpcy5MYW5ndWFnZUlkLCAxMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcblxyXG4gICAgICAgIC8vICAgICAgICB9LFxyXG4gICAgICAgIC8vICAgICAgICBlcnJvciA9PiBjb25zb2xlLmxvZyhcIlVuYWJsZSB0byBsb2FkIExhbmd1YWdlIERhdGFcIiksXHJcbiAgICAgICAgLy8gICAgICAgICgpID0+IHtcclxuICAgICAgICAvLyAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiTGFuZ3VhZ2UgcmVzb3VyY2UgbG9hZGVkXCIpO1xyXG4gICAgICAgIC8vICAgICAgICB9XHJcbiAgICAgICAgLy8gICAgKTtcclxuXHJcbiAgICAgICAgLy99XG4gICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwibGFuZ1wiLCB0aGlzLkxhbmd1YWdlSWQpO1xuICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2Uuc2V0Q29va2llKFwibGFuZ1wiLCB0aGlzLkxhbmd1YWdlSWQsIDEwKTtcblxuICAgICAgICBkZWJ1Z2dlcjtcbiAgICAgICAgdmFyIFVzZXJEZXQgPSBKU09OLnBhcnNlKHNlc3Npb25TdG9yYWdlLmdldEl0ZW0oJ3VzZXJJbmZvcm1hdGlvbicpKTtcclxuICAgICAgICAvL3RoaXMuX3VzZXJNb2RlbCA9IHtcclxuICAgICAgICAvLyAgICB1c2VyTmFtZTogVXNlck5hbWUsXHJcbiAgICAgICAgLy8gICAgcGFzc3dvcmQ6IFwiXCIsXHJcbiAgICAgICAgLy8gICAgb3JnTmFtZTogb3JnTmFtZSxcclxuICAgICAgICAvLyAgICBsYW5nOiBsYW5nLFxyXG4gICAgICAgIC8vICAgIHJlbWVtYmVyTWU6IHJlbWVtYmVyTWVcclxuICAgICAgICAvL31cclxuICAgICAgICAvL2lmICh0ZW1wICE9IFwiXCIgJiYgdGVtcCAhPSB1bmRlZmluZWQpIHtcclxuICAgICAgICAvLyAgICB2YXIgZHRhID0gJC5wYXJzZUpTT04odGVtcCkuRGF0YTtcclxuICAgICAgICAvLyAgICB0aGlzLkxvZ2luRGF0YSA9IGR0YTtcclxuICAgICAgICAvLyAgICB2YXIgdXNlcmRldCA9IEpTT04ucGFyc2UoYXRvYihkdGFbXCJ0b2tlblwiXS5zcGxpdCgnLicpWzFdKSk7XHJcbiAgICAgICAgLy8gICAgdXNlcmRldC5MYW5ndWFnZSA9IGxhbmc7XHJcbiAgICAgICAgLy8gICAgdmFyIHN0aW5ndXNlcmRldCA9IEpTT04uc3RyaW5naWZ5KHVzZXJkZXQpO1xyXG4gICAgICAgIC8vICAgIGR0YVtcInRva2VuXCJdLnNwbGl0KCcuJylbMV0gPSBKU09OLnN0cmluZ2lmeSh1c2VyZGV0KTtcclxuICAgICAgICAvLyAgICB2YXIgdXRzID0gZHRhW1widG9rZW5cIl0uc3BsaXQoJy4nKVsxXTtcclxuICAgICAgICAvLyAgICBhbGVydCh1c2VyZGV0Lkxhbmd1YWdlKTtcclxuICAgICAgICAvLyAgICBzZXNzaW9uU3RvcmFnZS5zZXRJdGVtKCdYVG9rZW4nLCBkdGFbXCJ0b2tlblwiXSlcclxuICAgICAgICAvLyAgICBzZXNzaW9uU3RvcmFnZS5zZXRJdGVtKCdzZXNzaW9uSW5mb3JtYXRpb24nLCBhdG9iKGR0YVtcInRva2VuXCJdLnNwbGl0KCcuJylbMF0pKTtcclxuICAgICAgICAvLyAgICBzZXNzaW9uU3RvcmFnZS5zZXRJdGVtKCd1c2VySW5mb3JtYXRpb24nLCBhdG9iKGR0YVtcInRva2VuXCJdLnNwbGl0KCcuJylbMV0pKTtcclxuICAgICAgICAvLyAgICB2YXIgdCA9IHNlc3Npb25TdG9yYWdlLmdldEl0ZW0oJ3Nlc3Npb25JbmZvcm1hdGlvbicpO1xyXG4gICAgICAgIC8vICAgIHZhciB1dCA9IHNlc3Npb25TdG9yYWdlLmdldEl0ZW0oJ3VzZXJJbmZvcm1hdGlvbicpO1xyXG4gICAgICAgIC8vICAgIC8vRmVhdGNoaW5nIFVzZXJpbmZvcm1hdGlvblxyXG4gICAgICAgIC8vICAgIHRoaXMuTG9naW5EYXRhID0gSlNPTi5wYXJzZShhdG9iKGR0YVtcInRva2VuXCJdLnNwbGl0KCcuJylbMV0pKTtcclxuICAgICAgICAvLyAgICAvL3ZhciBsYW5ncmVzID0gdGhpcy5nZXRDb29raWUoXCJsYW5ncmVzb3VyY2VcIik7XHJcbiAgICAgICAgLy8gICAgdGhpcy5nZXRsYW5ncmVzKHRoaXMuTG9naW5EYXRhLkxhbmd1YWdlKTtcclxuICAgICAgICAvLyAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImxhbmdcIiwgdGhpcy5Mb2dpbkRhdGEuTGFuZ3VhZ2UpO1xyXG4gICAgICAgIC8vICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwiZW1wbG95ZWVpZFwiLCB0aGlzLkxvZ2luRGF0YS5lbXBsb3llZWlkKTtcclxuICAgICAgICAvLyAgICB0aGlzLklzTG9nZWRJbiA9IHRydWU7XHJcbiAgICAgICAgLy99XG4gICAgICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmID0gXCIvXCI7XG4gICAgICAgIFxuICAgIH1cbiAgICBsb2dvdXQoKSB7XG4gICAgICAgIHZhciBlbXBpZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiZW1wbG95ZWVpZFwiKTtcbiAgICAgICAgbG9jYWxTdG9yYWdlLmNsZWFyKCk7XG4gICAgICAgIHNlc3Npb25TdG9yYWdlLmNsZWFyKCk7XG4gICAgICAgIC8vZGVidWdnZXI7XG4gICAgICAgIC8vdmFyIGRhdGEgPSB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZ2V0Q29va2llKFwiXG4gICAgICAgIC8vICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5zZXRDb29raWUoXCJVc2VyRGV0XCIsIGRhdGEsIDEwKTtcblxuICAgICAgICAvL3ZhciBkYXRhID0gdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmdldENvb2tpZShcIlJlbWVtYmVyS2V5XCIpOyAgXG4gICAgICAgIC8vdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLnNldENvb2tpZShcIlVzZXJEZXRcIiwgZGF0YSwgMTApOyBcbiAgICAgICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmRlbGV0ZUNvb2tpZShcIlJlbWVtYmVyS2V5XCIpOyAgIFxuICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZGVsZXRlQ29va2llKGVtcGlkICsgXCJjdXN0XCIpOyAgXG4gICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5kZWxldGVDb29raWUoZW1waWQgKyBcImVtcFwiKTsgIFxuICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZGVsZXRlQ29va2llKGVtcGlkICsgXCJzcmNcIik7ICBcbiAgICAgICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmRlbGV0ZUNvb2tpZShlbXBpZCArIFwiY2NvZGVcIik7ICBcbiAgICAgICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmRlbGV0ZUNvb2tpZShlbXBpZCArIFwiU01TRGV0XCIpO1xuICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZGVsZXRlQ29va2llKGVtcGlkICtcIlNNU01lc3NhZ2VcIik7XG4gICAgICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmPVwiL1wiO1xuICAgIH1cblxuXG4gICAgbmdPbkluaXQoKSB7XG4gICAgICAgIHRoaXMubGFuZ3VhZ2VBcnJheSA9IHRoaXMuX3Jlc291cmNlU2VydmljZS5HZXRBdmFpbGFibGVMYW5ndWFnZXMoKTtcbiAgICAgICAgdmFyIGxuZyA9IHRoaXMuX3Jlc291cmNlU2VydmljZS5nZXRDb29raWUoXCJsYW5nXCIpO1xuICAgICAgICBpZiAobG5nLmxlbmd0aCA+IDApXG4gICAgICAgICAgICBsbmcgPSBsbmcuc3Vic3RyaW5nKDEsIGxuZy5sZW5ndGgpO1xuICAgICAgICBpZiAobG5nID09IFwiXCIpXG4gICAgICAgICAgICBsbmcgPSBcImVuXCI7XG4gICAgICAgIHRoaXMuTGFuZyA9IGxuZztcclxuICAgICAgICAvL2FsZXJ0KHRoaXMuTGFuZytcIiBsYW5nXCIpO1xyXG4gICAgICAgIGlmICh0aGlzLkxhbmcgPT0gXCJoZVwiKSB7XHJcbiAgICAgICAgICAgIHRoaXMuSXNSVEwgPSBcInJ0bFwiO1xyXG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB0aGlzLklzUlRMID0gXCJsdHJcIjtcbiAgICAgICAgfVxuICAgIH1cbn0iXX0=
