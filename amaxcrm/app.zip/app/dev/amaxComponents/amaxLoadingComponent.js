System.register(['angular2/core'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1;
    var AmaxLoadingComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            }],
        execute: function() {
            AmaxLoadingComponent = (function () {
                function AmaxLoadingComponent() {
                }
                AmaxLoadingComponent = __decorate([
                    core_1.Component({
                        selector: "mx-loading",
                        template: "\n        <div class=\"bubblingG\">\n        \n    </div>"
                    }), 
                    __metadata('design:paramtypes', [])
                ], AmaxLoadingComponent);
                return AmaxLoadingComponent;
            }());
            exports_1("AmaxLoadingComponent", AmaxLoadingComponent);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldi9hbWF4Q29tcG9uZW50cy9hbWF4TG9hZGluZ0NvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztZQVNBO2dCQUFBO2dCQUNBLENBQUM7Z0JBUkQ7b0JBQUMsZ0JBQVMsQ0FBQzt3QkFDUCxRQUFRLEVBQUMsWUFBWTt3QkFDckIsUUFBUSxFQUFDLDJEQUdGO3FCQUNWLENBQUM7O3dDQUFBO2dCQUVGLDJCQUFDO1lBQUQsQ0FEQSxBQUNDLElBQUE7WUFERCx1REFDQyxDQUFBIiwiZmlsZSI6ImRldi9hbWF4Q29tcG9uZW50cy9hbWF4TG9hZGluZ0NvbXBvbmVudC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCB9IGZyb20gJ2FuZ3VsYXIyL2NvcmUnO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjpcIm14LWxvYWRpbmdcIixcbiAgICB0ZW1wbGF0ZTpgXG4gICAgICAgIDxkaXYgY2xhc3M9XCJidWJibGluZ0dcIj5cbiAgICAgICAgXG4gICAgPC9kaXY+YFxufSlcbmV4cG9ydCBjbGFzcyBBbWF4TG9hZGluZ0NvbXBvbmVudHtcbn0iXX0=
