System.register(["angular2/core", "../amaxUtil"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, amaxUtil_1;
    var AmaxCrmBreadcrumbComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (amaxUtil_1_1) {
                amaxUtil_1 = amaxUtil_1_1;
            }],
        execute: function() {
            AmaxCrmBreadcrumbComponent = (function () {
                function AmaxCrmBreadcrumbComponent() {
                    this.breadcrumbs = [
                        {
                            icon: 'fa-home',
                            name: 'Home'
                        },
                        {
                            icon: 'fa-rocket',
                            name: 'Office'
                        }
                    ];
                    amaxUtil_1.onEvent.listenEvent(amaxUtil_1.crmEvent.breadcrumbChange, this.updateBreadCrum);
                }
                AmaxCrmBreadcrumbComponent.prototype.updateBreadCrum = function (evt) {
                    this.breadcrumbs = evt.evtData;
                };
                AmaxCrmBreadcrumbComponent = __decorate([
                    core_1.Component({
                        selector: 'mx-breadcrumb',
                        templateUrl: './app/amaxComponents/templates/amaxCrmBreadcrumb.html',
                    }), 
                    __metadata('design:paramtypes', [])
                ], AmaxCrmBreadcrumbComponent);
                return AmaxCrmBreadcrumbComponent;
            }());
            exports_1("AmaxCrmBreadcrumbComponent", AmaxCrmBreadcrumbComponent);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldi9hbWF4Q29tcG9uZW50cy9hbWF4Q3JtQnJlYWRjcnVtYkNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztZQVFBO2dCQUVJO29CQUNJLElBQUksQ0FBQyxXQUFXLEdBQUM7d0JBQ2I7NEJBQ0ksSUFBSSxFQUFDLFNBQVM7NEJBQ2QsSUFBSSxFQUFDLE1BQU07eUJBQ2Q7d0JBQ0Q7NEJBQ0ksSUFBSSxFQUFDLFdBQVc7NEJBQ2hCLElBQUksRUFBQyxRQUFRO3lCQUNoQjtxQkFDSixDQUFDO29CQUVGLGtCQUFPLENBQUMsV0FBVyxDQUFDLG1CQUFRLENBQUMsZ0JBQWdCLEVBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFBO2dCQUV2RSxDQUFDO2dCQUNELG9EQUFlLEdBQWYsVUFBZ0IsR0FBRztvQkFDZixJQUFJLENBQUMsV0FBVyxHQUFHLEdBQUcsQ0FBQyxPQUFPLENBQUM7Z0JBQ25DLENBQUM7Z0JBdkJMO29CQUFDLGdCQUFTLENBQUM7d0JBQ1AsUUFBUSxFQUFDLGVBQWU7d0JBQ3hCLFdBQVcsRUFBQyx1REFBdUQ7cUJBQ3RFLENBQUM7OzhDQUFBO2dCQXFCRixpQ0FBQztZQUFELENBcEJBLEFBb0JDLElBQUE7WUFwQkQsbUVBb0JDLENBQUEiLCJmaWxlIjoiZGV2L2FtYXhDb21wb25lbnRzL2FtYXhDcm1CcmVhZGNydW1iQ29tcG9uZW50LmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtDb21wb25lbnR9IGZyb20gXCJhbmd1bGFyMi9jb3JlXCI7XG5pbXBvcnQge29uRXZlbnQsIGNybUV2ZW50fSBmcm9tIFwiLi4vYW1heFV0aWxcIjtcblxuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjonbXgtYnJlYWRjcnVtYicsXG4gICAgdGVtcGxhdGVVcmw6Jy4vYXBwL2FtYXhDb21wb25lbnRzL3RlbXBsYXRlcy9hbWF4Q3JtQnJlYWRjcnVtYi5odG1sJyxcbn0pXG5leHBvcnQgY2xhc3MgQW1heENybUJyZWFkY3J1bWJDb21wb25lbnR7XG4gICAgYnJlYWRjcnVtYnM6QXJyYXk8YW55PjtcbiAgICBjb25zdHJ1Y3Rvcigpe1xuICAgICAgICB0aGlzLmJyZWFkY3J1bWJzPVtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBpY29uOidmYS1ob21lJyxcbiAgICAgICAgICAgICAgICBuYW1lOidIb21lJ1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBpY29uOidmYS1yb2NrZXQnLFxuICAgICAgICAgICAgICAgIG5hbWU6J09mZmljZSdcbiAgICAgICAgICAgIH1cbiAgICAgICAgXTtcbiAgICAgICAgXG4gICAgICAgIG9uRXZlbnQubGlzdGVuRXZlbnQoY3JtRXZlbnQuYnJlYWRjcnVtYkNoYW5nZSx0aGlzLnVwZGF0ZUJyZWFkQ3J1bSlcblxuICAgIH1cbiAgICB1cGRhdGVCcmVhZENydW0oZXZ0KXtcbiAgICAgICAgdGhpcy5icmVhZGNydW1icyA9IGV2dC5ldnREYXRhO1xuICAgIH1cbn0iXX0=
