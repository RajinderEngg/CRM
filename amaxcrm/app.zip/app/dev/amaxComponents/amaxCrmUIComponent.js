System.register(['angular2/core', "./amaxCrmNavbarComponent", "./amaxCrmSidebarComponent", "./amaxCrmBreadcrumbComponent", "angular2/router"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, amaxCrmNavbarComponent_1, amaxCrmSidebarComponent_1, amaxCrmBreadcrumbComponent_1, router_1;
    var AmaxCrmUIComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (amaxCrmNavbarComponent_1_1) {
                amaxCrmNavbarComponent_1 = amaxCrmNavbarComponent_1_1;
            },
            function (amaxCrmSidebarComponent_1_1) {
                amaxCrmSidebarComponent_1 = amaxCrmSidebarComponent_1_1;
            },
            function (amaxCrmBreadcrumbComponent_1_1) {
                amaxCrmBreadcrumbComponent_1 = amaxCrmBreadcrumbComponent_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            }],
        execute: function() {
            AmaxCrmUIComponent = (function () {
                function AmaxCrmUIComponent() {
                }
                AmaxCrmUIComponent.prototype.ngOnInit = function () {
                    ////var windWidth = jQuery(window).width();
                    ////if (windWidth > 250) {
                    //    var brwidth = screen.width;
                    //    var sideWidth = jQuery("#slide-out").width();
                    //    jQuery(".breadcrumbs").css("width", brwidth - sideWidth );
                    ////}
                };
                AmaxCrmUIComponent = __decorate([
                    core_1.Component({
                        selector: 'mx-ui',
                        templateUrl: './app/amaxComponents/templates/amaxCrmUI.html',
                        directives: [router_1.ROUTER_DIRECTIVES, amaxCrmNavbarComponent_1.AmaxCrmNavbarComponent, amaxCrmSidebarComponent_1.AmaxCrmSidebarComponent, amaxCrmBreadcrumbComponent_1.AmaxCrmBreadcrumbComponent]
                    }), 
                    __metadata('design:paramtypes', [])
                ], AmaxCrmUIComponent);
                return AmaxCrmUIComponent;
            }());
            exports_1("AmaxCrmUIComponent", AmaxCrmUIComponent);
        }
    }
});
// template : `
//     <mx-navbar></mx-navbar>
//     <div class="main-container" id="main-container">
//         <mx-sidebar></mx-sidebar>
//     </div><!-- /.main-container -->
// `,
//directives: [AmaxCrmNavbarComponent, AmaxCrmSidebarComponent] 

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldi9hbWF4Q29tcG9uZW50cy9hbWF4Q3JtVUlDb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7WUFXQTtnQkFBQTtnQkFVQSxDQUFDO2dCQVRHLHFDQUFRLEdBQVI7b0JBRUksMkNBQTJDO29CQUMzQywwQkFBMEI7b0JBQzFCLGlDQUFpQztvQkFDakMsbURBQW1EO29CQUNuRCxnRUFBZ0U7b0JBQ2hFLEtBQUs7Z0JBQ1QsQ0FBQztnQkFkTDtvQkFBQyxnQkFBUyxDQUFDO3dCQUNQLFFBQVEsRUFBRSxPQUFPO3dCQUNqQixXQUFXLEVBQUcsK0NBQStDO3dCQUM3RCxVQUFVLEVBQUMsQ0FBQywwQkFBaUIsRUFBRSwrQ0FBc0IsRUFBRSxpREFBdUIsRUFBRSx1REFBMEIsQ0FBQztxQkFDOUcsQ0FBQzs7c0NBQUE7Z0JBV0YseUJBQUM7WUFBRCxDQVZBLEFBVUMsSUFBQTtZQVZELG1EQVVDLENBQUE7Ozs7QUFJRyxlQUFlO0FBQ2YsOEJBQThCO0FBQzlCLHVEQUF1RDtBQUN2RCxvQ0FBb0M7QUFDcEMsc0NBQXNDO0FBQ3RDLEtBQUs7QUFDTCwrREFBK0QiLCJmaWxlIjoiZGV2L2FtYXhDb21wb25lbnRzL2FtYXhDcm1VSUNvbXBvbmVudC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgT25Jbml0IH0gZnJvbSAnYW5ndWxhcjIvY29yZSc7XG5pbXBvcnQge0FtYXhDcm1OYXZiYXJDb21wb25lbnR9IGZyb20gXCIuL2FtYXhDcm1OYXZiYXJDb21wb25lbnRcIjtcbmltcG9ydCB7QW1heENybVNpZGViYXJDb21wb25lbnR9IGZyb20gXCIuL2FtYXhDcm1TaWRlYmFyQ29tcG9uZW50XCI7XG5pbXBvcnQge0FtYXhDcm1CcmVhZGNydW1iQ29tcG9uZW50fSBmcm9tIFwiLi9hbWF4Q3JtQnJlYWRjcnVtYkNvbXBvbmVudFwiO1xuaW1wb3J0IHtST1VURVJfRElSRUNUSVZFU30gZnJvbSBcImFuZ3VsYXIyL3JvdXRlclwiO1xuZGVjbGFyZSB2YXIgalF1ZXJ5O1xuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdteC11aScsXG4gICAgdGVtcGxhdGVVcmwgOiAnLi9hcHAvYW1heENvbXBvbmVudHMvdGVtcGxhdGVzL2FtYXhDcm1VSS5odG1sJyxcbiAgICBkaXJlY3RpdmVzOltST1VURVJfRElSRUNUSVZFUywgQW1heENybU5hdmJhckNvbXBvbmVudCwgQW1heENybVNpZGViYXJDb21wb25lbnQsIEFtYXhDcm1CcmVhZGNydW1iQ29tcG9uZW50XVxufSlcbmV4cG9ydCBjbGFzcyBBbWF4Q3JtVUlDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXR7XG4gICAgbmdPbkluaXQoKSB7XHJcblxyXG4gICAgICAgIC8vLy92YXIgd2luZFdpZHRoID0galF1ZXJ5KHdpbmRvdykud2lkdGgoKTtcclxuICAgICAgICAvLy8vaWYgKHdpbmRXaWR0aCA+IDI1MCkge1xyXG4gICAgICAgIC8vICAgIHZhciBicndpZHRoID0gc2NyZWVuLndpZHRoO1xyXG4gICAgICAgIC8vICAgIHZhciBzaWRlV2lkdGggPSBqUXVlcnkoXCIjc2xpZGUtb3V0XCIpLndpZHRoKCk7XHJcbiAgICAgICAgLy8gICAgalF1ZXJ5KFwiLmJyZWFkY3J1bWJzXCIpLmNzcyhcIndpZHRoXCIsIGJyd2lkdGggLSBzaWRlV2lkdGggKTtcclxuICAgICAgICAvLy8vfVxuICAgIH1cbn1cblxuXG5cbiAgICAvLyB0ZW1wbGF0ZSA6IGBcbiAgICAvLyAgICAgPG14LW5hdmJhcj48L214LW5hdmJhcj5cbiAgICAvLyAgICAgPGRpdiBjbGFzcz1cIm1haW4tY29udGFpbmVyXCIgaWQ9XCJtYWluLWNvbnRhaW5lclwiPlxuICAgIC8vICAgICAgICAgPG14LXNpZGViYXI+PC9teC1zaWRlYmFyPlxuICAgIC8vICAgICA8L2Rpdj48IS0tIC8ubWFpbi1jb250YWluZXIgLS0+XG4gICAgLy8gYCxcbiAgICAvL2RpcmVjdGl2ZXM6IFtBbWF4Q3JtTmF2YmFyQ29tcG9uZW50LCBBbWF4Q3JtU2lkZWJhckNvbXBvbmVudF0iXX0=
