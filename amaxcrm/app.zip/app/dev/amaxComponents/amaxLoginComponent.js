System.register(['angular2/core', '../comonComponents/basicComponents', "../services/ResourceService"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, basicComponents_1, ResourceService_1;
    var AmaxLoginComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (basicComponents_1_1) {
                basicComponents_1 = basicComponents_1_1;
            },
            function (ResourceService_1_1) {
                ResourceService_1 = ResourceService_1_1;
            }],
        execute: function() {
            AmaxLoginComponent = (function () {
                function AmaxLoginComponent(_languageService) {
                    this._languageService = _languageService;
                    this.dataEmitter = new core_1.EventEmitter();
                    this.languageEmitter = new core_1.EventEmitter();
                    this.languageArray = [];
                    this.Language = "English";
                    this.Language = "English";
                }
                AmaxLoginComponent.prototype.languageSelectionChange = function (evt) {
                    debugger;
                    this.languageEmitter.emit(evt);
                };
                AmaxLoginComponent.prototype.Validate = function () {
                    this.dataEmitter.emit(this.modelInput);
                };
                AmaxLoginComponent.prototype.ngOnInit = function () {
                    this.languageArray = this._languageService.GetAvailableLanguages();
                    var lang = this._languageService.getCookie("lang");
                    ///alert(lang);
                    if (lang.length > 0)
                        var lang = lang.substring(1, lang.length);
                    if (lang == "he")
                        lang = "עִברִית";
                    else {
                        lang = "English";
                    }
                    this.Language = lang;
                };
                __decorate([
                    core_1.Input("dataModel"), 
                    __metadata('design:type', Object)
                ], AmaxLoginComponent.prototype, "modelInput", void 0);
                __decorate([
                    core_1.Input("res"), 
                    __metadata('design:type', Object)
                ], AmaxLoginComponent.prototype, "RES", void 0);
                __decorate([
                    core_1.Output("ondata"), 
                    __metadata('design:type', Object)
                ], AmaxLoginComponent.prototype, "dataEmitter", void 0);
                __decorate([
                    core_1.Output("onlanguage"), 
                    __metadata('design:type', Object)
                ], AmaxLoginComponent.prototype, "languageEmitter", void 0);
                AmaxLoginComponent = __decorate([
                    core_1.Component({
                        selector: 'mx-login',
                        templateUrl: './app/amaxComponents/templates/login.html',
                        directives: [basicComponents_1.SelectInputComponent],
                        providers: [ResourceService_1.ResourceService]
                    }), 
                    __metadata('design:paramtypes', [ResourceService_1.ResourceService])
                ], AmaxLoginComponent);
                return AmaxLoginComponent;
            }());
            exports_1("AmaxLoginComponent", AmaxLoginComponent);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldi9hbWF4Q29tcG9uZW50cy9hbWF4TG9naW5Db21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7WUFXQTtnQkFTSSw0QkFBb0IsZ0JBQWlDO29CQUFqQyxxQkFBZ0IsR0FBaEIsZ0JBQWdCLENBQWlCO29CQUxuQyxnQkFBVyxHQUFHLElBQUksbUJBQVksRUFBRSxDQUFDO29CQUM3QixvQkFBZSxHQUFHLElBQUksbUJBQVksRUFBRSxDQUFDO29CQUUzRCxrQkFBYSxHQUFHLEVBQUUsQ0FBQztvQkFDbkIsYUFBUSxHQUFXLFNBQVMsQ0FBQztvQkFFekIsSUFBSSxDQUFDLFFBQVEsR0FBRyxTQUFTLENBQUM7Z0JBQzlCLENBQUM7Z0JBRUQsb0RBQXVCLEdBQXZCLFVBQXdCLEdBQUc7b0JBQ3ZCLFFBQVEsQ0FBQztvQkFDVCxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDbkMsQ0FBQztnQkFFRCxxQ0FBUSxHQUFSO29CQUNJLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztnQkFDM0MsQ0FBQztnQkFFRCxxQ0FBUSxHQUFSO29CQUNJLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLHFCQUFxQixFQUFFLENBQUM7b0JBQ25FLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQ25ELGVBQWU7b0JBQ2YsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7d0JBQ2hCLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDOUMsRUFBRSxDQUFDLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQzt3QkFDYixJQUFJLEdBQUcsU0FBUyxDQUFDO29CQUNyQixJQUFJLENBQUMsQ0FBQzt3QkFDRixJQUFJLEdBQUcsU0FBUyxDQUFDO29CQUNyQixDQUFDO29CQUNELElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO2dCQUN6QixDQUFDO2dCQWpDRDtvQkFBQyxZQUFLLENBQUMsV0FBVyxDQUFDOztzRUFBQTtnQkFDbkI7b0JBQUMsWUFBSyxDQUFDLEtBQUssQ0FBQzs7K0RBQUE7Z0JBRWI7b0JBQUMsYUFBTSxDQUFDLFFBQVEsQ0FBQzs7dUVBQUE7Z0JBQ2pCO29CQUFDLGFBQU0sQ0FBQyxZQUFZLENBQUM7OzJFQUFBO2dCQVh6QjtvQkFBQyxnQkFBUyxDQUFDO3dCQUNQLFFBQVEsRUFBQyxVQUFVO3dCQUNuQixXQUFXLEVBQUMsMkNBQTJDO3dCQUN2RCxVQUFVLEVBQUUsQ0FBQyxzQ0FBb0IsQ0FBRTt3QkFDbkMsU0FBUyxFQUFDLENBQUMsaUNBQWUsQ0FBQztxQkFDOUIsQ0FBQzs7c0NBQUE7Z0JBb0NGLHlCQUFDO1lBQUQsQ0FuQ0EsQUFtQ0MsSUFBQTtZQW5DRCxtREFtQ0MsQ0FBQSIsImZpbGUiOiJkZXYvYW1heENvbXBvbmVudHMvYW1heExvZ2luQ29tcG9uZW50LmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtDb21wb25lbnQsIE91dHB1dCwgSW5wdXQsIEV2ZW50RW1pdHRlciwgT25Jbml0fSBmcm9tICdhbmd1bGFyMi9jb3JlJztcbmltcG9ydCB7IFNlbGVjdElucHV0Q29tcG9uZW50IH0gZnJvbSAnLi4vY29tb25Db21wb25lbnRzL2Jhc2ljQ29tcG9uZW50cyc7XG5pbXBvcnQge1Jlc291cmNlU2VydmljZX0gZnJvbSBcIi4uL3NlcnZpY2VzL1Jlc291cmNlU2VydmljZVwiO1xuXG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOidteC1sb2dpbicsXG4gICAgdGVtcGxhdGVVcmw6Jy4vYXBwL2FtYXhDb21wb25lbnRzL3RlbXBsYXRlcy9sb2dpbi5odG1sJyxcbiAgICBkaXJlY3RpdmVzOiBbU2VsZWN0SW5wdXRDb21wb25lbnQgXSxcbiAgICBwcm92aWRlcnM6W1Jlc291cmNlU2VydmljZV1cbn0pXG5leHBvcnQgY2xhc3MgQW1heExvZ2luQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0e1xuICAgIEBJbnB1dChcImRhdGFNb2RlbFwiKSBtb2RlbElucHV0O1xuICAgIEBJbnB1dChcInJlc1wiKSBSRVM6T2JqZWN0O1xuXG4gICAgQE91dHB1dChcIm9uZGF0YVwiKSBkYXRhRW1pdHRlciA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcbiAgICBAT3V0cHV0KFwib25sYW5ndWFnZVwiKSBsYW5ndWFnZUVtaXR0ZXIgPSBuZXcgRXZlbnRFbWl0dGVyKCk7XG5cbiAgICBsYW5ndWFnZUFycmF5ID0gW107XG4gICAgTGFuZ3VhZ2U6IHN0cmluZyA9IFwiRW5nbGlzaFwiO1xuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgX2xhbmd1YWdlU2VydmljZTogUmVzb3VyY2VTZXJ2aWNlKSB7XG4gICAgICAgIHRoaXMuTGFuZ3VhZ2UgPSBcIkVuZ2xpc2hcIjtcbiAgICB9XG5cbiAgICBsYW5ndWFnZVNlbGVjdGlvbkNoYW5nZShldnQpIHtcbiAgICAgICAgZGVidWdnZXI7XG4gICAgICAgIHRoaXMubGFuZ3VhZ2VFbWl0dGVyLmVtaXQoZXZ0KTtcbiAgICB9XG5cbiAgICBWYWxpZGF0ZSgpIHtcbiAgICAgICAgdGhpcy5kYXRhRW1pdHRlci5lbWl0KHRoaXMubW9kZWxJbnB1dCk7XG4gICAgfVxuXG4gICAgbmdPbkluaXQoKSB7XG4gICAgICAgIHRoaXMubGFuZ3VhZ2VBcnJheSA9IHRoaXMuX2xhbmd1YWdlU2VydmljZS5HZXRBdmFpbGFibGVMYW5ndWFnZXMoKTtcbiAgICAgICAgdmFyIGxhbmcgPSB0aGlzLl9sYW5ndWFnZVNlcnZpY2UuZ2V0Q29va2llKFwibGFuZ1wiKTtcbiAgICAgICAgLy8vYWxlcnQobGFuZyk7XG4gICAgICAgIGlmIChsYW5nLmxlbmd0aCA+IDApXG4gICAgICAgICAgICB2YXIgbGFuZyA9IGxhbmcuc3Vic3RyaW5nKDEsIGxhbmcubGVuZ3RoKTtcbiAgICAgICAgaWYgKGxhbmcgPT0gXCJoZVwiKVxuICAgICAgICAgICAgbGFuZyA9IFwi16LWtNeR16jWtNeZ16pcIjtcbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBsYW5nID0gXCJFbmdsaXNoXCI7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5MYW5ndWFnZSA9IGxhbmc7XG4gICAgfVxufSJdfQ==
