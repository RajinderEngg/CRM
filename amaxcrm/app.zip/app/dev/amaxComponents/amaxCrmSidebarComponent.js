System.register(['angular2/core', "angular2/router", "../services/ResourceService"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1, ResourceService_1;
    var AmaxCrmSidebarComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (ResourceService_1_1) {
                ResourceService_1 = ResourceService_1_1;
            }],
        execute: function() {
            AmaxCrmSidebarComponent = (function () {
                function AmaxCrmSidebarComponent(_resourceService) {
                    this._resourceService = _resourceService;
                    this.UserName = "";
                }
                AmaxCrmSidebarComponent.prototype.LogOut = function () {
                    var empid = localStorage.getItem("employeeid");
                    localStorage.clear();
                    sessionStorage.clear();
                    //debugger;
                    //var data = this._resourceService.getCookie("
                    //    this._resourceService.setCookie("UserDet", data, 10);
                    //var data = this._resourceService.getCookie("RememberKey");  
                    //this._resourceService.setCookie("UserDet", data, 10); 
                    this._resourceService.deleteCookie("RememberKey");
                    this._resourceService.deleteCookie(empid + "cust");
                    this._resourceService.deleteCookie(empid + "emp");
                    this._resourceService.deleteCookie(empid + "src");
                    this._resourceService.deleteCookie(empid + "ccode");
                    this._resourceService.deleteCookie(empid + "SMSDet");
                    this._resourceService.deleteCookie(empid + "SMSMessage");
                    window.location.href = "/";
                };
                AmaxCrmSidebarComponent.prototype.ngOnInit = function () {
                    AMAX_CRM.enableSidebar();
                    var Uname = this._resourceService.getCookie("UserName");
                    if (Uname.length > 0 && Uname[0] == "=") {
                        Uname = Uname.substring(1, Uname.length);
                    }
                    this.UserName = Uname;
                    this.SideNav = this.SideNav = this._resourceService.GetMenues();
                    //Main Left Sidebar Menu
                    $('.sidebar-collapse').sideNav({
                        edge: 'left',
                    });
                    // FULL SCREEN MENU (Layout 02)
                    $('.menu-sidebar-collapse').sideNav({
                        menuWidth: 240,
                        edge: 'left',
                        //closeOnClick:true, // Set if default menu open is true
                        menuOut: false // Set if default menu open is true
                    });
                    // HORIZONTAL MENU (Layout 03)
                    $('.dropdown-menu').dropdown({
                        inDuration: 300,
                        outDuration: 225,
                        constrain_width: false,
                        hover: true,
                        gutter: 0,
                        belowOrigin: true // Displays dropdown below the button
                    });
                    // Perfect Scrollbar
                    $('select').not('.disabled').material_select();
                    var leftnav = $(".page-topbar").height();
                    var leftnavHeight = window.innerHeight - leftnav;
                    $('.leftside-navigation').height(leftnavHeight).perfectScrollbar({
                        suppressScrollX: true
                    });
                    var righttnav = $("#chat-out").height();
                    $('.rightside-navigation').height(righttnav).perfectScrollbar({
                        suppressScrollX: true
                    });
                };
                AmaxCrmSidebarComponent = __decorate([
                    core_1.Component({
                        selector: 'mx-sidebar',
                        templateUrl: './app/amaxComponents/templates/amaxCrmSidebar.html',
                        directives: [router_1.ROUTER_DIRECTIVES],
                        providers: [ResourceService_1.ResourceService]
                    }), 
                    __metadata('design:paramtypes', [ResourceService_1.ResourceService])
                ], AmaxCrmSidebarComponent);
                return AmaxCrmSidebarComponent;
            }());
            exports_1("AmaxCrmSidebarComponent", AmaxCrmSidebarComponent);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldi9hbWF4Q29tcG9uZW50cy9hbWF4Q3JtU2lkZWJhckNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztZQVlBO2dCQUdJLGlDQUFvQixnQkFBZ0M7b0JBQWhDLHFCQUFnQixHQUFoQixnQkFBZ0IsQ0FBZ0I7b0JBRHBELGFBQVEsR0FBVyxFQUFFLENBQUM7Z0JBQ2dDLENBQUM7Z0JBQ3ZELHdDQUFNLEdBQU47b0JBQ0ksSUFBSSxLQUFLLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQztvQkFDL0MsWUFBWSxDQUFDLEtBQUssRUFBRSxDQUFDO29CQUNyQixjQUFjLENBQUMsS0FBSyxFQUFFLENBQUM7b0JBQ3ZCLFdBQVc7b0JBQ1gsOENBQThDO29CQUM5QywyREFBMkQ7b0JBRTNELDhEQUE4RDtvQkFDOUQsd0RBQXdEO29CQUN4RCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxDQUFDLGFBQWEsQ0FBQyxDQUFDO29CQUNsRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxDQUFDLEtBQUssR0FBRyxNQUFNLENBQUMsQ0FBQztvQkFDbkQsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDLENBQUM7b0JBQ2xELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQyxDQUFDO29CQUNsRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxDQUFDLEtBQUssR0FBRyxPQUFPLENBQUMsQ0FBQztvQkFDcEQsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQyxLQUFLLEdBQUcsUUFBUSxDQUFDLENBQUM7b0JBQ3JELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLENBQUMsS0FBSyxHQUFHLFlBQVksQ0FBQyxDQUFDO29CQUN6RCxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUM7Z0JBQy9CLENBQUM7Z0JBQ0QsMENBQVEsR0FBUjtvQkFJSSxRQUFRLENBQUMsYUFBYSxFQUFFLENBQUM7b0JBRXpCLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7b0JBQ3hELEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsQ0FBQyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxHQUFHLENBQUMsQ0FBQyxDQUFDO3dCQUN0QyxLQUFLLEdBQUcsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUM3QyxDQUFDO29CQUNELElBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO29CQUN0QixJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsRUFBRSxDQUFDO29CQUdoRSx3QkFBd0I7b0JBQ3hCLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLE9BQU8sQ0FBQzt3QkFDM0IsSUFBSSxFQUFFLE1BQU07cUJBQ2YsQ0FBQyxDQUFDO29CQUVILCtCQUErQjtvQkFDL0IsQ0FBQyxDQUFDLHdCQUF3QixDQUFDLENBQUMsT0FBTyxDQUFDO3dCQUNoQyxTQUFTLEVBQUUsR0FBRzt3QkFDZCxJQUFJLEVBQUUsTUFBTTt3QkFDWix3REFBd0Q7d0JBQ3hELE9BQU8sRUFBRSxLQUFLLENBQUMsbUNBQW1DO3FCQUVyRCxDQUFDLENBQUM7b0JBRUgsOEJBQThCO29CQUM5QixDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxRQUFRLENBQUM7d0JBQ3pCLFVBQVUsRUFBRSxHQUFHO3dCQUNmLFdBQVcsRUFBRSxHQUFHO3dCQUNoQixlQUFlLEVBQUUsS0FBSzt3QkFDdEIsS0FBSyxFQUFFLElBQUk7d0JBQ1gsTUFBTSxFQUFFLENBQUM7d0JBQ1QsV0FBVyxFQUFFLElBQUksQ0FBQyxxQ0FBcUM7cUJBQzFELENBQUMsQ0FBQztvQkFHSCxvQkFBb0I7b0JBQ3BCLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUMsZUFBZSxFQUFFLENBQUM7b0JBQy9DLElBQUksT0FBTyxHQUFHLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztvQkFDekMsSUFBSSxhQUFhLEdBQUcsTUFBTSxDQUFDLFdBQVcsR0FBRyxPQUFPLENBQUM7b0JBQ2pELENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQzt3QkFDN0QsZUFBZSxFQUFFLElBQUk7cUJBQ3hCLENBQUMsQ0FBQztvQkFDSCxJQUFJLFNBQVMsR0FBRyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUM7b0JBQ3hDLENBQUMsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQzt3QkFDMUQsZUFBZSxFQUFFLElBQUk7cUJBQ3hCLENBQUMsQ0FBQztnQkFHUCxDQUFDO2dCQWpGTDtvQkFBQyxnQkFBUyxDQUFDO3dCQUNQLFFBQVEsRUFBRSxZQUFZO3dCQUN0QixXQUFXLEVBQUMsb0RBQW9EO3dCQUNoRSxVQUFVLEVBQUMsQ0FBQywwQkFBaUIsQ0FBQzt3QkFDOUIsU0FBUyxFQUFDLENBQUMsaUNBQWUsQ0FBQztxQkFDOUIsQ0FBQzs7MkNBQUE7Z0JBNkVGLDhCQUFDO1lBQUQsQ0E1RUEsQUE0RUMsSUFBQTtZQTVFRCw2REE0RUMsQ0FBQSIsImZpbGUiOiJkZXYvYW1heENvbXBvbmVudHMvYW1heENybVNpZGViYXJDb21wb25lbnQuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge0NvbXBvbmVudCwgT25Jbml0fSBmcm9tICdhbmd1bGFyMi9jb3JlJztcbmltcG9ydCB7Uk9VVEVSX0RJUkVDVElWRVN9IGZyb20gXCJhbmd1bGFyMi9yb3V0ZXJcIjtcbmltcG9ydCB7UmVzb3VyY2VTZXJ2aWNlLCBNZW51ZUl0ZW19IGZyb20gXCIuLi9zZXJ2aWNlcy9SZXNvdXJjZVNlcnZpY2VcIjtcblxuZGVjbGFyZSB2YXIgQU1BWF9DUk07XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnbXgtc2lkZWJhcicsXG4gICAgdGVtcGxhdGVVcmw6Jy4vYXBwL2FtYXhDb21wb25lbnRzL3RlbXBsYXRlcy9hbWF4Q3JtU2lkZWJhci5odG1sJyxcbiAgICBkaXJlY3RpdmVzOltST1VURVJfRElSRUNUSVZFU10sXG4gICAgcHJvdmlkZXJzOltSZXNvdXJjZVNlcnZpY2VdXG59KVxuZXhwb3J0IGNsYXNzIEFtYXhDcm1TaWRlYmFyQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0e1xuICAgIFNpZGVOYXY6IFByb21pc2U8YW55PjtcbiAgICBVc2VyTmFtZTogc3RyaW5nID0gXCJcIjtcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIF9yZXNvdXJjZVNlcnZpY2U6UmVzb3VyY2VTZXJ2aWNlKXt9XG4gICAgTG9nT3V0KCkge1xuICAgICAgICB2YXIgZW1waWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImVtcGxveWVlaWRcIik7XG4gICAgICAgIGxvY2FsU3RvcmFnZS5jbGVhcigpO1xuICAgICAgICBzZXNzaW9uU3RvcmFnZS5jbGVhcigpO1xuICAgICAgICAvL2RlYnVnZ2VyO1xuICAgICAgICAvL3ZhciBkYXRhID0gdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmdldENvb2tpZShcIlxuICAgICAgICAvLyAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2Uuc2V0Q29va2llKFwiVXNlckRldFwiLCBkYXRhLCAxMCk7XG5cbiAgICAgICAgLy92YXIgZGF0YSA9IHRoaXMuX3Jlc291cmNlU2VydmljZS5nZXRDb29raWUoXCJSZW1lbWJlcktleVwiKTsgIFxuICAgICAgICAvL3RoaXMuX3Jlc291cmNlU2VydmljZS5zZXRDb29raWUoXCJVc2VyRGV0XCIsIGRhdGEsIDEwKTsgXG4gICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5kZWxldGVDb29raWUoXCJSZW1lbWJlcktleVwiKTtcbiAgICAgICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmRlbGV0ZUNvb2tpZShlbXBpZCArIFwiY3VzdFwiKTtcbiAgICAgICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmRlbGV0ZUNvb2tpZShlbXBpZCArIFwiZW1wXCIpO1xuICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZGVsZXRlQ29va2llKGVtcGlkICsgXCJzcmNcIik7XG4gICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5kZWxldGVDb29raWUoZW1waWQgKyBcImNjb2RlXCIpO1xuICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZGVsZXRlQ29va2llKGVtcGlkICsgXCJTTVNEZXRcIik7XG4gICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5kZWxldGVDb29raWUoZW1waWQgKyBcIlNNU01lc3NhZ2VcIik7XG4gICAgICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmID0gXCIvXCI7XG4gICAgfVxuICAgIG5nT25Jbml0KCkge1xuXG5cbiAgICAgICAgXG4gICAgICAgIEFNQVhfQ1JNLmVuYWJsZVNpZGViYXIoKTtcblxyXG4gICAgICAgIHZhciBVbmFtZSA9IHRoaXMuX3Jlc291cmNlU2VydmljZS5nZXRDb29raWUoXCJVc2VyTmFtZVwiKTtcbiAgICAgICAgaWYgKFVuYW1lLmxlbmd0aCA+IDAgJiYgVW5hbWVbMF0gPT0gXCI9XCIpIHtcclxuICAgICAgICAgICAgVW5hbWUgPSBVbmFtZS5zdWJzdHJpbmcoMSwgVW5hbWUubGVuZ3RoKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLlVzZXJOYW1lID0gVW5hbWU7XG4gICAgICAgIHRoaXMuU2lkZU5hdiA9IHRoaXMuU2lkZU5hdiA9IHRoaXMuX3Jlc291cmNlU2VydmljZS5HZXRNZW51ZXMoKTtcblxuXG4gICAgICAgIC8vTWFpbiBMZWZ0IFNpZGViYXIgTWVudVxyXG4gICAgICAgICQoJy5zaWRlYmFyLWNvbGxhcHNlJykuc2lkZU5hdih7XHJcbiAgICAgICAgICAgIGVkZ2U6ICdsZWZ0JywgLy8gQ2hvb3NlIHRoZSBob3Jpem9udGFsIG9yaWdpbiAgICBcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgLy8gRlVMTCBTQ1JFRU4gTUVOVSAoTGF5b3V0IDAyKVxyXG4gICAgICAgICQoJy5tZW51LXNpZGViYXItY29sbGFwc2UnKS5zaWRlTmF2KHtcclxuICAgICAgICAgICAgbWVudVdpZHRoOiAyNDAsXHJcbiAgICAgICAgICAgIGVkZ2U6ICdsZWZ0JywgLy8gQ2hvb3NlIHRoZSBob3Jpem9udGFsIG9yaWdpbiAgICAgXHJcbiAgICAgICAgICAgIC8vY2xvc2VPbkNsaWNrOnRydWUsIC8vIFNldCBpZiBkZWZhdWx0IG1lbnUgb3BlbiBpcyB0cnVlXHJcbiAgICAgICAgICAgIG1lbnVPdXQ6IGZhbHNlIC8vIFNldCBpZiBkZWZhdWx0IG1lbnUgb3BlbiBpcyB0cnVlXHJcbiAgICAgICAgXHJcbiAgICAgICAgfSk7XG5cbiAgICAgICAgLy8gSE9SSVpPTlRBTCBNRU5VIChMYXlvdXQgMDMpXG4gICAgICAgICQoJy5kcm9wZG93bi1tZW51JykuZHJvcGRvd24oe1xuICAgICAgICAgICAgaW5EdXJhdGlvbjogMzAwLFxuICAgICAgICAgICAgb3V0RHVyYXRpb246IDIyNSxcbiAgICAgICAgICAgIGNvbnN0cmFpbl93aWR0aDogZmFsc2UsIC8vIERvZXMgbm90IGNoYW5nZSB3aWR0aCBvZiBkcm9wZG93biB0byB0aGF0IG9mIHRoZSBhY3RpdmF0b3JcbiAgICAgICAgICAgIGhvdmVyOiB0cnVlLCAvLyBBY3RpdmF0ZSBvbiBob3ZlclxuICAgICAgICAgICAgZ3V0dGVyOiAwLCAvLyBTcGFjaW5nIGZyb20gZWRnZVxuICAgICAgICAgICAgYmVsb3dPcmlnaW46IHRydWUgLy8gRGlzcGxheXMgZHJvcGRvd24gYmVsb3cgdGhlIGJ1dHRvblxuICAgICAgICB9KTtcblxuXG4gICAgICAgIC8vIFBlcmZlY3QgU2Nyb2xsYmFyXG4gICAgICAgICQoJ3NlbGVjdCcpLm5vdCgnLmRpc2FibGVkJykubWF0ZXJpYWxfc2VsZWN0KCk7XG4gICAgICAgIHZhciBsZWZ0bmF2ID0gJChcIi5wYWdlLXRvcGJhclwiKS5oZWlnaHQoKTtcbiAgICAgICAgdmFyIGxlZnRuYXZIZWlnaHQgPSB3aW5kb3cuaW5uZXJIZWlnaHQgLSBsZWZ0bmF2O1xuICAgICAgICAkKCcubGVmdHNpZGUtbmF2aWdhdGlvbicpLmhlaWdodChsZWZ0bmF2SGVpZ2h0KS5wZXJmZWN0U2Nyb2xsYmFyKHtcbiAgICAgICAgICAgIHN1cHByZXNzU2Nyb2xsWDogdHJ1ZVxuICAgICAgICB9KTtcbiAgICAgICAgdmFyIHJpZ2h0dG5hdiA9ICQoXCIjY2hhdC1vdXRcIikuaGVpZ2h0KCk7XG4gICAgICAgICQoJy5yaWdodHNpZGUtbmF2aWdhdGlvbicpLmhlaWdodChyaWdodHRuYXYpLnBlcmZlY3RTY3JvbGxiYXIoe1xuICAgICAgICAgICAgc3VwcHJlc3NTY3JvbGxYOiB0cnVlXG4gICAgICAgIH0pOyBcblxuXG4gICAgfVxufSJdfQ==
