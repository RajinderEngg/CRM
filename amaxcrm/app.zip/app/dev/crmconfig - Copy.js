System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var crmConfig, serviceConfig, LocalDict, SessionlDict;
    return {
        setters:[],
        execute: function() {
            crmConfig = {
                version: "1.0.0.22",
                minSvcVersion: "",
                minDbsVersion: "",
                falbackLanguage: "he"
            };
            serviceConfig = {
                serviceBaseUrl: "http://localhost/amaxweb/Api.svc/",
                serviceApiUrl: "http://localhost:57998/API/",
                accesTokenStoreName: "XToken",
                accesTokenRequestHeader: "X-Token",
                accesTokenResponceHeader: "XToken",
                authenticationMode: "JWT-Token"
            };
            exports_1("LocalDict", LocalDict = {
                userCredential: "userCredential",
                selectedLanguage: "preferedLanguage",
                languageResource: "languageResource",
                SmsSettings: "smsSettings"
            });
            exports_1("SessionlDict", SessionlDict = {});
            if (window.location.href.indexOf("127.0.0.1") > -1)
                serviceConfig.serviceBaseUrl = "http://localhost:57998/Api.svc/";
            exports_1("serviceConfig", serviceConfig);
            exports_1("crmConfig", crmConfig);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldi9jcm1jb25maWcgLSBDb3B5LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztRQUFJLFNBQVMsRUFNVCxhQUFhLEVBVU4sU0FBUyxFQU9ULFlBQVk7Ozs7WUF2Qm5CLFNBQVMsR0FBRztnQkFDWixPQUFPLEVBQUUsVUFBVTtnQkFDbkIsYUFBYSxFQUFFLEVBQUU7Z0JBQ2pCLGFBQWEsRUFBRSxFQUFFO2dCQUNqQixlQUFlLEVBQUUsSUFBSTthQUN4QixDQUFDO1lBQ0UsYUFBYSxHQUFHO2dCQUNoQixjQUFjLEVBQUUsbUNBQW1DO2dCQUNuRCxhQUFhLEVBQUUsNkJBQTZCO2dCQUM1QyxtQkFBbUIsRUFBQyxRQUFRO2dCQUM1Qix1QkFBdUIsRUFBQyxTQUFTO2dCQUNqQyx3QkFBd0IsRUFBQyxRQUFRO2dCQUdqQyxrQkFBa0IsRUFBQyxXQUFXO2FBQ2pDLENBQUE7WUFDVSx1QkFBQSxTQUFTLEdBQUc7Z0JBQ25CLGNBQWMsRUFBRSxnQkFBZ0I7Z0JBQ2hDLGdCQUFnQixFQUFFLGtCQUFrQjtnQkFDcEMsZ0JBQWdCLEVBQUUsa0JBQWtCO2dCQUNwQyxXQUFXLEVBQUUsYUFBYTthQUM3QixDQUFBLENBQUE7WUFFVSwwQkFBQSxZQUFZLEdBQUcsRUFFekIsQ0FBQSxDQUFBO1lBQ0QsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO2dCQUNuRCxhQUFhLENBQUMsY0FBYyxHQUFDLGlDQUFpQyxDQUFDO1lBRS9ELHlDQUFhO1lBQ2IsaUNBQVMiLCJmaWxlIjoiZGV2L2NybWNvbmZpZyAtIENvcHkuanMiLCJzb3VyY2VzQ29udGVudCI6WyJsZXQgY3JtQ29uZmlnID0ge1xyXG4gICAgdmVyc2lvbjogXCIxLjAuMC4yMlwiLFxyXG4gICAgbWluU3ZjVmVyc2lvbjogXCJcIixcclxuICAgIG1pbkRic1ZlcnNpb246IFwiXCIsXHJcbiAgICBmYWxiYWNrTGFuZ3VhZ2U6IFwiaGVcIlxyXG59O1xubGV0IHNlcnZpY2VDb25maWcgPSB7XG4gICAgc2VydmljZUJhc2VVcmw6IFwiaHR0cDovL2xvY2FsaG9zdC9hbWF4d2ViL0FwaS5zdmMvXCIsXG4gICAgc2VydmljZUFwaVVybDogXCJodHRwOi8vbG9jYWxob3N0OjU3OTk4L0FQSS9cIixcbiAgICBhY2Nlc1Rva2VuU3RvcmVOYW1lOlwiWFRva2VuXCIsXG4gICAgYWNjZXNUb2tlblJlcXVlc3RIZWFkZXI6XCJYLVRva2VuXCIsXG4gICAgYWNjZXNUb2tlblJlc3BvbmNlSGVhZGVyOlwiWFRva2VuXCIsXG4gICAgXG5cbiAgICBhdXRoZW50aWNhdGlvbk1vZGU6XCJKV1QtVG9rZW5cIlxufVxuZXhwb3J0IHZhciBMb2NhbERpY3QgPSB7XHJcbiAgICB1c2VyQ3JlZGVudGlhbDogXCJ1c2VyQ3JlZGVudGlhbFwiLFxyXG4gICAgc2VsZWN0ZWRMYW5ndWFnZTogXCJwcmVmZXJlZExhbmd1YWdlXCIsXHJcbiAgICBsYW5ndWFnZVJlc291cmNlOiBcImxhbmd1YWdlUmVzb3VyY2VcIixcclxuICAgIFNtc1NldHRpbmdzOiBcInNtc1NldHRpbmdzXCJcclxufVxyXG5cclxuZXhwb3J0IHZhciBTZXNzaW9ubERpY3QgPSB7XHJcblxyXG59XHJcbmlmICh3aW5kb3cubG9jYXRpb24uaHJlZi5pbmRleE9mKFwiMTI3LjAuMC4xXCIpID4gLTEpXG5zZXJ2aWNlQ29uZmlnLnNlcnZpY2VCYXNlVXJsPVwiaHR0cDovL2xvY2FsaG9zdDo1Nzk5OC9BcGkuc3ZjL1wiO1xuZXhwb3J0IHtcbnNlcnZpY2VDb25maWcsXG5jcm1Db25maWdcbn0iXX0=
