System.register(['angular2/core', 'angular2/http', 'rxjs/add/operator/map', '../crmconfig'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, http_1, crmconfig_1;
    var AmaxService;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (http_1_1) {
                http_1 = http_1_1;
            },
            function (_1) {},
            function (crmconfig_1_1) {
                crmconfig_1 = crmconfig_1_1;
            }],
        execute: function() {
            AmaxService = (function () {
                function AmaxService(http) {
                    this.http = http;
                    this.baseUrl = crmconfig_1.serviceConfig.serviceApiUrl;
                }
                AmaxService.prototype.getHeader = function () {
                    //debugger;
                    var header = new http_1.Headers();
                    header.append("Content-Type", "application/json; charset=utf-8");
                    if (sessionStorage.getItem(crmconfig_1.serviceConfig.accesTokenStoreName)) {
                        header.append(crmconfig_1.serviceConfig.accesTokenRequestHeader, sessionStorage.getItem(crmconfig_1.serviceConfig.accesTokenStoreName));
                    }
                    else {
                        throw 'Access token not available';
                    }
                    return header;
                };
                AmaxService.prototype.validateLogin = function (UserID, Password, OrganizationName, rememberMe) {
                    //debugger;
                    var lang = "en";
                    var Language = localStorage.getItem("lang");
                    if (Language != "" && Language != null)
                        lang = Language;
                    var userInfo = {
                        OrgId: OrganizationName,
                        UserName: UserID,
                        Password: Password,
                        Language: lang
                    };
                    var header = new http_1.Headers();
                    header.append("Content-Type", "application/x-www-form-urlencoded");
                    // header.append("Data-Type", "json");
                    //header.append("Content-Type", "text/plain");
                    var jdata = jQuery.param(userInfo);
                    //debugger;
                    return this.http.post((this.baseUrl + "Service/Login"), //URL for the request
                    jdata, //Data for the request
                    { headers: header } //HEADERS for the request
                    ).map(function (res) { return res.text(); });
                };
                AmaxService.prototype.GetReport = function (ReportName, parameters) {
                    var header = new http_1.Headers();
                    header.append("Content-Type", "application/x-www-form-urlencoded");
                    var reportinfo = {
                        ReportName: ReportName,
                        Parameters: parameters
                    };
                    var jdata = jQuery.param(reportinfo);
                    return this.http.post(this.baseUrl + "Service/AmaxReportingService", jdata, { headers: header }).map(function (res) { return res.json().data; });
                };
                AmaxService.prototype.ExecuteJson = function (jsonQData) {
                    var header = new http_1.Headers();
                    header.append("Content-Type", "application/x-www-form-urlencoded");
                    var jdata = jQuery.param(jsonQData);
                    return this.http.post(this.baseUrl + "Service/ExecuteJson", jdata, { headers: header }).map(function (res) { return res.json().data; });
                };
                //Queryes
                AmaxService.prototype.GetDataFromServer = function (query) {
                    // debugger;
                    var params = JSON.stringify(query);
                    return this.http.post(this.baseUrl + "Service/DevQuery", params, { headers: this.getHeader() }).map(function (res) { return res.text(); });
                };
                AmaxService.prototype.GetGeneralGroupData = function () {
                    //debugger;
                    var GetGeneralGroupData = {
                        uqery: "SELECT GroupId, GroupName, GroupNameEng, GroupParenCategory FROM CustomerGroupsGeneral WHERE ( IsSupport = 0 and Ishide = 0 and SecurityLevel <= 10) ORDER BY GroupName",
                        parameters: {}
                    };
                    var jdata = JSON.stringify(GetGeneralGroupData);
                    return this.http.post(this.baseUrl + "Service/DevQuery", jdata, { headers: this.getHeader() }).map(function (res) { return res.json().data; });
                };
                AmaxService.prototype.GetGeneralGroupTree = function () {
                    //debugger;
                    var lang = localStorage.getItem("lang");
                    var req = '{"Lang":"' + lang + '"}';
                    return this.http.post(this.baseUrl + "Service/GetTreeData", req, { headers: this.getHeader() }).map(function (res) { return res.text(); });
                    //alert(rest);
                    //return rest.kendoTree;
                };
                //public SendSms(username: string, company: string, message: string, groups: Array<number>, phoneTypeId: number) {
                //    //debugger;
                //    var header = new Headers();
                //    header.append("Content-Type", "application/x-www-form-urlencoded");
                //    var smsdet = {
                //        username: username,
                //        company: company,
                //        message: message,
                //        groups: groups,
                //        phoneType: phoneTypeId
                //    }
                //    var jdata = JSON.stringify(smsdet);
                //    return this.http.post(
                //        this.baseUrl + "Service/SendSms",
                //        //jQuery.param({
                //        //    username: username,
                //        //    company: company,
                //        //    message: message,
                //        //    groups: groups,
                //        //    phoneType: phoneTypeId
                //        //}),
                //        jdata,
                //        { headers: this.getHeader()  }
                //    ).map(res=> res.text());
                //}
                AmaxService.prototype.SendSms = function (username, company, message, groups, phoneTypeId, providerId, returnBalanceAndCustomerCount, isConfirmed, SenderPhoneNumber, sendlater) {
                    if (isConfirmed === void 0) { isConfirmed = false; }
                    if (SenderPhoneNumber === void 0) { SenderPhoneNumber = ""; }
                    if (sendlater === void 0) { sendlater = ""; }
                    var IsBranchEnabled = localStorage.getItem("IsBranchEnabled");
                    var Branchid = localStorage.getItem("Branchid");
                    return this.http.post(this.baseUrl + "Service/SendSms", JSON.stringify({
                        username: username,
                        company: company,
                        message: message,
                        groups: groups,
                        phoneType: phoneTypeId,
                        providerId: providerId,
                        returnBalanceAndCustomerCount: returnBalanceAndCustomerCount,
                        isConfirmed: isConfirmed,
                        SenderPhoneNumber: SenderPhoneNumber,
                        sendlater: sendlater,
                        IsBranchEnabled: IsBranchEnabled,
                        Branchid: Branchid
                    }), { headers: this.getHeader() }).map(function (res) { return res.text(); });
                };
                AmaxService.prototype.ExecuteDataService = function (query, parameters) {
                    return this.http.post(this.baseUrl + "Service/ExecuteDataService", JSON.stringify({ query: query, parameters: parameters }), { headers: this.getHeader() }).map(function (res) { return res.text(); });
                };
                //Utility service
                AmaxService.prototype.CreateCatche = function () {
                    this.ExecuteDataService("InitalizeCRM", {}).subscribe(function (initialData) {
                        localStorage.setItem('SmsCompanyList', JSON.stringify(initialData["SmsCompanyList"]));
                        localStorage.setItem('CellPhoneTypeList', JSON.stringify(initialData["CellPhoneTypeList"]));
                        localStorage.setItem('PhoneTypeList', JSON.stringify(initialData["PhoneTypeList"]));
                        localStorage.setItem('GeneralGroupData', JSON.stringify(initialData["GeneralGroupData"]));
                    }, function (error) {
                        console.log(error);
                        localStorage.clear();
                        sessionStorage.clear();
                    }, function () { });
                };
                AmaxService = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [http_1.Http])
                ], AmaxService);
                return AmaxService;
            }());
            exports_1("AmaxService", AmaxService);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldi9zZXJ2aWNlcy9BbWF4U2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7WUFTQTtnQkFFSSxxQkFBb0IsSUFBVTtvQkFBVixTQUFJLEdBQUosSUFBSSxDQUFNO29CQUMxQixJQUFJLENBQUMsT0FBTyxHQUFHLHlCQUFhLENBQUMsYUFBYSxDQUFDO2dCQUMvQyxDQUFDO2dCQUVPLCtCQUFTLEdBQWpCO29CQUNJLFdBQVc7b0JBQ1gsSUFBSSxNQUFNLEdBQUcsSUFBSSxjQUFPLEVBQUUsQ0FBQztvQkFDM0IsTUFBTSxDQUFDLE1BQU0sQ0FBQyxjQUFjLEVBQUUsaUNBQWlDLENBQUMsQ0FBQztvQkFDakUsRUFBRSxDQUFDLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyx5QkFBYSxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUM1RCxNQUFNLENBQUMsTUFBTSxDQUFDLHlCQUFhLENBQUMsdUJBQXVCLEVBQUUsY0FBYyxDQUFDLE9BQU8sQ0FBQyx5QkFBYSxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQztvQkFDcEgsQ0FBQztvQkFBQyxJQUFJLENBQUMsQ0FBQzt3QkFDSixNQUFNLDRCQUE0QixDQUFDO29CQUN2QyxDQUFDO29CQUNELE1BQU0sQ0FBQyxNQUFNLENBQUM7Z0JBQ2xCLENBQUM7Z0JBRU0sbUNBQWEsR0FBcEIsVUFBcUIsTUFBYyxFQUFFLFFBQWdCLEVBQUUsZ0JBQXdCLEVBQUUsVUFBb0I7b0JBQ2pHLFdBQVc7b0JBQ1gsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDO29CQUNoQixJQUFJLFFBQVEsR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUM1QyxFQUFFLENBQUMsQ0FBQyxRQUFRLElBQUksRUFBRSxJQUFJLFFBQVEsSUFBSSxJQUFJLENBQUM7d0JBQ25DLElBQUksR0FBRyxRQUFRLENBQUM7b0JBQ3BCLElBQUksUUFBUSxHQUFHO3dCQUNYLEtBQUssRUFBRSxnQkFBZ0I7d0JBQ3ZCLFFBQVEsRUFBRSxNQUFNO3dCQUNoQixRQUFRLEVBQUUsUUFBUTt3QkFDbEIsUUFBUSxFQUFFLElBQUk7cUJBRWpCLENBQUE7b0JBQ0QsSUFBSSxNQUFNLEdBQUcsSUFBSSxjQUFPLEVBQUUsQ0FBQztvQkFDM0IsTUFBTSxDQUFDLE1BQU0sQ0FBQyxjQUFjLEVBQUUsbUNBQW1DLENBQUMsQ0FBQztvQkFDbkUsc0NBQXNDO29CQUN0Qyw4Q0FBOEM7b0JBRzlDLElBQUksS0FBSyxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUM7b0JBQ25DLFdBQVc7b0JBQ1gsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUNqQixDQUFDLElBQUksQ0FBQyxPQUFPLEdBQUcsZUFBZSxDQUFDLEVBQXNCLHFCQUFxQjtvQkFDM0UsS0FBSyxFQUFvQixzQkFBc0I7b0JBQy9DLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxDQUF5Qix5QkFBeUI7cUJBQ3hFLENBQUMsR0FBRyxDQUFDLFVBQUEsR0FBRyxJQUFJLE9BQUEsR0FBRyxDQUFDLElBQUksRUFBRSxFQUFWLENBQVUsQ0FBQyxDQUFDO2dCQUk3QixDQUFDO2dCQUVNLCtCQUFTLEdBQWhCLFVBQWlCLFVBQWtCLEVBQUUsVUFBa0I7b0JBQ25ELElBQUksTUFBTSxHQUFHLElBQUksY0FBTyxFQUFFLENBQUM7b0JBQzNCLE1BQU0sQ0FBQyxNQUFNLENBQUMsY0FBYyxFQUFFLG1DQUFtQyxDQUFDLENBQUM7b0JBQ25FLElBQUksVUFBVSxHQUFHO3dCQUNiLFVBQVUsRUFBRSxVQUFVO3dCQUN0QixVQUFVLEVBQUUsVUFBVTtxQkFDekIsQ0FBQTtvQkFDRCxJQUFJLEtBQUssR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDO29CQUNyQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQ2pCLElBQUksQ0FBQyxPQUFPLEdBQUcsOEJBQThCLEVBQzdDLEtBQUssRUFDTCxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsQ0FDdEIsQ0FBQyxHQUFHLENBQUMsVUFBQSxHQUFHLElBQUcsT0FBQSxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUMsSUFBSSxFQUFmLENBQWUsQ0FBQyxDQUFDO2dCQUNqQyxDQUFDO2dCQUVNLGlDQUFXLEdBQWxCLFVBQW1CLFNBQWM7b0JBQzdCLElBQUksTUFBTSxHQUFHLElBQUksY0FBTyxFQUFFLENBQUM7b0JBQzNCLE1BQU0sQ0FBQyxNQUFNLENBQUMsY0FBYyxFQUFFLG1DQUFtQyxDQUFDLENBQUM7b0JBQ25FLElBQUksS0FBSyxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUM7b0JBQ3BDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FDakIsSUFBSSxDQUFDLE9BQU8sR0FBRyxxQkFBcUIsRUFDcEMsS0FBSyxFQUNMLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxDQUN0QixDQUFDLEdBQUcsQ0FBQyxVQUFBLEdBQUcsSUFBRyxPQUFBLEdBQUcsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxJQUFJLEVBQWYsQ0FBZSxDQUFDLENBQUM7Z0JBQ2pDLENBQUM7Z0JBR0QsU0FBUztnQkFDRix1Q0FBaUIsR0FBeEIsVUFBeUIsS0FBSztvQkFDMUIsWUFBWTtvQkFFWixJQUFJLE1BQU0sR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUVuQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQ2pCLElBQUksQ0FBQyxPQUFPLEdBQUcsa0JBQWtCLEVBQ2pDLE1BQU0sRUFDTixFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsU0FBUyxFQUFFLEVBQUUsQ0FDaEMsQ0FBQyxHQUFHLENBQUMsVUFBQSxHQUFHLElBQUcsT0FBQSxHQUFHLENBQUMsSUFBSSxFQUFFLEVBQVYsQ0FBVSxDQUFDLENBQUM7Z0JBQzVCLENBQUM7Z0JBRU0seUNBQW1CLEdBQTFCO29CQUNJLFdBQVc7b0JBQ1gsSUFBSSxtQkFBbUIsR0FBRzt3QkFDdEIsS0FBSyxFQUFFLHlLQUF5Szt3QkFDaEwsVUFBVSxFQUFFLEVBQUU7cUJBQ2pCLENBQUE7b0JBQ0QsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO29CQUNoRCxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQ2pCLElBQUksQ0FBQyxPQUFPLEdBQUcsa0JBQWtCLEVBQ2pDLEtBQUssRUFDTCxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsU0FBUyxFQUFFLEVBQUUsQ0FDaEMsQ0FBQyxHQUFHLENBQUMsVUFBQSxHQUFHLElBQUcsT0FBQSxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUMsSUFBSSxFQUFmLENBQWUsQ0FBQyxDQUFDO2dCQUNqQyxDQUFDO2dCQUVNLHlDQUFtQixHQUExQjtvQkFDSSxXQUFXO29CQUNYLElBQUksSUFBSSxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQ3hDLElBQUksR0FBRyxHQUFHLFdBQVcsR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUFDO29CQUVwQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQ2pCLElBQUksQ0FBQyxPQUFPLEdBQUcscUJBQXFCLEVBQ3BDLEdBQUcsRUFDSCxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsU0FBUyxFQUFFLEVBQUUsQ0FDaEMsQ0FBQyxHQUFHLENBQUMsVUFBQSxHQUFHLElBQUcsT0FBQSxHQUFHLENBQUMsSUFBSSxFQUFFLEVBQVYsQ0FBVSxDQUFDLENBQUM7b0JBQ3hCLGNBQWM7b0JBQ2Qsd0JBQXdCO2dCQUM1QixDQUFDO2dCQUVELGtIQUFrSDtnQkFDbEgsaUJBQWlCO2dCQUNqQixpQ0FBaUM7Z0JBQ2pDLHlFQUF5RTtnQkFDekUsb0JBQW9CO2dCQUNwQiw2QkFBNkI7Z0JBQzdCLDJCQUEyQjtnQkFDM0IsMkJBQTJCO2dCQUMzQix5QkFBeUI7Z0JBQ3pCLGdDQUFnQztnQkFDaEMsT0FBTztnQkFDUCx5Q0FBeUM7Z0JBQ3pDLDRCQUE0QjtnQkFDNUIsMkNBQTJDO2dCQUMzQywwQkFBMEI7Z0JBQzFCLG1DQUFtQztnQkFDbkMsaUNBQWlDO2dCQUNqQyxpQ0FBaUM7Z0JBQ2pDLCtCQUErQjtnQkFDL0Isc0NBQXNDO2dCQUN0QyxlQUFlO2dCQUNmLGdCQUFnQjtnQkFDaEIsd0NBQXdDO2dCQUN4Qyw4QkFBOEI7Z0JBQzlCLEdBQUc7Z0JBRUksNkJBQU8sR0FBZCxVQUFlLFFBQWdCLEVBQUUsT0FBZSxFQUFFLE9BQWUsRUFBRSxNQUFxQixFQUFFLFdBQW1CLEVBQUUsVUFBa0IsRUFBRSw2QkFBc0MsRUFBRSxXQUE2QixFQUFFLGlCQUE4QixFQUFFLFNBQXNCO29CQUFyRiwyQkFBNkIsR0FBN0IsbUJBQTZCO29CQUFFLGlDQUE4QixHQUE5QixzQkFBOEI7b0JBQUUseUJBQXNCLEdBQXRCLGNBQXNCO29CQUM1UCxJQUFJLGVBQWUsR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLGlCQUFpQixDQUFDLENBQUM7b0JBQzlELElBQUksUUFBUSxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7b0JBQ2hELE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FDakIsSUFBSSxDQUFDLE9BQU8sR0FBRyxpQkFBaUIsRUFDaEMsSUFBSSxDQUFDLFNBQVMsQ0FBQzt3QkFDWCxRQUFRLEVBQUUsUUFBUTt3QkFDbEIsT0FBTyxFQUFFLE9BQU87d0JBQ2hCLE9BQU8sRUFBRSxPQUFPO3dCQUNoQixNQUFNLEVBQUUsTUFBTTt3QkFDZCxTQUFTLEVBQUUsV0FBVzt3QkFDdEIsVUFBVSxFQUFFLFVBQVU7d0JBQ3RCLDZCQUE2QixFQUFFLDZCQUE2Qjt3QkFDNUQsV0FBVyxFQUFFLFdBQVc7d0JBQ3hCLGlCQUFpQixFQUFFLGlCQUFpQjt3QkFDcEMsU0FBUyxFQUFFLFNBQVM7d0JBQ3BCLGVBQWUsRUFBRSxlQUFlO3dCQUNoQyxRQUFRLEVBQUUsUUFBUTtxQkFDckIsQ0FBQyxFQUNGLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxTQUFTLEVBQUUsRUFBRSxDQUNoQyxDQUFDLEdBQUcsQ0FBQyxVQUFBLEdBQUcsSUFBRyxPQUFBLEdBQUcsQ0FBQyxJQUFJLEVBQUUsRUFBVixDQUFVLENBQUMsQ0FBQztnQkFDNUIsQ0FBQztnQkFFTSx3Q0FBa0IsR0FBekIsVUFBMEIsS0FBYSxFQUFFLFVBQWU7b0JBQ3BELE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FDakIsSUFBSSxDQUFDLE9BQU8sR0FBRyw0QkFBNEIsRUFDM0MsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsVUFBVSxFQUFFLFVBQVUsRUFBRSxDQUFDLEVBQ3hELEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxTQUFTLEVBQUUsRUFBRSxDQUNoQyxDQUFDLEdBQUcsQ0FBQyxVQUFBLEdBQUcsSUFBRyxPQUFBLEdBQUcsQ0FBQyxJQUFJLEVBQUUsRUFBVixDQUFVLENBQUMsQ0FBQztnQkFDNUIsQ0FBQztnQkFFRCxpQkFBaUI7Z0JBQ1Ysa0NBQVksR0FBbkI7b0JBQ0ksSUFBSSxDQUFDLGtCQUFrQixDQUFDLGNBQWMsRUFBRSxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQ2pELFVBQUEsV0FBVzt3QkFDUCxZQUFZLENBQUMsT0FBTyxDQUFDLGdCQUFnQixFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUN0RixZQUFZLENBQUMsT0FBTyxDQUFDLG1CQUFtQixFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUM1RixZQUFZLENBQUMsT0FBTyxDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ3BGLFlBQVksQ0FBQyxPQUFPLENBQUMsa0JBQWtCLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQzlGLENBQUMsRUFDRCxVQUFBLEtBQUs7d0JBQ0QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQzt3QkFDbkIsWUFBWSxDQUFDLEtBQUssRUFBRSxDQUFDO3dCQUNyQixjQUFjLENBQUMsS0FBSyxFQUFFLENBQUM7b0JBQzNCLENBQUMsRUFDRCxjQUFRLENBQUMsQ0FBQyxDQUFDO2dCQUNuQixDQUFDO2dCQTlMTDtvQkFBQyxpQkFBVSxFQUFFOzsrQkFBQTtnQkFpTWIsa0JBQUM7WUFBRCxDQWhNQSxBQWdNQyxJQUFBO1lBaE1ELHFDQWdNQyxDQUFBIiwiZmlsZSI6ImRldi9zZXJ2aWNlcy9BbWF4U2VydmljZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdhbmd1bGFyMi9jb3JlJztcbmltcG9ydCB7IEh0dHAsIEhlYWRlcnMgIH0gZnJvbSAnYW5ndWxhcjIvaHR0cCc7XG5pbXBvcnQgJ3J4anMvYWRkL29wZXJhdG9yL21hcCc7XG5pbXBvcnQge09ic2VydmFibGV9IGZyb20gXCJyeGpzL09ic2VydmFibGVcIjtcbmltcG9ydCB7c2VydmljZUNvbmZpZ30gZnJvbSAnLi4vY3JtY29uZmlnJztcblxuXG5kZWNsYXJlIHZhciBqUXVlcnk7XG5ASW5qZWN0YWJsZSgpXG5leHBvcnQgY2xhc3MgQW1heFNlcnZpY2Uge1xuICAgIGJhc2VVcmw6IHN0cmluZztcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIGh0dHA6IEh0dHApIHtcbiAgICAgICAgdGhpcy5iYXNlVXJsID0gc2VydmljZUNvbmZpZy5zZXJ2aWNlQXBpVXJsO1xuICAgIH1cblxuICAgIHByaXZhdGUgZ2V0SGVhZGVyKCk6IEhlYWRlcnMge1xuICAgICAgICAvL2RlYnVnZ2VyO1xuICAgICAgICB2YXIgaGVhZGVyID0gbmV3IEhlYWRlcnMoKTtcbiAgICAgICAgaGVhZGVyLmFwcGVuZChcIkNvbnRlbnQtVHlwZVwiLCBcImFwcGxpY2F0aW9uL2pzb247IGNoYXJzZXQ9dXRmLThcIik7XG4gICAgICAgIGlmIChzZXNzaW9uU3RvcmFnZS5nZXRJdGVtKHNlcnZpY2VDb25maWcuYWNjZXNUb2tlblN0b3JlTmFtZSkpIHtcbiAgICAgICAgICAgIGhlYWRlci5hcHBlbmQoc2VydmljZUNvbmZpZy5hY2Nlc1Rva2VuUmVxdWVzdEhlYWRlciwgc2Vzc2lvblN0b3JhZ2UuZ2V0SXRlbShzZXJ2aWNlQ29uZmlnLmFjY2VzVG9rZW5TdG9yZU5hbWUpKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRocm93ICdBY2Nlc3MgdG9rZW4gbm90IGF2YWlsYWJsZSc7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGhlYWRlcjtcbiAgICB9XG5cbiAgICBwdWJsaWMgdmFsaWRhdGVMb2dpbihVc2VySUQ6IHN0cmluZywgUGFzc3dvcmQ6IHN0cmluZywgT3JnYW5pemF0aW9uTmFtZTogc3RyaW5nLCByZW1lbWJlck1lPzogYm9vbGVhbikge1xuICAgICAgICAvL2RlYnVnZ2VyO1xuICAgICAgICB2YXIgbGFuZyA9IFwiZW5cIjtcbiAgICAgICAgdmFyIExhbmd1YWdlID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJsYW5nXCIpO1xuICAgICAgICBpZiAoTGFuZ3VhZ2UgIT0gXCJcIiAmJiBMYW5ndWFnZSAhPSBudWxsKVxuICAgICAgICAgICAgbGFuZyA9IExhbmd1YWdlO1xuICAgICAgICB2YXIgdXNlckluZm8gPSB7XG4gICAgICAgICAgICBPcmdJZDogT3JnYW5pemF0aW9uTmFtZSxcbiAgICAgICAgICAgIFVzZXJOYW1lOiBVc2VySUQsXG4gICAgICAgICAgICBQYXNzd29yZDogUGFzc3dvcmQsXG4gICAgICAgICAgICBMYW5ndWFnZTogbGFuZ1xuXG4gICAgICAgIH1cbiAgICAgICAgdmFyIGhlYWRlciA9IG5ldyBIZWFkZXJzKCk7XG4gICAgICAgIGhlYWRlci5hcHBlbmQoXCJDb250ZW50LVR5cGVcIiwgXCJhcHBsaWNhdGlvbi94LXd3dy1mb3JtLXVybGVuY29kZWRcIik7XHJcbiAgICAgICAgLy8gaGVhZGVyLmFwcGVuZChcIkRhdGEtVHlwZVwiLCBcImpzb25cIik7XHJcbiAgICAgICAgLy9oZWFkZXIuYXBwZW5kKFwiQ29udGVudC1UeXBlXCIsIFwidGV4dC9wbGFpblwiKTtcbiAgICAgICAgXG5cbiAgICAgICAgdmFyIGpkYXRhID0galF1ZXJ5LnBhcmFtKHVzZXJJbmZvKTtcbiAgICAgICAgLy9kZWJ1Z2dlcjtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0KFxuICAgICAgICAgICAgKHRoaXMuYmFzZVVybCArIFwiU2VydmljZS9Mb2dpblwiKSwgICAgICAgICAgICAgICAgICAgICAvL1VSTCBmb3IgdGhlIHJlcXVlc3RcbiAgICAgICAgICAgIGpkYXRhLCAgICAgICAgICAgICAgICAgICAvL0RhdGEgZm9yIHRoZSByZXF1ZXN0XG4gICAgICAgICAgICB7IGhlYWRlcnM6IGhlYWRlciB9ICAgICAgICAgICAgICAgICAgICAgICAgIC8vSEVBREVSUyBmb3IgdGhlIHJlcXVlc3RcbiAgICAgICAgKS5tYXAocmVzID0+IHJlcy50ZXh0KCkpO1xuXG5cblxuICAgIH1cblxuICAgIHB1YmxpYyBHZXRSZXBvcnQoUmVwb3J0TmFtZTogc3RyaW5nLCBwYXJhbWV0ZXJzOiBPYmplY3QpOiBPYnNlcnZhYmxlIHtcbiAgICAgICAgdmFyIGhlYWRlciA9IG5ldyBIZWFkZXJzKCk7XG4gICAgICAgIGhlYWRlci5hcHBlbmQoXCJDb250ZW50LVR5cGVcIiwgXCJhcHBsaWNhdGlvbi94LXd3dy1mb3JtLXVybGVuY29kZWRcIik7XG4gICAgICAgIHZhciByZXBvcnRpbmZvID0ge1xuICAgICAgICAgICAgUmVwb3J0TmFtZTogUmVwb3J0TmFtZSxcbiAgICAgICAgICAgIFBhcmFtZXRlcnM6IHBhcmFtZXRlcnNcbiAgICAgICAgfVxuICAgICAgICB2YXIgamRhdGEgPSBqUXVlcnkucGFyYW0ocmVwb3J0aW5mbyk7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdChcbiAgICAgICAgICAgIHRoaXMuYmFzZVVybCArIFwiU2VydmljZS9BbWF4UmVwb3J0aW5nU2VydmljZVwiLFxuICAgICAgICAgICAgamRhdGEsXG4gICAgICAgICAgICB7IGhlYWRlcnM6IGhlYWRlciB9XG4gICAgICAgICkubWFwKHJlcz0+IHJlcy5qc29uKCkuZGF0YSk7XG4gICAgfVxuXG4gICAgcHVibGljIEV4ZWN1dGVKc29uKGpzb25RRGF0YTogYW55KTogT2JzZXJ2YWJsZSB7XG4gICAgICAgIHZhciBoZWFkZXIgPSBuZXcgSGVhZGVycygpO1xuICAgICAgICBoZWFkZXIuYXBwZW5kKFwiQ29udGVudC1UeXBlXCIsIFwiYXBwbGljYXRpb24veC13d3ctZm9ybS11cmxlbmNvZGVkXCIpO1xuICAgICAgICB2YXIgamRhdGEgPSBqUXVlcnkucGFyYW0oanNvblFEYXRhKTtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0KFxuICAgICAgICAgICAgdGhpcy5iYXNlVXJsICsgXCJTZXJ2aWNlL0V4ZWN1dGVKc29uXCIsXG4gICAgICAgICAgICBqZGF0YSxcbiAgICAgICAgICAgIHsgaGVhZGVyczogaGVhZGVyIH1cbiAgICAgICAgKS5tYXAocmVzPT4gcmVzLmpzb24oKS5kYXRhKTtcbiAgICB9XG5cblxuICAgIC8vUXVlcnllc1xuICAgIHB1YmxpYyBHZXREYXRhRnJvbVNlcnZlcihxdWVyeSk6IE9ic2VydmFibGUge1xuICAgICAgICAvLyBkZWJ1Z2dlcjtcbiAgICAgICAgXG4gICAgICAgIHZhciBwYXJhbXMgPSBKU09OLnN0cmluZ2lmeShxdWVyeSk7XG4gICAgICAgIFxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3QoXG4gICAgICAgICAgICB0aGlzLmJhc2VVcmwgKyBcIlNlcnZpY2UvRGV2UXVlcnlcIixcbiAgICAgICAgICAgIHBhcmFtcyxcbiAgICAgICAgICAgIHsgaGVhZGVyczogdGhpcy5nZXRIZWFkZXIoKSB9XG4gICAgICAgICkubWFwKHJlcz0+IHJlcy50ZXh0KCkpO1xuICAgIH1cblxuICAgIHB1YmxpYyBHZXRHZW5lcmFsR3JvdXBEYXRhKCk6IE9ic2VydmFibGUge1xuICAgICAgICAvL2RlYnVnZ2VyO1xuICAgICAgICB2YXIgR2V0R2VuZXJhbEdyb3VwRGF0YSA9IHtcbiAgICAgICAgICAgIHVxZXJ5OiBcIlNFTEVDVCBHcm91cElkLCBHcm91cE5hbWUsIEdyb3VwTmFtZUVuZywgR3JvdXBQYXJlbkNhdGVnb3J5IEZST00gQ3VzdG9tZXJHcm91cHNHZW5lcmFsIFdIRVJFICggSXNTdXBwb3J0ID0gMCBhbmQgSXNoaWRlID0gMCBhbmQgU2VjdXJpdHlMZXZlbCA8PSAxMCkgT1JERVIgQlkgR3JvdXBOYW1lXCIsXG4gICAgICAgICAgICBwYXJhbWV0ZXJzOiB7fVxuICAgICAgICB9XG4gICAgICAgIHZhciBqZGF0YSA9IEpTT04uc3RyaW5naWZ5KEdldEdlbmVyYWxHcm91cERhdGEpO1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3QoXG4gICAgICAgICAgICB0aGlzLmJhc2VVcmwgKyBcIlNlcnZpY2UvRGV2UXVlcnlcIixcbiAgICAgICAgICAgIGpkYXRhLFxuICAgICAgICAgICAgeyBoZWFkZXJzOiB0aGlzLmdldEhlYWRlcigpIH1cbiAgICAgICAgKS5tYXAocmVzPT4gcmVzLmpzb24oKS5kYXRhKTtcbiAgICB9XG5cbiAgICBwdWJsaWMgR2V0R2VuZXJhbEdyb3VwVHJlZSgpOiBPYnNlcnZhYmxlIHtcbiAgICAgICAgLy9kZWJ1Z2dlcjtcbiAgICAgICAgdmFyIGxhbmcgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImxhbmdcIik7XG4gICAgICAgIHZhciByZXEgPSAne1wiTGFuZ1wiOlwiJyArIGxhbmcgKyAnXCJ9JztcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3QoXG4gICAgICAgICAgICB0aGlzLmJhc2VVcmwgKyBcIlNlcnZpY2UvR2V0VHJlZURhdGFcIixcbiAgICAgICAgICAgIHJlcSxcbiAgICAgICAgICAgIHsgaGVhZGVyczogdGhpcy5nZXRIZWFkZXIoKSB9XG4gICAgICAgICkubWFwKHJlcz0+IHJlcy50ZXh0KCkpO1xuICAgICAgICAvL2FsZXJ0KHJlc3QpO1xuICAgICAgICAvL3JldHVybiByZXN0LmtlbmRvVHJlZTtcbiAgICB9XG5cbiAgICAvL3B1YmxpYyBTZW5kU21zKHVzZXJuYW1lOiBzdHJpbmcsIGNvbXBhbnk6IHN0cmluZywgbWVzc2FnZTogc3RyaW5nLCBncm91cHM6IEFycmF5PG51bWJlcj4sIHBob25lVHlwZUlkOiBudW1iZXIpIHtcbiAgICAvLyAgICAvL2RlYnVnZ2VyO1xuICAgIC8vICAgIHZhciBoZWFkZXIgPSBuZXcgSGVhZGVycygpO1xuICAgIC8vICAgIGhlYWRlci5hcHBlbmQoXCJDb250ZW50LVR5cGVcIiwgXCJhcHBsaWNhdGlvbi94LXd3dy1mb3JtLXVybGVuY29kZWRcIik7XG4gICAgLy8gICAgdmFyIHNtc2RldCA9IHtcbiAgICAvLyAgICAgICAgdXNlcm5hbWU6IHVzZXJuYW1lLFxuICAgIC8vICAgICAgICBjb21wYW55OiBjb21wYW55LFxuICAgIC8vICAgICAgICBtZXNzYWdlOiBtZXNzYWdlLFxuICAgIC8vICAgICAgICBncm91cHM6IGdyb3VwcyxcbiAgICAvLyAgICAgICAgcGhvbmVUeXBlOiBwaG9uZVR5cGVJZFxuICAgIC8vICAgIH1cbiAgICAvLyAgICB2YXIgamRhdGEgPSBKU09OLnN0cmluZ2lmeShzbXNkZXQpO1xuICAgIC8vICAgIHJldHVybiB0aGlzLmh0dHAucG9zdChcbiAgICAvLyAgICAgICAgdGhpcy5iYXNlVXJsICsgXCJTZXJ2aWNlL1NlbmRTbXNcIixcbiAgICAvLyAgICAgICAgLy9qUXVlcnkucGFyYW0oe1xuICAgIC8vICAgICAgICAvLyAgICB1c2VybmFtZTogdXNlcm5hbWUsXG4gICAgLy8gICAgICAgIC8vICAgIGNvbXBhbnk6IGNvbXBhbnksXG4gICAgLy8gICAgICAgIC8vICAgIG1lc3NhZ2U6IG1lc3NhZ2UsXG4gICAgLy8gICAgICAgIC8vICAgIGdyb3VwczogZ3JvdXBzLFxuICAgIC8vICAgICAgICAvLyAgICBwaG9uZVR5cGU6IHBob25lVHlwZUlkXG4gICAgLy8gICAgICAgIC8vfSksXG4gICAgLy8gICAgICAgIGpkYXRhLFxuICAgIC8vICAgICAgICB7IGhlYWRlcnM6IHRoaXMuZ2V0SGVhZGVyKCkgIH1cbiAgICAvLyAgICApLm1hcChyZXM9PiByZXMudGV4dCgpKTtcbiAgICAvL31cblxuICAgIHB1YmxpYyBTZW5kU21zKHVzZXJuYW1lOiBzdHJpbmcsIGNvbXBhbnk6IHN0cmluZywgbWVzc2FnZTogc3RyaW5nLCBncm91cHM6IEFycmF5PG51bWJlcj4sIHBob25lVHlwZUlkOiBudW1iZXIsIHByb3ZpZGVySWQ6IG51bWJlciwgcmV0dXJuQmFsYW5jZUFuZEN1c3RvbWVyQ291bnQ6IGJvb2xlYW4sIGlzQ29uZmlybWVkPzogYm9vbGVhbiA9IGZhbHNlLCBTZW5kZXJQaG9uZU51bWJlcjogc3RyaW5nID0gXCJcIiwgc2VuZGxhdGVyOiBzdHJpbmcgPSBcIlwiKSB7XHJcbiAgICAgICAgdmFyIElzQnJhbmNoRW5hYmxlZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiSXNCcmFuY2hFbmFibGVkXCIpO1xyXG4gICAgICAgIHZhciBCcmFuY2hpZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiQnJhbmNoaWRcIik7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0KFxyXG4gICAgICAgICAgICB0aGlzLmJhc2VVcmwgKyBcIlNlcnZpY2UvU2VuZFNtc1wiLFxyXG4gICAgICAgICAgICBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgICAgICAgICB1c2VybmFtZTogdXNlcm5hbWUsXHJcbiAgICAgICAgICAgICAgICBjb21wYW55OiBjb21wYW55LFxyXG4gICAgICAgICAgICAgICAgbWVzc2FnZTogbWVzc2FnZSxcclxuICAgICAgICAgICAgICAgIGdyb3VwczogZ3JvdXBzLFxyXG4gICAgICAgICAgICAgICAgcGhvbmVUeXBlOiBwaG9uZVR5cGVJZCxcclxuICAgICAgICAgICAgICAgIHByb3ZpZGVySWQ6IHByb3ZpZGVySWQsXHJcbiAgICAgICAgICAgICAgICByZXR1cm5CYWxhbmNlQW5kQ3VzdG9tZXJDb3VudDogcmV0dXJuQmFsYW5jZUFuZEN1c3RvbWVyQ291bnQsXHJcbiAgICAgICAgICAgICAgICBpc0NvbmZpcm1lZDogaXNDb25maXJtZWQsXHJcbiAgICAgICAgICAgICAgICBTZW5kZXJQaG9uZU51bWJlcjogU2VuZGVyUGhvbmVOdW1iZXIsXHJcbiAgICAgICAgICAgICAgICBzZW5kbGF0ZXI6IHNlbmRsYXRlcixcclxuICAgICAgICAgICAgICAgIElzQnJhbmNoRW5hYmxlZDogSXNCcmFuY2hFbmFibGVkLFxyXG4gICAgICAgICAgICAgICAgQnJhbmNoaWQ6IEJyYW5jaGlkXHJcbiAgICAgICAgICAgIH0pLFxyXG4gICAgICAgICAgICB7IGhlYWRlcnM6IHRoaXMuZ2V0SGVhZGVyKCkgfVxyXG4gICAgICAgICkubWFwKHJlcz0+IHJlcy50ZXh0KCkpO1xyXG4gICAgfVxuXG4gICAgcHVibGljIEV4ZWN1dGVEYXRhU2VydmljZShxdWVyeTogc3RyaW5nLCBwYXJhbWV0ZXJzOiBhbnkpIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3QoXHJcbiAgICAgICAgICAgIHRoaXMuYmFzZVVybCArIFwiU2VydmljZS9FeGVjdXRlRGF0YVNlcnZpY2VcIixcclxuICAgICAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBxdWVyeTogcXVlcnksIHBhcmFtZXRlcnM6IHBhcmFtZXRlcnMgfSksXHJcbiAgICAgICAgICAgIHsgaGVhZGVyczogdGhpcy5nZXRIZWFkZXIoKSB9XHJcbiAgICAgICAgKS5tYXAocmVzPT4gcmVzLnRleHQoKSk7XHJcbiAgICB9XG5cbiAgICAvL1V0aWxpdHkgc2VydmljZVxyXG4gICAgcHVibGljIENyZWF0ZUNhdGNoZSgpIHtcclxuICAgICAgICB0aGlzLkV4ZWN1dGVEYXRhU2VydmljZShcIkluaXRhbGl6ZUNSTVwiLCB7fSkuc3Vic2NyaWJlKFxyXG4gICAgICAgICAgICBpbml0aWFsRGF0YT0+IHtcclxuICAgICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCdTbXNDb21wYW55TGlzdCcsIEpTT04uc3RyaW5naWZ5KGluaXRpYWxEYXRhW1wiU21zQ29tcGFueUxpc3RcIl0pKTtcclxuICAgICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCdDZWxsUGhvbmVUeXBlTGlzdCcsIEpTT04uc3RyaW5naWZ5KGluaXRpYWxEYXRhW1wiQ2VsbFBob25lVHlwZUxpc3RcIl0pKTtcclxuICAgICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCdQaG9uZVR5cGVMaXN0JywgSlNPTi5zdHJpbmdpZnkoaW5pdGlhbERhdGFbXCJQaG9uZVR5cGVMaXN0XCJdKSk7XHJcbiAgICAgICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnR2VuZXJhbEdyb3VwRGF0YScsIEpTT04uc3RyaW5naWZ5KGluaXRpYWxEYXRhW1wiR2VuZXJhbEdyb3VwRGF0YVwiXSkpO1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBlcnJvcj0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5jbGVhcigpO1xyXG4gICAgICAgICAgICAgICAgc2Vzc2lvblN0b3JhZ2UuY2xlYXIoKTtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgKCkgPT4geyB9KTtcclxuICAgIH1cblxuXG59Il19
