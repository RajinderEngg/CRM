System.register(['angular2/core', 'angular2/http', 'rxjs/add/operator/map', '../crmconfig'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, http_1, crmconfig_1;
    var ChargeCreditService;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (http_1_1) {
                http_1 = http_1_1;
            },
            function (_1) {},
            function (crmconfig_1_1) {
                crmconfig_1 = crmconfig_1_1;
            }],
        execute: function() {
            ChargeCreditService = (function () {
                function ChargeCreditService(http) {
                    this.http = http;
                    this.baseUrl = crmconfig_1.serviceConfig.serviceApiUrl;
                }
                ChargeCreditService.prototype.getHeader = function () {
                    var header = new http_1.Headers();
                    header.append("Content-Type", "application/json");
                    if (sessionStorage.getItem(crmconfig_1.serviceConfig.accesTokenStoreName)) {
                        header.append(crmconfig_1.serviceConfig.accesTokenRequestHeader, sessionStorage.getItem(crmconfig_1.serviceConfig.accesTokenStoreName));
                    }
                    else {
                        throw 'Access token not available';
                    }
                    return header;
                };
                ChargeCreditService.prototype.Save = function (SaveObject) {
                    return this.http.post(this.baseUrl + "CheargeCredit/GetChargeAshrait", //URL for the request
                    SaveObject, { headers: this.getHeader() } //{ headers: header }
                    ).map(function (res) { return res.text(); });
                };
                ChargeCreditService.prototype.BindTermDet = function (TermNo) {
                    return this.http.get(this.baseUrl + "CheargeCredit/GetTerminalDetByTermNo?TerminalNo=" + TermNo, { headers: this.getHeader() }).map(function (res) { return res.text(); });
                };
                ChargeCreditService.prototype.BindCurrencyList = function () {
                    return this.http.get(this.baseUrl + "Dropdown/BindCurrencyList", { headers: this.getHeader() }).map(function (res) { return res.text(); });
                };
                ChargeCreditService.prototype.BindCreditTypeList = function () {
                    return this.http.get(this.baseUrl + "Dropdown/BindCreditTypeList", { headers: this.getHeader() }).map(function (res) { return res.text(); });
                };
                ChargeCreditService.prototype.BindChargeTypeList = function () {
                    return this.http.get(this.baseUrl + "Dropdown/BindChargeTypeList", { headers: this.getHeader() }).map(function (res) { return res.text(); });
                };
                ChargeCreditService.prototype.BindYears = function () {
                    return this.http.get(this.baseUrl + "Dropdown/BindYears", { headers: this.getHeader() }).map(function (res) { return res.text(); });
                };
                ChargeCreditService.prototype.BindMonths = function () {
                    return this.http.get(this.baseUrl + "Dropdown/BindMonths", { headers: this.getHeader() }).map(function (res) { return res.text(); });
                };
                ChargeCreditService.prototype.GetWebServiceResponce = function (Url) {
                    return this.http.get(this.baseUrl + "CheargeCredit/GetWebServiceResponce?Url=" + url, { headers: this.getHeader() }).map(function (res) { return res.text(); });
                };
                ChargeCreditService.prototype.IsInsertTotblLastUpdate = function (CustomerId) {
                    return this.http.get(this.baseUrl + "CheargeCredit/IsInsertTotblLastUpdate?CustomerId=" + CustomerId, { headers: this.getHeader() }).map(function (res) { return res.text(); });
                };
                ChargeCreditService.prototype.InsertTotblLastUpdate = function (CustomerId, SumtoBill) {
                    return this.http.get(this.baseUrl + "CheargeCredit/InsertTotblLastUpdate?CustomerId=" + CustomerId + "&SumtoBill=" + SumtoBill, { headers: this.getHeader() }).map(function (res) { return res.text(); });
                };
                ChargeCreditService.prototype.UpdateOwnerId = function (CustomerId, OwnerId) {
                    return this.http.get(this.baseUrl + "CheargeCredit/UpdateOwnerId?CustomerId=" + CustomerId + "&OwnerId=" + OwnerId, { headers: this.getHeader() }).map(function (res) { return res.text(); });
                };
                ChargeCreditService.prototype.getPrint = function (DealNumber, TermNo) {
                    return this.http.get(this.baseUrl + "CheargeCredit/getPrint?DealNumber=" + DealNumber + "&TerminalNo=" + TermNo, { headers: this.getHeader() }).map(function (res) { return res.text(); });
                };
                ChargeCreditService = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [http_1.Http])
                ], ChargeCreditService);
                return ChargeCreditService;
            }());
            exports_1("ChargeCreditService", ChargeCreditService);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldi9zZXJ2aWNlcy9DaGFyZ2VDcmVkaXRTZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztZQU9BO2dCQUVJLDZCQUFvQixJQUFVO29CQUFWLFNBQUksR0FBSixJQUFJLENBQU07b0JBQzFCLElBQUksQ0FBQyxPQUFPLEdBQUcseUJBQWEsQ0FBQyxhQUFhLENBQUM7Z0JBQy9DLENBQUM7Z0JBRU8sdUNBQVMsR0FBakI7b0JBQ0ksSUFBSSxNQUFNLEdBQUcsSUFBSSxjQUFPLEVBQUUsQ0FBQztvQkFDM0IsTUFBTSxDQUFDLE1BQU0sQ0FBQyxjQUFjLEVBQUUsa0JBQWtCLENBQUMsQ0FBQztvQkFDbEQsRUFBRSxDQUFBLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyx5QkFBYSxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQSxDQUFDO3dCQUMxRCxNQUFNLENBQUMsTUFBTSxDQUFDLHlCQUFhLENBQUMsdUJBQXVCLEVBQUUsY0FBYyxDQUFDLE9BQU8sQ0FBQyx5QkFBYSxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQztvQkFDcEgsQ0FBQztvQkFBQSxJQUFJLENBQUMsQ0FBQzt3QkFDSCxNQUFNLDRCQUE0QixDQUFDO29CQUN2QyxDQUFDO29CQUNELE1BQU0sQ0FBQyxNQUFNLENBQUM7Z0JBQ2xCLENBQUM7Z0JBSU0sa0NBQUksR0FBWCxVQUFZLFVBQWtCO29CQUMxQixNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQ2pCLElBQUksQ0FBQyxPQUFPLEdBQUcsZ0NBQWdDLEVBQW9CLHFCQUFxQjtvQkFDeEYsVUFBVSxFQUNWLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxTQUFTLEVBQUUsRUFBRSxDQUFnQyxxQkFBcUI7cUJBRXJGLENBQUMsR0FBRyxDQUFDLFVBQUEsR0FBRyxJQUFJLE9BQUEsR0FBRyxDQUFDLElBQUksRUFBRSxFQUFWLENBQVUsQ0FBQyxDQUFDO2dCQUM3QixDQUFDO2dCQU1NLHlDQUFXLEdBQWxCLFVBQW1CLE1BQWM7b0JBQzdCLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FDaEIsSUFBSSxDQUFDLE9BQU8sR0FBRyxrREFBa0QsR0FBRyxNQUFNLEVBQzFFLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxTQUFTLEVBQUUsRUFBRSxDQUNoQyxDQUFDLEdBQUcsQ0FBQyxVQUFBLEdBQUcsSUFBRyxPQUFBLEdBQUcsQ0FBQyxJQUFJLEVBQUUsRUFBVixDQUFVLENBQUMsQ0FBQztnQkFDNUIsQ0FBQztnQkFFTSw4Q0FBZ0IsR0FBdkI7b0JBQ0ksTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUNoQixJQUFJLENBQUMsT0FBTyxHQUFHLDJCQUEyQixFQUMxQyxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsU0FBUyxFQUFFLEVBQUUsQ0FDaEMsQ0FBQyxHQUFHLENBQUMsVUFBQSxHQUFHLElBQUcsT0FBQSxHQUFHLENBQUMsSUFBSSxFQUFFLEVBQVYsQ0FBVSxDQUFDLENBQUM7Z0JBQzVCLENBQUM7Z0JBRU0sZ0RBQWtCLEdBQXpCO29CQUNJLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FDaEIsSUFBSSxDQUFDLE9BQU8sR0FBRyw2QkFBNkIsRUFDNUMsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLFNBQVMsRUFBRSxFQUFFLENBQ2hDLENBQUMsR0FBRyxDQUFDLFVBQUEsR0FBRyxJQUFHLE9BQUEsR0FBRyxDQUFDLElBQUksRUFBRSxFQUFWLENBQVUsQ0FBQyxDQUFDO2dCQUM1QixDQUFDO2dCQUNNLGdEQUFrQixHQUF6QjtvQkFDSSxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQ2hCLElBQUksQ0FBQyxPQUFPLEdBQUcsNkJBQTZCLEVBQzVDLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxTQUFTLEVBQUUsRUFBRSxDQUNoQyxDQUFDLEdBQUcsQ0FBQyxVQUFBLEdBQUcsSUFBRyxPQUFBLEdBQUcsQ0FBQyxJQUFJLEVBQUUsRUFBVixDQUFVLENBQUMsQ0FBQztnQkFDNUIsQ0FBQztnQkFFTSx1Q0FBUyxHQUFoQjtvQkFDSSxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQ2hCLElBQUksQ0FBQyxPQUFPLEdBQUcsb0JBQW9CLEVBQ25DLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxTQUFTLEVBQUUsRUFBRSxDQUNoQyxDQUFDLEdBQUcsQ0FBQyxVQUFBLEdBQUcsSUFBRyxPQUFBLEdBQUcsQ0FBQyxJQUFJLEVBQUUsRUFBVixDQUFVLENBQUMsQ0FBQztnQkFDNUIsQ0FBQztnQkFDTSx3Q0FBVSxHQUFqQjtvQkFDSSxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQ2hCLElBQUksQ0FBQyxPQUFPLEdBQUcscUJBQXFCLEVBQ3BDLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxTQUFTLEVBQUUsRUFBRSxDQUNoQyxDQUFDLEdBQUcsQ0FBQyxVQUFBLEdBQUcsSUFBRyxPQUFBLEdBQUcsQ0FBQyxJQUFJLEVBQUUsRUFBVixDQUFVLENBQUMsQ0FBQztnQkFDNUIsQ0FBQztnQkFDTSxtREFBcUIsR0FBNUIsVUFBNkIsR0FBRztvQkFDNUIsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUNoQixJQUFJLENBQUMsT0FBTyxHQUFHLDBDQUEwQyxHQUFDLEdBQUcsRUFDN0QsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLFNBQVMsRUFBRSxFQUFFLENBQ2hDLENBQUMsR0FBRyxDQUFDLFVBQUEsR0FBRyxJQUFHLE9BQUEsR0FBRyxDQUFDLElBQUksRUFBRSxFQUFWLENBQVUsQ0FBQyxDQUFDO2dCQUM1QixDQUFDO2dCQUNNLHFEQUF1QixHQUE5QixVQUErQixVQUFVO29CQUNyQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQ2hCLElBQUksQ0FBQyxPQUFPLEdBQUcsbURBQW1ELEdBQUcsVUFBVSxFQUMvRSxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsU0FBUyxFQUFFLEVBQUUsQ0FDaEMsQ0FBQyxHQUFHLENBQUMsVUFBQSxHQUFHLElBQUcsT0FBQSxHQUFHLENBQUMsSUFBSSxFQUFFLEVBQVYsQ0FBVSxDQUFDLENBQUM7Z0JBQzVCLENBQUM7Z0JBQ00sbURBQXFCLEdBQTVCLFVBQTZCLFVBQVUsRUFBRSxTQUFTO29CQUM5QyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQ2hCLElBQUksQ0FBQyxPQUFPLEdBQUcsaURBQWlELEdBQUcsVUFBVSxHQUFHLGFBQWEsR0FBRyxTQUFTLEVBQ3pHLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxTQUFTLEVBQUUsRUFBRSxDQUNoQyxDQUFDLEdBQUcsQ0FBQyxVQUFBLEdBQUcsSUFBRyxPQUFBLEdBQUcsQ0FBQyxJQUFJLEVBQUUsRUFBVixDQUFVLENBQUMsQ0FBQztnQkFDNUIsQ0FBQztnQkFDTSwyQ0FBYSxHQUFwQixVQUFxQixVQUFVLEVBQUUsT0FBTztvQkFDcEMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUNoQixJQUFJLENBQUMsT0FBTyxHQUFHLHlDQUF5QyxHQUFHLFVBQVUsR0FBRyxXQUFXLEdBQUcsT0FBTyxFQUM3RixFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsU0FBUyxFQUFFLEVBQUUsQ0FDaEMsQ0FBQyxHQUFHLENBQUMsVUFBQSxHQUFHLElBQUcsT0FBQSxHQUFHLENBQUMsSUFBSSxFQUFFLEVBQVYsQ0FBVSxDQUFDLENBQUM7Z0JBQzVCLENBQUM7Z0JBQ00sc0NBQVEsR0FBZixVQUFnQixVQUFVLEVBQUMsTUFBTTtvQkFDN0IsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUNoQixJQUFJLENBQUMsT0FBTyxHQUFHLG9DQUFvQyxHQUFHLFVBQVUsR0FBRyxjQUFjLEdBQUcsTUFBTSxFQUMxRixFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsU0FBUyxFQUFFLEVBQUUsQ0FDaEMsQ0FBQyxHQUFHLENBQUMsVUFBQSxHQUFHLElBQUcsT0FBQSxHQUFHLENBQUMsSUFBSSxFQUFFLEVBQVYsQ0FBVSxDQUFDLENBQUM7Z0JBQzVCLENBQUM7Z0JBckdMO29CQUFDLGlCQUFVLEVBQUU7O3VDQUFBO2dCQXNHYiwwQkFBQztZQUFELENBckdBLEFBcUdDLElBQUE7WUFyR0QscURBcUdDLENBQUEiLCJmaWxlIjoiZGV2L3NlcnZpY2VzL0NoYXJnZUNyZWRpdFNlcnZpY2UuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnYW5ndWxhcjIvY29yZSc7XG5pbXBvcnQgeyBIdHRwLCBIZWFkZXJzICB9IGZyb20gJ2FuZ3VsYXIyL2h0dHAnO1xuaW1wb3J0ICdyeGpzL2FkZC9vcGVyYXRvci9tYXAnO1xuaW1wb3J0IHtPYnNlcnZhYmxlfSBmcm9tIFwicnhqcy9PYnNlcnZhYmxlXCI7XG5pbXBvcnQge3NlcnZpY2VDb25maWd9IGZyb20gJy4uL2NybWNvbmZpZyc7XG5cbkBJbmplY3RhYmxlKClcbmV4cG9ydCBjbGFzcyBDaGFyZ2VDcmVkaXRTZXJ2aWNlIHtcbiAgICBiYXNlVXJsOiBzdHJpbmc7XG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBodHRwOiBIdHRwKSB7XG4gICAgICAgIHRoaXMuYmFzZVVybCA9IHNlcnZpY2VDb25maWcuc2VydmljZUFwaVVybDtcbiAgICB9XG5cbiAgICBwcml2YXRlIGdldEhlYWRlcigpOkhlYWRlcnN7XG4gICAgICAgIHZhciBoZWFkZXIgPSBuZXcgSGVhZGVycygpO1xuICAgICAgICBoZWFkZXIuYXBwZW5kKFwiQ29udGVudC1UeXBlXCIsIFwiYXBwbGljYXRpb24vanNvblwiKTtcbiAgICAgICAgaWYoc2Vzc2lvblN0b3JhZ2UuZ2V0SXRlbShzZXJ2aWNlQ29uZmlnLmFjY2VzVG9rZW5TdG9yZU5hbWUpKXtcbiAgICAgICAgICAgIGhlYWRlci5hcHBlbmQoc2VydmljZUNvbmZpZy5hY2Nlc1Rva2VuUmVxdWVzdEhlYWRlciwgc2Vzc2lvblN0b3JhZ2UuZ2V0SXRlbShzZXJ2aWNlQ29uZmlnLmFjY2VzVG9rZW5TdG9yZU5hbWUpKTtcbiAgICAgICAgfWVsc2Uge1xuICAgICAgICAgICAgdGhyb3cgJ0FjY2VzcyB0b2tlbiBub3QgYXZhaWxhYmxlJztcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gaGVhZGVyO1xuICAgIH1cblxuICAgIFxyXG5cclxuICAgIHB1YmxpYyBTYXZlKFNhdmVPYmplY3Q6IHN0cmluZykge1xyXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdChcclxuICAgICAgICAgICAgdGhpcy5iYXNlVXJsICsgXCJDaGVhcmdlQ3JlZGl0L0dldENoYXJnZUFzaHJhaXRcIiwgICAgICAgICAgICAgICAgICAgLy9VUkwgZm9yIHRoZSByZXF1ZXN0XHJcbiAgICAgICAgICAgIFNhdmVPYmplY3QsXHJcbiAgICAgICAgICAgIHsgaGVhZGVyczogdGhpcy5nZXRIZWFkZXIoKSB9ICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL3sgaGVhZGVyczogaGVhZGVyIH1cclxuICAgICAgICAgICAgLy9IRUFERVJTIGZvciB0aGUgcmVxdWVzdFxyXG4gICAgICAgICkubWFwKHJlcyA9PiByZXMudGV4dCgpKTtcclxuICAgIH1cblxuICAgIFxuICAgIFxuICAgIFxuXG4gICAgcHVibGljIEJpbmRUZXJtRGV0KFRlcm1Obzogc3RyaW5nKTogT2JzZXJ2YWJsZSB7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0KFxuICAgICAgICAgICAgdGhpcy5iYXNlVXJsICsgXCJDaGVhcmdlQ3JlZGl0L0dldFRlcm1pbmFsRGV0QnlUZXJtTm8/VGVybWluYWxObz1cIiArIFRlcm1ObyxcbiAgICAgICAgICAgIHsgaGVhZGVyczogdGhpcy5nZXRIZWFkZXIoKSB9XG4gICAgICAgICkubWFwKHJlcz0+IHJlcy50ZXh0KCkpO1xuICAgIH1cbiAgIFxuICAgIHB1YmxpYyBCaW5kQ3VycmVuY3lMaXN0KCk6IE9ic2VydmFibGUge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLmdldChcbiAgICAgICAgICAgIHRoaXMuYmFzZVVybCArIFwiRHJvcGRvd24vQmluZEN1cnJlbmN5TGlzdFwiLFxuICAgICAgICAgICAgeyBoZWFkZXJzOiB0aGlzLmdldEhlYWRlcigpIH1cbiAgICAgICAgKS5tYXAocmVzPT4gcmVzLnRleHQoKSk7XG4gICAgfVxuXG4gICAgcHVibGljIEJpbmRDcmVkaXRUeXBlTGlzdCgpOiBPYnNlcnZhYmxlIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5nZXQoXG4gICAgICAgICAgICB0aGlzLmJhc2VVcmwgKyBcIkRyb3Bkb3duL0JpbmRDcmVkaXRUeXBlTGlzdFwiLFxuICAgICAgICAgICAgeyBoZWFkZXJzOiB0aGlzLmdldEhlYWRlcigpIH1cbiAgICAgICAgKS5tYXAocmVzPT4gcmVzLnRleHQoKSk7XG4gICAgfVxuICAgIHB1YmxpYyBCaW5kQ2hhcmdlVHlwZUxpc3QoKTogT2JzZXJ2YWJsZSB7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0KFxuICAgICAgICAgICAgdGhpcy5iYXNlVXJsICsgXCJEcm9wZG93bi9CaW5kQ2hhcmdlVHlwZUxpc3RcIixcbiAgICAgICAgICAgIHsgaGVhZGVyczogdGhpcy5nZXRIZWFkZXIoKSB9XG4gICAgICAgICkubWFwKHJlcz0+IHJlcy50ZXh0KCkpO1xuICAgIH1cblxuICAgIHB1YmxpYyBCaW5kWWVhcnMoKTogT2JzZXJ2YWJsZSB7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0KFxuICAgICAgICAgICAgdGhpcy5iYXNlVXJsICsgXCJEcm9wZG93bi9CaW5kWWVhcnNcIixcbiAgICAgICAgICAgIHsgaGVhZGVyczogdGhpcy5nZXRIZWFkZXIoKSB9XG4gICAgICAgICkubWFwKHJlcz0+IHJlcy50ZXh0KCkpO1xuICAgIH1cbiAgICBwdWJsaWMgQmluZE1vbnRocygpOiBPYnNlcnZhYmxlIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5nZXQoXG4gICAgICAgICAgICB0aGlzLmJhc2VVcmwgKyBcIkRyb3Bkb3duL0JpbmRNb250aHNcIixcbiAgICAgICAgICAgIHsgaGVhZGVyczogdGhpcy5nZXRIZWFkZXIoKSB9XG4gICAgICAgICkubWFwKHJlcz0+IHJlcy50ZXh0KCkpO1xuICAgIH1cbiAgICBwdWJsaWMgR2V0V2ViU2VydmljZVJlc3BvbmNlKFVybCk6IE9ic2VydmFibGUge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLmdldChcbiAgICAgICAgICAgIHRoaXMuYmFzZVVybCArIFwiQ2hlYXJnZUNyZWRpdC9HZXRXZWJTZXJ2aWNlUmVzcG9uY2U/VXJsPVwiK3VybCxcbiAgICAgICAgICAgIHsgaGVhZGVyczogdGhpcy5nZXRIZWFkZXIoKSB9XG4gICAgICAgICkubWFwKHJlcz0+IHJlcy50ZXh0KCkpO1xuICAgIH1cbiAgICBwdWJsaWMgSXNJbnNlcnRUb3RibExhc3RVcGRhdGUoQ3VzdG9tZXJJZCk6IE9ic2VydmFibGUge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLmdldChcbiAgICAgICAgICAgIHRoaXMuYmFzZVVybCArIFwiQ2hlYXJnZUNyZWRpdC9Jc0luc2VydFRvdGJsTGFzdFVwZGF0ZT9DdXN0b21lcklkPVwiICsgQ3VzdG9tZXJJZCxcbiAgICAgICAgICAgIHsgaGVhZGVyczogdGhpcy5nZXRIZWFkZXIoKSB9XG4gICAgICAgICkubWFwKHJlcz0+IHJlcy50ZXh0KCkpO1xuICAgIH1cbiAgICBwdWJsaWMgSW5zZXJ0VG90YmxMYXN0VXBkYXRlKEN1c3RvbWVySWQsIFN1bXRvQmlsbCk6IE9ic2VydmFibGUge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLmdldChcbiAgICAgICAgICAgIHRoaXMuYmFzZVVybCArIFwiQ2hlYXJnZUNyZWRpdC9JbnNlcnRUb3RibExhc3RVcGRhdGU/Q3VzdG9tZXJJZD1cIiArIEN1c3RvbWVySWQgKyBcIiZTdW10b0JpbGw9XCIgKyBTdW10b0JpbGwsXG4gICAgICAgICAgICB7IGhlYWRlcnM6IHRoaXMuZ2V0SGVhZGVyKCkgfVxuICAgICAgICApLm1hcChyZXM9PiByZXMudGV4dCgpKTtcbiAgICB9XG4gICAgcHVibGljIFVwZGF0ZU93bmVySWQoQ3VzdG9tZXJJZCwgT3duZXJJZCk6IE9ic2VydmFibGUge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLmdldChcbiAgICAgICAgICAgIHRoaXMuYmFzZVVybCArIFwiQ2hlYXJnZUNyZWRpdC9VcGRhdGVPd25lcklkP0N1c3RvbWVySWQ9XCIgKyBDdXN0b21lcklkICsgXCImT3duZXJJZD1cIiArIE93bmVySWQsXG4gICAgICAgICAgICB7IGhlYWRlcnM6IHRoaXMuZ2V0SGVhZGVyKCkgfVxuICAgICAgICApLm1hcChyZXM9PiByZXMudGV4dCgpKTtcbiAgICB9XG4gICAgcHVibGljIGdldFByaW50KERlYWxOdW1iZXIsVGVybU5vKTogT2JzZXJ2YWJsZSB7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0KFxuICAgICAgICAgICAgdGhpcy5iYXNlVXJsICsgXCJDaGVhcmdlQ3JlZGl0L2dldFByaW50P0RlYWxOdW1iZXI9XCIgKyBEZWFsTnVtYmVyICsgXCImVGVybWluYWxObz1cIiArIFRlcm1ObyxcbiAgICAgICAgICAgIHsgaGVhZGVyczogdGhpcy5nZXRIZWFkZXIoKSB9XG4gICAgICAgICkubWFwKHJlcz0+IHJlcy50ZXh0KCkpO1xuICAgIH1cbn0iXX0=
