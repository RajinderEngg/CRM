System.register(['angular2/core', "./ResourceService", "../crmconfig"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, ResourceService_1, crmconfig_1;
    var AmaxCrmSyinc;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (ResourceService_1_1) {
                ResourceService_1 = ResourceService_1_1;
            },
            function (crmconfig_1_1) {
                crmconfig_1 = crmconfig_1_1;
            }],
        execute: function() {
            AmaxCrmSyinc = (function () {
                function AmaxCrmSyinc(_resourceService) {
                    this._resourceService = _resourceService;
                    this.FormType = "SCREEN_SMS";
                }
                AmaxCrmSyinc.prototype.on = function (eventName, handler) {
                    document.addEventListener(eventName, function (e) { return handler(e['detail']); });
                };
                AmaxCrmSyinc.prototype.off = function (eventName, handler) {
                    document.removeEventListener(eventName, function (e) { return handler(e['detail']); });
                };
                AmaxCrmSyinc.prototype.emit = function (eventName, eventData) {
                    var evt = new CustomEvent(eventName, eventData);
                    evt.initCustomEvent(eventName, true, true, eventData);
                    document.dispatchEvent(evt);
                };
                AmaxCrmSyinc.prototype.storeLocal = function (key, value) {
                    localStorage.setItem(key, JSON.stringify(value));
                    this.emit('lsset.' + key, value);
                };
                AmaxCrmSyinc.prototype.storeSession = function (key, value) {
                    sessionStorage.setItem(key, JSON.stringify(value));
                    this.emit('ssset.' + key, value);
                };
                AmaxCrmSyinc.prototype.fetchLocal = function (key) {
                    return localStorage.getItem(key);
                };
                AmaxCrmSyinc.prototype.fetchSession = function (key) {
                    return localStorage.getItem(key);
                };
                AmaxCrmSyinc.prototype.fetchLocalJSON = function (key) {
                    return JSON.parse(this.fetchLocal(key));
                };
                AmaxCrmSyinc.prototype.fetchLocalEval = function (key) {
                    return eval(this.fetchLocal(key));
                };
                AmaxCrmSyinc.prototype.fetchLanguageResource = function (resourceName) {
                    //debugger;
                    var _resource; //= this.fetchLocalJSON(LocalDict.languageResource);
                    var languageCode = localStorage.getItem("lang");
                    this._resourceService.GetLangRes("SCREEN_SMS", languageCode).subscribe(function (response) {
                        //debugger;
                        response = $.parseJSON(response);
                        if (response.IsError == true) {
                            alert(response.ErrMsg);
                        }
                        else {
                            //localStorage.setItem("langresource", JSON.stringify(response.Data));
                            //localStorage.setItem("lang", evt.code);
                            _resource = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    if (_resource) {
                        try {
                            return _resource[resourceName];
                        }
                        catch (ex) {
                            console.error("Error while parsing resource!");
                            console.error(ex);
                            return false;
                        }
                    }
                    else {
                        var selectedLanguage = localStorage.getItem(crmconfig_1.LocalDict.selectedLanguage) || crmconfig_1.crmConfig.falbackLanguage;
                        localStorage.setItem(crmconfig_1.LocalDict.selectedLanguage, selectedLanguage);
                        this.loadLanguageResource(selectedLanguage);
                        return false;
                    }
                };
                AmaxCrmSyinc.prototype.loadLanguageResource = function (languageCode) {
                    var _this = this;
                    //this._resourceService.GetSelecetdLanguage(languageCode).subscribe(
                    //    data=> {
                    //        debugger;
                    //        this.storeLocal(LocalDict.languageResource,data);
                    //        localStorage.setItem(LocalDict.selectedLanguage,languageCode);
                    //    },
                    //    error=>{
                    //        console.error("Error while featching language json");
                    //        console.error(error);
                    //    },
                    //    ()=>{
                    //        console.log('Language resource compleate');
                    //    }
                    //);
                    languageCode = localStorage.getItem("lang");
                    this._resourceService.GetLangRes(this.FormType, languageCode).subscribe(function (response) {
                        // debugger;
                        response = $.parseJSON(response);
                        if (response.IsError == true) {
                            alert(response.ErrMsg);
                        }
                        else {
                            //localStorage.setItem("langresource", JSON.stringify(response.Data));
                            //localStorage.setItem("lang", evt.code);
                            //this.RES = response.Data;
                            _this.storeLocal(crmconfig_1.LocalDict.languageResource, response.Data);
                            localStorage.setItem(crmconfig_1.LocalDict.selectedLanguage, languageCode);
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxCrmSyinc.prototype.isRtl = function () {
                    //debugger;
                    var selectedLanguage = localStorage.getItem(crmconfig_1.LocalDict.selectedLanguage) || crmconfig_1.crmConfig.falbackLanguage;
                    switch (selectedLanguage) {
                        case "he":
                            return false;
                        default:
                            return true;
                    }
                    return true;
                };
                AmaxCrmSyinc = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [ResourceService_1.ResourceService])
                ], AmaxCrmSyinc);
                return AmaxCrmSyinc;
            }());
            exports_1("AmaxCrmSyinc", AmaxCrmSyinc);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldi9zZXJ2aWNlcy9BbWF4Q3JtU3lpbmMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7WUFLQTtnQkFDSSxzQkFBb0IsZ0JBQWlDO29CQUFqQyxxQkFBZ0IsR0FBaEIsZ0JBQWdCLENBQWlCO29CQUNyRCxhQUFRLEdBQVcsWUFBWSxDQUFDO2dCQUR5QixDQUFDO2dCQUUxRCx5QkFBRSxHQUFGLFVBQUcsU0FBZ0IsRUFBRSxPQUFXO29CQUM1QixRQUFRLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxFQUFDLFVBQUMsQ0FBQyxJQUFJLE9BQUEsT0FBTyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFwQixDQUFvQixDQUFDLENBQUM7Z0JBQ3BFLENBQUM7Z0JBRUQsMEJBQUcsR0FBSCxVQUFJLFNBQWdCLEVBQUUsT0FBVztvQkFDN0IsUUFBUSxDQUFDLG1CQUFtQixDQUFDLFNBQVMsRUFBQyxVQUFDLENBQUMsSUFBSSxPQUFBLE9BQU8sQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBcEIsQ0FBb0IsQ0FBQyxDQUFDO2dCQUN2RSxDQUFDO2dCQUVELDJCQUFJLEdBQUosVUFBSyxTQUFnQixFQUFFLFNBQWE7b0JBQ2hDLElBQUksR0FBRyxHQUFHLElBQUksV0FBVyxDQUFDLFNBQVMsRUFBRSxTQUFTLENBQUMsQ0FBQztvQkFDaEQsR0FBRyxDQUFDLGVBQWUsQ0FBQyxTQUFTLEVBQUMsSUFBSSxFQUFDLElBQUksRUFBQyxTQUFTLENBQUMsQ0FBQztvQkFDbkQsUUFBUSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDaEMsQ0FBQztnQkFFRCxpQ0FBVSxHQUFWLFVBQVcsR0FBVSxFQUFFLEtBQVM7b0JBQzVCLFlBQVksQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztvQkFDakQsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLEdBQUMsR0FBRyxFQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNsQyxDQUFDO2dCQUNELG1DQUFZLEdBQVosVUFBYSxHQUFVLEVBQUUsS0FBUztvQkFDOUIsY0FBYyxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO29CQUNuRCxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsR0FBQyxHQUFHLEVBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ2xDLENBQUM7Z0JBRUQsaUNBQVUsR0FBVixVQUFXLEdBQVc7b0JBRWxCLE1BQU0sQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUNyQyxDQUFDO2dCQUNELG1DQUFZLEdBQVosVUFBYSxHQUFXO29CQUVwQixNQUFNLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDckMsQ0FBQztnQkFFRCxxQ0FBYyxHQUFkLFVBQWUsR0FBVztvQkFFdEIsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO2dCQUM1QyxDQUFDO2dCQUNELHFDQUFjLEdBQWQsVUFBZSxHQUFVO29CQUNyQixNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztnQkFDdEMsQ0FBQztnQkFHRCw0Q0FBcUIsR0FBckIsVUFBc0IsWUFBb0I7b0JBQ3RDLFdBQVc7b0JBQ1gsSUFBSSxTQUFTLENBQUMsQ0FBQyxvREFBb0Q7b0JBQ25FLElBQUksWUFBWSxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQ2hELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsWUFBWSxFQUFFLFlBQVksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7d0JBQzNFLFdBQVc7d0JBQ1gsUUFBUSxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQ2pDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQzt3QkFDM0IsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixzRUFBc0U7NEJBQ3RFLHlDQUF5Qzs0QkFDekMsU0FBUyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7d0JBRzlCLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBRUgsRUFBRSxDQUFBLENBQUMsU0FBUyxDQUFDLENBQUEsQ0FBQzt3QkFDVixJQUFHLENBQUM7NEJBQ0EsTUFBTSxDQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUMsQ0FBQzt3QkFDbkMsQ0FBQzt3QkFBQSxLQUFLLENBQUEsQ0FBQyxFQUFFLENBQUMsQ0FBQSxDQUFDOzRCQUNQLE9BQU8sQ0FBQyxLQUFLLENBQUMsK0JBQStCLENBQUMsQ0FBQzs0QkFDL0MsT0FBTyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQzs0QkFDbEIsTUFBTSxDQUFDLEtBQUssQ0FBQzt3QkFDakIsQ0FBQztvQkFDTCxDQUFDO29CQUNELElBQUksQ0FBQSxDQUFDO3dCQUNELElBQUksZ0JBQWdCLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxxQkFBUyxDQUFDLGdCQUFnQixDQUFDLElBQUkscUJBQVMsQ0FBQyxlQUFlLENBQUM7d0JBQ3JHLFlBQVksQ0FBQyxPQUFPLENBQUMscUJBQVMsQ0FBQyxnQkFBZ0IsRUFBQyxnQkFBZ0IsQ0FBQyxDQUFDO3dCQUVsRSxJQUFJLENBQUMsb0JBQW9CLENBQUMsZ0JBQWdCLENBQUMsQ0FBQzt3QkFDNUMsTUFBTSxDQUFDLEtBQUssQ0FBQTtvQkFDaEIsQ0FBQztnQkFDTCxDQUFDO2dCQUNELDJDQUFvQixHQUFwQixVQUFxQixZQUFtQjtvQkFBeEMsaUJBa0NDO29CQWpDRyxvRUFBb0U7b0JBQ3BFLGNBQWM7b0JBQ2QsbUJBQW1CO29CQUNuQiwyREFBMkQ7b0JBQzNELHdFQUF3RTtvQkFDeEUsUUFBUTtvQkFDUixjQUFjO29CQUNkLCtEQUErRDtvQkFDL0QsK0JBQStCO29CQUMvQixRQUFRO29CQUNSLFdBQVc7b0JBQ1gscURBQXFEO29CQUNyRCxPQUFPO29CQUNQLElBQUk7b0JBQ0osWUFBWSxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQzVDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxZQUFZLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUM3RSxZQUFZO3dCQUNYLFFBQVEsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUNqQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUM7d0JBQzNCLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0Ysc0VBQXNFOzRCQUN0RSx5Q0FBeUM7NEJBQ3pDLDJCQUEyQjs0QkFDM0IsS0FBSSxDQUFDLFVBQVUsQ0FBQyxxQkFBUyxDQUFDLGdCQUFnQixFQUFFLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQzs0QkFDM0QsWUFBWSxDQUFDLE9BQU8sQ0FBQyxxQkFBUyxDQUFDLGdCQUFnQixFQUFFLFlBQVksQ0FBQyxDQUFDO3dCQUNuRSxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO2dCQUNQLENBQUM7Z0JBRUQsNEJBQUssR0FBTDtvQkFDSSxXQUFXO29CQUNYLElBQUksZ0JBQWdCLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxxQkFBUyxDQUFDLGdCQUFnQixDQUFDLElBQUkscUJBQVMsQ0FBQyxlQUFlLENBQUE7b0JBQ3BHLE1BQU0sQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUEsQ0FBQzt3QkFDdEIsS0FBSyxJQUFJOzRCQUNMLE1BQU0sQ0FBQyxLQUFLLENBQUM7d0JBQ2pCOzRCQUNJLE1BQU0sQ0FBQyxJQUFJLENBQUM7b0JBQ3BCLENBQUM7b0JBQ0QsTUFBTSxDQUFDLElBQUksQ0FBQztnQkFDaEIsQ0FBQztnQkFuSUw7b0JBQUMsaUJBQVUsRUFBRTs7Z0NBQUE7Z0JBb0liLG1CQUFDO1lBQUQsQ0FuSUEsQUFtSUMsSUFBQTtZQW5JRCx1Q0FtSUMsQ0FBQSIsImZpbGUiOiJkZXYvc2VydmljZXMvQW1heENybVN5aW5jLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtJbmplY3RhYmxlfSBmcm9tICdhbmd1bGFyMi9jb3JlJztcclxuaW1wb3J0IHtSZXNvdXJjZVNlcnZpY2V9IGZyb20gXCIuL1Jlc291cmNlU2VydmljZVwiO1xyXG5pbXBvcnQge0xvY2FsRGljdCwgY3JtQ29uZmlnfSBmcm9tIFwiLi4vY3JtY29uZmlnXCI7XHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBBbWF4Q3JtU3lpbmMge1xyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBfcmVzb3VyY2VTZXJ2aWNlOiBSZXNvdXJjZVNlcnZpY2UpIHsgfVxyXG4gICAgRm9ybVR5cGU6IHN0cmluZyA9IFwiU0NSRUVOX1NNU1wiO1xyXG4gICAgb24oZXZlbnROYW1lOnN0cmluZywgaGFuZGxlcjphbnkpIHtcclxuICAgICAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKGV2ZW50TmFtZSwoZSk9PiBoYW5kbGVyKGVbJ2RldGFpbCddKSk7XHJcbiAgICB9XHJcblxyXG4gICAgb2ZmKGV2ZW50TmFtZTpzdHJpbmcsIGhhbmRsZXI6YW55KSB7XHJcbiAgICAgICAgZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcihldmVudE5hbWUsKGUpPT4gaGFuZGxlcihlWydkZXRhaWwnXSkpO1xyXG4gICAgfVxyXG5cclxuICAgIGVtaXQoZXZlbnROYW1lOnN0cmluZywgZXZlbnREYXRhOmFueSkge1xyXG4gICAgICAgIHZhciBldnQgPSBuZXcgQ3VzdG9tRXZlbnQoZXZlbnROYW1lLCBldmVudERhdGEpO1xyXG4gICAgICAgIGV2dC5pbml0Q3VzdG9tRXZlbnQoZXZlbnROYW1lLHRydWUsdHJ1ZSxldmVudERhdGEpO1xyXG4gICAgICAgIGRvY3VtZW50LmRpc3BhdGNoRXZlbnQoZXZ0KTtcclxuICAgIH1cclxuXHJcbiAgICBzdG9yZUxvY2FsKGtleTpzdHJpbmcsIHZhbHVlOmFueSl7XHJcbiAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oa2V5LCBKU09OLnN0cmluZ2lmeSh2YWx1ZSkpO1xyXG4gICAgICAgIHRoaXMuZW1pdCgnbHNzZXQuJytrZXksdmFsdWUpO1xyXG4gICAgfVxyXG4gICAgc3RvcmVTZXNzaW9uKGtleTpzdHJpbmcsIHZhbHVlOmFueSl7XHJcbiAgICAgICAgc2Vzc2lvblN0b3JhZ2Uuc2V0SXRlbShrZXksIEpTT04uc3RyaW5naWZ5KHZhbHVlKSk7XHJcbiAgICAgICAgdGhpcy5lbWl0KCdzc3NldC4nK2tleSx2YWx1ZSk7XHJcbiAgICB9XHJcblxyXG4gICAgZmV0Y2hMb2NhbChrZXk6IHN0cmluZyk6IHN0cmluZ3tcclxuICAgICAgICBcclxuICAgICAgICByZXR1cm4gbG9jYWxTdG9yYWdlLmdldEl0ZW0oa2V5KTtcclxuICAgIH1cclxuICAgIGZldGNoU2Vzc2lvbihrZXk6IHN0cmluZyk6IHN0cmluZ3tcclxuICAgICAgICBcclxuICAgICAgICByZXR1cm4gbG9jYWxTdG9yYWdlLmdldEl0ZW0oa2V5KTtcclxuICAgIH1cclxuXHJcbiAgICBmZXRjaExvY2FsSlNPTihrZXk6IHN0cmluZyk6IGFueXtcclxuICAgICAgICBcclxuICAgICAgICByZXR1cm4gSlNPTi5wYXJzZSh0aGlzLmZldGNoTG9jYWwoa2V5KSk7XHJcbiAgICB9XHJcbiAgICBmZXRjaExvY2FsRXZhbChrZXk6c3RyaW5nKTphbnl7XHJcbiAgICAgICAgcmV0dXJuIGV2YWwodGhpcy5mZXRjaExvY2FsKGtleSkpO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICBmZXRjaExhbmd1YWdlUmVzb3VyY2UocmVzb3VyY2VOYW1lOiBzdHJpbmcpOiBhbnl7XHJcbiAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICB2YXIgX3Jlc291cmNlOyAvLz0gdGhpcy5mZXRjaExvY2FsSlNPTihMb2NhbERpY3QubGFuZ3VhZ2VSZXNvdXJjZSk7XHJcbiAgICAgICAgdmFyIGxhbmd1YWdlQ29kZSA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwibGFuZ1wiKTtcclxuICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuR2V0TGFuZ1JlcyhcIlNDUkVFTl9TTVNcIiwgbGFuZ3VhZ2VDb2RlKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgIHJlc3BvbnNlID0gJC5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBhbGVydChyZXNwb25zZS5FcnJNc2cpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgLy9sb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImxhbmdyZXNvdXJjZVwiLCBKU09OLnN0cmluZ2lmeShyZXNwb25zZS5EYXRhKSk7XHJcbiAgICAgICAgICAgICAgICAvL2xvY2FsU3RvcmFnZS5zZXRJdGVtKFwibGFuZ1wiLCBldnQuY29kZSk7XHJcbiAgICAgICAgICAgICAgICBfcmVzb3VyY2UgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgLy90aGlzLnN0b3JlTG9jYWwoTG9jYWxEaWN0Lmxhbmd1YWdlUmVzb3VyY2UsIHJlc3BvbnNlLkRhdGEpO1xyXG4gICAgICAgICAgICAgICAgLy9sb2NhbFN0b3JhZ2Uuc2V0SXRlbShMb2NhbERpY3Quc2VsZWN0ZWRMYW5ndWFnZSwgbGFuZ3VhZ2VDb2RlKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgaWYoX3Jlc291cmNlKXtcclxuICAgICAgICAgICAgdHJ5e1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIF9yZXNvdXJjZVtyZXNvdXJjZU5hbWVdO1xyXG4gICAgICAgICAgICB9Y2F0Y2goZXgpe1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHdoaWxlIHBhcnNpbmcgcmVzb3VyY2UhXCIpO1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihleCk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZXtcclxuICAgICAgICAgICAgdmFyIHNlbGVjdGVkTGFuZ3VhZ2UgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShMb2NhbERpY3Quc2VsZWN0ZWRMYW5ndWFnZSkgfHwgY3JtQ29uZmlnLmZhbGJhY2tMYW5ndWFnZTtcclxuICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oTG9jYWxEaWN0LnNlbGVjdGVkTGFuZ3VhZ2Usc2VsZWN0ZWRMYW5ndWFnZSk7XHJcblxyXG4gICAgICAgICAgICB0aGlzLmxvYWRMYW5ndWFnZVJlc291cmNlKHNlbGVjdGVkTGFuZ3VhZ2UpO1xyXG4gICAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBsb2FkTGFuZ3VhZ2VSZXNvdXJjZShsYW5ndWFnZUNvZGU6c3RyaW5nKXtcclxuICAgICAgICAvL3RoaXMuX3Jlc291cmNlU2VydmljZS5HZXRTZWxlY2V0ZExhbmd1YWdlKGxhbmd1YWdlQ29kZSkuc3Vic2NyaWJlKFxyXG4gICAgICAgIC8vICAgIGRhdGE9PiB7XHJcbiAgICAgICAgLy8gICAgICAgIGRlYnVnZ2VyO1xyXG4gICAgICAgIC8vICAgICAgICB0aGlzLnN0b3JlTG9jYWwoTG9jYWxEaWN0Lmxhbmd1YWdlUmVzb3VyY2UsZGF0YSk7XHJcbiAgICAgICAgLy8gICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKExvY2FsRGljdC5zZWxlY3RlZExhbmd1YWdlLGxhbmd1YWdlQ29kZSk7XHJcbiAgICAgICAgLy8gICAgfSxcclxuICAgICAgICAvLyAgICBlcnJvcj0+e1xyXG4gICAgICAgIC8vICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3Igd2hpbGUgZmVhdGNoaW5nIGxhbmd1YWdlIGpzb25cIik7XHJcbiAgICAgICAgLy8gICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICAgIC8vICAgIH0sXHJcbiAgICAgICAgLy8gICAgKCk9PntcclxuICAgICAgICAvLyAgICAgICAgY29uc29sZS5sb2coJ0xhbmd1YWdlIHJlc291cmNlIGNvbXBsZWF0ZScpO1xyXG4gICAgICAgIC8vICAgIH1cclxuICAgICAgICAvLyk7XHJcbiAgICAgICAgbGFuZ3VhZ2VDb2RlID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJsYW5nXCIpO1xyXG4gICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5HZXRMYW5nUmVzKHRoaXMuRm9ybVR5cGUsIGxhbmd1YWdlQ29kZSkuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgIC8vIGRlYnVnZ2VyO1xyXG4gICAgICAgICAgICByZXNwb25zZSA9ICQucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYWxlcnQocmVzcG9uc2UuRXJyTXNnKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIC8vbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJsYW5ncmVzb3VyY2VcIiwgSlNPTi5zdHJpbmdpZnkocmVzcG9uc2UuRGF0YSkpO1xyXG4gICAgICAgICAgICAgICAgLy9sb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImxhbmdcIiwgZXZ0LmNvZGUpO1xyXG4gICAgICAgICAgICAgICAgLy90aGlzLlJFUyA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnN0b3JlTG9jYWwoTG9jYWxEaWN0Lmxhbmd1YWdlUmVzb3VyY2UsIHJlc3BvbnNlLkRhdGEpO1xyXG4gICAgICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oTG9jYWxEaWN0LnNlbGVjdGVkTGFuZ3VhZ2UsIGxhbmd1YWdlQ29kZSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgaXNSdGwoKTogYm9vbGVhbntcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgIHZhciBzZWxlY3RlZExhbmd1YWdlID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oTG9jYWxEaWN0LnNlbGVjdGVkTGFuZ3VhZ2UpIHx8IGNybUNvbmZpZy5mYWxiYWNrTGFuZ3VhZ2VcclxuICAgICAgICBzd2l0Y2ggKHNlbGVjdGVkTGFuZ3VhZ2Upe1xyXG4gICAgICAgICAgICBjYXNlIFwiaGVcIjpcclxuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgIH1cclxufSJdfQ==
