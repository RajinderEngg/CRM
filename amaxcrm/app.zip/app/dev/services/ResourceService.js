System.register(["angular2/core", "angular2/http", 'rxjs/add/operator/map', "../crmconfig"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, http_1, crmconfig_1;
    var ResourceService;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (http_1_1) {
                http_1 = http_1_1;
            },
            function (_1) {},
            function (crmconfig_1_1) {
                crmconfig_1 = crmconfig_1_1;
            }],
        execute: function() {
            ResourceService = (function () {
                function ResourceService(_http) {
                    this._http = _http;
                    this.headers = new http_1.Headers();
                    this.headers.append("Content-Type", "application/json");
                    this.baseUrl = crmconfig_1.serviceConfig.serviceApiUrl;
                    this.AppUrl = crmconfig_1.serviceConfig.AppUrl;
                }
                ResourceService.prototype.getHeader = function () {
                    var header = new http_1.Headers();
                    header.append("Content-Type", "application/json");
                    //if (sessionStorage.getItem(serviceConfig.accesTokenStoreName)) {
                    //    header.append(serviceConfig.accesTokenRequestHeader, sessionStorage.getItem(serviceConfig.accesTokenStoreName));
                    //} else {
                    //    throw 'Access token not available';
                    //}
                    return header;
                };
                ResourceService.prototype.setCookie = function (name, value, expireDays, path) {
                    if (path === void 0) { path = ""; }
                    //debugger;
                    var d = new Date();
                    d.setTime(d.getTime() + expireDays * 24 * 60 * 60 * 1000);
                    var expires = "expires=" + d.toUTCString();
                    document.cookie = name + "=" + value + "; " + expires + (path.length > 0 ? "; path=" + path : "");
                    //document.cookie = name + "=" + value + "; path=" + path;
                };
                ResourceService.prototype.getCookie = function (name) {
                    //debugger;
                    var ca = document.cookie.split(';');
                    var caLen = ca.length;
                    var cookieName = name + "=";
                    var c;
                    for (var i = 0; i < caLen; i += 1) {
                        c = ca[i].replace(/^\s\+/g, "");
                        var index = c.indexOf(cookieName);
                        if (c.indexOf(cookieName) == 0) {
                            return c.substring(cookieName.length, c.length);
                        }
                        if (c.indexOf(cookieName) == 1 && cookieName == name + "=") {
                            return c.substring(cookieName.length, c.length);
                        }
                    }
                    return "";
                };
                ResourceService.prototype.deleteCookie = function (name) {
                    this.setCookie(name, "", -1);
                };
                ResourceService.prototype.LoadLanguageResource = function (code) {
                    if (code === void 0) { code = "he"; }
                    // the function is not in use
                };
                ResourceService.prototype.GetSelecetdLanguage = function (code) {
                    //debugger;
                    if (!code)
                        code = "en";
                    code = code.trim();
                    // debugger;
                    //,
                    //{ headers: this.headers }
                    return this._http.get("/src/lang/" + code + ".json")
                        .map(function (res) { return res.json(); });
                };
                ResourceService.prototype.GetAvailableLanguages = function () {
                    return [
                        { name: "English", code: "en" },
                        { name: "עִברִית", code: "he" }
                    ];
                };
                ResourceService.prototype.GetMenues = function () {
                    var _this = this;
                    var lang = this.getCookie("lang");
                    //alert(lang);
                    if (lang.length > 0)
                        lang = lang.substring(1, lang.length);
                    if (lang == "")
                        lang = "en";
                    return new Promise(function (resolve) {
                        return _this._http.get("/src/menu-" + lang + ".json", { headers: _this.headers })
                            .map(function (res) { return res.json().menu; })
                            .subscribe(function (menudata) {
                            resolve(menudata);
                        });
                    });
                };
                ResourceService.prototype.GetFormByName = function (formName) {
                    return this._http.get("/src/forms/" + formName + ".json", { headers: this.headers })
                        .map(function (res) { return res.json(); });
                    //return new Promise(resolve=>{
                    //    this._http.get("/src/forms/"+formName+".json",{headers:this.headers})
                    //        .map(res=>res.json())
                    //        .subscribe(data=>resolve(data));
                    //})
                };
                //localstorage utility
                ResourceService.prototype.GetLocalStorage = function (key) {
                    var data = localStorage.getItem(key);
                    return JSON.parse(data);
                };
                ResourceService.prototype.SetLocalStorage = function (key, data) {
                    localStorage.setItem(key, JSON.stringify(data));
                };
                //sessionStorage utility
                ResourceService.prototype.GetSessionStorage = function (key) {
                    var data = sessionStorage.getItem(key);
                    return JSON.parse(data);
                };
                ResourceService.prototype.SetSessionStorage = function (key, data) {
                    sessionStorage.setItem(key, JSON.stringify(data));
                };
                ResourceService.prototype.GetLangRes = function (FormType, Lang) {
                    //alert(FormType);
                    //debugger;
                    //var Lang = localStorage.getItem("lang");
                    return this._http.get(this.baseUrl + "Dropdown/GetLangRes?FormType=" + FormType + "&Lang=" + Lang, { headers: this.getHeader() }).map(function (res) { return res.text(); });
                };
                ResourceService = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [http_1.Http])
                ], ResourceService);
                return ResourceService;
            }());
            exports_1("ResourceService", ResourceService);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldi9zZXJ2aWNlcy9SZXNvdXJjZVNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1lBWUE7Z0JBSUkseUJBQW9CLEtBQVc7b0JBQVgsVUFBSyxHQUFMLEtBQUssQ0FBTTtvQkFDM0IsSUFBSSxDQUFDLE9BQU8sR0FBQyxJQUFJLGNBQU8sRUFBRSxDQUFDO29CQUMzQixJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxjQUFjLEVBQUUsa0JBQWtCLENBQUMsQ0FBQztvQkFDeEQsSUFBSSxDQUFDLE9BQU8sR0FBRyx5QkFBYSxDQUFDLGFBQWEsQ0FBQztvQkFDM0MsSUFBSSxDQUFDLE1BQU0sR0FBRyx5QkFBYSxDQUFDLE1BQU0sQ0FBQztnQkFDdkMsQ0FBQztnQkFLTyxtQ0FBUyxHQUFqQjtvQkFDSSxJQUFJLE1BQU0sR0FBRyxJQUFJLGNBQU8sRUFBRSxDQUFDO29CQUMzQixNQUFNLENBQUMsTUFBTSxDQUFDLGNBQWMsRUFBRSxrQkFBa0IsQ0FBQyxDQUFDO29CQUNsRCxrRUFBa0U7b0JBQ2xFLHNIQUFzSDtvQkFDdEgsVUFBVTtvQkFDVix5Q0FBeUM7b0JBQ3pDLEdBQUc7b0JBQ0gsTUFBTSxDQUFDLE1BQU0sQ0FBQztnQkFDbEIsQ0FBQztnQkFHTSxtQ0FBUyxHQUFoQixVQUFpQixJQUFZLEVBQUUsS0FBYSxFQUFFLFVBQWtCLEVBQUUsSUFBaUI7b0JBQWpCLG9CQUFpQixHQUFqQixTQUFpQjtvQkFDL0UsV0FBVztvQkFDWCxJQUFJLENBQUMsR0FBUyxJQUFJLElBQUksRUFBRSxDQUFDO29CQUN6QixDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLEVBQUUsR0FBRyxVQUFVLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsSUFBSSxDQUFDLENBQUM7b0JBQzFELElBQUksT0FBTyxHQUFXLFVBQVUsR0FBRyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7b0JBQ25ELFFBQVEsQ0FBQyxNQUFNLEdBQUcsSUFBSSxHQUFHLEdBQUcsR0FBRyxLQUFLLEdBQUcsSUFBSSxHQUFHLE9BQU8sR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxHQUFHLFNBQVMsR0FBRyxJQUFJLEdBQUcsRUFBRSxDQUFDLENBQUM7b0JBRWxHLDBEQUEwRDtnQkFDOUQsQ0FBQztnQkFFTSxtQ0FBUyxHQUFoQixVQUFpQixJQUFZO29CQUN6QixXQUFXO29CQUNYLElBQUksRUFBRSxHQUFrQixRQUFRLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztvQkFDbkQsSUFBSSxLQUFLLEdBQVcsRUFBRSxDQUFDLE1BQU0sQ0FBQztvQkFDOUIsSUFBSSxVQUFVLEdBQUcsSUFBSSxHQUFHLEdBQUcsQ0FBQztvQkFDNUIsSUFBSSxDQUFTLENBQUM7b0JBRWQsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDO3dCQUN4QyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUM7d0JBQ2hDLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7d0JBQ2xDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQzs0QkFDN0IsTUFBTSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7d0JBQ3BELENBQUM7d0JBQ0QsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksVUFBVSxJQUFJLElBQUksR0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDOzRCQUN2RCxNQUFNLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQzt3QkFDcEQsQ0FBQztvQkFDTCxDQUFDO29CQUNELE1BQU0sQ0FBQyxFQUFFLENBQUM7Z0JBQ2QsQ0FBQztnQkFFTSxzQ0FBWSxHQUFuQixVQUFvQixJQUFJO29CQUNwQixJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDakMsQ0FBQztnQkFHTSw4Q0FBb0IsR0FBM0IsVUFBNEIsSUFBbUI7b0JBQW5CLG9CQUFtQixHQUFuQixXQUFtQjtvQkFDM0MsNkJBQTZCO2dCQUNqQyxDQUFDO2dCQUdNLDZDQUFtQixHQUExQixVQUEyQixJQUFhO29CQUNwQyxXQUFXO29CQUNYLEVBQUUsQ0FBQSxDQUFDLENBQUMsSUFBSSxDQUFDO3dCQUFBLElBQUksR0FBQyxJQUFJLENBQUM7b0JBQ25CLElBQUksR0FBRyxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ3BCLFlBQVk7b0JBQ1gsR0FBRztvQkFDSCwyQkFBMkI7b0JBQzNCLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FDakIsWUFBWSxHQUFDLElBQUksR0FBQyxPQUFPLENBQUM7eUJBQ3pCLEdBQUcsQ0FDSixVQUFBLEdBQUcsSUFBSSxPQUFBLEdBQUcsQ0FBQyxJQUFJLEVBQUUsRUFBVixDQUFVLENBQ2hCLENBQUM7Z0JBQ1YsQ0FBQztnQkFFTSwrQ0FBcUIsR0FBNUI7b0JBQ0ksTUFBTSxDQUFDO3dCQUNILEVBQUMsSUFBSSxFQUFDLFNBQVMsRUFBRSxJQUFJLEVBQUMsSUFBSSxFQUFDO3dCQUMzQixFQUFDLElBQUksRUFBQyxTQUFTLEVBQUUsSUFBSSxFQUFDLElBQUksRUFBQztxQkFDOUIsQ0FBQztnQkFDTixDQUFDO2dCQUVNLG1DQUFTLEdBQWhCO29CQUFBLGlCQWtCQztvQkFoQkcsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDbEMsY0FBYztvQkFDZCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQzt3QkFDaEIsSUFBSSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDMUMsRUFBRSxDQUFDLENBQUMsSUFBSSxJQUFJLEVBQUUsQ0FBQzt3QkFDWCxJQUFJLEdBQUcsSUFBSSxDQUFDO29CQUNoQixNQUFNLENBQUMsSUFBSSxPQUFPLENBQUMsVUFBQSxPQUFPO3dCQUN0QixPQUFBLEtBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUNWLFlBQVksR0FBRyxJQUFJLEdBQUMsT0FBTyxFQUMzQixFQUFFLE9BQU8sRUFBRSxLQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7NkJBQ3pCLEdBQUcsQ0FBQyxVQUFBLEdBQUcsSUFBRyxPQUFBLEdBQUcsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxJQUFJLEVBQWYsQ0FBZSxDQUFDOzZCQUMxQixTQUFTLENBQUMsVUFBQSxRQUFROzRCQUVmLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDdEIsQ0FBQyxDQUFDO29CQVBOLENBT00sQ0FDVCxDQUFBO2dCQUNMLENBQUM7Z0JBRU0sdUNBQWEsR0FBcEIsVUFBcUIsUUFBZTtvQkFDaEMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLGFBQWEsR0FBQyxRQUFRLEdBQUMsT0FBTyxFQUFDLEVBQUMsT0FBTyxFQUFDLElBQUksQ0FBQyxPQUFPLEVBQUMsQ0FBQzt5QkFDdkUsR0FBRyxDQUFDLFVBQUEsR0FBRyxJQUFFLE9BQUEsR0FBRyxDQUFDLElBQUksRUFBRSxFQUFWLENBQVUsQ0FBQyxDQUFDO29CQUUxQiwrQkFBK0I7b0JBQy9CLDJFQUEyRTtvQkFDM0UsK0JBQStCO29CQUMvQiwwQ0FBMEM7b0JBQzFDLElBQUk7Z0JBQ1IsQ0FBQztnQkFFRCxzQkFBc0I7Z0JBQ2YseUNBQWUsR0FBdEIsVUFBdUIsR0FBVztvQkFDOUIsSUFBSSxJQUFJLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztvQkFDckMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQzVCLENBQUM7Z0JBQ00seUNBQWUsR0FBdEIsVUFBdUIsR0FBVyxFQUFFLElBQVM7b0JBQ3pDLFlBQVksQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztnQkFDcEQsQ0FBQztnQkFFRCx3QkFBd0I7Z0JBQ2pCLDJDQUFpQixHQUF4QixVQUF5QixHQUFXO29CQUNoQyxJQUFJLElBQUksR0FBRyxjQUFjLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUN2QyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDNUIsQ0FBQztnQkFDTSwyQ0FBaUIsR0FBeEIsVUFBeUIsR0FBVyxFQUFFLElBQVM7b0JBQzNDLGNBQWMsQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztnQkFDdEQsQ0FBQztnQkFDTSxvQ0FBVSxHQUFqQixVQUFrQixRQUFnQixFQUFFLElBQVk7b0JBQzVDLGtCQUFrQjtvQkFDbEIsV0FBVztvQkFDWCwwQ0FBMEM7b0JBQzFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FDakIsSUFBSSxDQUFDLE9BQU8sR0FBRywrQkFBK0IsR0FBRyxRQUFRLEdBQUcsUUFBUSxHQUFHLElBQUksRUFDM0UsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLFNBQVMsRUFBRSxFQUFFLENBQ2hDLENBQUMsR0FBRyxDQUFDLFVBQUEsR0FBRyxJQUFHLE9BQUEsR0FBRyxDQUFDLElBQUksRUFBRSxFQUFWLENBQVUsQ0FBQyxDQUFDO2dCQUM1QixDQUFDO2dCQWhKTDtvQkFBQyxpQkFBVSxFQUFFOzttQ0FBQTtnQkFpSmIsc0JBQUM7WUFBRCxDQWhKQSxBQWdKQyxJQUFBO1lBaEpELDZDQWdKQyxDQUFBIiwiZmlsZSI6ImRldi9zZXJ2aWNlcy9SZXNvdXJjZVNlcnZpY2UuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge0luamVjdGFibGV9IGZyb20gXCJhbmd1bGFyMi9jb3JlXCI7XG5pbXBvcnQge0h0dHAsIEhlYWRlcnN9IGZyb20gXCJhbmd1bGFyMi9odHRwXCI7XG5pbXBvcnQgJ3J4anMvYWRkL29wZXJhdG9yL21hcCc7XG5pbXBvcnQge0xvY2FsRGljdCwgY3JtQ29uZmlnLCBzZXJ2aWNlQ29uZmlnfSBmcm9tIFwiLi4vY3JtY29uZmlnXCI7XG5leHBvcnQgaW50ZXJmYWNlIE1lbnVlSXRlbXtcbiAgICBsYWJlbDpzdHJpbmcsXG4gICAgcm91dGVyVXJsOnN0cmluZyxcbiAgICBmYWljb24/OnN0cmluZyxcbiAgICBzdWJNZW51cz86QXJyYXk8TWVudWVJdGVtPlxufVxuXG5ASW5qZWN0YWJsZSgpXG5leHBvcnQgY2xhc3MgUmVzb3VyY2VTZXJ2aWNlIHtcbiAgICBoZWFkZXJzOiBIZWFkZXJzO1xuICAgIEFwcFVybDogc3RyaW5nO1xuICAgIGJhc2VVcmw6IHN0cmluZztcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIF9odHRwOiBIdHRwKSB7XG4gICAgICAgIHRoaXMuaGVhZGVycz1uZXcgSGVhZGVycygpO1xuICAgICAgICB0aGlzLmhlYWRlcnMuYXBwZW5kKFwiQ29udGVudC1UeXBlXCIsIFwiYXBwbGljYXRpb24vanNvblwiKTtcbiAgICAgICAgdGhpcy5iYXNlVXJsID0gc2VydmljZUNvbmZpZy5zZXJ2aWNlQXBpVXJsO1xuICAgICAgICB0aGlzLkFwcFVybCA9IHNlcnZpY2VDb25maWcuQXBwVXJsO1xuICAgIH1cblxuXG5cblxuICAgIHByaXZhdGUgZ2V0SGVhZGVyKCk6IEhlYWRlcnMge1xuICAgICAgICB2YXIgaGVhZGVyID0gbmV3IEhlYWRlcnMoKTtcbiAgICAgICAgaGVhZGVyLmFwcGVuZChcIkNvbnRlbnQtVHlwZVwiLCBcImFwcGxpY2F0aW9uL2pzb25cIik7XG4gICAgICAgIC8vaWYgKHNlc3Npb25TdG9yYWdlLmdldEl0ZW0oc2VydmljZUNvbmZpZy5hY2Nlc1Rva2VuU3RvcmVOYW1lKSkge1xuICAgICAgICAvLyAgICBoZWFkZXIuYXBwZW5kKHNlcnZpY2VDb25maWcuYWNjZXNUb2tlblJlcXVlc3RIZWFkZXIsIHNlc3Npb25TdG9yYWdlLmdldEl0ZW0oc2VydmljZUNvbmZpZy5hY2Nlc1Rva2VuU3RvcmVOYW1lKSk7XG4gICAgICAgIC8vfSBlbHNlIHtcbiAgICAgICAgLy8gICAgdGhyb3cgJ0FjY2VzcyB0b2tlbiBub3QgYXZhaWxhYmxlJztcbiAgICAgICAgLy99XG4gICAgICAgIHJldHVybiBoZWFkZXI7XG4gICAgfVxuXG5cbiAgICBwdWJsaWMgc2V0Q29va2llKG5hbWU6IHN0cmluZywgdmFsdWU6IE9iamVjdCwgZXhwaXJlRGF5czogbnVtYmVyLCBwYXRoOiBzdHJpbmcgPSBcIlwiKSB7ICAgICAgIC8qZXhwaXJlRGF5czogbnVtYmVyLCovXHJcbiAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICBsZXQgZDogRGF0ZSA9IG5ldyBEYXRlKCk7XHJcbiAgICAgICAgZC5zZXRUaW1lKGQuZ2V0VGltZSgpICsgZXhwaXJlRGF5cyAqIDI0ICogNjAgKiA2MCAqIDEwMDApO1xyXG4gICAgICAgIGxldCBleHBpcmVzOiBzdHJpbmcgPSBcImV4cGlyZXM9XCIgKyBkLnRvVVRDU3RyaW5nKCk7XHJcbiAgICAgICAgZG9jdW1lbnQuY29va2llID0gbmFtZSArIFwiPVwiICsgdmFsdWUgKyBcIjsgXCIgKyBleHBpcmVzICsgKHBhdGgubGVuZ3RoID4gMCA/IFwiOyBwYXRoPVwiICsgcGF0aCA6IFwiXCIpO1xyXG5cclxuICAgICAgICAvL2RvY3VtZW50LmNvb2tpZSA9IG5hbWUgKyBcIj1cIiArIHZhbHVlICsgXCI7IHBhdGg9XCIgKyBwYXRoO1xyXG4gICAgfVxuXG4gICAgcHVibGljIGdldENvb2tpZShuYW1lOiBzdHJpbmcpIHtcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgIGxldCBjYTogQXJyYXk8c3RyaW5nPiA9IGRvY3VtZW50LmNvb2tpZS5zcGxpdCgnOycpO1xyXG4gICAgICAgIGxldCBjYUxlbjogbnVtYmVyID0gY2EubGVuZ3RoO1xyXG4gICAgICAgIGxldCBjb29raWVOYW1lID0gbmFtZSArIFwiPVwiO1xyXG4gICAgICAgIGxldCBjOiBzdHJpbmc7XHJcblxyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBjYUxlbjsgaSArPSAxKSB7XHJcbiAgICAgICAgICAgIGMgPSBjYVtpXS5yZXBsYWNlKC9eXFxzXFwrL2csIFwiXCIpO1xyXG4gICAgICAgICAgICB2YXIgaW5kZXggPSBjLmluZGV4T2YoY29va2llTmFtZSk7XHJcbiAgICAgICAgICAgIGlmIChjLmluZGV4T2YoY29va2llTmFtZSkgPT0gMCkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGMuc3Vic3RyaW5nKGNvb2tpZU5hbWUubGVuZ3RoLCBjLmxlbmd0aCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKGMuaW5kZXhPZihjb29raWVOYW1lKSA9PSAxICYmIGNvb2tpZU5hbWUgPT0gbmFtZStcIj1cIikge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGMuc3Vic3RyaW5nKGNvb2tpZU5hbWUubGVuZ3RoLCBjLmxlbmd0aCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIFwiXCI7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGRlbGV0ZUNvb2tpZShuYW1lKSB7XHJcbiAgICAgICAgdGhpcy5zZXRDb29raWUobmFtZSwgXCJcIiwgLTEpO1xyXG4gICAgfVxuXG5cbiAgICBwdWJsaWMgTG9hZExhbmd1YWdlUmVzb3VyY2UoY29kZTogc3RyaW5nID0gXCJoZVwiKSB7XHJcbiAgICAgICAgLy8gdGhlIGZ1bmN0aW9uIGlzIG5vdCBpbiB1c2VcclxuICAgIH1cblxuXG4gICAgcHVibGljIEdldFNlbGVjZXRkTGFuZ3VhZ2UoY29kZT86IHN0cmluZykge1xuICAgICAgICAvL2RlYnVnZ2VyO1xuICAgICAgICBpZighY29kZSljb2RlPVwiZW5cIjtcbiAgICAgICAgY29kZSA9IGNvZGUudHJpbSgpO1xuICAgICAgIC8vIGRlYnVnZ2VyO1xuICAgICAgICAvLyxcbiAgICAgICAgLy97IGhlYWRlcnM6IHRoaXMuaGVhZGVycyB9XG4gICAgICAgIHJldHVybiB0aGlzLl9odHRwLmdldChcbiAgICAgICAgICAgIFwiL3NyYy9sYW5nL1wiK2NvZGUrXCIuanNvblwiKVxuICAgICAgICAgICAgLm1hcChcbiAgICAgICAgICAgIHJlcyA9PiByZXMuanNvbigpXG4gICAgICAgICAgICApO1xuICAgIH1cblxuICAgIHB1YmxpYyBHZXRBdmFpbGFibGVMYW5ndWFnZXMoKTpbT2JqZWN0XXtcbiAgICAgICAgcmV0dXJuIFtcbiAgICAgICAgICAgIHtuYW1lOlwiRW5nbGlzaFwiLCBjb2RlOlwiZW5cIn0sXG4gICAgICAgICAgICB7bmFtZTpcItei1rTXkdeo1rTXmdeqXCIsIGNvZGU6XCJoZVwifVxuICAgICAgICBdO1xuICAgIH1cblxuICAgIHB1YmxpYyBHZXRNZW51ZXMoKSB7XG4gICAgICAgXG4gICAgICAgIHZhciBsYW5nID0gdGhpcy5nZXRDb29raWUoXCJsYW5nXCIpO1xuICAgICAgICAvL2FsZXJ0KGxhbmcpO1xuICAgICAgICBpZiAobGFuZy5sZW5ndGggPiAwKVxuICAgICAgICAgICAgbGFuZyA9IGxhbmcuc3Vic3RyaW5nKDEsIGxhbmcubGVuZ3RoKTtcbiAgICAgICAgaWYgKGxhbmcgPT0gXCJcIilcbiAgICAgICAgICAgIGxhbmcgPSBcImVuXCI7XG4gICAgICAgIHJldHVybiBuZXcgUHJvbWlzZShyZXNvbHZlPT5cbiAgICAgICAgICAgIHRoaXMuX2h0dHAuZ2V0KFxuICAgICAgICAgICAgICAgIFwiL3NyYy9tZW51LVwiICsgbGFuZytcIi5qc29uXCIsXG4gICAgICAgICAgICAgICAgeyBoZWFkZXJzOiB0aGlzLmhlYWRlcnMgfSlcbiAgICAgICAgICAgICAgICAubWFwKHJlcyA9PnJlcy5qc29uKCkubWVudSlcbiAgICAgICAgICAgICAgICAuc3Vic2NyaWJlKG1lbnVkYXRhPT4ge1xuICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZShtZW51ZGF0YSk7XG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgKVxuICAgIH1cblxuICAgIHB1YmxpYyBHZXRGb3JtQnlOYW1lKGZvcm1OYW1lOnN0cmluZyl7XG4gICAgICAgIHJldHVybiB0aGlzLl9odHRwLmdldChcIi9zcmMvZm9ybXMvXCIrZm9ybU5hbWUrXCIuanNvblwiLHtoZWFkZXJzOnRoaXMuaGVhZGVyc30pXG4gICAgICAgICAgICAubWFwKHJlcz0+cmVzLmpzb24oKSk7XG5cbiAgICAgICAgLy9yZXR1cm4gbmV3IFByb21pc2UocmVzb2x2ZT0+e1xuICAgICAgICAvLyAgICB0aGlzLl9odHRwLmdldChcIi9zcmMvZm9ybXMvXCIrZm9ybU5hbWUrXCIuanNvblwiLHtoZWFkZXJzOnRoaXMuaGVhZGVyc30pXG4gICAgICAgIC8vICAgICAgICAubWFwKHJlcz0+cmVzLmpzb24oKSlcbiAgICAgICAgLy8gICAgICAgIC5zdWJzY3JpYmUoZGF0YT0+cmVzb2x2ZShkYXRhKSk7XG4gICAgICAgIC8vfSlcbiAgICB9XG5cclxuICAgIC8vbG9jYWxzdG9yYWdlIHV0aWxpdHlcclxuICAgIHB1YmxpYyBHZXRMb2NhbFN0b3JhZ2Uoa2V5OiBzdHJpbmcpOiBhbnkge1xyXG4gICAgICAgIHZhciBkYXRhID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oa2V5KTtcclxuICAgICAgICByZXR1cm4gSlNPTi5wYXJzZShkYXRhKTtcclxuICAgIH1cclxuICAgIHB1YmxpYyBTZXRMb2NhbFN0b3JhZ2Uoa2V5OiBzdHJpbmcsIGRhdGE6IGFueSkge1xyXG4gICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKGtleSwgSlNPTi5zdHJpbmdpZnkoZGF0YSkpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vc2Vzc2lvblN0b3JhZ2UgdXRpbGl0eVxyXG4gICAgcHVibGljIEdldFNlc3Npb25TdG9yYWdlKGtleTogc3RyaW5nKTogYW55IHtcclxuICAgICAgICB2YXIgZGF0YSA9IHNlc3Npb25TdG9yYWdlLmdldEl0ZW0oa2V5KTtcclxuICAgICAgICByZXR1cm4gSlNPTi5wYXJzZShkYXRhKTtcclxuICAgIH1cclxuICAgIHB1YmxpYyBTZXRTZXNzaW9uU3RvcmFnZShrZXk6IHN0cmluZywgZGF0YTogYW55KSB7XHJcbiAgICAgICAgc2Vzc2lvblN0b3JhZ2Uuc2V0SXRlbShrZXksIEpTT04uc3RyaW5naWZ5KGRhdGEpKTtcclxuICAgIH1cbiAgICBwdWJsaWMgR2V0TGFuZ1JlcyhGb3JtVHlwZTogc3RyaW5nLCBMYW5nOiBzdHJpbmcpOiBPYnNlcnZhYmxlIHtcbiAgICAgICAgLy9hbGVydChGb3JtVHlwZSk7XG4gICAgICAgIC8vZGVidWdnZXI7XG4gICAgICAgIC8vdmFyIExhbmcgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImxhbmdcIik7XG4gICAgICAgIHJldHVybiB0aGlzLl9odHRwLmdldChcbiAgICAgICAgICAgIHRoaXMuYmFzZVVybCArIFwiRHJvcGRvd24vR2V0TGFuZ1Jlcz9Gb3JtVHlwZT1cIiArIEZvcm1UeXBlICsgXCImTGFuZz1cIiArIExhbmcsXG4gICAgICAgICAgICB7IGhlYWRlcnM6IHRoaXMuZ2V0SGVhZGVyKCkgfVxuICAgICAgICApLm1hcChyZXM9PiByZXMudGV4dCgpKTtcbiAgICB9XG59Il19
