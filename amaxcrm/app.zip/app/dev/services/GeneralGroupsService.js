System.register(['angular2/core', 'angular2/http', 'rxjs/add/operator/map', '../crmconfig'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, http_1, crmconfig_1;
    var GeneralGroupsService;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (http_1_1) {
                http_1 = http_1_1;
            },
            function (_1) {},
            function (crmconfig_1_1) {
                crmconfig_1 = crmconfig_1_1;
            }],
        execute: function() {
            GeneralGroupsService = (function () {
                function GeneralGroupsService(http) {
                    this.http = http;
                    this.baseUrl = crmconfig_1.serviceConfig.serviceApiUrl;
                }
                GeneralGroupsService.prototype.getHeader = function () {
                    var header = new http_1.Headers();
                    header.append("Content-Type", "application/json");
                    if (sessionStorage.getItem(crmconfig_1.serviceConfig.accesTokenStoreName)) {
                        header.append(crmconfig_1.serviceConfig.accesTokenRequestHeader, sessionStorage.getItem(crmconfig_1.serviceConfig.accesTokenStoreName));
                    }
                    else {
                        throw 'Access token not available';
                    }
                    return header;
                };
                GeneralGroupsService.prototype.GetCompleteCustDet = function (GroupIds) {
                    //var Lang = localStorage.getItem("lang");
                    return this.http.get(this.baseUrl + "GeneralGroups/GetCustomersListOfGroups?GroupIds=" + GroupIds, { headers: this.getHeader() }).map(function (res) { return res.text(); });
                };
                GeneralGroupsService = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [http_1.Http])
                ], GeneralGroupsService);
                return GeneralGroupsService;
            }());
            exports_1("GeneralGroupsService", GeneralGroupsService);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldi9zZXJ2aWNlcy9HZW5lcmFsR3JvdXBzU2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7WUFPQTtnQkFFSSw4QkFBb0IsSUFBVTtvQkFBVixTQUFJLEdBQUosSUFBSSxDQUFNO29CQUMxQixJQUFJLENBQUMsT0FBTyxHQUFHLHlCQUFhLENBQUMsYUFBYSxDQUFDO2dCQUMvQyxDQUFDO2dCQUVPLHdDQUFTLEdBQWpCO29CQUNJLElBQUksTUFBTSxHQUFHLElBQUksY0FBTyxFQUFFLENBQUM7b0JBQzNCLE1BQU0sQ0FBQyxNQUFNLENBQUMsY0FBYyxFQUFFLGtCQUFrQixDQUFDLENBQUM7b0JBQ2xELEVBQUUsQ0FBQSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMseUJBQWEsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUEsQ0FBQzt3QkFDMUQsTUFBTSxDQUFDLE1BQU0sQ0FBQyx5QkFBYSxDQUFDLHVCQUF1QixFQUFFLGNBQWMsQ0FBQyxPQUFPLENBQUMseUJBQWEsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUM7b0JBQ3BILENBQUM7b0JBQUEsSUFBSSxDQUFDLENBQUM7d0JBQ0gsTUFBTSw0QkFBNEIsQ0FBQztvQkFDdkMsQ0FBQztvQkFDRCxNQUFNLENBQUMsTUFBTSxDQUFDO2dCQUNsQixDQUFDO2dCQUNNLGlEQUFrQixHQUF6QixVQUEwQixRQUFRO29CQUM5QiwwQ0FBMEM7b0JBRTFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FDaEIsSUFBSSxDQUFDLE9BQU8sR0FBRyxrREFBa0QsR0FBRyxRQUFRLEVBQzVFLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxTQUFTLEVBQUUsRUFBRSxDQUNoQyxDQUFDLEdBQUcsQ0FBQyxVQUFBLEdBQUcsSUFBRyxPQUFBLEdBQUcsQ0FBQyxJQUFJLEVBQUUsRUFBVixDQUFVLENBQUMsQ0FBQztnQkFDNUIsQ0FBQztnQkF4Qkw7b0JBQUMsaUJBQVUsRUFBRTs7d0NBQUE7Z0JBeUJiLDJCQUFDO1lBQUQsQ0F4QkEsQUF3QkMsSUFBQTtZQXhCRCx1REF3QkMsQ0FBQSIsImZpbGUiOiJkZXYvc2VydmljZXMvR2VuZXJhbEdyb3Vwc1NlcnZpY2UuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnYW5ndWxhcjIvY29yZSc7XG5pbXBvcnQgeyBIdHRwLCBIZWFkZXJzICB9IGZyb20gJ2FuZ3VsYXIyL2h0dHAnO1xuaW1wb3J0ICdyeGpzL2FkZC9vcGVyYXRvci9tYXAnO1xuaW1wb3J0IHtPYnNlcnZhYmxlfSBmcm9tIFwicnhqcy9PYnNlcnZhYmxlXCI7XG5pbXBvcnQge3NlcnZpY2VDb25maWd9IGZyb20gJy4uL2NybWNvbmZpZyc7XG5cbkBJbmplY3RhYmxlKClcbmV4cG9ydCBjbGFzcyBHZW5lcmFsR3JvdXBzU2VydmljZSB7XG4gICAgYmFzZVVybDogc3RyaW5nO1xuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgaHR0cDogSHR0cCkge1xuICAgICAgICB0aGlzLmJhc2VVcmwgPSBzZXJ2aWNlQ29uZmlnLnNlcnZpY2VBcGlVcmw7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBnZXRIZWFkZXIoKTpIZWFkZXJze1xuICAgICAgICB2YXIgaGVhZGVyID0gbmV3IEhlYWRlcnMoKTtcbiAgICAgICAgaGVhZGVyLmFwcGVuZChcIkNvbnRlbnQtVHlwZVwiLCBcImFwcGxpY2F0aW9uL2pzb25cIik7XG4gICAgICAgIGlmKHNlc3Npb25TdG9yYWdlLmdldEl0ZW0oc2VydmljZUNvbmZpZy5hY2Nlc1Rva2VuU3RvcmVOYW1lKSl7XG4gICAgICAgICAgICBoZWFkZXIuYXBwZW5kKHNlcnZpY2VDb25maWcuYWNjZXNUb2tlblJlcXVlc3RIZWFkZXIsIHNlc3Npb25TdG9yYWdlLmdldEl0ZW0oc2VydmljZUNvbmZpZy5hY2Nlc1Rva2VuU3RvcmVOYW1lKSk7XG4gICAgICAgIH1lbHNlIHtcbiAgICAgICAgICAgIHRocm93ICdBY2Nlc3MgdG9rZW4gbm90IGF2YWlsYWJsZSc7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGhlYWRlcjtcbiAgICB9XG4gICAgcHVibGljIEdldENvbXBsZXRlQ3VzdERldChHcm91cElkcyk6IE9ic2VydmFibGUge1xuICAgICAgICAvL3ZhciBMYW5nID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJsYW5nXCIpO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0KFxuICAgICAgICAgICAgdGhpcy5iYXNlVXJsICsgXCJHZW5lcmFsR3JvdXBzL0dldEN1c3RvbWVyc0xpc3RPZkdyb3Vwcz9Hcm91cElkcz1cIiArIEdyb3VwSWRzLFxuICAgICAgICAgICAgeyBoZWFkZXJzOiB0aGlzLmdldEhlYWRlcigpIH1cbiAgICAgICAgKS5tYXAocmVzPT4gcmVzLnRleHQoKSk7XG4gICAgfVxufSJdfQ==
