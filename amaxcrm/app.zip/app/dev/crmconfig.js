System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var crmConfig, serviceConfig, LocalDict, SessionlDict;
    return {
        setters:[],
        execute: function() {
            crmConfig = {
                version: "1.0.0.22",
                minSvcVersion: "",
                minDbsVersion: "",
                falbackLanguage: "he"
            };
            serviceConfig = {
                serviceBaseUrl: "http://localhost/amaxweb/Api.svc/",
                serviceApiUrl: "http://localhost:57998/API/",
                AppUrl: "http://localhost:3000/#/",
                accesTokenStoreName: "XToken",
                accesTokenRequestHeader: "X-Token",
                accesTokenResponceHeader: "XToken",
                authenticationMode: "JWT-Token"
            };
            exports_1("LocalDict", LocalDict = {
                userCredential: "userCredential",
                selectedLanguage: "preferedLanguage",
                languageResource: "languageResource",
                SmsSettings: "smsSettings"
            });
            exports_1("SessionlDict", SessionlDict = {});
            if (window.location.href.indexOf("127.0.0.1") > -1)
                serviceConfig.serviceBaseUrl = "http://localhost:57998/Api.svc/";
            exports_1("serviceConfig", serviceConfig);
            exports_1("crmConfig", crmConfig);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldi9jcm1jb25maWcudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O1FBQUksU0FBUyxFQU1ULGFBQWEsRUFXTixTQUFTLEVBT1QsWUFBWTs7OztZQXhCbkIsU0FBUyxHQUFHO2dCQUNaLE9BQU8sRUFBRSxVQUFVO2dCQUNuQixhQUFhLEVBQUUsRUFBRTtnQkFDakIsYUFBYSxFQUFFLEVBQUU7Z0JBQ2pCLGVBQWUsRUFBRSxJQUFJO2FBQ3hCLENBQUM7WUFDRSxhQUFhLEdBQUc7Z0JBQ2hCLGNBQWMsRUFBRSxtQ0FBbUM7Z0JBQ25ELGFBQWEsRUFBRSw2QkFBNkI7Z0JBQzVDLE1BQU0sRUFBRSwwQkFBMEI7Z0JBQ2xDLG1CQUFtQixFQUFDLFFBQVE7Z0JBQzVCLHVCQUF1QixFQUFDLFNBQVM7Z0JBQ2pDLHdCQUF3QixFQUFDLFFBQVE7Z0JBR2pDLGtCQUFrQixFQUFDLFdBQVc7YUFDakMsQ0FBQTtZQUNVLHVCQUFBLFNBQVMsR0FBRztnQkFDbkIsY0FBYyxFQUFFLGdCQUFnQjtnQkFDaEMsZ0JBQWdCLEVBQUUsa0JBQWtCO2dCQUNwQyxnQkFBZ0IsRUFBRSxrQkFBa0I7Z0JBQ3BDLFdBQVcsRUFBRSxhQUFhO2FBQzdCLENBQUEsQ0FBQTtZQUVVLDBCQUFBLFlBQVksR0FBRyxFQUV6QixDQUFBLENBQUE7WUFDRCxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7Z0JBQy9DLGFBQWEsQ0FBQyxjQUFjLEdBQUUsaUNBQWlDLENBQUM7WUFFcEUseUNBQWE7WUFDYixpQ0FBUyIsImZpbGUiOiJkZXYvY3JtY29uZmlnLmpzIiwic291cmNlc0NvbnRlbnQiOlsibGV0IGNybUNvbmZpZyA9IHtcclxuICAgIHZlcnNpb246IFwiMS4wLjAuMjJcIixcclxuICAgIG1pblN2Y1ZlcnNpb246IFwiXCIsXHJcbiAgICBtaW5EYnNWZXJzaW9uOiBcIlwiLFxyXG4gICAgZmFsYmFja0xhbmd1YWdlOiBcImhlXCJcclxufTtcbmxldCBzZXJ2aWNlQ29uZmlnID0ge1xuICAgIHNlcnZpY2VCYXNlVXJsOiBcImh0dHA6Ly9sb2NhbGhvc3QvYW1heHdlYi9BcGkuc3ZjL1wiLFxuICAgIHNlcnZpY2VBcGlVcmw6IFwiaHR0cDovL2xvY2FsaG9zdDo1Nzk5OC9BUEkvXCIsXG4gICAgQXBwVXJsOiBcImh0dHA6Ly9sb2NhbGhvc3Q6MzAwMC8jL1wiLFxuICAgIGFjY2VzVG9rZW5TdG9yZU5hbWU6XCJYVG9rZW5cIixcbiAgICBhY2Nlc1Rva2VuUmVxdWVzdEhlYWRlcjpcIlgtVG9rZW5cIixcbiAgICBhY2Nlc1Rva2VuUmVzcG9uY2VIZWFkZXI6XCJYVG9rZW5cIixcbiAgICBcblxuICAgIGF1dGhlbnRpY2F0aW9uTW9kZTpcIkpXVC1Ub2tlblwiXG59XG5leHBvcnQgdmFyIExvY2FsRGljdCA9IHtcclxuICAgIHVzZXJDcmVkZW50aWFsOiBcInVzZXJDcmVkZW50aWFsXCIsXHJcbiAgICBzZWxlY3RlZExhbmd1YWdlOiBcInByZWZlcmVkTGFuZ3VhZ2VcIixcclxuICAgIGxhbmd1YWdlUmVzb3VyY2U6IFwibGFuZ3VhZ2VSZXNvdXJjZVwiLFxyXG4gICAgU21zU2V0dGluZ3M6IFwic21zU2V0dGluZ3NcIlxyXG59XHJcblxyXG5leHBvcnQgdmFyIFNlc3Npb25sRGljdCA9IHtcclxuXHJcbn1cclxuaWYgKHdpbmRvdy5sb2NhdGlvbi5ocmVmLmluZGV4T2YoXCIxMjcuMC4wLjFcIikgPiAtMSlcbiAgICBzZXJ2aWNlQ29uZmlnLnNlcnZpY2VCYXNlVXJsID1cImh0dHA6Ly9sb2NhbGhvc3Q6NTc5OTgvQXBpLnN2Yy9cIjtcbmV4cG9ydCB7XG5zZXJ2aWNlQ29uZmlnLFxuY3JtQ29uZmlnXG59Il19
