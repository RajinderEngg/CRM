System.register(['./latin-map'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var latin_map_1;
    var AutocompleteUtils;
    return {
        setters:[
            function (latin_map_1_1) {
                latin_map_1 = latin_map_1_1;
            }],
        execute: function() {
            AutocompleteUtils = (function () {
                function AutocompleteUtils() {
                }
                AutocompleteUtils.latinize = function (str) {
                    return str.replace(/[^A-Za-z0-9\[\] ]/g, function (a) {
                        return AutocompleteUtils.latinMap[a] || a;
                    });
                };
                AutocompleteUtils.escapeRegexp = function (queryToEscape) {
                    // Regex: capture the whole query string and replace it with the string that will be used to match
                    // the results, for example if the capture is 'a' the result will be \a
                    return queryToEscape.replace(/([.?*+^$[\]\\(){}|-])/g, '\\$1');
                };
                AutocompleteUtils.tokenize = function (str, wordRegexDelimiters, phraseRegexDelimiters) {
                    if (wordRegexDelimiters === void 0) { wordRegexDelimiters = ' '; }
                    if (phraseRegexDelimiters === void 0) { phraseRegexDelimiters = ''; }
                    var regexStr = '(?:[' + phraseRegexDelimiters + '])([^' + phraseRegexDelimiters + ']+)(?:[' + phraseRegexDelimiters + '])|([^' + wordRegexDelimiters + ']+)';
                    var preTokenized = str.split(new RegExp(regexStr, 'g'));
                    var result = [];
                    var preTokenizedLength = preTokenized.length;
                    var token;
                    var replacePhraseDelimiters = new RegExp('[' + phraseRegexDelimiters + ']+', 'g');
                    for (var i = 0; i < preTokenizedLength; i += 1) {
                        token = preTokenized[i];
                        if (token && token.length && token !== wordRegexDelimiters) {
                            result.push(token.replace(replacePhraseDelimiters, ''));
                        }
                    }
                    return result;
                };
                AutocompleteUtils.latinMap = latin_map_1.latinMap;
                return AutocompleteUtils;
            }());
            exports_1("AutocompleteUtils", AutocompleteUtils);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldi9hdXRvY29tcGxldGUvc2FuaXRpemUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7WUFDQTtnQkFBQTtnQkFnQ0EsQ0FBQztnQkE3QmlCLDBCQUFRLEdBQXRCLFVBQXVCLEdBQVU7b0JBQzdCLE1BQU0sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLG9CQUFvQixFQUFFLFVBQVUsQ0FBQzt3QkFDaEQsTUFBTSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBQzlDLENBQUMsQ0FBQyxDQUFDO2dCQUNQLENBQUM7Z0JBRWEsOEJBQVksR0FBMUIsVUFBMkIsYUFBb0I7b0JBQzNDLGtHQUFrRztvQkFDbEcsdUVBQXVFO29CQUN2RSxNQUFNLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyx3QkFBd0IsRUFBRSxNQUFNLENBQUMsQ0FBQztnQkFDbkUsQ0FBQztnQkFFYSwwQkFBUSxHQUF0QixVQUF1QixHQUFVLEVBQUUsbUJBQWdDLEVBQUUscUJBQWlDO29CQUFuRSxtQ0FBZ0MsR0FBaEMseUJBQWdDO29CQUFFLHFDQUFpQyxHQUFqQywwQkFBaUM7b0JBQ2xHLElBQUksUUFBUSxHQUFVLE1BQU0sR0FBRyxxQkFBcUIsR0FBRyxPQUFPLEdBQUcscUJBQXFCLEdBQUcsU0FBUyxHQUFHLHFCQUFxQixHQUFHLFFBQVEsR0FBRyxtQkFBbUIsR0FBRyxLQUFLLENBQUM7b0JBQ3BLLElBQUksWUFBWSxHQUFpQixHQUFHLENBQUMsS0FBSyxDQUFDLElBQUksTUFBTSxDQUFDLFFBQVEsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDO29CQUN0RSxJQUFJLE1BQU0sR0FBaUIsRUFBRSxDQUFDO29CQUM5QixJQUFJLGtCQUFrQixHQUFVLFlBQVksQ0FBQyxNQUFNLENBQUM7b0JBQ3BELElBQUksS0FBWSxDQUFDO29CQUNqQixJQUFJLHVCQUF1QixHQUFHLElBQUksTUFBTSxDQUFDLEdBQUcsR0FBRyxxQkFBcUIsR0FBRyxJQUFJLEVBQUUsR0FBRyxDQUFDLENBQUM7b0JBRWxGLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsa0JBQWtCLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDO3dCQUM3QyxLQUFLLEdBQUcsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUN4QixFQUFFLENBQUMsQ0FBQyxLQUFLLElBQUksS0FBSyxDQUFDLE1BQU0sSUFBSSxLQUFLLEtBQUssbUJBQW1CLENBQUMsQ0FBQyxDQUFDOzRCQUN6RCxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsdUJBQXVCLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQzt3QkFDNUQsQ0FBQztvQkFDTCxDQUFDO29CQUVELE1BQU0sQ0FBQyxNQUFNLENBQUM7Z0JBQ2xCLENBQUM7Z0JBOUJNLDBCQUFRLEdBQU8sb0JBQVEsQ0FBQztnQkErQm5DLHdCQUFDO1lBQUQsQ0FoQ0EsQUFnQ0MsSUFBQTtZQWhDRCxpREFnQ0MsQ0FBQSIsImZpbGUiOiJkZXYvYXV0b2NvbXBsZXRlL3Nhbml0aXplLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgbGF0aW5NYXAgfSBmcm9tICcuL2xhdGluLW1hcCc7XG5leHBvcnQgY2xhc3MgQXV0b2NvbXBsZXRlVXRpbHMge1xuICAgIHN0YXRpYyBsYXRpbk1hcDphbnkgPSBsYXRpbk1hcDtcblxuICAgIHB1YmxpYyBzdGF0aWMgbGF0aW5pemUoc3RyOnN0cmluZykge1xuICAgICAgICByZXR1cm4gc3RyLnJlcGxhY2UoL1teQS1aYS16MC05XFxbXFxdIF0vZywgZnVuY3Rpb24gKGEpIHtcbiAgICAgICAgICAgIHJldHVybiBBdXRvY29tcGxldGVVdGlscy5sYXRpbk1hcFthXSB8fCBhO1xuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICBwdWJsaWMgc3RhdGljIGVzY2FwZVJlZ2V4cChxdWVyeVRvRXNjYXBlOnN0cmluZykge1xuICAgICAgICAvLyBSZWdleDogY2FwdHVyZSB0aGUgd2hvbGUgcXVlcnkgc3RyaW5nIGFuZCByZXBsYWNlIGl0IHdpdGggdGhlIHN0cmluZyB0aGF0IHdpbGwgYmUgdXNlZCB0byBtYXRjaFxuICAgICAgICAvLyB0aGUgcmVzdWx0cywgZm9yIGV4YW1wbGUgaWYgdGhlIGNhcHR1cmUgaXMgJ2EnIHRoZSByZXN1bHQgd2lsbCBiZSBcXGFcbiAgICAgICAgcmV0dXJuIHF1ZXJ5VG9Fc2NhcGUucmVwbGFjZSgvKFsuPyorXiRbXFxdXFxcXCgpe318LV0pL2csICdcXFxcJDEnKTtcbiAgICB9XG5cbiAgICBwdWJsaWMgc3RhdGljIHRva2VuaXplKHN0cjpzdHJpbmcsIHdvcmRSZWdleERlbGltaXRlcnM6c3RyaW5nID0gJyAnLCBwaHJhc2VSZWdleERlbGltaXRlcnM6c3RyaW5nID0gJycpOkFycmF5PHN0cmluZz4ge1xuICAgICAgICBsZXQgcmVnZXhTdHI6c3RyaW5nID0gJyg/OlsnICsgcGhyYXNlUmVnZXhEZWxpbWl0ZXJzICsgJ10pKFteJyArIHBocmFzZVJlZ2V4RGVsaW1pdGVycyArICddKykoPzpbJyArIHBocmFzZVJlZ2V4RGVsaW1pdGVycyArICddKXwoW14nICsgd29yZFJlZ2V4RGVsaW1pdGVycyArICddKyknO1xuICAgICAgICBsZXQgcHJlVG9rZW5pemVkOkFycmF5PHN0cmluZz4gPSBzdHIuc3BsaXQobmV3IFJlZ0V4cChyZWdleFN0ciwgJ2cnKSk7XG4gICAgICAgIGxldCByZXN1bHQ6QXJyYXk8c3RyaW5nPiA9IFtdO1xuICAgICAgICBsZXQgcHJlVG9rZW5pemVkTGVuZ3RoOm51bWJlciA9IHByZVRva2VuaXplZC5sZW5ndGg7XG4gICAgICAgIGxldCB0b2tlbjpzdHJpbmc7XG4gICAgICAgIGxldCByZXBsYWNlUGhyYXNlRGVsaW1pdGVycyA9IG5ldyBSZWdFeHAoJ1snICsgcGhyYXNlUmVnZXhEZWxpbWl0ZXJzICsgJ10rJywgJ2cnKTtcblxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHByZVRva2VuaXplZExlbmd0aDsgaSArPSAxKSB7XG4gICAgICAgICAgICB0b2tlbiA9IHByZVRva2VuaXplZFtpXTtcbiAgICAgICAgICAgIGlmICh0b2tlbiAmJiB0b2tlbi5sZW5ndGggJiYgdG9rZW4gIT09IHdvcmRSZWdleERlbGltaXRlcnMpIHtcbiAgICAgICAgICAgICAgICByZXN1bHQucHVzaCh0b2tlbi5yZXBsYWNlKHJlcGxhY2VQaHJhc2VEZWxpbWl0ZXJzLCAnJykpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG59Il19
