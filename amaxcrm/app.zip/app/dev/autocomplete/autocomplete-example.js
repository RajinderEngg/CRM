/**
 * Created by Tareq Boulakjar. from angulartypescript.com
 */
System.register(['angular2/core', 'angular2/common', './autocomplete-container', './autocomplete.component'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, common_1, autocomplete_container_1, autocomplete_component_1;
    var AUTOCOMPLETE_DIRECTIVES, Angular2Autocomplete;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (autocomplete_container_1_1) {
                autocomplete_container_1 = autocomplete_container_1_1;
            },
            function (autocomplete_component_1_1) {
                autocomplete_component_1 = autocomplete_component_1_1;
            }],
        execute: function() {
            exports_1("AUTOCOMPLETE_DIRECTIVES", AUTOCOMPLETE_DIRECTIVES = [autocomplete_component_1.Autocomplete, autocomplete_container_1.AutocompleteContainer]);
            /*Angular 2 Autocomplete Example*/
            Angular2Autocomplete = (function () {
                function Angular2Autocomplete() {
                    this.selectedCar = '';
                    this.asyncSelectedCar = '';
                    this.autocompleteLoading = false;
                    this.autocompleteNoResults = false;
                    this.carsExample1 = ['BMW', 'Audi', 'Mercedes', 'Porsche', 'Volkswagen', 'Opel', 'Maserati', 'Volkswagen', 'BMW Serie 1', 'BMW Serie 2'];
                    this.carsExample2 = [
                        { id: 1, name: 'BMW' },
                        { id: 2, name: 'Audi' },
                        { id: 3, name: 'Mercedes' },
                        { id: 4, name: 'Porsche' },
                        { id: 5, name: 'Volkswagen' },
                        { id: 6, name: 'Opel' },
                        { id: 7, name: 'Maserati' },
                        { id: 8, name: 'Volkswagen' },
                        { id: 9, name: 'BMW Serie 1' },
                        { id: 10, name: 'BMW Serie 2' },
                    ];
                }
                Angular2Autocomplete.prototype.getCurrentContext = function () {
                    return this;
                };
                Angular2Autocomplete.prototype.getAsyncData = function (context) {
                    if (this._previousContext === context) {
                        return this._cachedResult;
                    }
                    this._previousContext = context;
                    var f = function () {
                        var p = new Promise(function (resolve) {
                            setTimeout(function () {
                                var query = new RegExp(context.asyncSelectedCar, 'ig');
                                return resolve(context.carsExample1.filter(function (state) {
                                    return query.test(state);
                                }));
                            }, 500);
                        });
                        return p;
                    };
                    this._cachedResult = f;
                    return this._cachedResult;
                };
                Angular2Autocomplete.prototype.changeAutocompleteLoading = function (e) {
                    this.autocompleteLoading = e;
                };
                Angular2Autocomplete.prototype.changeAutocompleteNoResults = function (e) {
                    this.autocompleteNoResults = e;
                };
                Angular2Autocomplete.prototype.autocompleteOnSelect = function (e) {
                    console.log("Selected value: " + e.item);
                };
                Angular2Autocomplete = __decorate([
                    core_1.Component({
                        selector: 'my-app',
                        template: "\n                <div class='container-fluid'>\n                    <h3>Angular 2 Autocomplete Example</h3>\n                    <h4>The Selected Car: {{selectedCar}}</h4>\n                    <input [(ngModel)]=\"selectedCar\"\n                           [autocomplete]=\"carsExample2\"\n                           (autocompleteOnSelect)=\"autocompleteOnSelect($event)\"\n                           [autocompleteOptionField]=\"'name'\"\n                           class=\"form-control\">\n\n                    <h3>Asynchronous results</h3>\n                    <h4>Model: {{asyncSelectedCar}}</h4>\n                    <input [(ngModel)]=\"asyncSelectedCar\"\n                           [autocomplete]=\"getAsyncData(getCurrentContext())\"\n                           (autocompleteLoading)=\"changeAutocompleteLoading($event)\"\n                           (autocompleteNoResults)=\"changeAutocompleteNoResults($event)\"\n                           (autocompleteOnSelect)=\"autocompleteOnSelect($event)\"\n                           [autocompleteOptionsLimit]=\"7\"\n                           placeholder=\"Locations loaded with timeout\"\n                           class=\"form-control\">\n                    <div [hidden]=\"autocompleteLoading!==true\">\n                        <i class=\"glyphicon glyphicon-refresh ng-hide\" style=\"\"></i>\n                    </div>\n                    <div [hidden]=\"autocompleteNoResults!==true\" class=\"\" style=\"\">\n                        <i class=\"glyphicon glyphicon-remove\"></i> Empty Query !\n                    </div>\n                </div>\n               ",
                        directives: [AUTOCOMPLETE_DIRECTIVES, common_1.CORE_DIRECTIVES, common_1.FORM_DIRECTIVES],
                    }), 
                    __metadata('design:paramtypes', [])
                ], Angular2Autocomplete);
                return Angular2Autocomplete;
            }());
            exports_1("Angular2Autocomplete", Angular2Autocomplete);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldi9hdXRvY29tcGxldGUvYXV0b2NvbXBsZXRlLWV4YW1wbGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7O0dBRUc7Ozs7Ozs7Ozs7Ozs7O1FBTVUsdUJBQXVCOzs7Ozs7Ozs7Ozs7Ozs7O1lBQXZCLHFDQUFBLHVCQUF1QixHQUFHLENBQUMscUNBQVksRUFBRSw4Q0FBcUIsQ0FBQyxDQUFBLENBQUM7WUFHN0Usa0NBQWtDO1lBa0NsQztnQkFBQTtvQkFDWSxnQkFBVyxHQUFVLEVBQUUsQ0FBQztvQkFDeEIscUJBQWdCLEdBQVUsRUFBRSxDQUFDO29CQUM3Qix3QkFBbUIsR0FBVyxLQUFLLENBQUM7b0JBQ3BDLDBCQUFxQixHQUFXLEtBQUssQ0FBQztvQkFDdEMsaUJBQVksR0FBaUIsQ0FBQyxLQUFLLEVBQUUsTUFBTSxFQUFDLFVBQVUsRUFBQyxTQUFTLEVBQUMsWUFBWSxFQUFDLE1BQU0sRUFBQyxVQUFVLEVBQUMsWUFBWSxFQUFDLGFBQWEsRUFBQyxhQUFhLENBQUMsQ0FBQztvQkFDMUksaUJBQVksR0FBYzt3QkFDOUIsRUFBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUM7d0JBQ3BCLEVBQUMsRUFBRSxFQUFFLENBQUMsRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFDO3dCQUNyQixFQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUUsSUFBSSxFQUFFLFVBQVUsRUFBQzt3QkFDekIsRUFBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUM7d0JBQ3hCLEVBQUMsRUFBRSxFQUFFLENBQUMsRUFBRSxJQUFJLEVBQUUsWUFBWSxFQUFDO3dCQUMzQixFQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBQzt3QkFDckIsRUFBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFLElBQUksRUFBRSxVQUFVLEVBQUM7d0JBQ3pCLEVBQUMsRUFBRSxFQUFFLENBQUMsRUFBRSxJQUFJLEVBQUUsWUFBWSxFQUFDO3dCQUMzQixFQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUUsSUFBSSxFQUFFLGFBQWEsRUFBQzt3QkFDNUIsRUFBQyxFQUFFLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxhQUFhLEVBQUM7cUJBQ2hDLENBQUM7Z0JBMENOLENBQUM7Z0JBdkNXLGdEQUFpQixHQUF6QjtvQkFDSSxNQUFNLENBQUMsSUFBSSxDQUFDO2dCQUNoQixDQUFDO2dCQUtPLDJDQUFZLEdBQXBCLFVBQXFCLE9BQVc7b0JBQzVCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsS0FBSyxPQUFPLENBQUMsQ0FBQyxDQUFDO3dCQUNwQyxNQUFNLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQztvQkFDOUIsQ0FBQztvQkFFRCxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsT0FBTyxDQUFDO29CQUNoQyxJQUFJLENBQUMsR0FBWTt3QkFDYixJQUFJLENBQUMsR0FBcUIsSUFBSSxPQUFPLENBQUMsVUFBQyxPQUFnQjs0QkFDbkQsVUFBVSxDQUFDO2dDQUNQLElBQUksS0FBSyxHQUFHLElBQUksTUFBTSxDQUFDLE9BQU8sQ0FBQyxnQkFBZ0IsRUFBRSxJQUFJLENBQUMsQ0FBQztnQ0FDdkQsTUFBTSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxVQUFDLEtBQVM7b0NBQ2pELE1BQU0sQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dDQUM3QixDQUFDLENBQUMsQ0FBQyxDQUFDOzRCQUNSLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQzt3QkFDWixDQUFDLENBQUMsQ0FBQzt3QkFDSCxNQUFNLENBQUMsQ0FBQyxDQUFDO29CQUNiLENBQUMsQ0FBQztvQkFDRixJQUFJLENBQUMsYUFBYSxHQUFHLENBQUMsQ0FBQztvQkFDdkIsTUFBTSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUM7Z0JBQzlCLENBQUM7Z0JBRU8sd0RBQXlCLEdBQWpDLFVBQWtDLENBQVM7b0JBQ3ZDLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxDQUFDLENBQUM7Z0JBQ2pDLENBQUM7Z0JBRU8sMERBQTJCLEdBQW5DLFVBQW9DLENBQVM7b0JBQ3pDLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxDQUFDLENBQUM7Z0JBQ25DLENBQUM7Z0JBRU8sbURBQW9CLEdBQTVCLFVBQTZCLENBQUs7b0JBQzlCLE9BQU8sQ0FBQyxHQUFHLENBQUMscUJBQW1CLENBQUMsQ0FBQyxJQUFNLENBQUMsQ0FBQztnQkFDN0MsQ0FBQztnQkEzRkw7b0JBQUMsZ0JBQVMsQ0FBQzt3QkFDUCxRQUFRLEVBQUUsUUFBUTt3QkFFbEIsUUFBUSxFQUFDLHdsREEyQkc7d0JBQ1osVUFBVSxFQUFFLENBQUMsdUJBQXVCLEVBQUUsd0JBQWUsRUFBRSx3QkFBZSxDQUFDO3FCQUMxRSxDQUFDOzt3Q0FBQTtnQkE0REYsMkJBQUM7WUFBRCxDQTNEQSxBQTJEQyxJQUFBO1lBM0RELHVEQTJEQyxDQUFBIiwiZmlsZSI6ImRldi9hdXRvY29tcGxldGUvYXV0b2NvbXBsZXRlLWV4YW1wbGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIENyZWF0ZWQgYnkgVGFyZXEgQm91bGFramFyLiBmcm9tIGFuZ3VsYXJ0eXBlc2NyaXB0LmNvbVxuICovXG5cbmltcG9ydCB7Q29tcG9uZW50LCBFbGVtZW50UmVmLCBWaWV3RW5jYXBzdWxhdGlvbn0gZnJvbSAnYW5ndWxhcjIvY29yZSc7XG5pbXBvcnQge0NPUkVfRElSRUNUSVZFUywgRk9STV9ESVJFQ1RJVkVTfSBmcm9tICdhbmd1bGFyMi9jb21tb24nO1xuaW1wb3J0IHtBdXRvY29tcGxldGVDb250YWluZXJ9IGZyb20gJy4vYXV0b2NvbXBsZXRlLWNvbnRhaW5lcic7XG5pbXBvcnQge0F1dG9jb21wbGV0ZX0gZnJvbSAnLi9hdXRvY29tcGxldGUuY29tcG9uZW50JztcbmV4cG9ydCBjb25zdCBBVVRPQ09NUExFVEVfRElSRUNUSVZFUyA9IFtBdXRvY29tcGxldGUsIEF1dG9jb21wbGV0ZUNvbnRhaW5lcl07XG5cblxuLypBbmd1bGFyIDIgQXV0b2NvbXBsZXRlIEV4YW1wbGUqL1xuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdteS1hcHAnLFxuXG4gICAgdGVtcGxhdGU6YFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9J2NvbnRhaW5lci1mbHVpZCc+XG4gICAgICAgICAgICAgICAgICAgIDxoMz5Bbmd1bGFyIDIgQXV0b2NvbXBsZXRlIEV4YW1wbGU8L2gzPlxuICAgICAgICAgICAgICAgICAgICA8aDQ+VGhlIFNlbGVjdGVkIENhcjoge3tzZWxlY3RlZENhcn19PC9oND5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0IFsobmdNb2RlbCldPVwic2VsZWN0ZWRDYXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgW2F1dG9jb21wbGV0ZV09XCJjYXJzRXhhbXBsZTJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgKGF1dG9jb21wbGV0ZU9uU2VsZWN0KT1cImF1dG9jb21wbGV0ZU9uU2VsZWN0KCRldmVudClcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgW2F1dG9jb21wbGV0ZU9wdGlvbkZpZWxkXT1cIiduYW1lJ1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImZvcm0tY29udHJvbFwiPlxuXG4gICAgICAgICAgICAgICAgICAgIDxoMz5Bc3luY2hyb25vdXMgcmVzdWx0czwvaDM+XG4gICAgICAgICAgICAgICAgICAgIDxoND5Nb2RlbDoge3thc3luY1NlbGVjdGVkQ2FyfX08L2g0PlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXQgWyhuZ01vZGVsKV09XCJhc3luY1NlbGVjdGVkQ2FyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIFthdXRvY29tcGxldGVdPVwiZ2V0QXN5bmNEYXRhKGdldEN1cnJlbnRDb250ZXh0KCkpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIChhdXRvY29tcGxldGVMb2FkaW5nKT1cImNoYW5nZUF1dG9jb21wbGV0ZUxvYWRpbmcoJGV2ZW50KVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAoYXV0b2NvbXBsZXRlTm9SZXN1bHRzKT1cImNoYW5nZUF1dG9jb21wbGV0ZU5vUmVzdWx0cygkZXZlbnQpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIChhdXRvY29tcGxldGVPblNlbGVjdCk9XCJhdXRvY29tcGxldGVPblNlbGVjdCgkZXZlbnQpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIFthdXRvY29tcGxldGVPcHRpb25zTGltaXRdPVwiN1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkxvY2F0aW9ucyBsb2FkZWQgd2l0aCB0aW1lb3V0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzPVwiZm9ybS1jb250cm9sXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgW2hpZGRlbl09XCJhdXRvY29tcGxldGVMb2FkaW5nIT09dHJ1ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGkgY2xhc3M9XCJnbHlwaGljb24gZ2x5cGhpY29uLXJlZnJlc2ggbmctaGlkZVwiIHN0eWxlPVwiXCI+PC9pPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBbaGlkZGVuXT1cImF1dG9jb21wbGV0ZU5vUmVzdWx0cyE9PXRydWVcIiBjbGFzcz1cIlwiIHN0eWxlPVwiXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aSBjbGFzcz1cImdseXBoaWNvbiBnbHlwaGljb24tcmVtb3ZlXCI+PC9pPiBFbXB0eSBRdWVyeSAhXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgYCxcbiAgICBkaXJlY3RpdmVzOiBbQVVUT0NPTVBMRVRFX0RJUkVDVElWRVMsIENPUkVfRElSRUNUSVZFUywgRk9STV9ESVJFQ1RJVkVTXSxcbn0pXG5leHBvcnQgY2xhc3MgQW5ndWxhcjJBdXRvY29tcGxldGUge1xuICAgIHByaXZhdGUgc2VsZWN0ZWRDYXI6c3RyaW5nID0gJyc7XG4gICAgcHJpdmF0ZSBhc3luY1NlbGVjdGVkQ2FyOnN0cmluZyA9ICcnO1xuICAgIHByaXZhdGUgYXV0b2NvbXBsZXRlTG9hZGluZzpib29sZWFuID0gZmFsc2U7XG4gICAgcHJpdmF0ZSBhdXRvY29tcGxldGVOb1Jlc3VsdHM6Ym9vbGVhbiA9IGZhbHNlO1xuICAgIHByaXZhdGUgY2Fyc0V4YW1wbGUxOkFycmF5PHN0cmluZz4gPSBbJ0JNVycsICdBdWRpJywnTWVyY2VkZXMnLCdQb3JzY2hlJywnVm9sa3N3YWdlbicsJ09wZWwnLCdNYXNlcmF0aScsJ1ZvbGtzd2FnZW4nLCdCTVcgU2VyaWUgMScsJ0JNVyBTZXJpZSAyJ107XG4gICAgcHJpdmF0ZSBjYXJzRXhhbXBsZTI6QXJyYXk8YW55PiA9IFtcbiAgICAgICAge2lkOiAxLCBuYW1lOiAnQk1XJ30sXG4gICAgICAgIHtpZDogMiwgbmFtZTogJ0F1ZGknfSxcbiAgICAgICAge2lkOiAzLCBuYW1lOiAnTWVyY2VkZXMnfSxcbiAgICAgICAge2lkOiA0LCBuYW1lOiAnUG9yc2NoZSd9LFxuICAgICAgICB7aWQ6IDUsIG5hbWU6ICdWb2xrc3dhZ2VuJ30sXG4gICAgICAgIHtpZDogNiwgbmFtZTogJ09wZWwnfSxcbiAgICAgICAge2lkOiA3LCBuYW1lOiAnTWFzZXJhdGknfSxcbiAgICAgICAge2lkOiA4LCBuYW1lOiAnVm9sa3N3YWdlbid9LFxuICAgICAgICB7aWQ6IDksIG5hbWU6ICdCTVcgU2VyaWUgMSd9LFxuICAgICAgICB7aWQ6IDEwLCBuYW1lOiAnQk1XIFNlcmllIDInfSxcbiAgICBdO1xuXG5cbiAgICBwcml2YXRlIGdldEN1cnJlbnRDb250ZXh0KCkge1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICBwcml2YXRlIF9jYWNoZWRSZXN1bHQ6YW55O1xuICAgIHByaXZhdGUgX3ByZXZpb3VzQ29udGV4dDphbnk7XG5cbiAgICBwcml2YXRlIGdldEFzeW5jRGF0YShjb250ZXh0OmFueSk6RnVuY3Rpb24ge1xuICAgICAgICBpZiAodGhpcy5fcHJldmlvdXNDb250ZXh0ID09PSBjb250ZXh0KSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fY2FjaGVkUmVzdWx0O1xuICAgICAgICB9XG5cbiAgICAgICAgdGhpcy5fcHJldmlvdXNDb250ZXh0ID0gY29udGV4dDtcbiAgICAgICAgbGV0IGY6RnVuY3Rpb24gPSBmdW5jdGlvbiAoKTpQcm9taXNlPHN0cmluZ1tdPiB7XG4gICAgICAgICAgICBsZXQgcDpQcm9taXNlPHN0cmluZ1tdPiA9IG5ldyBQcm9taXNlKChyZXNvbHZlOkZ1bmN0aW9uKSA9PiB7XG4gICAgICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGxldCBxdWVyeSA9IG5ldyBSZWdFeHAoY29udGV4dC5hc3luY1NlbGVjdGVkQ2FyLCAnaWcnKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlc29sdmUoY29udGV4dC5jYXJzRXhhbXBsZTEuZmlsdGVyKChzdGF0ZTphbnkpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBxdWVyeS50ZXN0KHN0YXRlKTtcbiAgICAgICAgICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgICAgIH0sIDUwMCk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHJldHVybiBwO1xuICAgICAgICB9O1xuICAgICAgICB0aGlzLl9jYWNoZWRSZXN1bHQgPSBmO1xuICAgICAgICByZXR1cm4gdGhpcy5fY2FjaGVkUmVzdWx0O1xuICAgIH1cblxuICAgIHByaXZhdGUgY2hhbmdlQXV0b2NvbXBsZXRlTG9hZGluZyhlOmJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5hdXRvY29tcGxldGVMb2FkaW5nID0gZTtcbiAgICB9XG5cbiAgICBwcml2YXRlIGNoYW5nZUF1dG9jb21wbGV0ZU5vUmVzdWx0cyhlOmJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5hdXRvY29tcGxldGVOb1Jlc3VsdHMgPSBlO1xuICAgIH1cblxuICAgIHByaXZhdGUgYXV0b2NvbXBsZXRlT25TZWxlY3QoZTphbnkpIHtcbiAgICAgICAgY29uc29sZS5sb2coYFNlbGVjdGVkIHZhbHVlOiAke2UuaXRlbX1gKTtcbiAgICB9XG59Il19
