System.register(['angular2/core', 'angular2/common', './autocomplete.component', './options.class', './position'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, common_1, autocomplete_component_1, options_class_1, position_1;
    var AutocompleteContainer;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (autocomplete_component_1_1) {
                autocomplete_component_1 = autocomplete_component_1_1;
            },
            function (options_class_1_1) {
                options_class_1 = options_class_1_1;
            },
            function (position_1_1) {
                position_1 = position_1_1;
            }],
        execute: function() {
            AutocompleteContainer = (function () {
                function AutocompleteContainer(element, options) {
                    this.element = element;
                    this._matches = [];
                    Object.assign(this, options);
                }
                Object.defineProperty(AutocompleteContainer.prototype, "matches", {
                    get: function () {
                        return this._matches;
                    },
                    set: function (value) {
                        this._matches = value;
                        if (this._matches.length > 0) {
                            this._active = this._matches[0];
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(AutocompleteContainer.prototype, "field", {
                    set: function (value) {
                        this._field = value;
                    },
                    enumerable: true,
                    configurable: true
                });
                AutocompleteContainer.prototype.position = function (hostEl) {
                    this.display = 'block';
                    this.top = '0px';
                    this.left = '0px';
                    var p = position_1.positionService
                        .positionElements(hostEl.nativeElement, this.element.nativeElement.children[0], this.placement, false);
                    this.top = p.top + 'px';
                    this.left = p.left + 'px';
                };
                AutocompleteContainer.prototype.selectActiveMatch = function () {
                    this.selectMatch(this._active);
                };
                AutocompleteContainer.prototype.prevActiveMatch = function () {
                    var index = this.matches.indexOf(this._active);
                    this._active = this.matches[index - 1 < 0 ? this.matches.length - 1 : index - 1];
                };
                AutocompleteContainer.prototype.nextActiveMatch = function () {
                    var index = this.matches.indexOf(this._active);
                    this._active = this.matches[index + 1 > this.matches.length - 1 ? 0 : index + 1];
                };
                AutocompleteContainer.prototype.selectActive = function (value) {
                    this._active = value;
                };
                AutocompleteContainer.prototype.isActive = function (value) {
                    return this._active === value;
                };
                AutocompleteContainer.prototype.selectMatch = function (value, e) {
                    if (e === void 0) { e = null; }
                    if (e) {
                        e.stopPropagation();
                        e.preventDefault();
                    }
                    this.parent.changeModel(value);
                    this.parent.autocompleteOnSelect.emit({
                        item: value
                    });
                    return false;
                };
                AutocompleteContainer.prototype.hightlight = function (item, query) {
                    var itemStr = (typeof item === 'object' && this._field ? item[this._field] : item).toString();
                    //let itemStrHelper:string = (this.parent.autocompleteLatinize ? AutocompleteUtils.latinize(itemStr) : itemStr).toLowerCase();
                    var itemStrHelper = itemStr.toLowerCase();
                    var startIdx;
                    var tokenLen;
                    if (typeof query === 'object') {
                        var queryLen = query.length;
                        for (var i = 0; i < queryLen; i += 1) {
                            startIdx = itemStrHelper.indexOf(query[i]);
                            tokenLen = query[i].length;
                            if (startIdx >= 0 && tokenLen > 0) {
                                itemStr = itemStr.substring(0, startIdx) + '<strong>' + itemStr.substring(startIdx, startIdx + tokenLen) + '</strong>' + itemStr.substring(startIdx + tokenLen);
                                itemStrHelper = itemStrHelper.substring(0, startIdx) + '        ' + ' '.repeat(tokenLen) + '         ' + itemStrHelper.substring(startIdx + tokenLen);
                            }
                        }
                    }
                    else if (query) {
                        startIdx = itemStrHelper.indexOf(query);
                        tokenLen = query.length;
                        if (startIdx >= 0 && tokenLen > 0) {
                            itemStr = itemStr.substring(0, startIdx) + '<strong>' + itemStr.substring(startIdx, startIdx + tokenLen) + '</strong>' + itemStr.substring(startIdx + tokenLen);
                        }
                    }
                    return itemStr;
                };
                AutocompleteContainer = __decorate([
                    core_1.Component({
                        selector: 'autocomplete-container',
                        directives: [common_1.CORE_DIRECTIVES],
                        template: "\n                  <ul class=\"dropdown-menu\"\n                      [ngStyle]=\"{top: top, left: left, display: display}\"\n                      style=\"display: block;\">\n                    <li *ngFor=\"#match of matches\"\n                        [class.active]=\"isActive(match)\"\n                        (mouseenter)=\"selectActive(match)\">\n                        <a href=\"#\" (click)=\"selectMatch(match, $event)\" tabindex=\"-1\" [innerHtml]=\"hightlight(match, query)\"></a>\n                    </li>\n                  </ul>\n              ",
                        encapsulation: core_1.ViewEncapsulation.None,
                        providers: [core_1.ElementRef, autocomplete_component_1.Autocomplete]
                    }), 
                    __metadata('design:paramtypes', [core_1.ElementRef, options_class_1.AutocompleteOptions])
                ], AutocompleteContainer);
                return AutocompleteContainer;
            }());
            exports_1("AutocompleteContainer", AutocompleteContainer);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldi9hdXRvY29tcGxldGUvYXV0b2NvbXBsZXRlLWNvbnRhaW5lci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztZQTRCQTtnQkFXSSwrQkFBbUIsT0FBa0IsRUFBRSxPQUEyQjtvQkFBL0MsWUFBTyxHQUFQLE9BQU8sQ0FBVztvQkFSN0IsYUFBUSxHQUFjLEVBQUUsQ0FBQztvQkFTN0IsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQUM7Z0JBQ2pDLENBQUM7Z0JBRUQsc0JBQVcsMENBQU87eUJBQWxCO3dCQUNJLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDO29CQUN6QixDQUFDO3lCQUVELFVBQW1CLEtBQW1CO3dCQUNsQyxJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQzt3QkFFdEIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUNwQyxDQUFDO29CQUNMLENBQUM7OzttQkFSQTtnQkFVRCxzQkFBVyx3Q0FBSzt5QkFBaEIsVUFBaUIsS0FBWTt3QkFDekIsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7b0JBQ3hCLENBQUM7OzttQkFBQTtnQkFFTSx3Q0FBUSxHQUFmLFVBQWdCLE1BQWlCO29CQUM3QixJQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQztvQkFDdkIsSUFBSSxDQUFDLEdBQUcsR0FBRyxLQUFLLENBQUM7b0JBQ2pCLElBQUksQ0FBQyxJQUFJLEdBQUcsS0FBSyxDQUFDO29CQUNsQixJQUFJLENBQUMsR0FBRywwQkFBZTt5QkFDbEIsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLGFBQWEsRUFDbEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxFQUN0QyxJQUFJLENBQUMsU0FBUyxFQUFFLEtBQUssQ0FBQyxDQUFDO29CQUMvQixJQUFJLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDO29CQUN4QixJQUFJLENBQUMsSUFBSSxHQUFHLENBQUMsQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO2dCQUM5QixDQUFDO2dCQUVNLGlEQUFpQixHQUF4QjtvQkFDSSxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztnQkFDbkMsQ0FBQztnQkFFTSwrQ0FBZSxHQUF0QjtvQkFDSSxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7b0JBQy9DLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sR0FBRyxDQUFDLEdBQUcsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDO2dCQUNyRixDQUFDO2dCQUVNLCtDQUFlLEdBQXRCO29CQUNJLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztvQkFDL0MsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUM7Z0JBQ3JGLENBQUM7Z0JBRU8sNENBQVksR0FBcEIsVUFBcUIsS0FBUztvQkFDMUIsSUFBSSxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7Z0JBQ3pCLENBQUM7Z0JBRU8sd0NBQVEsR0FBaEIsVUFBaUIsS0FBUztvQkFDdEIsTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLEtBQUssS0FBSyxDQUFDO2dCQUNsQyxDQUFDO2dCQUVPLDJDQUFXLEdBQW5CLFVBQW9CLEtBQVMsRUFBRSxDQUFjO29CQUFkLGlCQUFjLEdBQWQsUUFBYztvQkFDekMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDSixDQUFDLENBQUMsZUFBZSxFQUFFLENBQUM7d0JBQ3BCLENBQUMsQ0FBQyxjQUFjLEVBQUUsQ0FBQztvQkFDdkIsQ0FBQztvQkFFRCxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDL0IsSUFBSSxDQUFDLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUM7d0JBQ2xDLElBQUksRUFBRSxLQUFLO3FCQUNkLENBQUMsQ0FBQztvQkFDSCxNQUFNLENBQUMsS0FBSyxDQUFDO2dCQUNqQixDQUFDO2dCQUVPLDBDQUFVLEdBQWxCLFVBQW1CLElBQVEsRUFBRSxLQUFZO29CQUNyQyxJQUFJLE9BQU8sR0FBVSxDQUFDLE9BQU8sSUFBSSxLQUFLLFFBQVEsSUFBSSxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUM7b0JBQ3JHLDhIQUE4SDtvQkFDOUgsSUFBSSxhQUFhLEdBQVMsT0FBTyxDQUFDLFdBQVcsRUFBRSxDQUFDO29CQUNoRCxJQUFJLFFBQWUsQ0FBQztvQkFDcEIsSUFBSSxRQUFlLENBQUM7b0JBRXBCLEVBQUUsQ0FBQyxDQUFDLE9BQU8sS0FBSyxLQUFLLFFBQVEsQ0FBQyxDQUFDLENBQUM7d0JBQzVCLElBQUksUUFBUSxHQUFVLEtBQUssQ0FBQyxNQUFNLENBQUM7d0JBQ25DLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsUUFBUSxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQzs0QkFDbkMsUUFBUSxHQUFHLGFBQWEsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7NEJBQzNDLFFBQVEsR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDOzRCQUMzQixFQUFFLENBQUMsQ0FBQyxRQUFRLElBQUksQ0FBQyxJQUFJLFFBQVEsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUNoQyxPQUFPLEdBQUcsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsUUFBUSxDQUFDLEdBQUcsVUFBVSxHQUFHLE9BQU8sQ0FBQyxTQUFTLENBQUMsUUFBUSxFQUFFLFFBQVEsR0FBRyxRQUFRLENBQUMsR0FBRyxXQUFXLEdBQUcsT0FBTyxDQUFDLFNBQVMsQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFDLENBQUM7Z0NBQ2hLLGFBQWEsR0FBRyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxRQUFRLENBQUMsR0FBRyxVQUFVLEdBQUcsR0FBRyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsR0FBRyxXQUFXLEdBQUcsYUFBYSxDQUFDLFNBQVMsQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFDLENBQUM7NEJBQzFKLENBQUM7d0JBQ0wsQ0FBQztvQkFDTCxDQUFDO29CQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO3dCQUNmLFFBQVEsR0FBRyxhQUFhLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO3dCQUN4QyxRQUFRLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQzt3QkFDeEIsRUFBRSxDQUFDLENBQUMsUUFBUSxJQUFJLENBQUMsSUFBSSxRQUFRLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQzs0QkFDaEMsT0FBTyxHQUFHLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxHQUFHLFVBQVUsR0FBRyxPQUFPLENBQUMsU0FBUyxDQUFDLFFBQVEsRUFBRSxRQUFRLEdBQUcsUUFBUSxDQUFDLEdBQUcsV0FBVyxHQUFHLE9BQU8sQ0FBQyxTQUFTLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQyxDQUFDO3dCQUNwSyxDQUFDO29CQUNMLENBQUM7b0JBRUQsTUFBTSxDQUFDLE9BQU8sQ0FBQztnQkFDbkIsQ0FBQztnQkExSEw7b0JBQUMsZ0JBQVMsQ0FBQzt3QkFDUCxRQUFRLEVBQUUsd0JBQXdCO3dCQUNsQyxVQUFVLEVBQUUsQ0FBQyx3QkFBZSxDQUFDO3dCQUM3QixRQUFRLEVBQUUsa2pCQVVDO3dCQUVYLGFBQWEsRUFBRSx3QkFBaUIsQ0FBQyxJQUFJO3dCQUNyQyxTQUFTLEVBQUUsQ0FBQyxpQkFBVSxFQUFFLHFDQUFZLENBQUM7cUJBQ3hDLENBQUM7O3lDQUFBO2dCQTBHRiw0QkFBQztZQUFELENBekdBLEFBeUdDLElBQUE7WUF6R0QseURBeUdDLENBQUEiLCJmaWxlIjoiZGV2L2F1dG9jb21wbGV0ZS9hdXRvY29tcGxldGUtY29udGFpbmVyLmpzIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBib290c3RyYXBcbiAqL1xuaW1wb3J0IHtDb21wb25lbnQsIEVsZW1lbnRSZWYsIFZpZXdFbmNhcHN1bGF0aW9ufSBmcm9tICdhbmd1bGFyMi9jb3JlJztcbmltcG9ydCB7Q09SRV9ESVJFQ1RJVkVTfSBmcm9tICdhbmd1bGFyMi9jb21tb24nO1xuaW1wb3J0IHtBdXRvY29tcGxldGV9IGZyb20gJy4vYXV0b2NvbXBsZXRlLmNvbXBvbmVudCc7XG5pbXBvcnQge0F1dG9jb21wbGV0ZU9wdGlvbnN9IGZyb20gJy4vb3B0aW9ucy5jbGFzcyc7XG5pbXBvcnQge3Bvc2l0aW9uU2VydmljZX0gZnJvbSAnLi9wb3NpdGlvbic7XG5cblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdhdXRvY29tcGxldGUtY29udGFpbmVyJyxcbiAgICBkaXJlY3RpdmVzOiBbQ09SRV9ESVJFQ1RJVkVTXSxcbiAgICB0ZW1wbGF0ZTogYFxuICAgICAgICAgICAgICAgICAgPHVsIGNsYXNzPVwiZHJvcGRvd24tbWVudVwiXG4gICAgICAgICAgICAgICAgICAgICAgW25nU3R5bGVdPVwie3RvcDogdG9wLCBsZWZ0OiBsZWZ0LCBkaXNwbGF5OiBkaXNwbGF5fVwiXG4gICAgICAgICAgICAgICAgICAgICAgc3R5bGU9XCJkaXNwbGF5OiBibG9jaztcIj5cbiAgICAgICAgICAgICAgICAgICAgPGxpICpuZ0Zvcj1cIiNtYXRjaCBvZiBtYXRjaGVzXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIFtjbGFzcy5hY3RpdmVdPVwiaXNBY3RpdmUobWF0Y2gpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIChtb3VzZWVudGVyKT1cInNlbGVjdEFjdGl2ZShtYXRjaClcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxhIGhyZWY9XCIjXCIgKGNsaWNrKT1cInNlbGVjdE1hdGNoKG1hdGNoLCAkZXZlbnQpXCIgdGFiaW5kZXg9XCItMVwiIFtpbm5lckh0bWxdPVwiaGlnaHRsaWdodChtYXRjaCwgcXVlcnkpXCI+PC9hPlxuICAgICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICAgICAgYCxcblxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXG4gICAgcHJvdmlkZXJzOiBbRWxlbWVudFJlZiwgQXV0b2NvbXBsZXRlXVxufSlcbmV4cG9ydCBjbGFzcyBBdXRvY29tcGxldGVDb250YWluZXIge1xuICAgIHB1YmxpYyBwYXJlbnQ6QXV0b2NvbXBsZXRlO1xuICAgIHB1YmxpYyBxdWVyeTphbnk7XG4gICAgcHJpdmF0ZSBfbWF0Y2hlczpBcnJheTxhbnk+ID0gW107XG4gICAgcHJpdmF0ZSBfZmllbGQ6c3RyaW5nO1xuICAgIHByaXZhdGUgX2FjdGl2ZTphbnk7XG4gICAgcHJpdmF0ZSB0b3A6c3RyaW5nO1xuICAgIHByaXZhdGUgbGVmdDpzdHJpbmc7XG4gICAgcHJpdmF0ZSBkaXNwbGF5OnN0cmluZztcbiAgICBwcml2YXRlIHBsYWNlbWVudDpzdHJpbmc7XG5cbiAgICBjb25zdHJ1Y3RvcihwdWJsaWMgZWxlbWVudDpFbGVtZW50UmVmLCBvcHRpb25zOkF1dG9jb21wbGV0ZU9wdGlvbnMpIHtcbiAgICAgICAgT2JqZWN0LmFzc2lnbih0aGlzLCBvcHRpb25zKTtcbiAgICB9XG5cbiAgICBwdWJsaWMgZ2V0IG1hdGNoZXMoKTpBcnJheTxzdHJpbmc+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX21hdGNoZXM7XG4gICAgfVxuXG4gICAgcHVibGljIHNldCBtYXRjaGVzKHZhbHVlOkFycmF5PHN0cmluZz4pIHtcbiAgICAgICAgdGhpcy5fbWF0Y2hlcyA9IHZhbHVlO1xuXG4gICAgICAgIGlmICh0aGlzLl9tYXRjaGVzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIHRoaXMuX2FjdGl2ZSA9IHRoaXMuX21hdGNoZXNbMF07XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBwdWJsaWMgc2V0IGZpZWxkKHZhbHVlOnN0cmluZykge1xuICAgICAgICB0aGlzLl9maWVsZCA9IHZhbHVlO1xuICAgIH1cblxuICAgIHB1YmxpYyBwb3NpdGlvbihob3N0RWw6RWxlbWVudFJlZikge1xuICAgICAgICB0aGlzLmRpc3BsYXkgPSAnYmxvY2snO1xuICAgICAgICB0aGlzLnRvcCA9ICcwcHgnO1xuICAgICAgICB0aGlzLmxlZnQgPSAnMHB4JztcbiAgICAgICAgbGV0IHAgPSBwb3NpdGlvblNlcnZpY2VcbiAgICAgICAgICAgIC5wb3NpdGlvbkVsZW1lbnRzKGhvc3RFbC5uYXRpdmVFbGVtZW50LFxuICAgICAgICAgICAgICAgIHRoaXMuZWxlbWVudC5uYXRpdmVFbGVtZW50LmNoaWxkcmVuWzBdLFxuICAgICAgICAgICAgICAgIHRoaXMucGxhY2VtZW50LCBmYWxzZSk7XG4gICAgICAgIHRoaXMudG9wID0gcC50b3AgKyAncHgnO1xuICAgICAgICB0aGlzLmxlZnQgPSBwLmxlZnQgKyAncHgnO1xuICAgIH1cblxuICAgIHB1YmxpYyBzZWxlY3RBY3RpdmVNYXRjaCgpIHtcbiAgICAgICAgdGhpcy5zZWxlY3RNYXRjaCh0aGlzLl9hY3RpdmUpO1xuICAgIH1cblxuICAgIHB1YmxpYyBwcmV2QWN0aXZlTWF0Y2goKSB7XG4gICAgICAgIGxldCBpbmRleCA9IHRoaXMubWF0Y2hlcy5pbmRleE9mKHRoaXMuX2FjdGl2ZSk7XG4gICAgICAgIHRoaXMuX2FjdGl2ZSA9IHRoaXMubWF0Y2hlc1tpbmRleCAtIDEgPCAwID8gdGhpcy5tYXRjaGVzLmxlbmd0aCAtIDEgOiBpbmRleCAtIDFdO1xuICAgIH1cblxuICAgIHB1YmxpYyBuZXh0QWN0aXZlTWF0Y2goKSB7XG4gICAgICAgIGxldCBpbmRleCA9IHRoaXMubWF0Y2hlcy5pbmRleE9mKHRoaXMuX2FjdGl2ZSk7XG4gICAgICAgIHRoaXMuX2FjdGl2ZSA9IHRoaXMubWF0Y2hlc1tpbmRleCArIDEgPiB0aGlzLm1hdGNoZXMubGVuZ3RoIC0gMSA/IDAgOiBpbmRleCArIDFdO1xuICAgIH1cblxuICAgIHByaXZhdGUgc2VsZWN0QWN0aXZlKHZhbHVlOmFueSkge1xuICAgICAgICB0aGlzLl9hY3RpdmUgPSB2YWx1ZTtcbiAgICB9XG5cbiAgICBwcml2YXRlIGlzQWN0aXZlKHZhbHVlOmFueSk6Ym9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9hY3RpdmUgPT09IHZhbHVlO1xuICAgIH1cblxuICAgIHByaXZhdGUgc2VsZWN0TWF0Y2godmFsdWU6YW55LCBlOkV2ZW50ID0gbnVsbCkge1xuICAgICAgICBpZiAoZSkge1xuICAgICAgICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHRoaXMucGFyZW50LmNoYW5nZU1vZGVsKHZhbHVlKTtcbiAgICAgICAgdGhpcy5wYXJlbnQuYXV0b2NvbXBsZXRlT25TZWxlY3QuZW1pdCh7XG4gICAgICAgICAgICBpdGVtOiB2YWx1ZVxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cblxuICAgIHByaXZhdGUgaGlnaHRsaWdodChpdGVtOmFueSwgcXVlcnk6c3RyaW5nKSB7XG4gICAgICAgIGxldCBpdGVtU3RyOnN0cmluZyA9ICh0eXBlb2YgaXRlbSA9PT0gJ29iamVjdCcgJiYgdGhpcy5fZmllbGQgPyBpdGVtW3RoaXMuX2ZpZWxkXSA6IGl0ZW0pLnRvU3RyaW5nKCk7XG4gICAgICAgIC8vbGV0IGl0ZW1TdHJIZWxwZXI6c3RyaW5nID0gKHRoaXMucGFyZW50LmF1dG9jb21wbGV0ZUxhdGluaXplID8gQXV0b2NvbXBsZXRlVXRpbHMubGF0aW5pemUoaXRlbVN0cikgOiBpdGVtU3RyKS50b0xvd2VyQ2FzZSgpO1xuICAgICAgICBsZXQgaXRlbVN0ckhlbHBlcjpzdHJpbmcgPWl0ZW1TdHIudG9Mb3dlckNhc2UoKTtcbiAgICAgICAgbGV0IHN0YXJ0SWR4Om51bWJlcjtcbiAgICAgICAgbGV0IHRva2VuTGVuOm51bWJlcjtcblxuICAgICAgICBpZiAodHlwZW9mIHF1ZXJ5ID09PSAnb2JqZWN0Jykge1xuICAgICAgICAgICAgbGV0IHF1ZXJ5TGVuOm51bWJlciA9IHF1ZXJ5Lmxlbmd0aDtcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcXVlcnlMZW47IGkgKz0gMSkge1xuICAgICAgICAgICAgICAgIHN0YXJ0SWR4ID0gaXRlbVN0ckhlbHBlci5pbmRleE9mKHF1ZXJ5W2ldKTtcbiAgICAgICAgICAgICAgICB0b2tlbkxlbiA9IHF1ZXJ5W2ldLmxlbmd0aDtcbiAgICAgICAgICAgICAgICBpZiAoc3RhcnRJZHggPj0gMCAmJiB0b2tlbkxlbiA+IDApIHtcbiAgICAgICAgICAgICAgICAgICAgaXRlbVN0ciA9IGl0ZW1TdHIuc3Vic3RyaW5nKDAsIHN0YXJ0SWR4KSArICc8c3Ryb25nPicgKyBpdGVtU3RyLnN1YnN0cmluZyhzdGFydElkeCwgc3RhcnRJZHggKyB0b2tlbkxlbikgKyAnPC9zdHJvbmc+JyArIGl0ZW1TdHIuc3Vic3RyaW5nKHN0YXJ0SWR4ICsgdG9rZW5MZW4pO1xuICAgICAgICAgICAgICAgICAgICBpdGVtU3RySGVscGVyID0gaXRlbVN0ckhlbHBlci5zdWJzdHJpbmcoMCwgc3RhcnRJZHgpICsgJyAgICAgICAgJyArICcgJy5yZXBlYXQodG9rZW5MZW4pICsgJyAgICAgICAgICcgKyBpdGVtU3RySGVscGVyLnN1YnN0cmluZyhzdGFydElkeCArIHRva2VuTGVuKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSBpZiAocXVlcnkpIHtcbiAgICAgICAgICAgIHN0YXJ0SWR4ID0gaXRlbVN0ckhlbHBlci5pbmRleE9mKHF1ZXJ5KTtcbiAgICAgICAgICAgIHRva2VuTGVuID0gcXVlcnkubGVuZ3RoO1xuICAgICAgICAgICAgaWYgKHN0YXJ0SWR4ID49IDAgJiYgdG9rZW5MZW4gPiAwKSB7XG4gICAgICAgICAgICAgICAgaXRlbVN0ciA9IGl0ZW1TdHIuc3Vic3RyaW5nKDAsIHN0YXJ0SWR4KSArICc8c3Ryb25nPicgKyBpdGVtU3RyLnN1YnN0cmluZyhzdGFydElkeCwgc3RhcnRJZHggKyB0b2tlbkxlbikgKyAnPC9zdHJvbmc+JyArIGl0ZW1TdHIuc3Vic3RyaW5nKHN0YXJ0SWR4ICsgdG9rZW5MZW4pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIGl0ZW1TdHI7XG4gICAgfVxufVxuIl19
