System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var AutocompleteOptions;
    return {
        setters:[],
        execute: function() {
            AutocompleteOptions = (function () {
                function AutocompleteOptions(options) {
                    Object.assign(this, options);
                }
                return AutocompleteOptions;
            }());
            exports_1("AutocompleteOptions", AutocompleteOptions);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldi9hdXRvY29tcGxldGUvb3B0aW9ucy5jbGFzcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7O1lBQUE7Z0JBSUksNkJBQVksT0FBMkI7b0JBQ25DLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxDQUFDO2dCQUNqQyxDQUFDO2dCQUNMLDBCQUFDO1lBQUQsQ0FQQSxBQU9DLElBQUE7WUFQRCxxREFPQyxDQUFBIiwiZmlsZSI6ImRldi9hdXRvY29tcGxldGUvb3B0aW9ucy5jbGFzcy5qcyIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBjbGFzcyBBdXRvY29tcGxldGVPcHRpb25zIHtcbiAgICBwdWJsaWMgcGxhY2VtZW50OnN0cmluZztcbiAgICBwdWJsaWMgYW5pbWF0aW9uOmJvb2xlYW47XG5cbiAgICBjb25zdHJ1Y3RvcihvcHRpb25zOkF1dG9jb21wbGV0ZU9wdGlvbnMpIHtcbiAgICAgICAgT2JqZWN0LmFzc2lnbih0aGlzLCBvcHRpb25zKTtcbiAgICB9XG59Il19
