System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var PositionService, positionService;
    return {
        setters:[],
        execute: function() {
            PositionService = (function () {
                function PositionService() {
                }
                Object.defineProperty(PositionService.prototype, "window", {
                    get: function () {
                        return window;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(PositionService.prototype, "document", {
                    get: function () {
                        return window.document;
                    },
                    enumerable: true,
                    configurable: true
                });
                PositionService.prototype.getStyle = function (nativeEl, cssProp) {
                    // IE
                    if (nativeEl.currentStyle) {
                        return nativeEl.currentStyle[cssProp];
                    }
                    if (this.window.getComputedStyle) {
                        return this.window.getComputedStyle(nativeEl)[cssProp];
                    }
                    // finally try and get inline style
                    return nativeEl.style[cssProp];
                };
                /**
                 * Checks if a given element is statically positioned
                 * @param nativeEl - raw DOM element
                 */
                PositionService.prototype.isStaticPositioned = function (nativeEl) {
                    return (this.getStyle(nativeEl, 'position') || 'static') === 'static';
                };
                /**
                 * returns the closest, non-statically positioned parentOffset of a given element
                 * @param nativeEl
                 */
                PositionService.prototype.parentOffsetEl = function (nativeEl) {
                    var offsetParent = nativeEl.offsetParent || this.document;
                    while (offsetParent && offsetParent !== this.document &&
                        this.isStaticPositioned(offsetParent)) {
                        offsetParent = offsetParent.offsetParent;
                    }
                    return offsetParent || this.document;
                };
                ;
                /**
                 * Provides read-only equivalent of jQuery's position function:
                 * http://api.jquery.com/position/
                 */
                PositionService.prototype.position = function (nativeEl) {
                    var elBCR = this.offset(nativeEl);
                    var offsetParentBCR = { top: 0, left: 0 };
                    var offsetParentEl = this.parentOffsetEl(nativeEl);
                    if (offsetParentEl !== this.document) {
                        offsetParentBCR = this.offset(offsetParentEl);
                        offsetParentBCR.top += offsetParentEl.clientTop - offsetParentEl.scrollTop;
                        offsetParentBCR.left += offsetParentEl.clientLeft - offsetParentEl.scrollLeft;
                    }
                    var boundingClientRect = nativeEl.getBoundingClientRect();
                    return {
                        width: boundingClientRect.width || nativeEl.offsetWidth,
                        height: boundingClientRect.height || nativeEl.offsetHeight,
                        top: elBCR.top - offsetParentBCR.top,
                        left: elBCR.left - offsetParentBCR.left
                    };
                };
                /**
                 * Provides read-only equivalent of jQuery's offset function:
                 * http://api.jquery.com/offset/
                 */
                PositionService.prototype.offset = function (nativeEl) {
                    var boundingClientRect = nativeEl.getBoundingClientRect();
                    return {
                        width: boundingClientRect.width || nativeEl.offsetWidth,
                        height: boundingClientRect.height || nativeEl.offsetHeight,
                        top: boundingClientRect.top + (this.window.pageYOffset || this.document.documentElement.scrollTop),
                        left: boundingClientRect.left + (this.window.pageXOffset || this.document.documentElement.scrollLeft)
                    };
                };
                /**
                 * Provides coordinates for the targetEl in relation to hostEl
                 */
                PositionService.prototype.positionElements = function (hostEl, targetEl, positionStr, appendToBody) {
                    var positionStrParts = positionStr.split('-');
                    var pos0 = positionStrParts[0];
                    var pos1 = positionStrParts[1] || 'center';
                    var hostElPos = appendToBody ?
                        this.offset(hostEl) :
                        this.position(hostEl);
                    var targetElWidth = targetEl.offsetWidth;
                    var targetElHeight = targetEl.offsetHeight;
                    var shiftWidth = {
                        center: function () {
                            return hostElPos.left + hostElPos.width / 2 - targetElWidth / 2;
                        },
                        left: function () {
                            return hostElPos.left;
                        },
                        right: function () {
                            return hostElPos.left + hostElPos.width;
                        }
                    };
                    var shiftHeight = {
                        center: function () {
                            return hostElPos.top + hostElPos.height / 2 - targetElHeight / 2;
                        },
                        top: function () {
                            return hostElPos.top;
                        },
                        bottom: function () {
                            return hostElPos.top + hostElPos.height;
                        }
                    };
                    var targetElPos;
                    switch (pos0) {
                        case 'right':
                            targetElPos = {
                                top: shiftHeight[pos1](),
                                left: shiftWidth[pos0]()
                            };
                            break;
                        case 'left':
                            targetElPos = {
                                top: shiftHeight[pos1](),
                                left: hostElPos.left - targetElWidth
                            };
                            break;
                        case 'bottom':
                            targetElPos = {
                                top: shiftHeight[pos0](),
                                left: shiftWidth[pos1]()
                            };
                            break;
                        default:
                            targetElPos = {
                                top: hostElPos.top - targetElHeight,
                                left: shiftWidth[pos1]()
                            };
                            break;
                    }
                    return targetElPos;
                };
                return PositionService;
            }());
            exports_1("PositionService", PositionService);
            exports_1("positionService", positionService = new PositionService());
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldi9hdXRvY29tcGxldGUvcG9zaXRpb24udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O3lCQWdLYSxlQUFlOzs7O1lBdko1QjtnQkFBQTtnQkFxSkEsQ0FBQztnQkFwSkcsc0JBQVksbUNBQU07eUJBQWxCO3dCQUNJLE1BQU0sQ0FBQyxNQUFNLENBQUM7b0JBQ2xCLENBQUM7OzttQkFBQTtnQkFFRCxzQkFBWSxxQ0FBUTt5QkFBcEI7d0JBQ0ksTUFBTSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7b0JBQzNCLENBQUM7OzttQkFBQTtnQkFFTyxrQ0FBUSxHQUFoQixVQUFpQixRQUFZLEVBQUUsT0FBYztvQkFDekMsS0FBSztvQkFDTCxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQzt3QkFDeEIsTUFBTSxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLENBQUM7b0JBQzFDLENBQUM7b0JBRUQsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUM7d0JBQy9CLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLFFBQVEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO29CQUMzRCxDQUFDO29CQUNELG1DQUFtQztvQkFDbkMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7Z0JBQ25DLENBQUM7Z0JBR0Q7OzttQkFHRztnQkFDSyw0Q0FBa0IsR0FBMUIsVUFBMkIsUUFBWTtvQkFDbkMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUUsVUFBVSxDQUFDLElBQUksUUFBUSxDQUFFLEtBQUssUUFBUSxDQUFDO2dCQUMzRSxDQUFDO2dCQUdEOzs7bUJBR0c7Z0JBQ0ssd0NBQWMsR0FBdEIsVUFBdUIsUUFBWTtvQkFDL0IsSUFBSSxZQUFZLEdBQUcsUUFBUSxDQUFDLFlBQVksSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDO29CQUMxRCxPQUFPLFlBQVksSUFBSSxZQUFZLEtBQUssSUFBSSxDQUFDLFFBQVE7d0JBQ3JELElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDO3dCQUNwQyxZQUFZLEdBQUcsWUFBWSxDQUFDLFlBQVksQ0FBQztvQkFDN0MsQ0FBQztvQkFDRCxNQUFNLENBQUMsWUFBWSxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUM7Z0JBQ3pDLENBQUM7O2dCQUVEOzs7bUJBR0c7Z0JBQ0ksa0NBQVEsR0FBZixVQUFnQixRQUFZO29CQUN4QixJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDO29CQUNsQyxJQUFJLGVBQWUsR0FBRyxFQUFDLEdBQUcsRUFBRSxDQUFDLEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBQyxDQUFDO29CQUN4QyxJQUFJLGNBQWMsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDO29CQUNuRCxFQUFFLENBQUMsQ0FBQyxjQUFjLEtBQUssSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7d0JBQ25DLGVBQWUsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxDQUFDO3dCQUM5QyxlQUFlLENBQUMsR0FBRyxJQUFJLGNBQWMsQ0FBQyxTQUFTLEdBQUcsY0FBYyxDQUFDLFNBQVMsQ0FBQzt3QkFDM0UsZUFBZSxDQUFDLElBQUksSUFBSSxjQUFjLENBQUMsVUFBVSxHQUFHLGNBQWMsQ0FBQyxVQUFVLENBQUM7b0JBQ2xGLENBQUM7b0JBRUQsSUFBSSxrQkFBa0IsR0FBRyxRQUFRLENBQUMscUJBQXFCLEVBQUUsQ0FBQztvQkFDMUQsTUFBTSxDQUFDO3dCQUNILEtBQUssRUFBRSxrQkFBa0IsQ0FBQyxLQUFLLElBQUksUUFBUSxDQUFDLFdBQVc7d0JBQ3ZELE1BQU0sRUFBRSxrQkFBa0IsQ0FBQyxNQUFNLElBQUksUUFBUSxDQUFDLFlBQVk7d0JBQzFELEdBQUcsRUFBRSxLQUFLLENBQUMsR0FBRyxHQUFHLGVBQWUsQ0FBQyxHQUFHO3dCQUNwQyxJQUFJLEVBQUUsS0FBSyxDQUFDLElBQUksR0FBRyxlQUFlLENBQUMsSUFBSTtxQkFDMUMsQ0FBQztnQkFDTixDQUFDO2dCQUVEOzs7bUJBR0c7Z0JBQ0ksZ0NBQU0sR0FBYixVQUFjLFFBQVk7b0JBQ3RCLElBQUksa0JBQWtCLEdBQUcsUUFBUSxDQUFDLHFCQUFxQixFQUFFLENBQUM7b0JBQzFELE1BQU0sQ0FBQzt3QkFDSCxLQUFLLEVBQUUsa0JBQWtCLENBQUMsS0FBSyxJQUFJLFFBQVEsQ0FBQyxXQUFXO3dCQUN2RCxNQUFNLEVBQUUsa0JBQWtCLENBQUMsTUFBTSxJQUFJLFFBQVEsQ0FBQyxZQUFZO3dCQUMxRCxHQUFHLEVBQUUsa0JBQWtCLENBQUMsR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxlQUFlLENBQUMsU0FBUyxDQUFDO3dCQUNsRyxJQUFJLEVBQUUsa0JBQWtCLENBQUMsSUFBSSxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxlQUFlLENBQUMsVUFBVSxDQUFDO3FCQUN4RyxDQUFDO2dCQUNOLENBQUM7Z0JBRUQ7O21CQUVHO2dCQUNJLDBDQUFnQixHQUF2QixVQUF3QixNQUFVLEVBQUUsUUFBWSxFQUFFLFdBQWUsRUFBRSxZQUFnQjtvQkFDL0UsSUFBSSxnQkFBZ0IsR0FBRyxXQUFXLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUM5QyxJQUFJLElBQUksR0FBRyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDL0IsSUFBSSxJQUFJLEdBQUcsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLElBQUksUUFBUSxDQUFDO29CQUMzQyxJQUFJLFNBQVMsR0FBRyxZQUFZO3dCQUN4QixJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQzt3QkFDbkIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDMUIsSUFBSSxhQUFhLEdBQUcsUUFBUSxDQUFDLFdBQVcsQ0FBQztvQkFDekMsSUFBSSxjQUFjLEdBQUcsUUFBUSxDQUFDLFlBQVksQ0FBQztvQkFFM0MsSUFBSSxVQUFVLEdBQWM7d0JBQ3hCLE1BQU0sRUFBRTs0QkFDSixNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksR0FBRyxTQUFTLENBQUMsS0FBSyxHQUFHLENBQUMsR0FBRyxhQUFhLEdBQUcsQ0FBQyxDQUFDO3dCQUNwRSxDQUFDO3dCQUNELElBQUksRUFBRTs0QkFDRixNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQzt3QkFDMUIsQ0FBQzt3QkFDRCxLQUFLLEVBQUU7NEJBQ0gsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLEdBQUcsU0FBUyxDQUFDLEtBQUssQ0FBQzt3QkFDNUMsQ0FBQztxQkFDSixDQUFDO29CQUVGLElBQUksV0FBVyxHQUFjO3dCQUN6QixNQUFNLEVBQUU7NEJBQ0osTUFBTSxDQUFDLFNBQVMsQ0FBQyxHQUFHLEdBQUcsU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLEdBQUcsY0FBYyxHQUFHLENBQUMsQ0FBQzt3QkFDckUsQ0FBQzt3QkFDRCxHQUFHLEVBQUU7NEJBQ0QsTUFBTSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUM7d0JBQ3pCLENBQUM7d0JBQ0QsTUFBTSxFQUFFOzRCQUNKLE1BQU0sQ0FBQyxTQUFTLENBQUMsR0FBRyxHQUFHLFNBQVMsQ0FBQyxNQUFNLENBQUM7d0JBQzVDLENBQUM7cUJBQ0osQ0FBQztvQkFFRixJQUFJLFdBQXVDLENBQUM7b0JBQzVDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7d0JBQ1gsS0FBSyxPQUFPOzRCQUNSLFdBQVcsR0FBRztnQ0FDVixHQUFHLEVBQUUsV0FBVyxDQUFDLElBQUksQ0FBQyxFQUFFO2dDQUN4QixJQUFJLEVBQUUsVUFBVSxDQUFDLElBQUksQ0FBQyxFQUFFOzZCQUMzQixDQUFDOzRCQUNGLEtBQUssQ0FBQzt3QkFDVixLQUFLLE1BQU07NEJBQ1AsV0FBVyxHQUFHO2dDQUNWLEdBQUcsRUFBRSxXQUFXLENBQUMsSUFBSSxDQUFDLEVBQUU7Z0NBQ3hCLElBQUksRUFBRSxTQUFTLENBQUMsSUFBSSxHQUFHLGFBQWE7NkJBQ3ZDLENBQUM7NEJBQ0YsS0FBSyxDQUFDO3dCQUNWLEtBQUssUUFBUTs0QkFDVCxXQUFXLEdBQUc7Z0NBQ1YsR0FBRyxFQUFFLFdBQVcsQ0FBQyxJQUFJLENBQUMsRUFBRTtnQ0FDeEIsSUFBSSxFQUFFLFVBQVUsQ0FBQyxJQUFJLENBQUMsRUFBRTs2QkFDM0IsQ0FBQzs0QkFDRixLQUFLLENBQUM7d0JBQ1Y7NEJBQ0ksV0FBVyxHQUFHO2dDQUNWLEdBQUcsRUFBRSxTQUFTLENBQUMsR0FBRyxHQUFHLGNBQWM7Z0NBQ25DLElBQUksRUFBRSxVQUFVLENBQUMsSUFBSSxDQUFDLEVBQUU7NkJBQzNCLENBQUM7NEJBQ0YsS0FBSyxDQUFDO29CQUNkLENBQUM7b0JBRUQsTUFBTSxDQUFDLFdBQVcsQ0FBQztnQkFDdkIsQ0FBQztnQkFDTCxzQkFBQztZQUFELENBckpBLEFBcUpDLElBQUE7WUFySkQsNkNBcUpDLENBQUE7WUFFWSw2QkFBQSxlQUFlLEdBQUcsSUFBSSxlQUFlLEVBQUUsQ0FBQSxDQUFDIiwiZmlsZSI6ImRldi9hdXRvY29tcGxldGUvcG9zaXRpb24uanMiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIGJvb3RzdHJhcFxuICovXG5pbXBvcnQge1xuICAgIEluamVjdGFibGUsXG4gICAgRWxlbWVudFJlZlxufSBmcm9tICdhbmd1bGFyMi9jb3JlJztcbmltcG9ydCB7SUF0dHJpYnV0ZX0gZnJvbSAnLi9JQXR0cmlidXRlJztcblxuZXhwb3J0IGNsYXNzIFBvc2l0aW9uU2VydmljZSB7XG4gICAgcHJpdmF0ZSBnZXQgd2luZG93KCk6YW55IHtcbiAgICAgICAgcmV0dXJuIHdpbmRvdztcbiAgICB9XG5cbiAgICBwcml2YXRlIGdldCBkb2N1bWVudCgpOmFueSB7XG4gICAgICAgIHJldHVybiB3aW5kb3cuZG9jdW1lbnQ7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBnZXRTdHlsZShuYXRpdmVFbDphbnksIGNzc1Byb3A6c3RyaW5nKTphbnkge1xuICAgICAgICAvLyBJRVxuICAgICAgICBpZiAobmF0aXZlRWwuY3VycmVudFN0eWxlKSB7XG4gICAgICAgICAgICByZXR1cm4gbmF0aXZlRWwuY3VycmVudFN0eWxlW2Nzc1Byb3BdO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHRoaXMud2luZG93LmdldENvbXB1dGVkU3R5bGUpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLndpbmRvdy5nZXRDb21wdXRlZFN0eWxlKG5hdGl2ZUVsKVtjc3NQcm9wXTtcbiAgICAgICAgfVxuICAgICAgICAvLyBmaW5hbGx5IHRyeSBhbmQgZ2V0IGlubGluZSBzdHlsZVxuICAgICAgICByZXR1cm4gbmF0aXZlRWwuc3R5bGVbY3NzUHJvcF07XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBDaGVja3MgaWYgYSBnaXZlbiBlbGVtZW50IGlzIHN0YXRpY2FsbHkgcG9zaXRpb25lZFxuICAgICAqIEBwYXJhbSBuYXRpdmVFbCAtIHJhdyBET00gZWxlbWVudFxuICAgICAqL1xuICAgIHByaXZhdGUgaXNTdGF0aWNQb3NpdGlvbmVkKG5hdGl2ZUVsOmFueSk6YW55IHtcbiAgICAgICAgcmV0dXJuICh0aGlzLmdldFN0eWxlKG5hdGl2ZUVsLCAncG9zaXRpb24nKSB8fCAnc3RhdGljJyApID09PSAnc3RhdGljJztcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIHJldHVybnMgdGhlIGNsb3Nlc3QsIG5vbi1zdGF0aWNhbGx5IHBvc2l0aW9uZWQgcGFyZW50T2Zmc2V0IG9mIGEgZ2l2ZW4gZWxlbWVudFxuICAgICAqIEBwYXJhbSBuYXRpdmVFbFxuICAgICAqL1xuICAgIHByaXZhdGUgcGFyZW50T2Zmc2V0RWwobmF0aXZlRWw6YW55KSB7XG4gICAgICAgIGxldCBvZmZzZXRQYXJlbnQgPSBuYXRpdmVFbC5vZmZzZXRQYXJlbnQgfHwgdGhpcy5kb2N1bWVudDtcbiAgICAgICAgd2hpbGUgKG9mZnNldFBhcmVudCAmJiBvZmZzZXRQYXJlbnQgIT09IHRoaXMuZG9jdW1lbnQgJiZcbiAgICAgICAgdGhpcy5pc1N0YXRpY1Bvc2l0aW9uZWQob2Zmc2V0UGFyZW50KSkge1xuICAgICAgICAgICAgb2Zmc2V0UGFyZW50ID0gb2Zmc2V0UGFyZW50Lm9mZnNldFBhcmVudDtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gb2Zmc2V0UGFyZW50IHx8IHRoaXMuZG9jdW1lbnQ7XG4gICAgfTtcblxuICAgIC8qKlxuICAgICAqIFByb3ZpZGVzIHJlYWQtb25seSBlcXVpdmFsZW50IG9mIGpRdWVyeSdzIHBvc2l0aW9uIGZ1bmN0aW9uOlxuICAgICAqIGh0dHA6Ly9hcGkuanF1ZXJ5LmNvbS9wb3NpdGlvbi9cbiAgICAgKi9cbiAgICBwdWJsaWMgcG9zaXRpb24obmF0aXZlRWw6YW55KTp7d2lkdGg6IG51bWJlciwgaGVpZ2h0OiBudW1iZXIsIHRvcDogbnVtYmVyLCBsZWZ0OiBudW1iZXJ9IHtcbiAgICAgICAgbGV0IGVsQkNSID0gdGhpcy5vZmZzZXQobmF0aXZlRWwpO1xuICAgICAgICBsZXQgb2Zmc2V0UGFyZW50QkNSID0ge3RvcDogMCwgbGVmdDogMH07XG4gICAgICAgIGxldCBvZmZzZXRQYXJlbnRFbCA9IHRoaXMucGFyZW50T2Zmc2V0RWwobmF0aXZlRWwpO1xuICAgICAgICBpZiAob2Zmc2V0UGFyZW50RWwgIT09IHRoaXMuZG9jdW1lbnQpIHtcbiAgICAgICAgICAgIG9mZnNldFBhcmVudEJDUiA9IHRoaXMub2Zmc2V0KG9mZnNldFBhcmVudEVsKTtcbiAgICAgICAgICAgIG9mZnNldFBhcmVudEJDUi50b3AgKz0gb2Zmc2V0UGFyZW50RWwuY2xpZW50VG9wIC0gb2Zmc2V0UGFyZW50RWwuc2Nyb2xsVG9wO1xuICAgICAgICAgICAgb2Zmc2V0UGFyZW50QkNSLmxlZnQgKz0gb2Zmc2V0UGFyZW50RWwuY2xpZW50TGVmdCAtIG9mZnNldFBhcmVudEVsLnNjcm9sbExlZnQ7XG4gICAgICAgIH1cblxuICAgICAgICBsZXQgYm91bmRpbmdDbGllbnRSZWN0ID0gbmF0aXZlRWwuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICB3aWR0aDogYm91bmRpbmdDbGllbnRSZWN0LndpZHRoIHx8IG5hdGl2ZUVsLm9mZnNldFdpZHRoLFxuICAgICAgICAgICAgaGVpZ2h0OiBib3VuZGluZ0NsaWVudFJlY3QuaGVpZ2h0IHx8IG5hdGl2ZUVsLm9mZnNldEhlaWdodCxcbiAgICAgICAgICAgIHRvcDogZWxCQ1IudG9wIC0gb2Zmc2V0UGFyZW50QkNSLnRvcCxcbiAgICAgICAgICAgIGxlZnQ6IGVsQkNSLmxlZnQgLSBvZmZzZXRQYXJlbnRCQ1IubGVmdFxuICAgICAgICB9O1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFByb3ZpZGVzIHJlYWQtb25seSBlcXVpdmFsZW50IG9mIGpRdWVyeSdzIG9mZnNldCBmdW5jdGlvbjpcbiAgICAgKiBodHRwOi8vYXBpLmpxdWVyeS5jb20vb2Zmc2V0L1xuICAgICAqL1xuICAgIHB1YmxpYyBvZmZzZXQobmF0aXZlRWw6YW55KTp7d2lkdGg6IG51bWJlciwgaGVpZ2h0OiBudW1iZXIsIHRvcDogbnVtYmVyLCBsZWZ0OiBudW1iZXJ9IHtcbiAgICAgICAgbGV0IGJvdW5kaW5nQ2xpZW50UmVjdCA9IG5hdGl2ZUVsLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgd2lkdGg6IGJvdW5kaW5nQ2xpZW50UmVjdC53aWR0aCB8fCBuYXRpdmVFbC5vZmZzZXRXaWR0aCxcbiAgICAgICAgICAgIGhlaWdodDogYm91bmRpbmdDbGllbnRSZWN0LmhlaWdodCB8fCBuYXRpdmVFbC5vZmZzZXRIZWlnaHQsXG4gICAgICAgICAgICB0b3A6IGJvdW5kaW5nQ2xpZW50UmVjdC50b3AgKyAodGhpcy53aW5kb3cucGFnZVlPZmZzZXQgfHwgdGhpcy5kb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuc2Nyb2xsVG9wKSxcbiAgICAgICAgICAgIGxlZnQ6IGJvdW5kaW5nQ2xpZW50UmVjdC5sZWZ0ICsgKHRoaXMud2luZG93LnBhZ2VYT2Zmc2V0IHx8IHRoaXMuZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LnNjcm9sbExlZnQpXG4gICAgICAgIH07XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUHJvdmlkZXMgY29vcmRpbmF0ZXMgZm9yIHRoZSB0YXJnZXRFbCBpbiByZWxhdGlvbiB0byBob3N0RWxcbiAgICAgKi9cbiAgICBwdWJsaWMgcG9zaXRpb25FbGVtZW50cyhob3N0RWw6YW55LCB0YXJnZXRFbDphbnksIHBvc2l0aW9uU3RyOmFueSwgYXBwZW5kVG9Cb2R5OmFueSk6e3RvcDogbnVtYmVyLCBsZWZ0OiBudW1iZXJ9IHtcbiAgICAgICAgbGV0IHBvc2l0aW9uU3RyUGFydHMgPSBwb3NpdGlvblN0ci5zcGxpdCgnLScpO1xuICAgICAgICBsZXQgcG9zMCA9IHBvc2l0aW9uU3RyUGFydHNbMF07XG4gICAgICAgIGxldCBwb3MxID0gcG9zaXRpb25TdHJQYXJ0c1sxXSB8fCAnY2VudGVyJztcbiAgICAgICAgbGV0IGhvc3RFbFBvcyA9IGFwcGVuZFRvQm9keSA/XG4gICAgICAgICAgICB0aGlzLm9mZnNldChob3N0RWwpIDpcbiAgICAgICAgICAgIHRoaXMucG9zaXRpb24oaG9zdEVsKTtcbiAgICAgICAgbGV0IHRhcmdldEVsV2lkdGggPSB0YXJnZXRFbC5vZmZzZXRXaWR0aDtcbiAgICAgICAgbGV0IHRhcmdldEVsSGVpZ2h0ID0gdGFyZ2V0RWwub2Zmc2V0SGVpZ2h0O1xuXG4gICAgICAgIGxldCBzaGlmdFdpZHRoOklBdHRyaWJ1dGUgPSB7XG4gICAgICAgICAgICBjZW50ZXI6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gaG9zdEVsUG9zLmxlZnQgKyBob3N0RWxQb3Mud2lkdGggLyAyIC0gdGFyZ2V0RWxXaWR0aCAvIDI7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgbGVmdDogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBob3N0RWxQb3MubGVmdDtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICByaWdodDogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBob3N0RWxQb3MubGVmdCArIGhvc3RFbFBvcy53aWR0aDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcblxuICAgICAgICBsZXQgc2hpZnRIZWlnaHQ6SUF0dHJpYnV0ZSA9IHtcbiAgICAgICAgICAgIGNlbnRlcjogZnVuY3Rpb24gKCk6bnVtYmVyIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gaG9zdEVsUG9zLnRvcCArIGhvc3RFbFBvcy5oZWlnaHQgLyAyIC0gdGFyZ2V0RWxIZWlnaHQgLyAyO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHRvcDogZnVuY3Rpb24gKCk6bnVtYmVyIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gaG9zdEVsUG9zLnRvcDtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBib3R0b206IGZ1bmN0aW9uICgpOm51bWJlciB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGhvc3RFbFBvcy50b3AgKyBob3N0RWxQb3MuaGVpZ2h0O1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuXG4gICAgICAgIGxldCB0YXJnZXRFbFBvczp7dG9wOiBudW1iZXIsIGxlZnQ6IG51bWJlcn07XG4gICAgICAgIHN3aXRjaCAocG9zMCkge1xuICAgICAgICAgICAgY2FzZSAncmlnaHQnOlxuICAgICAgICAgICAgICAgIHRhcmdldEVsUG9zID0ge1xuICAgICAgICAgICAgICAgICAgICB0b3A6IHNoaWZ0SGVpZ2h0W3BvczFdKCksXG4gICAgICAgICAgICAgICAgICAgIGxlZnQ6IHNoaWZ0V2lkdGhbcG9zMF0oKVxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICdsZWZ0JzpcbiAgICAgICAgICAgICAgICB0YXJnZXRFbFBvcyA9IHtcbiAgICAgICAgICAgICAgICAgICAgdG9wOiBzaGlmdEhlaWdodFtwb3MxXSgpLFxuICAgICAgICAgICAgICAgICAgICBsZWZ0OiBob3N0RWxQb3MubGVmdCAtIHRhcmdldEVsV2lkdGhcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAnYm90dG9tJzpcbiAgICAgICAgICAgICAgICB0YXJnZXRFbFBvcyA9IHtcbiAgICAgICAgICAgICAgICAgICAgdG9wOiBzaGlmdEhlaWdodFtwb3MwXSgpLFxuICAgICAgICAgICAgICAgICAgICBsZWZ0OiBzaGlmdFdpZHRoW3BvczFdKClcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICB0YXJnZXRFbFBvcyA9IHtcbiAgICAgICAgICAgICAgICAgICAgdG9wOiBob3N0RWxQb3MudG9wIC0gdGFyZ2V0RWxIZWlnaHQsXG4gICAgICAgICAgICAgICAgICAgIGxlZnQ6IHNoaWZ0V2lkdGhbcG9zMV0oKVxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gdGFyZ2V0RWxQb3M7XG4gICAgfVxufVxuXG5leHBvcnQgY29uc3QgcG9zaXRpb25TZXJ2aWNlID0gbmV3IFBvc2l0aW9uU2VydmljZSgpO1xuIl19
