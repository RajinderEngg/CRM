System.register(['angular2/platform/browser', './autocomplete-example'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var browser_1, autocomplete_example_1;
    return {
        setters:[
            function (browser_1_1) {
                browser_1 = browser_1_1;
            },
            function (autocomplete_example_1_1) {
                autocomplete_example_1 = autocomplete_example_1_1;
            }],
        execute: function() {
            browser_1.bootstrap(autocomplete_example_1.Angular2Autocomplete);
        }
    }
});
/*
Copyright 2016 angulartypescript.com. All Rights Reserved.
Everyone can use this source code; don’t forget to indicate the source please:
http://www.angulartypescript.com/
*/

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldi9hdXRvY29tcGxldGUvbWFpbi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7O1lBTUEsbUJBQVMsQ0FBQywyQ0FBb0IsQ0FBQyxDQUFDOzs7O0FBR2hDOzs7O0VBSUUiLCJmaWxlIjoiZGV2L2F1dG9jb21wbGV0ZS9tYWluLmpzIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBDcmVhdGVkIGJ5IFRhcmVxIEJvdWxha2phci4gZnJvbSBhbmd1bGFydHlwZXNjcmlwdC5jb21cbiAqL1xuaW1wb3J0IHtib290c3RyYXB9ICBmcm9tICdhbmd1bGFyMi9wbGF0Zm9ybS9icm93c2VyJztcbmltcG9ydCB7QW5ndWxhcjJBdXRvY29tcGxldGV9IGZyb20gJy4vYXV0b2NvbXBsZXRlLWV4YW1wbGUnO1xuXG5ib290c3RyYXAoQW5ndWxhcjJBdXRvY29tcGxldGUpO1xuXG5cbi8qXG5Db3B5cmlnaHQgMjAxNiBhbmd1bGFydHlwZXNjcmlwdC5jb20uIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG5FdmVyeW9uZSBjYW4gdXNlIHRoaXMgc291cmNlIGNvZGU7IGRvbuKAmXQgZm9yZ2V0IHRvIGluZGljYXRlIHRoZSBzb3VyY2UgcGxlYXNlOlxuaHR0cDovL3d3dy5hbmd1bGFydHlwZXNjcmlwdC5jb20vIFxuKi9cbiJdfQ==
