System.register(['angular2/core', 'angular2/common', './sanitize', './autocomplete-container', './options.class'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, core_2, common_1, sanitize_1, autocomplete_container_1, options_class_1;
    var Autocomplete;
    function setProperty(renderer, elementRef, propName, propValue) {
        renderer.setElementProperty(elementRef.nativeElement, propName, propValue);
    }
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
                core_2 = core_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (sanitize_1_1) {
                sanitize_1 = sanitize_1_1;
            },
            function (autocomplete_container_1_1) {
                autocomplete_container_1 = autocomplete_container_1_1;
            },
            function (options_class_1_1) {
                options_class_1 = options_class_1_1;
            }],
        execute: function() {
            Autocomplete = (function () {
                function Autocomplete(cd, element, renderer, loader) {
                    this.cd = cd;
                    this.element = element;
                    this.renderer = renderer;
                    this.loader = loader;
                    this.autocompleteLoading = new core_2.EventEmitter();
                    this.autocompleteNoResults = new core_2.EventEmitter();
                    this.autocompleteOnSelect = new core_2.EventEmitter();
                    this.autocompleteAsync = null;
                    this.autocompleteLatinize = true;
                    this.autocompleteSingleWords = true;
                    this.autocompleteWordDelimiters = ' ';
                    this.autocompletePhraseDelimiters = '\'"';
                    this._matches = [];
                    this.placement = 'bottom-left';
                }
                Object.defineProperty(Autocomplete.prototype, "matches", {
                    get: function () {
                        return this._matches;
                    },
                    enumerable: true,
                    configurable: true
                });
                Autocomplete.prototype.debounce = function (func, wait) {
                    var timeout;
                    var args;
                    var timestamp;
                    var waitOriginal = wait;
                    return function () {
                        // save details of latest call
                        args = [].slice.call(arguments, 0);
                        timestamp = Date.now();
                        // this trick is about implementing of 'autocompleteWaitMs'
                        // in this case we have adaptive 'wait' parameter
                        // we should use standard 'wait'('waitOriginal') in case of
                        // popup is opened, otherwise - 'autocompleteWaitMs' parameter
                        wait = this.container ? waitOriginal : this.autocompleteWaitMs;
                        // this is where the magic happens
                        var later = function () {
                            // how long ago was the last call
                            var last = Date.now() - timestamp;
                            // if the latest call was less that the wait period ago
                            // then we reset the timeout to wait for the difference
                            if (last < wait) {
                                timeout = setTimeout(later, wait - last);
                            }
                            else {
                                timeout = null;
                                func.apply(this, args);
                            }
                        };
                        // we only need to set the timer now if one isn't already running
                        if (!timeout) {
                            timeout = setTimeout(later, wait);
                        }
                    };
                };
                Autocomplete.prototype.processMatches = function () {
                    this._matches = [];
                    if (this.cd.model.toString().length >= this.autocompleteMinLength) {
                        // If singleWords, break model here to not be doing extra work on each iteration
                        var normalizedQuery = (this.autocompleteLatinize ? sanitize_1.AutocompleteUtils.latinize(this.cd.model) : this.cd.model).toString().toLowerCase();
                        normalizedQuery = this.autocompleteSingleWords ? sanitize_1.AutocompleteUtils.tokenize(normalizedQuery, this.autocompleteWordDelimiters, this.autocompletePhraseDelimiters) : normalizedQuery;
                        for (var i = 0; i < this.autocomplete.length; i++) {
                            var match = void 0;
                            if (typeof this.autocomplete[i] === 'object' &&
                                this.autocomplete[i][this.autocompleteOptionField]) {
                                match = this.autocompleteLatinize ? sanitize_1.AutocompleteUtils.latinize(this.autocomplete[i][this.autocompleteOptionField].toString()) : this.autocomplete[i][this.autocompleteOptionField].toString();
                            }
                            if (typeof this.autocomplete[i] === 'string') {
                                match = this.autocompleteLatinize ? sanitize_1.AutocompleteUtils.latinize(this.autocomplete[i].toString()) : this.autocomplete[i].toString();
                            }
                            if (!match) {
                                console.log('Invalid match type', typeof this.autocomplete[i], this.autocompleteOptionField);
                                continue;
                            }
                            if (this.testMatch(match.toLowerCase(), normalizedQuery)) {
                                this._matches.push(this.autocomplete[i]);
                                if (this._matches.length > this.autocompleteOptionsLimit - 1) {
                                    break;
                                }
                            }
                        }
                    }
                };
                Autocomplete.prototype.testMatch = function (match, test) {
                    var spaceLength;
                    if (typeof test === 'object') {
                        spaceLength = test.length;
                        for (var i = 0; i < spaceLength; i += 1) {
                            if (test[i].length > 0 && match.indexOf(test[i]) < 0) {
                                return false;
                            }
                        }
                        return true;
                    }
                    else {
                        return match.indexOf(test) >= 0;
                    }
                };
                Autocomplete.prototype.finalizeAsyncCall = function () {
                    this.autocompleteLoading.emit(false);
                    this.autocompleteNoResults.emit(this.cd.model.toString().length >=
                        this.autocompleteMinLength && this.matches.length <= 0);
                    if (this.cd.model.toString().length <= 0 || this._matches.length <= 0) {
                        this.hide();
                        return;
                    }
                    if (this.container && this._matches.length > 0) {
                        // This improves the speedas it won't have to be done for each list item
                        var normalizedQuery = (this.autocompleteLatinize ? sanitize_1.AutocompleteUtils.latinize(this.cd.model) : this.cd.model).toString().toLowerCase();
                        this.container.query = this.autocompleteSingleWords ? sanitize_1.AutocompleteUtils.tokenize(normalizedQuery, this.autocompleteWordDelimiters, this.autocompletePhraseDelimiters) : normalizedQuery;
                        this.container.matches = this._matches;
                    }
                    if (!this.container && this._matches.length > 0) {
                        this.show(this._matches);
                    }
                };
                Autocomplete.prototype.ngOnInit = function () {
                    var _this = this;
                    // this.autocompleteMinLength = 3;
                    this.autocompleteOptionsLimit = this.autocompleteOptionsLimit || 20;
                    this.autocompleteMinLength = this.autocompleteMinLength || 1;
                    this.autocompleteWaitMs = this.autocompleteWaitMs || 0;
                    // async should be false in case of array
                    if (this.autocompleteAsync === null && typeof this.autocomplete !== 'function') {
                        this.autocompleteAsync = false;
                    }
                    // async should be true for any case of function
                    if (typeof this.autocomplete === 'function') {
                        this.autocompleteAsync = true;
                    }
                    if (this.autocompleteAsync === true) {
                        debugger;
                        this.debouncer = this.debounce(function () {
                            if (typeof _this.autocomplete === 'function') {
                                _this.autocomplete().then(function (matches) {
                                    _this._matches = [];
                                    if (_this.cd.model.toString().length >= _this.autocompleteMinLength) {
                                        for (var i = 0; i < matches.length; i++) {
                                            _this._matches.push(matches[i]);
                                            if (_this._matches.length > _this.autocompleteOptionsLimit - 1) {
                                                break;
                                            }
                                        }
                                    }
                                    _this.finalizeAsyncCall();
                                });
                            }
                            // source is array
                            if (typeof _this.autocomplete === 'object' && _this.autocomplete.length) {
                                _this.processMatches();
                                _this.finalizeAsyncCall();
                            }
                        }, 100);
                    }
                };
                Autocomplete.prototype.onChange = function (e) {
                    if (this.container) {
                        // esc
                        if (e.keyCode === 27) {
                            this.hide();
                            return;
                        }
                        // up
                        if (e.keyCode === 38) {
                            this.container.prevActiveMatch();
                            return;
                        }
                        // down
                        if (e.keyCode === 40) {
                            this.container.nextActiveMatch();
                            return;
                        }
                        // enter
                        if (e.keyCode === 13) {
                            this.container.selectActiveMatch();
                            return;
                        }
                    }
                    this.autocompleteLoading.emit(true);
                    if (this.autocompleteAsync === true) {
                        this.debouncer();
                    }
                    if (this.autocompleteAsync === false) {
                        this.processMatches();
                        this.finalizeAsyncCall();
                    }
                };
                Autocomplete.prototype.changeModel = function (value) {
                    var valueStr = ((typeof value === 'object' && this.autocompleteOptionField) ? value[this.autocompleteOptionField] : value).toString();
                    this.cd.viewToModelUpdate(valueStr);
                    setProperty(this.renderer, this.element, 'value', valueStr);
                    this.hide();
                };
                Autocomplete.prototype.show = function (matches) {
                    var _this = this;
                    var options = new options_class_1.AutocompleteOptions({
                        placement: this.placement,
                        animation: false
                    });
                    var binding = core_2.Injector.resolve([
                        new core_2.Provider(options_class_1.AutocompleteOptions, { useValue: options })
                    ]);
                    this.popup = this.loader
                        .loadNextToLocation(autocomplete_container_1.AutocompleteContainer, this.element, binding)
                        .then(function (componentRef) {
                        componentRef.instance.position(_this.element);
                        _this.container = componentRef.instance;
                        _this.container.parent = _this;
                        // This improves the speedas it won't have to be done for each list item
                        var normalizedQuery = (_this.autocompleteLatinize ? sanitize_1.AutocompleteUtils.latinize(_this.cd.model) : _this.cd.model).toString().toLowerCase();
                        _this.container.query = _this.autocompleteSingleWords ? sanitize_1.AutocompleteUtils.tokenize(normalizedQuery, _this.autocompleteWordDelimiters, _this.autocompletePhraseDelimiters) : normalizedQuery;
                        _this.container.matches = matches;
                        _this.container.field = _this.autocompleteOptionField;
                        _this.element.nativeElement.focus();
                        return componentRef;
                    });
                };
                Autocomplete.prototype.hide = function () {
                    var _this = this;
                    if (this.container) {
                        this.popup.then(function (componentRef) {
                            componentRef.dispose();
                            _this.container = null;
                            return componentRef;
                        });
                    }
                };
                __decorate([
                    core_2.Output(), 
                    __metadata('design:type', core_2.EventEmitter)
                ], Autocomplete.prototype, "autocompleteLoading", void 0);
                __decorate([
                    core_2.Output(), 
                    __metadata('design:type', core_2.EventEmitter)
                ], Autocomplete.prototype, "autocompleteNoResults", void 0);
                __decorate([
                    core_2.Output(), 
                    __metadata('design:type', core_2.EventEmitter)
                ], Autocomplete.prototype, "autocompleteOnSelect", void 0);
                __decorate([
                    core_2.Input(), 
                    __metadata('design:type', Object)
                ], Autocomplete.prototype, "autocomplete", void 0);
                __decorate([
                    core_2.Input(), 
                    __metadata('design:type', Number)
                ], Autocomplete.prototype, "autocompleteMinLength", void 0);
                __decorate([
                    core_2.Input(), 
                    __metadata('design:type', Number)
                ], Autocomplete.prototype, "autocompleteWaitMs", void 0);
                __decorate([
                    core_2.Input(), 
                    __metadata('design:type', Number)
                ], Autocomplete.prototype, "autocompleteOptionsLimit", void 0);
                __decorate([
                    core_2.Input(), 
                    __metadata('design:type', String)
                ], Autocomplete.prototype, "autocompleteOptionField", void 0);
                __decorate([
                    core_2.Input(), 
                    __metadata('design:type', Boolean)
                ], Autocomplete.prototype, "autocompleteAsync", void 0);
                __decorate([
                    core_2.Input(), 
                    __metadata('design:type', Boolean)
                ], Autocomplete.prototype, "autocompleteLatinize", void 0);
                __decorate([
                    core_2.Input(), 
                    __metadata('design:type', Boolean)
                ], Autocomplete.prototype, "autocompleteSingleWords", void 0);
                __decorate([
                    core_2.Input(), 
                    __metadata('design:type', String)
                ], Autocomplete.prototype, "autocompleteWordDelimiters", void 0);
                __decorate([
                    core_2.Input(), 
                    __metadata('design:type', String)
                ], Autocomplete.prototype, "autocompletePhraseDelimiters", void 0);
                __decorate([
                    core_2.HostListener('keyup', ['$event']), 
                    __metadata('design:type', Function), 
                    __metadata('design:paramtypes', [KeyboardEvent]), 
                    __metadata('design:returntype', void 0)
                ], Autocomplete.prototype, "onChange", null);
                Autocomplete = __decorate([
                    core_2.Directive({
                        selector: 'autocomplete[ngModel], [ngModel][autocomplete]'
                    }), 
                    __metadata('design:paramtypes', [common_1.NgModel, core_1.ElementRef, core_2.Renderer, core_2.DynamicComponentLoader])
                ], Autocomplete);
                return Autocomplete;
            }());
            exports_1("Autocomplete", Autocomplete);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldi9hdXRvY29tcGxldGUvYXV0b2NvbXBsZXRlLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7OztJQWFBLHFCQUFxQixRQUFpQixFQUFFLFVBQXFCLEVBQUUsUUFBZSxFQUFFLFNBQWE7UUFDekYsUUFBUSxDQUFDLGtCQUFrQixDQUFDLFVBQVUsQ0FBQyxhQUFhLEVBQUUsUUFBUSxFQUFFLFNBQVMsQ0FBQyxDQUFDO0lBQy9FLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1lBYUQ7Z0JBeUJJLHNCQUFvQixFQUFVLEVBQ1YsT0FBa0IsRUFDbEIsUUFBaUIsRUFDakIsTUFBNkI7b0JBSDdCLE9BQUUsR0FBRixFQUFFLENBQVE7b0JBQ1YsWUFBTyxHQUFQLE9BQU8sQ0FBVztvQkFDbEIsYUFBUSxHQUFSLFFBQVEsQ0FBUztvQkFDakIsV0FBTSxHQUFOLE1BQU0sQ0FBdUI7b0JBM0JoQyx3QkFBbUIsR0FBeUIsSUFBSSxtQkFBWSxFQUFFLENBQUM7b0JBQy9ELDBCQUFxQixHQUF5QixJQUFJLG1CQUFZLEVBQUUsQ0FBQztvQkFDakUseUJBQW9CLEdBQTZCLElBQUksbUJBQVksRUFBRSxDQUFDO29CQU9yRSxzQkFBaUIsR0FBVyxJQUFJLENBQUM7b0JBQ2pDLHlCQUFvQixHQUFXLElBQUksQ0FBQztvQkFDcEMsNEJBQXVCLEdBQVcsSUFBSSxDQUFDO29CQUN2QywrQkFBMEIsR0FBVSxHQUFHLENBQUM7b0JBQ3hDLGlDQUE0QixHQUFVLEtBQUssQ0FBQztvQkFPcEQsYUFBUSxHQUFjLEVBQUUsQ0FBQztvQkFDekIsY0FBUyxHQUFVLGFBQWEsQ0FBQztnQkFPekMsQ0FBQztnQkFFRCxzQkFBVyxpQ0FBTzt5QkFBbEI7d0JBQ0ksTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUM7b0JBQ3pCLENBQUM7OzttQkFBQTtnQkFFTywrQkFBUSxHQUFoQixVQUFpQixJQUFhLEVBQUUsSUFBVztvQkFDdkMsSUFBSSxPQUFXLENBQUM7b0JBQ2hCLElBQUksSUFBZSxDQUFDO29CQUNwQixJQUFJLFNBQWdCLENBQUM7b0JBQ3JCLElBQUksWUFBWSxHQUFVLElBQUksQ0FBQztvQkFFL0IsTUFBTSxDQUFDO3dCQUNILDhCQUE4Qjt3QkFDOUIsSUFBSSxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsQ0FBQzt3QkFDbkMsU0FBUyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQzt3QkFFdkIsMkRBQTJEO3dCQUMzRCxpREFBaUQ7d0JBQ2pELDJEQUEyRDt3QkFDM0QsOERBQThEO3dCQUM5RCxJQUFJLEdBQUcsSUFBSSxDQUFDLFNBQVMsR0FBRyxZQUFZLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDO3dCQUUvRCxrQ0FBa0M7d0JBQ2xDLElBQUksS0FBSyxHQUFHOzRCQUVSLGlDQUFpQzs0QkFDakMsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxHQUFHLFNBQVMsQ0FBQzs0QkFFbEMsdURBQXVEOzRCQUN2RCx1REFBdUQ7NEJBQ3ZELEVBQUUsQ0FBQyxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dDQUNkLE9BQU8sR0FBRyxVQUFVLENBQUMsS0FBSyxFQUFFLElBQUksR0FBRyxJQUFJLENBQUMsQ0FBQzs0QkFFN0MsQ0FBQzs0QkFBQyxJQUFJLENBQUMsQ0FBQztnQ0FDSixPQUFPLEdBQUcsSUFBSSxDQUFDO2dDQUNmLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDOzRCQUMzQixDQUFDO3dCQUNMLENBQUMsQ0FBQzt3QkFFRixpRUFBaUU7d0JBQ2pFLEVBQUUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQzs0QkFDWCxPQUFPLEdBQUcsVUFBVSxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsQ0FBQzt3QkFDdEMsQ0FBQztvQkFDTCxDQUFDLENBQUM7Z0JBQ04sQ0FBQztnQkFFTyxxQ0FBYyxHQUF0QjtvQkFDSSxJQUFJLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQztvQkFDbkIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsUUFBUSxFQUFFLENBQUMsTUFBTSxJQUFJLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUM7d0JBQ2hFLGdGQUFnRjt3QkFDaEYsSUFBSSxlQUFlLEdBQUcsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLEdBQUcsNEJBQWlCLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxXQUFXLEVBQUUsQ0FBQzt3QkFDdkksZUFBZSxHQUFHLElBQUksQ0FBQyx1QkFBdUIsR0FBRyw0QkFBaUIsQ0FBQyxRQUFRLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQywwQkFBMEIsRUFBRSxJQUFJLENBQUMsNEJBQTRCLENBQUMsR0FBRyxlQUFlLENBQUM7d0JBQ25MLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQzs0QkFDaEQsSUFBSSxLQUFLLFNBQU8sQ0FBQzs0QkFFakIsRUFBRSxDQUFDLENBQUMsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxLQUFLLFFBQVE7Z0NBQ3hDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUNyRCxLQUFLLEdBQUcsSUFBSSxDQUFDLG9CQUFvQixHQUFHLDRCQUFpQixDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLFFBQVEsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQzs0QkFDbE0sQ0FBQzs0QkFFRCxFQUFFLENBQUMsQ0FBQyxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLEtBQUssUUFBUSxDQUFDLENBQUMsQ0FBQztnQ0FDM0MsS0FBSyxHQUFHLElBQUksQ0FBQyxvQkFBb0IsR0FBRyw0QkFBaUIsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUM7NEJBQ3RJLENBQUM7NEJBRUQsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO2dDQUNULE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLEVBQUUsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO2dDQUM3RixRQUFRLENBQUM7NEJBQ2IsQ0FBQzs0QkFFRCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxXQUFXLEVBQUUsRUFBRSxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQ3ZELElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDekMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLHdCQUF3QixHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7b0NBQzNELEtBQUssQ0FBQztnQ0FDVixDQUFDOzRCQUNMLENBQUM7d0JBQ0wsQ0FBQztvQkFDTCxDQUFDO2dCQUNMLENBQUM7Z0JBRU8sZ0NBQVMsR0FBakIsVUFBa0IsS0FBWSxFQUFFLElBQVE7b0JBQ3BDLElBQUksV0FBa0IsQ0FBQztvQkFFdkIsRUFBRSxDQUFDLENBQUMsT0FBTyxJQUFJLEtBQUssUUFBUSxDQUFDLENBQUMsQ0FBQzt3QkFDM0IsV0FBVyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUM7d0JBQzFCLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsV0FBVyxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQzs0QkFDdEMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUNuRCxNQUFNLENBQUMsS0FBSyxDQUFDOzRCQUNqQixDQUFDO3dCQUNMLENBQUM7d0JBQ0QsTUFBTSxDQUFDLElBQUksQ0FBQztvQkFDaEIsQ0FBQztvQkFBQyxJQUFJLENBQUMsQ0FBQzt3QkFDSixNQUFNLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBQ3BDLENBQUM7Z0JBQ0wsQ0FBQztnQkFFTyx3Q0FBaUIsR0FBekI7b0JBQ0ksSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDckMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQyxNQUFNO3dCQUMzRCxJQUFJLENBQUMscUJBQXFCLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUM7b0JBRTVELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLFFBQVEsRUFBRSxDQUFDLE1BQU0sSUFBSSxDQUFDLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDcEUsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO3dCQUNaLE1BQU0sQ0FBQztvQkFDWCxDQUFDO29CQUVELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDN0Msd0VBQXdFO3dCQUN4RSxJQUFJLGVBQWUsR0FBRyxDQUFDLElBQUksQ0FBQyxvQkFBb0IsR0FBRyw0QkFBaUIsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsRUFBRSxDQUFDLFdBQVcsRUFBRSxDQUFDO3dCQUN2SSxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsdUJBQXVCLEdBQUcsNEJBQWlCLENBQUMsUUFBUSxDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUMsMEJBQTBCLEVBQUUsSUFBSSxDQUFDLDRCQUE0QixDQUFDLEdBQUcsZUFBZSxDQUFDO3dCQUN4TCxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDO29CQUMzQyxDQUFDO29CQUVELEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUM5QyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFDN0IsQ0FBQztnQkFDTCxDQUFDO2dCQUVELCtCQUFRLEdBQVI7b0JBQUEsaUJBMENDO29CQXpDRSxrQ0FBa0M7b0JBQ2pDLElBQUksQ0FBQyx3QkFBd0IsR0FBRyxJQUFJLENBQUMsd0JBQXdCLElBQUksRUFBRSxDQUFDO29CQUNwRSxJQUFJLENBQUMscUJBQXFCLEdBQUcsSUFBSSxDQUFDLHFCQUFxQixJQUFJLENBQUMsQ0FBQztvQkFDN0QsSUFBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQyxrQkFBa0IsSUFBSSxDQUFDLENBQUM7b0JBRXZELHlDQUF5QztvQkFDekMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLGlCQUFpQixLQUFLLElBQUksSUFBSSxPQUFPLElBQUksQ0FBQyxZQUFZLEtBQUssVUFBVSxDQUFDLENBQUMsQ0FBQzt3QkFDN0UsSUFBSSxDQUFDLGlCQUFpQixHQUFHLEtBQUssQ0FBQztvQkFDbkMsQ0FBQztvQkFFRCxnREFBZ0Q7b0JBQ2hELEVBQUUsQ0FBQyxDQUFDLE9BQU8sSUFBSSxDQUFDLFlBQVksS0FBSyxVQUFVLENBQUMsQ0FBQyxDQUFDO3dCQUMxQyxJQUFJLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDO29CQUNsQyxDQUFDO29CQUVELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDO3dCQUNsQyxRQUFRLENBQUM7d0JBQ1QsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDOzRCQUMzQixFQUFFLENBQUMsQ0FBQyxPQUFPLEtBQUksQ0FBQyxZQUFZLEtBQUssVUFBVSxDQUFDLENBQUMsQ0FBQztnQ0FDMUMsS0FBSSxDQUFDLFlBQVksRUFBRSxDQUFDLElBQUksQ0FBQyxVQUFDLE9BQWE7b0NBQ25DLEtBQUksQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDO29DQUNuQixFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQyxNQUFNLElBQUksS0FBSSxDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQzt3Q0FDaEUsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxPQUFPLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUM7NENBQ3RDLEtBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOzRDQUMvQixFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxLQUFJLENBQUMsd0JBQXdCLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztnREFDM0QsS0FBSyxDQUFDOzRDQUNWLENBQUM7d0NBQ0wsQ0FBQztvQ0FDTCxDQUFDO29DQUVELEtBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO2dDQUM3QixDQUFDLENBQUMsQ0FBQzs0QkFDUCxDQUFDOzRCQUVELGtCQUFrQjs0QkFDbEIsRUFBRSxDQUFDLENBQUMsT0FBTyxLQUFJLENBQUMsWUFBWSxLQUFLLFFBQVEsSUFBSSxLQUFJLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7Z0NBQ3BFLEtBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztnQ0FDdEIsS0FBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7NEJBQzdCLENBQUM7d0JBQ0wsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO29CQUNaLENBQUM7Z0JBQ0wsQ0FBQztnQkFHRCwrQkFBUSxHQUFSLFVBQVMsQ0FBZTtvQkFDcEIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7d0JBQ2pCLE1BQU07d0JBQ04sRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDOzRCQUNuQixJQUFJLENBQUMsSUFBSSxFQUFFLENBQUM7NEJBQ1osTUFBTSxDQUFDO3dCQUNYLENBQUM7d0JBRUQsS0FBSzt3QkFDTCxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUM7NEJBQ25CLElBQUksQ0FBQyxTQUFTLENBQUMsZUFBZSxFQUFFLENBQUM7NEJBQ2pDLE1BQU0sQ0FBQzt3QkFDWCxDQUFDO3dCQUVELE9BQU87d0JBQ1AsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDOzRCQUNuQixJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWUsRUFBRSxDQUFDOzRCQUNqQyxNQUFNLENBQUM7d0JBQ1gsQ0FBQzt3QkFFRCxRQUFRO3dCQUNSLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQzs0QkFDbkIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxpQkFBaUIsRUFBRSxDQUFDOzRCQUNuQyxNQUFNLENBQUM7d0JBQ1gsQ0FBQztvQkFDTCxDQUFDO29CQUVELElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBRXBDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDO3dCQUNsQyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7b0JBQ3JCLENBQUM7b0JBRUQsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLGlCQUFpQixLQUFLLEtBQUssQ0FBQyxDQUFDLENBQUM7d0JBQ25DLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQzt3QkFDdEIsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7b0JBQzdCLENBQUM7Z0JBQ0wsQ0FBQztnQkFFTSxrQ0FBVyxHQUFsQixVQUFtQixLQUFTO29CQUN4QixJQUFJLFFBQVEsR0FBVSxDQUFDLENBQUMsT0FBTyxLQUFLLEtBQUssUUFBUSxJQUFJLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsR0FBRyxLQUFLLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQztvQkFDN0ksSUFBSSxDQUFDLEVBQUUsQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFDcEMsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLE9BQU8sRUFBRSxPQUFPLEVBQUUsUUFBUSxDQUFDLENBQUM7b0JBQzVELElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDaEIsQ0FBQztnQkFFRCwyQkFBSSxHQUFKLFVBQUssT0FBa0I7b0JBQXZCLGlCQXlCQztvQkF4QkcsSUFBSSxPQUFPLEdBQUcsSUFBSSxtQ0FBbUIsQ0FBQzt3QkFDbEMsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO3dCQUN6QixTQUFTLEVBQUUsS0FBSztxQkFDbkIsQ0FBQyxDQUFDO29CQUVILElBQUksT0FBTyxHQUFHLGVBQVEsQ0FBQyxPQUFPLENBQUM7d0JBQzNCLElBQUksZUFBUSxDQUFDLG1DQUFtQixFQUFFLEVBQUMsUUFBUSxFQUFFLE9BQU8sRUFBQyxDQUFDO3FCQUN6RCxDQUFDLENBQUM7b0JBR0gsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsTUFBTTt5QkFDbkIsa0JBQWtCLENBQUMsOENBQXFCLEVBQUUsSUFBSSxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUM7eUJBQ2hFLElBQUksQ0FBQyxVQUFDLFlBQXlCO3dCQUM1QixZQUFZLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxLQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7d0JBQzdDLEtBQUksQ0FBQyxTQUFTLEdBQUcsWUFBWSxDQUFDLFFBQVEsQ0FBQzt3QkFDdkMsS0FBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEdBQUcsS0FBSSxDQUFDO3dCQUM3Qix3RUFBd0U7d0JBQ3hFLElBQUksZUFBZSxHQUFHLENBQUMsS0FBSSxDQUFDLG9CQUFvQixHQUFHLDRCQUFpQixDQUFDLFFBQVEsQ0FBQyxLQUFJLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLEtBQUksQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUMsV0FBVyxFQUFFLENBQUM7d0JBQ3ZJLEtBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLEtBQUksQ0FBQyx1QkFBdUIsR0FBRyw0QkFBaUIsQ0FBQyxRQUFRLENBQUMsZUFBZSxFQUFFLEtBQUksQ0FBQywwQkFBMEIsRUFBRSxLQUFJLENBQUMsNEJBQTRCLENBQUMsR0FBRyxlQUFlLENBQUM7d0JBQ3hMLEtBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQzt3QkFDakMsS0FBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsS0FBSSxDQUFDLHVCQUF1QixDQUFDO3dCQUNwRCxLQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxLQUFLLEVBQUUsQ0FBQzt3QkFDbkMsTUFBTSxDQUFDLFlBQVksQ0FBQztvQkFDeEIsQ0FBQyxDQUFDLENBQUM7Z0JBQ1gsQ0FBQztnQkFFRCwyQkFBSSxHQUFKO29CQUFBLGlCQVFDO29CQVBHLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO3dCQUNqQixJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxVQUFDLFlBQXlCOzRCQUN0QyxZQUFZLENBQUMsT0FBTyxFQUFFLENBQUM7NEJBQ3ZCLEtBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDOzRCQUN0QixNQUFNLENBQUMsWUFBWSxDQUFDO3dCQUN4QixDQUFDLENBQUMsQ0FBQztvQkFDUCxDQUFDO2dCQUNMLENBQUM7Z0JBaFJEO29CQUFDLGFBQU0sRUFBRTs7eUVBQUE7Z0JBQ1Q7b0JBQUMsYUFBTSxFQUFFOzsyRUFBQTtnQkFDVDtvQkFBQyxhQUFNLEVBQUU7OzBFQUFBO2dCQUVUO29CQUFDLFlBQUssRUFBRTs7a0VBQUE7Z0JBQ1I7b0JBQUMsWUFBSyxFQUFFOzsyRUFBQTtnQkFDUjtvQkFBQyxZQUFLLEVBQUU7O3dFQUFBO2dCQUNSO29CQUFDLFlBQUssRUFBRTs7OEVBQUE7Z0JBQ1I7b0JBQUMsWUFBSyxFQUFFOzs2RUFBQTtnQkFDUjtvQkFBQyxZQUFLLEVBQUU7O3VFQUFBO2dCQUNSO29CQUFDLFlBQUssRUFBRTs7MEVBQUE7Z0JBQ1I7b0JBQUMsWUFBSyxFQUFFOzs2RUFBQTtnQkFDUjtvQkFBQyxZQUFLLEVBQUU7O2dGQUFBO2dCQUNSO29CQUFDLFlBQUssRUFBRTs7a0ZBQUE7Z0JBaUxSO29CQUFDLG1CQUFZLENBQUMsT0FBTyxFQUFFLENBQUMsUUFBUSxDQUFDLENBQUM7Ozs7NERBQUE7Z0JBbE10QztvQkFBQyxnQkFBUyxDQUFDO3dCQUNQLFFBQVEsRUFBRSxnREFBZ0Q7cUJBQzdELENBQUM7O2dDQUFBO2dCQW1SRixtQkFBQztZQUFELENBbFJBLEFBa1JDLElBQUE7WUFsUkQsdUNBa1JDLENBQUEiLCJmaWxlIjoiZGV2L2F1dG9jb21wbGV0ZS9hdXRvY29tcGxldGUuY29tcG9uZW50LmpzIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBib290c3RyYXBcbiAqL1xuaW1wb3J0IHtDb21wb25lbnQsIEVsZW1lbnRSZWYsIFZpZXdFbmNhcHN1bGF0aW9ufSBmcm9tICdhbmd1bGFyMi9jb3JlJztcbmltcG9ydCB7Q09SRV9ESVJFQ1RJVkVTfSBmcm9tICdhbmd1bGFyMi9jb21tb24nO1xuaW1wb3J0IHtcbiAgICBEaXJlY3RpdmUsIElucHV0LCBPdXRwdXQsIEhvc3RMaXN0ZW5lcixcbiAgICBFdmVudEVtaXR0ZXIsIE9uSW5pdCxcbiAgICBFbGVtZW50UmVmLCBSZW5kZXJlcixcbiAgICBEeW5hbWljQ29tcG9uZW50TG9hZGVyLCBDb21wb25lbnRSZWYsIFByb3ZpZGVyLCBJbmplY3RvclxufSBmcm9tICdhbmd1bGFyMi9jb3JlJztcbmltcG9ydCB7TmdNb2RlbH1mcm9tICdhbmd1bGFyMi9jb21tb24nO1xuXG5mdW5jdGlvbiBzZXRQcm9wZXJ0eShyZW5kZXJlcjpSZW5kZXJlciwgZWxlbWVudFJlZjpFbGVtZW50UmVmLCBwcm9wTmFtZTpzdHJpbmcsIHByb3BWYWx1ZTphbnkpIHtcbiAgICByZW5kZXJlci5zZXRFbGVtZW50UHJvcGVydHkoZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LCBwcm9wTmFtZSwgcHJvcFZhbHVlKTtcbn1cblxuaW1wb3J0IHtwb3NpdGlvblNlcnZpY2V9IGZyb20gJy4vcG9zaXRpb24nO1xuaW1wb3J0IHtBdXRvY29tcGxldGVVdGlsc30gZnJvbSAnLi9zYW5pdGl6ZSc7XG5pbXBvcnQge0F1dG9jb21wbGV0ZUNvbnRhaW5lcn0gZnJvbSAnLi9hdXRvY29tcGxldGUtY29udGFpbmVyJztcbmltcG9ydCB7QXV0b2NvbXBsZXRlT3B0aW9uc30gZnJvbSAnLi9vcHRpb25zLmNsYXNzJztcblxuXG5cblxuQERpcmVjdGl2ZSh7XG4gICAgc2VsZWN0b3I6ICdhdXRvY29tcGxldGVbbmdNb2RlbF0sIFtuZ01vZGVsXVthdXRvY29tcGxldGVdJ1xufSlcbmV4cG9ydCBjbGFzcyBBdXRvY29tcGxldGUgaW1wbGVtZW50cyBPbkluaXQge1xuICAgIEBPdXRwdXQoKSBwdWJsaWMgYXV0b2NvbXBsZXRlTG9hZGluZzpFdmVudEVtaXR0ZXI8Ym9vbGVhbj4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XG4gICAgQE91dHB1dCgpIHB1YmxpYyBhdXRvY29tcGxldGVOb1Jlc3VsdHM6RXZlbnRFbWl0dGVyPGJvb2xlYW4+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xuICAgIEBPdXRwdXQoKSBwdWJsaWMgYXV0b2NvbXBsZXRlT25TZWxlY3Q6RXZlbnRFbWl0dGVyPHtpdGVtOiBhbnl9PiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcblxuICAgIEBJbnB1dCgpIHB1YmxpYyBhdXRvY29tcGxldGU6YW55O1xuICAgIEBJbnB1dCgpIHB1YmxpYyBhdXRvY29tcGxldGVNaW5MZW5ndGg6bnVtYmVyO1xuICAgIEBJbnB1dCgpIHB1YmxpYyBhdXRvY29tcGxldGVXYWl0TXM6bnVtYmVyO1xuICAgIEBJbnB1dCgpIHB1YmxpYyBhdXRvY29tcGxldGVPcHRpb25zTGltaXQ6bnVtYmVyO1xuICAgIEBJbnB1dCgpIHB1YmxpYyBhdXRvY29tcGxldGVPcHRpb25GaWVsZDpzdHJpbmc7XG4gICAgQElucHV0KCkgcHVibGljIGF1dG9jb21wbGV0ZUFzeW5jOmJvb2xlYW4gPSBudWxsO1xuICAgIEBJbnB1dCgpIHB1YmxpYyBhdXRvY29tcGxldGVMYXRpbml6ZTpib29sZWFuID0gdHJ1ZTtcbiAgICBASW5wdXQoKSBwdWJsaWMgYXV0b2NvbXBsZXRlU2luZ2xlV29yZHM6Ym9vbGVhbiA9IHRydWU7XG4gICAgQElucHV0KCkgcHVibGljIGF1dG9jb21wbGV0ZVdvcmREZWxpbWl0ZXJzOnN0cmluZyA9ICcgJztcbiAgICBASW5wdXQoKSBwdWJsaWMgYXV0b2NvbXBsZXRlUGhyYXNlRGVsaW1pdGVyczpzdHJpbmcgPSAnXFwnXCInO1xuXG5cblxuICAgIHB1YmxpYyBjb250YWluZXI6QXV0b2NvbXBsZXRlQ29udGFpbmVyO1xuXG4gICAgcHJpdmF0ZSBkZWJvdW5jZXI6RnVuY3Rpb247XG4gICAgcHJpdmF0ZSBfbWF0Y2hlczpBcnJheTxhbnk+ID0gW107XG4gICAgcHJpdmF0ZSBwbGFjZW1lbnQ6c3RyaW5nID0gJ2JvdHRvbS1sZWZ0JztcbiAgICBwcml2YXRlIHBvcHVwOlByb21pc2U8Q29tcG9uZW50UmVmPjtcblxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgY2Q6TmdNb2RlbCxcbiAgICAgICAgICAgICAgICBwcml2YXRlIGVsZW1lbnQ6RWxlbWVudFJlZixcbiAgICAgICAgICAgICAgICBwcml2YXRlIHJlbmRlcmVyOlJlbmRlcmVyLFxuICAgICAgICAgICAgICAgIHByaXZhdGUgbG9hZGVyOkR5bmFtaWNDb21wb25lbnRMb2FkZXIpIHtcbiAgICB9XG5cbiAgICBwdWJsaWMgZ2V0IG1hdGNoZXMoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9tYXRjaGVzO1xuICAgIH1cblxuICAgIHByaXZhdGUgZGVib3VuY2UoZnVuYzpGdW5jdGlvbiwgd2FpdDpudW1iZXIpOkZ1bmN0aW9uIHtcbiAgICAgICAgbGV0IHRpbWVvdXQ6YW55O1xuICAgICAgICBsZXQgYXJnczpBcnJheTxhbnk+O1xuICAgICAgICBsZXQgdGltZXN0YW1wOm51bWJlcjtcbiAgICAgICAgbGV0IHdhaXRPcmlnaW5hbDpudW1iZXIgPSB3YWl0O1xuXG4gICAgICAgIHJldHVybiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAvLyBzYXZlIGRldGFpbHMgb2YgbGF0ZXN0IGNhbGxcbiAgICAgICAgICAgIGFyZ3MgPSBbXS5zbGljZS5jYWxsKGFyZ3VtZW50cywgMCk7XG4gICAgICAgICAgICB0aW1lc3RhbXAgPSBEYXRlLm5vdygpO1xuXG4gICAgICAgICAgICAvLyB0aGlzIHRyaWNrIGlzIGFib3V0IGltcGxlbWVudGluZyBvZiAnYXV0b2NvbXBsZXRlV2FpdE1zJ1xuICAgICAgICAgICAgLy8gaW4gdGhpcyBjYXNlIHdlIGhhdmUgYWRhcHRpdmUgJ3dhaXQnIHBhcmFtZXRlclxuICAgICAgICAgICAgLy8gd2Ugc2hvdWxkIHVzZSBzdGFuZGFyZCAnd2FpdCcoJ3dhaXRPcmlnaW5hbCcpIGluIGNhc2Ugb2ZcbiAgICAgICAgICAgIC8vIHBvcHVwIGlzIG9wZW5lZCwgb3RoZXJ3aXNlIC0gJ2F1dG9jb21wbGV0ZVdhaXRNcycgcGFyYW1ldGVyXG4gICAgICAgICAgICB3YWl0ID0gdGhpcy5jb250YWluZXIgPyB3YWl0T3JpZ2luYWwgOiB0aGlzLmF1dG9jb21wbGV0ZVdhaXRNcztcblxuICAgICAgICAgICAgLy8gdGhpcyBpcyB3aGVyZSB0aGUgbWFnaWMgaGFwcGVuc1xuICAgICAgICAgICAgbGV0IGxhdGVyID0gZnVuY3Rpb24gKCkge1xuXG4gICAgICAgICAgICAgICAgLy8gaG93IGxvbmcgYWdvIHdhcyB0aGUgbGFzdCBjYWxsXG4gICAgICAgICAgICAgICAgbGV0IGxhc3QgPSBEYXRlLm5vdygpIC0gdGltZXN0YW1wO1xuXG4gICAgICAgICAgICAgICAgLy8gaWYgdGhlIGxhdGVzdCBjYWxsIHdhcyBsZXNzIHRoYXQgdGhlIHdhaXQgcGVyaW9kIGFnb1xuICAgICAgICAgICAgICAgIC8vIHRoZW4gd2UgcmVzZXQgdGhlIHRpbWVvdXQgdG8gd2FpdCBmb3IgdGhlIGRpZmZlcmVuY2VcbiAgICAgICAgICAgICAgICBpZiAobGFzdCA8IHdhaXQpIHtcbiAgICAgICAgICAgICAgICAgICAgdGltZW91dCA9IHNldFRpbWVvdXQobGF0ZXIsIHdhaXQgLSBsYXN0KTtcbiAgICAgICAgICAgICAgICAgICAgLy8gb3IgaWYgbm90IHdlIGNhbiBudWxsIG91dCB0aGUgdGltZXIgYW5kIHJ1biB0aGUgbGF0ZXN0XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgdGltZW91dCA9IG51bGw7XG4gICAgICAgICAgICAgICAgICAgIGZ1bmMuYXBwbHkodGhpcywgYXJncyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgLy8gd2Ugb25seSBuZWVkIHRvIHNldCB0aGUgdGltZXIgbm93IGlmIG9uZSBpc24ndCBhbHJlYWR5IHJ1bm5pbmdcbiAgICAgICAgICAgIGlmICghdGltZW91dCkge1xuICAgICAgICAgICAgICAgIHRpbWVvdXQgPSBzZXRUaW1lb3V0KGxhdGVyLCB3YWl0KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICB9XG5cbiAgICBwcml2YXRlIHByb2Nlc3NNYXRjaGVzKCkge1xuICAgICAgICB0aGlzLl9tYXRjaGVzID0gW107XG4gICAgICAgIGlmICh0aGlzLmNkLm1vZGVsLnRvU3RyaW5nKCkubGVuZ3RoID49IHRoaXMuYXV0b2NvbXBsZXRlTWluTGVuZ3RoKSB7XG4gICAgICAgICAgICAvLyBJZiBzaW5nbGVXb3JkcywgYnJlYWsgbW9kZWwgaGVyZSB0byBub3QgYmUgZG9pbmcgZXh0cmEgd29yayBvbiBlYWNoIGl0ZXJhdGlvblxuICAgICAgICAgICAgbGV0IG5vcm1hbGl6ZWRRdWVyeSA9ICh0aGlzLmF1dG9jb21wbGV0ZUxhdGluaXplID8gQXV0b2NvbXBsZXRlVXRpbHMubGF0aW5pemUodGhpcy5jZC5tb2RlbCkgOiB0aGlzLmNkLm1vZGVsKS50b1N0cmluZygpLnRvTG93ZXJDYXNlKCk7XG4gICAgICAgICAgICBub3JtYWxpemVkUXVlcnkgPSB0aGlzLmF1dG9jb21wbGV0ZVNpbmdsZVdvcmRzID8gQXV0b2NvbXBsZXRlVXRpbHMudG9rZW5pemUobm9ybWFsaXplZFF1ZXJ5LCB0aGlzLmF1dG9jb21wbGV0ZVdvcmREZWxpbWl0ZXJzLCB0aGlzLmF1dG9jb21wbGV0ZVBocmFzZURlbGltaXRlcnMpIDogbm9ybWFsaXplZFF1ZXJ5O1xuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0aGlzLmF1dG9jb21wbGV0ZS5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgIGxldCBtYXRjaDpzdHJpbmc7XG5cbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIHRoaXMuYXV0b2NvbXBsZXRlW2ldID09PSAnb2JqZWN0JyAmJlxuICAgICAgICAgICAgICAgICAgICB0aGlzLmF1dG9jb21wbGV0ZVtpXVt0aGlzLmF1dG9jb21wbGV0ZU9wdGlvbkZpZWxkXSkge1xuICAgICAgICAgICAgICAgICAgICBtYXRjaCA9IHRoaXMuYXV0b2NvbXBsZXRlTGF0aW5pemUgPyBBdXRvY29tcGxldGVVdGlscy5sYXRpbml6ZSh0aGlzLmF1dG9jb21wbGV0ZVtpXVt0aGlzLmF1dG9jb21wbGV0ZU9wdGlvbkZpZWxkXS50b1N0cmluZygpKSA6IHRoaXMuYXV0b2NvbXBsZXRlW2ldW3RoaXMuYXV0b2NvbXBsZXRlT3B0aW9uRmllbGRdLnRvU3RyaW5nKCk7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmF1dG9jb21wbGV0ZVtpXSA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgICAgICAgICAgICAgbWF0Y2ggPSB0aGlzLmF1dG9jb21wbGV0ZUxhdGluaXplID8gQXV0b2NvbXBsZXRlVXRpbHMubGF0aW5pemUodGhpcy5hdXRvY29tcGxldGVbaV0udG9TdHJpbmcoKSkgOiB0aGlzLmF1dG9jb21wbGV0ZVtpXS50b1N0cmluZygpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGlmICghbWF0Y2gpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ0ludmFsaWQgbWF0Y2ggdHlwZScsIHR5cGVvZiB0aGlzLmF1dG9jb21wbGV0ZVtpXSwgdGhpcy5hdXRvY29tcGxldGVPcHRpb25GaWVsZCk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGlmICh0aGlzLnRlc3RNYXRjaChtYXRjaC50b0xvd2VyQ2FzZSgpLCBub3JtYWxpemVkUXVlcnkpKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX21hdGNoZXMucHVzaCh0aGlzLmF1dG9jb21wbGV0ZVtpXSk7XG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLl9tYXRjaGVzLmxlbmd0aCA+IHRoaXMuYXV0b2NvbXBsZXRlT3B0aW9uc0xpbWl0IC0gMSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBwcml2YXRlIHRlc3RNYXRjaChtYXRjaDpzdHJpbmcsIHRlc3Q6YW55KSB7XG4gICAgICAgIGxldCBzcGFjZUxlbmd0aDpudW1iZXI7XG5cbiAgICAgICAgaWYgKHR5cGVvZiB0ZXN0ID09PSAnb2JqZWN0Jykge1xuICAgICAgICAgICAgc3BhY2VMZW5ndGggPSB0ZXN0Lmxlbmd0aDtcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgc3BhY2VMZW5ndGg7IGkgKz0gMSkge1xuICAgICAgICAgICAgICAgIGlmICh0ZXN0W2ldLmxlbmd0aCA+IDAgJiYgbWF0Y2guaW5kZXhPZih0ZXN0W2ldKSA8IDApIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcmV0dXJuIG1hdGNoLmluZGV4T2YodGVzdCkgPj0gMDtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHByaXZhdGUgZmluYWxpemVBc3luY0NhbGwoKSB7XG4gICAgICAgIHRoaXMuYXV0b2NvbXBsZXRlTG9hZGluZy5lbWl0KGZhbHNlKTtcbiAgICAgICAgdGhpcy5hdXRvY29tcGxldGVOb1Jlc3VsdHMuZW1pdCh0aGlzLmNkLm1vZGVsLnRvU3RyaW5nKCkubGVuZ3RoID49XG4gICAgICAgICAgICB0aGlzLmF1dG9jb21wbGV0ZU1pbkxlbmd0aCAmJiB0aGlzLm1hdGNoZXMubGVuZ3RoIDw9IDApO1xuXG4gICAgICAgIGlmICh0aGlzLmNkLm1vZGVsLnRvU3RyaW5nKCkubGVuZ3RoIDw9IDAgfHwgdGhpcy5fbWF0Y2hlcy5sZW5ndGggPD0gMCkge1xuICAgICAgICAgICAgdGhpcy5oaWRlKCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBpZiAodGhpcy5jb250YWluZXIgJiYgdGhpcy5fbWF0Y2hlcy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAvLyBUaGlzIGltcHJvdmVzIHRoZSBzcGVlZGFzIGl0IHdvbid0IGhhdmUgdG8gYmUgZG9uZSBmb3IgZWFjaCBsaXN0IGl0ZW1cbiAgICAgICAgICAgIGxldCBub3JtYWxpemVkUXVlcnkgPSAodGhpcy5hdXRvY29tcGxldGVMYXRpbml6ZSA/IEF1dG9jb21wbGV0ZVV0aWxzLmxhdGluaXplKHRoaXMuY2QubW9kZWwpIDogdGhpcy5jZC5tb2RlbCkudG9TdHJpbmcoKS50b0xvd2VyQ2FzZSgpO1xuICAgICAgICAgICAgdGhpcy5jb250YWluZXIucXVlcnkgPSB0aGlzLmF1dG9jb21wbGV0ZVNpbmdsZVdvcmRzID8gQXV0b2NvbXBsZXRlVXRpbHMudG9rZW5pemUobm9ybWFsaXplZFF1ZXJ5LCB0aGlzLmF1dG9jb21wbGV0ZVdvcmREZWxpbWl0ZXJzLCB0aGlzLmF1dG9jb21wbGV0ZVBocmFzZURlbGltaXRlcnMpIDogbm9ybWFsaXplZFF1ZXJ5O1xuICAgICAgICAgICAgdGhpcy5jb250YWluZXIubWF0Y2hlcyA9IHRoaXMuX21hdGNoZXM7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoIXRoaXMuY29udGFpbmVyICYmIHRoaXMuX21hdGNoZXMubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgdGhpcy5zaG93KHRoaXMuX21hdGNoZXMpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgbmdPbkluaXQoKSB7XG4gICAgICAgLy8gdGhpcy5hdXRvY29tcGxldGVNaW5MZW5ndGggPSAzO1xuICAgICAgICB0aGlzLmF1dG9jb21wbGV0ZU9wdGlvbnNMaW1pdCA9IHRoaXMuYXV0b2NvbXBsZXRlT3B0aW9uc0xpbWl0IHx8IDIwO1xuICAgICAgICB0aGlzLmF1dG9jb21wbGV0ZU1pbkxlbmd0aCA9IHRoaXMuYXV0b2NvbXBsZXRlTWluTGVuZ3RoIHx8IDE7XG4gICAgICAgIHRoaXMuYXV0b2NvbXBsZXRlV2FpdE1zID0gdGhpcy5hdXRvY29tcGxldGVXYWl0TXMgfHwgMDtcblxuICAgICAgICAvLyBhc3luYyBzaG91bGQgYmUgZmFsc2UgaW4gY2FzZSBvZiBhcnJheVxuICAgICAgICBpZiAodGhpcy5hdXRvY29tcGxldGVBc3luYyA9PT0gbnVsbCAmJiB0eXBlb2YgdGhpcy5hdXRvY29tcGxldGUgIT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgIHRoaXMuYXV0b2NvbXBsZXRlQXN5bmMgPSBmYWxzZTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIGFzeW5jIHNob3VsZCBiZSB0cnVlIGZvciBhbnkgY2FzZSBvZiBmdW5jdGlvblxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuYXV0b2NvbXBsZXRlID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICB0aGlzLmF1dG9jb21wbGV0ZUFzeW5jID0gdHJ1ZTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICh0aGlzLmF1dG9jb21wbGV0ZUFzeW5jID09PSB0cnVlKSB7XG4gICAgICAgICAgICBkZWJ1Z2dlcjtcbiAgICAgICAgICAgIHRoaXMuZGVib3VuY2VyID0gdGhpcy5kZWJvdW5jZSgoKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmF1dG9jb21wbGV0ZSA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmF1dG9jb21wbGV0ZSgpLnRoZW4oKG1hdGNoZXM6YW55W10pID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX21hdGNoZXMgPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmNkLm1vZGVsLnRvU3RyaW5nKCkubGVuZ3RoID49IHRoaXMuYXV0b2NvbXBsZXRlTWluTGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBtYXRjaGVzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX21hdGNoZXMucHVzaChtYXRjaGVzW2ldKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX21hdGNoZXMubGVuZ3RoID4gdGhpcy5hdXRvY29tcGxldGVPcHRpb25zTGltaXQgLSAxKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5maW5hbGl6ZUFzeW5jQ2FsbCgpO1xuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAvLyBzb3VyY2UgaXMgYXJyYXlcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIHRoaXMuYXV0b2NvbXBsZXRlID09PSAnb2JqZWN0JyAmJiB0aGlzLmF1dG9jb21wbGV0ZS5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5wcm9jZXNzTWF0Y2hlcygpO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmZpbmFsaXplQXN5bmNDYWxsKCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSwgMTAwKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIEBIb3N0TGlzdGVuZXIoJ2tleXVwJywgWyckZXZlbnQnXSlcbiAgICBvbkNoYW5nZShlOktleWJvYXJkRXZlbnQpIHtcbiAgICAgICAgaWYgKHRoaXMuY29udGFpbmVyKSB7XG4gICAgICAgICAgICAvLyBlc2NcbiAgICAgICAgICAgIGlmIChlLmtleUNvZGUgPT09IDI3KSB7XG4gICAgICAgICAgICAgICAgdGhpcy5oaWRlKCk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyB1cFxuICAgICAgICAgICAgaWYgKGUua2V5Q29kZSA9PT0gMzgpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmNvbnRhaW5lci5wcmV2QWN0aXZlTWF0Y2goKTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIGRvd25cbiAgICAgICAgICAgIGlmIChlLmtleUNvZGUgPT09IDQwKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5jb250YWluZXIubmV4dEFjdGl2ZU1hdGNoKCk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyBlbnRlclxuICAgICAgICAgICAgaWYgKGUua2V5Q29kZSA9PT0gMTMpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmNvbnRhaW5lci5zZWxlY3RBY3RpdmVNYXRjaCgpO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIHRoaXMuYXV0b2NvbXBsZXRlTG9hZGluZy5lbWl0KHRydWUpO1xuXG4gICAgICAgIGlmICh0aGlzLmF1dG9jb21wbGV0ZUFzeW5jID09PSB0cnVlKSB7XG4gICAgICAgICAgICB0aGlzLmRlYm91bmNlcigpO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHRoaXMuYXV0b2NvbXBsZXRlQXN5bmMgPT09IGZhbHNlKSB7XG4gICAgICAgICAgICB0aGlzLnByb2Nlc3NNYXRjaGVzKCk7XG4gICAgICAgICAgICB0aGlzLmZpbmFsaXplQXN5bmNDYWxsKCk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBwdWJsaWMgY2hhbmdlTW9kZWwodmFsdWU6YW55KSB7XG4gICAgICAgIGxldCB2YWx1ZVN0cjpzdHJpbmcgPSAoKHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcgJiYgdGhpcy5hdXRvY29tcGxldGVPcHRpb25GaWVsZCkgPyB2YWx1ZVt0aGlzLmF1dG9jb21wbGV0ZU9wdGlvbkZpZWxkXSA6IHZhbHVlKS50b1N0cmluZygpO1xuICAgICAgICB0aGlzLmNkLnZpZXdUb01vZGVsVXBkYXRlKHZhbHVlU3RyKTtcbiAgICAgICAgc2V0UHJvcGVydHkodGhpcy5yZW5kZXJlciwgdGhpcy5lbGVtZW50LCAndmFsdWUnLCB2YWx1ZVN0cik7XG4gICAgICAgIHRoaXMuaGlkZSgpO1xuICAgIH1cblxuICAgIHNob3cobWF0Y2hlczpBcnJheTxhbnk+KSB7XG4gICAgICAgIGxldCBvcHRpb25zID0gbmV3IEF1dG9jb21wbGV0ZU9wdGlvbnMoe1xuICAgICAgICAgICAgcGxhY2VtZW50OiB0aGlzLnBsYWNlbWVudCxcbiAgICAgICAgICAgIGFuaW1hdGlvbjogZmFsc2VcbiAgICAgICAgfSk7XG5cbiAgICAgICAgbGV0IGJpbmRpbmcgPSBJbmplY3Rvci5yZXNvbHZlKFtcbiAgICAgICAgICAgIG5ldyBQcm92aWRlcihBdXRvY29tcGxldGVPcHRpb25zLCB7dXNlVmFsdWU6IG9wdGlvbnN9KVxuICAgICAgICBdKTtcblxuXG4gICAgICAgIHRoaXMucG9wdXAgPSB0aGlzLmxvYWRlclxuICAgICAgICAgICAgLmxvYWROZXh0VG9Mb2NhdGlvbihBdXRvY29tcGxldGVDb250YWluZXIsIHRoaXMuZWxlbWVudCwgYmluZGluZylcbiAgICAgICAgICAgIC50aGVuKChjb21wb25lbnRSZWY6Q29tcG9uZW50UmVmKSA9PiB7XG4gICAgICAgICAgICAgICAgY29tcG9uZW50UmVmLmluc3RhbmNlLnBvc2l0aW9uKHRoaXMuZWxlbWVudCk7XG4gICAgICAgICAgICAgICAgdGhpcy5jb250YWluZXIgPSBjb21wb25lbnRSZWYuaW5zdGFuY2U7XG4gICAgICAgICAgICAgICAgdGhpcy5jb250YWluZXIucGFyZW50ID0gdGhpcztcbiAgICAgICAgICAgICAgICAvLyBUaGlzIGltcHJvdmVzIHRoZSBzcGVlZGFzIGl0IHdvbid0IGhhdmUgdG8gYmUgZG9uZSBmb3IgZWFjaCBsaXN0IGl0ZW1cbiAgICAgICAgICAgICAgICBsZXQgbm9ybWFsaXplZFF1ZXJ5ID0gKHRoaXMuYXV0b2NvbXBsZXRlTGF0aW5pemUgPyBBdXRvY29tcGxldGVVdGlscy5sYXRpbml6ZSh0aGlzLmNkLm1vZGVsKSA6IHRoaXMuY2QubW9kZWwpLnRvU3RyaW5nKCkudG9Mb3dlckNhc2UoKTtcbiAgICAgICAgICAgICAgICB0aGlzLmNvbnRhaW5lci5xdWVyeSA9IHRoaXMuYXV0b2NvbXBsZXRlU2luZ2xlV29yZHMgPyBBdXRvY29tcGxldGVVdGlscy50b2tlbml6ZShub3JtYWxpemVkUXVlcnksIHRoaXMuYXV0b2NvbXBsZXRlV29yZERlbGltaXRlcnMsIHRoaXMuYXV0b2NvbXBsZXRlUGhyYXNlRGVsaW1pdGVycykgOiBub3JtYWxpemVkUXVlcnk7XG4gICAgICAgICAgICAgICAgdGhpcy5jb250YWluZXIubWF0Y2hlcyA9IG1hdGNoZXM7XG4gICAgICAgICAgICAgICAgdGhpcy5jb250YWluZXIuZmllbGQgPSB0aGlzLmF1dG9jb21wbGV0ZU9wdGlvbkZpZWxkO1xuICAgICAgICAgICAgICAgIHRoaXMuZWxlbWVudC5uYXRpdmVFbGVtZW50LmZvY3VzKCk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGNvbXBvbmVudFJlZjtcbiAgICAgICAgICAgIH0pO1xuICAgIH1cblxuICAgIGhpZGUoKSB7XG4gICAgICAgIGlmICh0aGlzLmNvbnRhaW5lcikge1xuICAgICAgICAgICAgdGhpcy5wb3B1cC50aGVuKChjb21wb25lbnRSZWY6Q29tcG9uZW50UmVmKSA9PiB7XG4gICAgICAgICAgICAgICAgY29tcG9uZW50UmVmLmRpc3Bvc2UoKTtcbiAgICAgICAgICAgICAgICB0aGlzLmNvbnRhaW5lciA9IG51bGw7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGNvbXBvbmVudFJlZjtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfVxufVxuXG5cbiJdfQ==
