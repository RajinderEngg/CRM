System.register(["angular2/core", "../comonComponents/basicComponents/select", "../services/AmaxService", "../amaxUtil"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, select_1, AmaxService_1, amaxUtil_1;
    var AmaxSmsComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (select_1_1) {
                select_1 = select_1_1;
            },
            function (AmaxService_1_1) {
                AmaxService_1 = AmaxService_1_1;
            },
            function (amaxUtil_1_1) {
                amaxUtil_1 = amaxUtil_1_1;
            }],
        execute: function() {
            AmaxSmsComponent = (function () {
                function AmaxSmsComponent(_amaxService) {
                    this._amaxService = _amaxService;
                    this.SelectedData = { Name: "", Value: "", Company: "", UserName: "" };
                }
                AmaxSmsComponent.prototype.doNothing = function () { };
                AmaxSmsComponent.prototype.openModel = function () {
                };
                AmaxSmsComponent.prototype.ngOnInit = function () {
                    var _this = this;
                    //debugger;
                    //this.RES = jQuery.parseJSON(localStorage.getItem("langresource"));
                    this._amaxService.GetDataFromServer({
                        SmsCompanyList: {
                            uqery: "\n                        Select\n                            usersms AS UserName,\n                            companysms AS Value\n                        from\n                            ApplicationInfo\n                    ",
                            parameters: {}
                        },
                        PhoneTypeList: {
                            uqery: "SELECT id AS Value, contentHeb+' ('+ contenteng +')' AS Label FROM PhoneTypes",
                            parameters: {}
                        }
                    }).subscribe(function (data) {
                        //debugger;
                        console.log(data);
                        var res = jQuery.parseJSON(data);
                        _this.SmsData = res.Data.data.SmsCompanyList;
                        _this.PhoneTypeListData = res.Data.data.PhoneTypeList;
                    }, function (error) { }, function () { });
                    this._amaxService.GetGeneralGroupTree().subscribe(function (data) {
                        var res = jQuery.parseJSON(data);
                        jQuery("#groupTree").kendoTreeView({
                            checkboxes: {
                                checkChildren: true
                            },
                            //check: this.onGroupSelect,
                            dataSource: res.Data.kendoTree
                        });
                    }, function (err) {
                    }, function () {
                    });
                };
                AmaxSmsComponent.prototype.getSelectedGroups = function () {
                    //debugger;
                    var _CheckedGroups = [];
                    amaxUtil_1.Kendo_utility.checkedNodeIds(jQuery("#groupTree").data("kendoTreeView").dataSource.view(), _CheckedGroups);
                    return _CheckedGroups;
                };
                AmaxSmsComponent.prototype.SendToSelectedGroups = function () {
                    //debugger;
                    //username:string,company:string,message:string,groups:Array<any>,phoneTypeId:number
                    var _selectedGroups = this.getSelectedGroups();
                    var status = "ok";
                    if (_selectedGroups.length == 0)
                        status = "No groups selected";
                    else if (!this.SelectedData.UserName || !this.SelectedData.Value)
                        status = "Please select a provider";
                    else if (!this.SelectedPhoneType.Value)
                        status = "Select Phone type";
                    else if (!this.message)
                        status = "Message can't be empty";
                    if (status != "ok") {
                        alert(status);
                        return;
                    }
                    ;
                    this._amaxService.SendSms(this.SelectedData.UserName, this.SelectedData.Value, this.message, this.getSelectedGroups(), this.SelectedPhoneType.Value).subscribe(function (data) {
                        debugger;
                        console.log(data);
                        var res = jQuery.parseJSON(data);
                        alert(res.Data.err);
                    }, function (err) {
                        console.log(err);
                    }, function () {
                        console.log("Sms send responce compleated!");
                    });
                };
                AmaxSmsComponent = __decorate([
                    core_1.Component({
                        name: 'amax-sms',
                        pipes: [amaxUtil_1.GroupFilterPipe, amaxUtil_1.GroupParenFilterPipe],
                        template: "\n        <div class=\"row\">\n            <div class=\"col-xs-12\">\n\n                <div class=\"row\">\n                    <div class=\"col-xs-12 col-sm-4 col-md-6\">\n                        <label>Select Sms Provider</label>\n                        <mx-select [data]=\"SmsData\" label=\"Value\" (onData)=\"SelectedData = $event\" cssclass=\"form-control\"></mx-select>\n                    </div>\n                    <div class=\"col-xs-12 col-sm-4 col-md-6\">\n                        <label>Select Phone Type</label>\n                        <mx-select [data]=\"PhoneTypeListData\" label=\"Label\" (onData)=\"SelectedPhoneType = $event\" cssclass=\"form-control\"></mx-select>\n                    </div>\n                    <div class=\"col-xs-12 col-sm-4 col-md-3\">\n                        <label>Company</label>\n                        <input class=\"form-control\" type=\"text\" readonly value=\"{{SelectedData.Value}}\"/>\n                    </div>\n                    <div class=\"col-xs-12 col-sm-4 col-md-3\">\n                        <label>Username</label>\n                        <input class=\"form-control\" type=\"text\" readonly value=\"{{SelectedData.UserName}}\"/>\n                    </div>\n                    <div class=\"col-sm-12\">\n                        <label>Select Group</label>\n                        <div class=\"k-content\" style=\"margin: 4px auto;width: 100%; padding: 4px 10px 20px;\">\n                            <div id=\"groupTree\" style=\"overflow: visible;\"> Loading... </div>\n                        </div>\n                    </div>\n                    <div class=\"col-xs-12\">\n                        <label>Message :</label>\n                        <textarea #msg (keyup)=\"message=msg.value\" class=\"form-control\" placeholder=\"Type your messages\"></textarea>\n                        <span>{{msg.value.length||0}} of 120</span>\n                        \n                    </div>\n                </div>\n            </div>\n            <div class=\"col-xs-12\">\n                <button class=\"btn btn-primary\" (click)=\"SendToSelectedGroups()\">Send Message</button>\n            </div>\n        </div>\n    ",
                        directives: [select_1.SelectInputComponent],
                        providers: [AmaxService_1.AmaxService]
                    }), 
                    __metadata('design:paramtypes', [AmaxService_1.AmaxService])
                ], AmaxSmsComponent);
                return AmaxSmsComponent;
            }());
            exports_1("AmaxSmsComponent", AmaxSmsComponent);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldi9hbWF4L3Ntc19PbGQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7WUFxREE7Z0JBbUJJLDBCQUFxQixZQUF3QjtvQkFBeEIsaUJBQVksR0FBWixZQUFZLENBQVk7b0JBQ3pDLElBQUksQ0FBQyxZQUFZLEdBQUcsRUFBQyxJQUFJLEVBQUMsRUFBRSxFQUFFLEtBQUssRUFBQyxFQUFFLEVBQUUsT0FBTyxFQUFDLEVBQUUsRUFBRSxRQUFRLEVBQUMsRUFBRSxFQUFDLENBQUM7Z0JBQ3JFLENBQUM7Z0JBVEQsb0NBQVMsR0FBVCxjQUFZLENBQUM7Z0JBR2Isb0NBQVMsR0FBVDtnQkFFQSxDQUFDO2dCQUtELG1DQUFRLEdBQVI7b0JBQUEsaUJBb0RDO29CQW5ERyxXQUFXO29CQUNYLG9FQUFvRTtvQkFDcEUsSUFBSSxDQUFDLFlBQVksQ0FBQyxpQkFBaUIsQ0FBQzt3QkFDaEMsY0FBYyxFQUFDOzRCQUNYLEtBQUssRUFBQyxzT0FNRDs0QkFDTCxVQUFVLEVBQUMsRUFBRTt5QkFDaEI7d0JBQ0QsYUFBYSxFQUFDOzRCQUNWLEtBQUssRUFBQywrRUFBK0U7NEJBQ3JGLFVBQVUsRUFBQyxFQUFFO3lCQUNoQjtxQkFDSixDQUFDLENBQUMsU0FBUyxDQUNSLFVBQUMsSUFBSTt3QkFDRCxXQUFXO3dCQUNYLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ2xCLElBQUksR0FBRyxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBRWpDLEtBQUksQ0FBQyxPQUFPLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDO3dCQUM1QyxLQUFJLENBQUMsaUJBQWlCLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDO29CQUN6RCxDQUFDLEVBQ0QsVUFBQyxLQUFLLElBQUksQ0FBQyxFQUNYLGNBQUssQ0FBQyxDQUNULENBQUM7b0JBRUYsSUFBSSxDQUFDLFlBQVksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDLFNBQVMsQ0FFN0MsVUFBQyxJQUFJO3dCQUNELElBQUksR0FBRyxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBRWpDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxhQUFhLENBQUM7NEJBQy9CLFVBQVUsRUFBRTtnQ0FDUixhQUFhLEVBQUUsSUFBSTs2QkFDdEI7NEJBQ0QsNEJBQTRCOzRCQUM1QixVQUFVLEVBQUUsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTO3lCQUNqQyxDQUFDLENBQUM7b0JBQ1AsQ0FBQyxFQUNELFVBQUMsR0FBRztvQkFFSixDQUFDLEVBQ0Q7b0JBRUEsQ0FBQyxDQUVKLENBQUM7Z0JBQ04sQ0FBQztnQkFHRCw0Q0FBaUIsR0FBakI7b0JBQ0ksV0FBVztvQkFDWCxJQUFJLGNBQWMsR0FBRyxFQUFFLENBQUM7b0JBQ3hCLHdCQUFhLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxFQUFDLGNBQWMsQ0FBQyxDQUFDO29CQUMxRyxNQUFNLENBQUMsY0FBYyxDQUFDO2dCQUMxQixDQUFDO2dCQUVELCtDQUFvQixHQUFwQjtvQkFDSSxXQUFXO29CQUNYLG9GQUFvRjtvQkFDcEYsSUFBSSxlQUFlLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7b0JBQy9DLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQztvQkFFbEIsRUFBRSxDQUFBLENBQUMsZUFBZSxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUM7d0JBQUMsTUFBTSxHQUFHLG9CQUFvQixDQUFDO29CQUM5RCxJQUFJLENBQUMsRUFBRSxDQUFBLENBQUMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsSUFBRyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDO3dCQUFDLE1BQU0sR0FBQywwQkFBMEIsQ0FBQztvQkFDbEcsSUFBSSxDQUFDLEVBQUUsQ0FBQSxDQUFDLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLEtBQUssQ0FBQzt3QkFBQyxNQUFNLEdBQUMsbUJBQW1CLENBQUM7b0JBQ2xFLElBQUksQ0FBQyxFQUFFLENBQUEsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUM7d0JBQUMsTUFBTSxHQUFHLHdCQUF3QixDQUFDO29CQUV6RCxFQUFFLENBQUEsQ0FBQyxNQUFNLElBQUUsSUFBSSxDQUFDLENBQUEsQ0FBQzt3QkFDYixLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7d0JBQ2QsTUFBTSxDQUFDO29CQUNYLENBQUM7b0JBQUEsQ0FBQztvQkFFRixJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FDckIsSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLEVBQzFCLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxFQUN2QixJQUFJLENBQUMsT0FBTyxFQUNaLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxFQUN4QixJQUFJLENBQUMsaUJBQWlCLENBQUMsS0FBSyxDQUMvQixDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQ1osUUFBUSxDQUFDO3dCQUNMLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUE7d0JBQ3JCLElBQUksR0FBRyxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ2pDLEtBQUssQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUdwQixDQUFDLEVBQ0EsVUFBQSxHQUFHO3dCQUNBLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUE7b0JBQ3BCLENBQUMsRUFBQzt3QkFDRSxPQUFPLENBQUMsR0FBRyxDQUFDLCtCQUErQixDQUFDLENBQUM7b0JBQ2pELENBQUMsQ0FDSixDQUFBO2dCQUNMLENBQUM7Z0JBdEtMO29CQUFDLGdCQUFTLENBQUM7d0JBQ1AsSUFBSSxFQUFDLFVBQVU7d0JBQ2YsS0FBSyxFQUFDLENBQUMsMEJBQWUsRUFBRSwrQkFBb0IsQ0FBQzt3QkFDN0MsUUFBUSxFQUFDLHFwRUF1Q1I7d0JBQ0QsVUFBVSxFQUFDLENBQUMsNkJBQW9CLENBQUM7d0JBQ2pDLFNBQVMsRUFBQyxDQUFDLHlCQUFXLENBQUM7cUJBQzFCLENBQUM7O29DQUFBO2dCQTBIRix1QkFBQztZQUFELENBekhBLEFBeUhDLElBQUE7WUF6SEQsK0NBeUhDLENBQUEiLCJmaWxlIjoiZGV2L2FtYXgvc21zX09sZC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7Q29tcG9uZW50LCBPbkluaXR9IGZyb20gXCJhbmd1bGFyMi9jb3JlXCI7XG5pbXBvcnQgIHtTZWxlY3RJbnB1dENvbXBvbmVudH0gZnJvbSBcIi4uL2NvbW9uQ29tcG9uZW50cy9iYXNpY0NvbXBvbmVudHMvc2VsZWN0XCJcbmltcG9ydCB7QW1heFNlcnZpY2V9IGZyb20gXCIuLi9zZXJ2aWNlcy9BbWF4U2VydmljZVwiO1xuaW1wb3J0IHtHcm91cEZpbHRlclBpcGUsIEdyb3VwUGFyZW5GaWx0ZXJQaXBlLCBLZW5kb191dGlsaXR5fSBmcm9tIFwiLi4vYW1heFV0aWxcIjtcblxuZGVjbGFyZSB2YXIgalF1ZXJ5O1xuXG5AQ29tcG9uZW50KHtcbiAgICBuYW1lOidhbWF4LXNtcycsXG4gICAgcGlwZXM6W0dyb3VwRmlsdGVyUGlwZSwgR3JvdXBQYXJlbkZpbHRlclBpcGVdLFxuICAgIHRlbXBsYXRlOmBcbiAgICAgICAgPGRpdiBjbGFzcz1cInJvd1wiPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbC14cy0xMlwiPlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInJvd1wiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sLXhzLTEyIGNvbC1zbS00IGNvbC1tZC02XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWw+U2VsZWN0IFNtcyBQcm92aWRlcjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bXgtc2VsZWN0IFtkYXRhXT1cIlNtc0RhdGFcIiBsYWJlbD1cIlZhbHVlXCIgKG9uRGF0YSk9XCJTZWxlY3RlZERhdGEgPSAkZXZlbnRcIiBjc3NjbGFzcz1cImZvcm0tY29udHJvbFwiPjwvbXgtc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbC14cy0xMiBjb2wtc20tNCBjb2wtbWQtNlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsPlNlbGVjdCBQaG9uZSBUeXBlPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxteC1zZWxlY3QgW2RhdGFdPVwiUGhvbmVUeXBlTGlzdERhdGFcIiBsYWJlbD1cIkxhYmVsXCIgKG9uRGF0YSk9XCJTZWxlY3RlZFBob25lVHlwZSA9ICRldmVudFwiIGNzc2NsYXNzPVwiZm9ybS1jb250cm9sXCI+PC9teC1zZWxlY3Q+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sLXhzLTEyIGNvbC1zbS00IGNvbC1tZC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWw+Q29tcGFueTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgY2xhc3M9XCJmb3JtLWNvbnRyb2xcIiB0eXBlPVwidGV4dFwiIHJlYWRvbmx5IHZhbHVlPVwie3tTZWxlY3RlZERhdGEuVmFsdWV9fVwiLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wteHMtMTIgY29sLXNtLTQgY29sLW1kLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbD5Vc2VybmFtZTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgY2xhc3M9XCJmb3JtLWNvbnRyb2xcIiB0eXBlPVwidGV4dFwiIHJlYWRvbmx5IHZhbHVlPVwie3tTZWxlY3RlZERhdGEuVXNlck5hbWV9fVwiLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtc20tMTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbD5TZWxlY3QgR3JvdXA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImstY29udGVudFwiIHN0eWxlPVwibWFyZ2luOiA0cHggYXV0bzt3aWR0aDogMTAwJTsgcGFkZGluZzogNHB4IDEwcHggMjBweDtcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGlkPVwiZ3JvdXBUcmVlXCIgc3R5bGU9XCJvdmVyZmxvdzogdmlzaWJsZTtcIj4gTG9hZGluZy4uLiA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbC14cy0xMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsPk1lc3NhZ2UgOjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGV4dGFyZWEgI21zZyAoa2V5dXApPVwibWVzc2FnZT1tc2cudmFsdWVcIiBjbGFzcz1cImZvcm0tY29udHJvbFwiIHBsYWNlaG9sZGVyPVwiVHlwZSB5b3VyIG1lc3NhZ2VzXCI+PC90ZXh0YXJlYT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnt7bXNnLnZhbHVlLmxlbmd0aHx8MH19IG9mIDEyMDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbC14cy0xMlwiPlxuICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3M9XCJidG4gYnRuLXByaW1hcnlcIiAoY2xpY2spPVwiU2VuZFRvU2VsZWN0ZWRHcm91cHMoKVwiPlNlbmQgTWVzc2FnZTwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgIGAsXG4gICAgZGlyZWN0aXZlczpbU2VsZWN0SW5wdXRDb21wb25lbnRdLFxuICAgIHByb3ZpZGVyczpbQW1heFNlcnZpY2VdXG59KVxuZXhwb3J0IGNsYXNzIEFtYXhTbXNDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXR7XG4gICAgLy9SRVM6IE9iamVjdDtcbiAgICBTbXNEYXRhOkFycmF5PGFueT47XG4gICAgU2VsZWN0ZWREYXRhOmFueTtcblxuICAgIFBob25lVHlwZUxpc3REYXRhOkFycmF5PGFueT47XG4gICAgU2VsZWN0ZWRQaG9uZVR5cGU6YW55O1xuICAgIHVzZXJOYW1lOnN0cmluZztcbiAgICBtZXNzYWdlOnN0cmluZztcblxuXG5cbiAgICBkb05vdGhpbmcoKXt9XG5cblxuICAgIG9wZW5Nb2RlbCgpe1xuICAgICAgICBcbiAgICB9XG5cbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlICBfYW1heFNlcnZpY2U6QW1heFNlcnZpY2Upe1xuICAgICAgICB0aGlzLlNlbGVjdGVkRGF0YSA9IHtOYW1lOlwiXCIsIFZhbHVlOlwiXCIsIENvbXBhbnk6XCJcIiwgVXNlck5hbWU6XCJcIn07XG4gICAgfVxuICAgIG5nT25Jbml0KCkge1xuICAgICAgICAvL2RlYnVnZ2VyO1xuICAgICAgICAvL3RoaXMuUkVTID0galF1ZXJ5LnBhcnNlSlNPTihsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImxhbmdyZXNvdXJjZVwiKSk7XG4gICAgICAgIHRoaXMuX2FtYXhTZXJ2aWNlLkdldERhdGFGcm9tU2VydmVyKHtcbiAgICAgICAgICAgIFNtc0NvbXBhbnlMaXN0OntcbiAgICAgICAgICAgICAgICB1cWVyeTpgXG4gICAgICAgICAgICAgICAgICAgICAgICBTZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1c2Vyc21zIEFTIFVzZXJOYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbXBhbnlzbXMgQVMgVmFsdWVcbiAgICAgICAgICAgICAgICAgICAgICAgIGZyb21cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBBcHBsaWNhdGlvbkluZm9cbiAgICAgICAgICAgICAgICAgICAgYCxcbiAgICAgICAgICAgICAgICBwYXJhbWV0ZXJzOnt9XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgUGhvbmVUeXBlTGlzdDp7XG4gICAgICAgICAgICAgICAgdXFlcnk6XCJTRUxFQ1QgaWQgQVMgVmFsdWUsIGNvbnRlbnRIZWIrJyAoJysgY29udGVudGVuZyArJyknIEFTIExhYmVsIEZST00gUGhvbmVUeXBlc1wiLFxuICAgICAgICAgICAgICAgIHBhcmFtZXRlcnM6e31cbiAgICAgICAgICAgIH1cbiAgICAgICAgfSkuc3Vic2NyaWJlKFxuICAgICAgICAgICAgKGRhdGEpID0+IHtcbiAgICAgICAgICAgICAgICAvL2RlYnVnZ2VyO1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGRhdGEpO1xuICAgICAgICAgICAgICAgIHZhciByZXMgPSBqUXVlcnkucGFyc2VKU09OKGRhdGEpO1xuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIHRoaXMuU21zRGF0YSA9IHJlcy5EYXRhLmRhdGEuU21zQ29tcGFueUxpc3Q7XG4gICAgICAgICAgICAgICAgdGhpcy5QaG9uZVR5cGVMaXN0RGF0YSA9IHJlcy5EYXRhLmRhdGEuUGhvbmVUeXBlTGlzdDtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAoZXJyb3IpPT57fSxcbiAgICAgICAgICAgICgpPT57fVxuICAgICAgICApO1xuICAgICAgICBcbiAgICAgICAgdGhpcy5fYW1heFNlcnZpY2UuR2V0R2VuZXJhbEdyb3VwVHJlZSgpLnN1YnNjcmliZShcbiAgICAgICAgXG4gICAgICAgICAgICAoZGF0YSkgPT4ge1xuICAgICAgICAgICAgICAgIHZhciByZXMgPSBqUXVlcnkucGFyc2VKU09OKGRhdGEpO1xuXG4gICAgICAgICAgICAgICAgalF1ZXJ5KFwiI2dyb3VwVHJlZVwiKS5rZW5kb1RyZWVWaWV3KHtcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tib3hlczoge1xuICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tDaGlsZHJlbjogdHJ1ZVxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAvL2NoZWNrOiB0aGlzLm9uR3JvdXBTZWxlY3QsXG4gICAgICAgICAgICAgICAgICAgIGRhdGFTb3VyY2U6IHJlcy5EYXRhLmtlbmRvVHJlZVxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIChlcnIpID0+IHtcblxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICgpID0+IHtcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgXG4gICAgICAgICk7XG4gICAgfVxuXG5cbiAgICBnZXRTZWxlY3RlZEdyb3VwcygpOiBBcnJheTxudW1iZXI+e1xuICAgICAgICAvL2RlYnVnZ2VyO1xuICAgICAgICB2YXIgX0NoZWNrZWRHcm91cHMgPSBbXTtcbiAgICAgICAgS2VuZG9fdXRpbGl0eS5jaGVja2VkTm9kZUlkcyhqUXVlcnkoXCIjZ3JvdXBUcmVlXCIpLmRhdGEoXCJrZW5kb1RyZWVWaWV3XCIpLmRhdGFTb3VyY2UudmlldygpLF9DaGVja2VkR3JvdXBzKTtcbiAgICAgICAgcmV0dXJuIF9DaGVja2VkR3JvdXBzO1xuICAgIH1cblxuICAgIFNlbmRUb1NlbGVjdGVkR3JvdXBzKCkge1xuICAgICAgICAvL2RlYnVnZ2VyO1xuICAgICAgICAvL3VzZXJuYW1lOnN0cmluZyxjb21wYW55OnN0cmluZyxtZXNzYWdlOnN0cmluZyxncm91cHM6QXJyYXk8YW55PixwaG9uZVR5cGVJZDpudW1iZXJcbiAgICAgICAgdmFyIF9zZWxlY3RlZEdyb3VwcyA9IHRoaXMuZ2V0U2VsZWN0ZWRHcm91cHMoKTtcbiAgICAgICAgdmFyIHN0YXR1cyA9IFwib2tcIjtcblxuICAgICAgICBpZihfc2VsZWN0ZWRHcm91cHMubGVuZ3RoID09IDApIHN0YXR1cyA9IFwiTm8gZ3JvdXBzIHNlbGVjdGVkXCI7XG4gICAgICAgIGVsc2UgaWYoIXRoaXMuU2VsZWN0ZWREYXRhLlVzZXJOYW1lIHx8IXRoaXMuU2VsZWN0ZWREYXRhLlZhbHVlKSBzdGF0dXM9XCJQbGVhc2Ugc2VsZWN0IGEgcHJvdmlkZXJcIjtcbiAgICAgICAgZWxzZSBpZighdGhpcy5TZWxlY3RlZFBob25lVHlwZS5WYWx1ZSkgc3RhdHVzPVwiU2VsZWN0IFBob25lIHR5cGVcIjtcbiAgICAgICAgZWxzZSBpZighdGhpcy5tZXNzYWdlKSBzdGF0dXMgPSBcIk1lc3NhZ2UgY2FuJ3QgYmUgZW1wdHlcIjtcblxuICAgICAgICBpZihzdGF0dXMhPVwib2tcIil7XG4gICAgICAgICAgICBhbGVydChzdGF0dXMpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9O1xuXG4gICAgICAgIHRoaXMuX2FtYXhTZXJ2aWNlLlNlbmRTbXMoXG4gICAgICAgICAgICB0aGlzLlNlbGVjdGVkRGF0YS5Vc2VyTmFtZSxcbiAgICAgICAgICAgIHRoaXMuU2VsZWN0ZWREYXRhLlZhbHVlLFxuICAgICAgICAgICAgdGhpcy5tZXNzYWdlLFxuICAgICAgICAgICAgdGhpcy5nZXRTZWxlY3RlZEdyb3VwcygpLFxuICAgICAgICAgICAgdGhpcy5TZWxlY3RlZFBob25lVHlwZS5WYWx1ZVxuICAgICAgICApLnN1YnNjcmliZShkYXRhPT4ge1xuICAgICAgICAgICAgZGVidWdnZXI7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZGF0YSlcbiAgICAgICAgICAgIHZhciByZXMgPSBqUXVlcnkucGFyc2VKU09OKGRhdGEpO1xuICAgICAgICAgICAgYWxlcnQocmVzLkRhdGEuZXJyKTtcblxuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLGVycj0+e1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycilcbiAgICAgICAgICAgIH0sKCk9PntcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIlNtcyBzZW5kIHJlc3BvbmNlIGNvbXBsZWF0ZWQhXCIpO1xuICAgICAgICAgICAgfVxuICAgICAgICApXG4gICAgfVxufSJdfQ==
