System.register(['angular2/common', "../../services/ResourceService", "angular2/router", "angular2/core", "../../services/CustomerService", "../../amaxUtil", '../../autocomplete/autocomplete-container', '../../autocomplete/autocomplete.component', '../../comonComponents/basicComponents'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var common_1, ResourceService_1, router_1, core_1, CustomerService_1, amaxUtil_1, autocomplete_container_1, autocomplete_component_1, basicComponents_1;
    var AUTOCOMPLETE_DIRECTIVES, AmaxCustomers;
    return {
        setters:[
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (ResourceService_1_1) {
                ResourceService_1 = ResourceService_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (CustomerService_1_1) {
                CustomerService_1 = CustomerService_1_1;
            },
            function (amaxUtil_1_1) {
                amaxUtil_1 = amaxUtil_1_1;
            },
            function (autocomplete_container_1_1) {
                autocomplete_container_1 = autocomplete_container_1_1;
            },
            function (autocomplete_component_1_1) {
                autocomplete_component_1 = autocomplete_component_1_1;
            },
            function (basicComponents_1_1) {
                basicComponents_1 = basicComponents_1_1;
            }],
        execute: function() {
            exports_1("AUTOCOMPLETE_DIRECTIVES", AUTOCOMPLETE_DIRECTIVES = [autocomplete_component_1.Autocomplete, autocomplete_container_1.AutocompleteContainer]);
            AmaxCustomers = (function () {
                function AmaxCustomers(_resourceService, _customerService, _routeParams) {
                    this._resourceService = _resourceService;
                    this._customerService = _customerService;
                    this._routeParams = _routeParams;
                    this.modelInput = {};
                    this.TempmodelInput = {};
                    this.custSearchData = [];
                    this.RES = {};
                    this.SelectedPhType = {};
                    this.tempstreetmsg = "";
                    this.Formtype = "CUSTOMER_MASTER";
                    this.Lang = "";
                    //modelInput.lname= "";
                    this.ShowMore = false;
                    this.IsRecordEditMode = false;
                    this.ShowMoreText = "More";
                    this.ShowLoader = false;
                    this.ShowMsg = false;
                    this.ShowGroups = true;
                    this.GroupText = "Show Groups";
                    this.Msg = "";
                    this.MsgClass = "text-primary";
                    this.Isbtndisable = "";
                    this.IsFileAsSaveBtn = "";
                    this.IsFileAsCancelBtn = "";
                    this.languageArray = [];
                    this.Address = {};
                    this.PhoneModel = {};
                    this.EmailModel = {};
                    this.IsShowAll = false;
                    this.CustList = {};
                    this.SAVE_BTN_TEXT = "";
                    this.BTN_PHADD = "";
                    this.EditPhoneData = {};
                    this.EditAddressData = {};
                    this.EditEmailData = {};
                    this.IsFileAstxtShow = false;
                    this.FILEAS_BTN_TEXT = "";
                    this.cssFileAsBtn = "";
                    this.IsCancel = false;
                    this.SearchVal = "";
                    this.EnterCount = 0;
                    this.CustIdText = "";
                    this.BaseAppUrl = "";
                    this.PhIndex = 0;
                    this.KendoRTLCSS = "";
                    this.CHANGEDIR = "";
                    this.ChangeDialog = "";
                    //IsFileAsSave: boolean = false;
                    //Email: string = "";
                    //CustomerEmail: Object = {};
                    //modelInput.CustomerEmails = [];
                    this._CustTypes = [];
                    this._Sources = [];
                    this._Employees = [];
                    this._Suffixes = [];
                    this._PhoneTypes = [];
                    this._AddressTypes = [];
                    this._Groups = [];
                    this._Countries = [];
                    this._States = [];
                    this._Cities = [];
                    this.selectedCar = '';
                    this.asyncSelectedCar = '';
                    this.autocompleteLoading = false;
                    this.autocompleteNoResults = false;
                    this.autocompleteSelect = false;
                    this._previousasyncSelectedCar = '';
                    this.modelInput.BirthDate = "";
                    this.modelInput.CustomerAddresses = [];
                    this.modelInput.CustomerPhones = [];
                    this.modelInput.CustomerEmails = [];
                    this.modelInput.CustomerGroups = [];
                    this.Address.CountryCode = "";
                    this.Address.StateId = "";
                    this.modelInput.employeeid = "";
                    this.modelInput.CustomerType = "";
                    this.modelInput.CameFromCustomer = "";
                    this.modelInput.Safixid = "";
                    this.modelInput.Gender = "0";
                    this.PhoneModel.PhoneTypeId = "";
                    this.RES.CUSTOMER_MASTER = {};
                    this.IsShowAll = false;
                    this.SAVE_BTN_TEXT = this.RES.CUSTOMER_MASTER.APP_BTN_SAVE;
                    this.BTN_PHADD = this.RES.CUSTOMER_MASTER.APP_BTN_PHADD;
                    this.ADD_NEW_CUST_TEXT = this.RES.CUSTOMER_MASTER.APP_LBL_NEW_CUST;
                    this.modelInput.CustomerEmails = [{ Email: "", EmailName: "", Newslettere: true, publish: 1, NewsOrder: "News1", EPublishOrder: "EPub1" }];
                    this.modelInput.CustomerPhones = [{ PhoneTypeId: "", Prefix: "", Area: "", Phone: "", IsSms: 1, Comments: "", IsShowRemarks: false, phpublish: 1, SMSOrder: "SMS1", PublishOrder: "Pub1" }];
                    // debugger;
                    var empid = localStorage.getItem("employeeid");
                    var ccode = this._resourceService.getCookie(empid + "ccode");
                    if (ccode.length > 0)
                        ccode = ccode.substring(1, ccode.length);
                    this.modelInput.CustomerAddresses = [{
                            Street: "", Street2: "", CityName: "", Zip: "", CountryCode: ccode, StateId: "", AddressTypeId: "",
                            ForDelivery: true, MainAddress: true, MainOrder: "MainAddr1", DelvryOrder: "Delvry1"
                        }];
                    var custtype = this._resourceService.getCookie(empid + "cust");
                    if (custtype.length > 0) {
                        custtype = custtype.substring(1, custtype.length);
                    }
                    this.modelInput.CustomerType = custtype;
                    var emp = this._resourceService.getCookie(empid + "emp");
                    if (emp.length > 0)
                        emp = emp.substring(1, emp.length);
                    this.modelInput.employeeid = emp;
                    var source = this._resourceService.getCookie(empid + "src");
                    if (source.length > 0)
                        source = source.substring(1, source.length);
                    else {
                    }
                    this.modelInput.CameFromCustomer = source;
                    this.CSSTEXT = "mdi-content-add";
                    this.cssFileAsBtn = "mdi-content-create";
                    this.IsFileAstxtShow = false;
                    clearTimeout(this.StopTimeOut);
                    this.modelInput.CustomerId = _routeParams.params.Id;
                    this.BaseAppUrl = _resourceService.AppUrl;
                    this.TempmodelInput = this.modelInput;
                    //alert(this._resourceService.getCookie(empid + "cust"));
                    //this.ShowMoreText = "More";
                }
                AmaxCustomers.prototype.getCurrentContext = function () {
                    return this;
                };
                AmaxCustomers.prototype.dateSelectionChange = function (evt) {
                    console.log(evt);
                    this.modelInput.BirthDate = evt;
                    // alert(this.modelInput.BirthDate);
                    //this.validateLogin();
                };
                AmaxCustomers.prototype.getAsyncData = function (context) {
                    var _this = this;
                    var SrchVal = context.asyncSelectedCar;
                    // if (SrchVal != undefined && SrchVal != null && SrchVal != "") {
                    // debugger;
                    if (this._previousasyncSelectedCar == context.asyncSelectedCar) {
                        //clearTimeout(this.StopTimeOut);
                        return this._cachedResult;
                    }
                    else {
                        //alert(this._previousasyncSelectedCar + " | " + context.asyncSelectedCar);
                        if (context.asyncSelectedCar != "") {
                            this._previousasyncSelectedCar = context.asyncSelectedCar;
                            //  this.StopTimeOut = setTimeout(() => {
                            //    alert(SrchVal);
                            this._customerService.GetCompleteSearch(SrchVal).subscribe(function (response) {
                                // debugger;
                                response = jQuery.parseJSON(response);
                                if (response.IsError == true) {
                                    //alert(response.ErrMsg);
                                    bootbox.alert({ message: response.ErrMsg,
                                        className: _this.ChangeDialog,
                                        buttons: {
                                            ok: {
                                                //label: 'Ok',
                                                className: _this.CHANGEDIR
                                            }
                                        }
                                    });
                                }
                                else {
                                    context.carsExample1 = response.Data;
                                }
                            }, function (error) {
                                console.log(error);
                            }, function () {
                                console.log("CallCompleted");
                            });
                            // }, 500);
                            this._cachedResult = context.carsExample1;
                        }
                        else {
                            this._cachedResult = [];
                        }
                        return this._cachedResult;
                    }
                };
                AmaxCustomers.prototype.changeAutocompleteLoading = function (e) {
                    this.autocompleteLoading = e;
                };
                AmaxCustomers.prototype.changeAutocompleteNoResults = function (e) {
                    this.autocompleteSelect = false;
                    this.autocompleteNoResults = e;
                };
                AmaxCustomers.prototype.autocompleteOnSelect = function (e) {
                    var _this = this;
                    this.autocompleteSelect = true;
                    console.log("Selected value: " + e.item);
                    var CompData = e.item.split('|');
                    //debugger;
                    if (e.item != undefined && e.item != "" && e.item != null) {
                        //alert(CompData[0]);
                        this._customerService.GetCompleteCustDet(CompData[0].trim()).subscribe(function (response) {
                            //debugger;
                            response = jQuery.parseJSON(response);
                            if (response.IsError == true) {
                                //alert(response.ErrMsg);
                                bootbox.alert({ message: response.ErrMsg,
                                    className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                            else {
                                _this.modelInput = response.Data;
                                // alert(this.modelInput.BirthDate);
                                _this.SAVE_BTN_TEXT = _this.RES.CUSTOMER_MASTER.APP_BTN_UPDATE;
                                _this.ADD_NEW_CUST_TEXT = _this.RES.CUSTOMER_MASTER.APP_LBL_UPDATE_CUST;
                                _this.CSSTEXT = "mdi-content-create";
                                if (_this.modelInput.CustomerEmails.length == 0) {
                                    _this.modelInput.CustomerEmails = [{ Email: "", EmailName: _this.modelInput.FileAs, Newslettere: false }];
                                }
                                if (_this.modelInput.CustomerPhones.length == 0) {
                                    var phid = "";
                                    jQuery.each(_this._PhoneTypes, function () {
                                        if (this.Text == "CellPhone") {
                                            phid = this.Value;
                                            return false;
                                        }
                                    });
                                    _this.modelInput.CustomerPhones = [{ PhoneTypeId: phid, Prefix: "", Area: "", Phone: "", IsSms: 0, Comments: "", phpublish: 0 }];
                                }
                                if (_this.modelInput.CustomerAddresses.length == 0) {
                                    var empid = localStorage.getItem("employeeid");
                                    var ccode = _this._resourceService.getCookie(empid + "ccode");
                                    if (ccode.length > 0)
                                        ccode = ccode.substring(1, ccode.length);
                                    var adid = "";
                                    var comptext = "Home";
                                    if (_this.modelInput.Company != "" && _this.modelInput.Company != undefined && _this.modelInput.Company != null) {
                                        comptext = "Work";
                                    }
                                    jQuery.each(_this._AddressTypes, function () {
                                        if (this.Text == comptext) {
                                            adid = this.Value;
                                            return false;
                                        }
                                    });
                                    _this.modelInput.CustomerAddresses = [{ Street: "", Street2: "", CityName: "", Zip: "", CountryCode: ccode, StateId: "", AddressTypeId: adid, ForDelivery: false, MainAddress: false }];
                                }
                                _this.CustIdText = "( " + _this.modelInput.CustomerId + " )";
                                _this.IsFileAstxtShow = false;
                                //this.IsCancel = true;
                                //this.HideShowFileAstxt();
                                _this.CancelFileAstxt();
                                _this.IsShowAll = true;
                                //this.bindGroup();
                                //alert(this.RES);
                                _this.bindGroupTree(true);
                            }
                        }, function (error) {
                            console.log(error);
                        }, function () {
                            console.log("CallCompleted");
                        });
                    }
                };
                AmaxCustomers.prototype.OpenNewReceipt = function () {
                    if (this.modelInput != undefined && this.modelInput.CustomerId != undefined && this.modelInput.CustomerId >= 0) {
                        var custId = this.modelInput.CustomerId;
                        if (custId != -1) {
                            var emid = localStorage.getItem("employeeid");
                            document.location = this.BaseAppUrl + "ReceiptSelect/" + emid + "/" + custId;
                        }
                    }
                };
                AmaxCustomers.prototype.OpenChargeCreditPage = function () {
                    var _this = this;
                    this.Isbtndisable = "disabled";
                    this._customerService.CheckIsOpenCharge().subscribe(function (response) {
                        console.log(response);
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    } } });
                        }
                        else {
                            //debugger;
                            if (response.Data != undefined && response.Data != null && response.Data.length == 1) {
                                var custId = -1;
                                if (_this.TempmodelInput != undefined && _this.TempmodelInput.CustomerId != undefined && _this.TempmodelInput.CustomerId >= 0) {
                                    custId = _this.TempmodelInput.CustomerId;
                                }
                                if (_this.modelInput != undefined && _this.modelInput.CustomerId != undefined && _this.modelInput.CustomerId >= 0) {
                                    custId = _this.modelInput.CustomerId;
                                }
                                if (custId != -1) {
                                    document.location = _this.BaseAppUrl + "ChargeCredit/" + custId + "/" + response.Data[0].Value;
                                }
                                else {
                                    bootbox.alert({
                                        message: 'Please save new or load previous customer and then click on charge credit button',
                                        className: _this.ChangeDialog,
                                        buttons: {
                                            ok: {
                                                //label: 'Ok',
                                                className: _this.CHANGEDIR
                                            }
                                        }
                                    });
                                }
                            }
                            else if (response.Data != undefined && response.Data != null && response.Data.length > 1) {
                                //debugger;
                                var custId = -1;
                                if (_this.TempmodelInput != undefined && _this.TempmodelInput.CustomerId != undefined && _this.TempmodelInput.CustomerId >= 0) {
                                    custId = _this.TempmodelInput.CustomerId;
                                }
                                if (_this.modelInput != undefined && _this.modelInput.CustomerId != undefined && _this.modelInput.CustomerId >= 0) {
                                    custId = _this.modelInput.CustomerId;
                                }
                                if (custId != -1) {
                                    document.location = _this.BaseAppUrl + "Terminals/Show/" + custId;
                                }
                                else {
                                    bootbox.alert({
                                        message: 'Please save new or load previous customer and then click on charge credit button',
                                        className: _this.ChangeDialog,
                                        buttons: {
                                            ok: {
                                                //label: 'Ok',
                                                className: _this.CHANGEDIR
                                            }
                                        }
                                    });
                                }
                            }
                            else {
                                bootbox.alert({
                                    message: _this.RES.CUSTOMER_MASTER.APP_MSG_CHARGECREDIT,
                                    className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        } }
                                });
                            }
                        }
                        _this.ShowMsg = true;
                        _this.Msg = response.ErrMsg;
                    }, function (error) { return console.log(error); }, function () { return console.log("Save Call Compleated"); });
                    this.Isbtndisable = "";
                };
                AmaxCustomers.prototype.StopTimer = function () {
                    bootbox.alert({
                        message: 'From Stop Timer' + this.StopTimeOut, className: this.ChangeDialog,
                        buttons: {
                            ok: {
                                //label: 'Ok',
                                className: this.CHANGEDIR
                            }
                        }
                    });
                    clearTimeout(this.StopTimeOut);
                };
                AmaxCustomers.prototype.SetdefaultPage = function () {
                    var _this = this;
                    document.location = this.BaseAppUrl + "Customer/Add/-1";
                    this.IsFileAstxtShow = true;
                    this.IsCancel = true;
                    var empid = localStorage.getItem("employeeid");
                    this.asyncSelectedCar = "";
                    this.modelInput = {};
                    this.modelInput.BirthDate = "";
                    this.modelInput.CustomerId = -1;
                    this.CustIdText = "";
                    this.HideShowFileAstxt();
                    var custtype = this._resourceService.getCookie(empid + "cust");
                    if (custtype.length > 0)
                        custtype = custtype.substring(1, custtype.length);
                    this.modelInput.CustomerType = custtype;
                    var emp = this._resourceService.getCookie(empid + "emp");
                    if (emp.length > 0)
                        emp = emp.substring(1, emp.length);
                    this.modelInput.employeeid = emp;
                    var source = this._resourceService.getCookie(empid + "src");
                    if (source.length > 0)
                        source = source.substring(1, source.length);
                    this.modelInput.CameFromCustomer = source;
                    this.ShowMore = false;
                    //this.ShowMoreText = "More"; 
                    this.ShowMoreText = this.RES.CUSTOMER_MASTER.APP_LNK_LBL_MORE;
                    this.SAVE_BTN_TEXT = this.RES.CUSTOMER_MASTER.APP_BTN_SAVE;
                    this.CSSTEXT = "mdi-content-add";
                    this.ADD_NEW_CUST_TEXT = this.RES.CUSTOMER_MASTER.APP_LBL_NEW_CUST;
                    this.ShowGroups = true;
                    this.showhideGroups();
                    //this.GroupText = this.RES.CUSTOMER_MASTER.APP_LBL_SHOWGROUPS;
                    var phid = "";
                    var SMS = 0;
                    var publish = 0;
                    var epublish = 0;
                    jQuery.each(this._PhoneTypes, function () {
                        if (this.Text == "CellPhone") {
                            phid = this.Value;
                            SMS = 1;
                            publish = 1;
                            epublish = 1;
                            return false;
                        }
                    });
                    this.modelInput.CustomerPhones = [{ PhoneTypeId: phid, Prefix: "", Area: "", Phone: "", IsSms: SMS, Comments: "", phpublish: publish }];
                    //debugger;
                    this.modelInput.CustomerEmails = [{ Email: "", EmailName: "", Newslettere: false, publish: epublish }];
                    var cntrycode = this._resourceService.getCookie(empid + "ccode");
                    if (cntrycode.length > 0)
                        cntrycode = cntrycode.substring(1, cntrycode.length);
                    var adid = "";
                    jQuery.each(this._AddressTypes, function () {
                        if (this.Text == "Home") {
                            adid = this.Value;
                            return false;
                        }
                    });
                    this.modelInput.CustomerAddresses = [{ Street: "", Street2: "", CityName: "", Zip: "", CountryCode: cntrycode, StateId: "", AddressTypeId: adid, ForDelivery: false, MainAddress: false }];
                    this.modelInput.CustomerGroups = [];
                    this.Address.CountryCode = "";
                    this.Address.StateId = "";
                    this.modelInput.Safixid = "";
                    this.modelInput.Gender = "0";
                    this.ShowMsg = false;
                    this.Msg = "";
                    this.IsShowAll = false;
                    this._customerService.GetGeneralGroups(this.IsShowAll).subscribe(function (data) {
                        // debugger;
                        if (_this.IsShowAll == false) {
                            jQuery("#groupTree").html("Loding...");
                            var res = jQuery.parseJSON(data).Data;
                            jQuery("#groupTree").kendoTreeView({
                                loadOnDemand: true,
                                checkboxes: {
                                    checkChildren: true
                                },
                                //check: this.onGroupSelect,
                                dataSource: res
                            });
                        }
                        else {
                            jQuery("#groupTree1").html("Loding...");
                            var res = jQuery.parseJSON(data).Data;
                            jQuery("#groupTree1").kendoTreeView({
                                loadOnDemand: true,
                                checkboxes: {
                                    checkChildren: true
                                },
                                //check: this.onGroupSelect,
                                dataSource: res
                            });
                        }
                    }, function (err) {
                    }, function () {
                    });
                };
                AmaxCustomers.prototype.CancelFileAstxt = function () {
                    this.IsFileAstxtShow = true;
                    this.IsFileAstxtShow = false;
                    this.IsCancel = true;
                    jQuery("#FileAstxt").hide();
                    jQuery("#FileAsSpn").show();
                    this.FILEAS_BTN_TEXT = this.RES.CUSTOMER_MASTER.APP_BTN_FILEAS;
                    if (this.modelInput.CustomerId != undefined && this.modelInput.CustomerId != null && parseInt(this.modelInput.CustomerId) > -1) {
                        jQuery("#FileAsSaveBtn").show();
                        this.cssFileAsBtn = "mdi-content-create";
                        jQuery("#FileAsCancelBtn").hide();
                    }
                    else {
                        jQuery("#FileAsSaveBtn").hide();
                        jQuery("#FileAsCancelBtn").hide();
                    }
                };
                AmaxCustomers.prototype.HideShowFileAstxt = function () {
                    var _this = this;
                    if (this.IsFileAstxtShow == false) {
                        this.IsFileAstxtShow = true;
                        jQuery("#FileAstxt").show();
                        jQuery("#FileAsSpn").hide();
                        this.IsCancel = false;
                        this.FILEAS_BTN_TEXT = this.RES.CUSTOMER_MASTER.APP_BTN_SAVEFILEAS;
                        // alert(this.modelInput.CustomerId);
                        if (this.modelInput.CustomerId != undefined && this.modelInput.CustomerId != null && parseInt(this.modelInput.CustomerId) > -1) {
                            jQuery("#FileAsSaveBtn").show();
                            this.cssFileAsBtn = "mdi-content-save";
                            jQuery("#FileAsCancelBtn").show();
                        }
                        else {
                            jQuery("#FileAsSaveBtn").hide();
                            jQuery("#FileAsCancelBtn").hide();
                        }
                    }
                    else {
                        this.IsFileAstxtShow = false;
                        jQuery("#FileAstxt").hide();
                        jQuery("#FileAsSpn").show();
                        this.FILEAS_BTN_TEXT = this.RES.CUSTOMER_MASTER.APP_BTN_FILEAS;
                        if (this.modelInput.CustomerId != undefined && this.modelInput.CustomerId != null && parseInt(this.modelInput.CustomerId) > -1) {
                            jQuery("#FileAsSaveBtn").show();
                            this.cssFileAsBtn = "mdi-content-create";
                            jQuery("#FileAsCancelBtn").hide();
                            if (this.modelInput.FileAs != "" && this.modelInput.FileAs != undefined && this.modelInput.FileAs != null && this.IsCancel == false) {
                                this._customerService.SaveFileAs(this.modelInput.CustomerId, this.modelInput.FileAs).subscribe(function (response) {
                                    response = jQuery.parseJSON(response);
                                    //alert('hello');
                                    if (response.IsError == true) {
                                        //alert(response.ErrMsg);
                                        bootbox.alert({
                                            message: response.ErrMsg, className: _this.ChangeDialog,
                                            buttons: {
                                                ok: {
                                                    //label: 'Ok',
                                                    className: _this.CHANGEDIR
                                                }
                                            }
                                        });
                                    }
                                    //this.IsFileAsSave = false;
                                    bootbox.alert({
                                        message: response.ErrMsg, className: _this.ChangeDialog,
                                        buttons: {
                                            ok: {
                                                //label: 'Ok',
                                                className: _this.CHANGEDIR
                                            }
                                        }
                                    });
                                    _this.IsCancel = true;
                                    //}
                                    //else {
                                    //}
                                });
                            }
                            else {
                                bootbox.alert({
                                    message: this.RES.CUSTOMER_MASTER.APP_EMPTYFILEAS, className: this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: this.CHANGEDIR
                                        }
                                    }
                                });
                                this.bindFileAs();
                                this.IsFileAstxtShow = false;
                                this.HideShowFileAstxt();
                            }
                        }
                        else {
                            jQuery("#FileAsSaveBtn").hide();
                            jQuery("#FileAsCancelBtn").hide();
                        }
                    }
                };
                AmaxCustomers.prototype.SetEmailName = function () {
                    if (this.modelInput.FileAs != undefined && this.modelInput.FileAs != null) {
                        if (this.modelInput.CustomerEmails.length > 0) {
                            this.modelInput.CustomerEmails[this.modelInput.CustomerEmails.length - 1].EmailName = this.modelInput.FileAs;
                        }
                    }
                };
                AmaxCustomers.prototype.CheckCustWithSameName = function () {
                };
                AmaxCustomers.prototype.SetDefaultCust = function () {
                    //alert();
                    //debugger;
                };
                AmaxCustomers.prototype.setdefaultAddress = function () {
                    this.bindFileAs();
                    this.CheckCustWithfnamelnamecompphsemails();
                    var adid = "";
                    var adtext = "Home";
                    if (this.modelInput.Company != "" && this.modelInput.Company != undefined) {
                        adtext = "Work";
                    }
                    jQuery.each(this._AddressTypes, function () {
                        if (this.Text == adtext) {
                            adid = this.Value;
                            return false;
                        }
                    });
                    this.modelInput.CustomerAddresses[this.modelInput.CustomerAddresses.length - 1].AddressTypeId = adid;
                };
                AmaxCustomers.prototype.bindFileAs = function () {
                    if (this.modelInput.FileAs == "" || this.modelInput.FileAs == undefined) {
                        //debugger;
                        if ((this.modelInput.Company == "" || this.modelInput.Company == undefined)) {
                            var fileastext = "";
                            if (this.modelInput.fname != "" && this.modelInput.fname != undefined && this.modelInput.lname != "" && this.modelInput.lname != undefined) {
                                fileastext = this.modelInput.lname + " " + this.modelInput.fname;
                            }
                            else if (this.modelInput.fname != "" && this.modelInput.fname != undefined && (this.modelInput.lname == "" || this.modelInput.lname == undefined)) {
                                fileastext = " " + this.modelInput.fname;
                            }
                            else if ((this.modelInput.fname == "" || this.modelInput.fname == undefined) && (this.modelInput.lname != "" && this.modelInput.lname != undefined)) {
                                fileastext = this.modelInput.lname + " ";
                            }
                            this.modelInput.FileAs = fileastext;
                        }
                        else if ((this.modelInput.lname == "" || this.modelInput.lname == undefined) && (this.modelInput.fname == "" || this.modelInput.lname == undefined)) {
                            var fileastext = "";
                            if ((this.modelInput.Company != "" && this.modelInput.Company != undefined)) {
                                fileastext = this.modelInput.Company;
                            }
                            this.modelInput.FileAs = fileastext;
                        }
                        else
                            this.modelInput.FileAs = "(" + this.modelInput.Company + ") " + this.modelInput.lname + " " + this.modelInput.fname; //+ " " & m_strSpouse
                        if (this.modelInput.CustomerEmails.length > 0) {
                            this.modelInput.CustomerEmails[this.modelInput.CustomerEmails.length - 1].EmailName = this.modelInput.FileAs;
                        }
                    }
                    this.SetEmailName();
                };
                AmaxCustomers.prototype.bindGroup = function () {
                    //alert(this.IsShowAll); this function is calling on click of checkbox
                    var isshow = false;
                    if (this.IsShowAll == true) {
                        isshow = false;
                        this.IsShowAll = false;
                    }
                    else {
                        this.IsShowAll = true;
                        isshow = true;
                    }
                    this.bindGroupTree(isshow);
                };
                AmaxCustomers.prototype.saveCustomerData = function () {
                    var _this = this;
                    //debugger;
                    this.Isbtndisable = "disabled";
                    this.ShowLoader = true;
                    this.getSelectedGroups();
                    var count = 0;
                    if (this.modelInput.CustomerAddresses != undefined && this.modelInput.CustomerAddresses != null) {
                        jQuery.each(this.modelInput.CustomerAddresses, function () {
                            if (this.MainAddress == true) {
                                count = count + 1;
                            }
                            if (count > 1) {
                                //bootbox.alert("Main Address sholud be only one");
                                this.Isbtndisable = "";
                                this.ShowLoader = false;
                                return false;
                            }
                        });
                    }
                    //alert(this.modelInput.BirthDate);
                    if (this.modelInput.BirthDate != "") {
                        if (moment(this.modelInput.BirthDate, "DD-MM-YYYY", true).isValid() == false) {
                            bootbox.alert({ message: "Birthdate is not valid" });
                            this.Isbtndisable = "";
                            this.ShowLoader = false;
                            return false;
                        }
                    }
                    if (count <= 1 || this.modelInput.CustomerAddresses == undefined || this.modelInput.CustomerAddresses == null) {
                        if (this.modelInput.CustomerPhones != undefined && this.modelInput.CustomerPhones != null) {
                            var phtemp = [];
                            jQuery('input[name^="ph"]').each(function () {
                                phtemp.push(jQuery(this).val());
                            });
                            var artemp = [];
                            jQuery('input[name^="ar"]').each(function () {
                                artemp.push(jQuery(this).val());
                            });
                            var pretemp = [];
                            jQuery('input[name^="pre"]').each(function () {
                                pretemp.push(jQuery(this).val());
                            });
                            var i = 0;
                            jQuery.each(this.modelInput.CustomerPhones, function () {
                                if (this.IsSms == true) {
                                    this.IsSms = "1";
                                }
                                else {
                                    this.IsSms = "0";
                                }
                                if (this.phpublish == true) {
                                    this.phpublish = "1";
                                }
                                else {
                                    this.phpublish = "0";
                                }
                                this.Phone = phtemp[i];
                                this.Area = artemp[i];
                                this.Prefix = pretemp[i];
                                i++;
                                //var temp = this.PhoneTypeId.split(';');
                                //this.PhoneTypeId = parseInt(temp[1]);
                                //this.PhoneType = temp[0];
                            });
                        }
                        if (this.modelInput.CustomerEmails != undefined && this.modelInput.CustomerEmails != null) {
                            jQuery.each(this.modelInput.CustomerEmails, function () {
                                if (this.publish == true) {
                                    this.publish = "1";
                                }
                                else {
                                    this.publish = "0";
                                }
                                i++;
                            });
                        }
                        var jdata = JSON.stringify(this.modelInput);
                        console.log(jdata);
                        this._customerService.AddCustomer(jdata).subscribe(function (response) {
                            console.log(response);
                            response = jQuery.parseJSON(response);
                            _this.Isbtndisable = "";
                            _this.ShowLoader = false;
                            if (response.IsError == true) {
                                //alert(response.ErrMsg);
                                _this.MsgClass = "text-danger";
                            }
                            else {
                                //alert(response.ErrMsg);
                                _this.MsgClass = "text-success";
                                var empid = localStorage.getItem("employeeid");
                                _this._resourceService.setCookie(empid + "cust", _this.modelInput.CustomerType, 10);
                                _this._resourceService.setCookie(empid + "emp", _this.modelInput.employeeid, 10);
                                _this._resourceService.setCookie(empid + "src", _this.modelInput.CameFromCustomer, 10);
                                if (_this.modelInput.CustomerAddresses.length > 0)
                                    _this._resourceService.setCookie(empid + "ccode", _this.modelInput.CustomerAddresses[_this.modelInput.CustomerAddresses.length - 1].CountryCode, 10);
                                // debugger;
                                //document.location = this.BaseAppUrl + "Customer/Add/-1";
                                //debugger;
                                _this.TempmodelInput = response.Data;
                                _this.modelInput = response.Data;
                                _this.editCustDet(_this.modelInput);
                            }
                            _this.ShowMsg = true;
                            _this.Msg = response.ErrMsg;
                        }, function (error) { return console.log(error); }, function () { return console.log("Save Call Compleated"); });
                    }
                    else {
                        bootbox.alert({
                            message: this.RES.CUSTOMER_MASTER.APP_MSG_ISMAINADD, className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                        this.Isbtndisable = "";
                        this.ShowLoader = false;
                    }
                };
                AmaxCustomers.prototype.CheckCustWithfnamelnamecompphsemails = function () {
                    var _this = this;
                    var jdata = JSON.stringify(this.modelInput);
                    //debugger;
                    var fname = "";
                    var lname = "";
                    var company = "";
                    var phones = "";
                    var emails = "";
                    if (this.modelInput.fname == undefined)
                        fname = "";
                    else
                        fname = this.modelInput.fname;
                    if (this.modelInput.lname == undefined)
                        lname = "";
                    else
                        lname = this.modelInput.lname;
                    if (this.modelInput.Company == undefined)
                        company = "";
                    else
                        company = this.modelInput.Company;
                    jQuery('input[name^="ph"]').each(function () {
                        if (jQuery(this).val() != "" && jQuery(this).val() != undefined && jQuery(this).val() != null && jQuery(this).val().length >= 3) {
                            phones += jQuery(this).val() + "','";
                        }
                    });
                    if (phones.length > 0)
                        phones = phones.substring(0, phones.length - 3);
                    jQuery.each(this.modelInput.CustomerEmails, function () {
                        if (this.Email != "" && this.Email != undefined && this.Email != null && this.Email.length >= 3) {
                            emails += this.Email + "','";
                        }
                    });
                    if (emails.length > 0)
                        emails = emails.substring(0, emails.length - 3);
                    if ((fname != "" && fname.length >= 2 && lname != "" && lname.length >= 2)
                        || (company != "" && company.length >= 3)
                        || (phones != "")
                        || (emails != "")) {
                        this._customerService.GetCustomersSearchData(fname, lname, company, phones, emails).subscribe(function (response) {
                            //debugger;
                            response = jQuery.parseJSON(response);
                            if (response.IsError == true) {
                                bootbox.alert({
                                    message: response.ErrMsg, className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                            else {
                                _this.CustList = {};
                                _this.CustList = response.Data;
                                if (response.Data != null && response.Data != undefined) {
                                    _this.custSearchData = response.Data;
                                    jQuery('#CustModal').openModal();
                                }
                            }
                        }, function (error) {
                            console.log(error);
                        }, function () {
                            console.log("CallCompleted");
                        });
                    }
                    //this.bindFileAs();
                };
                AmaxCustomers.prototype.CheckCustWithfnamelname = function (fname, lname, company) {
                    var _this = this;
                    var jdata = JSON.stringify(this.modelInput);
                    //debugger;
                    if (this.modelInput.fname == undefined)
                        fname = "";
                    else
                        fname = this.modelInput.fname;
                    if (this.modelInput.lname == undefined)
                        lname = "";
                    else
                        lname = this.modelInput.lname;
                    if (this.modelInput.Company == undefined)
                        company = "";
                    else
                        company = this.modelInput.Company;
                    this._customerService.CheckCustWithSameName(fname, lname, company).subscribe(function (response) {
                        //debugger;
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.CustList = {};
                            _this.CustList = response.Data;
                            if (response.Data != null && response.Data != undefined) {
                                _this.custSearchData = response.Data;
                                jQuery("#CustModal").openModal();
                            }
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //this.bindFileAs();
                };
                AmaxCustomers.prototype.CheckCustWithEmail = function () {
                    //var Email = "";
                    //if (this.EmailModel.Email != "" && this.EmailModel.Email != undefined)
                    //    Email = this.EmailModel.Email;
                    //this._customerService.CheckCustWithSameEmail(Email).subscribe(response=> {
                    //    //debugger;
                    //    response = jQuery.parseJSON(response);
                    //    if (response.IsError == true) {
                    //        alert(response.ErrMsg);
                    //    }
                    //    else {
                    //        this.CustList = {};
                    //        this.CustList = response.Data;
                    //        if (response.Data != null && response.Data != undefined) {
                    //            this.custSearchData = response.Data;
                    //            jQuery("#CustModal").modal("show");
                    //        }
                    //        //alert(this.RES);
                    //    }
                    //}, error=> {
                    //    console.log(error);
                    //}, () => {
                    //    console.log("CallCompleted")
                    //});
                };
                AmaxCustomers.prototype.CheckCustWithPhone = function () {
                    var _this = this;
                    var Phone = "";
                    if (this.PhoneModel.Phone != "" && this.PhoneModel.Phone != undefined)
                        Phone = this.PhoneModel.Phone;
                    this._customerService.CheckCustWithSamePhone(this.PhoneModel.Phone).subscribe(function (response) {
                        //debugger;
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.CustList = {};
                            _this.CustList = response.Data;
                            if (response.Data != null && response.Data != undefined) {
                                _this.custSearchData = response.Data;
                                jQuery("#CustModal").openModal();
                            }
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxCustomers.prototype.ShowRemarks = function (PhObj) {
                    jQuery.each(this.modelInput.CustomerPhones, function () {
                        if (this == PhObj) {
                            this.IsShowRemarks = true;
                        }
                    });
                };
                AmaxCustomers.prototype.showAddPopup = function () {
                    this.Address = {};
                    this.PhoneModel = {};
                    this.PhoneModel.PhoneTypeId = "";
                    this.Address.CountryCode = "";
                    this.Address.StateId = "";
                    this.Address.CityName = "";
                    this.Address.AddressTypeId = "";
                    this.EmailModel = {};
                    this.BTN_PHADD = this.RES.CUSTOMER_MASTER.APP_BTN_PHADD;
                };
                AmaxCustomers.prototype.showhideGroups = function () {
                    //debugger;
                    if (this.ShowGroups == false) {
                        this.ShowGroups = true;
                        this.GroupText = this.RES.CUSTOMER_MASTER.APP_LBL_HIDEGROUP;
                        jQuery("#GrpDiv").show(1000);
                    }
                    else {
                        this.ShowGroups = false;
                        this.GroupText = this.RES.CUSTOMER_MASTER.APP_LBL_SHOWGROUPS;
                        jQuery("#GrpDiv").hide(1000);
                    }
                };
                AmaxCustomers.prototype.CanaddAddress = function (adobj) {
                    //alert('Hello');
                    return (adobj.Street != undefined && adobj.Street != "")
                        && (adobj.Street2 != undefined && adobj.Street2 != "")
                        && (adobj.Zip != undefined && adobj.Zip != "")
                        && (adobj.CountryCode != undefined && adobj.CountryCode != "")
                        && (adobj.AddressTypeId != undefined && adobj.AddressTypeId != "");
                };
                AmaxCustomers.prototype.AddAddresses = function (adobj) {
                    var IsMainAdd = false;
                    adobj.CityName = jQuery("#City").val();
                    if (this.CanaddAddress(adobj)) {
                        var empid = localStorage.getItem("employeeid");
                        this._resourceService.setCookie(empid + "ccode", adobj.CountryCode, 10);
                        var adid = "";
                        var adtext = "Home";
                        if (this.modelInput.Company != "" && this.modelInput.Company != undefined) {
                            adtext = "Work";
                        }
                        jQuery.each(this._AddressTypes, function () {
                            if (this.Text == adtext) {
                                adid = this.Value;
                                return false;
                            }
                        });
                        var AddresObj = { Street: "", Street2: "", CityName: "", Zip: "", CountryCode: adobj.CountryCode, StateId: "", AddressTypeId: adid, ForDelivery: false, MainAddress: false, MainOrder: "MainAddr" + (this.modelInput.CustomerAddresses.length + 1).toString(), DelvryOrder: "Delvry" + (this.modelInput.CustomerAddresses.length + 1).toString() };
                        //jQuery.each(this.modelInput.CustomerAddresses, function () {
                        //    if (this.MainAddress == true && adobj.MainAddress == true && this != adobj) {
                        //        adobj.MainAddress = false;
                        //        return false;
                        //    }
                        //});
                        if (IsMainAdd == false) {
                            this.modelInput.CustomerAddresses.push(AddresObj);
                        }
                    }
                    else {
                        var msg = '';
                        if (adobj.Street == undefined || adobj.Street == "") {
                            //msg += '\nStreet is not filled'; APP_AL_MSG_STREET
                            msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_MSG_STREET;
                        }
                        if (adobj.Street2 == undefined || adobj.Street2 == "") {
                            //msg += '\nArea is not filled';
                            msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_MSG_AREA;
                        }
                        //if (adobj.CityName == undefined || adobj.CityName == "")
                        //    //msg += '\nCity is not filled'; 
                        //    msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_MSG_CITY;
                        if (adobj.Zip == undefined || adobj.Zip == "") {
                            //msg += '\nZip is not filled'; 
                            msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_MSG_ZIP;
                        }
                        if (adobj.CountryCode == undefined || adobj.CountryCode == "") {
                            //msg += '\nCountry is not selected';
                            msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_MSG_COUNTRY;
                        }
                        //if (this.Address.StateId == undefined || this.Address.StateId == "") {
                        //    msg += '\nState is not selected';
                        //}
                        if (adobj.AddressTypeId == undefined || adobj.AddressTypeId == "") {
                            //msg += '\nAddress type is not selected';
                            msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_MSG_ADTYPE;
                        }
                        bootbox.alert({
                            message: msg, className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                    }
                };
                AmaxCustomers.prototype.CanaddPhone = function (phoneObj) {
                    //debugger;
                    //alert(this.PhoneModel.PhoneTypeId + ' ' + this.PhoneModel.PhoneType + ' ' + this.PhoneModel.Prefix + ' ' + this.PhoneModel.Area + ' ' + this.PhoneModel.Phone);
                    return (phoneObj.PhoneTypeId != undefined && phoneObj.PhoneTypeId != "");
                    // && (this.PhoneModel.PhoneType != undefined&& this.PhoneModel.PhoneType != "" )
                    //&& (this.PhoneModel.Prefix != undefined&& this.PhoneModel.Prefix != ""  )
                    //&& (this.PhoneModel.Area != undefined&&this.PhoneModel.Area != ""  )
                    //&& (phoneObj.Phone != undefined && phoneObj.Phone != "");
                    //&& (this.PhoneModel.Prefix != undefined && this.PhoneModel.Prefix.length != 3);            ;
                };
                AmaxCustomers.prototype.AddPhones = function (phoneObj) {
                    if (this.CanaddPhone(phoneObj)) {
                        debugger;
                        //if (this.IsRecordEditMode == false) {
                        var phid = "";
                        var SMS = 0;
                        var publish = 0;
                        jQuery.each(this._PhoneTypes, function () {
                            if (this.Text == "CellPhone") {
                                phid = this.Value;
                                SMS = 1;
                                publish = 1;
                                return false;
                            }
                        });
                        var PhoneObj = { PhoneTypeId: phid, PhoneType: "", Prefix: "", Area: "", Phone: "", IsSms: SMS, Comments: "", IsShowRemarks: false, phpublish: publish, SMSOrder: "SMS" + (this.modelInput.CustomerPhones.length + 1).toString(), PublishOrder: "Pub" + (this.modelInput.CustomerPhones.length + 1).toString() };
                        this.modelInput.CustomerPhones.push(PhoneObj);
                    }
                    else {
                        var msg = '';
                        if (phoneObj.PhoneTypeId == undefined || phoneObj.PhoneTypeId == "") {
                            //msg += '\nPhone type is not selected';
                            msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_REGMSG_PHTYPE;
                        }
                        //if (phoneObj.Phone == undefined || phoneObj.Phone == "") {
                        //    //msg += '\nPhone number is not filled';
                        //    msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_REGMSG_PHNO;
                        //}
                        //if (this.PhoneModel.Prefix.length!=3) {
                        //    msg += '\nPrefix must of 3 numeric digits';
                        //}
                        bootbox.alert({
                            message: msg, className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                    }
                };
                AmaxCustomers.prototype.CanaddEmail = function (EmailObj) {
                    //debugger;
                    //alert('Hello');
                    return (EmailObj.EmailName != undefined && EmailObj.EmailName != "");
                    //(EmailObj.Email != undefined && EmailObj.Email != "") &&
                };
                AmaxCustomers.prototype.AddEmails = function (EmailObj) {
                    //debugger;
                    if (this.CanaddEmail(EmailObj)) {
                        var epublish = 0;
                        jQuery.each(this._PhoneTypes, function () {
                            if (this.Text == "CellPhone") {
                                epublish = 1;
                                return false;
                            }
                        });
                        //if (this.IsRecordEditMode == false) {
                        var eObj = {};
                        eObj.Email = "";
                        eObj.EmailName = this.modelInput.FileAs;
                        eObj.Newslettere = true;
                        eObj.publish = epublish;
                        eObj.NewsOrder = "News" + (this.modelInput.CustomerEmails.length + 1).toString();
                        eObj.EPublishOrder = "EPub" + (this.modelInput.CustomerEmails.length + 1).toString();
                        this.modelInput.CustomerEmails.push(eObj);
                    }
                    else {
                        var msg = '';
                        //if (EmailObj.Email == undefined || EmailObj.Email == "")
                        //    //msg += '\nEmail is not filled';
                        //    msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_REGMSG_EMAIL;
                        if (EmailObj.EmailName == undefined || EmailObj.EmailName == "") {
                            //msg += '\nName is not filled';
                            msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_REGMSG_ENAME;
                        }
                        bootbox.alert({
                            message: msg, className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                    }
                    // this.modelInput.CustomerAddresses = this.CustomerAddresses;
                };
                AmaxCustomers.prototype.editCustDet = function (Obj) {
                    var _this = this;
                    this._customerService.GetCompleteCustDet(Obj.CustomerId).subscribe(function (response) {
                        // debugger;
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.modelInput = response.Data;
                            _this.SAVE_BTN_TEXT = _this.RES.CUSTOMER_MASTER.APP_BTN_UPDATE;
                            //this.ADD_NEW_CUST_TEXT = this.RES.CUSTOMER_MASTER.APP_LBL_UPDATE_CUST;
                            _this.CSSTEXT = "mdi-content-add";
                            if (_this.modelInput.CustomerEmails.length == 0) {
                                _this.modelInput.CustomerEmails = [{ Email: "", EmailName: _this.modelInput.FileAs, Newslettere: false, publish: 0, NewsOrder: "News1", EPublishOrder: "EPub1" }];
                            }
                            else {
                                var count = 1;
                                jQuery.each(_this.modelInput.CustomerEmails, function () {
                                    this.NewsOrder = "News" + count;
                                    this.EPublishOrder = "EPub" + count++;
                                });
                            }
                            if (_this.modelInput.CustomerPhones.length == 0) {
                                var phid = "";
                                jQuery.each(_this._PhoneTypes, function () {
                                    if (this.Text == "CellPhone") {
                                        phid = this.Value;
                                        return false;
                                    }
                                });
                                _this.modelInput.CustomerPhones = [{ PhoneTypeId: phid, Prefix: "", Area: "", Phone: "", IsSms: 0, Comments: "", phpublish: 0, SMSOrder: "SMS1", PublishOrder: "Pub1" }];
                            }
                            else {
                                var count = 1;
                                jQuery.each(_this.modelInput.CustomerPhones, function () {
                                    this.SMSOrder = "SMS" + count;
                                    this.PublishOrder = "Pub" + count++;
                                });
                            }
                            if (_this.modelInput.CustomerAddresses.length == 0) {
                                var empid = localStorage.getItem("employeeid");
                                var ccode = _this._resourceService.getCookie(empid + "ccode");
                                if (ccode.length > 0)
                                    ccode = ccode.substring(1, ccode.length);
                                var adid = "";
                                var comptext = "Home";
                                if (_this.modelInput.Company != "" && _this.modelInput.Company != undefined && _this.modelInput.Company != null) {
                                    comptext = "Work";
                                }
                                jQuery.each(_this._AddressTypes, function () {
                                    if (this.Text == comptext) {
                                        adid = this.Value;
                                        return false;
                                    }
                                });
                                _this.modelInput.CustomerAddresses = [{ Street: "", Street2: "", CityName: "", Zip: "", CountryCode: ccode, StateId: "", AddressTypeId: adid, ForDelivery: false, MainAddress: false, MainOrder: "MainAddr1", DelvryOrder: "Delvry1" }];
                            }
                            else {
                                var count = 1;
                                jQuery.each(_this.modelInput.CustomerAddresses, function () {
                                    this.MainOrder = "MainAddr" + count;
                                    this.DelvryOrder = "Delvry" + count++;
                                });
                            }
                            //var treeview = jQuery("#groupTree").data("kendoTreeView");
                            //var bar = treeview.findById("Bar");
                            //jQuery.each(this.modelInput.CustomerGroups, function () {
                            //    var data = jQuery("#groupTree").data("kendoTreeView").dataSource.getByUid(this.CustomerGeneralGroupId);
                            //    if (data) {
                            //        data.set("checked", true);
                            //    }
                            //    //var GroupNode = treeview.findById(this.CustomerGeneralGroupId);
                            //    //treeview.dataItem(GroupNode).set("checked", true);
                            //});
                            _this.CustIdText = "( " + _this.modelInput.CustomerId + " )";
                            _this.IsFileAstxtShow = false;
                            _this.HideShowFileAstxt();
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxCustomers.prototype.CheckPhoneType = function (PhoneObj) {
                    var _this = this;
                    //debugger;
                    //alert(PhoneObj.PhoneTypeId + " | " + jQuery("#PhoneType").val());
                    var pretemp = [];
                    jQuery('select[name^="phtype"]').each(function () {
                        pretemp.push(jQuery(this).val());
                    });
                    var index = 0;
                    jQuery.each(this.modelInput.CustomerPhones, function () {
                        if (this == PhoneObj) {
                            return false;
                        }
                        index = index + 1;
                    });
                    if (pretemp[index] != undefined && pretemp[index] != null && pretemp[index] != "") {
                        var PhoneTypeId = pretemp[index];
                        this._customerService.GetPhoneTypeDet(PhoneTypeId).subscribe(function (data) {
                            //debugger;
                            //
                            var response = jQuery.parseJSON(data);
                            if (response.IsError == true) {
                                bootbox.alert({
                                    message: response.ErrMsg, className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                            else {
                                if (response.Data != undefined && response.Data != null && response.Data != "") {
                                    //debugger;
                                    //alert(index + " | " + this.modelInput.CustomerPhones[index].IsSms + " | " + response.Data.Text);
                                    if (response.Data.Text == "1") {
                                        _this.modelInput.CustomerPhones[index].IsSms = 1;
                                        _this.modelInput.CustomerPhones[index].phpublish = 1;
                                        _this.modelInput.CustomerEmails[_this.modelInput.CustomerEmails.length - 1].publish = 1;
                                    }
                                    else {
                                        _this.modelInput.CustomerPhones[index].phpublish = 0;
                                        _this.modelInput.CustomerPhones[index].IsSms = 0;
                                        _this.modelInput.CustomerEmails[_this.modelInput.CustomerEmails.length - 1].publish = 0;
                                    }
                                }
                            }
                            //var treeviewDataSource = jQuery("#groupTree").data("kendoTreeView").dataSource.view();
                        }, function (err) {
                        }, function () {
                        });
                    }
                };
                AmaxCustomers.prototype.editEmailDet = function (EmailObj) {
                    //debugger;
                    var index = 0;
                    this.IsRecordEditMode = true;
                    this.BTN_PHADD = this.RES.CUSTOMER_MASTER.APP_BTN_PHEDIT;
                    this.EmailModel.Email = EmailObj.Email;
                    this.EmailModel.EmailName = EmailObj.EmailName;
                    this.EmailModel.Newslettere = EmailObj.Newslettere;
                    this.EditEmailData = {};
                    this.EditEmailData = EmailObj;
                };
                AmaxCustomers.prototype.delEmailDet = function (EmailObj) {
                    //debugger;
                    var index = 0;
                    jQuery.each(this.modelInput.CustomerEmails, function () {
                        if (this == EmailObj) {
                            return false;
                        }
                        index = index + 1;
                    });
                    this.modelInput.CustomerEmails.splice(index, 1);
                };
                AmaxCustomers.prototype.editAddressDet = function (AddressObj) {
                    //debugger;
                    var index = 0;
                    this.IsRecordEditMode = true;
                    this.BTN_PHADD = this.RES.CUSTOMER_MASTER.APP_BTN_PHEDIT;
                    // AddressObj.CityName = jQuery("#City").val();
                    this.Address.Street = AddressObj.Street;
                    this.Address.Street2 = AddressObj.Street2;
                    this.Address.CityName = AddressObj.CityName;
                    this.Address.Zip = AddressObj.Zip;
                    this.Address.CountryCode = AddressObj.CountryCode;
                    this.Address.StateId = AddressObj.StateId;
                    this.Address.AddressTypeId = AddressObj.AddressTypeId;
                    this.Address.MainAddress = AddressObj.MainAddress;
                    this.Address.ForDelivery = AddressObj.ForDelivery;
                    this.EditAddressData = {};
                    this.EditAddressData = AddressObj;
                };
                AmaxCustomers.prototype.delAddressDet = function (AddressObj) {
                    // debugger; 
                    var index = 0;
                    jQuery.each(this.modelInput.CustomerAddresses, function () {
                        if (this == AddressObj) {
                            return false;
                        }
                        index = index + 1;
                    });
                    this.modelInput.CustomerAddresses.splice(index, 1);
                };
                AmaxCustomers.prototype.editPhoneDet = function (PhoneObj) {
                    var index = 0;
                    this.BTN_PHADD = this.RES.CUSTOMER_MASTER.APP_BTN_PHEDIT;
                    var temp = PhoneObj.PhoneTypeId.split(';');
                    this.PhoneModel.PhoneTypeId = PhoneObj.PhoneType + ";" + PhoneObj.PhoneTypeId;
                    this.PhoneModel.PhoneType = PhoneObj.PhoneType;
                    this.PhoneModel.Prefix = PhoneObj.Prefix;
                    this.PhoneModel.Area = PhoneObj.Area;
                    this.PhoneModel.Phone = PhoneObj.Phone;
                    this.PhoneModel.IsSms = PhoneObj.IsSms;
                    this.PhoneModel.Comments = PhoneObj.Comments;
                    this.EditPhoneData = {};
                    this.EditPhoneData = PhoneObj;
                };
                AmaxCustomers.prototype.delPhoneDet = function (PhoneObj) {
                    var index = 0;
                    jQuery.each(this.modelInput.CustomerPhones, function () {
                        if (this == PhoneObj) {
                            return false;
                        }
                        index = index + 1;
                    });
                    this.modelInput.CustomerPhones.splice(index, 1);
                };
                AmaxCustomers.prototype.getSelectedGroups = function () {
                    this.modelInput.CustomerGroups = [];
                    var _CheckedGroups = [];
                    if (this.IsShowAll == false) {
                        amaxUtil_1.Kendo_utility.checkedNodeIds(jQuery("#groupTree").data("kendoTreeView").dataSource.view(), _CheckedGroups);
                    }
                    else {
                        amaxUtil_1.Kendo_utility.checkedNodeIds(jQuery("#groupTree1").data("kendoTreeView").dataSource.view(), _CheckedGroups);
                    }
                    for (var i = 0; i < _CheckedGroups.length; i++) {
                        var GObj = {};
                        GObj.CustomerGeneralGroupId = _CheckedGroups[i];
                        this.modelInput.CustomerGroups.push(GObj);
                    }
                };
                AmaxCustomers.prototype.More = function () {
                    // alert("call");
                    if (this.ShowMore == true) {
                        this.ShowMore = false;
                        //this.ShowMoreText = "More";
                        this.ShowMoreText = this.RES.CUSTOMER_MASTER.APP_LNK_LBL_MORE;
                    }
                    else {
                        this.ShowMore = true;
                        //this.ShowMoreText = "Less"; 
                        this.ShowMoreText = this.RES.CUSTOMER_MASTER.APP_LNK_LBL_LESS;
                    }
                };
                AmaxCustomers.prototype.bindGroupTree = function (Isshowall) {
                    var _this = this;
                    this._customerService.GetGeneralGroups(Isshowall).subscribe(function (data) {
                        //debugger;
                        //
                        //alert(Isshowall);
                        if (Isshowall == false) {
                            jQuery("#groupTree").html("Loding...");
                            var res = jQuery.parseJSON(data).Data;
                            jQuery("#groupTree").kendoTreeView({
                                loadOnDemand: true,
                                checkboxes: {
                                    checkChildren: true
                                },
                                //check: this.onGroupSelect,
                                dataSource: res
                            });
                            var grpids = "";
                            jQuery.each(_this.modelInput.CustomerGroups, function () {
                                grpids += this.CustomerGeneralGroupId + ";";
                            });
                            if (grpids.length > 0) {
                                amaxUtil_1.Kendo_utility.checkingNodeIds(jQuery("#groupTree").data("kendoTreeView").dataSource.view(), grpids.substring(0, grpids.length - 1));
                            }
                        }
                        else {
                            jQuery("#groupTree1").html("Loding...");
                            var res = jQuery.parseJSON(data).Data;
                            jQuery("#groupTree1").kendoTreeView({
                                loadOnDemand: true,
                                checkboxes: {
                                    checkChildren: true
                                },
                                //check: this.onGroupSelect,
                                dataSource: res
                            });
                            var grpids = "";
                            jQuery.each(_this.modelInput.CustomerGroups, function () {
                                grpids += this.CustomerGeneralGroupId + ";";
                            });
                            if (grpids.length > 0) {
                                amaxUtil_1.Kendo_utility.checkingNodeIds(jQuery("#groupTree1").data("kendoTreeView").dataSource.view(), grpids.substring(0, grpids.length - 1));
                            }
                        }
                        //var treeviewDataSource = jQuery("#groupTree").data("kendoTreeView").dataSource.view();
                    }, function (err) {
                    }, function () {
                    });
                };
                AmaxCustomers.prototype.GetDataForSearch = function (event) {
                    //this.SearchVal = jQuery("#Searchtxt").val();
                    //alert(event.keyCode);
                    //if (this.SearchVal != undefined && this.SearchVal != "" && this.SearchVal != null && event.keyCode == 13) {
                    //alert(this.autocompleteSelect + " " + this.autocompleteNoResults);
                    //    this.EnterCount++;
                    //    if (this.EnterCount >= 2) {
                    //        this._customerService.GetCompleteSearch(this.SearchVal).subscribe(response=> {
                    //            response = jQuery.parseJSON(response);
                    //            if (response.IsError == true) {
                    //                alert(response.ErrMsg);
                    //            }
                    //            else {
                    //                this.CustList = {};
                    //                this.CustList = response.Data;
                    //                if (response.Data != null && response.Data != undefined) {
                    //                    this.custSearchData = response.Data;
                    //                    jQuery("#CustModal").modal("show");
                    //                }
                    //            }
                    //        }, error=> {
                    //            console.log(error);
                    //        }, () => {
                    //            console.log("CallCompleted")
                    //        });
                    //        this.EnterCount = 0;
                    //    }
                    //}
                    //this.SearchVal = "";
                };
                AmaxCustomers.prototype.ngOnInit = function () {
                    var _this = this;
                    // debugger;
                    //bootbox.alert("This is the default alert!");
                    if (localStorage.getItem("lang") == "") {
                        localStorage.setItem("lang", "en");
                    }
                    if (this._resourceService.getCookie("lang") == "") {
                        this._resourceService.setCookie("lang", "en", 10);
                    }
                    this.IsCancel = false;
                    this.showhideGroups();
                    this.IsFileAstxtShow = true;
                    //this.modelInput.CustomerId = -1;
                    if (this.modelInput.CustomerId >= 0) {
                        //this.IsFileAstxtShow = false;
                        this.editCustDet(this.modelInput);
                        this.SAVE_BTN_TEXT = this.RES.CUSTOMER_MASTER.APP_BTN_UPDATE;
                        //this.ADD_NEW_CUST_TEXT = this.RES.CUSTOMER_MASTER.APP_LBL_UPDATE_CUST;
                        //this.CSSTEXT = "mdi-content-add";
                        if (this.modelInput.CustomerAddresses.length == 0) {
                            var empid = localStorage.getItem("employeeid");
                            var ccode = this._resourceService.getCookie(empid + "ccode");
                            if (ccode.length > 0)
                                ccode = ccode.substring(1, ccode.length);
                            var adid = "";
                            var comptext = "Home";
                            if (this.modelInput.Company != "" && this.modelInput.Company != undefined && this.modelInput.Company != null) {
                                comptext = "Work";
                            }
                            jQuery.each(this._AddressTypes, function () {
                                if (this.Text == comptext) {
                                    adid = this.Value;
                                    return false;
                                }
                            });
                            this.modelInput.CustomerAddresses = [{ Street: "", Street2: "", CityName: "", Zip: "", CountryCode: ccode, StateId: "", AddressTypeId: adid, ForDelivery: false, MainAddress: false, MainOrder: "MainAddr1", DelvryOrder: "Delvry1" }];
                        }
                        this.CustIdText = "( " + this.modelInput.CustomerId + " )";
                        this.IsFileAstxtShow = false;
                    }
                    this.Lang = this._resourceService.getCookie("lang");
                    if (this.Lang.length > 0) {
                        this.Lang = this.Lang.substring(1, this.Lang.length);
                    }
                    this.HideShowFileAstxt();
                    //this.RES = jQuery.parseJSON(this._customerService.GetLangRes(this.Formtype, this.Lang)).Data; //jQuery.parseJSON(localStorage.getItem("langresource"));
                    if (this.Lang == "he") {
                        this.KendoRTLCSS = "k-rtl";
                        this.CHANGEDIR = "rtlmodal";
                        this.ChangeDialog = "input_right";
                    }
                    else {
                        this.CHANGEDIR = "ltrmodal";
                        this.ChangeDialog = "input_left";
                    }
                    this._resourceService.GetLangRes(this.Formtype, this.Lang).subscribe(function (response) {
                        //debugger;
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.RES = response.Data;
                            _this.ShowMoreText = _this.RES.CUSTOMER_MASTER.APP_LNK_LBL_MORE;
                            _this.GroupText = _this.RES.CUSTOMER_MASTER.APP_LBL_SHOWGROUPS;
                            _this.SAVE_BTN_TEXT = _this.RES.CUSTOMER_MASTER.APP_BTN_SAVE;
                            _this.ADD_NEW_CUST_TEXT = _this.RES.CUSTOMER_MASTER.APP_LBL_NEW_CUST;
                            _this.FILEAS_BTN_TEXT = _this.RES.CUSTOMER_MASTER.APP_BTN_FILEAS;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //this.ShowMoreText = "More";
                    ////Cities
                    var CountryCode = this.Address.CountryCode;
                    var StateName = this.Address.StateId;
                    this._customerService.GetCities(CountryCode, StateName).subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            var typeaheadSource = [];
                            jQuery.each(response.Data, function () {
                                var newtemp = {};
                                newtemp.id = this.Value;
                                newtemp.name = this.Text;
                                typeaheadSource.push(newtemp);
                            });
                            _this._Cities = response.Data;
                            jQuery('#City').typeahead({
                                //data: this._Cities,
                                source: typeaheadSource,
                                //display: "text",
                                dataType: "JSON",
                            });
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this.languageArray = this._resourceService.GetAvailableLanguages();
                    this._customerService.GetCustomerTypes().subscribe(function (resp) {
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._CustTypes = response.Data;
                            if (_this.modelInput.CustomerType == "" || _this.modelInput.CustomerType == undefined || _this.modelInput.CustomerType == null) {
                                var CusttypeId;
                                jQuery.each(_this._CustTypes, function () {
                                    CusttypeId = this.Value;
                                    return false;
                                });
                                _this.modelInput.CustomerType = CusttypeId;
                            }
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    ////Sources
                    this._customerService.GetSources().subscribe(function (resp) {
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Sources = response.Data;
                            if (_this.modelInput.CameFromCustomer == "" || _this.modelInput.CameFromCustomer == undefined || _this.modelInput.CameFromCustomer == null) {
                                var Source;
                                jQuery.each(_this._Sources, function () {
                                    Source = this.Value;
                                    return false;
                                });
                                _this.modelInput.CameFromCustomer = Source;
                            }
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //GetEmployees
                    this._customerService.GetEmployees().subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Employees = response.Data;
                            if (_this.modelInput.employeeid == "" || _this.modelInput.employeeid == undefined || _this.modelInput.employeeid == null) {
                                var empid;
                                jQuery.each(_this._Employees, function () {
                                    empid = this.Value;
                                    return false;
                                });
                                _this.modelInput.employeeid = empid;
                            }
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //GetSuffixes
                    this._customerService.GetSuffixes().subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Suffixes = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //GetPhoneTypes
                    this._customerService.GetPhoneTypes().subscribe(function (response) {
                        // debugger;
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._PhoneTypes = response.Data;
                            var phid = "";
                            jQuery.each(_this._PhoneTypes, function () {
                                if (this.Text == "CellPhone") {
                                    phid = this.Value;
                                    return false;
                                }
                            });
                            _this.modelInput.CustomerPhones[0].PhoneTypeId = phid;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    var epublish = 0;
                    if (this.modelInput.CustomerPhones.length == 0) {
                        var phid = "";
                        jQuery.each(this._PhoneTypes, function () {
                            if (this.Text == "CellPhone") {
                                phid = this.Value;
                                epublish = 1;
                                return false;
                            }
                        });
                        this.modelInput.CustomerPhones = [{ PhoneTypeId: phid, Prefix: "", Area: "", Phone: "", IsSms: epublish, Comments: "", phpublish: epublish, SMSOrder: "SMS1", PublishOrder: "Pub1" }];
                    }
                    if (this.modelInput.CustomerEmails.length == 0) {
                        this.modelInput.CustomerEmails = [{ Email: "", EmailName: this.modelInput.FileAs, Newslettere: false, publish: epublish, NewsOrder: "News1", EPublishOrder: "EPub1" }];
                    }
                    //GetAddressTypes
                    this._customerService.GetAddressTypes().subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._AddressTypes = response.Data;
                            // debugger;
                            var adid = "";
                            jQuery.each(_this._AddressTypes, function () {
                                if (this.Text == "Home") {
                                    adid = this.Value;
                                    return false;
                                }
                            });
                            _this.modelInput.CustomerAddresses[0].AddressTypeId = adid;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //Groups
                    this._customerService.GetGroups().subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Groups = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    ////Countries
                    this._customerService.GetCountries().subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Countries = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    ////States
                    var CountryCode = this.Address.CountryCode;
                    this._customerService.GetStates(CountryCode).subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._States = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //Tree Group
                    //this.bindGroupTree(this.IsShowAll);
                    this._customerService.GetGeneralGroups(this.IsShowAll).subscribe(function (data) {
                        // debugger;
                        if (_this.IsShowAll == false) {
                            jQuery("#groupTree").html("Loding...");
                            var res = jQuery.parseJSON(data).Data;
                            jQuery("#groupTree").kendoTreeView({
                                loadOnDemand: true,
                                checkboxes: {
                                    checkChildren: true
                                },
                                //check: this.onGroupSelect,
                                dataSource: res
                            });
                            var grpids = "";
                            jQuery.each(_this.modelInput.CustomerGroups, function () {
                                grpids += this.CustomerGeneralGroupId + ";";
                            });
                            if (grpids.length > 0) {
                                amaxUtil_1.Kendo_utility.checkingNodeIds(jQuery("#groupTree").data("kendoTreeView").dataSource.view(), grpids.substring(0, grpids.length - 1));
                            }
                        }
                        else {
                            jQuery("#groupTree1").html("Loding...");
                            var res = jQuery.parseJSON(data).Data;
                            jQuery("#groupTree1").kendoTreeView({
                                loadOnDemand: true,
                                checkboxes: {
                                    checkChildren: true
                                },
                                //check: this.onGroupSelect,
                                dataSource: res
                            });
                            var grpids = "";
                            jQuery.each(_this.modelInput.CustomerGroups, function () {
                                grpids += this.CustomerGeneralGroupId + ";";
                            });
                            if (grpids.length > 0) {
                                amaxUtil_1.Kendo_utility.checkingNodeIds(jQuery("#groupTree1").data("kendoTreeView").dataSource.view(), grpids.substring(0, grpids.length - 1));
                            }
                        }
                    }, function (err) {
                    }, function () {
                    });
                    //alert(moment().format('D MMM YYYY'));       
                    // this.baseUrl + "Dropdown/BindAutoCompleteSrch"
                    var SrchData = null;
                    //alert('Hi');
                    jQuery("#EmailTable tbody tr td a[name=delEbtn]").not(":last").hide();
                    jQuery("#EmailTable tbody tr a[name=addEbtn]").not(":last").show();
                    //$('.modal').modal();
                };
                AmaxCustomers.$inject = ['$scope', '$location', '$anchorScroll'];
                AmaxCustomers = __decorate([
                    core_1.Component({
                        templateUrl: './app/amax/Customer/templates/customer.html',
                        directives: [common_1.NgSwitch, common_1.NgSwitchWhen, common_1.NgSwitchDefault, AUTOCOMPLETE_DIRECTIVES, common_1.CORE_DIRECTIVES, common_1.FORM_DIRECTIVES, basicComponents_1.AmaxDate],
                        providers: [CustomerService_1.CustomerService, ResourceService_1.ResourceService]
                    }), 
                    __metadata('design:paramtypes', [ResourceService_1.ResourceService, CustomerService_1.CustomerService, router_1.RouteParams])
                ], AmaxCustomers);
                return AmaxCustomers;
            }());
            exports_1("AmaxCustomers", AmaxCustomers);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldi9hbWF4L0N1c3RvbWVyL2FkZEN1c3RvbWVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7UUFXYSx1QkFBdUI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7WUFBdkIscUNBQUEsdUJBQXVCLEdBQUcsQ0FBQyxxQ0FBWSxFQUFFLDhDQUFxQixDQUFDLENBQUEsQ0FBQztZQVc3RTtnQkFpRkksdUJBQW9CLGdCQUFpQyxFQUFVLGdCQUFpQyxFQUFVLFlBQXlCO29CQUEvRyxxQkFBZ0IsR0FBaEIsZ0JBQWdCLENBQWlCO29CQUFVLHFCQUFnQixHQUFoQixnQkFBZ0IsQ0FBaUI7b0JBQVUsaUJBQVksR0FBWixZQUFZLENBQWE7b0JBaEZuSSxlQUFVLEdBQUcsRUFBRSxDQUFDO29CQUNoQixtQkFBYyxHQUFHLEVBQUUsQ0FBQztvQkFDcEIsbUJBQWMsR0FBVyxFQUFFLENBQUM7b0JBQzVCLFFBQUcsR0FBVyxFQUFFLENBQUM7b0JBQ2pCLG1CQUFjLEdBQVcsRUFBRSxDQUFDO29CQUM1QixrQkFBYSxHQUFXLEVBQUUsQ0FBQztvQkFDM0IsYUFBUSxHQUFVLGlCQUFpQixDQUFDO29CQUNwQyxTQUFJLEdBQVMsRUFBRSxDQUFDO29CQUNoQix1QkFBdUI7b0JBQ3ZCLGFBQVEsR0FBWSxLQUFLLENBQUM7b0JBQzFCLHFCQUFnQixHQUFZLEtBQUssQ0FBQztvQkFDbEMsaUJBQVksR0FBVyxNQUFNLENBQUM7b0JBRTlCLGVBQVUsR0FBWSxLQUFLLENBQUM7b0JBQzVCLFlBQU8sR0FBWSxLQUFLLENBQUM7b0JBQ3pCLGVBQVUsR0FBWSxJQUFJLENBQUM7b0JBQzNCLGNBQVMsR0FBUyxhQUFhLENBQUM7b0JBQ2hDLFFBQUcsR0FBVyxFQUFFLENBQUM7b0JBQ2pCLGFBQVEsR0FBVyxjQUFjLENBQUM7b0JBQ2xDLGlCQUFZLEdBQVcsRUFBRSxDQUFDO29CQUMxQixvQkFBZSxHQUFXLEVBQUUsQ0FBQztvQkFDN0Isc0JBQWlCLEdBQVcsRUFBRSxDQUFDO29CQUMvQixrQkFBYSxHQUFHLEVBQUUsQ0FBQztvQkFFbkIsWUFBTyxHQUFXLEVBQUUsQ0FBQztvQkFDckIsZUFBVSxHQUFXLEVBQUUsQ0FBQztvQkFDeEIsZUFBVSxHQUFXLEVBQUUsQ0FBQztvQkFDeEIsY0FBUyxHQUFZLEtBQUssQ0FBQztvQkFDM0IsYUFBUSxHQUFXLEVBQUUsQ0FBQztvQkFDdEIsa0JBQWEsR0FBVyxFQUFFLENBQUM7b0JBRTNCLGNBQVMsR0FBVyxFQUFFLENBQUM7b0JBQ3ZCLGtCQUFhLEdBQVcsRUFBRSxDQUFDO29CQUMzQixvQkFBZSxHQUFXLEVBQUUsQ0FBQztvQkFDN0Isa0JBQWEsR0FBVyxFQUFFLENBQUM7b0JBSzNCLG9CQUFlLEdBQVksS0FBSyxDQUFDO29CQUNqQyxvQkFBZSxHQUFXLEVBQUUsQ0FBQztvQkFDN0IsaUJBQVksR0FBVyxFQUFFLENBQUM7b0JBQzFCLGFBQVEsR0FBWSxLQUFLLENBQUM7b0JBQzFCLGNBQVMsR0FBVyxFQUFFLENBQUM7b0JBQ3ZCLGVBQVUsR0FBVyxDQUFDLENBQUM7b0JBRXZCLGVBQVUsR0FBVyxFQUFFLENBQUM7b0JBRXhCLGVBQVUsR0FBVyxFQUFFLENBQUM7b0JBQ3hCLFlBQU8sR0FBVyxDQUFDLENBQUM7b0JBQ3BCLGdCQUFXLEdBQVcsRUFBRSxDQUFDO29CQUN6QixjQUFTLEdBQVcsRUFBRSxDQUFDO29CQUN2QixpQkFBWSxHQUFXLEVBQUUsQ0FBQztvQkFDMUIsZ0NBQWdDO29CQUVoQyxxQkFBcUI7b0JBQ3JCLDZCQUE2QjtvQkFDN0IsaUNBQWlDO29CQUVqQyxlQUFVLEdBQUcsRUFBRSxDQUFDO29CQUNoQixhQUFRLEdBQUcsRUFBRSxDQUFDO29CQUNkLGVBQVUsR0FBRyxFQUFFLENBQUM7b0JBQ2hCLGNBQVMsR0FBRyxFQUFFLENBQUM7b0JBQ2YsZ0JBQVcsR0FBRyxFQUFFLENBQUM7b0JBQ2pCLGtCQUFhLEdBQUcsRUFBRSxDQUFDO29CQUNuQixZQUFPLEdBQUcsRUFBRSxDQUFDO29CQUNiLGVBQVUsR0FBRyxFQUFFLENBQUM7b0JBQ2hCLFlBQU8sR0FBRyxFQUFFLENBQUM7b0JBQ2IsWUFBTyxHQUFHLEVBQUUsQ0FBQztvQkFFTCxnQkFBVyxHQUFXLEVBQUUsQ0FBQztvQkFDekIscUJBQWdCLEdBQVcsRUFBRSxDQUFDO29CQUM5Qix3QkFBbUIsR0FBWSxLQUFLLENBQUM7b0JBQ3JDLDBCQUFxQixHQUFZLEtBQUssQ0FBQztvQkFDdkMsdUJBQWtCLEdBQVksS0FBSyxDQUFDO29CQTRFcEMsOEJBQXlCLEdBQVMsRUFBRSxDQUFDO29CQXBFekMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEdBQUcsRUFBRSxDQUFDO29CQUMvQixJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixHQUFHLEVBQUUsQ0FBQztvQkFDdkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDO29CQUNwQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxFQUFFLENBQUM7b0JBQ3BDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLEVBQUUsQ0FBQztvQkFDcEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEdBQUMsRUFBRSxDQUFDO29CQUM1QixJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7b0JBQzFCLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztvQkFDaEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEdBQUcsRUFBRSxDQUFDO29CQUNsQyxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixHQUFHLEVBQUUsQ0FBQztvQkFDdEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEdBQUcsRUFBRSxDQUFDO29CQUM3QixJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxHQUFHLENBQUM7b0JBQzdCLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxHQUFHLEVBQUUsQ0FBQztvQkFDakMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLEdBQUcsRUFBRSxDQUFDO29CQUM5QixJQUFJLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQztvQkFDdkIsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUM7b0JBQzNELElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsYUFBYSxDQUFDO29CQUN4RCxJQUFJLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsZ0JBQWdCLENBQUM7b0JBQ25FLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLENBQUMsRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFFLFNBQVMsRUFBRSxFQUFFLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFFLFNBQVMsRUFBRSxPQUFPLEVBQUUsYUFBYSxFQUFDLE9BQU8sRUFBRSxDQUFDLENBQUE7b0JBQ3pJLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLENBQUMsRUFBRSxXQUFXLEVBQUUsRUFBRSxFQUFFLE1BQU0sRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUUsUUFBUSxFQUFFLEVBQUUsRUFBRSxhQUFhLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxDQUFDLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBQyxZQUFZLEVBQUUsTUFBTSxFQUFDLENBQUMsQ0FBQTtvQkFDMUwsWUFBWTtvQkFDWCxJQUFJLEtBQUssR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDO29CQUUvQyxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxPQUFPLENBQUMsQ0FBQztvQkFDN0QsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7d0JBQ2pCLEtBQUssR0FBRyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBRTdDLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLEdBQUcsQ0FBQzs0QkFDakMsTUFBTSxFQUFFLEVBQUUsRUFBRSxPQUFPLEVBQUUsRUFBRSxFQUFFLFFBQVEsRUFBRSxFQUFFLEVBQUUsR0FBRyxFQUFFLEVBQUUsRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLE9BQU8sRUFBRSxFQUFFLEVBQUUsYUFBYSxFQUFFLEVBQUU7NEJBQ2xHLFdBQVcsRUFBRSxJQUFJLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUUsV0FBVyxFQUFFLFdBQVcsRUFBRSxTQUFTO3lCQUN2RixDQUFDLENBQUE7b0JBS0YsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsTUFBTSxDQUFDLENBQUM7b0JBQy9ELEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFFdEIsUUFBUSxHQUFHLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDdEQsQ0FBQztvQkFDRCxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksR0FBRyxRQUFRLENBQUM7b0JBR3hDLElBQUksR0FBRyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQyxDQUFDO29CQUN6RCxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQzt3QkFDZixHQUFHLEdBQUcsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUN2QyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBRyxHQUFHLENBQUM7b0JBRWpDLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQyxDQUFDO29CQUM1RCxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQzt3QkFDbEIsTUFBTSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDaEQsSUFBSSxDQUFDLENBQUM7b0JBRU4sQ0FBQztvQkFDRCxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixHQUFHLE1BQU0sQ0FBQztvQkFDMUMsSUFBSSxDQUFDLE9BQU8sR0FBRyxpQkFBaUIsQ0FBQztvQkFDakMsSUFBSSxDQUFDLFlBQVksR0FBRyxvQkFBb0IsQ0FBQztvQkFDekMsSUFBSSxDQUFDLGVBQWUsR0FBRyxLQUFLLENBQUM7b0JBQzdCLFlBQVksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7b0JBQy9CLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLFlBQVksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO29CQUNwRCxJQUFJLENBQUMsVUFBVSxHQUFHLGdCQUFnQixDQUFDLE1BQU0sQ0FBQztvQkFDMUMsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDO29CQUV0Qyx5REFBeUQ7b0JBQ3pELDZCQUE2QjtnQkFFakMsQ0FBQztnQkF4RU8seUNBQWlCLEdBQXpCO29CQUVJLE1BQU0sQ0FBQyxJQUFJLENBQUM7Z0JBQ2hCLENBQUM7Z0JBeUVELDJDQUFtQixHQUFuQixVQUFvQixHQUFHO29CQUNuQixPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUNqQixJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsR0FBRyxHQUFHLENBQUM7b0JBQ2pDLG9DQUFvQztvQkFDbkMsdUJBQXVCO2dCQUMzQixDQUFDO2dCQUVNLG9DQUFZLEdBQXBCLFVBQXFCLE9BQVk7b0JBQWpDLGlCQXNERTtvQkFwREUsSUFBSSxPQUFPLEdBQUcsT0FBTyxDQUFDLGdCQUFnQixDQUFDO29CQUV4QyxrRUFBa0U7b0JBRzlELFlBQVk7b0JBQ2YsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLHlCQUF5QixJQUFJLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUM7d0JBQ3pELGlDQUFpQzt3QkFDakMsTUFBTSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUM7b0JBQzlCLENBQUM7b0JBQ0wsSUFBSSxDQUFDLENBQUM7d0JBQ0YsMkVBQTJFO3dCQUN2RSxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzs0QkFDakMsSUFBSSxDQUFDLHlCQUF5QixHQUFHLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQzs0QkFDNUQseUNBQXlDOzRCQUN2QyxxQkFBcUI7NEJBQ2pCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO2dDQUNoRSxZQUFZO2dDQUNYLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dDQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7b0NBQzNCLHlCQUF5QjtvQ0FDekIsT0FBTyxDQUFDLEtBQUssQ0FBQyxFQUFDLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTt3Q0FDdEMsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO3dDQUN6QixPQUFPLEVBQUU7NENBQ0wsRUFBRSxFQUFFO2dEQUNBLGNBQWM7Z0RBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTOzZDQUM1Qjt5Q0FDSjtxQ0FDSixDQUFDLENBQUM7Z0NBQ1AsQ0FBQztnQ0FDRCxJQUFJLENBQUMsQ0FBQztvQ0FDRixPQUFPLENBQUMsWUFBWSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7Z0NBR3pDLENBQUM7NEJBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSztnQ0FDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDOzRCQUN2QixDQUFDLEVBQUU7Z0NBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTs0QkFDaEMsQ0FBQyxDQUFDLENBQUM7NEJBQ1IsV0FBVzs0QkFFVixJQUFJLENBQUMsYUFBYSxHQUFHLE9BQU8sQ0FBQyxZQUFZLENBQUM7d0JBQzlDLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsSUFBSSxDQUFDLGFBQWEsR0FBRyxFQUFFLENBQUM7d0JBQzVCLENBQUM7d0JBQ0QsTUFBTSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUM7b0JBQzlCLENBQUM7Z0JBR1IsQ0FBQztnQkFFTyxpREFBeUIsR0FBakMsVUFBa0MsQ0FBVTtvQkFDeEMsSUFBSSxDQUFDLG1CQUFtQixHQUFHLENBQUMsQ0FBQztnQkFDakMsQ0FBQztnQkFFTyxtREFBMkIsR0FBbkMsVUFBb0MsQ0FBVTtvQkFDMUMsSUFBSSxDQUFDLGtCQUFrQixHQUFHLEtBQUssQ0FBQztvQkFDaEMsSUFBSSxDQUFDLHFCQUFxQixHQUFHLENBQUMsQ0FBQztnQkFDbkMsQ0FBQztnQkFDTyw0Q0FBb0IsR0FBNUIsVUFBNkIsQ0FBTTtvQkFBbkMsaUJBa0ZDO29CQWpGRyxJQUFJLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDO29CQUMvQixPQUFPLENBQUMsR0FBRyxDQUFDLHFCQUFtQixDQUFDLENBQUMsSUFBTSxDQUFDLENBQUM7b0JBQ3pDLElBQUksUUFBUSxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUNqQyxXQUFXO29CQUNYLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksU0FBUyxJQUFJLENBQUMsQ0FBQyxJQUFJLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzt3QkFDeEQscUJBQXFCO3dCQUNyQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsa0JBQWtCLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTs0QkFDM0UsV0FBVzs0QkFDWCxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzs0QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO2dDQUMzQix5QkFBeUI7Z0NBQ3pCLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBQyxPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07b0NBQ25DLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtvQ0FDNUIsT0FBTyxFQUFFO3dDQUNMLEVBQUUsRUFBRTs0Q0FDQSxjQUFjOzRDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUzt5Q0FDNUI7cUNBQ0o7aUNBQ0osQ0FBQyxDQUFDOzRCQUNQLENBQUM7NEJBQ0QsSUFBSSxDQUFDLENBQUM7Z0NBQ0YsS0FBSSxDQUFDLFVBQVUsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO2dDQUNqQyxvQ0FBb0M7Z0NBQ25DLEtBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsY0FBYyxDQUFDO2dDQUM3RCxLQUFJLENBQUMsaUJBQWlCLEdBQUcsS0FBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsbUJBQW1CLENBQUM7Z0NBQ3RFLEtBQUksQ0FBQyxPQUFPLEdBQUcsb0JBQW9CLENBQUM7Z0NBQ3BDLEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO29DQUM3QyxLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxDQUFDLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsS0FBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUE7Z0NBQzNHLENBQUM7Z0NBQ0QsRUFBRSxDQUFDLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7b0NBQzdDLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQztvQ0FDZCxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUksQ0FBQyxXQUFXLEVBQUU7d0NBQzFCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksV0FBVyxDQUFDLENBQUMsQ0FBQzs0Q0FFM0IsSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7NENBQ2xCLE1BQU0sQ0FBQyxLQUFLLENBQUM7d0NBQ2pCLENBQUM7b0NBQ0wsQ0FBQyxDQUFDLENBQUM7b0NBRUgsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsQ0FBQyxFQUFFLFdBQVcsRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLEVBQUUsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRSxRQUFRLEVBQUUsRUFBRSxFQUFFLFNBQVMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2dDQUdwSSxDQUFDO2dDQUNELEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7b0NBQ2hELElBQUksS0FBSyxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUM7b0NBRS9DLElBQUksS0FBSyxHQUFHLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLE9BQU8sQ0FBQyxDQUFDO29DQUM3RCxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQzt3Q0FDakIsS0FBSyxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQztvQ0FDN0MsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDO29DQUNkLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQztvQ0FDdEIsRUFBRSxDQUFDLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLElBQUksRUFBRSxJQUFJLEtBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxJQUFJLFNBQVMsSUFBSSxLQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO3dDQUMzRyxRQUFRLEdBQUcsTUFBTSxDQUFDO29DQUN0QixDQUFDO29DQUNELE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLGFBQWEsRUFBRTt3Q0FDNUIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxRQUFRLENBQUMsQ0FBQyxDQUFDOzRDQUN4QixJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQzs0Q0FDbEIsTUFBTSxDQUFDLEtBQUssQ0FBQzt3Q0FDakIsQ0FBQztvQ0FDTCxDQUFDLENBQUMsQ0FBQztvQ0FFSCxLQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixHQUFHLENBQUMsRUFBRSxNQUFNLEVBQUUsRUFBRSxFQUFFLE9BQU8sRUFBRSxFQUFFLEVBQUUsUUFBUSxFQUFFLEVBQUUsRUFBRSxHQUFHLEVBQUUsRUFBRSxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsT0FBTyxFQUFFLEVBQUUsRUFBRSxhQUFhLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUM7Z0NBQzNMLENBQUM7Z0NBRUQsS0FBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLEdBQUcsS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO2dDQUMzRCxLQUFJLENBQUMsZUFBZSxHQUFHLEtBQUssQ0FBQztnQ0FDN0IsdUJBQXVCO2dDQUN2QiwyQkFBMkI7Z0NBQzNCLEtBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztnQ0FDdkIsS0FBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7Z0NBQ3RCLG1CQUFtQjtnQ0FDbkIsa0JBQWtCO2dDQUNsQixLQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxDQUFDOzRCQUM3QixDQUFDO3dCQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7NEJBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQzt3QkFDdkIsQ0FBQyxFQUFFOzRCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7d0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUNQLENBQUM7Z0JBQ0wsQ0FBQztnQkFDRCxzQ0FBYyxHQUFkO29CQUNJLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUM3RyxJQUFJLE1BQU0sR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQzt3QkFDeEMsRUFBRSxDQUFDLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs0QkFDZixJQUFJLElBQUksR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDOzRCQUM5QyxRQUFRLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxVQUFVLEdBQUcsZ0JBQWdCLEdBQUcsSUFBSSxHQUFHLEdBQUcsR0FBRyxNQUFNLENBQUM7d0JBQ2pGLENBQUM7b0JBQ0wsQ0FBQztnQkFDTCxDQUFDO2dCQUNELDRDQUFvQixHQUFwQjtvQkFBQSxpQkF5RkM7b0JBeEZHLElBQUksQ0FBQyxZQUFZLEdBQUcsVUFBVSxDQUFDO29CQUMvQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsaUJBQWlCLEVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUN4RCxPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUN0QixRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFHdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDdEQsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUIsRUFBRSxFQUFDLENBQUMsQ0FBQzt3QkFDbEIsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixXQUFXOzRCQUNYLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLElBQUksU0FBUyxJQUFJLFFBQVEsQ0FBQyxJQUFJLElBQUksSUFBSSxJQUFJLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQ25GLElBQUksTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDO2dDQUNoQixFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsY0FBYyxJQUFJLFNBQVMsSUFBSSxLQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsSUFBSSxTQUFTLElBQUksS0FBSSxDQUFDLGNBQWMsQ0FBQyxVQUFVLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztvQ0FDekgsTUFBTSxHQUFHLEtBQUksQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFBO2dDQUMzQyxDQUFDO2dDQUNELEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxVQUFVLElBQUksU0FBUyxJQUFJLEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLFNBQVMsSUFBSSxLQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO29DQUM3RyxNQUFNLEdBQUcsS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUE7Z0NBQ3ZDLENBQUM7Z0NBQ0QsRUFBRSxDQUFDLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQ0FDZixRQUFRLENBQUMsUUFBUSxHQUFHLEtBQUksQ0FBQyxVQUFVLEdBQUcsZUFBZSxHQUFHLE1BQU0sR0FBRyxHQUFHLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7Z0NBQ2xHLENBQUM7Z0NBQ0QsSUFBSSxDQUFDLENBQUM7b0NBRUYsT0FBTyxDQUFDLEtBQUssQ0FBQzt3Q0FDVixPQUFPLEVBQUUsa0ZBQWtGO3dDQUMzRixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7d0NBQzVCLE9BQU8sRUFBRTs0Q0FDTCxFQUFFLEVBQUU7Z0RBQ0EsY0FBYztnREFDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7NkNBQzVCO3lDQUVKO3FDQUNKLENBQUMsQ0FBQztnQ0FDUCxDQUFDOzRCQUNMLENBQUM7NEJBQ0QsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLElBQUksU0FBUyxJQUFJLFFBQVEsQ0FBQyxJQUFJLElBQUksSUFBSSxJQUFJLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQ3ZGLFdBQVc7Z0NBQ1gsSUFBSSxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7Z0NBQ2hCLEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxjQUFjLElBQUksU0FBUyxJQUFJLEtBQUksQ0FBQyxjQUFjLENBQUMsVUFBVSxJQUFJLFNBQVMsSUFBSSxLQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO29DQUN6SCxNQUFNLEdBQUcsS0FBSSxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUE7Z0NBQzNDLENBQUM7Z0NBQ0QsRUFBRSxDQUFDLENBQUMsS0FBSSxDQUFDLFVBQVUsSUFBSSxTQUFTLElBQUksS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksU0FBUyxJQUFJLEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7b0NBQzdHLE1BQU0sR0FBRyxLQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQTtnQ0FDdkMsQ0FBQztnQ0FDRCxFQUFFLENBQUMsQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO29DQUNmLFFBQVEsQ0FBQyxRQUFRLEdBQUcsS0FBSSxDQUFDLFVBQVUsR0FBRyxpQkFBaUIsR0FBRyxNQUFNLENBQUM7Z0NBQ3JFLENBQUM7Z0NBQ0QsSUFBSSxDQUFDLENBQUM7b0NBQ0YsT0FBTyxDQUFDLEtBQUssQ0FBQzt3Q0FDVixPQUFPLEVBQUUsa0ZBQWtGO3dDQUMzRixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7d0NBQzVCLE9BQU8sRUFBRTs0Q0FDTCxFQUFFLEVBQUU7Z0RBQ0EsY0FBYztnREFDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7NkNBQzVCO3lDQUNKO3FDQUNKLENBQUMsQ0FBQztnQ0FDUCxDQUFDOzRCQUVMLENBQUM7NEJBQ0QsSUFBSSxDQUFDLENBQUM7Z0NBQ0YsT0FBTyxDQUFDLEtBQUssQ0FBQztvQ0FDVixPQUFPLEVBQUUsS0FBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsb0JBQW9CO29DQUN0RCxTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7b0NBQzVCLE9BQU8sRUFBRTt3Q0FDTCxFQUFFLEVBQUU7NENBQ0EsY0FBYzs0Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7eUNBQzVCLEVBQUM7aUNBQ1QsQ0FBQyxDQUFDOzRCQUNQLENBQUM7d0JBQ0wsQ0FBQzt3QkFDRCxLQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQzt3QkFDcEIsS0FBSSxDQUFDLEdBQUcsR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDO29CQUMvQixDQUFDLEVBQ0csVUFBQSxLQUFLLElBQUcsT0FBQSxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxFQUFsQixDQUFrQixFQUMxQixjQUFNLE9BQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQkFBc0IsQ0FBQyxFQUFuQyxDQUFtQyxDQUM1QyxDQUFDO29CQUNGLElBQUksQ0FBQyxZQUFZLEdBQUcsRUFBRSxDQUFDO2dCQUMzQixDQUFDO2dCQUNELGlDQUFTLEdBQVQ7b0JBQ0ksT0FBTyxDQUFDLEtBQUssQ0FBQzt3QkFDVixPQUFPLEVBQUUsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLFdBQVcsRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLFlBQVk7d0JBQzNFLE9BQU8sRUFBRTs0QkFDTCxFQUFFLEVBQUU7Z0NBQ0EsY0FBYztnQ0FDZCxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVM7NkJBQzVCO3lCQUNKO3FCQUNKLENBQUMsQ0FBQztvQkFDSCxZQUFZLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO2dCQUNuQyxDQUFDO2dCQUNELHNDQUFjLEdBQWQ7b0JBQUEsaUJBb0hDO29CQW5IRyxRQUFRLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxVQUFVLEdBQUcsaUJBQWlCLENBQUM7b0JBQ3hELElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDO29CQUM1QixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQztvQkFFckIsSUFBSSxLQUFLLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQztvQkFDL0MsSUFBSSxDQUFDLGdCQUFnQixHQUFHLEVBQUUsQ0FBQztvQkFFM0IsSUFBSSxDQUFDLFVBQVUsR0FBRyxFQUFFLENBQUM7b0JBQ3JCLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxHQUFHLEVBQUUsQ0FBQztvQkFDL0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsQ0FBQyxDQUFDLENBQUM7b0JBQ2hDLElBQUksQ0FBQyxVQUFVLEdBQUcsRUFBRSxDQUFDO29CQUNyQixJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztvQkFDekIsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsTUFBTSxDQUFDLENBQUM7b0JBQy9ELEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO3dCQUNwQixRQUFRLEdBQUcsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUN0RCxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksR0FBRyxRQUFRLENBQUM7b0JBQ3hDLElBQUksR0FBRyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQyxDQUFDO29CQUN6RCxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQzt3QkFDZixHQUFHLEdBQUcsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUN2QyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBRyxHQUFHLENBQUM7b0JBQ2pDLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQyxDQUFDO29CQUM1RCxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQzt3QkFDbEIsTUFBTSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDaEQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsR0FBRyxNQUFNLENBQUM7b0JBRTFDLElBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO29CQUN0Qiw4QkFBOEI7b0JBQzlCLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsZ0JBQWdCLENBQUM7b0JBQzlELElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsWUFBWSxDQUFDO29CQUMzRCxJQUFJLENBQUMsT0FBTyxHQUFHLGlCQUFpQixDQUFDO29CQUNqQyxJQUFJLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsZ0JBQWdCLENBQUM7b0JBQ25FLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO29CQUN2QixJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7b0JBQ3RCLCtEQUErRDtvQkFJL0QsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDO29CQUNkLElBQUksR0FBRyxHQUFHLENBQUMsQ0FBQztvQkFDWixJQUFJLE9BQU8sR0FBRyxDQUFDLENBQUM7b0JBQ2hCLElBQUksUUFBUSxHQUFHLENBQUMsQ0FBQztvQkFDakIsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFO3dCQUMxQixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLFdBQVcsQ0FBQyxDQUFDLENBQUM7NEJBRTNCLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDOzRCQUNsQixHQUFHLEdBQUcsQ0FBQyxDQUFDOzRCQUNSLE9BQU8sR0FBRyxDQUFDLENBQUM7NEJBQ1osUUFBUSxHQUFHLENBQUMsQ0FBQzs0QkFDYixNQUFNLENBQUMsS0FBSyxDQUFDO3dCQUNqQixDQUFDO29CQUNMLENBQUMsQ0FBQyxDQUFDO29CQUVILElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLENBQUMsRUFBRSxXQUFXLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFFLEtBQUssRUFBRSxHQUFHLEVBQUUsUUFBUSxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsT0FBTyxFQUFFLENBQUMsQ0FBQTtvQkFDdkksV0FBVztvQkFFWCxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxDQUFDLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxDQUFDLENBQUE7b0JBQ3RHLElBQUksU0FBUyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLE9BQU8sQ0FBQyxDQUFDO29CQUNqRSxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQzt3QkFDckIsU0FBUyxHQUFHLFNBQVMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFFekQsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDO29CQUNkLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRTt3QkFDNUIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxNQUFNLENBQUMsQ0FBQyxDQUFDOzRCQUV0QixJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQzs0QkFDbEIsTUFBTSxDQUFDLEtBQUssQ0FBQzt3QkFDakIsQ0FBQztvQkFFTCxDQUFDLENBQUMsQ0FBQztvQkFHSCxJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixHQUFHLENBQUMsRUFBRSxNQUFNLEVBQUUsRUFBRSxFQUFFLE9BQU8sRUFBRSxFQUFFLEVBQUUsUUFBUSxFQUFFLEVBQUUsRUFBRSxHQUFHLEVBQUUsRUFBRSxFQUFFLFdBQVcsRUFBRSxTQUFTLEVBQUUsT0FBTyxFQUFFLEVBQUUsRUFBRSxhQUFhLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUE7b0JBQzFMLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLEVBQUUsQ0FBQztvQkFDcEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEdBQUcsRUFBRSxDQUFDO29CQUM5QixJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7b0JBQzFCLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztvQkFDN0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsR0FBRyxDQUFDO29CQUM3QixJQUFJLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQztvQkFDckIsSUFBSSxDQUFDLEdBQUcsR0FBRyxFQUFFLENBQUM7b0JBQ2QsSUFBSSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUM7b0JBQ3ZCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsU0FBUyxDQUM1RCxVQUFDLElBQUk7d0JBQ0QsWUFBWTt3QkFDWixFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsU0FBUyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUM7NEJBQzFCLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7NEJBQ3ZDLElBQUksR0FBRyxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFBOzRCQUNyQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsYUFBYSxDQUFDO2dDQUMvQixZQUFZLEVBQUUsSUFBSTtnQ0FDbEIsVUFBVSxFQUFFO29DQUNSLGFBQWEsRUFBRSxJQUFJO2lDQUN0QjtnQ0FDRCw0QkFBNEI7Z0NBQzVCLFVBQVUsRUFBRSxHQUFHOzZCQUNsQixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixNQUFNLENBQUMsYUFBYSxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDOzRCQUN4QyxJQUFJLEdBQUcsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQTs0QkFDckMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDLGFBQWEsQ0FBQztnQ0FDaEMsWUFBWSxFQUFFLElBQUk7Z0NBQ2xCLFVBQVUsRUFBRTtvQ0FDUixhQUFhLEVBQUUsSUFBSTtpQ0FDdEI7Z0NBQ0QsNEJBQTRCO2dDQUM1QixVQUFVLEVBQUUsR0FBRzs2QkFDbEIsQ0FBQyxDQUFDO3dCQUNQLENBQUM7b0JBQ0wsQ0FBQyxFQUNELFVBQUMsR0FBRztvQkFFSixDQUFDLEVBQ0Q7b0JBRUEsQ0FBQyxDQUNKLENBQUM7Z0JBQ04sQ0FBQztnQkFDRCx1Q0FBZSxHQUFmO29CQUNJLElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDO29CQUM1QixJQUFJLENBQUMsZUFBZSxHQUFHLEtBQUssQ0FBQztvQkFDN0IsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7b0JBQ3JCLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztvQkFDNUIsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO29CQUM1QixJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGNBQWMsQ0FBQztvQkFDL0QsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLElBQUksSUFBSSxRQUFRLENBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsR0FBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQzdILE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO3dCQUNoQyxJQUFJLENBQUMsWUFBWSxHQUFHLG9CQUFvQixDQUFDO3dCQUN6QyxNQUFNLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztvQkFDdEMsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixNQUFNLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQzt3QkFDaEMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ3RDLENBQUM7Z0JBQ0wsQ0FBQztnQkFFRCx5Q0FBaUIsR0FBakI7b0JBQUEsaUJBb0ZDO29CQWxGRyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUM7d0JBQ2hDLElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDO3dCQUM1QixNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7d0JBQzVCLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQzt3QkFDNUIsSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7d0JBQ3RCLElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsa0JBQWtCLENBQUM7d0JBQ3BFLHFDQUFxQzt3QkFDcEMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLElBQUksSUFBSSxRQUFRLENBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsR0FBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7NEJBQzdILE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDOzRCQUNoQyxJQUFJLENBQUMsWUFBWSxHQUFHLGtCQUFrQixDQUFDOzRCQUN2QyxNQUFNLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQzt3QkFDdEMsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixNQUFNLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQzs0QkFDaEMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7d0JBQ3RDLENBQUM7b0JBQ0wsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixJQUFJLENBQUMsZUFBZSxHQUFHLEtBQUssQ0FBQzt3QkFDN0IsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO3dCQUM1QixNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7d0JBQzVCLElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsY0FBYyxDQUFDO3dCQUUvRCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksSUFBSSxJQUFJLFFBQVEsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs0QkFDM0gsTUFBTSxDQUFDLGdCQUFnQixDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7NEJBQ2hDLElBQUksQ0FBQyxZQUFZLEdBQUcsb0JBQW9CLENBQUM7NEJBQ3pDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDOzRCQUVsQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsUUFBUSxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUM7Z0NBQ2xJLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO29DQUNuRyxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQztvQ0FDdEMsaUJBQWlCO29DQUNqQixFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7d0NBQzNCLHlCQUF5Qjt3Q0FDekIsT0FBTyxDQUFDLEtBQUssQ0FBQzs0Q0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7NENBQ3RELE9BQU8sRUFBRTtnREFDTCxFQUFFLEVBQUU7b0RBQ0EsY0FBYztvREFDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7aURBQzVCOzZDQUNKO3lDQUNKLENBQUMsQ0FBQztvQ0FDUCxDQUFDO29DQUNELDRCQUE0QjtvQ0FDNUIsT0FBTyxDQUFDLEtBQUssQ0FBQzt3Q0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7d0NBQ3RELE9BQU8sRUFBRTs0Q0FDTCxFQUFFLEVBQUU7Z0RBQ0EsY0FBYztnREFDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7NkNBQzVCO3lDQUNKO3FDQUNKLENBQUMsQ0FBQztvQ0FDSCxLQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQztvQ0FDckIsR0FBRztvQ0FDSCxRQUFRO29DQUVSLEdBQUc7Z0NBQ1AsQ0FBQyxDQUFDLENBQUM7NEJBQ1AsQ0FBQzs0QkFDRCxJQUFJLENBQUMsQ0FBQztnQ0FDRixPQUFPLENBQUMsS0FBSyxDQUFDO29DQUNWLE9BQU8sRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxlQUFlLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxZQUFZO29DQUMvRSxPQUFPLEVBQUU7d0NBQ0wsRUFBRSxFQUFFOzRDQUNBLGNBQWM7NENBQ2QsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO3lDQUM1QjtxQ0FDSjtpQ0FDSixDQUFDLENBQUM7Z0NBQ0gsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO2dDQUNsQixJQUFJLENBQUMsZUFBZSxHQUFHLEtBQUssQ0FBQztnQ0FDN0IsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7NEJBQzdCLENBQUM7d0JBQ0wsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixNQUFNLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQzs0QkFDaEMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7d0JBQ3RDLENBQUM7b0JBQ0wsQ0FBQztnQkFFTCxDQUFDO2dCQUNELG9DQUFZLEdBQVo7b0JBQ0ksRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7d0JBQ3hFLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDOzRCQUM1QyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDO3dCQUNqSCxDQUFDO29CQUNMLENBQUM7Z0JBQ0wsQ0FBQztnQkFDRCw2Q0FBcUIsR0FBckI7Z0JBRUEsQ0FBQztnQkFDRCxzQ0FBYyxHQUFkO29CQUNJLFVBQVU7b0JBQ1YsV0FBVztnQkFFZixDQUFDO2dCQUVELHlDQUFpQixHQUFqQjtvQkFFSSxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7b0JBQ2xCLElBQUksQ0FBQyxvQ0FBb0MsRUFBRSxDQUFDO29CQUM1QyxJQUFJLElBQUksR0FBRyxFQUFFLENBQUM7b0JBQ2QsSUFBSSxNQUFNLEdBQUcsTUFBTSxDQUFDO29CQUVwQixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQzt3QkFDeEUsTUFBTSxHQUFHLE1BQU0sQ0FBQztvQkFFcEIsQ0FBQztvQkFDRCxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUU7d0JBQzVCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksTUFBTSxDQUFDLENBQUMsQ0FBQzs0QkFDdEIsSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7NEJBQ2xCLE1BQU0sQ0FBQyxLQUFLLENBQUM7d0JBQ2pCLENBQUM7b0JBRUwsQ0FBQyxDQUFDLENBQUM7b0JBRUgsSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO2dCQUN6RyxDQUFDO2dCQUNELGtDQUFVLEdBQVY7b0JBRUksRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUM7d0JBQ3RFLFdBQVc7d0JBQ1gsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLElBQUksU0FBUyxDQUFFLENBQUMsQ0FBRCxDQUFDOzRCQUN6RSxJQUFJLFVBQVUsR0FBRyxFQUFFLENBQUM7NEJBQ3BCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUM7Z0NBQ3pJLFVBQVUsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUM7NEJBRXJFLENBQUM7NEJBQ0QsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssSUFBSSxTQUFTLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUNoSixVQUFVLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDOzRCQUM3QyxDQUFDOzRCQUNELElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssSUFBSSxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQ2xKLFVBQVUsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssR0FBRyxHQUFHLENBQUM7NEJBQzdDLENBQUM7NEJBQ0QsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsVUFBVSxDQUFDO3dCQUN4QyxDQUFDO3dCQUNELElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssSUFBSSxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7NEJBQ2xKLElBQUksVUFBVSxHQUFHLEVBQUUsQ0FBQzs0QkFDcEIsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUMxRSxVQUFVLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUM7NEJBQ3pDLENBQUM7NEJBQ0QsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsVUFBVSxDQUFDO3dCQUN4QyxDQUFDO3dCQUNELElBQUk7NEJBQ0EsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxHQUFHLElBQUksR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxxQkFBcUI7d0JBQzlJLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDOzRCQUM1QyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDO3dCQUNqSCxDQUFDO29CQUNMLENBQUM7b0JBQ0QsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO2dCQUN4QixDQUFDO2dCQUNELGlDQUFTLEdBQVQ7b0JBQ0ksc0VBQXNFO29CQUN0RSxJQUFJLE1BQU0sR0FBRyxLQUFLLENBQUM7b0JBQ25CLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzt3QkFDekIsTUFBTSxHQUFHLEtBQUssQ0FBQTt3QkFDZCxJQUFJLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQztvQkFDM0IsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQzt3QkFDdEIsTUFBTSxHQUFHLElBQUksQ0FBQztvQkFDbEIsQ0FBQztvQkFFRCxJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUMvQixDQUFDO2dCQUNELHdDQUFnQixHQUFoQjtvQkFBQSxpQkF1SUM7b0JBdElHLFdBQVc7b0JBQ1gsSUFBSSxDQUFDLFlBQVksR0FBRyxVQUFVLENBQUM7b0JBQy9CLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO29CQUN2QixJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztvQkFFekIsSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO29CQUNkLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzt3QkFDOUYsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixFQUFFOzRCQUMzQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7Z0NBQzNCLEtBQUssR0FBRyxLQUFLLEdBQUcsQ0FBQyxDQUFDOzRCQUN0QixDQUFDOzRCQUNELEVBQUUsQ0FBQyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUNaLG1EQUFtRDtnQ0FFbkQsSUFBSSxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUM7Z0NBQ3ZCLElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO2dDQUN4QixNQUFNLENBQUMsS0FBSyxDQUFDOzRCQUNqQixDQUFDO3dCQUNMLENBQUMsQ0FBQyxDQUFDO29CQUNQLENBQUM7b0JBQ0QsbUNBQW1DO29CQUNuQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO3dCQUNsQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsWUFBWSxFQUFFLElBQUksQ0FBQyxDQUFDLE9BQU8sRUFBRSxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUM7NEJBQzNFLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBRSxPQUFPLEVBQUUsd0JBQXdCLEVBQUUsQ0FBQyxDQUFDOzRCQUVyRCxJQUFJLENBQUMsWUFBWSxHQUFHLEVBQUUsQ0FBQzs0QkFDdkIsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7NEJBQ3hCLE1BQU0sQ0FBQyxLQUFLLENBQUM7d0JBQ2pCLENBQUM7b0JBQ0wsQ0FBQztvQkFDRCxFQUFFLENBQUMsQ0FBQyxLQUFLLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzt3QkFFNUcsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQ3hGLElBQUksTUFBTSxHQUFHLEVBQUUsQ0FBQzs0QkFDaEIsTUFBTSxDQUFDLG1CQUFtQixDQUFDLENBQUMsSUFBSSxDQUFDO2dDQUM3QixNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDOzRCQUNwQyxDQUFDLENBQUMsQ0FBQzs0QkFDSCxJQUFJLE1BQU0sR0FBRyxFQUFFLENBQUM7NEJBQ2hCLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLElBQUksQ0FBQztnQ0FDN0IsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQzs0QkFDcEMsQ0FBQyxDQUFDLENBQUM7NEJBQ0gsSUFBSSxPQUFPLEdBQUcsRUFBRSxDQUFDOzRCQUNqQixNQUFNLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0NBQzlCLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7NEJBQ3JDLENBQUMsQ0FBQyxDQUFDOzRCQUNILElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQzs0QkFDVixNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxFQUFFO2dDQUN4QyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7b0NBQ3JCLElBQUksQ0FBQyxLQUFLLEdBQUcsR0FBRyxDQUFDO2dDQUNyQixDQUFDO2dDQUNELElBQUksQ0FBQyxDQUFDO29DQUNGLElBQUksQ0FBQyxLQUFLLEdBQUcsR0FBRyxDQUFDO2dDQUNyQixDQUFDO2dDQUNELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQztvQ0FDekIsSUFBSSxDQUFDLFNBQVMsR0FBRyxHQUFHLENBQUM7Z0NBQ3pCLENBQUM7Z0NBQ0QsSUFBSSxDQUFDLENBQUM7b0NBQ0YsSUFBSSxDQUFDLFNBQVMsR0FBRyxHQUFHLENBQUM7Z0NBQ3pCLENBQUM7Z0NBQ0QsSUFBSSxDQUFDLEtBQUssR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQ3ZCLElBQUksQ0FBQyxJQUFJLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUN0QixJQUFJLENBQUMsTUFBTSxHQUFHLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDekIsQ0FBQyxFQUFFLENBQUM7Z0NBQ0oseUNBQXlDO2dDQUN6Qyx1Q0FBdUM7Z0NBQ3ZDLDJCQUEyQjs0QkFDL0IsQ0FBQyxDQUFDLENBQUM7d0JBRVAsQ0FBQzt3QkFDRCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDeEYsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRTtnQ0FDeEMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO29DQUN2QixJQUFJLENBQUMsT0FBTyxHQUFHLEdBQUcsQ0FBQztnQ0FDdkIsQ0FBQztnQ0FDRCxJQUFJLENBQUMsQ0FBQztvQ0FDRixJQUFJLENBQUMsT0FBTyxHQUFHLEdBQUcsQ0FBQztnQ0FDdkIsQ0FBQztnQ0FDRCxDQUFDLEVBQUUsQ0FBQzs0QkFDUixDQUFDLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO3dCQUM1QyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFBO3dCQUNsQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7NEJBQ3ZELE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUM7NEJBQ3RCLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDOzRCQUN0QyxLQUFJLENBQUMsWUFBWSxHQUFHLEVBQUUsQ0FBQzs0QkFDdkIsS0FBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7NEJBRXhCLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQztnQ0FDM0IseUJBQXlCO2dDQUN6QixLQUFJLENBQUMsUUFBUSxHQUFHLGFBQWEsQ0FBQzs0QkFDbEMsQ0FBQzs0QkFDRCxJQUFJLENBQUMsQ0FBQztnQ0FDRix5QkFBeUI7Z0NBRXpCLEtBQUksQ0FBQyxRQUFRLEdBQUcsY0FBYyxDQUFDO2dDQUMvQixJQUFJLEtBQUssR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDO2dDQUMvQyxLQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxNQUFNLEVBQUUsS0FBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEVBQUUsRUFBRSxDQUFDLENBQUM7Z0NBQ2xGLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLEtBQUssRUFBRSxLQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsRUFBRSxFQUFFLENBQUMsQ0FBQztnQ0FDL0UsS0FBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsS0FBSyxFQUFFLEtBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLEVBQUUsRUFBRSxDQUFDLENBQUM7Z0NBQ3JGLEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsTUFBTSxHQUFDLENBQUMsQ0FBQztvQ0FDM0MsS0FBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsT0FBTyxFQUFFLEtBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsV0FBVyxFQUFFLEVBQUUsQ0FBQyxDQUFDO2dDQUN2SixZQUFZO2dDQUNYLDBEQUEwRDtnQ0FDMUQsV0FBVztnQ0FDWCxLQUFJLENBQUMsY0FBYyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7Z0NBQ3BDLEtBQUksQ0FBQyxVQUFVLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQztnQ0FDaEMsS0FBSSxDQUFDLFdBQVcsQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7NEJBTXRDLENBQUM7NEJBQ0QsS0FBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7NEJBQ3BCLEtBQUksQ0FBQyxHQUFHLEdBQUcsUUFBUSxDQUFDLE1BQU0sQ0FBQzt3QkFDL0IsQ0FBQyxFQUNHLFVBQUEsS0FBSyxJQUFHLE9BQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBbEIsQ0FBa0IsRUFDMUIsY0FBTSxPQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsc0JBQXNCLENBQUMsRUFBbkMsQ0FBbUMsQ0FDNUMsQ0FBQztvQkFDTixDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUNGLE9BQU8sQ0FBQyxLQUFLLENBQUM7NEJBQ1YsT0FBTyxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGlCQUFpQixFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsWUFBWTs0QkFDakYsT0FBTyxFQUFFO2dDQUNMLEVBQUUsRUFBRTtvQ0FDQSxjQUFjO29DQUNkLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUztpQ0FDNUI7NkJBQ0o7eUJBQ0osQ0FBQyxDQUFDO3dCQUNILElBQUksQ0FBQyxZQUFZLEdBQUcsRUFBRSxDQUFDO3dCQUN2QixJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztvQkFDNUIsQ0FBQztnQkFDTCxDQUFDO2dCQUVELDREQUFvQyxHQUFwQztvQkFBQSxpQkEwRUM7b0JBekVHLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO29CQUM1QyxXQUFXO29CQUNYLElBQUksS0FBSyxHQUFHLEVBQUUsQ0FBQztvQkFDZixJQUFJLEtBQUssR0FBRyxFQUFFLENBQUM7b0JBQ2YsSUFBSSxPQUFPLEdBQUcsRUFBRSxDQUFDO29CQUNqQixJQUFJLE1BQU0sR0FBRyxFQUFFLENBQUM7b0JBQ2hCLElBQUksTUFBTSxHQUFHLEVBQUUsQ0FBQztvQkFFaEIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLElBQUksU0FBUyxDQUFDO3dCQUNuQyxLQUFLLEdBQUcsRUFBRSxDQUFDO29CQUNmLElBQUk7d0JBQ0EsS0FBSyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDO29CQUVsQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssSUFBSSxTQUFTLENBQUM7d0JBQ25DLEtBQUssR0FBRyxFQUFFLENBQUM7b0JBQ2YsSUFBSTt3QkFDQSxLQUFLLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUM7b0JBQ2xDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxJQUFJLFNBQVMsQ0FBQzt3QkFDckMsT0FBTyxHQUFHLEVBQUUsQ0FBQztvQkFDakIsSUFBSTt3QkFDQSxPQUFPLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUM7b0JBRXRDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLElBQUksQ0FBQzt3QkFFN0IsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsRUFBRSxJQUFJLEVBQUUsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxFQUFFLElBQUksU0FBUyxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLEVBQUUsSUFBSSxJQUFJLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDLE1BQU0sSUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDOzRCQUM1SCxNQUFNLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFHLEtBQUssQ0FBQzt3QkFDekMsQ0FBQztvQkFDTCxDQUFDLENBQUMsQ0FBQztvQkFDSCxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQzt3QkFBQyxNQUFNLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQztvQkFDdkUsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRTt3QkFDeEMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLEtBQUssSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLEtBQUssSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLElBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQzs0QkFDNUYsTUFBTSxJQUFJLElBQUksQ0FBQyxLQUFLLEdBQUMsS0FBSyxDQUFDO3dCQUMvQixDQUFDO29CQUVMLENBQUMsQ0FBQyxDQUFDO29CQUNILEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO3dCQUFDLE1BQU0sR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDO29CQUN2RSxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssSUFBSSxFQUFFLElBQUksS0FBSyxDQUFDLE1BQU0sSUFBSSxDQUFDLElBQUksS0FBSyxJQUFJLEVBQUUsSUFBSSxLQUFLLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQzsyQkFDbkUsQ0FBQyxPQUFPLElBQUksRUFBRSxJQUFJLE9BQU8sQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDOzJCQUN0QyxDQUFDLE1BQU0sSUFBSSxFQUFFLENBQUM7MkJBQ2QsQ0FBQyxNQUFNLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUVwQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsc0JBQXNCLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLE1BQU0sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7NEJBQ2xHLFdBQVc7NEJBQ1gsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7NEJBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQztnQ0FDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztvQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7b0NBQ3RELE9BQU8sRUFBRTt3Q0FDTCxFQUFFLEVBQUU7NENBQ0EsY0FBYzs0Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7eUNBQzVCO3FDQUNKO2lDQUNKLENBQUMsQ0FBQzs0QkFDUCxDQUFDOzRCQUNELElBQUksQ0FBQyxDQUFDO2dDQUNGLEtBQUksQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDO2dDQUNuQixLQUFJLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7Z0NBQzlCLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLElBQUksSUFBSSxJQUFJLFFBQVEsQ0FBQyxJQUFJLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQztvQ0FDdEQsS0FBSSxDQUFDLGNBQWMsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO29DQUNwQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsU0FBUyxFQUFFLENBQUE7Z0NBR3BDLENBQUM7NEJBRUwsQ0FBQzt3QkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLOzRCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7d0JBQ3ZCLENBQUMsRUFBRTs0QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO3dCQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFDUCxDQUFDO29CQUNELG9CQUFvQjtnQkFDeEIsQ0FBQztnQkFJRCwrQ0FBdUIsR0FBdkIsVUFBd0IsS0FBSyxFQUFFLEtBQUssRUFBQyxPQUFPO29CQUE1QyxpQkE4Q0M7b0JBN0NHLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO29CQUM1QyxXQUFXO29CQUNYLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLFNBQVMsQ0FBQzt3QkFDbkMsS0FBSyxHQUFHLEVBQUUsQ0FBQztvQkFDZixJQUFJO3dCQUNBLEtBQUssR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQztvQkFFbEMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLElBQUksU0FBUyxDQUFDO3dCQUNuQyxLQUFLLEdBQUcsRUFBRSxDQUFDO29CQUNmLElBQUk7d0JBQ0EsS0FBSyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDO29CQUNsQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sSUFBSSxTQUFTLENBQUM7d0JBQ3JDLE9BQU8sR0FBRyxFQUFFLENBQUM7b0JBQ2pCLElBQUk7d0JBQ0EsT0FBTyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDO29CQUN0QyxJQUFJLENBQUMsZ0JBQWdCLENBQUMscUJBQXFCLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUNqRixXQUFXO3dCQUNYLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUN0RCxPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQzs0QkFDbkIsS0FBSSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDOzRCQUM5QixFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxJQUFJLElBQUksSUFBSSxRQUFRLENBQUMsSUFBSSxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUM7Z0NBQ3RELEtBQUksQ0FBQyxjQUFjLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQztnQ0FDcEMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDOzRCQUVyQyxDQUFDO3dCQUVMLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsb0JBQW9CO2dCQUN4QixDQUFDO2dCQUtELDBDQUFrQixHQUFsQjtvQkFFSSxpQkFBaUI7b0JBQ2pCLHdFQUF3RTtvQkFDeEUsb0NBQW9DO29CQUNwQyw0RUFBNEU7b0JBQzVFLGlCQUFpQjtvQkFDakIsNENBQTRDO29CQUM1QyxxQ0FBcUM7b0JBQ3JDLGlDQUFpQztvQkFDakMsT0FBTztvQkFDUCxZQUFZO29CQUNaLDZCQUE2QjtvQkFDN0Isd0NBQXdDO29CQUN4QyxvRUFBb0U7b0JBQ3BFLGtEQUFrRDtvQkFDbEQsaURBQWlEO29CQUNqRCxXQUFXO29CQUNYLDRCQUE0QjtvQkFDNUIsT0FBTztvQkFDUCxjQUFjO29CQUNkLHlCQUF5QjtvQkFDekIsWUFBWTtvQkFDWixrQ0FBa0M7b0JBQ2xDLEtBQUs7Z0JBQ1QsQ0FBQztnQkFDRCwwQ0FBa0IsR0FBbEI7b0JBQUEsaUJBZ0NDO29CQS9CRyxJQUFJLEtBQUssR0FBRyxFQUFFLENBQUM7b0JBQ2YsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLFNBQVMsQ0FBQzt3QkFDbEUsS0FBSyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDO29CQUNsQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsc0JBQXNCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUNsRixXQUFXO3dCQUNYLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUN0RCxPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQzs0QkFDbkIsS0FBSSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDOzRCQUM5QixFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxJQUFJLElBQUksSUFBSSxRQUFRLENBQUMsSUFBSSxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUM7Z0NBQ3RELEtBQUksQ0FBQyxjQUFjLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQztnQ0FDcEMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDOzRCQUNyQyxDQUFDO3dCQUVMLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7Z0JBQ1AsQ0FBQztnQkFDRCxtQ0FBVyxHQUFYLFVBQVksS0FBSztvQkFDYixNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxFQUFFO3dCQUN4QyxFQUFFLENBQUMsQ0FBQyxJQUFJLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQzs0QkFDaEIsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7d0JBQzlCLENBQUM7b0JBRUwsQ0FBQyxDQUFDLENBQUM7Z0JBQ1AsQ0FBQztnQkFDRCxvQ0FBWSxHQUFaO29CQUNJLElBQUksQ0FBQyxPQUFPLEdBQUcsRUFBRSxDQUFDO29CQUNsQixJQUFJLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztvQkFDckIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEdBQUcsRUFBRSxDQUFDO29CQUNqQyxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsR0FBRyxFQUFFLENBQUM7b0JBQzlCLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztvQkFDMUIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDO29CQUMzQixJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsR0FBRyxFQUFFLENBQUM7b0JBQ2hDLElBQUksQ0FBQyxVQUFVLEdBQUcsRUFBRSxDQUFDO29CQUNyQixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGFBQWEsQ0FBQTtnQkFHM0QsQ0FBQztnQkFDRCxzQ0FBYyxHQUFkO29CQUNJLFdBQVc7b0JBQ1gsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDO3dCQUMzQixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQzt3QkFDdkIsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxpQkFBaUIsQ0FBQzt3QkFDNUQsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFDakMsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQzt3QkFDeEIsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxrQkFBa0IsQ0FBQzt3QkFDN0QsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFDakMsQ0FBQztnQkFFTCxDQUFDO2dCQUdELHFDQUFhLEdBQWIsVUFBYyxLQUFLO29CQUNmLGlCQUFpQjtvQkFDakIsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sSUFBSSxTQUFTLElBQUksS0FBSyxDQUFDLE1BQU0sSUFBSSxFQUFFLENBQUM7MkJBQ2pELENBQUMsS0FBSyxDQUFDLE9BQU8sSUFBSSxTQUFTLElBQUksS0FBSyxDQUFDLE9BQU8sSUFBSSxFQUFFLENBQUM7MkJBRW5ELENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxTQUFTLElBQUksS0FBSyxDQUFDLEdBQUcsSUFBSSxFQUFFLENBQUM7MkJBQzNDLENBQUMsS0FBSyxDQUFDLFdBQVcsSUFBSSxTQUFTLElBQUksS0FBSyxDQUFDLFdBQVcsSUFBSSxFQUFFLENBQUU7MkJBRTVELENBQUMsS0FBSyxDQUFDLGFBQWEsSUFBSSxTQUFTLElBQUksS0FBSyxDQUFDLGFBQWEsSUFBSSxFQUFFLENBQUMsQ0FBQztnQkFDM0UsQ0FBQztnQkFDRCxvQ0FBWSxHQUFaLFVBQWEsS0FBSztvQkFFZCxJQUFJLFNBQVMsR0FBRyxLQUFLLENBQUM7b0JBQ3RCLEtBQUssQ0FBQyxRQUFRLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDO29CQUV2QyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFFNUIsSUFBSSxLQUFLLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQzt3QkFDL0MsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsT0FBTyxFQUFFLEtBQUssQ0FBQyxXQUFXLEVBQUUsRUFBRSxDQUFDLENBQUM7d0JBQ3hFLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQzt3QkFDZCxJQUFJLE1BQU0sR0FBRyxNQUFNLENBQUM7d0JBQ3BCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDOzRCQUN4RSxNQUFNLEdBQUcsTUFBTSxDQUFDO3dCQUNwQixDQUFDO3dCQUNELE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRTs0QkFDNUIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxNQUFNLENBQUMsQ0FBQyxDQUFDO2dDQUN0QixJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztnQ0FDbEIsTUFBTSxDQUFDLEtBQUssQ0FBQzs0QkFDakIsQ0FBQzt3QkFFTCxDQUFDLENBQUMsQ0FBQzt3QkFDSCxJQUFJLFNBQVMsR0FBRyxFQUFFLE1BQU0sRUFBRSxFQUFFLEVBQUUsT0FBTyxFQUFFLEVBQUUsRUFBRSxRQUFRLEVBQUUsRUFBRSxFQUFFLEdBQUcsRUFBRSxFQUFFLEVBQUUsV0FBVyxFQUFFLEtBQUssQ0FBQyxXQUFXLEVBQUUsT0FBTyxFQUFFLEVBQUUsRUFBRSxhQUFhLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRyxTQUFTLEVBQUUsVUFBVSxHQUFHLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLEdBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsV0FBVyxFQUFFLFFBQVEsR0FBRyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsTUFBTSxHQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUM7d0JBRTVVLDhEQUE4RDt3QkFDOUQsbUZBQW1GO3dCQUVuRixvQ0FBb0M7d0JBQ3BDLHVCQUF1Qjt3QkFDdkIsT0FBTzt3QkFDUCxLQUFLO3dCQUNMLEVBQUUsQ0FBQyxDQUFDLFNBQVMsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDOzRCQUNyQixJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQzt3QkFDdEQsQ0FBQztvQkFFVCxDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUNGLElBQUksR0FBRyxHQUFHLEVBQUUsQ0FBQzt3QkFDYixFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxJQUFJLFNBQVMsSUFBSSxLQUFLLENBQUMsTUFBTSxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7NEJBQ2xELG9EQUFvRDs0QkFDcEQsR0FBRyxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxpQkFBaUIsQ0FBQzt3QkFDN0QsQ0FBQzt3QkFDRCxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxJQUFJLFNBQVMsSUFBSSxLQUFLLENBQUMsT0FBTyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7NEJBQ3BELGdDQUFnQzs0QkFDaEMsR0FBRyxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxlQUFlLENBQUM7d0JBQzNELENBQUM7d0JBQ0QsMERBQTBEO3dCQUMxRCx1Q0FBdUM7d0JBQ3ZDLDZEQUE2RDt3QkFDN0QsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxTQUFTLElBQUksS0FBSyxDQUFDLEdBQUcsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDOzRCQUM1QyxnQ0FBZ0M7NEJBQ2hDLEdBQUcsSUFBSSxJQUFJLEdBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsY0FBYyxDQUFDO3dCQUN4RCxDQUFDO3dCQUNELEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxXQUFXLElBQUksU0FBUyxJQUFJLEtBQUssQ0FBQyxXQUFXLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzs0QkFDNUQscUNBQXFDOzRCQUNyQyxHQUFHLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGtCQUFrQixDQUFDO3dCQUM5RCxDQUFDO3dCQUNELHdFQUF3RTt3QkFDeEUsdUNBQXVDO3dCQUN2QyxHQUFHO3dCQUNILEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxhQUFhLElBQUksU0FBUyxJQUFJLEtBQUssQ0FBQyxhQUFhLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzs0QkFDaEUsMENBQTBDOzRCQUMxQyxHQUFHLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGlCQUFpQixDQUFDO3dCQUM3RCxDQUFDO3dCQUNELE9BQU8sQ0FBQyxLQUFLLENBQUM7NEJBQ1YsT0FBTyxFQUFFLEdBQUcsRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLFlBQVk7NEJBQzFDLE9BQU8sRUFBRTtnQ0FDTCxFQUFFLEVBQUU7b0NBQ0EsY0FBYztvQ0FDZCxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVM7aUNBQzVCOzZCQUNKO3lCQUNKLENBQUMsQ0FBQztvQkFDUCxDQUFDO2dCQUVMLENBQUM7Z0JBQ0QsbUNBQVcsR0FBWCxVQUFZLFFBQVE7b0JBQ2hCLFdBQVc7b0JBQ1gsaUtBQWlLO29CQUNqSyxNQUFNLENBQUMsQ0FBQyxRQUFRLENBQUMsV0FBVyxJQUFJLFNBQVMsSUFBSSxRQUFRLENBQUMsV0FBVyxJQUFJLEVBQUUsQ0FBQyxDQUFBO29CQUNwRSxpRkFBaUY7b0JBQ2pGLDJFQUEyRTtvQkFDM0Usc0VBQXNFO29CQUN0RSwyREFBMkQ7b0JBQzNELDhGQUE4RjtnQkFDdEcsQ0FBQztnQkFDRCxpQ0FBUyxHQUFULFVBQVUsUUFBUTtvQkFDZCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFFN0IsUUFBUSxDQUFDO3dCQUNULHVDQUF1Qzt3QkFDdkMsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDO3dCQUNkLElBQUksR0FBRyxHQUFHLENBQUMsQ0FBQzt3QkFDWixJQUFJLE9BQU8sR0FBRyxDQUFDLENBQUM7d0JBQ2hCLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRTs0QkFDMUIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxXQUFXLENBQUMsQ0FBQyxDQUFDO2dDQUUzQixJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztnQ0FDbEIsR0FBRyxHQUFHLENBQUMsQ0FBQztnQ0FDUixPQUFPLEdBQUcsQ0FBQyxDQUFDO2dDQUNaLE1BQU0sQ0FBQyxLQUFLLENBQUM7NEJBQ2pCLENBQUM7d0JBQ0wsQ0FBQyxDQUFDLENBQUM7d0JBQ0gsSUFBSSxRQUFRLEdBQUcsRUFBRSxXQUFXLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBRSxFQUFFLEVBQUUsTUFBTSxFQUFFLEVBQUUsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLEdBQUcsRUFBRSxRQUFRLEVBQUUsRUFBRSxFQUFFLGFBQWEsRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsS0FBSyxHQUFHLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLFlBQVksRUFBRSxLQUFLLEdBQUcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQzt3QkFFalQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO29CQUlsRCxDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUNGLElBQUksR0FBRyxHQUFHLEVBQUUsQ0FBQzt3QkFDYixFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsV0FBVyxJQUFJLFNBQVMsSUFBSSxRQUFRLENBQUMsV0FBVyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7NEJBQ2xFLHdDQUF3Qzs0QkFDeEMsR0FBRyxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxvQkFBb0IsQ0FBQzt3QkFDaEUsQ0FBQzt3QkFDRCw0REFBNEQ7d0JBQzVELDhDQUE4Qzt3QkFDOUMsZ0VBQWdFO3dCQUNoRSxHQUFHO3dCQUNILHlDQUF5Qzt3QkFDekMsaURBQWlEO3dCQUNqRCxHQUFHO3dCQUNILE9BQU8sQ0FBQyxLQUFLLENBQUM7NEJBQ1YsT0FBTyxFQUFFLEdBQUcsRUFBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLFlBQVk7NEJBQ3pDLE9BQU8sRUFBRTtnQ0FDTCxFQUFFLEVBQUU7b0NBQ0EsY0FBYztvQ0FDZCxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVM7aUNBQzVCOzZCQUNKO3lCQUNKLENBQUMsQ0FBQztvQkFFUCxDQUFDO2dCQUVMLENBQUM7Z0JBQ0QsbUNBQVcsR0FBWCxVQUFZLFFBQVE7b0JBQ2hCLFdBQVc7b0JBQ1gsaUJBQWlCO29CQUNqQixNQUFNLENBQUMsQ0FBQyxRQUFRLENBQUMsU0FBUyxJQUFJLFNBQVMsSUFBSSxRQUFRLENBQUMsU0FBUyxJQUFJLEVBQUUsQ0FBQyxDQUFDO29CQUNyRSwwREFBMEQ7Z0JBRTlELENBQUM7Z0JBQ0QsaUNBQVMsR0FBVCxVQUFVLFFBQVE7b0JBQ2QsV0FBVztvQkFDWCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDN0IsSUFBSSxRQUFRLEdBQUcsQ0FBQyxDQUFDO3dCQUNqQixNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUU7NEJBQzNCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksV0FBVyxDQUFDLENBQUMsQ0FBQztnQ0FJM0IsUUFBUSxHQUFHLENBQUMsQ0FBQztnQ0FDWixNQUFNLENBQUMsS0FBSyxDQUFDOzRCQUNqQixDQUFDO3dCQUNMLENBQUMsQ0FBQyxDQUFDO3dCQUNILHVDQUF1Qzt3QkFDdkMsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDO3dCQUNkLElBQUksQ0FBQyxLQUFLLEdBQUcsRUFBRSxDQUFDO3dCQUNoQixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDO3dCQUN4QyxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQzt3QkFDeEIsSUFBSSxDQUFDLE9BQU8sR0FBRyxRQUFRLENBQUM7d0JBQ3hCLElBQUksQ0FBQyxTQUFTLEdBQUUsTUFBTSxHQUFHLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsTUFBTSxHQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRSxDQUFDO3dCQUM5RSxJQUFJLENBQUMsYUFBYSxHQUFFLE1BQU0sR0FBRyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQzt3QkFDaEYsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO29CQUdsRCxDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUNGLElBQUksR0FBRyxHQUFHLEVBQUUsQ0FBQzt3QkFDYiwwREFBMEQ7d0JBQzFELHVDQUF1Qzt3QkFDdkMsaUVBQWlFO3dCQUNqRSxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsU0FBUyxJQUFJLFNBQVMsSUFBSSxRQUFRLENBQUMsU0FBUyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7NEJBQzlELGdDQUFnQzs0QkFDaEMsR0FBRyxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxtQkFBbUIsQ0FBQzt3QkFDL0QsQ0FBQzt3QkFDRCxPQUFPLENBQUMsS0FBSyxDQUFDOzRCQUNWLE9BQU8sRUFBRSxHQUFHLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxZQUFZOzRCQUMxQyxPQUFPLEVBQUU7Z0NBQ0wsRUFBRSxFQUFFO29DQUNBLGNBQWM7b0NBQ2QsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO2lDQUM1Qjs2QkFDSjt5QkFDSixDQUFDLENBQUM7b0JBRVAsQ0FBQztvQkFFRCw4REFBOEQ7Z0JBQ2xFLENBQUM7Z0JBRUQsbUNBQVcsR0FBWCxVQUFZLEdBQUc7b0JBQWYsaUJBMkdDO29CQTFHRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsa0JBQWtCLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7d0JBQ3hFLFlBQVk7d0JBQ1gsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQ3RELE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEtBQUksQ0FBQyxVQUFVLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzs0QkFDaEMsS0FBSSxDQUFDLGFBQWEsR0FBRyxLQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxjQUFjLENBQUM7NEJBQzdELHdFQUF3RTs0QkFDeEUsS0FBSSxDQUFDLE9BQU8sR0FBRyxpQkFBaUIsQ0FBQzs0QkFDakMsRUFBRSxDQUFDLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQzdDLEtBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLENBQUMsRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFFLFNBQVMsRUFBRSxLQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLE9BQU8sRUFBRSxDQUFDLEVBQUUsU0FBUyxFQUFFLE9BQU8sRUFBRSxhQUFhLEVBQUUsT0FBTyxFQUFFLENBQUMsQ0FBQTs0QkFDbkssQ0FBQzs0QkFDRCxJQUFJLENBQUMsQ0FBQztnQ0FDRixJQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7Z0NBRWQsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRTtvQ0FDeEMsSUFBSSxDQUFDLFNBQVMsR0FBRyxNQUFNLEdBQUcsS0FBSyxDQUFDO29DQUNoQyxJQUFJLENBQUMsYUFBYSxHQUFHLE1BQU0sR0FBRyxLQUFLLEVBQUUsQ0FBQztnQ0FDMUMsQ0FBQyxDQUFDLENBQUM7NEJBQ1AsQ0FBQzs0QkFDRCxFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDN0MsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDO2dDQUVkLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLFdBQVcsRUFBRTtvQ0FFMUIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxXQUFXLENBQUMsQ0FBQyxDQUFDO3dDQUUzQixJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQzt3Q0FDbEIsTUFBTSxDQUFDLEtBQUssQ0FBQztvQ0FDakIsQ0FBQztnQ0FDTCxDQUFDLENBQUMsQ0FBQztnQ0FFSCxLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxDQUFDLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsQ0FBQyxFQUFFLFFBQVEsRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFFLENBQUMsRUFBRSxRQUFRLEVBQUUsTUFBTSxFQUFFLFlBQVksRUFBRSxNQUFNLEVBQUUsQ0FBQyxDQUFDOzRCQUc1SyxDQUFDOzRCQUNELElBQUksQ0FBQyxDQUFDO2dDQUNGLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQztnQ0FDZCxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxFQUFFO29DQUV4QyxJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssR0FBRyxLQUFLLENBQUM7b0NBQzlCLElBQUksQ0FBQyxZQUFZLEdBQUcsS0FBSyxHQUFHLEtBQUssRUFBRSxDQUFDO2dDQUN4QyxDQUFDLENBQUMsQ0FBQzs0QkFDUCxDQUFDOzRCQUNELEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQ2hELElBQUksS0FBSyxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUM7Z0NBRS9DLElBQUksS0FBSyxHQUFHLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLE9BQU8sQ0FBQyxDQUFDO2dDQUM3RCxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztvQ0FDakIsS0FBSyxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQztnQ0FDN0MsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDO2dDQUNkLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQztnQ0FDdEIsRUFBRSxDQUFDLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLElBQUksRUFBRSxJQUFJLEtBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxJQUFJLFNBQVMsSUFBSSxLQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO29DQUMzRyxRQUFRLEdBQUcsTUFBTSxDQUFDO2dDQUN0QixDQUFDO2dDQUNELE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLGFBQWEsRUFBRTtvQ0FDNUIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxRQUFRLENBQUMsQ0FBQyxDQUFDO3dDQUV4QixJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQzt3Q0FDbEIsTUFBTSxDQUFDLEtBQUssQ0FBQztvQ0FDakIsQ0FBQztnQ0FFTCxDQUFDLENBQUMsQ0FBQztnQ0FDSCxLQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixHQUFHLENBQUMsRUFBRSxNQUFNLEVBQUUsRUFBRSxFQUFFLE9BQU8sRUFBRSxFQUFFLEVBQUUsUUFBUSxFQUFFLEVBQUUsRUFBRSxHQUFHLEVBQUUsRUFBRSxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsT0FBTyxFQUFFLEVBQUUsRUFBRSxhQUFhLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsV0FBVyxFQUFFLFdBQVcsRUFBRSxTQUFTLEVBQUUsQ0FBQyxDQUFDOzRCQUMzTyxDQUFDOzRCQUNELElBQUksQ0FBQyxDQUFDO2dDQUNGLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQztnQ0FDbEIsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixFQUFFO29DQUMzQyxJQUFJLENBQUMsU0FBUyxHQUFHLFVBQVUsR0FBRyxLQUFLLENBQUM7b0NBQ3BDLElBQUksQ0FBQyxXQUFXLEdBQUcsUUFBUSxHQUFHLEtBQUssRUFBRSxDQUFDO2dDQUMxQyxDQUFDLENBQUMsQ0FBQzs0QkFDSCxDQUFDOzRCQUNELDREQUE0RDs0QkFFNUQscUNBQXFDOzRCQUdyQywyREFBMkQ7NEJBQzNELDZHQUE2Rzs0QkFDN0csaUJBQWlCOzRCQUNqQixvQ0FBb0M7NEJBQ3BDLE9BQU87NEJBQ1AsdUVBQXVFOzRCQUN2RSwwREFBMEQ7NEJBQzFELEtBQUs7NEJBQ0wsS0FBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLEdBQUcsS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDOzRCQUMzRCxLQUFJLENBQUMsZUFBZSxHQUFHLEtBQUssQ0FBQzs0QkFDN0IsS0FBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7d0JBRzdCLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7Z0JBQ1AsQ0FBQztnQkFDRCxzQ0FBYyxHQUFkLFVBQWUsUUFBUTtvQkFBdkIsaUJBK0RDO29CQTlERyxXQUFXO29CQUNYLG1FQUFtRTtvQkFDbkUsSUFBSSxPQUFPLEdBQUcsRUFBRSxDQUFDO29CQUNqQixNQUFNLENBQUMsd0JBQXdCLENBQUMsQ0FBQyxJQUFJLENBQUM7d0JBQ2xDLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7b0JBQ3JDLENBQUMsQ0FBQyxDQUFDO29CQUNILElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQztvQkFDZCxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxFQUFFO3dCQUN4QyxFQUFFLENBQUMsQ0FBQyxJQUFJLElBQUksUUFBUSxDQUFDLENBQUMsQ0FBQzs0QkFFbkIsTUFBTSxDQUFDLEtBQUssQ0FBQTt3QkFDaEIsQ0FBQzt3QkFDRCxLQUFLLEdBQUcsS0FBSyxHQUFHLENBQUMsQ0FBQztvQkFDdEIsQ0FBQyxDQUFDLENBQUM7b0JBRUgsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxJQUFJLFNBQVMsSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLElBQUksSUFBSSxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO3dCQUNoRixJQUFJLFdBQVcsR0FBRyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7d0JBQ2pDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxlQUFlLENBQUMsV0FBVyxDQUFDLENBQUMsU0FBUyxDQUN4RCxVQUFDLElBQUk7NEJBQ0QsV0FBVzs0QkFDWCxFQUFFOzRCQUNGLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7NEJBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQztnQ0FDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztvQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7b0NBQ3RELE9BQU8sRUFBRTt3Q0FDTCxFQUFFLEVBQUU7NENBQ0EsY0FBYzs0Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7eUNBQzVCO3FDQUNKO2lDQUNKLENBQUMsQ0FBQzs0QkFDUCxDQUFDOzRCQUNELElBQUksQ0FBQyxDQUFDO2dDQUNGLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLElBQUksU0FBUyxJQUFJLFFBQVEsQ0FBQyxJQUFJLElBQUksSUFBSSxJQUFJLFFBQVEsQ0FBQyxJQUFJLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQztvQ0FFN0UsV0FBVztvQ0FFWCxrR0FBa0c7b0NBQ2xHLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLEdBQUcsQ0FBQyxDQUFDLENBQUM7d0NBQzVCLEtBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUM7d0NBQ2hELEtBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUM7d0NBQ3BELEtBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxPQUFPLEdBQUcsQ0FBQyxDQUFDO29DQUMxRixDQUFDO29DQUNELElBQUksQ0FBQyxDQUFDO3dDQUNGLEtBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUM7d0NBQ3BELEtBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUM7d0NBQ2hELEtBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxPQUFPLEdBQUcsQ0FBQyxDQUFDO29DQUMxRixDQUFDO2dDQUVMLENBQUM7NEJBRUwsQ0FBQzs0QkFDRCx3RkFBd0Y7d0JBQzVGLENBQUMsRUFDRCxVQUFDLEdBQUc7d0JBRUosQ0FBQyxFQUNEO3dCQUVBLENBQUMsQ0FBQyxDQUFDO29CQUNQLENBQUM7Z0JBQ1QsQ0FBQztnQkFDRCxvQ0FBWSxHQUFaLFVBQWEsUUFBUTtvQkFDakIsV0FBVztvQkFDWCxJQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7b0JBQ2QsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQztvQkFDN0IsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxjQUFjLENBQUM7b0JBSXpELElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxHQUFHLFFBQVEsQ0FBQyxLQUFLLENBQUM7b0JBQ3ZDLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxHQUFHLFFBQVEsQ0FBQyxTQUFTLENBQUM7b0JBQy9DLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxHQUFHLFFBQVEsQ0FBQyxXQUFXLENBQUM7b0JBR25ELElBQUksQ0FBQyxhQUFhLEdBQUcsRUFBRSxDQUFDO29CQUN4QixJQUFJLENBQUMsYUFBYSxHQUFHLFFBQVEsQ0FBQztnQkFDbEMsQ0FBQztnQkFDRCxtQ0FBVyxHQUFYLFVBQVksUUFBUTtvQkFDaEIsV0FBVztvQkFDWCxJQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7b0JBQ2QsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRTt3QkFDeEMsRUFBRSxDQUFDLENBQUMsSUFBSSxJQUFJLFFBQVEsQ0FBQyxDQUFDLENBQUM7NEJBQ25CLE1BQU0sQ0FBQyxLQUFLLENBQUE7d0JBQ2hCLENBQUM7d0JBQ0QsS0FBSyxHQUFHLEtBQUssR0FBRyxDQUFDLENBQUM7b0JBRXRCLENBQUMsQ0FBQyxDQUFDO29CQUNILElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0JBQ3BELENBQUM7Z0JBRUQsc0NBQWMsR0FBZCxVQUFlLFVBQVU7b0JBQ3JCLFdBQVc7b0JBQ1gsSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO29CQUNkLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUM7b0JBQzdCLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsY0FBYyxDQUFDO29CQUUxRCwrQ0FBK0M7b0JBRTlDLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUM7b0JBQ3hDLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxHQUFHLFVBQVUsQ0FBQyxPQUFPLENBQUM7b0JBQzFDLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxHQUFHLFVBQVUsQ0FBQyxRQUFRLENBQUM7b0JBQzVDLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxHQUFHLFVBQVUsQ0FBQyxHQUFHLENBQUM7b0JBQ2xDLElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxHQUFHLFVBQVUsQ0FBQyxXQUFXLENBQUM7b0JBQ2xELElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxHQUFHLFVBQVUsQ0FBQyxPQUFPLENBQUM7b0JBQzFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxHQUFHLFVBQVUsQ0FBQyxhQUFhLENBQUM7b0JBQ3RELElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxHQUFHLFVBQVUsQ0FBQyxXQUFXLENBQUM7b0JBQ2xELElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxHQUFHLFVBQVUsQ0FBQyxXQUFXLENBQUM7b0JBR2xELElBQUksQ0FBQyxlQUFlLEdBQUcsRUFBRSxDQUFDO29CQUMxQixJQUFJLENBQUMsZUFBZSxHQUFHLFVBQVUsQ0FBQztnQkFDdEMsQ0FBQztnQkFFRCxxQ0FBYSxHQUFiLFVBQWMsVUFBVTtvQkFDckIsYUFBYTtvQkFDWixJQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7b0JBQ2QsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixFQUFFO3dCQUMzQyxFQUFFLENBQUMsQ0FBQyxJQUFJLElBQUksVUFBVSxDQUFDLENBQUMsQ0FBQzs0QkFDckIsTUFBTSxDQUFDLEtBQUssQ0FBQTt3QkFDaEIsQ0FBQzt3QkFDRCxLQUFLLEdBQUcsS0FBSyxHQUFHLENBQUMsQ0FBQztvQkFDdEIsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDO2dCQUN2RCxDQUFDO2dCQUNELG9DQUFZLEdBQVosVUFBYSxRQUFRO29CQUVqQixJQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7b0JBQ2QsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxjQUFjLENBQUE7b0JBQ3hELElBQUksSUFBSSxHQUFHLFFBQVEsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUUzQyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsR0FBRyxRQUFRLENBQUMsU0FBUyxHQUFHLEdBQUcsR0FBRyxRQUFRLENBQUMsV0FBVyxDQUFDO29CQUU5RSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsR0FBRyxRQUFRLENBQUMsU0FBUyxDQUFDO29CQUMvQyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDO29CQUN6QyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO29CQUNyQyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUMsS0FBSyxDQUFDO29CQUN2QyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUMsS0FBSyxDQUFDO29CQUN2QyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUMsUUFBUSxDQUFDO29CQUM3QyxJQUFJLENBQUMsYUFBYSxHQUFHLEVBQUUsQ0FBQztvQkFDeEIsSUFBSSxDQUFDLGFBQWEsR0FBRyxRQUFRLENBQUM7Z0JBQ2xDLENBQUM7Z0JBQ0QsbUNBQVcsR0FBWCxVQUFZLFFBQVE7b0JBRWhCLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQztvQkFDZCxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxFQUFFO3dCQUN4QyxFQUFFLENBQUMsQ0FBQyxJQUFJLElBQUksUUFBUSxDQUFDLENBQUMsQ0FBQzs0QkFDbkIsTUFBTSxDQUFDLEtBQUssQ0FBQTt3QkFDaEIsQ0FBQzt3QkFDRCxLQUFLLEdBQUcsS0FBSyxHQUFHLENBQUMsQ0FBQztvQkFDdEIsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQztnQkFDcEQsQ0FBQztnQkFHRCx5Q0FBaUIsR0FBakI7b0JBQ0ksSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDO29CQUNwQyxJQUFJLGNBQWMsR0FBRyxFQUFFLENBQUM7b0JBQ3hCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQzt3QkFDMUIsd0JBQWEsQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLEVBQUUsY0FBYyxDQUFDLENBQUM7b0JBQy9HLENBQUM7b0JBQ0QsSUFBSSxDQUFDLENBQUM7d0JBRUYsd0JBQWEsQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLEVBQUUsY0FBYyxDQUFDLENBQUM7b0JBQ2hILENBQUM7b0JBQ0QsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFDLENBQUMsR0FBQyxjQUFjLENBQUMsTUFBTSxFQUFDLENBQUMsRUFBRSxFQUFDLENBQUM7d0JBQ3hDLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQzt3QkFDZCxJQUFJLENBQUMsc0JBQXNCLEdBQUcsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUNoRCxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBRTlDLENBQUM7Z0JBRUwsQ0FBQztnQkFFRCw0QkFBSSxHQUFKO29CQUNHLGlCQUFpQjtvQkFDaEIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO3dCQUN4QixJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQzt3QkFFdEIsNkJBQTZCO3dCQUM3QixJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGdCQUFnQixDQUFDO29CQUNsRSxDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUNOLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO3dCQUNyQiw4QkFBOEI7d0JBQzlCLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsZ0JBQWdCLENBQUM7b0JBQzlELENBQUM7Z0JBQ0wsQ0FBQztnQkFDRCxxQ0FBYSxHQUFiLFVBQWMsU0FBUztvQkFBdkIsaUJBc0RDO29CQXJERyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLENBQUMsU0FBUyxDQUN2RCxVQUFDLElBQUk7d0JBQ0QsV0FBVzt3QkFDWCxFQUFFO3dCQUNGLG1CQUFtQjt3QkFDbkIsRUFBRSxDQUFDLENBQUMsU0FBUyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUM7NEJBQ3JCLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7NEJBQ3ZDLElBQUksR0FBRyxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFBOzRCQUNyQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsYUFBYSxDQUFDO2dDQUMvQixZQUFZLEVBQUUsSUFBSTtnQ0FDbEIsVUFBVSxFQUFFO29DQUNSLGFBQWEsRUFBRSxJQUFJO2lDQUN0QjtnQ0FDRCw0QkFBNEI7Z0NBQzVCLFVBQVUsRUFBRSxHQUFHOzZCQUNsQixDQUFDLENBQUM7NEJBQ0gsSUFBSSxNQUFNLEdBQUcsRUFBRSxDQUFDOzRCQUVoQixNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxFQUFFO2dDQUN4QyxNQUFNLElBQUksSUFBSSxDQUFDLHNCQUFzQixHQUFHLEdBQUcsQ0FBQzs0QkFDaEQsQ0FBQyxDQUFDLENBQUM7NEJBQ0gsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUNwQix3QkFBYSxDQUFDLGVBQWUsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsRUFBRSxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUE7NEJBQ3ZJLENBQUM7d0JBQ0wsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixNQUFNLENBQUMsYUFBYSxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDOzRCQUN4QyxJQUFJLEdBQUcsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQTs0QkFDckMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDLGFBQWEsQ0FBQztnQ0FDaEMsWUFBWSxFQUFFLElBQUk7Z0NBQ2xCLFVBQVUsRUFBRTtvQ0FDUixhQUFhLEVBQUUsSUFBSTtpQ0FDdEI7Z0NBQ0QsNEJBQTRCO2dDQUM1QixVQUFVLEVBQUUsR0FBRzs2QkFDbEIsQ0FBQyxDQUFDOzRCQUNILElBQUksTUFBTSxHQUFHLEVBQUUsQ0FBQzs0QkFDaEIsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRTtnQ0FDeEMsTUFBTSxJQUFJLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxHQUFHLENBQUM7NEJBQ2hELENBQUMsQ0FBQyxDQUFDOzRCQUNILEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDcEIsd0JBQWEsQ0FBQyxlQUFlLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLEVBQUUsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFBOzRCQUN4SSxDQUFDO3dCQUNMLENBQUM7d0JBQ0Qsd0ZBQXdGO29CQUM1RixDQUFDLEVBQ0QsVUFBQyxHQUFHO29CQUVKLENBQUMsRUFDRDtvQkFFQSxDQUFDLENBQ0osQ0FBQztnQkFDTixDQUFDO2dCQUNELHdDQUFnQixHQUFoQixVQUFpQixLQUFVO29CQUV2Qiw4Q0FBOEM7b0JBQzlDLHVCQUF1QjtvQkFDdkIsNkdBQTZHO29CQUN6RyxvRUFBb0U7b0JBQ3hFLHdCQUF3QjtvQkFDeEIsaUNBQWlDO29CQUNqQyx3RkFBd0Y7b0JBRXhGLG9EQUFvRDtvQkFDcEQsNkNBQTZDO29CQUM3Qyx5Q0FBeUM7b0JBQ3pDLGVBQWU7b0JBQ2Ysb0JBQW9CO29CQUNwQixxQ0FBcUM7b0JBQ3JDLGdEQUFnRDtvQkFDaEQsNEVBQTRFO29CQUM1RSwwREFBMEQ7b0JBQzFELHlEQUF5RDtvQkFFekQsbUJBQW1CO29CQUVuQixlQUFlO29CQUNmLHNCQUFzQjtvQkFDdEIsaUNBQWlDO29CQUNqQyxvQkFBb0I7b0JBQ3BCLDBDQUEwQztvQkFDMUMsYUFBYTtvQkFDYiw4QkFBOEI7b0JBQzlCLE9BQU87b0JBRVAsR0FBRztvQkFDSCxzQkFBc0I7Z0JBQzFCLENBQUM7Z0JBR0QsZ0NBQVEsR0FBUjtvQkFBQSxpQkFxZUM7b0JBbmVFLFlBQVk7b0JBQ1gsOENBQThDO29CQUM5QyxFQUFFLENBQUMsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7d0JBQ3JDLFlBQVksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxDQUFDO29CQUN2QyxDQUFDO29CQUNELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzt3QkFFaEQsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsSUFBSSxFQUFFLEVBQUUsQ0FBQyxDQUFDO29CQUN0RCxDQUFDO29CQUNELElBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO29CQUN0QixJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7b0JBQ3RCLElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDO29CQUU1QixrQ0FBa0M7b0JBRWxDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ2xDLCtCQUErQjt3QkFDL0IsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7d0JBRWxDLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsY0FBYyxDQUFDO3dCQUM3RCx3RUFBd0U7d0JBQ3hFLG1DQUFtQzt3QkFFbkMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQzs0QkFDaEQsSUFBSSxLQUFLLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQzs0QkFFL0MsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsT0FBTyxDQUFDLENBQUM7NEJBQzdELEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO2dDQUNqQixLQUFLLEdBQUcsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDOzRCQUM3QyxJQUFJLElBQUksR0FBRyxFQUFFLENBQUM7NEJBQ2QsSUFBSSxRQUFRLEdBQUcsTUFBTSxDQUFDOzRCQUN0QixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7Z0NBQzNHLFFBQVEsR0FBRyxNQUFNLENBQUM7NEJBQ3RCLENBQUM7NEJBQ0QsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFO2dDQUM1QixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLFFBQVEsQ0FBQyxDQUFDLENBQUM7b0NBRXhCLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO29DQUNsQixNQUFNLENBQUMsS0FBSyxDQUFDO2dDQUNqQixDQUFDOzRCQUVMLENBQUMsQ0FBQyxDQUFDOzRCQUNILElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLEdBQUcsQ0FBQyxFQUFFLE1BQU0sRUFBRSxFQUFFLEVBQUUsT0FBTyxFQUFFLEVBQUUsRUFBRSxRQUFRLEVBQUUsRUFBRSxFQUFFLEdBQUcsRUFBRSxFQUFFLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRSxPQUFPLEVBQUUsRUFBRSxFQUFFLGFBQWEsRUFBRSxJQUFJLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxXQUFXLEVBQUUsV0FBVyxFQUFFLFNBQVMsRUFBRSxDQUFDLENBQUM7d0JBQzNPLENBQUM7d0JBQ0QsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFBO3dCQUMxRCxJQUFJLENBQUMsZUFBZSxHQUFHLEtBQUssQ0FBQztvQkFFakMsQ0FBQztvQkFDRCxJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQ3BELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ3ZCLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQ3pELENBQUM7b0JBQ0QsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7b0JBQzFCLHlKQUF5SjtvQkFFeEosRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO3dCQUNwQixJQUFJLENBQUMsV0FBVyxHQUFHLE9BQU8sQ0FBQzt3QkFDM0IsSUFBSSxDQUFDLFNBQVMsR0FBRyxVQUFVLENBQUM7d0JBQzVCLElBQUksQ0FBQyxZQUFZLEdBQUcsYUFBYSxDQUFDO29CQUl0QyxDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUNGLElBQUksQ0FBQyxTQUFTLEdBQUcsVUFBVSxDQUFDO3dCQUM1QixJQUFJLENBQUMsWUFBWSxHQUFHLFlBQVksQ0FBQztvQkFDckMsQ0FBQztvQkFHRixJQUFJLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7d0JBQ3pFLFdBQVc7d0JBQ1gsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQ3RELE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEtBQUksQ0FBQyxHQUFHLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzs0QkFDekIsS0FBSSxDQUFDLFlBQVksR0FBRyxLQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxnQkFBZ0IsQ0FBQzs0QkFDOUQsS0FBSSxDQUFDLFNBQVMsR0FBRyxLQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxrQkFBa0IsQ0FBQzs0QkFDN0QsS0FBSSxDQUFDLGFBQWEsR0FBRyxLQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUM7NEJBQzNELEtBQUksQ0FBQyxpQkFBaUIsR0FBRyxLQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxnQkFBZ0IsQ0FBQzs0QkFDbkUsS0FBSSxDQUFDLGVBQWUsR0FBRyxLQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxjQUFjLENBQUM7d0JBRW5FLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsNkJBQTZCO29CQUU3QixVQUFVO29CQUNWLElBQUksV0FBVyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDO29CQUMzQyxJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQztvQkFDckMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxXQUFXLEVBQUUsU0FBUyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFDdEUsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQ3RELE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLElBQUksZUFBZSxHQUFHLEVBQUUsQ0FBQzs0QkFDekIsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFO2dDQUN2QixJQUFJLE9BQU8sR0FBRyxFQUFFLENBQUM7Z0NBQ2pCLE9BQU8sQ0FBQyxFQUFFLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztnQ0FDeEIsT0FBTyxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO2dDQUN6QixlQUFlLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDOzRCQUNsQyxDQUFDLENBQUMsQ0FBQzs0QkFDSCxLQUFJLENBQUMsT0FBTyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7NEJBQzdCLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUM7Z0NBQ3RCLHFCQUFxQjtnQ0FDckIsTUFBTSxFQUFFLGVBQWU7Z0NBQ3ZCLGtCQUFrQjtnQ0FDbEIsUUFBUSxFQUFFLE1BQU07NkJBSW5CLENBQUMsQ0FBQzt3QkFDUCxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQU9GLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLHFCQUFxQixFQUFFLENBQUM7b0JBQ25FLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBRW5ELElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQ3RELE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEtBQUksQ0FBQyxVQUFVLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzs0QkFDaEMsRUFBRSxDQUFDLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLElBQUksRUFBRSxJQUFJLEtBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxJQUFJLFNBQVMsSUFBSSxLQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO2dDQUMxSCxJQUFJLFVBQVUsQ0FBQztnQ0FDZixNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUksQ0FBQyxVQUFVLEVBQUU7b0NBQ3pCLFVBQVUsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO29DQUN4QixNQUFNLENBQUMsS0FBSyxDQUFDO2dDQUNqQixDQUFDLENBQUMsQ0FBQztnQ0FDSCxLQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksR0FBRyxVQUFVLENBQUM7NEJBQzlDLENBQUM7d0JBQ0wsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFHSCxXQUFXO29CQUNYLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUM3QyxJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUN0RCxPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7NEJBQzlCLEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLElBQUksRUFBRSxJQUFJLEtBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLElBQUksU0FBUyxJQUFJLEtBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQztnQ0FDdEksSUFBSSxNQUFNLENBQUM7Z0NBQ1gsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsUUFBUSxFQUFFO29DQUN2QixNQUFNLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztvQ0FDcEIsTUFBTSxDQUFDLEtBQUssQ0FBQztnQ0FDakIsQ0FBQyxDQUFDLENBQUM7Z0NBQ0gsS0FBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsR0FBRyxNQUFNLENBQUM7NEJBQzlDLENBQUM7d0JBQ0wsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFFSCxjQUFjO29CQUNkLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLEVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUNuRCxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDdEQsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLFVBQVUsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDOzRCQUNoQyxFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxFQUFFLElBQUksS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksU0FBUyxJQUFJLEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7Z0NBQ3BILElBQUksS0FBSyxDQUFDO2dDQUNWLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLFVBQVUsRUFBRTtvQ0FDekIsS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7b0NBQ25CLE1BQU0sQ0FBQyxLQUFLLENBQUM7Z0NBQ2pCLENBQUMsQ0FBQyxDQUFDO2dDQUNILEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQzs0QkFDdkMsQ0FBQzt3QkFDTCxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUNILGFBQWE7b0JBQ2IsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFdBQVcsRUFBRSxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7d0JBQ2xELFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUN0RCxPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsU0FBUyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7d0JBQ25DLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsZUFBZTtvQkFDZixJQUFJLENBQUMsZ0JBQWdCLENBQUMsYUFBYSxFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFDckQsWUFBWTt3QkFDWCxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDdEQsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLFdBQVcsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDOzRCQUNqQyxJQUFJLElBQUksR0FBRyxFQUFFLENBQUM7NEJBQ2QsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsV0FBVyxFQUFFO2dDQUMxQixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLFdBQVcsQ0FBQyxDQUFDLENBQUM7b0NBRTNCLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO29DQUNsQixNQUFNLENBQUMsS0FBSyxDQUFDO2dDQUNqQixDQUFDOzRCQUNMLENBQUMsQ0FBQyxDQUFDOzRCQUNILEtBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUM7d0JBQ3pELENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBR0gsSUFBSSxRQUFRLEdBQUcsQ0FBQyxDQUFDO29CQUNqQixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDN0MsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDO3dCQUVkLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRTs0QkFDMUIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxXQUFXLENBQUMsQ0FBQyxDQUFDO2dDQUUzQixJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztnQ0FDbEIsUUFBUSxHQUFHLENBQUMsQ0FBQztnQ0FDYixNQUFNLENBQUMsS0FBSyxDQUFDOzRCQUNqQixDQUFDO3dCQUNMLENBQUMsQ0FBQyxDQUFDO3dCQUVILElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLENBQUMsRUFBRSxXQUFXLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBRSxNQUFNLEVBQUUsWUFBWSxFQUFDLE1BQU0sRUFBRSxDQUFDLENBQUM7b0JBR3pMLENBQUM7b0JBQ0QsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQzdDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLENBQUMsRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsU0FBUyxFQUFFLE9BQU8sRUFBRSxhQUFhLEVBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQTtvQkFDekssQ0FBQztvQkFFRCxpQkFBaUI7b0JBQ2pCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxlQUFlLEVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUN0RCxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDdEQsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLGFBQWEsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDOzRCQUNwQyxZQUFZOzRCQUNYLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQzs0QkFDZCxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUksQ0FBQyxhQUFhLEVBQUU7Z0NBQzVCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksTUFBTSxDQUFDLENBQUMsQ0FBQztvQ0FFdEIsSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7b0NBQ2xCLE1BQU0sQ0FBQyxLQUFLLENBQUM7Z0NBQ2pCLENBQUM7NEJBRUwsQ0FBQyxDQUFDLENBQUM7NEJBQ0gsS0FBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO3dCQUM5RCxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUNILFFBQVE7b0JBRVIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7d0JBQ2hELFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUN0RCxPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsT0FBTyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7d0JBQ2pDLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsYUFBYTtvQkFFYixJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFDbkQsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQ3RELE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEtBQUksQ0FBQyxVQUFVLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzt3QkFDcEMsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFDSCxVQUFVO29CQUNWLElBQUksV0FBVyxHQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDO29CQUMxQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7d0JBQzNELFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUN0RCxPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsT0FBTyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7d0JBQ2pDLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBR0gsWUFBWTtvQkFFWixxQ0FBcUM7b0JBQ3JDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsU0FBUyxDQUM1RCxVQUFDLElBQUk7d0JBQ0YsWUFBWTt3QkFDWCxFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsU0FBUyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUM7NEJBQzFCLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7NEJBQ3ZDLElBQUksR0FBRyxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFBOzRCQUNyQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsYUFBYSxDQUFDO2dDQUMvQixZQUFZLEVBQUUsSUFBSTtnQ0FDbEIsVUFBVSxFQUFFO29DQUNSLGFBQWEsRUFBRSxJQUFJO2lDQUN0QjtnQ0FDRCw0QkFBNEI7Z0NBQzVCLFVBQVUsRUFBRSxHQUFHOzZCQUVsQixDQUFDLENBQUM7NEJBQ0gsSUFBSSxNQUFNLEdBQUcsRUFBRSxDQUFDOzRCQUNoQixNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxFQUFFO2dDQUN4QyxNQUFNLElBQUksSUFBSSxDQUFDLHNCQUFzQixHQUFHLEdBQUcsQ0FBQzs0QkFDaEQsQ0FBQyxDQUFDLENBQUM7NEJBQ0gsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUNwQix3QkFBYSxDQUFDLGVBQWUsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsRUFBRSxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUE7NEJBQ3ZJLENBQUM7d0JBQ0wsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixNQUFNLENBQUMsYUFBYSxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDOzRCQUN4QyxJQUFJLEdBQUcsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQTs0QkFDckMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDLGFBQWEsQ0FBQztnQ0FDaEMsWUFBWSxFQUFFLElBQUk7Z0NBQ2xCLFVBQVUsRUFBRTtvQ0FDUixhQUFhLEVBQUUsSUFBSTtpQ0FDdEI7Z0NBQ0QsNEJBQTRCO2dDQUM1QixVQUFVLEVBQUUsR0FBRzs2QkFDbEIsQ0FBQyxDQUFDOzRCQUNILElBQUksTUFBTSxHQUFHLEVBQUUsQ0FBQzs0QkFDaEIsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRTtnQ0FDeEMsTUFBTSxJQUFJLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxHQUFHLENBQUM7NEJBQ2hELENBQUMsQ0FBQyxDQUFDOzRCQUNILEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDcEIsd0JBQWEsQ0FBQyxlQUFlLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLEVBQUUsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFBOzRCQUN4SSxDQUFDO3dCQUNMLENBQUM7b0JBQ0wsQ0FBQyxFQUNELFVBQUMsR0FBRztvQkFFSixDQUFDLEVBQ0Q7b0JBRUEsQ0FBQyxDQUNKLENBQUM7b0JBRUYsOENBQThDO29CQUMvQyxpREFBaUQ7b0JBQ2hELElBQUksUUFBUSxHQUFHLElBQUksQ0FBQztvQkFFcEIsY0FBYztvQkFDZCxNQUFNLENBQUMseUNBQXlDLENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ3RFLE1BQU0sQ0FBQyxzQ0FBc0MsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztvQkFDbkUsc0JBQXNCO2dCQUUxQixDQUFDO2dCQWhrRU0scUJBQU8sR0FBRyxDQUFDLFFBQVEsRUFBRSxXQUFXLEVBQUUsZUFBZSxDQUFDLENBQUM7Z0JBdkQ5RDtvQkFBQyxnQkFBUyxDQUFDO3dCQUVQLFdBQVcsRUFBRSw2Q0FBNkM7d0JBQzFELFVBQVUsRUFBRSxDQUFDLGlCQUFRLEVBQUUscUJBQVksRUFBRSx3QkFBZSxFQUFFLHVCQUF1QixFQUFFLHdCQUFlLEVBQUUsd0JBQWUsRUFBRSwwQkFBUSxDQUFDO3dCQUMxSCxTQUFTLEVBQUUsQ0FBQyxpQ0FBZSxFQUFFLGlDQUFlLENBQUM7cUJBQ2hELENBQUM7O2lDQUFBO2dCQW1uRUYsb0JBQUM7WUFBRCxDQWpuRUEsQUFpbkVDLElBQUE7WUFqbkVELHlDQWluRUMsQ0FBQSIsImZpbGUiOiJkZXYvYW1heC9DdXN0b21lci9hZGRDdXN0b21lci5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7TmdTd2l0Y2gsIE5nU3dpdGNoV2hlbiwgTmdTd2l0Y2hEZWZhdWx0LCBDT1JFX0RJUkVDVElWRVMsIEZPUk1fRElSRUNUSVZFU30gZnJvbSAnYW5ndWxhcjIvY29tbW9uJ1xyXG5pbXBvcnQge1Jlc291cmNlU2VydmljZX0gZnJvbSBcIi4uLy4uL3NlcnZpY2VzL1Jlc291cmNlU2VydmljZVwiO1xyXG5pbXBvcnQge1JvdXRlUGFyYW1zfSBmcm9tIFwiYW5ndWxhcjIvcm91dGVyXCI7XHJcbmltcG9ydCB7Q29tcG9uZW50LCBPdXRwdXQsIElucHV0LCBFdmVudEVtaXR0ZXIsIE9uSW5pdH0gZnJvbSBcImFuZ3VsYXIyL2NvcmVcIjtcclxuaW1wb3J0IHtDdXN0b21lclNlcnZpY2V9IGZyb20gXCIuLi8uLi9zZXJ2aWNlcy9DdXN0b21lclNlcnZpY2VcIjtcclxuaW1wb3J0IHsganNvblEgfSBmcm9tICcuLi8uLi9qc29uUSc7XHJcbmltcG9ydCB7R3JvdXBGaWx0ZXJQaXBlLCBHcm91cFBhcmVuRmlsdGVyUGlwZSwgS2VuZG9fdXRpbGl0eX0gZnJvbSBcIi4uLy4uL2FtYXhVdGlsXCI7XHJcbmltcG9ydCB7QXV0b2NvbXBsZXRlQ29udGFpbmVyfSBmcm9tICcuLi8uLi9hdXRvY29tcGxldGUvYXV0b2NvbXBsZXRlLWNvbnRhaW5lcic7XHJcbmltcG9ydCB7QXV0b2NvbXBsZXRlfSBmcm9tICcuLi8uLi9hdXRvY29tcGxldGUvYXV0b2NvbXBsZXRlLmNvbXBvbmVudCc7XHJcbmltcG9ydCB7IEFtYXhEYXRlIH0gZnJvbSAnLi4vLi4vY29tb25Db21wb25lbnRzL2Jhc2ljQ29tcG9uZW50cyc7XHJcblxyXG5leHBvcnQgY29uc3QgQVVUT0NPTVBMRVRFX0RJUkVDVElWRVMgPSBbQXV0b2NvbXBsZXRlLCBBdXRvY29tcGxldGVDb250YWluZXJdO1xyXG5kZWNsYXJlIHZhciBqUXVlcnk7XHJcbmRlY2xhcmUgdmFyIHN3YWw7XHJcbmRlY2xhcmUgdmFyIG1vbWVudDtcclxuQENvbXBvbmVudCh7XHJcblxyXG4gICAgdGVtcGxhdGVVcmw6ICcuL2FwcC9hbWF4L0N1c3RvbWVyL3RlbXBsYXRlcy9jdXN0b21lci5odG1sJyxcclxuICAgIGRpcmVjdGl2ZXM6IFtOZ1N3aXRjaCwgTmdTd2l0Y2hXaGVuLCBOZ1N3aXRjaERlZmF1bHQsIEFVVE9DT01QTEVURV9ESVJFQ1RJVkVTLCBDT1JFX0RJUkVDVElWRVMsIEZPUk1fRElSRUNUSVZFUywgQW1heERhdGVdLFxyXG4gICAgcHJvdmlkZXJzOiBbQ3VzdG9tZXJTZXJ2aWNlLCBSZXNvdXJjZVNlcnZpY2VdXHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgQW1heEN1c3RvbWVycyBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcbiAgICBtb2RlbElucHV0ID0ge307XHJcbiAgICBUZW1wbW9kZWxJbnB1dCA9IHt9O1xyXG4gICAgY3VzdFNlYXJjaERhdGE6IE9iamVjdCA9IFtdO1xyXG4gICAgUkVTOiBPYmplY3QgPSB7fTtcclxuICAgIFNlbGVjdGVkUGhUeXBlOiBPYmplY3QgPSB7fTtcclxuICAgIHRlbXBzdHJlZXRtc2c6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBGb3JtdHlwZTogc3RyaW5nID1cIkNVU1RPTUVSX01BU1RFUlwiO1xyXG4gICAgTGFuZzogc3RyaW5nPVwiXCI7XHJcbiAgICAvL21vZGVsSW5wdXQubG5hbWU9IFwiXCI7XHJcbiAgICBTaG93TW9yZTogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgSXNSZWNvcmRFZGl0TW9kZTogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgU2hvd01vcmVUZXh0OiBzdHJpbmcgPSBcIk1vcmVcIjtcclxuXHJcbiAgICBTaG93TG9hZGVyOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBTaG93TXNnOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBTaG93R3JvdXBzOiBib29sZWFuID0gdHJ1ZTtcclxuICAgIEdyb3VwVGV4dDogc3RyaW5nPVwiU2hvdyBHcm91cHNcIjtcclxuICAgIE1zZzogc3RyaW5nID0gXCJcIjtcclxuICAgIE1zZ0NsYXNzOiBzdHJpbmcgPSBcInRleHQtcHJpbWFyeVwiO1xyXG4gICAgSXNidG5kaXNhYmxlOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgSXNGaWxlQXNTYXZlQnRuOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgSXNGaWxlQXNDYW5jZWxCdG46IHN0cmluZyA9IFwiXCI7XHJcbiAgICBsYW5ndWFnZUFycmF5ID0gW107XHJcblxyXG4gICAgQWRkcmVzczogT2JqZWN0ID0ge307XHJcbiAgICBQaG9uZU1vZGVsOiBPYmplY3QgPSB7fTtcclxuICAgIEVtYWlsTW9kZWw6IE9iamVjdCA9IHt9O1xyXG4gICAgSXNTaG93QWxsOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBDdXN0TGlzdDogT2JqZWN0ID0ge307XHJcbiAgICBTQVZFX0JUTl9URVhUOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgXHJcbiAgICBCVE5fUEhBREQ6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBFZGl0UGhvbmVEYXRhOiBPYmplY3QgPSB7fTtcclxuICAgIEVkaXRBZGRyZXNzRGF0YTogT2JqZWN0ID0ge307XHJcbiAgICBFZGl0RW1haWxEYXRhOiBPYmplY3QgPSB7fTtcclxuICAgIGFkSWQ6IHN0cmluZztcclxuICAgIElzRmlsZUFzT3BlbjogYm9vbGVhbjtcclxuICAgIEFERF9ORVdfQ1VTVF9URVhUOiBzdHJpbmc7XHJcbiAgICBDU1NURVhUOiBzdHJpbmc7XHJcbiAgICBJc0ZpbGVBc3R4dFNob3c6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIEZJTEVBU19CVE5fVEVYVDogc3RyaW5nID0gXCJcIjtcclxuICAgIGNzc0ZpbGVBc0J0bjogc3RyaW5nID0gXCJcIjtcclxuICAgIElzQ2FuY2VsOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBTZWFyY2hWYWw6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBFbnRlckNvdW50OiBudW1iZXIgPSAwO1xyXG4gICAgU3RvcFRpbWVPdXQ6IGFueTtcclxuICAgIEN1c3RJZFRleHQ6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBzdGF0aWMgJGluamVjdCA9IFsnJHNjb3BlJywgJyRsb2NhdGlvbicsICckYW5jaG9yU2Nyb2xsJ107XHJcbiAgICBCYXNlQXBwVXJsOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgUGhJbmRleDogbnVtYmVyID0gMDtcclxuICAgIEtlbmRvUlRMQ1NTOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgQ0hBTkdFRElSOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgQ2hhbmdlRGlhbG9nOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgLy9Jc0ZpbGVBc1NhdmU6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIFxyXG4gICAgLy9FbWFpbDogc3RyaW5nID0gXCJcIjtcclxuICAgIC8vQ3VzdG9tZXJFbWFpbDogT2JqZWN0ID0ge307XHJcbiAgICAvL21vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMgPSBbXTtcclxuICAgIFxyXG4gICAgX0N1c3RUeXBlcyA9IFtdO1xyXG4gICAgX1NvdXJjZXMgPSBbXTtcclxuICAgIF9FbXBsb3llZXMgPSBbXTtcclxuICAgIF9TdWZmaXhlcyA9IFtdO1xyXG4gICAgX1Bob25lVHlwZXMgPSBbXTtcclxuICAgIF9BZGRyZXNzVHlwZXMgPSBbXTtcclxuICAgIF9Hcm91cHMgPSBbXTtcclxuICAgIF9Db3VudHJpZXMgPSBbXTtcclxuICAgIF9TdGF0ZXMgPSBbXTtcclxuICAgIF9DaXRpZXMgPSBbXTtcclxuXHJcbiAgICBwcml2YXRlIHNlbGVjdGVkQ2FyOiBzdHJpbmcgPSAnJztcclxuICAgIHByaXZhdGUgYXN5bmNTZWxlY3RlZENhcjogc3RyaW5nID0gJyc7XHJcbiAgICBwcml2YXRlIGF1dG9jb21wbGV0ZUxvYWRpbmc6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHByaXZhdGUgYXV0b2NvbXBsZXRlTm9SZXN1bHRzOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwcml2YXRlIGF1dG9jb21wbGV0ZVNlbGVjdDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgXHJcbiAgICBwcml2YXRlIGdldEN1cnJlbnRDb250ZXh0KCkge1xyXG4gICAgICAgIFxyXG4gICAgICAgIHJldHVybiB0aGlzO1xyXG4gICAgfVxyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBfcmVzb3VyY2VTZXJ2aWNlOiBSZXNvdXJjZVNlcnZpY2UsIHByaXZhdGUgX2N1c3RvbWVyU2VydmljZTogQ3VzdG9tZXJTZXJ2aWNlLCBwcml2YXRlIF9yb3V0ZVBhcmFtczogUm91dGVQYXJhbXMpIHtcclxuICAgICAgICBcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQmlydGhEYXRlID0gXCJcIjtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMgPSBbXTtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXMgPSBbXTtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMgPSBbXTtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJHcm91cHMgPSBbXTtcclxuICAgICAgICB0aGlzLkFkZHJlc3MuQ291bnRyeUNvZGU9XCJcIjtcclxuICAgICAgICB0aGlzLkFkZHJlc3MuU3RhdGVJZCA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LmVtcGxveWVlaWQgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclR5cGUgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DYW1lRnJvbUN1c3RvbWVyID0gXCJcIjtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuU2FmaXhpZCA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkdlbmRlciA9IFwiMFwiO1xyXG4gICAgICAgIHRoaXMuUGhvbmVNb2RlbC5QaG9uZVR5cGVJZCA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSID0ge307XHJcbiAgICAgICAgdGhpcy5Jc1Nob3dBbGwgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLlNBVkVfQlROX1RFWFQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0JUTl9TQVZFO1xyXG4gICAgICAgIHRoaXMuQlROX1BIQUREID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9CVE5fUEhBREQ7XHJcbiAgICAgICAgdGhpcy5BRERfTkVXX0NVU1RfVEVYVCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfTEJMX05FV19DVVNUO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlscyA9IFt7IEVtYWlsOiBcIlwiLCBFbWFpbE5hbWU6IFwiXCIsIE5ld3NsZXR0ZXJlOiB0cnVlLCBwdWJsaXNoOiAxLCBOZXdzT3JkZXI6IFwiTmV3czFcIiwgRVB1Ymxpc2hPcmRlcjpcIkVQdWIxXCIgfV1cclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXMgPSBbeyBQaG9uZVR5cGVJZDogXCJcIiwgUHJlZml4OiBcIlwiLCBBcmVhOiBcIlwiLCBQaG9uZTogXCJcIiwgSXNTbXM6IDEsIENvbW1lbnRzOiBcIlwiLCBJc1Nob3dSZW1hcmtzOiBmYWxzZSwgcGhwdWJsaXNoOiAxLCBTTVNPcmRlcjogXCJTTVMxXCIsUHVibGlzaE9yZGVyOiBcIlB1YjFcIn1dXHJcbiAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICB2YXIgZW1waWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImVtcGxveWVlaWRcIik7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdmFyIGNjb2RlID0gdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmdldENvb2tpZShlbXBpZCArIFwiY2NvZGVcIik7XHJcbiAgICAgICAgaWYgKGNjb2RlLmxlbmd0aCA+IDApXHJcbiAgICAgICAgICAgIGNjb2RlID0gY2NvZGUuc3Vic3RyaW5nKDEsIGNjb2RlLmxlbmd0aCk7XHJcblxyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3NlcyA9IFt7XHJcbiAgICAgICAgICAgIFN0cmVldDogXCJcIiwgU3RyZWV0MjogXCJcIiwgQ2l0eU5hbWU6IFwiXCIsIFppcDogXCJcIiwgQ291bnRyeUNvZGU6IGNjb2RlLCBTdGF0ZUlkOiBcIlwiLCBBZGRyZXNzVHlwZUlkOiBcIlwiLFxyXG4gICAgICAgICAgICBGb3JEZWxpdmVyeTogdHJ1ZSwgTWFpbkFkZHJlc3M6IHRydWUsIE1haW5PcmRlcjogXCJNYWluQWRkcjFcIiwgRGVsdnJ5T3JkZXI6IFwiRGVsdnJ5MVwiXHJcbiAgICAgICAgfV1cclxuXHJcbiAgICAgICAgXHJcbiAgICAgICAgXHJcblxyXG4gICAgICAgIHZhciBjdXN0dHlwZSA9IHRoaXMuX3Jlc291cmNlU2VydmljZS5nZXRDb29raWUoZW1waWQgKyBcImN1c3RcIik7XHJcbiAgICAgICAgaWYgKGN1c3R0eXBlLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIGN1c3R0eXBlID0gY3VzdHR5cGUuc3Vic3RyaW5nKDEsIGN1c3R0eXBlLmxlbmd0aCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclR5cGUgPSBjdXN0dHlwZTtcclxuXHJcblxyXG4gICAgICAgIHZhciBlbXAgPSB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZ2V0Q29va2llKGVtcGlkICsgXCJlbXBcIik7XHJcbiAgICAgICAgaWYgKGVtcC5sZW5ndGggPiAwKVxyXG4gICAgICAgICAgICBlbXAgPSBlbXAuc3Vic3RyaW5nKDEsIGVtcC5sZW5ndGgpO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5lbXBsb3llZWlkID0gZW1wO1xyXG5cclxuICAgICAgICB2YXIgc291cmNlID0gdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmdldENvb2tpZShlbXBpZCArIFwic3JjXCIpO1xyXG4gICAgICAgIGlmIChzb3VyY2UubGVuZ3RoID4gMClcclxuICAgICAgICAgICAgc291cmNlID0gc291cmNlLnN1YnN0cmluZygxLCBzb3VyY2UubGVuZ3RoKTtcclxuICAgICAgICBlbHNlIHtcclxuXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DYW1lRnJvbUN1c3RvbWVyID0gc291cmNlO1xyXG4gICAgICAgIHRoaXMuQ1NTVEVYVCA9IFwibWRpLWNvbnRlbnQtYWRkXCI7XHJcbiAgICAgICAgdGhpcy5jc3NGaWxlQXNCdG4gPSBcIm1kaS1jb250ZW50LWNyZWF0ZVwiO1xyXG4gICAgICAgIHRoaXMuSXNGaWxlQXN0eHRTaG93ID0gZmFsc2U7XHJcbiAgICAgICAgY2xlYXJUaW1lb3V0KHRoaXMuU3RvcFRpbWVPdXQpO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkID0gX3JvdXRlUGFyYW1zLnBhcmFtcy5JZDtcclxuICAgICAgICB0aGlzLkJhc2VBcHBVcmwgPSBfcmVzb3VyY2VTZXJ2aWNlLkFwcFVybDtcclxuICAgICAgICB0aGlzLlRlbXBtb2RlbElucHV0ID0gdGhpcy5tb2RlbElucHV0O1xyXG4gICAgICAgIFxyXG4gICAgICAgIC8vYWxlcnQodGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmdldENvb2tpZShlbXBpZCArIFwiY3VzdFwiKSk7XHJcbiAgICAgICAgLy90aGlzLlNob3dNb3JlVGV4dCA9IFwiTW9yZVwiO1xyXG4gICAgICAgIFxyXG4gICAgfVxyXG4gICAgcHJpdmF0ZSBfY2FjaGVkUmVzdWx0OiBhbnk7XHJcbiAgICBwcml2YXRlIF9wcmV2aW91c2FzeW5jU2VsZWN0ZWRDYXI6IHN0cmluZz0nJztcclxuICAgIFxyXG4gICAgZGF0ZVNlbGVjdGlvbkNoYW5nZShldnQpIHtcclxuICAgICAgICBjb25zb2xlLmxvZyhldnQpO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5CaXJ0aERhdGUgPSBldnQ7XHJcbiAgICAgICAvLyBhbGVydCh0aGlzLm1vZGVsSW5wdXQuQmlydGhEYXRlKTtcclxuICAgICAgICAvL3RoaXMudmFsaWRhdGVMb2dpbigpO1xyXG4gICAgfVxuXHJcbiAgIHByaXZhdGUgZ2V0QXN5bmNEYXRhKGNvbnRleHQ6IGFueSk6IEZ1bmN0aW9uIHtcclxuICAgICAgICBcclxuICAgICAgIHZhciBTcmNoVmFsID0gY29udGV4dC5hc3luY1NlbGVjdGVkQ2FyO1xyXG4gICAgICBcclxuICAgICAgLy8gaWYgKFNyY2hWYWwgIT0gdW5kZWZpbmVkICYmIFNyY2hWYWwgIT0gbnVsbCAmJiBTcmNoVmFsICE9IFwiXCIpIHtcclxuXHJcbiAgICAgICBcclxuICAgICAgICAgIC8vIGRlYnVnZ2VyO1xyXG4gICAgICAgaWYgKHRoaXMuX3ByZXZpb3VzYXN5bmNTZWxlY3RlZENhciA9PSBjb250ZXh0LmFzeW5jU2VsZWN0ZWRDYXIpIHtcclxuICAgICAgICAgICAgICAgLy9jbGVhclRpbWVvdXQodGhpcy5TdG9wVGltZU91dCk7XHJcbiAgICAgICAgICAgICAgIHJldHVybiB0aGlzLl9jYWNoZWRSZXN1bHQ7XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgLy9hbGVydCh0aGlzLl9wcmV2aW91c2FzeW5jU2VsZWN0ZWRDYXIgKyBcIiB8IFwiICsgY29udGV4dC5hc3luY1NlbGVjdGVkQ2FyKTtcclxuICAgICAgICAgICAgICAgaWYgKGNvbnRleHQuYXN5bmNTZWxlY3RlZENhciAhPSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICB0aGlzLl9wcmV2aW91c2FzeW5jU2VsZWN0ZWRDYXIgPSBjb250ZXh0LmFzeW5jU2VsZWN0ZWRDYXI7XHJcbiAgICAgICAgICAgICAgICAgLy8gIHRoaXMuU3RvcFRpbWVPdXQgPSBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgIC8vICAgIGFsZXJ0KFNyY2hWYWwpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRDb21wbGV0ZVNlYXJjaChTcmNoVmFsKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vYWxlcnQocmVzcG9uc2UuRXJyTXNnKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe21lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRleHQuY2Fyc0V4YW1wbGUxID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vcmV0dXJuIGNvbnRleHQuY2Fyc0V4YW1wbGUxO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgLy8gfSwgNTAwKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICB0aGlzLl9jYWNoZWRSZXN1bHQgPSBjb250ZXh0LmNhcnNFeGFtcGxlMTtcclxuICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgIHRoaXMuX2NhY2hlZFJlc3VsdCA9IFtdO1xyXG4gICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgIHJldHVybiB0aGlzLl9jYWNoZWRSZXN1bHQ7XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgICAgIFxyXG4gICAgICAgIFxyXG4gICAgfVxyXG4gICBcclxuICAgIHByaXZhdGUgY2hhbmdlQXV0b2NvbXBsZXRlTG9hZGluZyhlOiBib29sZWFuKSB7XHJcbiAgICAgICAgdGhpcy5hdXRvY29tcGxldGVMb2FkaW5nID0gZTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIGNoYW5nZUF1dG9jb21wbGV0ZU5vUmVzdWx0cyhlOiBib29sZWFuKSB7XHJcbiAgICAgICAgdGhpcy5hdXRvY29tcGxldGVTZWxlY3QgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLmF1dG9jb21wbGV0ZU5vUmVzdWx0cyA9IGU7XHJcbiAgICB9XHJcbiAgICBwcml2YXRlIGF1dG9jb21wbGV0ZU9uU2VsZWN0KGU6IGFueSkge1xyXG4gICAgICAgIHRoaXMuYXV0b2NvbXBsZXRlU2VsZWN0ID0gdHJ1ZTtcclxuICAgICAgICBjb25zb2xlLmxvZyhgU2VsZWN0ZWQgdmFsdWU6ICR7ZS5pdGVtfWApO1xyXG4gICAgICAgIHZhciBDb21wRGF0YSA9IGUuaXRlbS5zcGxpdCgnfCcpO1xyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgaWYgKGUuaXRlbSAhPSB1bmRlZmluZWQgJiYgZS5pdGVtICE9IFwiXCIgJiYgZS5pdGVtICE9IG51bGwpIHtcclxuICAgICAgICAgICAgLy9hbGVydChDb21wRGF0YVswXSk7XHJcbiAgICAgICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRDb21wbGV0ZUN1c3REZXQoQ29tcERhdGFbMF0udHJpbSgpKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAvL2FsZXJ0KHJlc3BvbnNlLkVyck1zZyk7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7bWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgICAgLy8gYWxlcnQodGhpcy5tb2RlbElucHV0LkJpcnRoRGF0ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5TQVZFX0JUTl9URVhUID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9CVE5fVVBEQVRFO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuQUREX05FV19DVVNUX1RFWFQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0xCTF9VUERBVEVfQ1VTVDtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLkNTU1RFWFQgPSBcIm1kaS1jb250ZW50LWNyZWF0ZVwiO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMubGVuZ3RoID09IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzID0gW3sgRW1haWw6IFwiXCIsIEVtYWlsTmFtZTogdGhpcy5tb2RlbElucHV0LkZpbGVBcywgTmV3c2xldHRlcmU6IGZhbHNlIH1dXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXMubGVuZ3RoID09IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHBoaWQgPSBcIlwiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLl9QaG9uZVR5cGVzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5UZXh0ID09IFwiQ2VsbFBob25lXCIpIHtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGhpZCA9IHRoaXMuVmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lcyA9IFt7IFBob25lVHlwZUlkOiBwaGlkLCBQcmVmaXg6IFwiXCIsIEFyZWE6IFwiXCIsIFBob25lOiBcIlwiLCBJc1NtczogMCwgQ29tbWVudHM6IFwiXCIsIHBocHVibGlzaDogMCB9XTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMubGVuZ3RoID09IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGVtcGlkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJlbXBsb3llZWlkXCIpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGNjb2RlID0gdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmdldENvb2tpZShlbXBpZCArIFwiY2NvZGVcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChjY29kZS5sZW5ndGggPiAwKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2NvZGUgPSBjY29kZS5zdWJzdHJpbmcoMSwgY2NvZGUubGVuZ3RoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGFkaWQgPSBcIlwiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgY29tcHRleHQgPSBcIkhvbWVcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5Db21wYW55ICE9IFwiXCIgJiYgdGhpcy5tb2RlbElucHV0LkNvbXBhbnkgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dC5Db21wYW55ICE9IG51bGwpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbXB0ZXh0ID0gXCJXb3JrXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5fQWRkcmVzc1R5cGVzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5UZXh0ID09IGNvbXB0ZXh0KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWRpZCA9IHRoaXMuVmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3NlcyA9IFt7IFN0cmVldDogXCJcIiwgU3RyZWV0MjogXCJcIiwgQ2l0eU5hbWU6IFwiXCIsIFppcDogXCJcIiwgQ291bnRyeUNvZGU6IGNjb2RlLCBTdGF0ZUlkOiBcIlwiLCBBZGRyZXNzVHlwZUlkOiBhZGlkLCBGb3JEZWxpdmVyeTogZmFsc2UsIE1haW5BZGRyZXNzOiBmYWxzZSB9XTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuQ3VzdElkVGV4dCA9IFwiKCBcIiArIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkICsgXCIgKVwiO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuSXNGaWxlQXN0eHRTaG93ID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgLy90aGlzLklzQ2FuY2VsID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICAvL3RoaXMuSGlkZVNob3dGaWxlQXN0eHQoKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLkNhbmNlbEZpbGVBc3R4dCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuSXNTaG93QWxsID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICAvL3RoaXMuYmluZEdyb3VwKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9hbGVydCh0aGlzLlJFUyk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5iaW5kR3JvdXBUcmVlKHRydWUpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIE9wZW5OZXdSZWNlaXB0KCkge1xyXG4gICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkICE9IHVuZGVmaW5lZCAmJiB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCA+PSAwKSB7XHJcbiAgICAgICAgICAgIHZhciBjdXN0SWQgPSB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZDtcclxuICAgICAgICAgICAgaWYgKGN1c3RJZCAhPSAtMSkge1xyXG4gICAgICAgICAgICAgICAgdmFyIGVtaWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImVtcGxveWVlaWRcIik7XHJcbiAgICAgICAgICAgICAgICBkb2N1bWVudC5sb2NhdGlvbiA9IHRoaXMuQmFzZUFwcFVybCArIFwiUmVjZWlwdFNlbGVjdC9cIiArIGVtaWQgKyBcIi9cIiArIGN1c3RJZDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIE9wZW5DaGFyZ2VDcmVkaXRQYWdlKCkge1xyXG4gICAgICAgIHRoaXMuSXNidG5kaXNhYmxlID0gXCJkaXNhYmxlZFwiO1xyXG4gICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5DaGVja0lzT3BlbkNoYXJnZSgpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2cocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICBcclxuXHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZywgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7ICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSB9fSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLkRhdGEgIT0gdW5kZWZpbmVkICYmIHJlc3BvbnNlLkRhdGEgIT0gbnVsbCAmJiByZXNwb25zZS5EYXRhLmxlbmd0aCA9PSAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIGN1c3RJZCA9IC0xO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLlRlbXBtb2RlbElucHV0ICE9IHVuZGVmaW5lZCAmJiB0aGlzLlRlbXBtb2RlbElucHV0LkN1c3RvbWVySWQgIT0gdW5kZWZpbmVkICYmIHRoaXMuVGVtcG1vZGVsSW5wdXQuQ3VzdG9tZXJJZCA+PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGN1c3RJZCA9IHRoaXMuVGVtcG1vZGVsSW5wdXQuQ3VzdG9tZXJJZFxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0ICE9IHVuZGVmaW5lZCAmJiB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQgPj0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjdXN0SWQgPSB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZFxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAoY3VzdElkICE9IC0xKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRvY3VtZW50LmxvY2F0aW9uID0gdGhpcy5CYXNlQXBwVXJsICsgXCJDaGFyZ2VDcmVkaXQvXCIgKyBjdXN0SWQgKyBcIi9cIiArIHJlc3BvbnNlLkRhdGFbMF0uVmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiAnUGxlYXNlIHNhdmUgbmV3IG9yIGxvYWQgcHJldmlvdXMgY3VzdG9tZXIgYW5kIHRoZW4gY2xpY2sgb24gY2hhcmdlIGNyZWRpdCBidXR0b24nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKHJlc3BvbnNlLkRhdGEgIT0gdW5kZWZpbmVkICYmIHJlc3BvbnNlLkRhdGEgIT0gbnVsbCAmJiByZXNwb25zZS5EYXRhLmxlbmd0aCA+IDEpIHtcclxuICAgICAgICAgICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBjdXN0SWQgPSAtMTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5UZW1wbW9kZWxJbnB1dCAhPSB1bmRlZmluZWQgJiYgdGhpcy5UZW1wbW9kZWxJbnB1dC5DdXN0b21lcklkICE9IHVuZGVmaW5lZCAmJiB0aGlzLlRlbXBtb2RlbElucHV0LkN1c3RvbWVySWQgPj0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjdXN0SWQgPSB0aGlzLlRlbXBtb2RlbElucHV0LkN1c3RvbWVySWRcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dCAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkID49IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY3VzdElkID0gdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWRcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGN1c3RJZCAhPSAtMSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBkb2N1bWVudC5sb2NhdGlvbiA9IHRoaXMuQmFzZUFwcFVybCArIFwiVGVybWluYWxzL1Nob3cvXCIgKyBjdXN0SWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6ICdQbGVhc2Ugc2F2ZSBuZXcgb3IgbG9hZCBwcmV2aW91cyBjdXN0b21lciBhbmQgdGhlbiBjbGljayBvbiBjaGFyZ2UgY3JlZGl0IGJ1dHRvbicsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgIC8vIGFsZXJ0KHJlc3BvbnNlLkRhdGEubGVuZ3RoICsgJyBUZXJtaW5hbCBTY3JlZW4gaGVsbG8nKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX01TR19DSEFSR0VDUkVESVQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRoaXMuU2hvd01zZyA9IHRydWU7XHJcbiAgICAgICAgICAgIHRoaXMuTXNnID0gcmVzcG9uc2UuRXJyTXNnO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgICAgIGVycm9yPT4gY29uc29sZS5sb2coZXJyb3IpLFxyXG4gICAgICAgICAgICAoKSA9PiBjb25zb2xlLmxvZyhcIlNhdmUgQ2FsbCBDb21wbGVhdGVkXCIpXHJcbiAgICAgICAgKTtcclxuICAgICAgICB0aGlzLklzYnRuZGlzYWJsZSA9IFwiXCI7XHJcbiAgICB9XHJcbiAgICBTdG9wVGltZXIoKTogb2JzZXJ2YWJsZSB7XHJcbiAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgIG1lc3NhZ2U6ICdGcm9tIFN0b3AgVGltZXInICsgdGhpcy5TdG9wVGltZU91dCwgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGNsZWFyVGltZW91dCh0aGlzLlN0b3BUaW1lT3V0KTtcclxuICAgIH1cclxuICAgIFNldGRlZmF1bHRQYWdlKCl7XHJcbiAgICAgICAgZG9jdW1lbnQubG9jYXRpb24gPSB0aGlzLkJhc2VBcHBVcmwgKyBcIkN1c3RvbWVyL0FkZC8tMVwiO1xyXG4gICAgICAgIHRoaXMuSXNGaWxlQXN0eHRTaG93ID0gdHJ1ZTtcclxuICAgICAgICB0aGlzLklzQ2FuY2VsID0gdHJ1ZTtcclxuICAgICAgICBcclxuICAgICAgICB2YXIgZW1waWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImVtcGxveWVlaWRcIik7XHJcbiAgICAgICAgdGhpcy5hc3luY1NlbGVjdGVkQ2FyID0gXCJcIjtcclxuICAgICAgICBcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQgPSB7fTtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQmlydGhEYXRlID0gXCJcIjtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCA9IC0xO1xyXG4gICAgICAgIHRoaXMuQ3VzdElkVGV4dCA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5IaWRlU2hvd0ZpbGVBc3R4dCgpO1xyXG4gICAgICAgIHZhciBjdXN0dHlwZSA9IHRoaXMuX3Jlc291cmNlU2VydmljZS5nZXRDb29raWUoZW1waWQgKyBcImN1c3RcIik7XHJcbiAgICAgICAgaWYgKGN1c3R0eXBlLmxlbmd0aCA+IDApXHJcbiAgICAgICAgICAgIGN1c3R0eXBlID0gY3VzdHR5cGUuc3Vic3RyaW5nKDEsIGN1c3R0eXBlLmxlbmd0aCk7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyVHlwZSA9IGN1c3R0eXBlO1xyXG4gICAgICAgIHZhciBlbXAgPSB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZ2V0Q29va2llKGVtcGlkICsgXCJlbXBcIik7XHJcbiAgICAgICAgaWYgKGVtcC5sZW5ndGggPiAwKVxyXG4gICAgICAgICAgICBlbXAgPSBlbXAuc3Vic3RyaW5nKDEsIGVtcC5sZW5ndGgpO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5lbXBsb3llZWlkID0gZW1wO1xyXG4gICAgICAgIHZhciBzb3VyY2UgPSB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZ2V0Q29va2llKGVtcGlkICsgXCJzcmNcIik7XHJcbiAgICAgICAgaWYgKHNvdXJjZS5sZW5ndGggPiAwKVxyXG4gICAgICAgICAgICBzb3VyY2UgPSBzb3VyY2Uuc3Vic3RyaW5nKDEsIHNvdXJjZS5sZW5ndGgpO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DYW1lRnJvbUN1c3RvbWVyID0gc291cmNlO1xyXG5cclxuICAgICAgICB0aGlzLlNob3dNb3JlID0gZmFsc2U7XHJcbiAgICAgICAgLy90aGlzLlNob3dNb3JlVGV4dCA9IFwiTW9yZVwiOyBcclxuICAgICAgICB0aGlzLlNob3dNb3JlVGV4dCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfTE5LX0xCTF9NT1JFO1xyXG4gICAgICAgIHRoaXMuU0FWRV9CVE5fVEVYVCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfQlROX1NBVkU7XHJcbiAgICAgICAgdGhpcy5DU1NURVhUID0gXCJtZGktY29udGVudC1hZGRcIjtcclxuICAgICAgICB0aGlzLkFERF9ORVdfQ1VTVF9URVhUID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9MQkxfTkVXX0NVU1Q7XHJcbiAgICAgICAgdGhpcy5TaG93R3JvdXBzID0gdHJ1ZTtcclxuICAgICAgICB0aGlzLnNob3doaWRlR3JvdXBzKCk7XHJcbiAgICAgICAgLy90aGlzLkdyb3VwVGV4dCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfTEJMX1NIT1dHUk9VUFM7XHJcblxyXG4gICAgICAgIFxyXG5cclxuICAgICAgICB2YXIgcGhpZCA9IFwiXCI7XHJcbiAgICAgICAgdmFyIFNNUyA9IDA7XHJcbiAgICAgICAgdmFyIHB1Ymxpc2ggPSAwO1xyXG4gICAgICAgIHZhciBlcHVibGlzaCA9IDA7XHJcbiAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5fUGhvbmVUeXBlcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5UZXh0ID09IFwiQ2VsbFBob25lXCIpIHtcclxuXHJcbiAgICAgICAgICAgICAgICBwaGlkID0gdGhpcy5WYWx1ZTtcclxuICAgICAgICAgICAgICAgIFNNUyA9IDE7XHJcbiAgICAgICAgICAgICAgICBwdWJsaXNoID0gMTtcclxuICAgICAgICAgICAgICAgIGVwdWJsaXNoID0gMTtcclxuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXMgPSBbeyBQaG9uZVR5cGVJZDogcGhpZCwgUHJlZml4OiBcIlwiLCBBcmVhOiBcIlwiLCBQaG9uZTogXCJcIiwgSXNTbXM6IFNNUywgQ29tbWVudHM6IFwiXCIsIHBocHVibGlzaDogcHVibGlzaCB9XVxyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcblxyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlscyA9IFt7IEVtYWlsOiBcIlwiLCBFbWFpbE5hbWU6IFwiXCIsIE5ld3NsZXR0ZXJlOiBmYWxzZSwgcHVibGlzaDogZXB1Ymxpc2ggfV1cclxuICAgICAgICB2YXIgY250cnljb2RlID0gdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmdldENvb2tpZShlbXBpZCArIFwiY2NvZGVcIik7XHJcbiAgICAgICAgaWYgKGNudHJ5Y29kZS5sZW5ndGggPiAwKVxyXG4gICAgICAgICAgICBjbnRyeWNvZGUgPSBjbnRyeWNvZGUuc3Vic3RyaW5nKDEsIGNudHJ5Y29kZS5sZW5ndGgpO1xyXG5cclxuICAgICAgICB2YXIgYWRpZCA9IFwiXCI7XHJcbiAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5fQWRkcmVzc1R5cGVzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLlRleHQgPT0gXCJIb21lXCIpIHtcclxuXHJcbiAgICAgICAgICAgICAgICBhZGlkID0gdGhpcy5WYWx1ZTtcclxuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICB9KTtcclxuXHJcblxyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3NlcyA9IFt7IFN0cmVldDogXCJcIiwgU3RyZWV0MjogXCJcIiwgQ2l0eU5hbWU6IFwiXCIsIFppcDogXCJcIiwgQ291bnRyeUNvZGU6IGNudHJ5Y29kZSwgU3RhdGVJZDogXCJcIiwgQWRkcmVzc1R5cGVJZDogYWRpZCwgRm9yRGVsaXZlcnk6IGZhbHNlLCBNYWluQWRkcmVzczogZmFsc2UgfV1cclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJHcm91cHMgPSBbXTtcclxuICAgICAgICB0aGlzLkFkZHJlc3MuQ291bnRyeUNvZGUgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMuQWRkcmVzcy5TdGF0ZUlkID0gXCJcIjtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuU2FmaXhpZCA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkdlbmRlciA9IFwiMFwiO1xyXG4gICAgICAgIHRoaXMuU2hvd01zZyA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMuTXNnID0gXCJcIjtcclxuICAgICAgICB0aGlzLklzU2hvd0FsbCA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRHZW5lcmFsR3JvdXBzKHRoaXMuSXNTaG93QWxsKS5zdWJzY3JpYmUoXHJcbiAgICAgICAgICAgIChkYXRhKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLklzU2hvd0FsbCA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeShcIiNncm91cFRyZWVcIikuaHRtbChcIkxvZGluZy4uLlwiKTtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgcmVzID0galF1ZXJ5LnBhcnNlSlNPTihkYXRhKS5EYXRhXHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5KFwiI2dyb3VwVHJlZVwiKS5rZW5kb1RyZWVWaWV3KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbG9hZE9uRGVtYW5kOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjaGVja2JveGVzOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja0NoaWxkcmVuOiB0cnVlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vY2hlY2s6IHRoaXMub25Hcm91cFNlbGVjdCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGF0YVNvdXJjZTogcmVzXHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkoXCIjZ3JvdXBUcmVlMVwiKS5odG1sKFwiTG9kaW5nLi4uXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciByZXMgPSBqUXVlcnkucGFyc2VKU09OKGRhdGEpLkRhdGFcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkoXCIjZ3JvdXBUcmVlMVwiKS5rZW5kb1RyZWVWaWV3KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbG9hZE9uRGVtYW5kOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjaGVja2JveGVzOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja0NoaWxkcmVuOiB0cnVlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vY2hlY2s6IHRoaXMub25Hcm91cFNlbGVjdCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGF0YVNvdXJjZTogcmVzXHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIChlcnIpID0+IHtcclxuXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICgpID0+IHtcclxuXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICApO1xyXG4gICAgfVxyXG4gICAgQ2FuY2VsRmlsZUFzdHh0KCkge1xyXG4gICAgICAgIHRoaXMuSXNGaWxlQXN0eHRTaG93ID0gdHJ1ZTtcclxuICAgICAgICB0aGlzLklzRmlsZUFzdHh0U2hvdyA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMuSXNDYW5jZWwgPSB0cnVlO1xyXG4gICAgICAgIGpRdWVyeShcIiNGaWxlQXN0eHRcIikuaGlkZSgpO1xyXG4gICAgICAgIGpRdWVyeShcIiNGaWxlQXNTcG5cIikuc2hvdygpO1xyXG4gICAgICAgIHRoaXMuRklMRUFTX0JUTl9URVhUID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9CVE5fRklMRUFTO1xyXG4gICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQgIT0gbnVsbCAmJiBwYXJzZUludCggdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQpID4tMSkge1xyXG4gICAgICAgICAgICBqUXVlcnkoXCIjRmlsZUFzU2F2ZUJ0blwiKS5zaG93KCk7XHJcbiAgICAgICAgICAgIHRoaXMuY3NzRmlsZUFzQnRuID0gXCJtZGktY29udGVudC1jcmVhdGVcIjtcclxuICAgICAgICAgICAgalF1ZXJ5KFwiI0ZpbGVBc0NhbmNlbEJ0blwiKS5oaWRlKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBqUXVlcnkoXCIjRmlsZUFzU2F2ZUJ0blwiKS5oaWRlKCk7XHJcbiAgICAgICAgICAgIGpRdWVyeShcIiNGaWxlQXNDYW5jZWxCdG5cIikuaGlkZSgpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIFxyXG4gICAgSGlkZVNob3dGaWxlQXN0eHQoKTogb2JzZXJ2YWJsZSB7XHJcbiAgICAgICBcclxuICAgICAgICBpZiAodGhpcy5Jc0ZpbGVBc3R4dFNob3cgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgdGhpcy5Jc0ZpbGVBc3R4dFNob3cgPSB0cnVlO1xyXG4gICAgICAgICAgICBqUXVlcnkoXCIjRmlsZUFzdHh0XCIpLnNob3coKTtcclxuICAgICAgICAgICAgalF1ZXJ5KFwiI0ZpbGVBc1NwblwiKS5oaWRlKCk7XHJcbiAgICAgICAgICAgIHRoaXMuSXNDYW5jZWwgPSBmYWxzZTtcclxuICAgICAgICAgICAgdGhpcy5GSUxFQVNfQlROX1RFWFQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0JUTl9TQVZFRklMRUFTO1xyXG4gICAgICAgICAgIC8vIGFsZXJ0KHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkKTtcclxuICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkICE9IHVuZGVmaW5lZCAmJiB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCAhPSBudWxsICYmIHBhcnNlSW50KCB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCkgPi0xKSB7XHJcbiAgICAgICAgICAgICAgICBqUXVlcnkoXCIjRmlsZUFzU2F2ZUJ0blwiKS5zaG93KCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNzc0ZpbGVBc0J0biA9IFwibWRpLWNvbnRlbnQtc2F2ZVwiO1xyXG4gICAgICAgICAgICAgICAgalF1ZXJ5KFwiI0ZpbGVBc0NhbmNlbEJ0blwiKS5zaG93KCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBqUXVlcnkoXCIjRmlsZUFzU2F2ZUJ0blwiKS5oaWRlKCk7XHJcbiAgICAgICAgICAgICAgICBqUXVlcnkoXCIjRmlsZUFzQ2FuY2VsQnRuXCIpLmhpZGUoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5Jc0ZpbGVBc3R4dFNob3cgPSBmYWxzZTtcclxuICAgICAgICAgICAgalF1ZXJ5KFwiI0ZpbGVBc3R4dFwiKS5oaWRlKCk7XHJcbiAgICAgICAgICAgIGpRdWVyeShcIiNGaWxlQXNTcG5cIikuc2hvdygpO1xyXG4gICAgICAgICAgICB0aGlzLkZJTEVBU19CVE5fVEVYVCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfQlROX0ZJTEVBUztcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQgIT0gbnVsbCAmJiBwYXJzZUludCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCk+LTEpIHtcclxuICAgICAgICAgICAgICAgIGpRdWVyeShcIiNGaWxlQXNTYXZlQnRuXCIpLnNob3coKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuY3NzRmlsZUFzQnRuID0gXCJtZGktY29udGVudC1jcmVhdGVcIjtcclxuICAgICAgICAgICAgICAgIGpRdWVyeShcIiNGaWxlQXNDYW5jZWxCdG5cIikuaGlkZSgpO1xyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkZpbGVBcyAhPSBcIlwiICYmIHRoaXMubW9kZWxJbnB1dC5GaWxlQXMgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dC5GaWxlQXMgIT0gbnVsbCAmJiB0aGlzLklzQ2FuY2VsID09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLlNhdmVGaWxlQXModGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQsIHRoaXMubW9kZWxJbnB1dC5GaWxlQXMpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9hbGVydCgnaGVsbG8nKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9hbGVydChyZXNwb25zZS5FcnJNc2cpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL3RoaXMuSXNGaWxlQXNTYXZlID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLklzQ2FuY2VsID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vZWxzZSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL31cclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0VNUFRZRklMRUFTLCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5iaW5kRmlsZUFzKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5Jc0ZpbGVBc3R4dFNob3cgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLkhpZGVTaG93RmlsZUFzdHh0KCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBqUXVlcnkoXCIjRmlsZUFzU2F2ZUJ0blwiKS5oaWRlKCk7XHJcbiAgICAgICAgICAgICAgICBqUXVlcnkoXCIjRmlsZUFzQ2FuY2VsQnRuXCIpLmhpZGUoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgIH1cclxuICAgIFNldEVtYWlsTmFtZSgpOiBvYnNlcnZhYmxlIHtcclxuICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkZpbGVBcyAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0LkZpbGVBcyAhPSBudWxsKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzW3RoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlscy5sZW5ndGggLSAxXS5FbWFpbE5hbWUgPSB0aGlzLm1vZGVsSW5wdXQuRmlsZUFzO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgQ2hlY2tDdXN0V2l0aFNhbWVOYW1lKCk6IG9ic2VydmFibGUge1xyXG5cclxuICAgIH1cclxuICAgIFNldERlZmF1bHRDdXN0KCkge1xyXG4gICAgICAgIC8vYWxlcnQoKTtcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG5cclxuICAgIH1cclxuXHJcbiAgICBzZXRkZWZhdWx0QWRkcmVzcygpIHtcclxuICAgICAgICBcclxuICAgICAgICB0aGlzLmJpbmRGaWxlQXMoKTtcclxuICAgICAgICB0aGlzLkNoZWNrQ3VzdFdpdGhmbmFtZWxuYW1lY29tcHBoc2VtYWlscygpO1xyXG4gICAgICAgIHZhciBhZGlkID0gXCJcIjtcclxuICAgICAgICB2YXIgYWR0ZXh0ID0gXCJIb21lXCI7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ29tcGFueSAhPSBcIlwiICYmIHRoaXMubW9kZWxJbnB1dC5Db21wYW55ICE9IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICBhZHRleHQgPSBcIldvcmtcIjtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGpRdWVyeS5lYWNoKHRoaXMuX0FkZHJlc3NUeXBlcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5UZXh0ID09IGFkdGV4dCkge1xyXG4gICAgICAgICAgICAgICAgYWRpZCA9IHRoaXMuVmFsdWU7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzW3RoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3Nlcy5sZW5ndGggLSAxXS5BZGRyZXNzVHlwZUlkID0gYWRpZDtcclxuICAgIH1cclxuICAgIGJpbmRGaWxlQXMoKTogb2JzZXJ2YWJsZSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5GaWxlQXMgPT0gXCJcIiB8fCB0aGlzLm1vZGVsSW5wdXQuRmlsZUFzID09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICBpZiAoKHRoaXMubW9kZWxJbnB1dC5Db21wYW55ID09IFwiXCIgfHwgdGhpcy5tb2RlbElucHV0LkNvbXBhbnkgPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgICAgICB2YXIgZmlsZWFzdGV4dCA9IFwiXCI7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LmZuYW1lICE9IFwiXCIgJiYgdGhpcy5tb2RlbElucHV0LmZuYW1lICE9IHVuZGVmaW5lZCAmJiB0aGlzLm1vZGVsSW5wdXQubG5hbWUgIT0gXCJcIiAmJiB0aGlzLm1vZGVsSW5wdXQubG5hbWUgIT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZmlsZWFzdGV4dCA9IHRoaXMubW9kZWxJbnB1dC5sbmFtZSArIFwiIFwiICsgdGhpcy5tb2RlbElucHV0LmZuYW1lO1xyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSBpZiAodGhpcy5tb2RlbElucHV0LmZuYW1lICE9IFwiXCIgJiYgdGhpcy5tb2RlbElucHV0LmZuYW1lICE9IHVuZGVmaW5lZCAmJiAodGhpcy5tb2RlbElucHV0LmxuYW1lID09IFwiXCIgfHwgdGhpcy5tb2RlbElucHV0LmxuYW1lID09IHVuZGVmaW5lZCkpIHtcclxuICAgICAgICAgICAgICAgICAgICBmaWxlYXN0ZXh0ID0gXCIgXCIgKyB0aGlzLm1vZGVsSW5wdXQuZm5hbWU7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIGlmICgodGhpcy5tb2RlbElucHV0LmZuYW1lID09IFwiXCIgfHwgdGhpcy5tb2RlbElucHV0LmZuYW1lID09IHVuZGVmaW5lZCkgJiYgKHRoaXMubW9kZWxJbnB1dC5sbmFtZSAhPSBcIlwiICYmIHRoaXMubW9kZWxJbnB1dC5sbmFtZSAhPSB1bmRlZmluZWQpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZmlsZWFzdGV4dCA9IHRoaXMubW9kZWxJbnB1dC5sbmFtZSArIFwiIFwiO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkZpbGVBcyA9IGZpbGVhc3RleHQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSBpZiAoKHRoaXMubW9kZWxJbnB1dC5sbmFtZSA9PSBcIlwiIHx8IHRoaXMubW9kZWxJbnB1dC5sbmFtZSA9PSB1bmRlZmluZWQpICYmICh0aGlzLm1vZGVsSW5wdXQuZm5hbWUgPT0gXCJcIiB8fCB0aGlzLm1vZGVsSW5wdXQubG5hbWUgPT0gdW5kZWZpbmVkKSkge1xyXG4gICAgICAgICAgICAgICAgdmFyIGZpbGVhc3RleHQgPSBcIlwiO1xyXG4gICAgICAgICAgICAgICAgaWYgKCh0aGlzLm1vZGVsSW5wdXQuQ29tcGFueSAhPSBcIlwiICYmIHRoaXMubW9kZWxJbnB1dC5Db21wYW55ICE9IHVuZGVmaW5lZCkpIHtcclxuICAgICAgICAgICAgICAgICAgICBmaWxlYXN0ZXh0ID0gdGhpcy5tb2RlbElucHV0LkNvbXBhbnk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuRmlsZUFzID0gZmlsZWFzdGV4dDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlXHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuRmlsZUFzID0gXCIoXCIgKyB0aGlzLm1vZGVsSW5wdXQuQ29tcGFueSArIFwiKSBcIiArIHRoaXMubW9kZWxJbnB1dC5sbmFtZSArIFwiIFwiICsgdGhpcy5tb2RlbElucHV0LmZuYW1lOyAvLysgXCIgXCIgJiBtX3N0clNwb3VzZVxyXG4gICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlsc1t0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMubGVuZ3RoIC0gMV0uRW1haWxOYW1lID0gdGhpcy5tb2RlbElucHV0LkZpbGVBcztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLlNldEVtYWlsTmFtZSgpO1xyXG4gICAgfVxyXG4gICAgYmluZEdyb3VwKCk6IHZvaWQge1xyXG4gICAgICAgIC8vYWxlcnQodGhpcy5Jc1Nob3dBbGwpOyB0aGlzIGZ1bmN0aW9uIGlzIGNhbGxpbmcgb24gY2xpY2sgb2YgY2hlY2tib3hcclxuICAgICAgICB2YXIgaXNzaG93ID0gZmFsc2U7XHJcbiAgICAgICAgaWYgKHRoaXMuSXNTaG93QWxsID09IHRydWUpIHtcclxuICAgICAgICAgICAgaXNzaG93ID0gZmFsc2VcclxuICAgICAgICAgICAgdGhpcy5Jc1Nob3dBbGwgPSBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuSXNTaG93QWxsID0gdHJ1ZTtcclxuICAgICAgICAgICAgaXNzaG93ID0gdHJ1ZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMuYmluZEdyb3VwVHJlZShpc3Nob3cpO1xyXG4gICAgfVxyXG4gICAgc2F2ZUN1c3RvbWVyRGF0YSgpOiB2b2lkIHtcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgIHRoaXMuSXNidG5kaXNhYmxlID0gXCJkaXNhYmxlZFwiO1xyXG4gICAgICAgIHRoaXMuU2hvd0xvYWRlciA9IHRydWU7XHJcbiAgICAgICAgdGhpcy5nZXRTZWxlY3RlZEdyb3VwcygpO1xyXG4gICAgICAgXHJcbiAgICAgICAgdmFyIGNvdW50ID0gMDtcclxuICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzICE9IHVuZGVmaW5lZCAmJiB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMgIT0gbnVsbCkge1xyXG4gICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLk1haW5BZGRyZXNzID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICBjb3VudCA9IGNvdW50ICsgMTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGlmIChjb3VudCA+IDEpIHtcclxuICAgICAgICAgICAgICAgICAgICAvL2Jvb3Rib3guYWxlcnQoXCJNYWluIEFkZHJlc3Mgc2hvbHVkIGJlIG9ubHkgb25lXCIpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICB0aGlzLklzYnRuZGlzYWJsZSA9IFwiXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5TaG93TG9hZGVyID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgLy9hbGVydCh0aGlzLm1vZGVsSW5wdXQuQmlydGhEYXRlKTtcclxuICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkJpcnRoRGF0ZSAhPSBcIlwiKSB7XHJcbiAgICAgICAgICAgIGlmIChtb21lbnQodGhpcy5tb2RlbElucHV0LkJpcnRoRGF0ZSwgXCJERC1NTS1ZWVlZXCIsIHRydWUpLmlzVmFsaWQoKSA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7IG1lc3NhZ2U6IFwiQmlydGhkYXRlIGlzIG5vdCB2YWxpZFwiIH0pO1xyXG5cclxuICAgICAgICAgICAgICAgIHRoaXMuSXNidG5kaXNhYmxlID0gXCJcIjtcclxuICAgICAgICAgICAgICAgIHRoaXMuU2hvd0xvYWRlciA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChjb3VudCA8PSAxIHx8IHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3NlcyA9PSB1bmRlZmluZWQgfHwgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzID09IG51bGwpIHtcclxuXHJcbiAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXMgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lcyAhPSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICB2YXIgcGh0ZW1wID0gW107XHJcbiAgICAgICAgICAgICAgICBqUXVlcnkoJ2lucHV0W25hbWVePVwicGhcIl0nKS5lYWNoKGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgICAgICBwaHRlbXAucHVzaChqUXVlcnkodGhpcykudmFsKCkpO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB2YXIgYXJ0ZW1wID0gW107XHJcbiAgICAgICAgICAgICAgICBqUXVlcnkoJ2lucHV0W25hbWVePVwiYXJcIl0nKS5lYWNoKGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgICAgICBhcnRlbXAucHVzaChqUXVlcnkodGhpcykudmFsKCkpO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB2YXIgcHJldGVtcCA9IFtdO1xyXG4gICAgICAgICAgICAgICAgalF1ZXJ5KCdpbnB1dFtuYW1lXj1cInByZVwiXScpLmVhY2goZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHByZXRlbXAucHVzaChqUXVlcnkodGhpcykudmFsKCkpO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB2YXIgaSA9IDA7XHJcbiAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5Jc1NtcyA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuSXNTbXMgPSBcIjFcIjtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuSXNTbXMgPSBcIjBcIjtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMucGhwdWJsaXNoID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5waHB1Ymxpc2ggPSBcIjFcIjtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucGhwdWJsaXNoID0gXCIwXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuUGhvbmUgPSBwaHRlbXBbaV07XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5BcmVhID0gYXJ0ZW1wW2ldO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuUHJlZml4ID0gcHJldGVtcFtpXTtcclxuICAgICAgICAgICAgICAgICAgICBpKys7XHJcbiAgICAgICAgICAgICAgICAgICAgLy92YXIgdGVtcCA9IHRoaXMuUGhvbmVUeXBlSWQuc3BsaXQoJzsnKTtcclxuICAgICAgICAgICAgICAgICAgICAvL3RoaXMuUGhvbmVUeXBlSWQgPSBwYXJzZUludCh0ZW1wWzFdKTtcclxuICAgICAgICAgICAgICAgICAgICAvL3RoaXMuUGhvbmVUeXBlID0gdGVtcFswXTtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzICE9IHVuZGVmaW5lZCAmJiB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMgIT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMucHVibGlzaCA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucHVibGlzaCA9IFwiMVwiO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5wdWJsaXNoID0gXCIwXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGkrKztcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHZhciBqZGF0YSA9IEpTT04uc3RyaW5naWZ5KHRoaXMubW9kZWxJbnB1dCk7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGpkYXRhKVxyXG4gICAgICAgICAgICB0aGlzLl9jdXN0b21lclNlcnZpY2UuQWRkQ3VzdG9tZXIoamRhdGEpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLklzYnRuZGlzYWJsZSA9IFwiXCI7XHJcbiAgICAgICAgICAgICAgICB0aGlzLlNob3dMb2FkZXIgPSBmYWxzZTtcclxuXHJcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9hbGVydChyZXNwb25zZS5FcnJNc2cpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuTXNnQ2xhc3MgPSBcInRleHQtZGFuZ2VyXCI7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAvL2FsZXJ0KHJlc3BvbnNlLkVyck1zZyk7XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5Nc2dDbGFzcyA9IFwidGV4dC1zdWNjZXNzXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIGVtcGlkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJlbXBsb3llZWlkXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5zZXRDb29raWUoZW1waWQgKyBcImN1c3RcIiwgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyVHlwZSwgMTApO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5zZXRDb29raWUoZW1waWQgKyBcImVtcFwiLCB0aGlzLm1vZGVsSW5wdXQuZW1wbG95ZWVpZCwgMTApO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5zZXRDb29raWUoZW1waWQgKyBcInNyY1wiLCB0aGlzLm1vZGVsSW5wdXQuQ2FtZUZyb21DdXN0b21lciwgMTApO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMubGVuZ3RoPjApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5zZXRDb29raWUoZW1waWQgKyBcImNjb2RlXCIsIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3Nlc1t0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMubGVuZ3RoIC0gMV0uQ291bnRyeUNvZGUsIDEwKTtcclxuICAgICAgICAgICAgICAgICAgIC8vIGRlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vZG9jdW1lbnQubG9jYXRpb24gPSB0aGlzLkJhc2VBcHBVcmwgKyBcIkN1c3RvbWVyL0FkZC8tMVwiO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5UZW1wbW9kZWxJbnB1dCA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0ID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmVkaXRDdXN0RGV0KHRoaXMubW9kZWxJbnB1dCk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy90aGlzLlNldGRlZmF1bHRQYWdlKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gUmVzZXQgZm9ybSB2YWx1ZXNcclxuICAgICAgICAgICAgICAgICAgICAvL3RoaXMuX0N1c3RUeXBlcyA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB0aGlzLlNob3dNc2cgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5Nc2cgPSByZXNwb25zZS5FcnJNc2c7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICBlcnJvcj0+IGNvbnNvbGUubG9nKGVycm9yKSxcclxuICAgICAgICAgICAgICAgICgpID0+IGNvbnNvbGUubG9nKFwiU2F2ZSBDYWxsIENvbXBsZWF0ZWRcIilcclxuICAgICAgICAgICAgKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgbWVzc2FnZTogdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9NU0dfSVNNQUlOQURELCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB0aGlzLklzYnRuZGlzYWJsZSA9IFwiXCI7XHJcbiAgICAgICAgICAgIHRoaXMuU2hvd0xvYWRlciA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBDaGVja0N1c3RXaXRoZm5hbWVsbmFtZWNvbXBwaHNlbWFpbHMoKTogb2JzZXJ2YWJsZSB7XHJcbiAgICAgICAgdmFyIGpkYXRhID0gSlNPTi5zdHJpbmdpZnkodGhpcy5tb2RlbElucHV0KTtcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgIHZhciBmbmFtZSA9IFwiXCI7XHJcbiAgICAgICAgdmFyIGxuYW1lID0gXCJcIjtcclxuICAgICAgICB2YXIgY29tcGFueSA9IFwiXCI7XHJcbiAgICAgICAgdmFyIHBob25lcyA9IFwiXCI7XHJcbiAgICAgICAgdmFyIGVtYWlscyA9IFwiXCI7XHJcbiAgICAgICAgXHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5mbmFtZSA9PSB1bmRlZmluZWQpXHJcbiAgICAgICAgICAgIGZuYW1lID0gXCJcIjtcclxuICAgICAgICBlbHNlXHJcbiAgICAgICAgICAgIGZuYW1lID0gdGhpcy5tb2RlbElucHV0LmZuYW1lO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LmxuYW1lID09IHVuZGVmaW5lZClcclxuICAgICAgICAgICAgbG5hbWUgPSBcIlwiO1xyXG4gICAgICAgIGVsc2VcclxuICAgICAgICAgICAgbG5hbWUgPSB0aGlzLm1vZGVsSW5wdXQubG5hbWU7XHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5Db21wYW55ID09IHVuZGVmaW5lZClcclxuICAgICAgICAgICAgY29tcGFueSA9IFwiXCI7XHJcbiAgICAgICAgZWxzZVxyXG4gICAgICAgICAgICBjb21wYW55ID0gdGhpcy5tb2RlbElucHV0LkNvbXBhbnk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgalF1ZXJ5KCdpbnB1dFtuYW1lXj1cInBoXCJdJykuZWFjaChmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICBpZiAoalF1ZXJ5KHRoaXMpLnZhbCgpICE9IFwiXCIgJiYgalF1ZXJ5KHRoaXMpLnZhbCgpICE9IHVuZGVmaW5lZCAmJiBqUXVlcnkodGhpcykudmFsKCkgIT0gbnVsbCAmJiBqUXVlcnkodGhpcykudmFsKCkubGVuZ3RoPj0zKSB7XHJcbiAgICAgICAgICAgICAgICBwaG9uZXMgKz0galF1ZXJ5KHRoaXMpLnZhbCgpICsgXCInLCdcIjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGlmIChwaG9uZXMubGVuZ3RoID4gMCkgcGhvbmVzID0gcGhvbmVzLnN1YnN0cmluZygwLCBwaG9uZXMubGVuZ3RoIC0gMyk7XHJcbiAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLkVtYWlsICE9IFwiXCIgJiYgdGhpcy5FbWFpbCAhPSB1bmRlZmluZWQgJiYgdGhpcy5FbWFpbCAhPSBudWxsICYmIHRoaXMuRW1haWwubGVuZ3RoPj0zKSB7XHJcbiAgICAgICAgICAgICAgICBlbWFpbHMgKz0gdGhpcy5FbWFpbCtcIicsJ1wiO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGlmIChlbWFpbHMubGVuZ3RoID4gMCkgZW1haWxzID0gZW1haWxzLnN1YnN0cmluZygwLCBlbWFpbHMubGVuZ3RoIC0gMyk7XHJcbiAgICAgICAgaWYgKChmbmFtZSAhPSBcIlwiICYmIGZuYW1lLmxlbmd0aCA+PSAyICYmIGxuYW1lICE9IFwiXCIgJiYgbG5hbWUubGVuZ3RoID49IDIpXHJcbiAgICAgICAgICAgIHx8IChjb21wYW55ICE9IFwiXCIgJiYgY29tcGFueS5sZW5ndGggPj0gMylcclxuICAgICAgICAgICAgfHwgKHBob25lcyAhPSBcIlwiKVxyXG4gICAgICAgICAgICB8fCAoZW1haWxzICE9IFwiXCIpKSB7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICB0aGlzLl9jdXN0b21lclNlcnZpY2UuR2V0Q3VzdG9tZXJzU2VhcmNoRGF0YShmbmFtZSwgbG5hbWUsIGNvbXBhbnksIHBob25lcywgZW1haWxzKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLkN1c3RMaXN0ID0ge307XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5DdXN0TGlzdCA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLkRhdGEgIT0gbnVsbCAmJiByZXNwb25zZS5EYXRhICE9IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmN1c3RTZWFyY2hEYXRhID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgalF1ZXJ5KCcjQ3VzdE1vZGFsJykub3Blbk1vZGFsKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9qUXVlcnkoJyNDdXN0TW9kYWwnKS5tb2RhbCgnb3BlbicpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2pRdWVyeShcIiNDdXN0TW9kYWxcIikuc2hvdygxMDAwKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgLy9hbGVydCh0aGlzLlJFUyk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vdGhpcy5iaW5kRmlsZUFzKCk7XHJcbiAgICB9XHJcblxyXG5cclxuXHJcbiAgICBDaGVja0N1c3RXaXRoZm5hbWVsbmFtZShmbmFtZSwgbG5hbWUsY29tcGFueSk6IG9ic2VydmFibGUge1xyXG4gICAgICAgIHZhciBqZGF0YSA9IEpTT04uc3RyaW5naWZ5KHRoaXMubW9kZWxJbnB1dCk7XHJcbiAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LmZuYW1lID09IHVuZGVmaW5lZClcclxuICAgICAgICAgICAgZm5hbWUgPSBcIlwiO1xyXG4gICAgICAgIGVsc2VcclxuICAgICAgICAgICAgZm5hbWUgPSB0aGlzLm1vZGVsSW5wdXQuZm5hbWU7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQubG5hbWUgPT0gdW5kZWZpbmVkKVxyXG4gICAgICAgICAgICBsbmFtZSA9IFwiXCI7XHJcbiAgICAgICAgZWxzZVxyXG4gICAgICAgICAgICBsbmFtZSA9IHRoaXMubW9kZWxJbnB1dC5sbmFtZTtcclxuICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkNvbXBhbnkgPT0gdW5kZWZpbmVkKVxyXG4gICAgICAgICAgICBjb21wYW55ID0gXCJcIjtcclxuICAgICAgICBlbHNlXHJcbiAgICAgICAgICAgIGNvbXBhbnkgPSB0aGlzLm1vZGVsSW5wdXQuQ29tcGFueTtcclxuICAgICAgICB0aGlzLl9jdXN0b21lclNlcnZpY2UuQ2hlY2tDdXN0V2l0aFNhbWVOYW1lKGZuYW1lLCBsbmFtZSwgY29tcGFueSkuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5DdXN0TGlzdCA9IHt9O1xyXG4gICAgICAgICAgICAgICAgdGhpcy5DdXN0TGlzdCA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuRGF0YSAhPSBudWxsICYmIHJlc3BvbnNlLkRhdGEgIT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jdXN0U2VhcmNoRGF0YSA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5KFwiI0N1c3RNb2RhbFwiKS5vcGVuTW9kYWwoKTtcclxuICAgICAgICAgICAgICAgICAgICAvL2pRdWVyeShcIiNDdXN0TW9kYWxcIikuc2hvdygxMDAwKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC8vYWxlcnQodGhpcy5SRVMpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIC8vdGhpcy5iaW5kRmlsZUFzKCk7XHJcbiAgICB9XHJcblxyXG5cclxuXHJcblxyXG4gICAgQ2hlY2tDdXN0V2l0aEVtYWlsKCk6IG9ic2VydmFibGUge1xyXG4gICAgICAgIFxyXG4gICAgICAgIC8vdmFyIEVtYWlsID0gXCJcIjtcclxuICAgICAgICAvL2lmICh0aGlzLkVtYWlsTW9kZWwuRW1haWwgIT0gXCJcIiAmJiB0aGlzLkVtYWlsTW9kZWwuRW1haWwgIT0gdW5kZWZpbmVkKVxyXG4gICAgICAgIC8vICAgIEVtYWlsID0gdGhpcy5FbWFpbE1vZGVsLkVtYWlsO1xyXG4gICAgICAgIC8vdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkNoZWNrQ3VzdFdpdGhTYW1lRW1haWwoRW1haWwpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAvLyAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgIC8vICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgLy8gICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgIC8vICAgICAgICBhbGVydChyZXNwb25zZS5FcnJNc2cpO1xyXG4gICAgICAgIC8vICAgIH1cclxuICAgICAgICAvLyAgICBlbHNlIHtcclxuICAgICAgICAvLyAgICAgICAgdGhpcy5DdXN0TGlzdCA9IHt9O1xyXG4gICAgICAgIC8vICAgICAgICB0aGlzLkN1c3RMaXN0ID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAvLyAgICAgICAgaWYgKHJlc3BvbnNlLkRhdGEgIT0gbnVsbCAmJiByZXNwb25zZS5EYXRhICE9IHVuZGVmaW5lZCkge1xyXG4gICAgICAgIC8vICAgICAgICAgICAgdGhpcy5jdXN0U2VhcmNoRGF0YSA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgLy8gICAgICAgICAgICBqUXVlcnkoXCIjQ3VzdE1vZGFsXCIpLm1vZGFsKFwic2hvd1wiKTtcclxuICAgICAgICAvLyAgICAgICAgfVxyXG4gICAgICAgIC8vICAgICAgICAvL2FsZXJ0KHRoaXMuUkVTKTtcclxuICAgICAgICAvLyAgICB9XHJcbiAgICAgICAgLy99LCBlcnJvcj0+IHtcclxuICAgICAgICAvLyAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgLy99LCAoKSA9PiB7XHJcbiAgICAgICAgLy8gICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgLy99KTtcclxuICAgIH1cclxuICAgIENoZWNrQ3VzdFdpdGhQaG9uZSgpOiBvYnNlcnZhYmxlIHtcclxuICAgICAgICB2YXIgUGhvbmUgPSBcIlwiO1xyXG4gICAgICAgIGlmICh0aGlzLlBob25lTW9kZWwuUGhvbmUgIT0gXCJcIiAmJiB0aGlzLlBob25lTW9kZWwuUGhvbmUgIT0gdW5kZWZpbmVkKVxyXG4gICAgICAgICAgICBQaG9uZSA9IHRoaXMuUGhvbmVNb2RlbC5QaG9uZTtcclxuICAgICAgICB0aGlzLl9jdXN0b21lclNlcnZpY2UuQ2hlY2tDdXN0V2l0aFNhbWVQaG9uZSh0aGlzLlBob25lTW9kZWwuUGhvbmUpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuQ3VzdExpc3QgPSB7fTtcclxuICAgICAgICAgICAgICAgIHRoaXMuQ3VzdExpc3QgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLkRhdGEgIT0gbnVsbCAmJiByZXNwb25zZS5EYXRhICE9IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY3VzdFNlYXJjaERhdGEgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeShcIiNDdXN0TW9kYWxcIikub3Blbk1vZGFsKCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvL2FsZXJ0KHRoaXMuUkVTKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuICAgIFNob3dSZW1hcmtzKFBoT2JqKTogT2JzZXJ2YWJsZSB7XHJcbiAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzID09IFBoT2JqKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLklzU2hvd1JlbWFya3MgPSB0cnVlO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG4gICAgc2hvd0FkZFBvcHVwKCk6IG9ic2VydmFibGUge1xyXG4gICAgICAgIHRoaXMuQWRkcmVzcyA9IHt9O1xyXG4gICAgICAgIHRoaXMuUGhvbmVNb2RlbCA9IHt9O1xyXG4gICAgICAgIHRoaXMuUGhvbmVNb2RlbC5QaG9uZVR5cGVJZCA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5BZGRyZXNzLkNvdW50cnlDb2RlID0gXCJcIjtcclxuICAgICAgICB0aGlzLkFkZHJlc3MuU3RhdGVJZCA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5BZGRyZXNzLkNpdHlOYW1lID0gXCJcIjtcclxuICAgICAgICB0aGlzLkFkZHJlc3MuQWRkcmVzc1R5cGVJZCA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5FbWFpbE1vZGVsID0ge307XHJcbiAgICAgICAgdGhpcy5CVE5fUEhBREQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0JUTl9QSEFERFxyXG4gICAgICAgIFxyXG5cclxuICAgIH1cclxuICAgIHNob3doaWRlR3JvdXBzKCk6IG9ic2VydmFibGUge1xyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgaWYgKHRoaXMuU2hvd0dyb3VwcyA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICB0aGlzLlNob3dHcm91cHMgPSB0cnVlO1xyXG4gICAgICAgICAgICB0aGlzLkdyb3VwVGV4dCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfTEJMX0hJREVHUk9VUDtcclxuICAgICAgICAgICAgalF1ZXJ5KFwiI0dycERpdlwiKS5zaG93KDEwMDApO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5TaG93R3JvdXBzID0gZmFsc2U7XHJcbiAgICAgICAgICAgIHRoaXMuR3JvdXBUZXh0ID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9MQkxfU0hPV0dST1VQUztcclxuICAgICAgICAgICAgalF1ZXJ5KFwiI0dycERpdlwiKS5oaWRlKDEwMDApO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICB9XHJcblxyXG5cclxuICAgIENhbmFkZEFkZHJlc3MoYWRvYmopOiBib29sZWFuIHtcclxuICAgICAgICAvL2FsZXJ0KCdIZWxsbycpO1xyXG4gICAgICAgIHJldHVybiAoYWRvYmouU3RyZWV0ICE9IHVuZGVmaW5lZCAmJiBhZG9iai5TdHJlZXQgIT0gXCJcIilcclxuICAgICAgICAgICAgJiYgKGFkb2JqLlN0cmVldDIgIT0gdW5kZWZpbmVkICYmIGFkb2JqLlN0cmVldDIgIT0gXCJcIilcclxuICAgICAgICAgICAgLy8mJiAoYWRvYmouQ2l0eU5hbWUgIT0gdW5kZWZpbmVkICYmIGFkb2JqLkNpdHlOYW1lICE9IFwiXCIpXHJcbiAgICAgICAgICAgICYmIChhZG9iai5aaXAgIT0gdW5kZWZpbmVkICYmIGFkb2JqLlppcCAhPSBcIlwiKSBcclxuICAgICAgICAgICAgJiYgKGFkb2JqLkNvdW50cnlDb2RlICE9IHVuZGVmaW5lZCAmJiBhZG9iai5Db3VudHJ5Q29kZSAhPSBcIlwiIClcclxuICAgICAgICAgICAgLy8mJiAodGhpcy5BZGRyZXNzLlN0YXRlSWQgIT0gdW5kZWZpbmVkICYmIHRoaXMuQWRkcmVzcy5TdGF0ZUlkICE9IFwiXCIpXHJcbiAgICAgICAgICAgICYmIChhZG9iai5BZGRyZXNzVHlwZUlkICE9IHVuZGVmaW5lZCAmJiBhZG9iai5BZGRyZXNzVHlwZUlkICE9IFwiXCIpO1xyXG4gICAgfVxyXG4gICAgQWRkQWRkcmVzc2VzKGFkb2JqKTogb2JzZXJ2YWJsZSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdmFyIElzTWFpbkFkZCA9IGZhbHNlO1xyXG4gICAgICAgIGFkb2JqLkNpdHlOYW1lID0galF1ZXJ5KFwiI0NpdHlcIikudmFsKCk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgaWYgKHRoaXMuQ2FuYWRkQWRkcmVzcyhhZG9iaikpIHtcclxuXHJcbiAgICAgICAgICAgIHZhciBlbXBpZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiZW1wbG95ZWVpZFwiKTtcclxuICAgICAgICAgICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLnNldENvb2tpZShlbXBpZCArIFwiY2NvZGVcIiwgYWRvYmouQ291bnRyeUNvZGUsIDEwKTtcclxuICAgICAgICAgICAgdmFyIGFkaWQgPSBcIlwiO1xyXG4gICAgICAgICAgICB2YXIgYWR0ZXh0ID0gXCJIb21lXCI7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ29tcGFueSAhPSBcIlwiICYmIHRoaXMubW9kZWxJbnB1dC5Db21wYW55ICE9IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgYWR0ZXh0ID0gXCJXb3JrXCI7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5fQWRkcmVzc1R5cGVzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5UZXh0ID09IGFkdGV4dCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGFkaWQgPSB0aGlzLlZhbHVlO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB2YXIgQWRkcmVzT2JqID0geyBTdHJlZXQ6IFwiXCIsIFN0cmVldDI6IFwiXCIsIENpdHlOYW1lOiBcIlwiLCBaaXA6IFwiXCIsIENvdW50cnlDb2RlOiBhZG9iai5Db3VudHJ5Q29kZSwgU3RhdGVJZDogXCJcIiwgQWRkcmVzc1R5cGVJZDogYWRpZCwgRm9yRGVsaXZlcnk6IGZhbHNlLCBNYWluQWRkcmVzczogZmFsc2UsLCBNYWluT3JkZXI6IFwiTWFpbkFkZHJcIiArICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMubGVuZ3RoKzEpLnRvU3RyaW5nKCksIERlbHZyeU9yZGVyOiBcIkRlbHZyeVwiICsgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3Nlcy5sZW5ndGgrMSkudG9TdHJpbmcoKSB9O1xyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAvL2pRdWVyeS5lYWNoKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3NlcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgLy8gICAgaWYgKHRoaXMuTWFpbkFkZHJlc3MgPT0gdHJ1ZSAmJiBhZG9iai5NYWluQWRkcmVzcyA9PSB0cnVlICYmIHRoaXMgIT0gYWRvYmopIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgYWRvYmouTWFpbkFkZHJlc3MgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAvLyAgICB9XHJcbiAgICAgICAgICAgICAgICAvL30pO1xyXG4gICAgICAgICAgICAgICAgaWYgKElzTWFpbkFkZCA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3Nlcy5wdXNoKEFkZHJlc09iaik7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgdmFyIG1zZyA9ICcnO1xyXG4gICAgICAgICAgICBpZiAoYWRvYmouU3RyZWV0ID09IHVuZGVmaW5lZCB8fCBhZG9iai5TdHJlZXQgPT0gXCJcIikge1xyXG4gICAgICAgICAgICAgICAgLy9tc2cgKz0gJ1xcblN0cmVldCBpcyBub3QgZmlsbGVkJzsgQVBQX0FMX01TR19TVFJFRVRcclxuICAgICAgICAgICAgICAgIG1zZyArPSAnXFxuJyArIHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfQUxfTVNHX1NUUkVFVDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoYWRvYmouU3RyZWV0MiA9PSB1bmRlZmluZWQgfHwgYWRvYmouU3RyZWV0MiA9PSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICAvL21zZyArPSAnXFxuQXJlYSBpcyBub3QgZmlsbGVkJztcclxuICAgICAgICAgICAgICAgIG1zZyArPSAnXFxuJyArIHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfQUxfTVNHX0FSRUE7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgLy9pZiAoYWRvYmouQ2l0eU5hbWUgPT0gdW5kZWZpbmVkIHx8IGFkb2JqLkNpdHlOYW1lID09IFwiXCIpXHJcbiAgICAgICAgICAgIC8vICAgIC8vbXNnICs9ICdcXG5DaXR5IGlzIG5vdCBmaWxsZWQnOyBcclxuICAgICAgICAgICAgLy8gICAgbXNnICs9ICdcXG4nICsgdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9BTF9NU0dfQ0lUWTtcclxuICAgICAgICAgICAgaWYgKGFkb2JqLlppcCA9PSB1bmRlZmluZWQgfHwgYWRvYmouWmlwID09IFwiXCIpIHtcclxuICAgICAgICAgICAgICAgIC8vbXNnICs9ICdcXG5aaXAgaXMgbm90IGZpbGxlZCc7IFxyXG4gICAgICAgICAgICAgICAgbXNnICs9ICdcXG4nK3RoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfQUxfTVNHX1pJUDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoYWRvYmouQ291bnRyeUNvZGUgPT0gdW5kZWZpbmVkIHx8IGFkb2JqLkNvdW50cnlDb2RlID09IFwiXCIpIHtcclxuICAgICAgICAgICAgICAgIC8vbXNnICs9ICdcXG5Db3VudHJ5IGlzIG5vdCBzZWxlY3RlZCc7XHJcbiAgICAgICAgICAgICAgICBtc2cgKz0gJ1xcbicgKyB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0FMX01TR19DT1VOVFJZO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8vaWYgKHRoaXMuQWRkcmVzcy5TdGF0ZUlkID09IHVuZGVmaW5lZCB8fCB0aGlzLkFkZHJlc3MuU3RhdGVJZCA9PSBcIlwiKSB7XHJcbiAgICAgICAgICAgIC8vICAgIG1zZyArPSAnXFxuU3RhdGUgaXMgbm90IHNlbGVjdGVkJztcclxuICAgICAgICAgICAgLy99XHJcbiAgICAgICAgICAgIGlmIChhZG9iai5BZGRyZXNzVHlwZUlkID09IHVuZGVmaW5lZCB8fCBhZG9iai5BZGRyZXNzVHlwZUlkID09IFwiXCIpIHtcclxuICAgICAgICAgICAgICAgIC8vbXNnICs9ICdcXG5BZGRyZXNzIHR5cGUgaXMgbm90IHNlbGVjdGVkJztcclxuICAgICAgICAgICAgICAgIG1zZyArPSAnXFxuJyArIHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfQUxfTVNHX0FEVFlQRTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgIG1lc3NhZ2U6IG1zZywgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcblxyXG4gICAgfVxyXG4gICAgQ2FuYWRkUGhvbmUocGhvbmVPYmopOiBib29sZWFuIHtcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgIC8vYWxlcnQodGhpcy5QaG9uZU1vZGVsLlBob25lVHlwZUlkICsgJyAnICsgdGhpcy5QaG9uZU1vZGVsLlBob25lVHlwZSArICcgJyArIHRoaXMuUGhvbmVNb2RlbC5QcmVmaXggKyAnICcgKyB0aGlzLlBob25lTW9kZWwuQXJlYSArICcgJyArIHRoaXMuUGhvbmVNb2RlbC5QaG9uZSk7XHJcbiAgICAgICAgcmV0dXJuIChwaG9uZU9iai5QaG9uZVR5cGVJZCAhPSB1bmRlZmluZWQgJiYgcGhvbmVPYmouUGhvbmVUeXBlSWQgIT0gXCJcIilcclxuICAgICAgICAgICAgLy8gJiYgKHRoaXMuUGhvbmVNb2RlbC5QaG9uZVR5cGUgIT0gdW5kZWZpbmVkJiYgdGhpcy5QaG9uZU1vZGVsLlBob25lVHlwZSAhPSBcIlwiIClcclxuICAgICAgICAgICAgLy8mJiAodGhpcy5QaG9uZU1vZGVsLlByZWZpeCAhPSB1bmRlZmluZWQmJiB0aGlzLlBob25lTW9kZWwuUHJlZml4ICE9IFwiXCIgIClcclxuICAgICAgICAgICAgLy8mJiAodGhpcy5QaG9uZU1vZGVsLkFyZWEgIT0gdW5kZWZpbmVkJiZ0aGlzLlBob25lTW9kZWwuQXJlYSAhPSBcIlwiICApXHJcbiAgICAgICAgICAgIC8vJiYgKHBob25lT2JqLlBob25lICE9IHVuZGVmaW5lZCAmJiBwaG9uZU9iai5QaG9uZSAhPSBcIlwiKTtcclxuICAgICAgICAgICAgLy8mJiAodGhpcy5QaG9uZU1vZGVsLlByZWZpeCAhPSB1bmRlZmluZWQgJiYgdGhpcy5QaG9uZU1vZGVsLlByZWZpeC5sZW5ndGggIT0gMyk7ICAgICAgICAgICAgO1xyXG4gICAgfVxyXG4gICAgQWRkUGhvbmVzKHBob25lT2JqKTogb2JzZXJ2YWJsZSB7XHJcbiAgICAgICAgaWYgKHRoaXMuQ2FuYWRkUGhvbmUocGhvbmVPYmopKSB7XHJcblxyXG4gICAgICAgICAgICBkZWJ1Z2dlcjtcclxuICAgICAgICAgICAgLy9pZiAodGhpcy5Jc1JlY29yZEVkaXRNb2RlID09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgIHZhciBwaGlkID0gXCJcIjtcclxuICAgICAgICAgICAgdmFyIFNNUyA9IDA7XHJcbiAgICAgICAgICAgIHZhciBwdWJsaXNoID0gMDtcclxuICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5fUGhvbmVUeXBlcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuVGV4dCA9PSBcIkNlbGxQaG9uZVwiKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHBoaWQgPSB0aGlzLlZhbHVlO1xyXG4gICAgICAgICAgICAgICAgICAgIFNNUyA9IDE7XHJcbiAgICAgICAgICAgICAgICAgICAgcHVibGlzaCA9IDE7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgdmFyIFBob25lT2JqID0geyBQaG9uZVR5cGVJZDogcGhpZCwgUGhvbmVUeXBlOiBcIlwiLCBQcmVmaXg6IFwiXCIsIEFyZWE6IFwiXCIsIFBob25lOiBcIlwiLCBJc1NtczogU01TLCBDb21tZW50czogXCJcIiwgSXNTaG93UmVtYXJrczogZmFsc2UsIHBocHVibGlzaDogcHVibGlzaCwgU01TT3JkZXI6IFwiU01TXCIgKyAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzLmxlbmd0aCArIDEpLnRvU3RyaW5nKCksIFB1Ymxpc2hPcmRlcjogXCJQdWJcIiArICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXMubGVuZ3RoICsgMSkudG9TdHJpbmcoKSB9O1xyXG4gICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzLnB1c2goUGhvbmVPYmopO1xyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIC8vdGhpcy5DaGVja0N1c3RXaXRoZm5hbWVsbmFtZWNvbXBwaHNlbWFpbHMoKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHZhciBtc2cgPSAnJztcclxuICAgICAgICAgICAgaWYgKHBob25lT2JqLlBob25lVHlwZUlkID09IHVuZGVmaW5lZCB8fCBwaG9uZU9iai5QaG9uZVR5cGVJZCA9PSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICAvL21zZyArPSAnXFxuUGhvbmUgdHlwZSBpcyBub3Qgc2VsZWN0ZWQnO1xyXG4gICAgICAgICAgICAgICAgbXNnICs9ICdcXG4nICsgdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9BTF9SRUdNU0dfUEhUWVBFO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8vaWYgKHBob25lT2JqLlBob25lID09IHVuZGVmaW5lZCB8fCBwaG9uZU9iai5QaG9uZSA9PSBcIlwiKSB7XHJcbiAgICAgICAgICAgIC8vICAgIC8vbXNnICs9ICdcXG5QaG9uZSBudW1iZXIgaXMgbm90IGZpbGxlZCc7XHJcbiAgICAgICAgICAgIC8vICAgIG1zZyArPSAnXFxuJyArIHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfQUxfUkVHTVNHX1BITk87XHJcbiAgICAgICAgICAgIC8vfVxyXG4gICAgICAgICAgICAvL2lmICh0aGlzLlBob25lTW9kZWwuUHJlZml4Lmxlbmd0aCE9Mykge1xyXG4gICAgICAgICAgICAvLyAgICBtc2cgKz0gJ1xcblByZWZpeCBtdXN0IG9mIDMgbnVtZXJpYyBkaWdpdHMnO1xyXG4gICAgICAgICAgICAvL31cclxuICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICBtZXNzYWdlOiBtc2csY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgfVxyXG4gICAgQ2FuYWRkRW1haWwoRW1haWxPYmopOiBib29sZWFuIHtcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgIC8vYWxlcnQoJ0hlbGxvJyk7XHJcbiAgICAgICAgcmV0dXJuIChFbWFpbE9iai5FbWFpbE5hbWUgIT0gdW5kZWZpbmVkICYmIEVtYWlsT2JqLkVtYWlsTmFtZSAhPSBcIlwiKTtcclxuICAgICAgICAvLyhFbWFpbE9iai5FbWFpbCAhPSB1bmRlZmluZWQgJiYgRW1haWxPYmouRW1haWwgIT0gXCJcIikgJiZcclxuICAgICAgICAgICAgIFxyXG4gICAgfVxyXG4gICAgQWRkRW1haWxzKEVtYWlsT2JqKTogb2JzZXJ2YWJsZSB7XHJcbiAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICBpZiAodGhpcy5DYW5hZGRFbWFpbChFbWFpbE9iaikpIHtcclxuICAgICAgICAgICAgdmFyIGVwdWJsaXNoID0gMDtcclxuICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5fUGhvbmVUeXBlcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICBpZiAodGhpcy5UZXh0ID09IFwiQ2VsbFBob25lXCIpIHtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICBlcHVibGlzaCA9IDE7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgLy9pZiAodGhpcy5Jc1JlY29yZEVkaXRNb2RlID09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgIHZhciBlT2JqID0ge307XHJcbiAgICAgICAgICAgIGVPYmouRW1haWwgPSBcIlwiO1xyXG4gICAgICAgICAgICBlT2JqLkVtYWlsTmFtZSA9IHRoaXMubW9kZWxJbnB1dC5GaWxlQXM7XHJcbiAgICAgICAgICAgIGVPYmouTmV3c2xldHRlcmUgPSB0cnVlO1xyXG4gICAgICAgICAgICBlT2JqLnB1Ymxpc2ggPSBlcHVibGlzaDtcclxuICAgICAgICAgICAgZU9iai5OZXdzT3JkZXI9IFwiTmV3c1wiICsgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlscy5sZW5ndGgrMSkudG9TdHJpbmcoKTtcclxuICAgICAgICAgICAgZU9iai5FUHVibGlzaE9yZGVyPSBcIkVQdWJcIiArICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMubGVuZ3RoICsgMSkudG9TdHJpbmcoKTtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlscy5wdXNoKGVPYmopO1xyXG4gICAgICAgICAgICAgICAgLy90aGlzLkNoZWNrQ3VzdFdpdGhmbmFtZWxuYW1lY29tcHBoc2VtYWlscygpO1xyXG4gICAgICAgICAgICBcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHZhciBtc2cgPSAnJztcclxuICAgICAgICAgICAgLy9pZiAoRW1haWxPYmouRW1haWwgPT0gdW5kZWZpbmVkIHx8IEVtYWlsT2JqLkVtYWlsID09IFwiXCIpXHJcbiAgICAgICAgICAgIC8vICAgIC8vbXNnICs9ICdcXG5FbWFpbCBpcyBub3QgZmlsbGVkJztcclxuICAgICAgICAgICAgLy8gICAgbXNnICs9ICdcXG4nICsgdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9BTF9SRUdNU0dfRU1BSUw7XHJcbiAgICAgICAgICAgIGlmIChFbWFpbE9iai5FbWFpbE5hbWUgPT0gdW5kZWZpbmVkIHx8IEVtYWlsT2JqLkVtYWlsTmFtZSA9PSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICAvL21zZyArPSAnXFxuTmFtZSBpcyBub3QgZmlsbGVkJztcclxuICAgICAgICAgICAgICAgIG1zZyArPSAnXFxuJyArIHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfQUxfUkVHTVNHX0VOQU1FO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgbWVzc2FnZTogbXNnLCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICAgICAgLy8gdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzID0gdGhpcy5DdXN0b21lckFkZHJlc3NlcztcclxuICAgIH1cclxuICAgIFxyXG4gICAgZWRpdEN1c3REZXQoT2JqKSB7XHJcbiAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkdldENvbXBsZXRlQ3VzdERldChPYmouQ3VzdG9tZXJJZCkuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgIC8vIGRlYnVnZ2VyO1xyXG4gICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0ID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgIHRoaXMuU0FWRV9CVE5fVEVYVCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfQlROX1VQREFURTtcclxuICAgICAgICAgICAgICAgIC8vdGhpcy5BRERfTkVXX0NVU1RfVEVYVCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfTEJMX1VQREFURV9DVVNUO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5DU1NURVhUID0gXCJtZGktY29udGVudC1hZGRcIjtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMubGVuZ3RoID09IDApIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMgPSBbeyBFbWFpbDogXCJcIiwgRW1haWxOYW1lOiB0aGlzLm1vZGVsSW5wdXQuRmlsZUFzLCBOZXdzbGV0dGVyZTogZmFsc2UsIHB1Ymxpc2g6IDAsIE5ld3NPcmRlcjogXCJOZXdzMVwiLCBFUHVibGlzaE9yZGVyOiBcIkVQdWIxXCIgfV1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBjb3VudCA9IDE7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlscywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLk5ld3NPcmRlciA9IFwiTmV3c1wiICsgY291bnQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuRVB1Ymxpc2hPcmRlciA9IFwiRVB1YlwiICsgY291bnQrKztcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXMubGVuZ3RoID09IDApIHtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgcGhpZCA9IFwiXCI7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMuX1Bob25lVHlwZXMsIGZ1bmN0aW9uICgpIHtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLlRleHQgPT0gXCJDZWxsUGhvbmVcIikge1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBoaWQgPSB0aGlzLlZhbHVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lcyA9IFt7IFBob25lVHlwZUlkOiBwaGlkLCBQcmVmaXg6IFwiXCIsIEFyZWE6IFwiXCIsIFBob25lOiBcIlwiLCBJc1NtczogMCwgQ29tbWVudHM6IFwiXCIsIHBocHVibGlzaDogMCwgU01TT3JkZXI6IFwiU01TMVwiLCBQdWJsaXNoT3JkZXI6IFwiUHViMVwiIH1dO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIGRlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIGNvdW50ID0gMTtcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXMsIGZ1bmN0aW9uICgpIHtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuU01TT3JkZXIgPSBcIlNNU1wiICsgY291bnQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuUHVibGlzaE9yZGVyID0gXCJQdWJcIiArIGNvdW50Kys7XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzLmxlbmd0aCA9PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIGVtcGlkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJlbXBsb3llZWlkXCIpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICB2YXIgY2NvZGUgPSB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZ2V0Q29va2llKGVtcGlkICsgXCJjY29kZVwiKTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoY2NvZGUubGVuZ3RoID4gMClcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2NvZGUgPSBjY29kZS5zdWJzdHJpbmcoMSwgY2NvZGUubGVuZ3RoKTtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgYWRpZCA9IFwiXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIGNvbXB0ZXh0ID0gXCJIb21lXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5Db21wYW55ICE9IFwiXCIgJiYgdGhpcy5tb2RlbElucHV0LkNvbXBhbnkgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dC5Db21wYW55ICE9IG51bGwpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29tcHRleHQgPSBcIldvcmtcIjtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5fQWRkcmVzc1R5cGVzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLlRleHQgPT0gY29tcHRleHQpIHtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZGlkID0gdGhpcy5WYWx1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMgPSBbeyBTdHJlZXQ6IFwiXCIsIFN0cmVldDI6IFwiXCIsIENpdHlOYW1lOiBcIlwiLCBaaXA6IFwiXCIsIENvdW50cnlDb2RlOiBjY29kZSwgU3RhdGVJZDogXCJcIiwgQWRkcmVzc1R5cGVJZDogYWRpZCwgRm9yRGVsaXZlcnk6IGZhbHNlLCBNYWluQWRkcmVzczogZmFsc2UsIE1haW5PcmRlcjogXCJNYWluQWRkcjFcIiwgRGVsdnJ5T3JkZXI6IFwiRGVsdnJ5MVwiIH1dO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIGNvdW50ID0gMTtcclxuICAgICAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3NlcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuTWFpbk9yZGVyID0gXCJNYWluQWRkclwiICsgY291bnQ7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5EZWx2cnlPcmRlciA9IFwiRGVsdnJ5XCIgKyBjb3VudCsrO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvL3ZhciB0cmVldmlldyA9IGpRdWVyeShcIiNncm91cFRyZWVcIikuZGF0YShcImtlbmRvVHJlZVZpZXdcIik7XHJcblxyXG4gICAgICAgICAgICAgICAgLy92YXIgYmFyID0gdHJlZXZpZXcuZmluZEJ5SWQoXCJCYXJcIik7XHJcblxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAvL2pRdWVyeS5lYWNoKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckdyb3VwcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgLy8gICAgdmFyIGRhdGEgPSBqUXVlcnkoXCIjZ3JvdXBUcmVlXCIpLmRhdGEoXCJrZW5kb1RyZWVWaWV3XCIpLmRhdGFTb3VyY2UuZ2V0QnlVaWQodGhpcy5DdXN0b21lckdlbmVyYWxHcm91cElkKTtcclxuICAgICAgICAgICAgICAgIC8vICAgIGlmIChkYXRhKSB7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgZGF0YS5zZXQoXCJjaGVja2VkXCIsIHRydWUpO1xyXG4gICAgICAgICAgICAgICAgLy8gICAgfVxyXG4gICAgICAgICAgICAgICAgLy8gICAgLy92YXIgR3JvdXBOb2RlID0gdHJlZXZpZXcuZmluZEJ5SWQodGhpcy5DdXN0b21lckdlbmVyYWxHcm91cElkKTtcclxuICAgICAgICAgICAgICAgIC8vICAgIC8vdHJlZXZpZXcuZGF0YUl0ZW0oR3JvdXBOb2RlKS5zZXQoXCJjaGVja2VkXCIsIHRydWUpO1xyXG4gICAgICAgICAgICAgICAgLy99KTtcclxuICAgICAgICAgICAgICAgIHRoaXMuQ3VzdElkVGV4dCA9IFwiKCBcIiArIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkICsgXCIgKVwiO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5Jc0ZpbGVBc3R4dFNob3cgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIHRoaXMuSGlkZVNob3dGaWxlQXN0eHQoKTtcclxuXHJcbiAgICAgICAgICAgICAgICAvL2FsZXJ0KHRoaXMuUkVTKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuICAgIENoZWNrUGhvbmVUeXBlKFBob25lT2JqKSB7XHJcbiAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAvL2FsZXJ0KFBob25lT2JqLlBob25lVHlwZUlkICsgXCIgfCBcIiArIGpRdWVyeShcIiNQaG9uZVR5cGVcIikudmFsKCkpO1xyXG4gICAgICAgIHZhciBwcmV0ZW1wID0gW107XHJcbiAgICAgICAgalF1ZXJ5KCdzZWxlY3RbbmFtZV49XCJwaHR5cGVcIl0nKS5lYWNoKGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgcHJldGVtcC5wdXNoKGpRdWVyeSh0aGlzKS52YWwoKSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgdmFyIGluZGV4ID0gMDtcclxuICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMgPT0gUGhvbmVPYmopIHtcclxuXHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpbmRleCA9IGluZGV4ICsgMTtcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgaWYgKHByZXRlbXBbaW5kZXhdICE9IHVuZGVmaW5lZCAmJiBwcmV0ZW1wW2luZGV4XSAhPSBudWxsICYmIHByZXRlbXBbaW5kZXhdICE9IFwiXCIpIHtcclxuICAgICAgICAgICAgdmFyIFBob25lVHlwZUlkID0gcHJldGVtcFtpbmRleF07XHJcbiAgICAgICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRQaG9uZVR5cGVEZXQoUGhvbmVUeXBlSWQpLnN1YnNjcmliZShcclxuICAgICAgICAgICAgICAgIChkYXRhKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgICAgICAvL1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04oZGF0YSk7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZywgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5EYXRhICE9IHVuZGVmaW5lZCAmJiByZXNwb25zZS5EYXRhICE9IG51bGwgJiYgcmVzcG9uc2UuRGF0YSAhPSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vYWxlcnQoaW5kZXggKyBcIiB8IFwiICsgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzW2luZGV4XS5Jc1NtcyArIFwiIHwgXCIgKyByZXNwb25zZS5EYXRhLlRleHQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLkRhdGEuVGV4dCA9PSBcIjFcIikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lc1tpbmRleF0uSXNTbXMgPSAxO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lc1tpbmRleF0ucGhwdWJsaXNoID0gMTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHNbdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzLmxlbmd0aCAtIDFdLnB1Ymxpc2ggPSAxO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzW2luZGV4XS5waHB1Ymxpc2ggPSAwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lc1tpbmRleF0uSXNTbXMgPSAwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlsc1t0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMubGVuZ3RoIC0gMV0ucHVibGlzaCA9IDA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vYWxlcnQodGhpcy5SRVMpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAvL3ZhciB0cmVldmlld0RhdGFTb3VyY2UgPSBqUXVlcnkoXCIjZ3JvdXBUcmVlXCIpLmRhdGEoXCJrZW5kb1RyZWVWaWV3XCIpLmRhdGFTb3VyY2UudmlldygpO1xyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIChlcnIpID0+IHtcclxuXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgKCkgPT4ge1xyXG5cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBlZGl0RW1haWxEZXQoRW1haWxPYmopOiBvYnNlcnZhYmxlIHtcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgIHZhciBpbmRleCA9IDA7XHJcbiAgICAgICAgdGhpcy5Jc1JlY29yZEVkaXRNb2RlID0gdHJ1ZTtcclxuICAgICAgICB0aGlzLkJUTl9QSEFERCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfQlROX1BIRURJVDtcclxuICAgICAgICBcclxuXHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5FbWFpbE1vZGVsLkVtYWlsID0gRW1haWxPYmouRW1haWw7XHJcbiAgICAgICAgdGhpcy5FbWFpbE1vZGVsLkVtYWlsTmFtZSA9IEVtYWlsT2JqLkVtYWlsTmFtZTtcclxuICAgICAgICB0aGlzLkVtYWlsTW9kZWwuTmV3c2xldHRlcmUgPSBFbWFpbE9iai5OZXdzbGV0dGVyZTtcclxuXHJcblxyXG4gICAgICAgIHRoaXMuRWRpdEVtYWlsRGF0YSA9IHt9O1xyXG4gICAgICAgIHRoaXMuRWRpdEVtYWlsRGF0YSA9IEVtYWlsT2JqO1xyXG4gICAgfVxyXG4gICAgZGVsRW1haWxEZXQoRW1haWxPYmopOiBvYnNlcnZhYmxlIHtcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgIHZhciBpbmRleCA9IDA7XHJcbiAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzID09IEVtYWlsT2JqKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpbmRleCA9IGluZGV4ICsgMTtcclxuXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzLnNwbGljZShpbmRleCwgMSk7XHJcbiAgICB9XHJcblxyXG4gICAgZWRpdEFkZHJlc3NEZXQoQWRkcmVzc09iaik6IG9ic2VydmFibGUge1xyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgdmFyIGluZGV4ID0gMDtcclxuICAgICAgICB0aGlzLklzUmVjb3JkRWRpdE1vZGUgPSB0cnVlO1xyXG4gICAgICAgIHRoaXMuQlROX1BIQUREID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9CVE5fUEhFRElUO1xyXG4gICAgICAgIFxyXG4gICAgICAgLy8gQWRkcmVzc09iai5DaXR5TmFtZSA9IGpRdWVyeShcIiNDaXR5XCIpLnZhbCgpO1xyXG5cclxuICAgICAgICB0aGlzLkFkZHJlc3MuU3RyZWV0ID0gQWRkcmVzc09iai5TdHJlZXQ7XHJcbiAgICAgICAgdGhpcy5BZGRyZXNzLlN0cmVldDIgPSBBZGRyZXNzT2JqLlN0cmVldDI7XHJcbiAgICAgICAgdGhpcy5BZGRyZXNzLkNpdHlOYW1lID0gQWRkcmVzc09iai5DaXR5TmFtZTtcclxuICAgICAgICB0aGlzLkFkZHJlc3MuWmlwID0gQWRkcmVzc09iai5aaXA7XHJcbiAgICAgICAgdGhpcy5BZGRyZXNzLkNvdW50cnlDb2RlID0gQWRkcmVzc09iai5Db3VudHJ5Q29kZTtcclxuICAgICAgICB0aGlzLkFkZHJlc3MuU3RhdGVJZCA9IEFkZHJlc3NPYmouU3RhdGVJZDtcclxuICAgICAgICB0aGlzLkFkZHJlc3MuQWRkcmVzc1R5cGVJZCA9IEFkZHJlc3NPYmouQWRkcmVzc1R5cGVJZDtcclxuICAgICAgICB0aGlzLkFkZHJlc3MuTWFpbkFkZHJlc3MgPSBBZGRyZXNzT2JqLk1haW5BZGRyZXNzO1xyXG4gICAgICAgIHRoaXMuQWRkcmVzcy5Gb3JEZWxpdmVyeSA9IEFkZHJlc3NPYmouRm9yRGVsaXZlcnk7XHJcblxyXG5cclxuICAgICAgICB0aGlzLkVkaXRBZGRyZXNzRGF0YSA9IHt9O1xyXG4gICAgICAgIHRoaXMuRWRpdEFkZHJlc3NEYXRhID0gQWRkcmVzc09iajtcclxuICAgIH1cclxuXHJcbiAgICBkZWxBZGRyZXNzRGV0KEFkZHJlc3NPYmopOiBvYnNlcnZhYmxlIHtcclxuICAgICAgIC8vIGRlYnVnZ2VyOyBcclxuICAgICAgICB2YXIgaW5kZXggPSAwO1xyXG4gICAgICAgIGpRdWVyeS5lYWNoKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3NlcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICBpZiAodGhpcyA9PSBBZGRyZXNzT2JqKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpbmRleCA9IGluZGV4ICsgMTtcclxuICAgICAgICB9KTtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMuc3BsaWNlKGluZGV4LCAxKTtcclxuICAgIH1cclxuICAgIGVkaXRQaG9uZURldChQaG9uZU9iaik6IG9ic2VydmFibGUge1xyXG4gICAgICAgIFxyXG4gICAgICAgIHZhciBpbmRleCA9IDA7XHJcbiAgICAgICAgdGhpcy5CVE5fUEhBREQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0JUTl9QSEVESVRcclxuICAgICAgICB2YXIgdGVtcCA9IFBob25lT2JqLlBob25lVHlwZUlkLnNwbGl0KCc7Jyk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5QaG9uZU1vZGVsLlBob25lVHlwZUlkID0gUGhvbmVPYmouUGhvbmVUeXBlICsgXCI7XCIgKyBQaG9uZU9iai5QaG9uZVR5cGVJZDtcclxuICAgICAgICBcclxuICAgICAgICB0aGlzLlBob25lTW9kZWwuUGhvbmVUeXBlID0gUGhvbmVPYmouUGhvbmVUeXBlO1xyXG4gICAgICAgIHRoaXMuUGhvbmVNb2RlbC5QcmVmaXggPSBQaG9uZU9iai5QcmVmaXg7XHJcbiAgICAgICAgdGhpcy5QaG9uZU1vZGVsLkFyZWEgPSBQaG9uZU9iai5BcmVhO1xyXG4gICAgICAgIHRoaXMuUGhvbmVNb2RlbC5QaG9uZSA9IFBob25lT2JqLlBob25lO1xyXG4gICAgICAgIHRoaXMuUGhvbmVNb2RlbC5Jc1NtcyA9IFBob25lT2JqLklzU21zO1xyXG4gICAgICAgIHRoaXMuUGhvbmVNb2RlbC5Db21tZW50cyA9IFBob25lT2JqLkNvbW1lbnRzO1xyXG4gICAgICAgIHRoaXMuRWRpdFBob25lRGF0YSA9IHt9O1xyXG4gICAgICAgIHRoaXMuRWRpdFBob25lRGF0YSA9IFBob25lT2JqO1xyXG4gICAgfVxyXG4gICAgZGVsUGhvbmVEZXQoUGhvbmVPYmopOiBvYnNlcnZhYmxlIHtcclxuICAgICAgICBcclxuICAgICAgICB2YXIgaW5kZXggPSAwO1xyXG4gICAgICAgIGpRdWVyeS5lYWNoKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICBpZiAodGhpcyA9PSBQaG9uZU9iaikge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaW5kZXggPSBpbmRleCArIDE7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzLnNwbGljZShpbmRleCwgMSk7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIGdldFNlbGVjdGVkR3JvdXBzKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckdyb3VwcyA9IFtdO1xyXG4gICAgICAgIHZhciBfQ2hlY2tlZEdyb3VwcyA9IFtdO1xyXG4gICAgICAgIGlmICh0aGlzLklzU2hvd0FsbCA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICBLZW5kb191dGlsaXR5LmNoZWNrZWROb2RlSWRzKGpRdWVyeShcIiNncm91cFRyZWVcIikuZGF0YShcImtlbmRvVHJlZVZpZXdcIikuZGF0YVNvdXJjZS52aWV3KCksIF9DaGVja2VkR3JvdXBzKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgICAgIEtlbmRvX3V0aWxpdHkuY2hlY2tlZE5vZGVJZHMoalF1ZXJ5KFwiI2dyb3VwVHJlZTFcIikuZGF0YShcImtlbmRvVHJlZVZpZXdcIikuZGF0YVNvdXJjZS52aWV3KCksIF9DaGVja2VkR3JvdXBzKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7aTxfQ2hlY2tlZEdyb3Vwcy5sZW5ndGg7aSsrKXtcclxuICAgICAgICAgICAgdmFyIEdPYmogPSB7fTtcclxuICAgICAgICAgICAgR09iai5DdXN0b21lckdlbmVyYWxHcm91cElkID0gX0NoZWNrZWRHcm91cHNbaV07XHJcbiAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckdyb3Vwcy5wdXNoKEdPYmopO1xyXG4gICAgIFxyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgIH1cclxuXHJcbiAgICBNb3JlKCk6IG9ic2VydmFibGUge1xyXG4gICAgICAgLy8gYWxlcnQoXCJjYWxsXCIpO1xyXG4gICAgICAgIGlmICh0aGlzLlNob3dNb3JlID09IHRydWUpIHtcclxuICAgICAgICAgICAgdGhpcy5TaG93TW9yZSA9IGZhbHNlO1xyXG5cclxuICAgICAgICAgICAgLy90aGlzLlNob3dNb3JlVGV4dCA9IFwiTW9yZVwiO1xyXG4gICAgICAgICAgICB0aGlzLlNob3dNb3JlVGV4dCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfTE5LX0xCTF9NT1JFO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICB0aGlzLlNob3dNb3JlID0gdHJ1ZTtcclxuICAgICAgICAvL3RoaXMuU2hvd01vcmVUZXh0ID0gXCJMZXNzXCI7IFxyXG4gICAgICAgIHRoaXMuU2hvd01vcmVUZXh0ID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9MTktfTEJMX0xFU1M7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgYmluZEdyb3VwVHJlZShJc3Nob3dhbGwpOiBvYnNlcnZhYmxlIHtcclxuICAgICAgICB0aGlzLl9jdXN0b21lclNlcnZpY2UuR2V0R2VuZXJhbEdyb3VwcyhJc3Nob3dhbGwpLnN1YnNjcmliZShcclxuICAgICAgICAgICAgKGRhdGEpID0+IHtcclxuICAgICAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICAvL1xyXG4gICAgICAgICAgICAgICAgLy9hbGVydChJc3Nob3dhbGwpO1xyXG4gICAgICAgICAgICAgICAgaWYgKElzc2hvd2FsbCA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeShcIiNncm91cFRyZWVcIikuaHRtbChcIkxvZGluZy4uLlwiKTtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgcmVzID0galF1ZXJ5LnBhcnNlSlNPTihkYXRhKS5EYXRhXHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5KFwiI2dyb3VwVHJlZVwiKS5rZW5kb1RyZWVWaWV3KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbG9hZE9uRGVtYW5kOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjaGVja2JveGVzOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja0NoaWxkcmVuOiB0cnVlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vY2hlY2s6IHRoaXMub25Hcm91cFNlbGVjdCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGF0YVNvdXJjZTogcmVzXHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIGdycGlkcyA9IFwiXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5tb2RlbElucHV0LkN1c3RvbWVyR3JvdXBzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGdycGlkcyArPSB0aGlzLkN1c3RvbWVyR2VuZXJhbEdyb3VwSWQgKyBcIjtcIjtcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoZ3JwaWRzLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgS2VuZG9fdXRpbGl0eS5jaGVja2luZ05vZGVJZHMoalF1ZXJ5KFwiI2dyb3VwVHJlZVwiKS5kYXRhKFwia2VuZG9UcmVlVmlld1wiKS5kYXRhU291cmNlLnZpZXcoKSwgZ3JwaWRzLnN1YnN0cmluZygwLCBncnBpZHMubGVuZ3RoIC0gMSkpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5KFwiI2dyb3VwVHJlZTFcIikuaHRtbChcIkxvZGluZy4uLlwiKTtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgcmVzID0galF1ZXJ5LnBhcnNlSlNPTihkYXRhKS5EYXRhXHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5KFwiI2dyb3VwVHJlZTFcIikua2VuZG9UcmVlVmlldyh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRPbkRlbWFuZDogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tib3hlczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tDaGlsZHJlbjogdHJ1ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2NoZWNrOiB0aGlzLm9uR3JvdXBTZWxlY3QsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhdGFTb3VyY2U6IHJlc1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBncnBpZHMgPSBcIlwiO1xyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckdyb3VwcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBncnBpZHMgKz0gdGhpcy5DdXN0b21lckdlbmVyYWxHcm91cElkICsgXCI7XCI7XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGdycGlkcy5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEtlbmRvX3V0aWxpdHkuY2hlY2tpbmdOb2RlSWRzKGpRdWVyeShcIiNncm91cFRyZWUxXCIpLmRhdGEoXCJrZW5kb1RyZWVWaWV3XCIpLmRhdGFTb3VyY2UudmlldygpLCBncnBpZHMuc3Vic3RyaW5nKDAsIGdycGlkcy5sZW5ndGggLSAxKSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvL3ZhciB0cmVldmlld0RhdGFTb3VyY2UgPSBqUXVlcnkoXCIjZ3JvdXBUcmVlXCIpLmRhdGEoXCJrZW5kb1RyZWVWaWV3XCIpLmRhdGFTb3VyY2UudmlldygpO1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAoZXJyKSA9PiB7XHJcblxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAoKSA9PiB7XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgKTtcclxuICAgIH1cclxuICAgIEdldERhdGFGb3JTZWFyY2goZXZlbnQ6IGFueSk6IG9ic2VydmFibGUge1xyXG4gICAgICAgIFxyXG4gICAgICAgIC8vdGhpcy5TZWFyY2hWYWwgPSBqUXVlcnkoXCIjU2VhcmNodHh0XCIpLnZhbCgpO1xyXG4gICAgICAgIC8vYWxlcnQoZXZlbnQua2V5Q29kZSk7XHJcbiAgICAgICAgLy9pZiAodGhpcy5TZWFyY2hWYWwgIT0gdW5kZWZpbmVkICYmIHRoaXMuU2VhcmNoVmFsICE9IFwiXCIgJiYgdGhpcy5TZWFyY2hWYWwgIT0gbnVsbCAmJiBldmVudC5rZXlDb2RlID09IDEzKSB7XHJcbiAgICAgICAgICAgIC8vYWxlcnQodGhpcy5hdXRvY29tcGxldGVTZWxlY3QgKyBcIiBcIiArIHRoaXMuYXV0b2NvbXBsZXRlTm9SZXN1bHRzKTtcclxuICAgICAgICAvLyAgICB0aGlzLkVudGVyQ291bnQrKztcclxuICAgICAgICAvLyAgICBpZiAodGhpcy5FbnRlckNvdW50ID49IDIpIHtcclxuICAgICAgICAvLyAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkdldENvbXBsZXRlU2VhcmNoKHRoaXMuU2VhcmNoVmFsKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAvLyAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgLy8gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgYWxlcnQocmVzcG9uc2UuRXJyTXNnKTtcclxuICAgICAgICAvLyAgICAgICAgICAgIH1cclxuICAgICAgICAvLyAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgIC8vICAgICAgICAgICAgICAgIHRoaXMuQ3VzdExpc3QgPSB7fTtcclxuICAgICAgICAvLyAgICAgICAgICAgICAgICB0aGlzLkN1c3RMaXN0ID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAvLyAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuRGF0YSAhPSBudWxsICYmIHJlc3BvbnNlLkRhdGEgIT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgIHRoaXMuY3VzdFNlYXJjaERhdGEgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICBqUXVlcnkoXCIjQ3VzdE1vZGFsXCIpLm1vZGFsKFwic2hvd1wiKTtcclxuXHJcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyAgICAgICAgICAgIH1cclxuICAgICAgICAvLyAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgLy8gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgLy8gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAvLyAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIC8vICAgICAgICB9KTtcclxuICAgICAgICAvLyAgICAgICAgdGhpcy5FbnRlckNvdW50ID0gMDtcclxuICAgICAgICAvLyAgICB9XHJcbiAgICAgICAgICAgICAgIFxyXG4gICAgICAgIC8vfVxyXG4gICAgICAgIC8vdGhpcy5TZWFyY2hWYWwgPSBcIlwiO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICBuZ09uSW5pdCgpIHtcclxuICAgICAgICBcclxuICAgICAgIC8vIGRlYnVnZ2VyO1xyXG4gICAgICAgIC8vYm9vdGJveC5hbGVydChcIlRoaXMgaXMgdGhlIGRlZmF1bHQgYWxlcnQhXCIpO1xyXG4gICAgICAgIGlmIChsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImxhbmdcIikgPT0gXCJcIikge1xyXG4gICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImxhbmdcIiwgXCJlblwiKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHRoaXMuX3Jlc291cmNlU2VydmljZS5nZXRDb29raWUoXCJsYW5nXCIpID09IFwiXCIpIHtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5zZXRDb29raWUoXCJsYW5nXCIsIFwiZW5cIiwgMTApO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLklzQ2FuY2VsID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5zaG93aGlkZUdyb3VwcygpO1xyXG4gICAgICAgIHRoaXMuSXNGaWxlQXN0eHRTaG93ID0gdHJ1ZTtcclxuICAgICAgICBcclxuICAgICAgICAvL3RoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkID0gLTE7XHJcbiAgICAgICAgXHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkID49IDApIHtcclxuICAgICAgICAgICAgLy90aGlzLklzRmlsZUFzdHh0U2hvdyA9IGZhbHNlO1xyXG4gICAgICAgICAgICB0aGlzLmVkaXRDdXN0RGV0KHRoaXMubW9kZWxJbnB1dCk7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICB0aGlzLlNBVkVfQlROX1RFWFQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0JUTl9VUERBVEU7XHJcbiAgICAgICAgICAgIC8vdGhpcy5BRERfTkVXX0NVU1RfVEVYVCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfTEJMX1VQREFURV9DVVNUO1xyXG4gICAgICAgICAgICAvL3RoaXMuQ1NTVEVYVCA9IFwibWRpLWNvbnRlbnQtYWRkXCI7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzLmxlbmd0aCA9PSAwKSB7XHJcbiAgICAgICAgICAgICAgICB2YXIgZW1waWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImVtcGxveWVlaWRcIik7XHJcblxyXG4gICAgICAgICAgICAgICAgdmFyIGNjb2RlID0gdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmdldENvb2tpZShlbXBpZCArIFwiY2NvZGVcIik7XHJcbiAgICAgICAgICAgICAgICBpZiAoY2NvZGUubGVuZ3RoID4gMClcclxuICAgICAgICAgICAgICAgICAgICBjY29kZSA9IGNjb2RlLnN1YnN0cmluZygxLCBjY29kZS5sZW5ndGgpO1xyXG4gICAgICAgICAgICAgICAgdmFyIGFkaWQgPSBcIlwiO1xyXG4gICAgICAgICAgICAgICAgdmFyIGNvbXB0ZXh0ID0gXCJIb21lXCI7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkNvbXBhbnkgIT0gXCJcIiAmJiB0aGlzLm1vZGVsSW5wdXQuQ29tcGFueSAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0LkNvbXBhbnkgIT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbXB0ZXh0ID0gXCJXb3JrXCI7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLl9BZGRyZXNzVHlwZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5UZXh0ID09IGNvbXB0ZXh0KSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhZGlkID0gdGhpcy5WYWx1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3NlcyA9IFt7IFN0cmVldDogXCJcIiwgU3RyZWV0MjogXCJcIiwgQ2l0eU5hbWU6IFwiXCIsIFppcDogXCJcIiwgQ291bnRyeUNvZGU6IGNjb2RlLCBTdGF0ZUlkOiBcIlwiLCBBZGRyZXNzVHlwZUlkOiBhZGlkLCBGb3JEZWxpdmVyeTogZmFsc2UsIE1haW5BZGRyZXNzOiBmYWxzZSwgTWFpbk9yZGVyOiBcIk1haW5BZGRyMVwiLCBEZWx2cnlPcmRlcjogXCJEZWx2cnkxXCIgfV07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdGhpcy5DdXN0SWRUZXh0ID0gXCIoIFwiICsgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQgKyBcIiApXCJcclxuICAgICAgICAgICAgdGhpcy5Jc0ZpbGVBc3R4dFNob3cgPSBmYWxzZTtcclxuICAgICAgICAgICAgLy90aGlzLkhpZGVTaG93RmlsZUFzdHh0KCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuTGFuZyA9IHRoaXMuX3Jlc291cmNlU2VydmljZS5nZXRDb29raWUoXCJsYW5nXCIpO1xyXG4gICAgICAgIGlmICh0aGlzLkxhbmcubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICB0aGlzLkxhbmcgPSB0aGlzLkxhbmcuc3Vic3RyaW5nKDEsIHRoaXMuTGFuZy5sZW5ndGgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLkhpZGVTaG93RmlsZUFzdHh0KCk7XHJcbiAgICAgICAvL3RoaXMuUkVTID0galF1ZXJ5LnBhcnNlSlNPTih0aGlzLl9jdXN0b21lclNlcnZpY2UuR2V0TGFuZ1Jlcyh0aGlzLkZvcm10eXBlLCB0aGlzLkxhbmcpKS5EYXRhOyAvL2pRdWVyeS5wYXJzZUpTT04obG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJsYW5ncmVzb3VyY2VcIikpO1xyXG4gICAgICAgIFxyXG4gICAgICAgIGlmICh0aGlzLkxhbmcgPT0gXCJoZVwiKSB7XHJcbiAgICAgICAgICAgIHRoaXMuS2VuZG9SVExDU1MgPSBcImstcnRsXCI7XHJcbiAgICAgICAgICAgIHRoaXMuQ0hBTkdFRElSID0gXCJydGxtb2RhbFwiO1xyXG4gICAgICAgICAgICB0aGlzLkNoYW5nZURpYWxvZyA9IFwiaW5wdXRfcmlnaHRcIjtcclxuICAgICAgICAgICAgLy9qUXVlcnkoXCIuYm9vdGJveC1jbG9zZS1idXR0b25cIikuY3NzKFwiZmxvYXRcIiwgXCJsZWZ0IWltcG9ydGFudFwiKTtcclxuICAgICAgICAgICAgLy9qUXVlcnkoXCIubW9kYWwtZm9vdGVyIGJ1dHRvbjpiZWZvcmVcIikuY3NzKFwiZmxvYXRcIiwgXCJsZWZ0IWltcG9ydGFudFwiKTtcclxuICAgICAgICAgICAgLy9qUXVlcnkoXCIubW9kYWwtZm9vdGVyIGJ1dHRvbjphZnRlclwiKS5jc3MoXCJmbG9hdFwiLCBcImxlZnQhaW1wb3J0YW50XCIpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5DSEFOR0VESVIgPSBcImx0cm1vZGFsXCI7XHJcbiAgICAgICAgICAgIHRoaXMuQ2hhbmdlRGlhbG9nID0gXCJpbnB1dF9sZWZ0XCI7XHJcbiAgICAgICAgfVxyXG5cclxuXHJcbiAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuR2V0TGFuZ1Jlcyh0aGlzLkZvcm10eXBlLCB0aGlzLkxhbmcpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZywgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICB9XHJcbiAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgIHRoaXMuUkVTID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgdGhpcy5TaG93TW9yZVRleHQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0xOS19MQkxfTU9SRTtcclxuICAgICAgICAgICAgICAgdGhpcy5Hcm91cFRleHQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0xCTF9TSE9XR1JPVVBTO1xyXG4gICAgICAgICAgICAgICB0aGlzLlNBVkVfQlROX1RFWFQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0JUTl9TQVZFO1xyXG4gICAgICAgICAgICAgICB0aGlzLkFERF9ORVdfQ1VTVF9URVhUID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9MQkxfTkVXX0NVU1Q7XHJcbiAgICAgICAgICAgICAgIHRoaXMuRklMRUFTX0JUTl9URVhUID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9CVE5fRklMRUFTO1xyXG4gICAgICAgICAgICAgICAvL2FsZXJ0KHRoaXMuUkVTKTtcclxuICAgICAgICAgICB9XHJcbiAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICB9KTtcclxuICAgICAgIC8vdGhpcy5TaG93TW9yZVRleHQgPSBcIk1vcmVcIjtcclxuICAgICAgIFxyXG4gICAgICAgLy8vL0NpdGllc1xyXG4gICAgICAgdmFyIENvdW50cnlDb2RlID0gdGhpcy5BZGRyZXNzLkNvdW50cnlDb2RlO1xyXG4gICAgICAgdmFyIFN0YXRlTmFtZSA9IHRoaXMuQWRkcmVzcy5TdGF0ZUlkO1xyXG4gICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkdldENpdGllcyhDb3VudHJ5Q29kZSwgU3RhdGVOYW1lKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgIH1cclxuICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgdmFyIHR5cGVhaGVhZFNvdXJjZSA9IFtdO1xyXG4gICAgICAgICAgICAgICBqUXVlcnkuZWFjaChyZXNwb25zZS5EYXRhLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICB2YXIgbmV3dGVtcCA9IHt9O1xyXG4gICAgICAgICAgICAgICAgICAgbmV3dGVtcC5pZCA9IHRoaXMuVmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICBuZXd0ZW1wLm5hbWUgPSB0aGlzLlRleHQ7XHJcbiAgICAgICAgICAgICAgICAgICB0eXBlYWhlYWRTb3VyY2UucHVzaChuZXd0ZW1wKTtcclxuICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgIHRoaXMuX0NpdGllcyA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgIGpRdWVyeSgnI0NpdHknKS50eXBlYWhlYWQoe1xyXG4gICAgICAgICAgICAgICAgICAgLy9kYXRhOiB0aGlzLl9DaXRpZXMsXHJcbiAgICAgICAgICAgICAgICAgICBzb3VyY2U6IHR5cGVhaGVhZFNvdXJjZSxcclxuICAgICAgICAgICAgICAgICAgIC8vZGlzcGxheTogXCJ0ZXh0XCIsXHJcbiAgICAgICAgICAgICAgICAgICBkYXRhVHlwZTogXCJKU09OXCIsXHJcbiAgICAgICAgICAgICAgICAgICAvL2hpbnQ6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAvL2hpZ2hsaWdodDogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgIC8vbWluTGVuZ3RoOiAxLFxyXG4gICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICB9XHJcbiAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICB9KTtcclxuXHJcbiAgICAgICBcclxuICAgICAgIFxyXG4gICAgICAgICAgXHJcblxyXG5cclxuICAgICAgICB0aGlzLmxhbmd1YWdlQXJyYXkgPSB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuR2V0QXZhaWxhYmxlTGFuZ3VhZ2VzKCk7XHJcbiAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkdldEN1c3RvbWVyVHlwZXMoKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIHZhciByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcCk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZywgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9DdXN0VHlwZXMgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclR5cGUgPT0gXCJcIiB8fCB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJUeXBlID09IHVuZGVmaW5lZCB8fCB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJUeXBlID09IG51bGwpIHtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgQ3VzdHR5cGVJZDtcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLl9DdXN0VHlwZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgQ3VzdHR5cGVJZCA9IHRoaXMuVmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJUeXBlID0gQ3VzdHR5cGVJZDtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgXHJcbiAgICAgICAgLy8vL1NvdXJjZXNcclxuICAgICAgICB0aGlzLl9jdXN0b21lclNlcnZpY2UuR2V0U291cmNlcygpLnN1YnNjcmliZShyZXNwPT4ge1xyXG4gICAgICAgICAgICB2YXIgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3ApO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fU291cmNlcyA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkNhbWVGcm9tQ3VzdG9tZXIgPT0gXCJcIiB8fCB0aGlzLm1vZGVsSW5wdXQuQ2FtZUZyb21DdXN0b21lciA9PSB1bmRlZmluZWQgfHwgdGhpcy5tb2RlbElucHV0LkNhbWVGcm9tQ3VzdG9tZXIgPT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBTb3VyY2U7XHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5fU291cmNlcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBTb3VyY2UgPSB0aGlzLlZhbHVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkNhbWVGcm9tQ3VzdG9tZXIgPSBTb3VyY2U7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIC8vR2V0RW1wbG95ZWVzXHJcbiAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkdldEVtcGxveWVlcygpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX0VtcGxveWVlcyA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LmVtcGxveWVlaWQgPT0gXCJcIiB8fCB0aGlzLm1vZGVsSW5wdXQuZW1wbG95ZWVpZCA9PSB1bmRlZmluZWQgfHwgdGhpcy5tb2RlbElucHV0LmVtcGxveWVlaWQgPT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBlbXBpZDtcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLl9FbXBsb3llZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZW1waWQgPSB0aGlzLlZhbHVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LmVtcGxveWVlaWQgPSBlbXBpZDtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuICAgICAgICAvL0dldFN1ZmZpeGVzXHJcbiAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkdldFN1ZmZpeGVzKCkuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fU3VmZml4ZXMgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIC8vR2V0UGhvbmVUeXBlc1xyXG4gICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRQaG9uZVR5cGVzKCkuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgIC8vIGRlYnVnZ2VyO1xyXG4gICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fUGhvbmVUeXBlcyA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICB2YXIgcGhpZCA9IFwiXCI7XHJcbiAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLl9QaG9uZVR5cGVzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuVGV4dCA9PSBcIkNlbGxQaG9uZVwiKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwaGlkID0gdGhpcy5WYWx1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzWzBdLlBob25lVHlwZUlkID0gcGhpZDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuXHJcblxyXG4gICAgICAgIHZhciBlcHVibGlzaCA9IDA7XHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lcy5sZW5ndGggPT0gMCkge1xyXG4gICAgICAgICAgICB2YXIgcGhpZCA9IFwiXCI7XHJcblxyXG4gICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLl9QaG9uZVR5cGVzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5UZXh0ID09IFwiQ2VsbFBob25lXCIpIHtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgcGhpZCA9IHRoaXMuVmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgZXB1Ymxpc2ggPSAxO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXMgPSBbeyBQaG9uZVR5cGVJZDogcGhpZCwgUHJlZml4OiBcIlwiLCBBcmVhOiBcIlwiLCBQaG9uZTogXCJcIiwgSXNTbXM6IGVwdWJsaXNoLCBDb21tZW50czogXCJcIiwgcGhwdWJsaXNoOiBlcHVibGlzaCwgU01TT3JkZXI6IFwiU01TMVwiLCBQdWJsaXNoT3JkZXI6XCJQdWIxXCIgfV07XHJcbiAgICAgICAgICAgIC8vIGRlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMubGVuZ3RoID09IDApIHtcclxuICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzID0gW3sgRW1haWw6IFwiXCIsIEVtYWlsTmFtZTogdGhpcy5tb2RlbElucHV0LkZpbGVBcywgTmV3c2xldHRlcmU6IGZhbHNlLCBwdWJsaXNoOiBlcHVibGlzaCwgTmV3c09yZGVyOiBcIk5ld3MxXCIsIEVQdWJsaXNoT3JkZXI6XCJFUHViMVwiIH1dXHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvL0dldEFkZHJlc3NUeXBlc1xyXG4gICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRBZGRyZXNzVHlwZXMoKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZywgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9BZGRyZXNzVHlwZXMgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgIHZhciBhZGlkID0gXCJcIjtcclxuICAgICAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMuX0FkZHJlc3NUeXBlcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLlRleHQgPT0gXCJIb21lXCIpIHtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFkaWQgPSB0aGlzLlZhbHVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzWzBdLkFkZHJlc3NUeXBlSWQgPSBhZGlkO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIC8vR3JvdXBzXHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkdldEdyb3VwcygpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX0dyb3VwcyA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgLy8vL0NvdW50cmllc1xyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRDb3VudHJpZXMoKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZywgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9Db3VudHJpZXMgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIC8vLy9TdGF0ZXNcclxuICAgICAgICB2YXIgQ291bnRyeUNvZGU9IHRoaXMuQWRkcmVzcy5Db3VudHJ5Q29kZTtcclxuICAgICAgICB0aGlzLl9jdXN0b21lclNlcnZpY2UuR2V0U3RhdGVzKENvdW50cnlDb2RlKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZywgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9TdGF0ZXMgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIFxyXG4gICAgICAgIFxyXG4gICAgICAgIC8vVHJlZSBHcm91cFxyXG5cclxuICAgICAgICAvL3RoaXMuYmluZEdyb3VwVHJlZSh0aGlzLklzU2hvd0FsbCk7XHJcbiAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkdldEdlbmVyYWxHcm91cHModGhpcy5Jc1Nob3dBbGwpLnN1YnNjcmliZShcclxuICAgICAgICAgICAgKGRhdGEpID0+IHtcclxuICAgICAgICAgICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5Jc1Nob3dBbGwgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkoXCIjZ3JvdXBUcmVlXCIpLmh0bWwoXCJMb2RpbmcuLi5cIik7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIHJlcyA9IGpRdWVyeS5wYXJzZUpTT04oZGF0YSkuRGF0YVxyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeShcIiNncm91cFRyZWVcIikua2VuZG9UcmVlVmlldyh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRPbkRlbWFuZDogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tib3hlczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tDaGlsZHJlbjogdHJ1ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2NoZWNrOiB0aGlzLm9uR3JvdXBTZWxlY3QsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhdGFTb3VyY2U6IHJlc1xyXG5cclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgZ3JwaWRzID0gXCJcIjtcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJHcm91cHMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZ3JwaWRzICs9IHRoaXMuQ3VzdG9tZXJHZW5lcmFsR3JvdXBJZCArIFwiO1wiO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChncnBpZHMubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBLZW5kb191dGlsaXR5LmNoZWNraW5nTm9kZUlkcyhqUXVlcnkoXCIjZ3JvdXBUcmVlXCIpLmRhdGEoXCJrZW5kb1RyZWVWaWV3XCIpLmRhdGFTb3VyY2UudmlldygpLCBncnBpZHMuc3Vic3RyaW5nKDAsIGdycGlkcy5sZW5ndGggLSAxKSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkoXCIjZ3JvdXBUcmVlMVwiKS5odG1sKFwiTG9kaW5nLi4uXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciByZXMgPSBqUXVlcnkucGFyc2VKU09OKGRhdGEpLkRhdGFcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkoXCIjZ3JvdXBUcmVlMVwiKS5rZW5kb1RyZWVWaWV3KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbG9hZE9uRGVtYW5kOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjaGVja2JveGVzOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja0NoaWxkcmVuOiB0cnVlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vY2hlY2s6IHRoaXMub25Hcm91cFNlbGVjdCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGF0YVNvdXJjZTogcmVzXHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIGdycGlkcyA9IFwiXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5tb2RlbElucHV0LkN1c3RvbWVyR3JvdXBzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGdycGlkcyArPSB0aGlzLkN1c3RvbWVyR2VuZXJhbEdyb3VwSWQgKyBcIjtcIjtcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoZ3JwaWRzLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgS2VuZG9fdXRpbGl0eS5jaGVja2luZ05vZGVJZHMoalF1ZXJ5KFwiI2dyb3VwVHJlZTFcIikuZGF0YShcImtlbmRvVHJlZVZpZXdcIikuZGF0YVNvdXJjZS52aWV3KCksIGdycGlkcy5zdWJzdHJpbmcoMCwgZ3JwaWRzLmxlbmd0aCAtIDEpKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgKGVycikgPT4ge1xyXG5cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgKCkgPT4ge1xyXG5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgLy9hbGVydChtb21lbnQoKS5mb3JtYXQoJ0QgTU1NIFlZWVknKSk7ICAgICAgIFxyXG4gICAgICAgLy8gdGhpcy5iYXNlVXJsICsgXCJEcm9wZG93bi9CaW5kQXV0b0NvbXBsZXRlU3JjaFwiXHJcbiAgICAgICAgdmFyIFNyY2hEYXRhID0gbnVsbDtcclxuICAgICAgICAgICBcclxuICAgICAgICAvL2FsZXJ0KCdIaScpO1xyXG4gICAgICAgIGpRdWVyeShcIiNFbWFpbFRhYmxlIHRib2R5IHRyIHRkIGFbbmFtZT1kZWxFYnRuXVwiKS5ub3QoXCI6bGFzdFwiKS5oaWRlKCk7XHJcbiAgICAgICAgalF1ZXJ5KFwiI0VtYWlsVGFibGUgdGJvZHkgdHIgYVtuYW1lPWFkZEVidG5dXCIpLm5vdChcIjpsYXN0XCIpLnNob3coKTtcclxuICAgICAgICAvLyQoJy5tb2RhbCcpLm1vZGFsKCk7XHJcbiAgICAgICAgXHJcbiAgICB9XHJcbn1cclxuIl19
