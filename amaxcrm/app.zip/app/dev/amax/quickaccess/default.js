System.register(["angular2/core", "../../amaxUtil"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, amaxUtil_1;
    var defaultComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (amaxUtil_1_1) {
                amaxUtil_1 = amaxUtil_1_1;
            }],
        execute: function() {
            defaultComponent = (function () {
                function defaultComponent() {
                    //document.addEventListener('myCustomeEvt',this.onMyCustomeEvt);
                    amaxUtil_1.onEvent.listenEvent('myCustomeEvt', this.onMyCustomeEvt);
                }
                defaultComponent.prototype.onMyCustomeEvt = function (a) {
                    console.log(arguments.length);
                    console.log(a.evtData);
                };
                defaultComponent.prototype.ngOnDestroy = function () {
                    //document.removeEventListener('myCustomeEvt',this.onMyCustomeEvt);
                    amaxUtil_1.onEvent.removeEvtListner('myCustomeEvt', this.onMyCustomeEvt);
                };
                defaultComponent = __decorate([
                    core_1.Component({
                        template: "\n        <h1>Default Component</h1>\n        \n    "
                    }), 
                    __metadata('design:paramtypes', [])
                ], defaultComponent);
                return defaultComponent;
            }());
            exports_1("defaultComponent", defaultComponent);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldi9hbWF4L3F1aWNrYWNjZXNzL2RlZmF1bHQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7WUFRQTtnQkFDSTtvQkFDSSxnRUFBZ0U7b0JBQ2hFLGtCQUFPLENBQUMsV0FBVyxDQUFDLGNBQWMsRUFBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7Z0JBQzVELENBQUM7Z0JBQ0QseUNBQWMsR0FBZCxVQUFlLENBQUs7b0JBQ2hCLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUM5QixPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztnQkFDM0IsQ0FBQztnQkFFRCxzQ0FBVyxHQUFYO29CQUNJLG1FQUFtRTtvQkFDbkUsa0JBQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxjQUFjLEVBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO2dCQUNqRSxDQUFDO2dCQW5CTDtvQkFBQyxnQkFBUyxDQUFDO3dCQUNQLFFBQVEsRUFBQyxzREFHUjtxQkFDSixDQUFDOztvQ0FBQTtnQkFlRix1QkFBQztZQUFELENBZEEsQUFjQyxJQUFBO1lBZEQsK0NBY0MsQ0FBQSIsImZpbGUiOiJkZXYvYW1heC9xdWlja2FjY2Vzcy9kZWZhdWx0LmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtDb21wb25lbnQsIE9uRGVzdHJveX0gZnJvbSBcImFuZ3VsYXIyL2NvcmVcIjtcbmltcG9ydCB7b25FdmVudH0gZnJvbSBcIi4uLy4uL2FtYXhVdGlsXCI7XG5AQ29tcG9uZW50KHtcbiAgICB0ZW1wbGF0ZTpgXG4gICAgICAgIDxoMT5EZWZhdWx0IENvbXBvbmVudDwvaDE+XG4gICAgICAgIFxuICAgIGBcbn0pXG5leHBvcnQgY2xhc3MgZGVmYXVsdENvbXBvbmVudCBpbXBsZW1lbnRzIE9uRGVzdHJveXtcbiAgICBjb25zdHJ1Y3Rvcigpe1xuICAgICAgICAvL2RvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ215Q3VzdG9tZUV2dCcsdGhpcy5vbk15Q3VzdG9tZUV2dCk7XG4gICAgICAgIG9uRXZlbnQubGlzdGVuRXZlbnQoJ215Q3VzdG9tZUV2dCcsdGhpcy5vbk15Q3VzdG9tZUV2dCk7XG4gICAgfVxuICAgIG9uTXlDdXN0b21lRXZ0KGE6YW55KXtcbiAgICAgICAgY29uc29sZS5sb2coYXJndW1lbnRzLmxlbmd0aCk7XG4gICAgICAgIGNvbnNvbGUubG9nKGEuZXZ0RGF0YSk7XG4gICAgfVxuXG4gICAgbmdPbkRlc3Ryb3koKSB7XG4gICAgICAgIC8vZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcignbXlDdXN0b21lRXZ0Jyx0aGlzLm9uTXlDdXN0b21lRXZ0KTtcbiAgICAgICAgb25FdmVudC5yZW1vdmVFdnRMaXN0bmVyKCdteUN1c3RvbWVFdnQnLHRoaXMub25NeUN1c3RvbWVFdnQpO1xuICAgIH1cbn0iXX0=
