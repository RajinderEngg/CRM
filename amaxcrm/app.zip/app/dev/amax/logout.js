System.register(["angular2/core"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1;
    var AmaxLogoutComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            }],
        execute: function() {
            //import {ResourceService} from "../services/ResourceService";
            AmaxLogoutComponent = (function () {
                function AmaxLogoutComponent() {
                }
                AmaxLogoutComponent.prototype.ngOnInit = function () {
                    //debugger;
                    //this._resourceService.deleteCookie("RememberKey");
                };
                AmaxLogoutComponent = __decorate([
                    core_1.Component({
                        template: "<h1>Cleaning user information...</h1>"
                    }), 
                    __metadata('design:paramtypes', [])
                ], AmaxLogoutComponent);
                return AmaxLogoutComponent;
            }());
            exports_1("AmaxLogoutComponent", AmaxLogoutComponent);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldi9hbWF4L2xvZ291dC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztZQUNBLDhEQUE4RDtZQUs5RDtnQkFDSTtnQkFDQSxDQUFDO2dCQUdELHNDQUFRLEdBQVI7b0JBQ0ksV0FBVztvQkFDWCxvREFBb0Q7Z0JBQ3hELENBQUM7Z0JBWkw7b0JBQUMsZ0JBQVMsQ0FBQzt3QkFDUCxRQUFRLEVBQUUsdUNBQXVDO3FCQUVwRCxDQUFDOzt1Q0FBQTtnQkFVRiwwQkFBQztZQUFELENBVEEsQUFTQyxJQUFBO1lBVEQscURBU0MsQ0FBQSIsImZpbGUiOiJkZXYvYW1heC9sb2dvdXQuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge0NvbXBvbmVudCwgT25Jbml0fSBmcm9tIFwiYW5ndWxhcjIvY29yZVwiO1xuLy9pbXBvcnQge1Jlc291cmNlU2VydmljZX0gZnJvbSBcIi4uL3NlcnZpY2VzL1Jlc291cmNlU2VydmljZVwiO1xuQENvbXBvbmVudCh7XG4gICAgdGVtcGxhdGU6IFwiPGgxPkNsZWFuaW5nIHVzZXIgaW5mb3JtYXRpb24uLi48L2gxPlwiXG4gICAgXG59KVxuZXhwb3J0IGNsYXNzIEFtYXhMb2dvdXRDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXR7XG4gICAgY29uc3RydWN0b3IoKSB7ICAvKnByaXZhdGUgX3Jlc291cmNlU2VydmljZTogUmVzb3VyY2VTZXJ2aWNlKi9cbiAgICB9XG5cblxuICAgIG5nT25Jbml0KCkge1xuICAgICAgICAvL2RlYnVnZ2VyO1xuICAgICAgICAvL3RoaXMuX3Jlc291cmNlU2VydmljZS5kZWxldGVDb29raWUoXCJSZW1lbWJlcktleVwiKTtcbiAgICB9XG59Il19
