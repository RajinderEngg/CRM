System.register(["angular2/core", 'angular2/common', "../../services/ResourceService", "angular2/router", "../../services/RecieptService"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, common_1, ResourceService_1, router_1, RecieptService_1;
    var AmaxRecieptTemplate;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (ResourceService_1_1) {
                ResourceService_1 = ResourceService_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (RecieptService_1_1) {
                RecieptService_1 = RecieptService_1_1;
            }],
        execute: function() {
            //@NgModule({
            //    imports: [
            //        CKEditorModule
            //    ]
            //    //,declarations: [
            //    //    App,
            //    //],
            //    //bootstrap: [App]
            //})
            AmaxRecieptTemplate = (function () {
                function AmaxRecieptTemplate(_resourceService, _RecieptService, _routeParams) {
                    this._resourceService = _resourceService;
                    this._RecieptService = _RecieptService;
                    this._routeParams = _routeParams;
                    this.RES = {};
                    this.Formtype = "SCREEN_ADDRECIEPTTEMP";
                    this.Lang = "";
                    this._ReceiptTypes = [];
                    this._RecieptThnksLettersList = [];
                    this.ReceiptId = -1;
                    this.ReceiptName = "";
                    this.MsgClass = "text-primary";
                    this.modelInput = {};
                    this.editmodelInput = {};
                    this.Isbtndisable = "";
                    this.ShowLoader = false;
                    this.ShowMsg = false;
                    this.content = "";
                    this.Msg = "";
                    this.baseUrl = "";
                    this.ChangeDialog = "";
                    this.CHANGEDIR = "";
                    this.RES.SCREEN_ADDRECIEPTTEMP = {};
                    this.ReceiptName = "";
                    this.modelInput = {};
                    this.modelInput.ReceiptId = "";
                    this.modelInput.ThanksLetterNameEng = "";
                    this.content = "";
                    //alert(_routeParams.params.Id);
                    this.modelInput.ThanksLetterId = _routeParams.params.Id;
                    this.baseUrl = _resourceService.AppUrl;
                    //this.getRceiptThnksLetterDet();
                }
                AmaxRecieptTemplate.prototype.EditTemplate = function () {
                    var response = this.baseUrl + "Template/Edit/" + this.modelInput.ThanksLetterId + "/RecTemp";
                    document.location = response;
                };
                AmaxRecieptTemplate.prototype.CancelRecTemplate = function () {
                    var response = this.baseUrl + "ReceiptTemplate/Add/0";
                    document.location = response;
                };
                AmaxRecieptTemplate.prototype.CancelBtn = function () {
                    //this.modelInput = {};
                    //jQuery("#editor").val("");
                    //this.modelInput.ReceiptId = ""; 
                    //this.modelInput.ThanksLetterNameEng = "";
                    //this.modelInput.ThanksLetterName = "";
                    //this.modelInput.MailSubj = "";
                    //this.modelInput.MailBody = "";
                    var response = this.baseUrl + "ReceiptType/0";
                    if (this.modelInput.ReceiptId != "" && this.modelInput.ReceiptId != undefined && this.modelInput.ReceiptId != null) {
                        response = this.baseUrl + "ReceiptType/" + this.modelInput.ReceiptId;
                    }
                    document.location = response;
                };
                AmaxRecieptTemplate.prototype.getRceiptThnksLetterDet = function () {
                    var _this = this;
                    if (this.modelInput.ThanksLetterId != 0) {
                        this._RecieptService.GetRecieptThnksLetter(this.modelInput.ThanksLetterId).subscribe(function (response) {
                            //debugger;
                            response = jQuery.parseJSON(response);
                            if (response.IsError == true) {
                                bootbox.alert({
                                    message: response.ErrMsg,
                                    className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                            else {
                                //this.modelInput.ThanksLetterNameEng = response.Data.ThanksLetterNameEng;
                                _this.modelInput = response.Data;
                            }
                        }, function (error) {
                            console.log(error);
                        }, function () {
                            console.log("CallCompleted");
                        });
                    }
                };
                AmaxRecieptTemplate.prototype.saveReceiptTemplateData = function () {
                    var _this = this;
                    //debugger;
                    this.Isbtndisable = "disabled";
                    this.ShowLoader = true;
                    //this.modelInput.ReceiptId = parseInt(this.modelInput.ReceiptId);
                    this.modelInput.MailBody = jQuery("#editor").val();
                    var jdata = JSON.stringify(this.modelInput);
                    console.log(jdata);
                    this._RecieptService.AddReceiptThnksLetter(jdata).subscribe(function (response) {
                        console.log(response);
                        response = jQuery.parseJSON(response);
                        _this.Isbtndisable = "";
                        _this.ShowLoader = false;
                        if (response.IsError == true) {
                            //alert(response.ErrMsg);
                            _this.MsgClass = "text-danger";
                        }
                        else {
                            //alert(response.ErrMsg);
                            // debugger;
                            //this.MsgClass = "text-success";
                            //this.SAVE_BTN_TEXT = this.RES.SCREEN_ADDRECIEPTTEMP.APP_BTN_SAVE;
                            //this.modelInput = {};
                            //jQuery("#editor").val("");
                            //this.modelInput.ReceiptId = ""; 
                            //this.CancelRecTemplate();
                            var response = _this.baseUrl + "ReceiptType/0";
                            if (_this.modelInput.ReceiptId != "" && _this.modelInput.ReceiptId != undefined && _this.modelInput.ReceiptId != null) {
                                response = _this.baseUrl + "ReceiptType/" + _this.modelInput.ReceiptId;
                            }
                            document.location = response;
                        }
                        _this.ShowMsg = true;
                        _this.Msg = response.ErrMsg;
                    }, function (error) { return console.log(error); }, function () { return console.log("Save Call Compleated"); });
                };
                AmaxRecieptTemplate.prototype.ngOnInit = function () {
                    var _this = this;
                    this.Lang = localStorage.getItem("lang");
                    //this.getRceiptThnksLetterDet();
                    //this.editmodelInput.ThanksLetterNameEng = "Hello";
                    //this.modelInput.ThanksLetterNameEng = this.editmodelInput.ThanksLetterNameEng;
                    this._resourceService.GetLangRes(this.Formtype, this.Lang).subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.RES = response.Data;
                            if (_this.modelInput.ThanksLetterId != 0) {
                                _this.SAVE_BTN_TEXT = _this.RES.SCREEN_ADDRECIEPTTEMP.APP_BTN_UPDATE;
                            }
                            else {
                                _this.SAVE_BTN_TEXT = _this.RES.SCREEN_ADDRECIEPTTEMP.APP_BTN_SAVE;
                            }
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    if (this.modelInput.ThanksLetterId != 0) {
                        this._RecieptService.GetRecieptThnksLetter(this.modelInput.ThanksLetterId).subscribe(function (response) {
                            // debugger;
                            response = jQuery.parseJSON(response);
                            if (response.IsError == true) {
                                bootbox.alert({
                                    message: response.ErrMsg,
                                    className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                            else {
                                //this.modelInput = {};
                                _this.modelInput = response.Data;
                                jQuery("#editor").val(_this.modelInput.MailBody);
                                jQuery("#EditTemp").show();
                                jQuery('#editor').ckeditor(function () {
                                });
                            }
                        }, function (error) {
                            console.log(error);
                        }, function () {
                            console.log("CallCompleted");
                        });
                    }
                    else {
                        jQuery("#editor").val("");
                        jQuery("#EditTemp").hide();
                        jQuery('#editor').ckeditor(function () {
                        });
                    }
                    //this.modelInput.ThanksLetterNameEng = this.editmodelInput.ThanksLetterNameEng;
                    this._RecieptService.BindRecieptType().subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._ReceiptTypes = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxRecieptTemplate.$inject = ['$scope', '$http', '$templateCache'];
                AmaxRecieptTemplate = __decorate([
                    core_1.Component({
                        templateUrl: './app/amax/RecieptType/templates/RecieptTemplate.html',
                        directives: [common_1.NgSwitch, common_1.NgSwitchWhen, common_1.NgSwitchDefault],
                        providers: [RecieptService_1.RecieptService, ResourceService_1.ResourceService]
                    }), 
                    __metadata('design:paramtypes', [ResourceService_1.ResourceService, RecieptService_1.RecieptService, router_1.RouteParams])
                ], AmaxRecieptTemplate);
                return AmaxRecieptTemplate;
            }());
            exports_1("AmaxRecieptTemplate", AmaxRecieptTemplate);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldi9hbWF4L1JlY2llcHRUeXBlL1JlY2llcHRUZW1wbGF0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztZQVlBLGFBQWE7WUFDYixnQkFBZ0I7WUFDaEIsd0JBQXdCO1lBQ3hCLE9BQU87WUFDUCx3QkFBd0I7WUFDeEIsZ0JBQWdCO1lBQ2hCLFVBQVU7WUFDVix3QkFBd0I7WUFDeEIsSUFBSTtZQVFKO2dCQXFCSSw2QkFBb0IsZ0JBQWlDLEVBQVUsZUFBK0IsRUFDbEYsWUFBeUI7b0JBRGpCLHFCQUFnQixHQUFoQixnQkFBZ0IsQ0FBaUI7b0JBQVUsb0JBQWUsR0FBZixlQUFlLENBQWdCO29CQUNsRixpQkFBWSxHQUFaLFlBQVksQ0FBYTtvQkFyQnJDLFFBQUcsR0FBVyxFQUFFLENBQUM7b0JBQ2pCLGFBQVEsR0FBVyx1QkFBdUIsQ0FBQztvQkFDM0MsU0FBSSxHQUFXLEVBQUUsQ0FBQztvQkFDbEIsa0JBQWEsR0FBRyxFQUFFLENBQUM7b0JBQ25CLDZCQUF3QixHQUFHLEVBQUUsQ0FBQztvQkFDOUIsY0FBUyxHQUFXLENBQUMsQ0FBQyxDQUFDO29CQUN2QixnQkFBVyxHQUFXLEVBQUUsQ0FBQztvQkFDekIsYUFBUSxHQUFXLGNBQWMsQ0FBQztvQkFDbEMsZUFBVSxHQUFXLEVBQUUsQ0FBQztvQkFDeEIsbUJBQWMsR0FBVyxFQUFFLENBQUM7b0JBRTVCLGlCQUFZLEdBQVcsRUFBRSxDQUFDO29CQUMxQixlQUFVLEdBQVksS0FBSyxDQUFDO29CQUM1QixZQUFPLEdBQVksS0FBSyxDQUFDO29CQUN6QixZQUFPLEdBQVcsRUFBRSxDQUFDO29CQUNyQixRQUFHLEdBQVcsRUFBRSxDQUFDO29CQUNqQixZQUFPLEdBQVcsRUFBRSxDQUFDO29CQUNyQixpQkFBWSxHQUFXLEVBQUUsQ0FBQztvQkFDMUIsY0FBUyxHQUFXLEVBQUUsQ0FBQztvQkFLbkIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxxQkFBcUIsR0FBRyxFQUFFLENBQUM7b0JBQ3BDLElBQUksQ0FBQyxXQUFXLEdBQUcsRUFBRSxDQUFDO29CQUN0QixJQUFJLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztvQkFDckIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEdBQUcsRUFBRSxDQUFDO29CQUMvQixJQUFJLENBQUMsVUFBVSxDQUFDLG1CQUFtQixHQUFHLEVBQUUsQ0FBQztvQkFDekMsSUFBSSxDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7b0JBQ2xCLGdDQUFnQztvQkFDaEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsWUFBWSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7b0JBQ3hELElBQUksQ0FBQyxPQUFPLEdBQUcsZ0JBQWdCLENBQUMsTUFBTSxDQUFDO29CQUN2QyxpQ0FBaUM7Z0JBQ3JDLENBQUM7Z0JBQ0QsMENBQVksR0FBWjtvQkFFSSxJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsT0FBTyxHQUFHLGdCQUFnQixHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFDLFVBQVUsQ0FBQztvQkFFM0YsUUFBUSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUM7Z0JBQ2pDLENBQUM7Z0JBQ0QsK0NBQWlCLEdBQWpCO29CQUNJLElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxPQUFPLEdBQUcsdUJBQXVCLENBQUM7b0JBRXRELFFBQVEsQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFDO2dCQUNqQyxDQUFDO2dCQUNELHVDQUFTLEdBQVQ7b0JBQ0ksdUJBQXVCO29CQUV2Qiw0QkFBNEI7b0JBRTVCLGtDQUFrQztvQkFDbEMsMkNBQTJDO29CQUMzQyx3Q0FBd0M7b0JBQ3hDLGdDQUFnQztvQkFDaEMsZ0NBQWdDO29CQUNoQyxJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsT0FBTyxHQUFHLGVBQWUsQ0FBQztvQkFDOUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO3dCQUNqSCxRQUFRLEdBQUcsSUFBSSxDQUFDLE9BQU8sR0FBRyxjQUFjLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUM7b0JBQ3pFLENBQUM7b0JBQ0QsUUFBUSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUM7Z0JBQ2pDLENBQUM7Z0JBQ0QscURBQXVCLEdBQXZCO29CQUFBLGlCQTRCQztvQkEzQkcsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDdEMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7NEJBQ3pGLFdBQVc7NEJBQ1gsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7NEJBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQztnQ0FDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztvQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07b0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtvQ0FDNUIsT0FBTyxFQUFFO3dDQUNMLEVBQUUsRUFBRTs0Q0FDQSxjQUFjOzRDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUzt5Q0FDNUI7cUNBQ0o7aUNBQ0osQ0FBQyxDQUFDOzRCQUNQLENBQUM7NEJBQ0QsSUFBSSxDQUFDLENBQUM7Z0NBQ0YsMEVBQTBFO2dDQUUxRSxLQUFJLENBQUMsVUFBVSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7NEJBQ3BDLENBQUM7d0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzs0QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO3dCQUN2QixDQUFDLEVBQUU7NEJBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTt3QkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBQ1AsQ0FBQztnQkFDTCxDQUFDO2dCQUNELHFEQUF1QixHQUF2QjtvQkFBQSxpQkFnREM7b0JBL0NHLFdBQVc7b0JBQ1gsSUFBSSxDQUFDLFlBQVksR0FBRyxVQUFVLENBQUM7b0JBQy9CLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO29CQUN2QixrRUFBa0U7b0JBQ2xFLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQztvQkFDbkQsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7b0JBQzVDLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUE7b0JBQ2xCLElBQUksQ0FBQyxlQUFlLENBQUMscUJBQXFCLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFDaEUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDdEIsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQ3RDLEtBQUksQ0FBQyxZQUFZLEdBQUcsRUFBRSxDQUFDO3dCQUN2QixLQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQzt3QkFFeEIsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQix5QkFBeUI7NEJBQ3pCLEtBQUksQ0FBQyxRQUFRLEdBQUcsYUFBYSxDQUFDO3dCQUNsQyxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLHlCQUF5Qjs0QkFDMUIsWUFBWTs0QkFDWCxpQ0FBaUM7NEJBRWpDLG1FQUFtRTs0QkFHbkUsdUJBQXVCOzRCQUV2Qiw0QkFBNEI7NEJBRTVCLGtDQUFrQzs0QkFJbEMsMkJBQTJCOzRCQUMzQixJQUFJLFFBQVEsR0FBRyxLQUFJLENBQUMsT0FBTyxHQUFHLGVBQWUsQ0FBQzs0QkFDOUMsRUFBRSxDQUFDLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLElBQUksRUFBRSxJQUFJLEtBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxJQUFJLFNBQVMsSUFBSSxLQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO2dDQUNqSCxRQUFRLEdBQUcsS0FBSSxDQUFDLE9BQU8sR0FBRyxjQUFjLEdBQUcsS0FBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUM7NEJBQ3pFLENBQUM7NEJBQ0QsUUFBUSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUM7d0JBQ2pDLENBQUM7d0JBQ0QsS0FBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7d0JBQ3BCLEtBQUksQ0FBQyxHQUFHLEdBQUcsUUFBUSxDQUFDLE1BQU0sQ0FBQztvQkFDL0IsQ0FBQyxFQUNHLFVBQUEsS0FBSyxJQUFHLE9BQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBbEIsQ0FBa0IsRUFDMUIsY0FBTSxPQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsc0JBQXNCLENBQUMsRUFBbkMsQ0FBbUMsQ0FDNUMsQ0FBQztnQkFFTixDQUFDO2dCQUNELHNDQUFRLEdBQVI7b0JBQUEsaUJBc0dDO29CQXBHRyxJQUFJLENBQUMsSUFBSSxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQ3pDLGlDQUFpQztvQkFDakMsb0RBQW9EO29CQUNwRCxnRkFBZ0Y7b0JBQ2hGLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFFekUsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLEdBQUcsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDOzRCQUN6QixFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUN0QyxLQUFJLENBQUMsYUFBYSxHQUFHLEtBQUksQ0FBQyxHQUFHLENBQUMscUJBQXFCLENBQUMsY0FBYyxDQUFDOzRCQUN2RSxDQUFDOzRCQUNELElBQUksQ0FBQyxDQUFDO2dDQUNGLEtBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSSxDQUFDLEdBQUcsQ0FBQyxxQkFBcUIsQ0FBQyxZQUFZLENBQUM7NEJBQ3JFLENBQUM7d0JBQ0wsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFDSCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUN0QyxJQUFJLENBQUMsZUFBZSxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTs0QkFDMUYsWUFBWTs0QkFDWCxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzs0QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO2dDQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO29DQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtvQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO29DQUM1QixPQUFPLEVBQUU7d0NBQ0wsRUFBRSxFQUFFOzRDQUNBLGNBQWM7NENBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3lDQUM1QjtxQ0FDSjtpQ0FDSixDQUFDLENBQUM7NEJBQ1AsQ0FBQzs0QkFDRCxJQUFJLENBQUMsQ0FBQztnQ0FDRix1QkFBdUI7Z0NBQ3ZCLEtBQUksQ0FBQyxVQUFVLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQztnQ0FDaEMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dDQUNoRCxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7Z0NBQzNCLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxRQUFRLENBQUM7Z0NBRTNCLENBQUMsQ0FBQyxDQUFDOzRCQUdQLENBQUM7d0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzs0QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO3dCQUN2QixDQUFDLEVBQUU7NEJBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTt3QkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBQ1AsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDO3dCQUMxQixNQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7d0JBQzNCLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxRQUFRLENBQUM7d0JBRTNCLENBQUMsQ0FBQyxDQUFDO29CQUNQLENBQUM7b0JBQ0QsZ0ZBQWdGO29CQUNoRixJQUFJLENBQUMsZUFBZSxDQUFDLGVBQWUsRUFBRSxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7d0JBRXJELFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO2dDQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQzVCLE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEtBQUksQ0FBQyxhQUFhLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzt3QkFDdkMsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztnQkFJUCxDQUFDO2dCQTlOTSwyQkFBTyxHQUFHLENBQUMsUUFBUSxFQUFFLE9BQU8sRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO2dCQTNCM0Q7b0JBQUMsZ0JBQVMsQ0FBQzt3QkFFUCxXQUFXLEVBQUUsdURBQXVEO3dCQUNwRSxVQUFVLEVBQUUsQ0FBQyxpQkFBUSxFQUFFLHFCQUFZLEVBQUUsd0JBQWUsQ0FBQzt3QkFDckQsU0FBUyxFQUFFLENBQUMsK0JBQWMsRUFBRSxpQ0FBZSxDQUFDO3FCQUMvQyxDQUFDOzt1Q0FBQTtnQkFxUEYsMEJBQUM7WUFBRCxDQW5QQSxBQW1QQyxJQUFBO1lBblBELHFEQW1QQyxDQUFBIiwiZmlsZSI6ImRldi9hbWF4L1JlY2llcHRUeXBlL1JlY2llcHRUZW1wbGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbIi8vaW1wb3J0IHtOZ01vZHVsZX0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbi8vaW1wb3J0IHtGb3Jtc01vZHVsZX0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xyXG5pbXBvcnQge0NvbXBvbmVudCwgT3V0cHV0LCBJbnB1dCwgRXZlbnRFbWl0dGVyLCBPbkluaXR9IGZyb20gXCJhbmd1bGFyMi9jb3JlXCI7XHJcbmltcG9ydCB7TmdTd2l0Y2gsIE5nU3dpdGNoV2hlbiwgTmdTd2l0Y2hEZWZhdWx0fSBmcm9tICdhbmd1bGFyMi9jb21tb24nXHJcbmltcG9ydCB7UmVzb3VyY2VTZXJ2aWNlfSBmcm9tIFwiLi4vLi4vc2VydmljZXMvUmVzb3VyY2VTZXJ2aWNlXCI7XHJcbmltcG9ydCB7Um91dGVQYXJhbXN9IGZyb20gXCJhbmd1bGFyMi9yb3V0ZXJcIjtcclxuaW1wb3J0IHtSZWNpZXB0U2VydmljZX0gZnJvbSBcIi4uLy4uL3NlcnZpY2VzL1JlY2llcHRTZXJ2aWNlXCI7XHJcbmltcG9ydCB7IGpzb25RIH0gZnJvbSAnLi4vLi4vanNvblEnO1xyXG5pbXBvcnQge0dyb3VwRmlsdGVyUGlwZSwgR3JvdXBQYXJlbkZpbHRlclBpcGUsIEtlbmRvX3V0aWxpdHl9IGZyb20gXCIuLi8uLi9hbWF4VXRpbFwiO1xyXG4vL2ltcG9ydCB7Q0tFZGl0b3JNb2R1bGV9IGZyb20gJ25nMi1ja2VkaXRvcic7XHJcblxyXG5kZWNsYXJlIHZhciBqUXVlcnk7XHJcbi8vQE5nTW9kdWxlKHtcclxuLy8gICAgaW1wb3J0czogW1xyXG4vLyAgICAgICAgQ0tFZGl0b3JNb2R1bGVcclxuLy8gICAgXVxyXG4vLyAgICAvLyxkZWNsYXJhdGlvbnM6IFtcclxuLy8gICAgLy8gICAgQXBwLFxyXG4vLyAgICAvL10sXHJcbi8vICAgIC8vYm9vdHN0cmFwOiBbQXBwXVxyXG4vL30pXHJcbkBDb21wb25lbnQoe1xyXG5cclxuICAgIHRlbXBsYXRlVXJsOiAnLi9hcHAvYW1heC9SZWNpZXB0VHlwZS90ZW1wbGF0ZXMvUmVjaWVwdFRlbXBsYXRlLmh0bWwnLFxyXG4gICAgZGlyZWN0aXZlczogW05nU3dpdGNoLCBOZ1N3aXRjaFdoZW4sIE5nU3dpdGNoRGVmYXVsdF0sXHJcbiAgICBwcm92aWRlcnM6IFtSZWNpZXB0U2VydmljZSwgUmVzb3VyY2VTZXJ2aWNlXVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEFtYXhSZWNpZXB0VGVtcGxhdGUgaW1wbGVtZW50cyBPbkluaXQge1xyXG4gICAgUkVTOiBPYmplY3QgPSB7fTtcclxuICAgIEZvcm10eXBlOiBzdHJpbmcgPSBcIlNDUkVFTl9BRERSRUNJRVBUVEVNUFwiO1xyXG4gICAgTGFuZzogc3RyaW5nID0gXCJcIjtcclxuICAgIF9SZWNlaXB0VHlwZXMgPSBbXTtcclxuICAgIF9SZWNpZXB0VGhua3NMZXR0ZXJzTGlzdCA9IFtdO1xyXG4gICAgUmVjZWlwdElkOiBudW1iZXIgPSAtMTtcclxuICAgIFJlY2VpcHROYW1lOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgTXNnQ2xhc3M6IHN0cmluZyA9IFwidGV4dC1wcmltYXJ5XCI7XHJcbiAgICBtb2RlbElucHV0OiBPYmplY3QgPSB7fTtcclxuICAgIGVkaXRtb2RlbElucHV0OiBPYmplY3QgPSB7fTtcclxuICAgIFNBVkVfQlROX1RFWFQ6IHN0cmluZztcclxuICAgIElzYnRuZGlzYWJsZTogc3RyaW5nID0gXCJcIjtcclxuICAgIFNob3dMb2FkZXI6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIFNob3dNc2c6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIGNvbnRlbnQ6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBNc2c6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBiYXNlVXJsOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgQ2hhbmdlRGlhbG9nOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgQ0hBTkdFRElSOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgc3RhdGljICRpbmplY3QgPSBbJyRzY29wZScsICckaHR0cCcsICckdGVtcGxhdGVDYWNoZSddO1xyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBfcmVzb3VyY2VTZXJ2aWNlOiBSZXNvdXJjZVNlcnZpY2UsIHByaXZhdGUgX1JlY2llcHRTZXJ2aWNlOiBSZWNpZXB0U2VydmljZSxcclxuICAgICAgICBwcml2YXRlIF9yb3V0ZVBhcmFtczogUm91dGVQYXJhbXMpIHtcclxuICAgICAgICBcclxuICAgICAgICB0aGlzLlJFUy5TQ1JFRU5fQUREUkVDSUVQVFRFTVAgPSB7fTtcclxuICAgICAgICB0aGlzLlJlY2VpcHROYW1lID0gXCJcIjtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQgPSB7fTtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdElkID0gXCJcIjtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuVGhhbmtzTGV0dGVyTmFtZUVuZyA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5jb250ZW50ID0gXCJcIjtcclxuICAgICAgICAvL2FsZXJ0KF9yb3V0ZVBhcmFtcy5wYXJhbXMuSWQpO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5UaGFua3NMZXR0ZXJJZCA9IF9yb3V0ZVBhcmFtcy5wYXJhbXMuSWQ7XHJcbiAgICAgICAgdGhpcy5iYXNlVXJsID0gX3Jlc291cmNlU2VydmljZS5BcHBVcmw7XHJcbiAgICAgICAgLy90aGlzLmdldFJjZWlwdFRobmtzTGV0dGVyRGV0KCk7XHJcbiAgICB9XHJcbiAgICBFZGl0VGVtcGxhdGUoKSB7XHJcbiAgICAgIFxyXG4gICAgICAgIHZhciByZXNwb25zZSA9IHRoaXMuYmFzZVVybCArIFwiVGVtcGxhdGUvRWRpdC9cIiArIHRoaXMubW9kZWxJbnB1dC5UaGFua3NMZXR0ZXJJZCtcIi9SZWNUZW1wXCI7XHJcbiAgICAgICAgXHJcbiAgICAgICAgZG9jdW1lbnQubG9jYXRpb24gPSByZXNwb25zZTtcclxuICAgIH1cclxuICAgIENhbmNlbFJlY1RlbXBsYXRlKCkge1xyXG4gICAgICAgIHZhciByZXNwb25zZSA9IHRoaXMuYmFzZVVybCArIFwiUmVjZWlwdFRlbXBsYXRlL0FkZC8wXCI7XHJcbiAgICAgICAgXHJcbiAgICAgICAgZG9jdW1lbnQubG9jYXRpb24gPSByZXNwb25zZTtcclxuICAgIH1cclxuICAgIENhbmNlbEJ0bigpIHtcclxuICAgICAgICAvL3RoaXMubW9kZWxJbnB1dCA9IHt9O1xyXG5cclxuICAgICAgICAvL2pRdWVyeShcIiNlZGl0b3JcIikudmFsKFwiXCIpO1xyXG5cclxuICAgICAgICAvL3RoaXMubW9kZWxJbnB1dC5SZWNlaXB0SWQgPSBcIlwiOyBcclxuICAgICAgICAvL3RoaXMubW9kZWxJbnB1dC5UaGFua3NMZXR0ZXJOYW1lRW5nID0gXCJcIjtcclxuICAgICAgICAvL3RoaXMubW9kZWxJbnB1dC5UaGFua3NMZXR0ZXJOYW1lID0gXCJcIjtcclxuICAgICAgICAvL3RoaXMubW9kZWxJbnB1dC5NYWlsU3ViaiA9IFwiXCI7XHJcbiAgICAgICAgLy90aGlzLm1vZGVsSW5wdXQuTWFpbEJvZHkgPSBcIlwiO1xyXG4gICAgICAgIHZhciByZXNwb25zZSA9IHRoaXMuYmFzZVVybCArIFwiUmVjZWlwdFR5cGUvMFwiO1xyXG4gICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdElkICE9IFwiXCIgJiYgdGhpcy5tb2RlbElucHV0LlJlY2VpcHRJZCAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0LlJlY2VpcHRJZCAhPSBudWxsKSB7XHJcbiAgICAgICAgICAgIHJlc3BvbnNlID0gdGhpcy5iYXNlVXJsICsgXCJSZWNlaXB0VHlwZS9cIiArIHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0SWQ7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGRvY3VtZW50LmxvY2F0aW9uID0gcmVzcG9uc2U7XHJcbiAgICB9XHJcbiAgICBnZXRSY2VpcHRUaG5rc0xldHRlckRldCgpIHtcclxuICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LlRoYW5rc0xldHRlcklkICE9IDApIHtcclxuICAgICAgICAgICAgdGhpcy5fUmVjaWVwdFNlcnZpY2UuR2V0UmVjaWVwdFRobmtzTGV0dGVyKHRoaXMubW9kZWxJbnB1dC5UaGFua3NMZXR0ZXJJZCkuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy90aGlzLm1vZGVsSW5wdXQuVGhhbmtzTGV0dGVyTmFtZUVuZyA9IHJlc3BvbnNlLkRhdGEuVGhhbmtzTGV0dGVyTmFtZUVuZztcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0ID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBzYXZlUmVjZWlwdFRlbXBsYXRlRGF0YSgpIHtcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgIHRoaXMuSXNidG5kaXNhYmxlID0gXCJkaXNhYmxlZFwiO1xyXG4gICAgICAgIHRoaXMuU2hvd0xvYWRlciA9IHRydWU7XHJcbiAgICAgICAgLy90aGlzLm1vZGVsSW5wdXQuUmVjZWlwdElkID0gcGFyc2VJbnQodGhpcy5tb2RlbElucHV0LlJlY2VpcHRJZCk7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0Lk1haWxCb2R5ID0galF1ZXJ5KFwiI2VkaXRvclwiKS52YWwoKTtcclxuICAgICAgICB2YXIgamRhdGEgPSBKU09OLnN0cmluZ2lmeSh0aGlzLm1vZGVsSW5wdXQpO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGpkYXRhKVxyXG4gICAgICAgIHRoaXMuX1JlY2llcHRTZXJ2aWNlLkFkZFJlY2VpcHRUaG5rc0xldHRlcihqZGF0YSkuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhyZXNwb25zZSk7XHJcbiAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgIHRoaXMuSXNidG5kaXNhYmxlID0gXCJcIjtcclxuICAgICAgICAgICAgdGhpcy5TaG93TG9hZGVyID0gZmFsc2U7XHJcblxyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAvL2FsZXJ0KHJlc3BvbnNlLkVyck1zZyk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLk1zZ0NsYXNzID0gXCJ0ZXh0LWRhbmdlclwiO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgLy9hbGVydChyZXNwb25zZS5FcnJNc2cpO1xyXG4gICAgICAgICAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgIC8vdGhpcy5Nc2dDbGFzcyA9IFwidGV4dC1zdWNjZXNzXCI7XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIC8vdGhpcy5TQVZFX0JUTl9URVhUID0gdGhpcy5SRVMuU0NSRUVOX0FERFJFQ0lFUFRURU1QLkFQUF9CVE5fU0FWRTtcclxuXHJcblxyXG4gICAgICAgICAgICAgICAgLy90aGlzLm1vZGVsSW5wdXQgPSB7fTtcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgLy9qUXVlcnkoXCIjZWRpdG9yXCIpLnZhbChcIlwiKTtcclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIC8vdGhpcy5tb2RlbElucHV0LlJlY2VpcHRJZCA9IFwiXCI7IFxyXG5cclxuXHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIC8vdGhpcy5DYW5jZWxSZWNUZW1wbGF0ZSgpO1xyXG4gICAgICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0gdGhpcy5iYXNlVXJsICsgXCJSZWNlaXB0VHlwZS8wXCI7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LlJlY2VpcHRJZCAhPSBcIlwiICYmIHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0SWQgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0SWQgIT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHJlc3BvbnNlID0gdGhpcy5iYXNlVXJsICsgXCJSZWNlaXB0VHlwZS9cIiArIHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0SWQ7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBkb2N1bWVudC5sb2NhdGlvbiA9IHJlc3BvbnNlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRoaXMuU2hvd01zZyA9IHRydWU7XHJcbiAgICAgICAgICAgIHRoaXMuTXNnID0gcmVzcG9uc2UuRXJyTXNnO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgICAgIGVycm9yPT4gY29uc29sZS5sb2coZXJyb3IpLFxyXG4gICAgICAgICAgICAoKSA9PiBjb25zb2xlLmxvZyhcIlNhdmUgQ2FsbCBDb21wbGVhdGVkXCIpXHJcbiAgICAgICAgKTtcclxuXHJcbiAgICB9XHJcbiAgICBuZ09uSW5pdCgpIHtcclxuICAgICAgICBcclxuICAgICAgICB0aGlzLkxhbmcgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImxhbmdcIik7XHJcbiAgICAgICAgLy90aGlzLmdldFJjZWlwdFRobmtzTGV0dGVyRGV0KCk7XHJcbiAgICAgICAgLy90aGlzLmVkaXRtb2RlbElucHV0LlRoYW5rc0xldHRlck5hbWVFbmcgPSBcIkhlbGxvXCI7XHJcbiAgICAgICAgLy90aGlzLm1vZGVsSW5wdXQuVGhhbmtzTGV0dGVyTmFtZUVuZyA9IHRoaXMuZWRpdG1vZGVsSW5wdXQuVGhhbmtzTGV0dGVyTmFtZUVuZztcclxuICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuR2V0TGFuZ1Jlcyh0aGlzLkZvcm10eXBlLCB0aGlzLkxhbmcpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuXHJcbiAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuUkVTID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuVGhhbmtzTGV0dGVySWQgIT0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuU0FWRV9CVE5fVEVYVCA9IHRoaXMuUkVTLlNDUkVFTl9BRERSRUNJRVBUVEVNUC5BUFBfQlROX1VQREFURTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuU0FWRV9CVE5fVEVYVCA9IHRoaXMuUkVTLlNDUkVFTl9BRERSRUNJRVBUVEVNUC5BUFBfQlROX1NBVkU7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5UaGFua3NMZXR0ZXJJZCAhPSAwKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX1JlY2llcHRTZXJ2aWNlLkdldFJlY2llcHRUaG5rc0xldHRlcih0aGlzLm1vZGVsSW5wdXQuVGhhbmtzTGV0dGVySWQpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIC8vdGhpcy5tb2RlbElucHV0ID0ge307XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0ID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkoXCIjZWRpdG9yXCIpLnZhbCh0aGlzLm1vZGVsSW5wdXQuTWFpbEJvZHkpO1xyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeShcIiNFZGl0VGVtcFwiKS5zaG93KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5KCcjZWRpdG9yJykuY2tlZGl0b3IoZnVuY3Rpb24gKCkge1xyXG5cclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAvLyB0aGlzLmVkaXRtb2RlbElucHV0LlRoYW5rc0xldHRlcklkID0gcmVzcG9uc2UuRGF0YS5UaGFua3NMZXR0ZXJJZDtcclxuICAgICAgICAgICAgICAgICAgICAvLyBhbGVydCh0aGlzLmVkaXRtb2RlbElucHV0LlRoYW5rc0xldHRlcklkKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIGpRdWVyeShcIiNlZGl0b3JcIikudmFsKFwiXCIpO1xyXG4gICAgICAgICAgICBqUXVlcnkoXCIjRWRpdFRlbXBcIikuaGlkZSgpO1xyXG4gICAgICAgICAgICBqUXVlcnkoJyNlZGl0b3InKS5ja2VkaXRvcihmdW5jdGlvbiAoKSB7XHJcblxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgLy90aGlzLm1vZGVsSW5wdXQuVGhhbmtzTGV0dGVyTmFtZUVuZyA9IHRoaXMuZWRpdG1vZGVsSW5wdXQuVGhhbmtzTGV0dGVyTmFtZUVuZztcclxuICAgICAgICB0aGlzLl9SZWNpZXB0U2VydmljZS5CaW5kUmVjaWVwdFR5cGUoKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9SZWNlaXB0VHlwZXMgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBcclxuICAgICAgICBcclxuICAgIH1cclxufVxyXG4iXX0=
