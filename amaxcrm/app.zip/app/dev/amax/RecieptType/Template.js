System.register(["angular2/core", 'angular2/common', "../../services/ResourceService", "angular2/router", "../../services/RecieptService"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, common_1, ResourceService_1, router_1, RecieptService_1;
    var AmaxTemplate;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (ResourceService_1_1) {
                ResourceService_1 = ResourceService_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (RecieptService_1_1) {
                RecieptService_1 = RecieptService_1_1;
            }],
        execute: function() {
            //@NgModule({
            //    imports: [
            //        CKEditorModule
            //    ]
            //    //,declarations: [
            //    //    App,
            //    //],
            //    //bootstrap: [App]
            //})
            AmaxTemplate = (function () {
                function AmaxTemplate(_resourceService, _RecieptService, _routeParams) {
                    this._resourceService = _resourceService;
                    this._RecieptService = _RecieptService;
                    this._routeParams = _routeParams;
                    this.RES = {};
                    this.Formtype = "SCREEN_EDITTEMP";
                    this.Lang = "";
                    this.MsgClass = "text-primary";
                    this.modelInput = {};
                    this.Isbtndisable = "";
                    this.ShowLoader = false;
                    this.ShowMsg = false;
                    this.FPage = "";
                    this.Msg = "";
                    this.OrgId = "";
                    this.ChangeDialog = "";
                    this.CHANGEDIR = "";
                    this.RES.SCREEN_EDITTEMP = {};
                    this.modelInput = {};
                    //alert(_routeParams.params.Id);
                    this.modelInput.ThanksLetterId = _routeParams.params.Id;
                    this.FPage = _routeParams.params.FPage;
                    this.baseUrl = _resourceService.AppUrl;
                    //this.getRceiptThnksLetterDet();
                }
                AmaxTemplate.prototype.CancelBtn = function () {
                    //this.modelInput = {};
                    var _this = this;
                    //jQuery("#editor").val("");
                    //this.modelInput.MailBody = "";
                    var redresponse = this.baseUrl + "ReceiptTemplate/Add/" + this.modelInput.ThanksLetterId;
                    if (this.FPage == "Rec") {
                        if (this.modelInput.ThanksLetterId > 0) {
                            //alert('Hello');
                            this._RecieptService.GetRecieptThnksLetter(this.modelInput.ThanksLetterId).subscribe(function (response) {
                                console.log(response);
                                response = jQuery.parseJSON(response);
                                _this.Isbtndisable = "";
                                _this.ShowLoader = false;
                                if (response.IsError == true) {
                                    bootbox.alert({
                                        message: response.ErrMsg,
                                        className: _this.ChangeDialog,
                                        buttons: {
                                            ok: {
                                                //label: 'Ok',
                                                className: _this.CHANGEDIR
                                            }
                                        }
                                    });
                                }
                                else {
                                    if (response.Data.ReceiptId != undefined && response.Data.ReceiptId != "" && response.Data.ReceiptId != null) {
                                        redresponse = _this.baseUrl + "ReceiptType/" + response.Data.ReceiptId;
                                    }
                                    else {
                                        redresponse = _this.baseUrl + "ReceiptType/0";
                                    }
                                    document.location = redresponse;
                                }
                                _this.ShowMsg = true;
                                _this.Msg = response.ErrMsg;
                            }, function (error) { return console.log(error); }, function () { return console.log("Save Call Compleated"); });
                        }
                    }
                    else {
                        document.location = redresponse;
                    }
                };
                AmaxTemplate.prototype.saveTemplateData = function () {
                    var _this = this;
                    if (this.modelInput.ThanksLetterId > 0) {
                        this.Isbtndisable = "disabled";
                        this.ShowLoader = true;
                        //this.modelInput.ReceiptId = parseInt(this.modelInput.ReceiptId);
                        this.modelInput.MailBody = jQuery("#editor").val();
                        var jdata = JSON.stringify(this.modelInput);
                        console.log(jdata);
                        this._RecieptService.SaveTemplate(this.modelInput.ThanksLetterId, this.modelInput.MailBody).subscribe(function (response) {
                            console.log(response);
                            response = jQuery.parseJSON(response);
                            _this.Isbtndisable = "";
                            _this.ShowLoader = false;
                            if (response.IsError == true) {
                                //alert(response.ErrMsg);
                                _this.MsgClass = "text-danger";
                            }
                            else {
                                //alert(response.ErrMsg);
                                // debugger;
                                var redresponse = _this.baseUrl + "ReceiptTemplate/Add/" + _this.modelInput.ThanksLetterId;
                                if (_this.FPage == "Rec") {
                                    if (_this.modelInput.ThanksLetterId > 0) {
                                        _this._RecieptService.GetRecieptThnksLetter(_this.modelInput.ThanksLetterId).subscribe(function (response) {
                                            console.log(response);
                                            response = jQuery.parseJSON(response);
                                            _this.Isbtndisable = "";
                                            _this.ShowLoader = false;
                                            if (response.IsError == true) {
                                                bootbox.alert({
                                                    message: response.ErrMsg,
                                                    className: _this.ChangeDialog,
                                                    buttons: {
                                                        ok: {
                                                            //label: 'Ok',
                                                            className: _this.CHANGEDIR
                                                        }
                                                    }
                                                });
                                            }
                                            else {
                                                if (response.Data.ReceiptId != undefined && response.Data.ReceiptId != "" && response.Data.ReceiptId != null) {
                                                    redresponse = _this.baseUrl + "ReceiptType/" + response.Data.ReceiptId;
                                                }
                                                else {
                                                    redresponse = _this.baseUrl + "ReceiptType/0";
                                                }
                                                document.location = redresponse;
                                            }
                                            _this.ShowMsg = true;
                                            _this.Msg = response.ErrMsg;
                                        }, function (error) { return console.log(error); }, function () { return console.log("Save Call Compleated"); });
                                    }
                                }
                                else {
                                    document.location = redresponse;
                                }
                                _this.MsgClass = "text-success";
                                //this.modelInput = {};
                                jQuery("#editor").val("");
                                _this.modelInput.MailBody = "";
                            }
                            _this.ShowMsg = true;
                            _this.Msg = response.ErrMsg;
                        }, function (error) { return console.log(error); }, function () { return console.log("Save Call Compleated"); });
                    }
                };
                AmaxTemplate.prototype.ngOnInit = function () {
                    var _this = this;
                    this.Lang = localStorage.getItem("lang");
                    this.OrgId = localStorage.getItem("OrgId");
                    if (this.modelInput.ThanksLetterId > 0) {
                        this._RecieptService.GetTemplate(this.modelInput.ThanksLetterId).subscribe(function (response) {
                            //debugger;
                            response = jQuery.parseJSON(response);
                            if (response.IsError == true) {
                                bootbox.alert({
                                    message: response.ErrMsg,
                                    className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        }
                                    }
                                });
                                jQuery("#editor").val("");
                                jQuery('#editor').ckeditor(function () {
                                });
                            }
                            else {
                                //this.modelInput.ThanksLetterNameEng = response.Data.ThanksLetterNameEng;
                                _this.modelInput.MailBody = response.Data;
                                //if (this.modelInput.MailBody != undefined && this.modelInput.MailBody != null) {
                                jQuery("#editor").val(_this.modelInput.MailBody);
                                jQuery('#editor').ckeditor(function () {
                                });
                            }
                        }, function (error) {
                            console.log(error);
                        }, function () {
                            console.log("CallCompleted");
                        });
                    }
                    else {
                        jQuery("#editor").val("");
                        jQuery('#editor').ckeditor(function () {
                        });
                    }
                    this._resourceService.GetLangRes(this.Formtype, this.Lang).subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.RES = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxTemplate.$inject = ['$scope', '$http', '$templateCache'];
                AmaxTemplate = __decorate([
                    core_1.Component({
                        templateUrl: './app/amax/RecieptType/templates/Template.html',
                        directives: [common_1.NgSwitch, common_1.NgSwitchWhen, common_1.NgSwitchDefault],
                        providers: [RecieptService_1.RecieptService, ResourceService_1.ResourceService]
                    }), 
                    __metadata('design:paramtypes', [ResourceService_1.ResourceService, RecieptService_1.RecieptService, router_1.RouteParams])
                ], AmaxTemplate);
                return AmaxTemplate;
            }());
            exports_1("AmaxTemplate", AmaxTemplate);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldi9hbWF4L1JlY2llcHRUeXBlL1RlbXBsYXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1lBYUEsYUFBYTtZQUNiLGdCQUFnQjtZQUNoQix3QkFBd0I7WUFDeEIsT0FBTztZQUNQLHdCQUF3QjtZQUN4QixnQkFBZ0I7WUFDaEIsVUFBVTtZQUNWLHdCQUF3QjtZQUN4QixJQUFJO1lBUUo7Z0JBZ0JJLHNCQUFvQixnQkFBaUMsRUFBVSxlQUErQixFQUNsRixZQUF5QjtvQkFEakIscUJBQWdCLEdBQWhCLGdCQUFnQixDQUFpQjtvQkFBVSxvQkFBZSxHQUFmLGVBQWUsQ0FBZ0I7b0JBQ2xGLGlCQUFZLEdBQVosWUFBWSxDQUFhO29CQWhCckMsUUFBRyxHQUFXLEVBQUUsQ0FBQztvQkFDakIsYUFBUSxHQUFXLGlCQUFpQixDQUFDO29CQUNyQyxTQUFJLEdBQVcsRUFBRSxDQUFDO29CQUNsQixhQUFRLEdBQVcsY0FBYyxDQUFDO29CQUNsQyxlQUFVLEdBQVcsRUFBRSxDQUFDO29CQUN4QixpQkFBWSxHQUFXLEVBQUUsQ0FBQztvQkFDMUIsZUFBVSxHQUFZLEtBQUssQ0FBQztvQkFDNUIsWUFBTyxHQUFZLEtBQUssQ0FBQztvQkFDekIsVUFBSyxHQUFTLEVBQUUsQ0FBQztvQkFDakIsUUFBRyxHQUFXLEVBQUUsQ0FBQztvQkFDakIsVUFBSyxHQUFXLEVBQUUsQ0FBQztvQkFFbkIsaUJBQVksR0FBVyxFQUFFLENBQUM7b0JBQzFCLGNBQVMsR0FBVyxFQUFFLENBQUM7b0JBS25CLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxHQUFHLEVBQUUsQ0FBQztvQkFFOUIsSUFBSSxDQUFDLFVBQVUsR0FBRyxFQUFFLENBQUM7b0JBRXJCLGdDQUFnQztvQkFDaEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsWUFBWSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7b0JBQ3hELElBQUksQ0FBQyxLQUFLLEdBQUcsWUFBWSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7b0JBQ3ZDLElBQUksQ0FBQyxPQUFPLEdBQUcsZ0JBQWdCLENBQUMsTUFBTSxDQUFDO29CQUN2QyxpQ0FBaUM7Z0JBQ3JDLENBQUM7Z0JBQ0QsZ0NBQVMsR0FBVDtvQkFDSSx1QkFBdUI7b0JBRDNCLGlCQW1EQztvQkFoREcsNEJBQTRCO29CQUU1QixnQ0FBZ0M7b0JBQ2hDLElBQUksV0FBVyxHQUFHLElBQUksQ0FBQyxPQUFPLEdBQUcsc0JBQXNCLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUM7b0JBQ3pGLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQzt3QkFDdEIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQzs0QkFFckMsaUJBQWlCOzRCQUNqQixJQUFJLENBQUMsZUFBZSxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTtnQ0FDekYsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQztnQ0FDdEIsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7Z0NBQ3RDLEtBQUksQ0FBQyxZQUFZLEdBQUcsRUFBRSxDQUFDO2dDQUN2QixLQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztnQ0FFeEIsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO29DQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO3dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTt3Q0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO3dDQUM1QixPQUFPLEVBQUU7NENBQ0wsRUFBRSxFQUFFO2dEQUNBLGNBQWM7Z0RBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTOzZDQUM1Qjt5Q0FDSjtxQ0FDSixDQUFDLENBQUM7Z0NBQ1AsQ0FBQztnQ0FDRCxJQUFJLENBQUMsQ0FBQztvQ0FDRixFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFNBQVMsSUFBSSxTQUFTLElBQUksUUFBUSxDQUFDLElBQUksQ0FBQyxTQUFTLElBQUksRUFBRSxJQUFJLFFBQVEsQ0FBQyxJQUFJLENBQUMsU0FBUyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7d0NBQzNHLFdBQVcsR0FBRyxLQUFJLENBQUMsT0FBTyxHQUFHLGNBQWMsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQztvQ0FDMUUsQ0FBQztvQ0FDRCxJQUFJLENBQUMsQ0FBQzt3Q0FDRixXQUFXLEdBQUcsS0FBSSxDQUFDLE9BQU8sR0FBRyxlQUFlLENBQUM7b0NBQ2pELENBQUM7b0NBQ0QsUUFBUSxDQUFDLFFBQVEsR0FBRyxXQUFXLENBQUM7Z0NBRXBDLENBQUM7Z0NBQ0QsS0FBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7Z0NBQ3BCLEtBQUksQ0FBQyxHQUFHLEdBQUcsUUFBUSxDQUFDLE1BQU0sQ0FBQzs0QkFDL0IsQ0FBQyxFQUNHLFVBQUEsS0FBSyxJQUFHLE9BQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBbEIsQ0FBa0IsRUFDMUIsY0FBTSxPQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsc0JBQXNCLENBQUMsRUFBbkMsQ0FBbUMsQ0FDNUMsQ0FBQzt3QkFFTixDQUFDO29CQUNMLENBQUM7b0JBQ0QsSUFBSSxDQUFDLENBQUM7d0JBQ0YsUUFBUSxDQUFDLFFBQVEsR0FBRyxXQUFXLENBQUM7b0JBQ3BDLENBQUM7Z0JBQ0wsQ0FBQztnQkFDRCx1Q0FBZ0IsR0FBaEI7b0JBQUEsaUJBb0ZDO29CQW5GRyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUNyQyxJQUFJLENBQUMsWUFBWSxHQUFHLFVBQVUsQ0FBQzt3QkFDL0IsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7d0JBQ3ZCLGtFQUFrRTt3QkFDbEUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDO3dCQUNuRCxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQzt3QkFDNUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQTt3QkFDbEIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFROzRCQUMxRyxPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDOzRCQUN0QixRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzs0QkFDdEMsS0FBSSxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUM7NEJBQ3ZCLEtBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDOzRCQUV4QixFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7Z0NBQzNCLHlCQUF5QjtnQ0FDekIsS0FBSSxDQUFDLFFBQVEsR0FBRyxhQUFhLENBQUM7NEJBQ2xDLENBQUM7NEJBQ0QsSUFBSSxDQUFDLENBQUM7Z0NBQ0YseUJBQXlCO2dDQUN6QixZQUFZO2dDQUVaLElBQUksV0FBVyxHQUFHLEtBQUksQ0FBQyxPQUFPLEdBQUcsc0JBQXNCLEdBQUcsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUM7Z0NBQ3pGLEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxLQUFLLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQztvQ0FDdEIsRUFBRSxDQUFDLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3Q0FHckMsS0FBSSxDQUFDLGVBQWUsQ0FBQyxxQkFBcUIsQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7NENBQ3pGLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUM7NENBQ3RCLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDOzRDQUN0QyxLQUFJLENBQUMsWUFBWSxHQUFHLEVBQUUsQ0FBQzs0Q0FDdkIsS0FBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7NENBRXhCLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQztnREFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztvREFDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07b0RBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtvREFDNUIsT0FBTyxFQUFFO3dEQUNMLEVBQUUsRUFBRTs0REFDQSxjQUFjOzREQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUzt5REFDNUI7cURBQ0o7aURBQ0osQ0FBQyxDQUFDOzRDQUNQLENBQUM7NENBQ0QsSUFBSSxDQUFDLENBQUM7Z0RBQ0YsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxTQUFTLElBQUksU0FBUyxJQUFJLFFBQVEsQ0FBQyxJQUFJLENBQUMsU0FBUyxJQUFJLEVBQUUsSUFBSSxRQUFRLENBQUMsSUFBSSxDQUFDLFNBQVMsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO29EQUMzRyxXQUFXLEdBQUcsS0FBSSxDQUFDLE9BQU8sR0FBRyxjQUFjLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUM7Z0RBQzFFLENBQUM7Z0RBQ0QsSUFBSSxDQUFDLENBQUM7b0RBQ0YsV0FBVyxHQUFHLEtBQUksQ0FBQyxPQUFPLEdBQUcsZUFBZSxDQUFDO2dEQUNqRCxDQUFDO2dEQUNELFFBQVEsQ0FBQyxRQUFRLEdBQUcsV0FBVyxDQUFDOzRDQUNwQyxDQUFDOzRDQUNELEtBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDOzRDQUNwQixLQUFJLENBQUMsR0FBRyxHQUFHLFFBQVEsQ0FBQyxNQUFNLENBQUM7d0NBQy9CLENBQUMsRUFDRyxVQUFBLEtBQUssSUFBRyxPQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEVBQWxCLENBQWtCLEVBQzFCLGNBQU0sT0FBQSxPQUFPLENBQUMsR0FBRyxDQUFDLHNCQUFzQixDQUFDLEVBQW5DLENBQW1DLENBQzVDLENBQUM7b0NBRU4sQ0FBQztnQ0FDTCxDQUFDO2dDQUNELElBQUksQ0FBQyxDQUFDO29DQUNGLFFBQVEsQ0FBQyxRQUFRLEdBQUcsV0FBVyxDQUFDO2dDQUNwQyxDQUFDO2dDQUdELEtBQUksQ0FBQyxRQUFRLEdBQUcsY0FBYyxDQUFDO2dDQUkvQix1QkFBdUI7Z0NBRXZCLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUM7Z0NBQzFCLEtBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQzs0QkFDbEMsQ0FBQzs0QkFDRCxLQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQzs0QkFDcEIsS0FBSSxDQUFDLEdBQUcsR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDO3dCQUMvQixDQUFDLEVBQ0csVUFBQSxLQUFLLElBQUcsT0FBQSxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxFQUFsQixDQUFrQixFQUMxQixjQUFNLE9BQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQkFBc0IsQ0FBQyxFQUFuQyxDQUFtQyxDQUM1QyxDQUFDO29CQUNOLENBQUM7Z0JBQ0wsQ0FBQztnQkFDRCwrQkFBUSxHQUFSO29CQUFBLGlCQXFGQztvQkFuRkcsSUFBSSxDQUFDLElBQUksR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUN6QyxJQUFJLENBQUMsS0FBSyxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUM7b0JBRzNDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ3JDLElBQUksQ0FBQyxlQUFlLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTs0QkFDL0UsV0FBVzs0QkFDWCxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzs0QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO2dDQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO29DQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtvQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO29DQUM1QixPQUFPLEVBQUU7d0NBQ0wsRUFBRSxFQUFFOzRDQUNBLGNBQWM7NENBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3lDQUM1QjtxQ0FDSjtpQ0FDSixDQUFDLENBQUM7Z0NBQ0gsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQztnQ0FDMUIsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztnQ0FFM0IsQ0FBQyxDQUFDLENBQUM7NEJBQ1AsQ0FBQzs0QkFDRCxJQUFJLENBQUMsQ0FBQztnQ0FDRiwwRUFBMEU7Z0NBRTFFLEtBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7Z0NBQ3pDLGtGQUFrRjtnQ0FDbEYsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dDQUM1QyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsUUFBUSxDQUFDO2dDQUUzQixDQUFDLENBQUMsQ0FBQzs0QkFHZixDQUFDO3dCQUFBLENBQUEsQUFBQyxFQUFDLFVBQUEsS0FBSzs0QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO3dCQUN2QixDQUFDLEVBQUU7NEJBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTt3QkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBQ1AsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDO3dCQUUxQixNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsUUFBUSxDQUFDO3dCQUUzQixDQUFDLENBQUMsQ0FBQztvQkFDUCxDQUFDO29CQUdELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFFekUsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLEdBQUcsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO3dCQU83QixDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO2dCQUtQLENBQUM7Z0JBNU9NLG9CQUFPLEdBQUcsQ0FBQyxRQUFRLEVBQUUsT0FBTyxFQUFFLGdCQUFnQixDQUFDLENBQUM7Z0JBdEIzRDtvQkFBQyxnQkFBUyxDQUFDO3dCQUVQLFdBQVcsRUFBRSxnREFBZ0Q7d0JBQzdELFVBQVUsRUFBRSxDQUFDLGlCQUFRLEVBQUUscUJBQVksRUFBRSx3QkFBZSxDQUFDO3dCQUNyRCxTQUFTLEVBQUUsQ0FBQywrQkFBYyxFQUFFLGlDQUFlLENBQUM7cUJBQy9DLENBQUM7O2dDQUFBO2dCQThQRixtQkFBQztZQUFELENBNVBBLEFBNFBDLElBQUE7WUE1UEQsdUNBNFBDLENBQUEiLCJmaWxlIjoiZGV2L2FtYXgvUmVjaWVwdFR5cGUvVGVtcGxhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyIvL2ltcG9ydCB7TmdNb2R1bGV9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG4vL2ltcG9ydCB7Rm9ybXNNb2R1bGV9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcclxuaW1wb3J0IHtDb21wb25lbnQsIE91dHB1dCwgSW5wdXQsIEV2ZW50RW1pdHRlciwgT25Jbml0fSBmcm9tIFwiYW5ndWxhcjIvY29yZVwiO1xyXG5pbXBvcnQge05nU3dpdGNoLCBOZ1N3aXRjaFdoZW4sIE5nU3dpdGNoRGVmYXVsdH0gZnJvbSAnYW5ndWxhcjIvY29tbW9uJ1xyXG5pbXBvcnQge1Jlc291cmNlU2VydmljZX0gZnJvbSBcIi4uLy4uL3NlcnZpY2VzL1Jlc291cmNlU2VydmljZVwiO1xyXG5pbXBvcnQge1JvdXRlUGFyYW1zfSBmcm9tIFwiYW5ndWxhcjIvcm91dGVyXCI7XHJcbmltcG9ydCB7UmVjaWVwdFNlcnZpY2V9IGZyb20gXCIuLi8uLi9zZXJ2aWNlcy9SZWNpZXB0U2VydmljZVwiO1xyXG5pbXBvcnQgeyBqc29uUSB9IGZyb20gJy4uLy4uL2pzb25RJztcclxuaW1wb3J0IHtHcm91cEZpbHRlclBpcGUsIEdyb3VwUGFyZW5GaWx0ZXJQaXBlLCBLZW5kb191dGlsaXR5fSBmcm9tIFwiLi4vLi4vYW1heFV0aWxcIjtcclxuLy9pbXBvcnQge0NLRWRpdG9yTW9kdWxlfSBmcm9tICduZzItY2tlZGl0b3InO1xyXG5cclxuZGVjbGFyZSB2YXIgalF1ZXJ5O1xyXG5kZWNsYXJlIHZhciBDS0VESVRPUjtcclxuLy9ATmdNb2R1bGUoe1xyXG4vLyAgICBpbXBvcnRzOiBbXHJcbi8vICAgICAgICBDS0VkaXRvck1vZHVsZVxyXG4vLyAgICBdXHJcbi8vICAgIC8vLGRlY2xhcmF0aW9uczogW1xyXG4vLyAgICAvLyAgICBBcHAsXHJcbi8vICAgIC8vXSxcclxuLy8gICAgLy9ib290c3RyYXA6IFtBcHBdXHJcbi8vfSlcclxuQENvbXBvbmVudCh7XHJcblxyXG4gICAgdGVtcGxhdGVVcmw6ICcuL2FwcC9hbWF4L1JlY2llcHRUeXBlL3RlbXBsYXRlcy9UZW1wbGF0ZS5odG1sJyxcclxuICAgIGRpcmVjdGl2ZXM6IFtOZ1N3aXRjaCwgTmdTd2l0Y2hXaGVuLCBOZ1N3aXRjaERlZmF1bHRdLFxyXG4gICAgcHJvdmlkZXJzOiBbUmVjaWVwdFNlcnZpY2UsIFJlc291cmNlU2VydmljZV1cclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBBbWF4VGVtcGxhdGUgaW1wbGVtZW50cyBPbkluaXQge1xyXG4gICAgUkVTOiBPYmplY3QgPSB7fTtcclxuICAgIEZvcm10eXBlOiBzdHJpbmcgPSBcIlNDUkVFTl9FRElUVEVNUFwiO1xyXG4gICAgTGFuZzogc3RyaW5nID0gXCJcIjtcclxuICAgIE1zZ0NsYXNzOiBzdHJpbmcgPSBcInRleHQtcHJpbWFyeVwiO1xyXG4gICAgbW9kZWxJbnB1dDogT2JqZWN0ID0ge307XHJcbiAgICBJc2J0bmRpc2FibGU6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBTaG93TG9hZGVyOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBTaG93TXNnOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBGUGFnZTogc3RyaW5nPVwiXCI7XHJcbiAgICBNc2c6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBPcmdJZDogc3RyaW5nID0gXCJcIjtcclxuICAgIGJhc2VVcmw6IHN0cmluZztcclxuICAgIENoYW5nZURpYWxvZzogc3RyaW5nID0gXCJcIjtcclxuICAgIENIQU5HRURJUjogc3RyaW5nID0gXCJcIjtcclxuICAgIHN0YXRpYyAkaW5qZWN0ID0gWyckc2NvcGUnLCAnJGh0dHAnLCAnJHRlbXBsYXRlQ2FjaGUnXTtcclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgX3Jlc291cmNlU2VydmljZTogUmVzb3VyY2VTZXJ2aWNlLCBwcml2YXRlIF9SZWNpZXB0U2VydmljZTogUmVjaWVwdFNlcnZpY2UsXHJcbiAgICAgICAgcHJpdmF0ZSBfcm91dGVQYXJhbXM6IFJvdXRlUGFyYW1zKSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5SRVMuU0NSRUVOX0VESVRURU1QID0ge307XHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0ID0ge307XHJcbiAgICAgICAgXHJcbiAgICAgICAgLy9hbGVydChfcm91dGVQYXJhbXMucGFyYW1zLklkKTtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuVGhhbmtzTGV0dGVySWQgPSBfcm91dGVQYXJhbXMucGFyYW1zLklkO1xyXG4gICAgICAgIHRoaXMuRlBhZ2UgPSBfcm91dGVQYXJhbXMucGFyYW1zLkZQYWdlO1xyXG4gICAgICAgIHRoaXMuYmFzZVVybCA9IF9yZXNvdXJjZVNlcnZpY2UuQXBwVXJsO1xyXG4gICAgICAgIC8vdGhpcy5nZXRSY2VpcHRUaG5rc0xldHRlckRldCgpO1xyXG4gICAgfVxyXG4gICAgQ2FuY2VsQnRuKCkge1xyXG4gICAgICAgIC8vdGhpcy5tb2RlbElucHV0ID0ge307XHJcblxyXG4gICAgICAgIC8valF1ZXJ5KFwiI2VkaXRvclwiKS52YWwoXCJcIik7XHJcblxyXG4gICAgICAgIC8vdGhpcy5tb2RlbElucHV0Lk1haWxCb2R5ID0gXCJcIjtcclxuICAgICAgICB2YXIgcmVkcmVzcG9uc2UgPSB0aGlzLmJhc2VVcmwgKyBcIlJlY2VpcHRUZW1wbGF0ZS9BZGQvXCIgKyB0aGlzLm1vZGVsSW5wdXQuVGhhbmtzTGV0dGVySWQ7XHJcbiAgICAgICAgaWYgKHRoaXMuRlBhZ2UgPT0gXCJSZWNcIikge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LlRoYW5rc0xldHRlcklkID4gMCkge1xyXG5cclxuICAgICAgICAgICAgICAgIC8vYWxlcnQoJ0hlbGxvJyk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9SZWNpZXB0U2VydmljZS5HZXRSZWNpZXB0VGhua3NMZXR0ZXIodGhpcy5tb2RlbElucHV0LlRoYW5rc0xldHRlcklkKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2cocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5Jc2J0bmRpc2FibGUgPSBcIlwiO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuU2hvd0xvYWRlciA9IGZhbHNlO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5EYXRhLlJlY2VpcHRJZCAhPSB1bmRlZmluZWQgJiYgcmVzcG9uc2UuRGF0YS5SZWNlaXB0SWQgIT0gXCJcIiAmJiByZXNwb25zZS5EYXRhLlJlY2VpcHRJZCAhPSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWRyZXNwb25zZSA9IHRoaXMuYmFzZVVybCArIFwiUmVjZWlwdFR5cGUvXCIgKyByZXNwb25zZS5EYXRhLlJlY2VpcHRJZDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlZHJlc3BvbnNlID0gdGhpcy5iYXNlVXJsICsgXCJSZWNlaXB0VHlwZS8wXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgZG9jdW1lbnQubG9jYXRpb24gPSByZWRyZXNwb25zZTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuU2hvd01zZyA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5Nc2cgPSByZXNwb25zZS5FcnJNc2c7XHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgIGVycm9yPT4gY29uc29sZS5sb2coZXJyb3IpLFxyXG4gICAgICAgICAgICAgICAgICAgICgpID0+IGNvbnNvbGUubG9nKFwiU2F2ZSBDYWxsIENvbXBsZWF0ZWRcIilcclxuICAgICAgICAgICAgICAgICk7XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBkb2N1bWVudC5sb2NhdGlvbiA9IHJlZHJlc3BvbnNlO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIHNhdmVUZW1wbGF0ZURhdGEoKSB7XHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5UaGFua3NMZXR0ZXJJZCA+IDApIHtcclxuICAgICAgICAgICAgdGhpcy5Jc2J0bmRpc2FibGUgPSBcImRpc2FibGVkXCI7XHJcbiAgICAgICAgICAgIHRoaXMuU2hvd0xvYWRlciA9IHRydWU7XHJcbiAgICAgICAgICAgIC8vdGhpcy5tb2RlbElucHV0LlJlY2VpcHRJZCA9IHBhcnNlSW50KHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0SWQpO1xyXG4gICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuTWFpbEJvZHkgPSBqUXVlcnkoXCIjZWRpdG9yXCIpLnZhbCgpO1xyXG4gICAgICAgICAgICB2YXIgamRhdGEgPSBKU09OLnN0cmluZ2lmeSh0aGlzLm1vZGVsSW5wdXQpO1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhqZGF0YSlcclxuICAgICAgICAgICAgdGhpcy5fUmVjaWVwdFNlcnZpY2UuU2F2ZVRlbXBsYXRlKHRoaXMubW9kZWxJbnB1dC5UaGFua3NMZXR0ZXJJZCwgdGhpcy5tb2RlbElucHV0Lk1haWxCb2R5KS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhyZXNwb25zZSk7XHJcbiAgICAgICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5Jc2J0bmRpc2FibGUgPSBcIlwiO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5TaG93TG9hZGVyID0gZmFsc2U7XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIC8vYWxlcnQocmVzcG9uc2UuRXJyTXNnKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLk1zZ0NsYXNzID0gXCJ0ZXh0LWRhbmdlclwiO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9hbGVydChyZXNwb25zZS5FcnJNc2cpO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIGRlYnVnZ2VyO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICB2YXIgcmVkcmVzcG9uc2UgPSB0aGlzLmJhc2VVcmwgKyBcIlJlY2VpcHRUZW1wbGF0ZS9BZGQvXCIgKyB0aGlzLm1vZGVsSW5wdXQuVGhhbmtzTGV0dGVySWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuRlBhZ2UgPT0gXCJSZWNcIikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LlRoYW5rc0xldHRlcklkID4gMCkge1xyXG5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9SZWNpZXB0U2VydmljZS5HZXRSZWNpZXB0VGhua3NMZXR0ZXIodGhpcy5tb2RlbElucHV0LlRoYW5rc0xldHRlcklkKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2cocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5Jc2J0bmRpc2FibGUgPSBcIlwiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuU2hvd0xvYWRlciA9IGZhbHNlO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5EYXRhLlJlY2VpcHRJZCAhPSB1bmRlZmluZWQgJiYgcmVzcG9uc2UuRGF0YS5SZWNlaXB0SWQgIT0gXCJcIiAmJiByZXNwb25zZS5EYXRhLlJlY2VpcHRJZCAhPSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWRyZXNwb25zZSA9IHRoaXMuYmFzZVVybCArIFwiUmVjZWlwdFR5cGUvXCIgKyByZXNwb25zZS5EYXRhLlJlY2VpcHRJZDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlZHJlc3BvbnNlID0gdGhpcy5iYXNlVXJsICsgXCJSZWNlaXB0VHlwZS8wXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZG9jdW1lbnQubG9jYXRpb24gPSByZWRyZXNwb25zZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5TaG93TXNnID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLk1zZyA9IHJlc3BvbnNlLkVyck1zZztcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZXJyb3I9PiBjb25zb2xlLmxvZyhlcnJvciksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKCkgPT4gY29uc29sZS5sb2coXCJTYXZlIENhbGwgQ29tcGxlYXRlZFwiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRvY3VtZW50LmxvY2F0aW9uID0gcmVkcmVzcG9uc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5Nc2dDbGFzcyA9IFwidGV4dC1zdWNjZXNzXCI7XHJcblxyXG5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgLy90aGlzLm1vZGVsSW5wdXQgPSB7fTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5KFwiI2VkaXRvclwiKS52YWwoXCJcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0Lk1haWxCb2R5ID0gXCJcIjtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHRoaXMuU2hvd01zZyA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICB0aGlzLk1zZyA9IHJlc3BvbnNlLkVyck1zZztcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIGVycm9yPT4gY29uc29sZS5sb2coZXJyb3IpLFxyXG4gICAgICAgICAgICAgICAgKCkgPT4gY29uc29sZS5sb2coXCJTYXZlIENhbGwgQ29tcGxlYXRlZFwiKVxyXG4gICAgICAgICAgICApO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIG5nT25Jbml0KCkge1xyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMuTGFuZyA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwibGFuZ1wiKTtcclxuICAgICAgICB0aGlzLk9yZ0lkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJPcmdJZFwiKTtcclxuXHJcbiAgICAgICAgXHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5UaGFua3NMZXR0ZXJJZCA+IDApIHtcclxuICAgICAgICAgICAgdGhpcy5fUmVjaWVwdFNlcnZpY2UuR2V0VGVtcGxhdGUodGhpcy5tb2RlbElucHV0LlRoYW5rc0xldHRlcklkKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5KFwiI2VkaXRvclwiKS52YWwoXCJcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5KCcjZWRpdG9yJykuY2tlZGl0b3IoZnVuY3Rpb24gKCkge1xyXG5cclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIC8vdGhpcy5tb2RlbElucHV0LlRoYW5rc0xldHRlck5hbWVFbmcgPSByZXNwb25zZS5EYXRhLlRoYW5rc0xldHRlck5hbWVFbmc7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5NYWlsQm9keSA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9pZiAodGhpcy5tb2RlbElucHV0Lk1haWxCb2R5ICE9IHVuZGVmaW5lZCAmJiB0aGlzLm1vZGVsSW5wdXQuTWFpbEJvZHkgIT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeShcIiNlZGl0b3JcIikudmFsKHRoaXMubW9kZWxJbnB1dC5NYWlsQm9keSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGpRdWVyeSgnI2VkaXRvcicpLmNrZWRpdG9yKGZ1bmN0aW9uICgpIHtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgLy8gfVxyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgalF1ZXJ5KFwiI2VkaXRvclwiKS52YWwoXCJcIik7XHJcblxyXG4gICAgICAgICAgICBqUXVlcnkoJyNlZGl0b3InKS5ja2VkaXRvcihmdW5jdGlvbiAoKSB7XHJcblxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcblxyXG4gICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5HZXRMYW5nUmVzKHRoaXMuRm9ybXR5cGUsIHRoaXMuTGFuZykuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG5cclxuICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5SRVMgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgLy9pZiAodGhpcy5tb2RlbElucHV0LlRoYW5rc0xldHRlcklkICE9IDApIHtcclxuICAgICAgICAgICAgICAgIC8vICAgIHRoaXMuU0FWRV9CVE5fVEVYVCA9IHRoaXMuUkVTLlNDUkVFTl9BRERSRUNJRVBUVEVNUC5BUFBfQlROX1VQREFURTtcclxuICAgICAgICAgICAgICAgIC8vfVxyXG4gICAgICAgICAgICAgICAgLy9lbHNlIHtcclxuICAgICAgICAgICAgICAgIC8vICAgIHRoaXMuU0FWRV9CVE5fVEVYVCA9IHRoaXMuUkVTLlNDUkVFTl9BRERSRUNJRVBUVEVNUC5BUFBfQlROX1NBVkU7XHJcbiAgICAgICAgICAgICAgICAvL31cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuICAgICAgICBcclxuXHJcbiAgICAgICAgXHJcbiAgICAgICAgXHJcbiAgICB9XHJcbn1cclxuIl19
