System.register(["angular2/core", 'angular2/common', "../../services/ResourceService", "angular2/router", "../../services/RecieptService"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, common_1, ResourceService_1, router_1, RecieptService_1;
    var AmaxReciept;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (ResourceService_1_1) {
                ResourceService_1 = ResourceService_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (RecieptService_1_1) {
                RecieptService_1 = RecieptService_1_1;
            }],
        execute: function() {
            AmaxReciept = (function () {
                // @ViewChild('RTLDiv') private myScrollContainer: ElementRef;
                function AmaxReciept(_resourceService, _RecieptService, _routeParams) {
                    this._resourceService = _resourceService;
                    this._RecieptService = _RecieptService;
                    this._routeParams = _routeParams;
                    this.RES = {};
                    this.Formtype = "SCREEN_RECIEPTTYPE";
                    this.Lang = "";
                    this._RecieptTypeList = [];
                    this._RecieptThnksLettersList = [];
                    this.ReceiptId = -1;
                    this.ReceiptName = "";
                    this.MsgClass = "text-primary";
                    this.modelInput = {};
                    this.ChangeDialog = "";
                    this.CHANGEDIR = "";
                    this.RES.SCREEN_RECIEPTTYPE = {};
                    this.ReceiptName = "";
                    this.modelInput = {};
                    //this.baseUrl = "http://localhost:3000/#/";
                    //debugger;
                    this.baseUrl = _resourceService.AppUrl;
                    this.ReceiptId = _routeParams.params.Id;
                }
                AmaxReciept.prototype.bindReceiptThnksLetterList = function () {
                    var _this = this;
                    this._RecieptService.GetRecieptThnksLettersList(this.ReceiptId).subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._RecieptThnksLettersList = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                //app.controller('TestCtrl', function($scope, $location, $anchorScroll) {
                AmaxReciept.prototype.ViewTemplates = function (ReceiptObj) {
                    //debugger;
                    this.ReceiptId = ReceiptObj.RecieptTypeId;
                    this.ReceiptName = ReceiptObj.RecieptNameEng + " | " + ReceiptObj.RecieptName;
                    this.bindReceiptThnksLetterList();
                    var dist = jQuery('#RTLDiv').offset().top - jQuery('#RTDiv').offset().top;
                    window.scrollTo(0, dist + 10);
                    //var response = this.baseUrl + "/ReceiptType/#RTLDiv";
                    //alert(response);
                    //document.location = response;
                    //$location.hash('RTLDiv');
                    //$anchorScroll();
                    //this.myScrollContainer.nativeElement.scrollTop = this.myScrollContainer.nativeElement.scrollHeight;
                };
                //}
                AmaxReciept.prototype.deleteReceiptThnksLetter = function (RTLObj) {
                    var _this = this;
                    if (confirm("Do you want to delete")) {
                        this._RecieptService.DeleteReceiptThnksLetter(RTLObj.ThanksLetterId).subscribe(function (resp) {
                            //debugger;
                            var response = jQuery.parseJSON(resp);
                            if (response.IsError == true) {
                                bootbox.alert({
                                    message: response.ErrMsg,
                                    className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                            else {
                                //this.MsgClass = "text-success";
                                //this._RecieptTypeList = response.Data;
                                var index = 0;
                                jQuery.each(_this._RecieptThnksLettersList, function () {
                                    if (this == RTLObj) {
                                        return false;
                                    }
                                    index = index + 1;
                                });
                                _this._RecieptThnksLettersList.splice(index, 1);
                                bootbox.alert({
                                    message: response.ErrMsg,
                                    className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                        }, function (error) {
                            console.log(error);
                        }, function () {
                            console.log("CallCompleted");
                        });
                    }
                };
                AmaxReciept.prototype.AddRTLScreen = function () {
                    //if (confirm("Do you want to add new")) {
                    var response = this.baseUrl + "ReceiptTemplate/Add/0";
                    //alert(response);
                    document.location = response;
                    //}
                };
                AmaxReciept.prototype.EditTemplate = function (RcptThnksLtrObj) {
                    var response = this.baseUrl + "Template/Edit/" + RcptThnksLtrObj.ThanksLetterId + "/Rec";
                    //alert(response);
                    document.location = response;
                };
                AmaxReciept.prototype.EditReceiptThnksLetter = function (RcptThnksLtrObj) {
                    var response = this.baseUrl + "ReceiptTemplate/Add/" + RcptThnksLtrObj.ThanksLetterId;
                    //alert(response);
                    document.location = response;
                };
                AmaxReciept.prototype.ngOnInit = function () {
                    var _this = this;
                    this.Lang = localStorage.getItem("lang");
                    this._resourceService.GetLangRes(this.Formtype, this.Lang).subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.RES = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._RecieptService.GetRecieptTypeList().subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._RecieptTypeList = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    if (this.ReceiptId != 0) {
                        this.bindReceiptThnksLetterList();
                    }
                };
                AmaxReciept.$inject = ['$scope', '$location', '$anchorScroll'];
                AmaxReciept = __decorate([
                    core_1.Component({
                        templateUrl: './app/amax/RecieptType/templates/RecieptType.html',
                        directives: [common_1.NgSwitch, common_1.NgSwitchWhen, common_1.NgSwitchDefault],
                        providers: [RecieptService_1.RecieptService, ResourceService_1.ResourceService]
                    }), 
                    __metadata('design:paramtypes', [ResourceService_1.ResourceService, RecieptService_1.RecieptService, router_1.RouteParams])
                ], AmaxReciept);
                return AmaxReciept;
            }());
            exports_1("AmaxReciept", AmaxReciept);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldi9hbWF4L1JlY2llcHRUeXBlL1JlY2llcHQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7WUFpQkE7Z0JBY0csOERBQThEO2dCQUM3RCxxQkFBb0IsZ0JBQWlDLEVBQVUsZUFBK0IsRUFBVSxZQUF5QjtvQkFBN0cscUJBQWdCLEdBQWhCLGdCQUFnQixDQUFpQjtvQkFBVSxvQkFBZSxHQUFmLGVBQWUsQ0FBZ0I7b0JBQVUsaUJBQVksR0FBWixZQUFZLENBQWE7b0JBYmpJLFFBQUcsR0FBVyxFQUFFLENBQUM7b0JBQ2pCLGFBQVEsR0FBVyxvQkFBb0IsQ0FBQztvQkFDeEMsU0FBSSxHQUFXLEVBQUUsQ0FBQztvQkFDbEIscUJBQWdCLEdBQUcsRUFBRSxDQUFDO29CQUN0Qiw2QkFBd0IsR0FBRyxFQUFFLENBQUM7b0JBQzlCLGNBQVMsR0FBVyxDQUFDLENBQUMsQ0FBQztvQkFDdkIsZ0JBQVcsR0FBVyxFQUFFLENBQUM7b0JBQ3pCLGFBQVEsR0FBVyxjQUFjLENBQUM7b0JBQ2xDLGVBQVUsR0FBVyxFQUFFLENBQUM7b0JBQ3hCLGlCQUFZLEdBQVcsRUFBRSxDQUFDO29CQUMxQixjQUFTLEdBQVcsRUFBRSxDQUFDO29CQUtuQixJQUFJLENBQUMsR0FBRyxDQUFDLGtCQUFrQixHQUFHLEVBQUUsQ0FBQztvQkFDakMsSUFBSSxDQUFDLFdBQVcsR0FBRyxFQUFFLENBQUM7b0JBQ3RCLElBQUksQ0FBQyxVQUFVLEdBQUcsRUFBRSxDQUFDO29CQUNyQiw0Q0FBNEM7b0JBQzVDLFdBQVc7b0JBQ1gsSUFBSSxDQUFDLE9BQU8sR0FBRyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUM7b0JBQ3ZDLElBQUksQ0FBQyxTQUFTLEdBQUcsWUFBWSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7Z0JBQzVDLENBQUM7Z0JBRUQsZ0RBQTBCLEdBQTFCO29CQUFBLGlCQXlCQztvQkF4QkcsSUFBSSxDQUFDLGVBQWUsQ0FBQywwQkFBMEIsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDMUUsV0FBVzt3QkFDWCxJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO2dDQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQzVCLE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEtBQUksQ0FBQyx3QkFBd0IsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO3dCQUVsRCxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO2dCQUNQLENBQUM7Z0JBQ0QseUVBQXlFO2dCQUNyRSxtQ0FBYSxHQUFiLFVBQWMsVUFBVTtvQkFDcEIsV0FBVztvQkFDWCxJQUFJLENBQUMsU0FBUyxHQUFHLFVBQVUsQ0FBQyxhQUFhLENBQUM7b0JBQzFDLElBQUksQ0FBQyxXQUFXLEdBQUcsVUFBVSxDQUFDLGNBQWMsR0FBRyxLQUFLLEdBQUcsVUFBVSxDQUFDLFdBQVcsQ0FBQztvQkFDOUUsSUFBSSxDQUFDLDBCQUEwQixFQUFFLENBQUM7b0JBQ2xDLElBQUksSUFBSSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxHQUFHLEdBQUcsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDLEdBQUcsQ0FBQztvQkFFMUUsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsSUFBSSxHQUFDLEVBQUUsQ0FBQyxDQUFDO29CQUM1Qix1REFBdUQ7b0JBQ3ZELGtCQUFrQjtvQkFDbEIsK0JBQStCO29CQUMvQiwyQkFBMkI7b0JBQzNCLGtCQUFrQjtvQkFDbEIscUdBQXFHO2dCQUV6RyxDQUFDO2dCQUNMLEdBQUc7Z0JBQ0gsOENBQXdCLEdBQXhCLFVBQXlCLE1BQU07b0JBQS9CLGlCQThDQztvQkE3Q0csRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLHVCQUF1QixDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUNuQyxJQUFJLENBQUMsZUFBZSxDQUFDLHdCQUF3QixDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJOzRCQUMvRSxXQUFXOzRCQUNYLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7NEJBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQztnQ0FDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztvQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07b0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtvQ0FDNUIsT0FBTyxFQUFFO3dDQUNMLEVBQUUsRUFBRTs0Q0FDQSxjQUFjOzRDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUzt5Q0FDNUI7cUNBQ0o7aUNBQ0osQ0FBQyxDQUFDOzRCQUVQLENBQUM7NEJBQ0QsSUFBSSxDQUFDLENBQUM7Z0NBQ0YsaUNBQWlDO2dDQUNqQyx3Q0FBd0M7Z0NBQ3hDLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQztnQ0FDZCxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUksQ0FBQyx3QkFBd0IsRUFBRTtvQ0FDdkMsRUFBRSxDQUFDLENBQUMsSUFBSSxJQUFJLE1BQU0sQ0FBQyxDQUFDLENBQUM7d0NBQ2pCLE1BQU0sQ0FBQyxLQUFLLENBQUE7b0NBQ2hCLENBQUM7b0NBQ0QsS0FBSyxHQUFHLEtBQUssR0FBRyxDQUFDLENBQUM7Z0NBQ3RCLENBQUMsQ0FBQyxDQUFDO2dDQUNILEtBQUksQ0FBQyx3QkFBd0IsQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDO2dDQUMvQyxPQUFPLENBQUMsS0FBSyxDQUFDO29DQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtvQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO29DQUM1QixPQUFPLEVBQUU7d0NBQ0wsRUFBRSxFQUFFOzRDQUNBLGNBQWM7NENBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3lDQUM1QjtxQ0FDSjtpQ0FDSixDQUFDLENBQUM7NEJBQ1AsQ0FBQzt3QkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLOzRCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7d0JBQ3ZCLENBQUMsRUFBRTs0QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO3dCQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFDUCxDQUFDO2dCQUNMLENBQUM7Z0JBQ0Qsa0NBQVksR0FBWjtvQkFDSSwwQ0FBMEM7b0JBRXRDLElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxPQUFPLEdBQUUsdUJBQXVCLENBQUM7b0JBQ3JELGtCQUFrQjtvQkFDbEIsUUFBUSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUM7b0JBRWpDLEdBQUc7Z0JBQ1AsQ0FBQztnQkFDRCxrQ0FBWSxHQUFaLFVBQWEsZUFBZTtvQkFDeEIsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLE9BQU8sR0FBRyxnQkFBZ0IsR0FBRyxlQUFlLENBQUMsY0FBYyxHQUFDLE1BQU0sQ0FBQztvQkFDdkYsa0JBQWtCO29CQUNsQixRQUFRLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQztnQkFDakMsQ0FBQztnQkFDRCw0Q0FBc0IsR0FBdEIsVUFBdUIsZUFBZTtvQkFDbEMsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLE9BQU8sR0FBRyxzQkFBc0IsR0FBRyxlQUFlLENBQUMsY0FBYyxDQUFDO29CQUN0RixrQkFBa0I7b0JBQ2xCLFFBQVEsQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFDO2dCQUNqQyxDQUFDO2dCQUNELDhCQUFRLEdBQVI7b0JBQUEsaUJBcURDO29CQXBERyxJQUFJLENBQUMsSUFBSSxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQ3pDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFFekUsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLEdBQUcsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO3dCQUM3QixDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUVILElBQUksQ0FBQyxlQUFlLENBQUMsa0JBQWtCLEVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUNwRCxXQUFXO3dCQUNYLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLGdCQUFnQixHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7d0JBRTFDLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUN0QixJQUFJLENBQUMsMEJBQTBCLEVBQUUsQ0FBQztvQkFDdEMsQ0FBQztnQkFDTCxDQUFDO2dCQWhMTSxtQkFBTyxHQUFHLENBQUMsUUFBUSxFQUFFLFdBQVcsRUFBRSxlQUFlLENBQUMsQ0FBQztnQkFwQjlEO29CQUFDLGdCQUFTLENBQUM7d0JBRVAsV0FBVyxFQUFFLG1EQUFtRDt3QkFDaEUsVUFBVSxFQUFFLENBQUMsaUJBQVEsRUFBRSxxQkFBWSxFQUFFLHdCQUFlLENBQUM7d0JBQ3JELFNBQVMsRUFBRSxDQUFDLCtCQUFjLEVBQUUsaUNBQWUsQ0FBQztxQkFDL0MsQ0FBQzs7K0JBQUE7Z0JBZ01GLGtCQUFDO1lBQUQsQ0E5TEEsQUE4TEMsSUFBQTtZQTlMRCxxQ0E4TEMsQ0FBQSIsImZpbGUiOiJkZXYvYW1heC9SZWNpZXB0VHlwZS9SZWNpZXB0LmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtDb21wb25lbnQsIE91dHB1dCwgSW5wdXQsIEV2ZW50RW1pdHRlciwgT25Jbml0fSBmcm9tIFwiYW5ndWxhcjIvY29yZVwiO1xyXG5pbXBvcnQge05nU3dpdGNoLCBOZ1N3aXRjaFdoZW4sIE5nU3dpdGNoRGVmYXVsdH0gZnJvbSAnYW5ndWxhcjIvY29tbW9uJ1xyXG5pbXBvcnQge1Jlc291cmNlU2VydmljZX0gZnJvbSBcIi4uLy4uL3NlcnZpY2VzL1Jlc291cmNlU2VydmljZVwiO1xyXG5pbXBvcnQge1JvdXRlUGFyYW1zfSBmcm9tIFwiYW5ndWxhcjIvcm91dGVyXCI7XHJcbmltcG9ydCB7UmVjaWVwdFNlcnZpY2V9IGZyb20gXCIuLi8uLi9zZXJ2aWNlcy9SZWNpZXB0U2VydmljZVwiO1xyXG5pbXBvcnQgeyBqc29uUSB9IGZyb20gJy4uLy4uL2pzb25RJztcclxuaW1wb3J0IHtHcm91cEZpbHRlclBpcGUsIEdyb3VwUGFyZW5GaWx0ZXJQaXBlLCBLZW5kb191dGlsaXR5fSBmcm9tIFwiLi4vLi4vYW1heFV0aWxcIjtcclxuXHJcbmRlY2xhcmUgdmFyIGpRdWVyeTtcclxuXHJcbkBDb21wb25lbnQoe1xyXG5cclxuICAgIHRlbXBsYXRlVXJsOiAnLi9hcHAvYW1heC9SZWNpZXB0VHlwZS90ZW1wbGF0ZXMvUmVjaWVwdFR5cGUuaHRtbCcsXHJcbiAgICBkaXJlY3RpdmVzOiBbTmdTd2l0Y2gsIE5nU3dpdGNoV2hlbiwgTmdTd2l0Y2hEZWZhdWx0XSxcclxuICAgIHByb3ZpZGVyczogW1JlY2llcHRTZXJ2aWNlLCBSZXNvdXJjZVNlcnZpY2VdXHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgQW1heFJlY2llcHQgaW1wbGVtZW50cyBPbkluaXQge1xyXG4gICAgYmFzZVVybDogc3RyaW5nO1xyXG4gICAgUkVTOiBPYmplY3QgPSB7fTtcclxuICAgIEZvcm10eXBlOiBzdHJpbmcgPSBcIlNDUkVFTl9SRUNJRVBUVFlQRVwiO1xyXG4gICAgTGFuZzogc3RyaW5nID0gXCJcIjtcclxuICAgIF9SZWNpZXB0VHlwZUxpc3QgPSBbXTtcclxuICAgIF9SZWNpZXB0VGhua3NMZXR0ZXJzTGlzdCA9IFtdO1xyXG4gICAgUmVjZWlwdElkOiBudW1iZXIgPSAtMTtcclxuICAgIFJlY2VpcHROYW1lOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgTXNnQ2xhc3M6IHN0cmluZyA9IFwidGV4dC1wcmltYXJ5XCI7XHJcbiAgICBtb2RlbElucHV0OiBPYmplY3QgPSB7fTtcclxuICAgIENoYW5nZURpYWxvZzogc3RyaW5nID0gXCJcIjtcclxuICAgIENIQU5HRURJUjogc3RyaW5nID0gXCJcIjtcclxuICAgIHN0YXRpYyAkaW5qZWN0ID0gWyckc2NvcGUnLCAnJGxvY2F0aW9uJywgJyRhbmNob3JTY3JvbGwnXTtcclxuICAgLy8gQFZpZXdDaGlsZCgnUlRMRGl2JykgcHJpdmF0ZSBteVNjcm9sbENvbnRhaW5lcjogRWxlbWVudFJlZjtcclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgX3Jlc291cmNlU2VydmljZTogUmVzb3VyY2VTZXJ2aWNlLCBwcml2YXRlIF9SZWNpZXB0U2VydmljZTogUmVjaWVwdFNlcnZpY2UsIHByaXZhdGUgX3JvdXRlUGFyYW1zOiBSb3V0ZVBhcmFtcykge1xyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMuUkVTLlNDUkVFTl9SRUNJRVBUVFlQRSA9IHt9O1xyXG4gICAgICAgIHRoaXMuUmVjZWlwdE5hbWUgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dCA9IHt9O1xyXG4gICAgICAgIC8vdGhpcy5iYXNlVXJsID0gXCJodHRwOi8vbG9jYWxob3N0OjMwMDAvIy9cIjtcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgIHRoaXMuYmFzZVVybCA9IF9yZXNvdXJjZVNlcnZpY2UuQXBwVXJsO1xyXG4gICAgICAgIHRoaXMuUmVjZWlwdElkID0gX3JvdXRlUGFyYW1zLnBhcmFtcy5JZDtcclxuICAgIH1cclxuICAgIFxyXG4gICAgYmluZFJlY2VpcHRUaG5rc0xldHRlckxpc3QoKSB7XHJcbiAgICAgICAgdGhpcy5fUmVjaWVwdFNlcnZpY2UuR2V0UmVjaWVwdFRobmtzTGV0dGVyc0xpc3QodGhpcy5SZWNlaXB0SWQpLnN1YnNjcmliZShyZXNwPT4ge1xyXG4gICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICB2YXIgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3ApO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9SZWNpZXB0VGhua3NMZXR0ZXJzTGlzdCA9IHJlc3BvbnNlLkRhdGE7XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG4gICAgLy9hcHAuY29udHJvbGxlcignVGVzdEN0cmwnLCBmdW5jdGlvbigkc2NvcGUsICRsb2NhdGlvbiwgJGFuY2hvclNjcm9sbCkge1xyXG4gICAgICAgIFZpZXdUZW1wbGF0ZXMoUmVjZWlwdE9iaikge1xyXG4gICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICB0aGlzLlJlY2VpcHRJZCA9IFJlY2VpcHRPYmouUmVjaWVwdFR5cGVJZDtcclxuICAgICAgICAgICAgdGhpcy5SZWNlaXB0TmFtZSA9IFJlY2VpcHRPYmouUmVjaWVwdE5hbWVFbmcgKyBcIiB8IFwiICsgUmVjZWlwdE9iai5SZWNpZXB0TmFtZTtcclxuICAgICAgICAgICAgdGhpcy5iaW5kUmVjZWlwdFRobmtzTGV0dGVyTGlzdCgpOyBcclxuICAgICAgICAgICAgdmFyIGRpc3QgPSBqUXVlcnkoJyNSVExEaXYnKS5vZmZzZXQoKS50b3AgLSBqUXVlcnkoJyNSVERpdicpLm9mZnNldCgpLnRvcDtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIHdpbmRvdy5zY3JvbGxUbygwLCBkaXN0KzEwKTtcclxuICAgICAgICAgICAgLy92YXIgcmVzcG9uc2UgPSB0aGlzLmJhc2VVcmwgKyBcIi9SZWNlaXB0VHlwZS8jUlRMRGl2XCI7XHJcbiAgICAgICAgICAgIC8vYWxlcnQocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICAvL2RvY3VtZW50LmxvY2F0aW9uID0gcmVzcG9uc2U7XHJcbiAgICAgICAgICAgIC8vJGxvY2F0aW9uLmhhc2goJ1JUTERpdicpO1xyXG4gICAgICAgICAgICAvLyRhbmNob3JTY3JvbGwoKTtcclxuICAgICAgICAgICAgLy90aGlzLm15U2Nyb2xsQ29udGFpbmVyLm5hdGl2ZUVsZW1lbnQuc2Nyb2xsVG9wID0gdGhpcy5teVNjcm9sbENvbnRhaW5lci5uYXRpdmVFbGVtZW50LnNjcm9sbEhlaWdodDtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgfVxyXG4gICAgLy99XHJcbiAgICBkZWxldGVSZWNlaXB0VGhua3NMZXR0ZXIoUlRMT2JqKSB7XHJcbiAgICAgICAgaWYgKGNvbmZpcm0oXCJEbyB5b3Ugd2FudCB0byBkZWxldGVcIikpIHtcclxuICAgICAgICAgICAgdGhpcy5fUmVjaWVwdFNlcnZpY2UuRGVsZXRlUmVjZWlwdFRobmtzTGV0dGVyKFJUTE9iai5UaGFua3NMZXR0ZXJJZCkuc3Vic2NyaWJlKHJlc3A9PiB7XHJcbiAgICAgICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy90aGlzLk1zZ0NsYXNzID0gXCJ0ZXh0LWRhbmdlclwiO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy90aGlzLk1zZ0NsYXNzID0gXCJ0ZXh0LXN1Y2Nlc3NcIjtcclxuICAgICAgICAgICAgICAgICAgICAvL3RoaXMuX1JlY2llcHRUeXBlTGlzdCA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIGluZGV4ID0gMDtcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLl9SZWNpZXB0VGhua3NMZXR0ZXJzTGlzdCwgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcyA9PSBSVExPYmopIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGluZGV4ID0gaW5kZXggKyAxO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX1JlY2llcHRUaG5rc0xldHRlcnNMaXN0LnNwbGljZShpbmRleCwgMSk7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIEFkZFJUTFNjcmVlbigpIHtcclxuICAgICAgICAvL2lmIChjb25maXJtKFwiRG8geW91IHdhbnQgdG8gYWRkIG5ld1wiKSkge1xyXG5cclxuICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0gdGhpcy5iYXNlVXJsICtcIlJlY2VpcHRUZW1wbGF0ZS9BZGQvMFwiO1xyXG4gICAgICAgICAgICAvL2FsZXJ0KHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgZG9jdW1lbnQubG9jYXRpb24gPSByZXNwb25zZTtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgLy99XHJcbiAgICB9XHJcbiAgICBFZGl0VGVtcGxhdGUoUmNwdFRobmtzTHRyT2JqKSB7XHJcbiAgICAgICAgdmFyIHJlc3BvbnNlID0gdGhpcy5iYXNlVXJsICsgXCJUZW1wbGF0ZS9FZGl0L1wiICsgUmNwdFRobmtzTHRyT2JqLlRoYW5rc0xldHRlcklkK1wiL1JlY1wiO1xyXG4gICAgICAgIC8vYWxlcnQocmVzcG9uc2UpO1xyXG4gICAgICAgIGRvY3VtZW50LmxvY2F0aW9uID0gcmVzcG9uc2U7XHJcbiAgICB9XHJcbiAgICBFZGl0UmVjZWlwdFRobmtzTGV0dGVyKFJjcHRUaG5rc0x0ck9iaikge1xyXG4gICAgICAgIHZhciByZXNwb25zZSA9IHRoaXMuYmFzZVVybCArIFwiUmVjZWlwdFRlbXBsYXRlL0FkZC9cIiArIFJjcHRUaG5rc0x0ck9iai5UaGFua3NMZXR0ZXJJZDtcclxuICAgICAgICAvL2FsZXJ0KHJlc3BvbnNlKTtcclxuICAgICAgICBkb2N1bWVudC5sb2NhdGlvbiA9IHJlc3BvbnNlO1xyXG4gICAgfVxyXG4gICAgbmdPbkluaXQoKSB7XHJcbiAgICAgICAgdGhpcy5MYW5nID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJsYW5nXCIpO1xyXG4gICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5HZXRMYW5nUmVzKHRoaXMuRm9ybXR5cGUsIHRoaXMuTGFuZykuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5SRVMgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICB0aGlzLl9SZWNpZXB0U2VydmljZS5HZXRSZWNpZXB0VHlwZUxpc3QoKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fUmVjaWVwdFR5cGVMaXN0ID0gcmVzcG9uc2UuRGF0YTtcclxuXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgaWYgKHRoaXMuUmVjZWlwdElkICE9IDApIHtcclxuICAgICAgICAgICAgdGhpcy5iaW5kUmVjZWlwdFRobmtzTGV0dGVyTGlzdCgpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG4iXX0=
