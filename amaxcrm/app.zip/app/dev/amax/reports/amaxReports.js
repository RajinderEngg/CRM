System.register(["angular2/core", "../../services/AmaxService", "angular2/router"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, AmaxService_1, router_1;
    var AmaxReport;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (AmaxService_1_1) {
                AmaxService_1 = AmaxService_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            }],
        execute: function() {
            AmaxReport = (function () {
                function AmaxReport(_amaxService, _routeParams) {
                    this._amaxService = _amaxService;
                    this._routeParams = _routeParams;
                }
                AmaxReport.prototype.redirectTo = function (location) {
                    alert(location);
                };
                AmaxReport.prototype.ngOnInit = function () {
                    var rpt = this._routeParams.get('rpt');
                    if (rpt) {
                        switch (rpt) {
                            case "Accounts":
                                this.ReportName = "Accounts";
                                this.ReportData = this._amaxService.GetReport(rpt, {});
                                this.ReportData.subscribe(function (data) {
                                    jQuery("#formReport").kendoGrid({
                                        dataSource: {
                                            data: data[0]
                                        },
                                        height: 350,
                                        columns: [
                                            {
                                                template: "<div (click)='redirectTo(\"form?frm=Accounts\")'>#: AccountName #</div></a>",
                                                field: "AccountName",
                                                title: "Account Name"
                                            },
                                            {
                                                template: "<div>#: AccountTypeName # ( #: AccountTpeNameEng # )</div>",
                                                field: "AccountTypeName",
                                                title: "Account Type"
                                            },
                                            {
                                                template: "<div>#: AccountDetail #</div>",
                                                field: "AccountDetail",
                                                title: "Account Detail"
                                            }
                                        ]
                                    });
                                });
                                break;
                            case "AccountType":
                                this.ReportName = "Accounts Types";
                                this.ReportData = this._amaxService.GetReport(rpt, {});
                                this.ReportData.subscribe(function (data) {
                                    console.log("1. Hello World");
                                    console.log("2. Hello World");
                                    console.log("3. Hello World");
                                    console.log(data);
                                    jQuery("#formReport").kendoGrid({
                                        dataSource: {
                                            data: data[0]
                                        },
                                        height: 350,
                                        selectable: "multiple",
                                        columns: [
                                            {
                                                template: "<div href=''>#: AccountTypeName # ( #: AccountTpeNameEng # )</div>",
                                                field: "AccountTypeName",
                                                title: "Account Type"
                                            }
                                        ]
                                    });
                                });
                                break;
                        }
                    }
                };
                AmaxReport = __decorate([
                    core_1.Component({
                        template: "\n        <h1>{{ReportName}}</h1>\n        \n        <div id=\"formReport\">\n        </div>\n    ",
                        directives: [router_1.ROUTER_DIRECTIVES],
                        providers: [AmaxService_1.AmaxService]
                    }), 
                    __metadata('design:paramtypes', [AmaxService_1.AmaxService, router_1.RouteParams])
                ], AmaxReport);
                return AmaxReport;
            }());
            exports_1("AmaxReport", AmaxReport);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldi9hbWF4L3JlcG9ydHMvYW1heFJlcG9ydHMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7WUFpQkE7Z0JBSUksb0JBQW9CLFlBQXdCLEVBQVUsWUFBd0I7b0JBQTFELGlCQUFZLEdBQVosWUFBWSxDQUFZO29CQUFVLGlCQUFZLEdBQVosWUFBWSxDQUFZO2dCQUM5RSxDQUFDO2dCQUNELCtCQUFVLEdBQVYsVUFBVyxRQUFlO29CQUN0QixLQUFLLENBQUMsUUFBUSxDQUFDLENBQUM7Z0JBQ3BCLENBQUM7Z0JBQ0QsNkJBQVEsR0FBUjtvQkFDSSxJQUFJLEdBQUcsR0FBRSxJQUFJLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdEMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQzt3QkFDTixNQUFNLENBQUEsQ0FBQyxHQUFHLENBQUMsQ0FBQSxDQUFDOzRCQUNSLEtBQUssVUFBVTtnQ0FDWCxJQUFJLENBQUMsVUFBVSxHQUFHLFVBQVUsQ0FBQztnQ0FDN0IsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLENBQUM7Z0NBRXZELElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTtvQ0FDMUIsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDLFNBQVMsQ0FBQzt3Q0FDNUIsVUFBVSxFQUFFOzRDQUNSLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDO3lDQUNoQjt3Q0FDRCxNQUFNLEVBQUMsR0FBRzt3Q0FDVixPQUFPLEVBQUM7NENBQ0o7Z0RBQ0ksUUFBUSxFQUFFLDZFQUE2RTtnREFDdkYsS0FBSyxFQUFFLGFBQWE7Z0RBQ3BCLEtBQUssRUFBRSxjQUFjOzZDQUN4Qjs0Q0FDRDtnREFDSSxRQUFRLEVBQUUsNERBQTREO2dEQUN0RSxLQUFLLEVBQUUsaUJBQWlCO2dEQUN4QixLQUFLLEVBQUUsY0FBYzs2Q0FDeEI7NENBQ0Q7Z0RBQ0ksUUFBUSxFQUFDLCtCQUErQjtnREFDeEMsS0FBSyxFQUFDLGVBQWU7Z0RBQ3JCLEtBQUssRUFBQyxnQkFBZ0I7NkNBQ3pCO3lDQUNKO3FDQUNKLENBQUMsQ0FBQztnQ0FDUCxDQUFDLENBQUMsQ0FBQztnQ0FDSCxLQUFLLENBQUM7NEJBQ1YsS0FBSyxhQUFhO2dDQUNkLElBQUksQ0FBQyxVQUFVLEdBQUcsZ0JBQWdCLENBQUM7Z0NBQ25DLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxDQUFBO2dDQUV0RCxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7b0NBQzFCLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztvQ0FDOUIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO29DQUM5QixPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDLENBQUM7b0NBQzlCLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUM7b0NBRWxCLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQyxTQUFTLENBQUM7d0NBQzVCLFVBQVUsRUFBRTs0Q0FDUixJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQzt5Q0FDaEI7d0NBQ0QsTUFBTSxFQUFDLEdBQUc7d0NBQ1YsVUFBVSxFQUFDLFVBQVU7d0NBQ3JCLE9BQU8sRUFBQzs0Q0FDSjtnREFDSSxRQUFRLEVBQUUsb0VBQW9FO2dEQUM5RSxLQUFLLEVBQUUsaUJBQWlCO2dEQUN4QixLQUFLLEVBQUUsY0FBYzs2Q0FDeEI7eUNBQ0o7cUNBQ0osQ0FBQyxDQUFDO2dDQUNQLENBQUMsQ0FBQyxDQUFDO2dDQUNILEtBQUssQ0FBQzt3QkFDZCxDQUFDO29CQUNMLENBQUM7Z0JBQ0wsQ0FBQztnQkFqRkw7b0JBQUMsZ0JBQVMsQ0FBQzt3QkFDUCxRQUFRLEVBQUUsb0dBS1Q7d0JBQ0QsVUFBVSxFQUFDLENBQUMsMEJBQWlCLENBQUM7d0JBQzlCLFNBQVMsRUFBRSxDQUFDLHlCQUFXLENBQUM7cUJBQzNCLENBQUM7OzhCQUFBO2dCQXlFRixpQkFBQztZQUFELENBeEVBLEFBd0VDLElBQUE7WUF4RUQsbUNBd0VDLENBQUEiLCJmaWxlIjoiZGV2L2FtYXgvcmVwb3J0cy9hbWF4UmVwb3J0cy5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7Q29tcG9uZW50LCBPbkluaXR9IGZyb20gXCJhbmd1bGFyMi9jb3JlXCI7XG5pbXBvcnQge09ic2VydmFibGV9IGZyb20gXCJyeGpzL09ic2VydmFibGVcIjtcbmltcG9ydCB7QW1heFNlcnZpY2V9IGZyb20gXCIuLi8uLi9zZXJ2aWNlcy9BbWF4U2VydmljZVwiO1xuaW1wb3J0IHtSb3V0ZVBhcmFtcywgUk9VVEVSX0RJUkVDVElWRVN9IGZyb20gXCJhbmd1bGFyMi9yb3V0ZXJcIjtcblxuZGVjbGFyZSB2YXIgalF1ZXJ5O1xuXG5AQ29tcG9uZW50KHtcbiAgICB0ZW1wbGF0ZTogYFxuICAgICAgICA8aDE+e3tSZXBvcnROYW1lfX08L2gxPlxuICAgICAgICBcbiAgICAgICAgPGRpdiBpZD1cImZvcm1SZXBvcnRcIj5cbiAgICAgICAgPC9kaXY+XG4gICAgYCxcbiAgICBkaXJlY3RpdmVzOltST1VURVJfRElSRUNUSVZFU10sXG4gICAgcHJvdmlkZXJzOiBbQW1heFNlcnZpY2VdXG59KVxuZXhwb3J0IGNsYXNzIEFtYXhSZXBvcnQgaW1wbGVtZW50cyBPbkluaXQge1xuICAgIFJlcG9ydERhdGE6T2JzZXJ2YWJsZTtcbiAgICBSZXBvcnROYW1lOnN0cmluZztcblxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgX2FtYXhTZXJ2aWNlOkFtYXhTZXJ2aWNlLCBwcml2YXRlIF9yb3V0ZVBhcmFtczpSb3V0ZVBhcmFtcykge1xuICAgIH1cbiAgICByZWRpcmVjdFRvKGxvY2F0aW9uOnN0cmluZyl7XG4gICAgICAgIGFsZXJ0KGxvY2F0aW9uKTtcbiAgICB9XG4gICAgbmdPbkluaXQoKSB7XG4gICAgICAgIHZhciBycHQgPXRoaXMuX3JvdXRlUGFyYW1zLmdldCgncnB0Jyk7XG4gICAgICAgIGlmIChycHQpIHtcbiAgICAgICAgICAgIHN3aXRjaChycHQpe1xuICAgICAgICAgICAgICAgIGNhc2UgXCJBY2NvdW50c1wiOlxuICAgICAgICAgICAgICAgICAgICB0aGlzLlJlcG9ydE5hbWUgPSBcIkFjY291bnRzXCI7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuUmVwb3J0RGF0YSA9IHRoaXMuX2FtYXhTZXJ2aWNlLkdldFJlcG9ydChycHQsIHt9KTtcblxuICAgICAgICAgICAgICAgICAgICB0aGlzLlJlcG9ydERhdGEuc3Vic2NyaWJlKGRhdGE9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBqUXVlcnkoXCIjZm9ybVJlcG9ydFwiKS5rZW5kb0dyaWQoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGFTb3VyY2U6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YTogZGF0YVswXVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OjM1MCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zOltcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGU6IFwiPGRpdiAoY2xpY2spPSdyZWRpcmVjdFRvKFxcXCJmb3JtP2ZybT1BY2NvdW50c1xcXCIpJz4jOiBBY2NvdW50TmFtZSAjPC9kaXY+PC9hPlwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZmllbGQ6IFwiQWNjb3VudE5hbWVcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlOiBcIkFjY291bnQgTmFtZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlOiBcIjxkaXY+IzogQWNjb3VudFR5cGVOYW1lICMgKCAjOiBBY2NvdW50VHBlTmFtZUVuZyAjICk8L2Rpdj5cIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpZWxkOiBcIkFjY291bnRUeXBlTmFtZVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU6IFwiQWNjb3VudCBUeXBlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGU6XCI8ZGl2PiM6IEFjY291bnREZXRhaWwgIzwvZGl2PlwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZmllbGQ6XCJBY2NvdW50RGV0YWlsXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZTpcIkFjY291bnQgRGV0YWlsXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgY2FzZSBcIkFjY291bnRUeXBlXCI6XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuUmVwb3J0TmFtZSA9IFwiQWNjb3VudHMgVHlwZXNcIjtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5SZXBvcnREYXRhID0gdGhpcy5fYW1heFNlcnZpY2UuR2V0UmVwb3J0KHJwdCwge30pXG5cbiAgICAgICAgICAgICAgICAgICAgdGhpcy5SZXBvcnREYXRhLnN1YnNjcmliZShkYXRhPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCIxLiBIZWxsbyBXb3JsZFwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiMi4gSGVsbG8gV29ybGRcIik7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIjMuIEhlbGxvIFdvcmxkXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZGF0YSk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGpRdWVyeShcIiNmb3JtUmVwb3J0XCIpLmtlbmRvR3JpZCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YVNvdXJjZToge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhOiBkYXRhWzBdXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6MzUwLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdGFibGU6XCJtdWx0aXBsZVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbnM6W1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZTogXCI8ZGl2IGhyZWY9Jyc+IzogQWNjb3VudFR5cGVOYW1lICMgKCAjOiBBY2NvdW50VHBlTmFtZUVuZyAjICk8L2Rpdj5cIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpZWxkOiBcIkFjY291bnRUeXBlTmFtZVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU6IFwiQWNjb3VudCBUeXBlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG59XG4iXX0=
