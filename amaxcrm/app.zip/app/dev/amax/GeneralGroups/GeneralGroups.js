System.register(['angular2/common', "angular2/router", "angular2/core", "../../services/AmaxCrmSyinc", "../../services/ResourceService", "../../services/AmaxService", "../../services/GeneralGroupsService", "../../amaxUtil"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var common_1, router_1, core_1, AmaxCrmSyinc_1, ResourceService_1, AmaxService_1, GeneralGroupsService_1, amaxUtil_1;
    var AmaxGeneralGroups;
    return {
        setters:[
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (AmaxCrmSyinc_1_1) {
                AmaxCrmSyinc_1 = AmaxCrmSyinc_1_1;
            },
            function (ResourceService_1_1) {
                ResourceService_1 = ResourceService_1_1;
            },
            function (AmaxService_1_1) {
                AmaxService_1 = AmaxService_1_1;
            },
            function (GeneralGroupsService_1_1) {
                GeneralGroupsService_1 = GeneralGroupsService_1_1;
            },
            function (amaxUtil_1_1) {
                amaxUtil_1 = amaxUtil_1_1;
            }],
        execute: function() {
            AmaxGeneralGroups = (function () {
                function AmaxGeneralGroups(_resourceService, _routeParams, _amaxService, _GeneralGroupsService) {
                    this._resourceService = _resourceService;
                    this._routeParams = _routeParams;
                    this._amaxService = _amaxService;
                    this._GeneralGroupsService = _GeneralGroupsService;
                    this.modelInput = {};
                    this.custSearchData = [];
                    this.RES = {};
                    this.Formtype = "GENERAL_GROUP";
                    this.Lang = "";
                    this.ShowMoreText = "More";
                    this.ShowLoader = false;
                    this.ShowMsg = false;
                    this.GroupText = "Show Groups";
                    this.Msg = "";
                    this.MsgClass = "text-primary";
                    this.Isbtndisable = "";
                    this.GroupIds = "";
                    this.KendoRTLCSS = "";
                    this._Groups = [];
                    this.ChangeDialog = "";
                    this.CHANGEDIR = "";
                    this.modelInput.CustomerAddresses = [];
                    this.modelInput.CustomerPhones = [];
                    this.modelInput.CustomerEmails = [];
                    this.modelInput.CustomerGroups = [];
                    this.modelInput.employeeid = "";
                    this.modelInput.CustomerType = "";
                    this.modelInput.CameFromCustomer = "";
                    this.modelInput.Safixid = "";
                    this.modelInput.Gender = "0";
                    this.RES.GENERAL_GROUP = {};
                    this.Formtype = "GENERAL_GROUP";
                    this.GroupIds = "";
                    this.baseUrl = _resourceService.AppUrl;
                }
                AmaxGeneralGroups.prototype.SetdefaultPage = function () {
                    this.modelInput = {};
                    this.Formtype = "GENERAL_GROUP";
                    this.GroupIds = "";
                    this.ShowMsg = false;
                    this.Msg = "";
                };
                AmaxGeneralGroups.prototype.GetCustData = function () {
                    var _this = this;
                    this.GroupIds = "";
                    var _CheckedGroups = [];
                    amaxUtil_1.Kendo_utility.checkedNodeIds(jQuery("#groupTree").data("kendoTreeView").dataSource.view(), _CheckedGroups);
                    for (var i = 0; i < _CheckedGroups.length; i++) {
                        this.GroupIds = this.GroupIds + _CheckedGroups[i] + ",";
                    }
                    if (this.GroupIds.length > 0) {
                        this.GroupIds = this.GroupIds.substring(0, this.GroupIds.length - 1);
                    }
                    this._GeneralGroupsService.GetCompleteCustDet(this.GroupIds).subscribe(function (response) {
                        //debugger;
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.modelInput = response.Data;
                            var dataSource = _this.modelInput;
                            jQuery("#grid").kendoGrid({
                                dataSource: dataSource,
                                pageable: {
                                    pageSizes: true,
                                    buttonCount: 5,
                                    pageSize: 20
                                },
                                sortable: true,
                                scrolleble: true,
                                selectable: true,
                                height: 400,
                                columns: [
                                    {
                                        field: "CustomerId", title: _this.RES.GENERAL_GROUP.KENDOGRID_CUSTID,
                                        //template: '<a href="#=CustomerId#">#:CustomerId#</a>'
                                        template: function (dataItem) {
                                            return "<a href='http://localhost:3000/#/Customer/Add/" + kendo.htmlEncode(dataItem.CustomerId) + "'>" + kendo.htmlEncode(dataItem.CustomerId) + "</a>";
                                        }
                                    },
                                    { field: "FileAs", title: _this.RES.GENERAL_GROUP.KENDOGRID_FILEAS }
                                ],
                            });
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxGeneralGroups.prototype.ngOnInit = function () {
                    var _this = this;
                    this.Lang = localStorage.getItem("lang");
                    this.SetdefaultPage();
                    if (this.Lang == "he") {
                        this.KendoRTLCSS = "k-rtl";
                    }
                    else {
                        this.KendoRTLCSS = "";
                    }
                    this._resourceService.GetLangRes(this.Formtype, this.Lang).subscribe(function (response) {
                        //debugger; 
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.RES = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //Tree Group
                    this._amaxService.GetGeneralGroupTree().subscribe(function (data) {
                        var res = jQuery.parseJSON(data);
                        jQuery("#groupTree").kendoTreeView({
                            loadOnDemand: true,
                            checkboxes: {
                                checkChildren: true
                            },
                            //check: this.onGroupSelect,
                            dataSource: res.Data.kendoTree
                        });
                        var dataSource = null;
                        jQuery("#grid").kendoGrid({
                            dataSource: dataSource,
                            pageable: {
                                pageSizes: true,
                                buttonCount: 5,
                                pageSize: 20
                            },
                            sortable: true,
                            scrolleble: true,
                            selectable: true,
                            height: 400,
                            columns: [
                                {
                                    field: "CustomerId", title: _this.RES.GENERAL_GROUP.KENDOGRID_CUSTID,
                                    template: "<a>#:CustomerId#</a>"
                                },
                                { field: "FileAs", title: _this.RES.GENERAL_GROUP.KENDOGRID_FILEAS }
                            ],
                        });
                    }, function (err) {
                    }, function () {
                    });
                };
                AmaxGeneralGroups = __decorate([
                    core_1.Component({
                        templateUrl: './app/amax/GeneralGroups/templates/GeneralGroups.html',
                        directives: [common_1.NgSwitch, common_1.NgSwitchWhen, common_1.NgSwitchDefault],
                        providers: [AmaxService_1.AmaxService, AmaxCrmSyinc_1.AmaxCrmSyinc, ResourceService_1.ResourceService, GeneralGroupsService_1.GeneralGroupsService]
                    }), 
                    __metadata('design:paramtypes', [ResourceService_1.ResourceService, router_1.RouteParams, AmaxService_1.AmaxService, GeneralGroupsService_1.GeneralGroupsService])
                ], AmaxGeneralGroups);
                return AmaxGeneralGroups;
            }());
            exports_1("AmaxGeneralGroups", AmaxGeneralGroups);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldi9hbWF4L0dlbmVyYWxHcm91cHMvR2VuZXJhbEdyb3Vwcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztZQWdCQTtnQkFzQkksMkJBQW9CLGdCQUFpQyxFQUFVLFlBQXlCLEVBQVUsWUFBeUIsRUFBVSxxQkFBMkM7b0JBQTVKLHFCQUFnQixHQUFoQixnQkFBZ0IsQ0FBaUI7b0JBQVUsaUJBQVksR0FBWixZQUFZLENBQWE7b0JBQVUsaUJBQVksR0FBWixZQUFZLENBQWE7b0JBQVUsMEJBQXFCLEdBQXJCLHFCQUFxQixDQUFzQjtvQkFyQmhMLGVBQVUsR0FBRyxFQUFFLENBQUM7b0JBQ2hCLG1CQUFjLEdBQVcsRUFBRSxDQUFDO29CQUM1QixRQUFHLEdBQVcsRUFBRSxDQUFDO29CQUNqQixhQUFRLEdBQVUsZUFBZSxDQUFDO29CQUNsQyxTQUFJLEdBQVMsRUFBRSxDQUFDO29CQUNoQixpQkFBWSxHQUFXLE1BQU0sQ0FBQztvQkFFOUIsZUFBVSxHQUFZLEtBQUssQ0FBQztvQkFDNUIsWUFBTyxHQUFZLEtBQUssQ0FBQztvQkFDekIsY0FBUyxHQUFTLGFBQWEsQ0FBQztvQkFDaEMsUUFBRyxHQUFXLEVBQUUsQ0FBQztvQkFDakIsYUFBUSxHQUFXLGNBQWMsQ0FBQztvQkFDbEMsaUJBQVksR0FBVyxFQUFFLENBQUM7b0JBQzFCLGFBQVEsR0FBVyxFQUFFLENBQUM7b0JBRXRCLGdCQUFXLEdBQVcsRUFBRSxDQUFDO29CQUN6QixZQUFPLEdBQUcsRUFBRSxDQUFDO29CQUNiLGlCQUFZLEdBQVcsRUFBRSxDQUFDO29CQUMxQixjQUFTLEdBQVcsRUFBRSxDQUFDO29CQUtuQixJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixHQUFHLEVBQUUsQ0FBQztvQkFDdkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDO29CQUNwQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxFQUFFLENBQUM7b0JBQ3BDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLEVBQUUsQ0FBQztvQkFFcEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsRUFBRSxDQUFDO29CQUNoQyxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUM7b0JBQ2xDLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLEdBQUcsRUFBRSxDQUFDO29CQUN0QyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7b0JBQzdCLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxHQUFHLEdBQUcsQ0FBQztvQkFDN0IsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLEdBQUcsRUFBRSxDQUFDO29CQUM1QixJQUFJLENBQUMsUUFBUSxHQUFHLGVBQWUsQ0FBQztvQkFDaEMsSUFBSSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUM7b0JBQ25CLElBQUksQ0FBQyxPQUFPLEdBQUcsZ0JBQWdCLENBQUMsTUFBTSxDQUFDO2dCQUszQyxDQUFDO2dCQUtELDBDQUFjLEdBQWQ7b0JBSUksSUFBSSxDQUFDLFVBQVUsR0FBRyxFQUFFLENBQUM7b0JBRXJCLElBQUksQ0FBQyxRQUFRLEdBQUcsZUFBZSxDQUFDO29CQUNoQyxJQUFJLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQztvQkFLbkIsSUFBSSxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7b0JBQ3JCLElBQUksQ0FBQyxHQUFHLEdBQUcsRUFBRSxDQUFDO2dCQUNsQixDQUFDO2dCQUlELHVDQUFXLEdBQVg7b0JBQUEsaUJBMERDO29CQXpERyxJQUFJLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQztvQkFDbkIsSUFBSSxjQUFjLEdBQUcsRUFBRSxDQUFDO29CQUN4Qix3QkFBYSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsRUFBRSxjQUFjLENBQUMsQ0FBQztvQkFDM0csR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxjQUFjLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUM7d0JBQzdDLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLFFBQVEsR0FBRyxjQUFjLENBQUMsQ0FBQyxDQUFDLEdBQUMsR0FBRyxDQUFDO29CQUMxRCxDQUFDO29CQUNELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQzNCLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDO29CQUN6RSxDQUFDO29CQUNELElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFDM0UsV0FBVzt3QkFDWCxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtnQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUM1QixPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsVUFBVSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7NEJBQ2hDLElBQUksVUFBVSxHQUFHLEtBQUksQ0FBQyxVQUFVLENBQUM7NEJBQ2pDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUM7Z0NBQ3RCLFVBQVUsRUFBRSxVQUFVO2dDQUN0QixRQUFRLEVBQUU7b0NBQ04sU0FBUyxFQUFFLElBQUk7b0NBQ2YsV0FBVyxFQUFFLENBQUM7b0NBQ2QsUUFBUSxFQUFFLEVBQUU7aUNBQ2Y7Z0NBQ0QsUUFBUSxFQUFFLElBQUk7Z0NBQ2QsVUFBVSxFQUFFLElBQUk7Z0NBQ2hCLFVBQVUsRUFBRSxJQUFJO2dDQUNoQixNQUFNLEVBQUUsR0FBRztnQ0FFWCxPQUFPLEVBQUU7b0NBQ0w7d0NBQ0ksS0FBSyxFQUFFLFlBQVksRUFBRSxLQUFLLEVBQUUsS0FBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsZ0JBQWdCO3dDQUNuRSx1REFBdUQ7d0NBQ3ZELFFBQVEsRUFBRSxVQUFVLFFBQVE7NENBQ3hCLE1BQU0sQ0FBQyxnREFBZ0QsR0FBRyxLQUFLLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsR0FBRyxJQUFJLEdBQUcsS0FBSyxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLEdBQUcsTUFBTSxDQUFDO3dDQUM1SixDQUFDO3FDQUNKO29DQUNELEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRSxLQUFLLEVBQUUsS0FBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsZ0JBQWdCLEVBQUU7aUNBRXRFOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO2dCQUNQLENBQUM7Z0JBQ0Qsb0NBQVEsR0FBUjtvQkFBQSxpQkFnR0M7b0JBMUZHLElBQUksQ0FBQyxJQUFJLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDekMsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO29CQUt0QixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7d0JBQ3BCLElBQUksQ0FBQyxXQUFXLEdBQUcsT0FBTyxDQUFDO29CQUMvQixDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUNGLElBQUksQ0FBQyxXQUFXLEdBQUcsRUFBRSxDQUFDO29CQUMxQixDQUFDO29CQUVGLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFDekUsWUFBWTt3QkFDWixRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtnQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUM1QixPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsR0FBRyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7d0JBQzdCLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBTUYsWUFBWTtvQkFHYixJQUFJLENBQUMsWUFBWSxDQUFDLG1CQUFtQixFQUFFLENBQUMsU0FBUyxDQUU3QyxVQUFDLElBQUk7d0JBQ0QsSUFBSSxHQUFHLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFFakMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLGFBQWEsQ0FBQzs0QkFDL0IsWUFBWSxFQUFFLElBQUk7NEJBQ2xCLFVBQVUsRUFBRTtnQ0FDUixhQUFhLEVBQUUsSUFBSTs2QkFDdEI7NEJBQ0QsNEJBQTRCOzRCQUM1QixVQUFVLEVBQUUsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTO3lCQUNqQyxDQUFDLENBQUM7d0JBQ0gsSUFBSSxVQUFVLEdBQUcsSUFBSSxDQUFDO3dCQUN0QixNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDOzRCQUN0QixVQUFVLEVBQUUsVUFBVTs0QkFDdEIsUUFBUSxFQUFFO2dDQUNOLFNBQVMsRUFBRSxJQUFJO2dDQUNmLFdBQVcsRUFBRSxDQUFDO2dDQUNkLFFBQVEsRUFBRSxFQUFFOzZCQUNmOzRCQUNELFFBQVEsRUFBRSxJQUFJOzRCQUNkLFVBQVUsRUFBRSxJQUFJOzRCQUNoQixVQUFVLEVBQUUsSUFBSTs0QkFDaEIsTUFBTSxFQUFFLEdBQUc7NEJBQ1gsT0FBTyxFQUFFO2dDQUNMO29DQUNJLEtBQUssRUFBRSxZQUFZLEVBQUUsS0FBSyxFQUFFLEtBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLGdCQUFnQjtvQ0FDbkUsUUFBUSxFQUFFLHNCQUFzQjtpQ0FDbkM7Z0NBQ0QsRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLEtBQUssRUFBRSxLQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsRUFBRzs2QkFFdkU7eUJBQ0osQ0FBQyxDQUFDO29CQUNQLENBQUMsRUFDRCxVQUFDLEdBQUc7b0JBRUosQ0FBQyxFQUNEO29CQUVBLENBQUMsQ0FFSixDQUFDO2dCQUlMLENBQUM7Z0JBbE9MO29CQUFDLGdCQUFTLENBQUM7d0JBRVAsV0FBVyxFQUFFLHVEQUF1RDt3QkFDcEUsVUFBVSxFQUFFLENBQUMsaUJBQVEsRUFBRSxxQkFBWSxFQUFFLHdCQUFlLENBQUM7d0JBQ3JELFNBQVMsRUFBRSxDQUFDLHlCQUFXLEVBQUUsMkJBQVksRUFBRSxpQ0FBZSxFQUFFLDJDQUFvQixDQUFDO3FCQUNoRixDQUFDOztxQ0FBQTtnQkE4TkYsd0JBQUM7WUFBRCxDQTdOQSxBQTZOQyxJQUFBO1lBN05ELGlEQTZOQyxDQUFBIiwiZmlsZSI6ImRldi9hbWF4L0dlbmVyYWxHcm91cHMvR2VuZXJhbEdyb3Vwcy5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7TmdTd2l0Y2gsIE5nU3dpdGNoV2hlbiwgTmdTd2l0Y2hEZWZhdWx0LCBDT1JFX0RJUkVDVElWRVMsIEZPUk1fRElSRUNUSVZFU30gZnJvbSAnYW5ndWxhcjIvY29tbW9uJ1xyXG5pbXBvcnQge1JvdXRlUGFyYW1zfSBmcm9tIFwiYW5ndWxhcjIvcm91dGVyXCI7XHJcbmltcG9ydCB7Q29tcG9uZW50LCBPdXRwdXQsIElucHV0LCBFdmVudEVtaXR0ZXIsIE9uSW5pdH0gZnJvbSBcImFuZ3VsYXIyL2NvcmVcIjtcclxuaW1wb3J0IHtBbWF4Q3JtU3lpbmN9IGZyb20gXCIuLi8uLi9zZXJ2aWNlcy9BbWF4Q3JtU3lpbmNcIjtcclxuaW1wb3J0IHtSZXNvdXJjZVNlcnZpY2V9IGZyb20gXCIuLi8uLi9zZXJ2aWNlcy9SZXNvdXJjZVNlcnZpY2VcIjtcclxuaW1wb3J0IHtBbWF4U2VydmljZX0gZnJvbSBcIi4uLy4uL3NlcnZpY2VzL0FtYXhTZXJ2aWNlXCI7XHJcbmltcG9ydCB7R2VuZXJhbEdyb3Vwc1NlcnZpY2V9IGZyb20gXCIuLi8uLi9zZXJ2aWNlcy9HZW5lcmFsR3JvdXBzU2VydmljZVwiO1xyXG5pbXBvcnQgeyBqc29uUSB9IGZyb20gJy4uLy4uL2pzb25RJztcclxuaW1wb3J0IHtHcm91cEZpbHRlclBpcGUsIEdyb3VwUGFyZW5GaWx0ZXJQaXBlLCBLZW5kb191dGlsaXR5fSBmcm9tIFwiLi4vLi4vYW1heFV0aWxcIjtcclxuZGVjbGFyZSB2YXIgalF1ZXJ5O1xyXG5AQ29tcG9uZW50KHtcclxuXHJcbiAgICB0ZW1wbGF0ZVVybDogJy4vYXBwL2FtYXgvR2VuZXJhbEdyb3Vwcy90ZW1wbGF0ZXMvR2VuZXJhbEdyb3Vwcy5odG1sJyxcclxuICAgIGRpcmVjdGl2ZXM6IFtOZ1N3aXRjaCwgTmdTd2l0Y2hXaGVuLCBOZ1N3aXRjaERlZmF1bHRdLFxyXG4gICAgcHJvdmlkZXJzOiBbQW1heFNlcnZpY2UsIEFtYXhDcm1TeWluYywgUmVzb3VyY2VTZXJ2aWNlLCBHZW5lcmFsR3JvdXBzU2VydmljZV1cclxufSlcclxuZXhwb3J0IGNsYXNzIEFtYXhHZW5lcmFsR3JvdXBzIGltcGxlbWVudHMgT25Jbml0IHtcclxuICAgIG1vZGVsSW5wdXQgPSB7fTtcclxuICAgIGN1c3RTZWFyY2hEYXRhOiBPYmplY3QgPSBbXTtcclxuICAgIFJFUzogT2JqZWN0ID0ge307XHJcbiAgICBGb3JtdHlwZTogc3RyaW5nID1cIkdFTkVSQUxfR1JPVVBcIjtcclxuICAgIExhbmc6IHN0cmluZz1cIlwiO1xyXG4gICAgU2hvd01vcmVUZXh0OiBzdHJpbmcgPSBcIk1vcmVcIjtcclxuXHJcbiAgICBTaG93TG9hZGVyOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBTaG93TXNnOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBHcm91cFRleHQ6IHN0cmluZz1cIlNob3cgR3JvdXBzXCI7XHJcbiAgICBNc2c6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBNc2dDbGFzczogc3RyaW5nID0gXCJ0ZXh0LXByaW1hcnlcIjtcclxuICAgIElzYnRuZGlzYWJsZTogc3RyaW5nID0gXCJcIjtcclxuICAgIEdyb3VwSWRzOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgYmFzZVVybDogc3RyaW5nO1xyXG4gICAgS2VuZG9SVExDU1M6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBfR3JvdXBzID0gW107XHJcbiAgICBDaGFuZ2VEaWFsb2c6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBDSEFOR0VESVI6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBcblxyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBfcmVzb3VyY2VTZXJ2aWNlOiBSZXNvdXJjZVNlcnZpY2UsIHByaXZhdGUgX3JvdXRlUGFyYW1zOiBSb3V0ZVBhcmFtcywgcHJpdmF0ZSBfYW1heFNlcnZpY2U6IEFtYXhTZXJ2aWNlLCBwcml2YXRlIF9HZW5lcmFsR3JvdXBzU2VydmljZTogR2VuZXJhbEdyb3Vwc1NlcnZpY2UpIHtcclxuICAgICAgICBcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMgPSBbXTtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXMgPSBbXTtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMgPSBbXTtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJHcm91cHMgPSBbXTtcclxuICAgICAgICBcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuZW1wbG95ZWVpZCA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyVHlwZSA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkNhbWVGcm9tQ3VzdG9tZXIgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5TYWZpeGlkID0gXCJcIjtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuR2VuZGVyID0gXCIwXCI7XHJcbiAgICAgICAgdGhpcy5SRVMuR0VORVJBTF9HUk9VUCA9IHt9O1xyXG4gICAgICAgIHRoaXMuRm9ybXR5cGUgPSBcIkdFTkVSQUxfR1JPVVBcIjtcclxuICAgICAgICB0aGlzLkdyb3VwSWRzID0gXCJcIjtcclxuICAgICAgICB0aGlzLmJhc2VVcmwgPSBfcmVzb3VyY2VTZXJ2aWNlLkFwcFVybDtcclxuICAgICBcclxuXHJcbiAgICAgICBcclxuICAgICAgICBcclxuICAgIH1cclxuICAgIHByaXZhdGUgX2NhY2hlZFJlc3VsdDogYW55O1xuICAgIHByaXZhdGUgX3ByZXZpb3VzQ29udGV4dDogYW55O1xuICAgIFxuICAgXHJcbiAgICBTZXRkZWZhdWx0UGFnZSgpOiBvYnNlcnZhdmJsZSB7XHJcbiAgICAgICBcclxuICAgICAgICBcclxuICAgICAgICBcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQgPSB7fTtcclxuXHJcbiAgICAgICAgdGhpcy5Gb3JtdHlwZSA9IFwiR0VORVJBTF9HUk9VUFwiO1xyXG4gICAgICAgIHRoaXMuR3JvdXBJZHMgPSBcIlwiO1xyXG5cclxuICAgICAgIFxyXG5cclxuICAgICAgIFxyXG4gICAgICAgIHRoaXMuU2hvd01zZyA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMuTXNnID0gXCJcIjtcclxuICAgIH1cclxuICAgIFxyXG4gICBcclxuXHJcbiAgICBHZXRDdXN0RGF0YSgpOiBPYnNlcnZhYmxlIHtcclxuICAgICAgICB0aGlzLkdyb3VwSWRzID0gXCJcIjtcclxuICAgICAgICB2YXIgX0NoZWNrZWRHcm91cHMgPSBbXTtcclxuICAgICAgICBLZW5kb191dGlsaXR5LmNoZWNrZWROb2RlSWRzKGpRdWVyeShcIiNncm91cFRyZWVcIikuZGF0YShcImtlbmRvVHJlZVZpZXdcIikuZGF0YVNvdXJjZS52aWV3KCksIF9DaGVja2VkR3JvdXBzKTtcclxuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IF9DaGVja2VkR3JvdXBzLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIHRoaXMuR3JvdXBJZHMgPSB0aGlzLkdyb3VwSWRzKyAgX0NoZWNrZWRHcm91cHNbaV0rXCIsXCI7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICh0aGlzLkdyb3VwSWRzLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgdGhpcy5Hcm91cElkcyA9IHRoaXMuR3JvdXBJZHMuc3Vic3RyaW5nKDAsIHRoaXMuR3JvdXBJZHMubGVuZ3RoIC0gMSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuX0dlbmVyYWxHcm91cHNTZXJ2aWNlLkdldENvbXBsZXRlQ3VzdERldCh0aGlzLkdyb3VwSWRzKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dCA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICB2YXIgZGF0YVNvdXJjZSA9IHRoaXMubW9kZWxJbnB1dDtcbiAgICAgICAgICAgICAgICBqUXVlcnkoXCIjZ3JpZFwiKS5rZW5kb0dyaWQoe1xyXG4gICAgICAgICAgICAgICAgICAgIGRhdGFTb3VyY2U6IGRhdGFTb3VyY2UsXHJcbiAgICAgICAgICAgICAgICAgICAgcGFnZWFibGU6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGFnZVNpemVzOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBidXR0b25Db3VudDogNSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGFnZVNpemU6IDIwXHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICBzb3J0YWJsZTogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICBzY3JvbGxlYmxlOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgIHNlbGVjdGFibGU6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiA0MDAsXHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgY29sdW1uczogW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaWVsZDogXCJDdXN0b21lcklkXCIsIHRpdGxlOiB0aGlzLlJFUy5HRU5FUkFMX0dST1VQLktFTkRPR1JJRF9DVVNUSUQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL3RlbXBsYXRlOiAnPGEgaHJlZj1cIiM9Q3VzdG9tZXJJZCNcIj4jOkN1c3RvbWVySWQjPC9hPidcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlOiBmdW5jdGlvbiAoZGF0YUl0ZW0pIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gXCI8YSBocmVmPSdodHRwOi8vbG9jYWxob3N0OjMwMDAvIy9DdXN0b21lci9BZGQvXCIgKyBrZW5kby5odG1sRW5jb2RlKGRhdGFJdGVtLkN1c3RvbWVySWQpICsgXCInPlwiICsga2VuZG8uaHRtbEVuY29kZShkYXRhSXRlbS5DdXN0b21lcklkKSArIFwiPC9hPlwiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7IGZpZWxkOiBcIkZpbGVBc1wiLCB0aXRsZTogdGhpcy5SRVMuR0VORVJBTF9HUk9VUC5LRU5ET0dSSURfRklMRUFTIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG4gICAgbmdPbkluaXQoKSB7XHJcbiAgICAgICBcclxuICAgICAgICBcclxuXHJcbiAgICAgICAgXHJcblxyXG4gICAgICAgIHRoaXMuTGFuZyA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwibGFuZ1wiKTtcclxuICAgICAgICB0aGlzLlNldGRlZmF1bHRQYWdlKCk7XHJcbiAgICAgIFxyXG5cclxuICAgICAgIFxyXG5cclxuICAgICAgICBpZiAodGhpcy5MYW5nID09IFwiaGVcIikge1xyXG4gICAgICAgICAgICB0aGlzLktlbmRvUlRMQ1NTID0gXCJrLXJ0bFwiO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5LZW5kb1JUTENTUyA9IFwiXCI7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5HZXRMYW5nUmVzKHRoaXMuRm9ybXR5cGUsIHRoaXMuTGFuZykuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgIC8vZGVidWdnZXI7IFxyXG4gICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICB0aGlzLlJFUyA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgfSk7XHJcbiAgICAgICBcclxuICAgICAgICBcclxuICAgICAgICBcclxuICAgICAgICBcclxuICAgICAgICBcclxuICAgICAgICAvL1RyZWUgR3JvdXBcclxuICAgICAgICBcclxuXHJcbiAgICAgICB0aGlzLl9hbWF4U2VydmljZS5HZXRHZW5lcmFsR3JvdXBUcmVlKCkuc3Vic2NyaWJlKFxuXG4gICAgICAgICAgIChkYXRhKSA9PiB7XG4gICAgICAgICAgICAgICB2YXIgcmVzID0galF1ZXJ5LnBhcnNlSlNPTihkYXRhKTtcblxuICAgICAgICAgICAgICAgalF1ZXJ5KFwiI2dyb3VwVHJlZVwiKS5rZW5kb1RyZWVWaWV3KHtcbiAgICAgICAgICAgICAgICAgICBsb2FkT25EZW1hbmQ6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgY2hlY2tib3hlczoge1xuICAgICAgICAgICAgICAgICAgICAgICBjaGVja0NoaWxkcmVuOiB0cnVlXG4gICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAvL2NoZWNrOiB0aGlzLm9uR3JvdXBTZWxlY3QsXG4gICAgICAgICAgICAgICAgICAgZGF0YVNvdXJjZTogcmVzLkRhdGEua2VuZG9UcmVlXG4gICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgIHZhciBkYXRhU291cmNlID0gbnVsbDtcbiAgICAgICAgICAgICAgIGpRdWVyeShcIiNncmlkXCIpLmtlbmRvR3JpZCh7XHJcbiAgICAgICAgICAgICAgICAgICBkYXRhU291cmNlOiBkYXRhU291cmNlLFxyXG4gICAgICAgICAgICAgICAgICAgcGFnZWFibGU6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICBwYWdlU2l6ZXM6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uQ291bnQ6IDUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgcGFnZVNpemU6IDIwXHJcbiAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgc29ydGFibGU6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICBzY3JvbGxlYmxlOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgc2VsZWN0YWJsZTogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgIGhlaWdodDogNDAwLFxyXG4gICAgICAgICAgICAgICAgICAgY29sdW1uczogW1xyXG4gICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgZmllbGQ6IFwiQ3VzdG9tZXJJZFwiLCB0aXRsZTogdGhpcy5SRVMuR0VORVJBTF9HUk9VUC5LRU5ET0dSSURfQ1VTVElEICxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGU6IFwiPGE+IzpDdXN0b21lcklkIzwvYT5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgeyBmaWVsZDogXCJGaWxlQXNcIiwgdGl0bGU6IHRoaXMuUkVTLkdFTkVSQUxfR1JPVVAuS0VORE9HUklEX0ZJTEVBUyAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICB9LFxuICAgICAgICAgICAoZXJyKSA9PiB7XG5cbiAgICAgICAgICAgfSxcbiAgICAgICAgICAgKCkgPT4ge1xuXG4gICAgICAgICAgIH1cblxuICAgICAgICk7XHJcblxyXG4gICAgICAgXHJcblxyXG4gICAgfVxyXG59XHJcbiJdfQ==
