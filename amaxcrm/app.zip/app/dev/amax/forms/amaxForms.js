System.register(["angular2/core", 'angular2/common', "../../services/ResourceService", "angular2/router", "../../services/AmaxService", '../../jsonQ'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, common_1, ResourceService_1, router_1, AmaxService_1, jsonQ_1;
    var AmaxForms;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (ResourceService_1_1) {
                ResourceService_1 = ResourceService_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (AmaxService_1_1) {
                AmaxService_1 = AmaxService_1_1;
            },
            function (jsonQ_1_1) {
                jsonQ_1 = jsonQ_1_1;
            }],
        execute: function() {
            AmaxForms = (function () {
                function AmaxForms(_resourceService, _amaxService, _routeParams) {
                    this._resourceService = _resourceService;
                    this._amaxService = _amaxService;
                    this._routeParams = _routeParams;
                    this.ShowForm = false;
                }
                AmaxForms.prototype.saveFormData = function () {
                    var jsQ = new jsonQ_1.jsonQ("DemoTransation", "DemoHashKey");
                    for (var _i = 0, _a = this.FormObject; _i < _a.length; _i++) {
                        var frm = _a[_i];
                        jsQ.addNewInsert(frm.tableName, frm.pKey, frm.pKeyName);
                        for (var _b = 0, _c = frm.fields; _b < _c.length; _b++) {
                            var fld = _c[_b];
                            if (!fld.dummy) {
                                console.log(jQuery("form #" + frm.tableName + "_" + fld.name).val());
                                console.log("form #" + frm.tableName + "_" + fld.name);
                                jsQ.Insert(fld.name, jQuery("form #" + frm.tableName + "_" + fld.name).val());
                            }
                        }
                        jsQ.addToList();
                    }
                    console.log(JSON.stringify(jsQ.toJsonQObject()));
                    this._amaxService.ExecuteJson(jsQ.toJsonQObject()).subscribe(function (data) {
                        console.log(data);
                    }, function (error) { return console.log(error); }, function () { return console.log("Call Compleated"); });
                };
                AmaxForms.prototype.ngOnInit = function () {
                    var _this = this;
                    var frm = this._routeParams.get('frm');
                    console.log(frm);
                    this._resourceService.GetFormByName(this._routeParams.get('frm')).subscribe(function (data) {
                        _this.FormObject = data;
                        _this.ShowForm = true;
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleated");
                    });
                };
                AmaxForms = __decorate([
                    core_1.Component({
                        providers: [ResourceService_1.ResourceService, AmaxService_1.AmaxService],
                        directives: [common_1.NgSwitch, common_1.NgSwitchWhen, common_1.NgSwitchDefault],
                        template: "\n        <form *ngIf=\"ShowForm\">\n            <div class=\"row\">\n                <div class=\"col-sm-12\">\n                    <div *ngFor=\"#group of FormObject\" class=\"row\">\n                        <h1>{{group.name}}</h1>\n                        <div *ngFor=\"#field of group.fields\" class=\"col-xs-12 col-md-6 {{field.hiden ? 'hide' : ''}}\">\n                            <div class=\"row\" style=\"padding-top: 15px;\">\n                                <div class=\"col-xs-12 col-sm-5 col-md-4\"><label>{{field.caption||field.name}}</label></div>\n                                <div class=\"col-xs-12 col-sm-7 col-md-8\" [ngSwitch]=\"field.type\">\n                                    <template [ngSwitchWhen]=\"select\">\n                                        <select>\n                                            <option>Option 1</option>\n                                            <option>Option 2</option>\n                                            <option>Option 3</option>\n                                            <option>Option 4</option>\n                                            <option>Option 5</option>\n                                        </select>\n                                    </template>\n                                    <template ngSwitchDefault>\n                                        <input id=\"{{group.tableName}}_{{field.name}}\" class=\"form-control\" name=\"{{field.name}}\" value=\"{{field.default}}\" type=\"text\">\n                                    </template>\n                                </div>\n                            </div>\n                        </div>\n                    </div>\n                </div>\n                <div class=\"col-xs-12\">\n                    <button type=\"button\" (click)=\"saveFormData()\" class=\"btn btn-primary pull-right\" style=\"margin-top: 20px;\">Save</button>\n                </div>\n            </div>\n        </form>\n    "
                    }), 
                    __metadata('design:paramtypes', [ResourceService_1.ResourceService, AmaxService_1.AmaxService, router_1.RouteParams])
                ], AmaxForms);
                return AmaxForms;
            }());
            exports_1("AmaxForms", AmaxForms);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldi9hbWF4L2Zvcm1zL2FtYXhGb3Jtcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztZQStDQTtnQkFJSSxtQkFBb0IsZ0JBQWdDLEVBQVUsWUFBd0IsRUFBVSxZQUF3QjtvQkFBcEcscUJBQWdCLEdBQWhCLGdCQUFnQixDQUFnQjtvQkFBVSxpQkFBWSxHQUFaLFlBQVksQ0FBWTtvQkFBVSxpQkFBWSxHQUFaLFlBQVksQ0FBWTtvQkFGeEgsYUFBUSxHQUFTLEtBQUssQ0FBQztnQkFHdkIsQ0FBQztnQkFFRCxnQ0FBWSxHQUFaO29CQUNJLElBQUksR0FBRyxHQUFHLElBQUksYUFBSyxDQUFDLGdCQUFnQixFQUFDLGFBQWEsQ0FBQyxDQUFDO29CQUVwRCxHQUFHLENBQUEsQ0FBWSxVQUFlLEVBQWYsS0FBQSxJQUFJLENBQUMsVUFBVSxFQUFmLGNBQWUsRUFBZixJQUFlLENBQUM7d0JBQTNCLElBQUksR0FBRyxTQUFBO3dCQUNQLEdBQUcsQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLFNBQVMsRUFBQyxHQUFHLENBQUMsSUFBSSxFQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDdEQsR0FBRyxDQUFBLENBQVksVUFBVSxFQUFWLEtBQUEsR0FBRyxDQUFDLE1BQU0sRUFBVixjQUFVLEVBQVYsSUFBVSxDQUFDOzRCQUF0QixJQUFJLEdBQUcsU0FBQTs0QkFDUCxFQUFFLENBQUEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQSxDQUFDO2dDQUNYLE9BQU8sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLFFBQVEsR0FBQyxHQUFHLENBQUMsU0FBUyxHQUFFLEdBQUcsR0FBRSxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQztnQ0FDakUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLEdBQUMsR0FBRyxDQUFDLFNBQVMsR0FBRSxHQUFHLEdBQUUsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDO2dDQUduRCxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLFFBQVEsR0FBQyxHQUFHLENBQUMsU0FBUyxHQUFDLEdBQUcsR0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQzs0QkFDNUUsQ0FBQzt5QkFDSjt3QkFDRCxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7cUJBQ25CO29CQUNELE9BQU8sQ0FBQyxHQUFHLENBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsYUFBYSxFQUFFLENBQUMsQ0FBQyxDQUFDO29CQUNsRCxJQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsYUFBYSxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUM3RCxPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDO29CQUNsQixDQUFDLEVBQ0QsVUFBQSxLQUFLLElBQUUsT0FBQSxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxFQUFsQixDQUFrQixFQUN6QixjQUFJLE9BQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxFQUE5QixDQUE4QixDQUNyQyxDQUFDO2dCQUNOLENBQUM7Z0JBRUQsNEJBQVEsR0FBUjtvQkFBQSxpQkFZQztvQkFYRyxJQUFJLEdBQUcsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztvQkFFakIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQzVFLEtBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO3dCQUN2QixLQUFJLENBQUMsUUFBUSxHQUFDLElBQUksQ0FBQztvQkFDdkIsQ0FBQyxFQUFDLFVBQUEsS0FBSzt3QkFDSCxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUM7d0JBQ0UsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFBO29CQUNqQyxDQUFDLENBQUMsQ0FBQztnQkFDUCxDQUFDO2dCQWpGTDtvQkFBQyxnQkFBUyxDQUFDO3dCQUNQLFNBQVMsRUFBRSxDQUFDLGlDQUFlLEVBQUMseUJBQVcsQ0FBQzt3QkFDeEMsVUFBVSxFQUFDLENBQUMsaUJBQVEsRUFBRSxxQkFBWSxFQUFFLHdCQUFlLENBQUM7d0JBQ3BELFFBQVEsRUFBRSx3NkRBZ0NUO3FCQUNKLENBQUM7OzZCQUFBO2dCQThDRixnQkFBQztZQUFELENBN0NBLEFBNkNDLElBQUE7WUE3Q0QsaUNBNkNDLENBQUEiLCJmaWxlIjoiZGV2L2FtYXgvZm9ybXMvYW1heEZvcm1zLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtDb21wb25lbnQsIE9uSW5pdH0gZnJvbSBcImFuZ3VsYXIyL2NvcmVcIjtcbmltcG9ydCB7TmdTd2l0Y2gsIE5nU3dpdGNoV2hlbiwgTmdTd2l0Y2hEZWZhdWx0fSBmcm9tICdhbmd1bGFyMi9jb21tb24nXG5pbXBvcnQge1Jlc291cmNlU2VydmljZX0gZnJvbSBcIi4uLy4uL3NlcnZpY2VzL1Jlc291cmNlU2VydmljZVwiO1xuaW1wb3J0IHtSb3V0ZVBhcmFtc30gZnJvbSBcImFuZ3VsYXIyL3JvdXRlclwiO1xuaW1wb3J0IHtBbWF4U2VydmljZX0gZnJvbSBcIi4uLy4uL3NlcnZpY2VzL0FtYXhTZXJ2aWNlXCI7XG5pbXBvcnQgeyBqc29uUSB9IGZyb20gJy4uLy4uL2pzb25RJztcblxuXG5kZWNsYXJlIHZhciBqUXVlcnk7XG5cbkBDb21wb25lbnQoe1xuICAgIHByb3ZpZGVyczogW1Jlc291cmNlU2VydmljZSxBbWF4U2VydmljZV0sXG4gICAgZGlyZWN0aXZlczpbTmdTd2l0Y2gsIE5nU3dpdGNoV2hlbiwgTmdTd2l0Y2hEZWZhdWx0XSxcbiAgICB0ZW1wbGF0ZTogYFxuICAgICAgICA8Zm9ybSAqbmdJZj1cIlNob3dGb3JtXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwicm93XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbC1zbS0xMlwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2ICpuZ0Zvcj1cIiNncm91cCBvZiBGb3JtT2JqZWN0XCIgY2xhc3M9XCJyb3dcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxoMT57e2dyb3VwLm5hbWV9fTwvaDE+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2ICpuZ0Zvcj1cIiNmaWVsZCBvZiBncm91cC5maWVsZHNcIiBjbGFzcz1cImNvbC14cy0xMiBjb2wtbWQtNiB7e2ZpZWxkLmhpZGVuID8gJ2hpZGUnIDogJyd9fVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJyb3dcIiBzdHlsZT1cInBhZGRpbmctdG9wOiAxNXB4O1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sLXhzLTEyIGNvbC1zbS01IGNvbC1tZC00XCI+PGxhYmVsPnt7ZmllbGQuY2FwdGlvbnx8ZmllbGQubmFtZX19PC9sYWJlbD48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbC14cy0xMiBjb2wtc20tNyBjb2wtbWQtOFwiIFtuZ1N3aXRjaF09XCJmaWVsZC50eXBlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGVtcGxhdGUgW25nU3dpdGNoV2hlbl09XCJzZWxlY3RcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uPk9wdGlvbiAxPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24+T3B0aW9uIDI8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbj5PcHRpb24gMzwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uPk9wdGlvbiA0PC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24+T3B0aW9uIDU8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGVtcGxhdGU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGVtcGxhdGUgbmdTd2l0Y2hEZWZhdWx0PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCBpZD1cInt7Z3JvdXAudGFibGVOYW1lfX1fe3tmaWVsZC5uYW1lfX1cIiBjbGFzcz1cImZvcm0tY29udHJvbFwiIG5hbWU9XCJ7e2ZpZWxkLm5hbWV9fVwiIHZhbHVlPVwie3tmaWVsZC5kZWZhdWx0fX1cIiB0eXBlPVwidGV4dFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZW1wbGF0ZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbC14cy0xMlwiPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiAoY2xpY2spPVwic2F2ZUZvcm1EYXRhKClcIiBjbGFzcz1cImJ0biBidG4tcHJpbWFyeSBwdWxsLXJpZ2h0XCIgc3R5bGU9XCJtYXJnaW4tdG9wOiAyMHB4O1wiPlNhdmU8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Zvcm0+XG4gICAgYFxufSlcbmV4cG9ydCBjbGFzcyBBbWF4Rm9ybXMgaW1wbGVtZW50cyBPbkluaXQge1xuICAgIEZvcm1PYmplY3Q6QXJyYXk8YW55PjtcbiAgICBTaG93Rm9ybTpib29sZWFuPWZhbHNlO1xuXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBfcmVzb3VyY2VTZXJ2aWNlOlJlc291cmNlU2VydmljZSwgcHJpdmF0ZSBfYW1heFNlcnZpY2U6QW1heFNlcnZpY2UsIHByaXZhdGUgX3JvdXRlUGFyYW1zOlJvdXRlUGFyYW1zKSB7XG4gICAgfVxuXG4gICAgc2F2ZUZvcm1EYXRhKCl7XG4gICAgICAgIHZhciBqc1EgPSBuZXcganNvblEoXCJEZW1vVHJhbnNhdGlvblwiLFwiRGVtb0hhc2hLZXlcIik7XG5cbiAgICAgICAgZm9yKHZhciBmcm0gb2YgdGhpcy5Gb3JtT2JqZWN0KXtcbiAgICAgICAgICAgIGpzUS5hZGROZXdJbnNlcnQoZnJtLnRhYmxlTmFtZSxmcm0ucEtleSxmcm0ucEtleU5hbWUpO1xuICAgICAgICAgICAgZm9yKHZhciBmbGQgb2YgZnJtLmZpZWxkcyl7XG4gICAgICAgICAgICAgICAgaWYoIWZsZC5kdW1teSl7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGpRdWVyeShcImZvcm0gI1wiK2ZybS50YWJsZU5hbWUrIFwiX1wiICtmbGQubmFtZSkudmFsKCkpO1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImZvcm0gI1wiK2ZybS50YWJsZU5hbWUrIFwiX1wiICtmbGQubmFtZSk7XG5cblxuICAgICAgICAgICAgICAgICAgICBqc1EuSW5zZXJ0KGZsZC5uYW1lLCBqUXVlcnkoXCJmb3JtICNcIitmcm0udGFibGVOYW1lK1wiX1wiK2ZsZC5uYW1lKS52YWwoKSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAganNRLmFkZFRvTGlzdCgpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnNvbGUubG9nKCBKU09OLnN0cmluZ2lmeShqc1EudG9Kc29uUU9iamVjdCgpKSk7XG4gICAgICAgIHRoaXMuX2FtYXhTZXJ2aWNlLkV4ZWN1dGVKc29uKGpzUS50b0pzb25RT2JqZWN0KCkpLnN1YnNjcmliZShkYXRhPT57XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhkYXRhKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBlcnJvcj0+Y29uc29sZS5sb2coZXJyb3IpLFxuICAgICAgICAgICAgKCk9PmNvbnNvbGUubG9nKFwiQ2FsbCBDb21wbGVhdGVkXCIpXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgbmdPbkluaXQoKSB7XG4gICAgICAgIHZhciBmcm0gPSB0aGlzLl9yb3V0ZVBhcmFtcy5nZXQoJ2ZybScpO1xuICAgICAgICBjb25zb2xlLmxvZyhmcm0pO1xuICAgICAgICBcbiAgICAgICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLkdldEZvcm1CeU5hbWUodGhpcy5fcm91dGVQYXJhbXMuZ2V0KCdmcm0nKSkuc3Vic2NyaWJlKGRhdGE9PntcbiAgICAgICAgICAgIHRoaXMuRm9ybU9iamVjdCA9IGRhdGE7XG4gICAgICAgICAgICB0aGlzLlNob3dGb3JtPXRydWU7XG4gICAgICAgIH0sZXJyb3I9PntcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcbiAgICAgICAgfSwoKT0+e1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxlYXRlZFwiKVxuICAgICAgICB9KTtcbiAgICB9XG59Il19
