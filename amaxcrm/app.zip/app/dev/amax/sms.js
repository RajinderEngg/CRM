System.register(["angular2/core", "../comonComponents/basicComponents/select", "../services/AmaxService", "../amaxUtil", "../services/ResourceService", "../crmconfig", "../services/AmaxCrmSyinc"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, select_1, AmaxService_1, amaxUtil_1, ResourceService_1, crmconfig_1, AmaxCrmSyinc_1;
    var AmaxSmsComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (select_1_1) {
                select_1 = select_1_1;
            },
            function (AmaxService_1_1) {
                AmaxService_1 = AmaxService_1_1;
            },
            function (amaxUtil_1_1) {
                amaxUtil_1 = amaxUtil_1_1;
            },
            function (ResourceService_1_1) {
                ResourceService_1 = ResourceService_1_1;
            },
            function (crmconfig_1_1) {
                crmconfig_1 = crmconfig_1_1;
            },
            function (AmaxCrmSyinc_1_1) {
                AmaxCrmSyinc_1 = AmaxCrmSyinc_1_1;
            }],
        execute: function() {
            AmaxSmsComponent = (function () {
                function AmaxSmsComponent(_amaxService, _resourceService, _amaxCrmSyinc) {
                    this._amaxService = _amaxService;
                    this._resourceService = _resourceService;
                    this._amaxCrmSyinc = _amaxCrmSyinc;
                    this.openSettrings = false;
                    this.SelectedData = {};
                    this.SelectedProvider = {};
                    this.ConfirmedSend = false;
                    this.SelectedPhoneType = {};
                    this.KendoRTLCSS = "";
                    this.ChangeDialog = "";
                    this.CHANGEDIR = "";
                    this.SelectedData.UserName = "";
                    this.SelectedData.Value = "";
                    this.SenderPhoneNumber = "";
                    this.SelectedPhoneType.Value = "";
                    this.SelectedProvider.value = "";
                    var empid = localStorage.getItem("employeeid");
                    var message = this._resourceService.getCookie(empid + "SMSMessage");
                    if (message.length > 0 && message[0] == "=")
                        message = message.substring(1, message.length);
                    this.message = message;
                }
                AmaxSmsComponent.prototype.SetdefaultMsgValue = function () {
                    //alert('Hello');
                    var empid = localStorage.getItem("employeeid");
                    this._resourceService.setCookie(empid + "SMSMessage", this.message, 10);
                    //alert(message);
                };
                AmaxSmsComponent.prototype.ngOnInit = function () {
                    //debugger;
                    var _this = this;
                    //this._amaxCrmSyinc.on('lsset.' + LocalDict.languageResource, data=> this.RES = data["SCREEN_SMS"]);
                    //this.RES = this._amaxCrmSyinc.fetchLanguageResource("SCREEN_SMS");
                    //alert('hello');
                    //loadingLanguage start
                    this._amaxCrmSyinc.on('lsset.' + crmconfig_1.LocalDict.languageResource, function (data) { return _this.RES = data["SCREEN_SMS"]; });
                    this.RES = this._amaxCrmSyinc.fetchLanguageResource("SCREEN_SMS");
                    //debugger;
                    if (!this.RES) {
                        if (!localStorage.getItem(crmconfig_1.LocalDict.selectedLanguage)) {
                            localStorage.setItem(crmconfig_1.LocalDict.selectedLanguage, crmconfig_1.crmConfig.falbackLanguage);
                        }
                        this.Language = localStorage.getItem("lang");
                        if (this.Language == "he") {
                            this.KendoRTLCSS = "k-rtl";
                        }
                        this._amaxCrmSyinc.loadLanguageResource(localStorage.getItem(crmconfig_1.LocalDict.selectedLanguage));
                    }
                    //loadingLanguage start
                    this.allBind();
                    //alert('Bye');
                    //var message = this._resourceService.getCookie("SMSMessage");
                    //if (message.length > 0 && message[0] == "=")
                    //    message = message.substring(1, message.length);
                    //this.message = message;
                };
                //saveSmsSettings(){
                //    alert("Sms Setting saved.");
                //    this.openSettrings=false;
                //}
                //openSmsSettings(){
                //    this.openSettrings=true;
                //    //setTimeout(function () {
                //    //    jQuery('#SmsSettingsPannel').addClass('animated bounceInDown');
                //    //},200);
                //}
                //closeSmsSettings(){
                //    jQuery('#SmsSettingsPannel').addClass('animated slideOutDown');
                //    setTimeout(()=>{
                //        this.openSettrings=false;
                //    },200);
                //}
                AmaxSmsComponent.prototype.saveSmsSettings = function () {
                    // debugger;
                    var jsonObject = { UserName: "", Value: "", SelectedProvider: "", SenderPhoneNumber: "" };
                    jsonObject.UserName = this.SelectedData.UserName;
                    //jsonObject.Value = this.SelectedData.Value;
                    //jsonObject.UserName = $("#User_txt").val;//this.SelectedData.UserName;
                    //jsonObject.Value = $("#Pass_txt").val;//this.SelectedData.Value;
                    jsonObject.SelectedProvider = this.SelectedProvider.value;
                    jsonObject.SenderPhoneNumber = this.SenderPhoneNumber;
                    if (jsonObject.UserName && this.SelectedData.Value && jsonObject.SelectedProvider && jsonObject.SenderPhoneNumber) {
                        this._amaxCrmSyinc.storeLocal(crmconfig_1.LocalDict.SmsSettings, jsonObject);
                        var empid = localStorage.getItem("employeeid");
                        this._resourceService.setCookie(empid + "SMSDet", JSON.stringify(jsonObject), 10);
                        this.closeSmsSettings();
                    }
                    else {
                        bootbox.alert({
                            message: "Please Varifye the settings",
                            className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                    }
                };
                AmaxSmsComponent.prototype.openSmsSettings = function () {
                    //debugger;
                    this.openSettrings = true;
                    //var jsonObject = JSON.parse(this._amaxCrmSyinc.fetchLocal(LocalDict.SmsSettings));
                    var empid = localStorage.getItem("employeeid");
                    var data = this._resourceService.getCookie(empid + "SMSDet");
                    var jsonObject = {};
                    if (data.length > 0)
                        jsonObject = jQuery.parseJSON(data.substring(1, data.length));
                    // debugger;
                    if (jsonObject != null) {
                        for (var i = 0; i < this.SmsData.length; i++)
                            if (this.SmsData[i].UserName == jsonObject.UserName)
                                this.SelectedData.UserName = this.SmsData[i].UserName; //&& this.SmsData[i].Value == jsonObject.Value
                        for (var i = 0; i < this.SmsProvider.length; i++)
                            if (this.SmsProvider[i].value == jsonObject.SelectedProvider)
                                this.SelectedProvider = this.SmsProvider[i];
                        this.SenderPhoneNumber = jsonObject.SenderPhoneNumber;
                    }
                    else {
                        this.SelectedData.UserName = "";
                        this.SelectedData.Value = "";
                        this.SenderPhoneNumber = "";
                    }
                };
                AmaxSmsComponent.prototype.closeSmsSettings = function () {
                    this.openSettrings = false;
                    this.allBind();
                };
                AmaxSmsComponent.prototype.doNothing = function () {
                };
                AmaxSmsComponent.prototype.openModel = function () {
                };
                AmaxSmsComponent.prototype.setSmsCompanyList = function (data) {
                    this.SmsData = data;
                    this.SelectedData = this.SmsData[0];
                };
                AmaxSmsComponent.prototype.bindPhoneTypeList = function (data) {
                    this.PhoneTypeListData = data;
                    this.SelectedPhoneType = this.PhoneTypeListData[0];
                };
                AmaxSmsComponent.prototype.bindGeneralGroupTree = function (data) {
                    // debugger;
                    jQuery("#groupTree").html("Loding...");
                    var res = jQuery.parseJSON(data);
                    setTimeout(function () {
                        jQuery("#groupTree").kendoTreeView({
                            loadOnDemand: true,
                            checkboxes: {
                                checkChildren: true
                            },
                            dataSource: res.Data.kendoTree
                        });
                        jQuery("#sendLaterDate").kendoDatePicker({
                            format: "dd-MM-yyyy"
                        });
                        switch_direction();
                    }, 1000);
                };
                AmaxSmsComponent.prototype.getSelectedGroups = function () {
                    var _CheckedGroups = [];
                    amaxUtil_1.Kendo_utility.checkedNodeIds(jQuery("#groupTree").data("kendoTreeView").dataSource.view(), _CheckedGroups);
                    return _CheckedGroups;
                };
                AmaxSmsComponent.prototype.SendToSelectedGroups = function () {
                    var _this = this;
                    //username:string,company:string,message:string,groups:Array<any>,phoneTypeId:number
                    debugger;
                    if (this.SelectedPhoneType == undefined || this.SelectedPhoneType == null || this.SelectedPhoneType.Value == "") {
                        this.SelectedPhoneType.Value = 0;
                    }
                    if (this.SelectedPhoneType.Value == 1 && this.SenderPhoneNumber.length != 10) {
                        bootbox.alert({
                            message: "Sender Must be 10 Digit valid cellphone number",
                            className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                        this.openSmsSettings();
                        return;
                    }
                    var _selectedGroups = this.getSelectedGroups();
                    var status = "ok";
                    if (_selectedGroups.length == 0)
                        status = "No groups selected";
                    //else if (!this.SelectedData.UserName || !this.SelectedData.Value) status = "Please select a provider";
                    //else if (!this.message) status = "Message can't be empty";
                    if (status != "ok") {
                        bootbox.alert({
                            message: status,
                            className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                        return;
                    }
                    ;
                    var sendlater = jQuery('#sendLaterDate').val() + " " + jQuery('#sendLaterHour').val() + ":" + jQuery('#sendLaterMin').val();
                    if (sendlater.length != 16)
                        sendlater = "";
                    var smsSettings = JSON.parse(this._amaxCrmSyinc.fetchLocal(crmconfig_1.LocalDict.SmsSettings));
                    if (!smsSettings) {
                        bootbox.alert({
                            message: "Sms Settings not found",
                            className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                        this.openSmsSettings();
                        return false;
                    }
                    else {
                        smsSettings.Value = this.SelectedData.Value;
                    }
                    this._amaxService.SendSms(smsSettings.UserName, smsSettings.Value, this.message, this.getSelectedGroups(), this.SelectedPhoneType.Value, smsSettings.SelectedProvider, !this.ConfirmedSend, this.ConfirmedSend, smsSettings.SenderPhoneNumber, sendlater).subscribe(function (data) {
                        console.log(data);
                        // debugger;
                        var _data = jQuery.parseJSON(data).Data;
                        /*jQuery("#SelectedCustomers").kendoGrid({
                            dataSource: {
                                data: _data.Customers
                            },
                            height: 350,
                            selectable: "multiple"
                        });*/
                        if (!_this.ConfirmedSend) {
                            if (_data.err) {
                                bootbox.alert({
                                    message: _data.err,
                                    className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        }
                                    }
                                });
                                _this.openSmsSettings();
                                return;
                            }
                            var RemainingCredit = _data.RemainingCredit;
                            var TotalCustomers = _data.TotalCustomers;
                            if (RemainingCredit > 0) {
                                if (RemainingCredit > TotalCustomers) {
                                    var message = "Total customers : " + TotalCustomers;
                                    message += "\nRemaining Creadit for sms : " + RemainingCredit;
                                    message += "\n\nProcide to send ?";
                                    if (confirm(message)) {
                                        _this.ConfirmedSend = true;
                                        _this.SendToSelectedGroups();
                                    }
                                }
                            }
                            else {
                                if (typeof RemainingCredit != 'undefined')
                                    bootbox.alert({
                                        message: "No SMS creadit",
                                        className: _this.ChangeDialog,
                                        buttons: {
                                            ok: {
                                                //label: 'Ok',
                                                className: _this.CHANGEDIR
                                            }
                                        }
                                    });
                                else
                                    bootbox.alert({
                                        message: "Error processing request",
                                        className: _this.ChangeDialog,
                                        buttons: {
                                            ok: {
                                                //label: 'Ok',
                                                className: _this.CHANGEDIR
                                            }
                                        }
                                    });
                            }
                        }
                        else {
                            _this.ConfirmedSend = false;
                            switch (_data.status) {
                                case 1:
                                    bootbox.alert({
                                        message: _data.message,
                                        className: _this.ChangeDialog,
                                        buttons: {
                                            ok: {
                                                //label: 'Ok',
                                                className: _this.CHANGEDIR
                                            }
                                        }
                                    });
                                    break;
                                case 0:
                                    if (_this.SelectedProvider.value == 1) {
                                        if (_data.err.indexOf("ERROR") > -1 && _data.err.indexOf("SENDER_PREFIX") > -1) {
                                            bootbox.alert({
                                                message: "Invalid Sender Phone Number",
                                                className: _this.ChangeDialog,
                                                buttons: {
                                                    ok: {
                                                        //label: 'Ok',
                                                        className: _this.CHANGEDIR
                                                    }
                                                }
                                            });
                                            _this.openSmsSettings();
                                            return false;
                                        }
                                    }
                                    else if (_this.SelectedProvider.value == 2) {
                                        bootbox.alert({
                                            message: "Unable To Send Message",
                                            className: _this.ChangeDialog,
                                            buttons: {
                                                ok: {
                                                    //label: 'Ok',
                                                    className: _this.CHANGEDIR
                                                }
                                            }
                                        });
                                    }
                                    break;
                                default:
                                    console.log(data);
                            }
                        }
                    }, function (err) {
                        if (typeof err._body == 'string') {
                            bootbox.alert({
                                message: JSON.parse(err._body).error,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            bootbox.alert({
                                message: "Unable to connect to the Service",
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                    }, function () {
                        console.log({
                            message: "Sms send responce compleated!",
                            className: _this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: _this.CHANGEDIR
                                }
                            }
                        });
                    });
                };
                AmaxSmsComponent.prototype.allBind = function () {
                    // debugger;
                    var _this = this;
                    this.SmsProvider = [
                        { name: "Sms 2 You", value: 1 },
                        { name: "019 Sms", value: 2 }
                    ];
                    this.SelectedProvider = this.SmsProvider[0];
                    //alert(this._amaxService.GetGeneralGroupTree(0));
                    //this.bindGeneralGroupTree(this._amaxService.GetGeneralGroupTree(0));
                    this._amaxService.GetGeneralGroupTree().subscribe(function (data) {
                        var res = jQuery.parseJSON(data);
                        jQuery("#groupTree").kendoTreeView({
                            loadOnDemand: true,
                            checkboxes: {
                                checkChildren: true
                            },
                            //check: this.onGroupSelect,
                            dataSource: res.Data.kendoTree
                        });
                        jQuery("#sendLaterDate").kendoDatePicker({
                            format: "dd-MM-yyyy"
                        });
                    }, function (err) {
                    }, function () {
                    });
                    //jQuery("#sendLaterDate").kendoDatePicker({
                    //    format: "dd-MM-yyyy"
                    //});
                    //this.bindPhoneTypeList(this._resourceService.GetLocalStorage("CellPhoneTypeList"));
                    //this.setSmsCompanyList(this._resourceService.GetLocalStorage("SmsCompanyList"));
                    this._amaxService.GetDataFromServer({
                        SmsCompanyList: {
                            uqery: "\n                        Select\n                            usersms AS UserName,\n                            passwordsms AS Value\n                        from\n                            ApplicationInfo\n                    ",
                            parameters: {}
                        },
                        PhoneTypeList: {
                            uqery: "SELECT id AS Value, contentHeb+' ('+ contenteng +')' AS Label FROM PhoneTypes",
                            parameters: {}
                        }
                    }).subscribe(function (data) {
                        //debugger;
                        console.log(data);
                        var res = jQuery.parseJSON(data);
                        _this.SmsData = res.Data.data.SmsCompanyList;
                        _this.PhoneTypeListData = res.Data.data.PhoneTypeList;
                        var phonetypeid = "";
                        jQuery.each(_this.PhoneTypeListData, function () {
                            phonetypeid = this.Label;
                            return false;
                        });
                        //jQuery("#PhontTypesel").attr("selectedval", phonetypeid);
                    }, function (error) { }, function () { });
                };
                AmaxSmsComponent = __decorate([
                    core_1.Component({
                        name: 'amax-sms',
                        pipes: [amaxUtil_1.GroupFilterPipe, amaxUtil_1.GroupParenFilterPipe],
                        template: "<div class=\"row\" *ngIf=\"RES\">\n\n    <div class=\"col s12 card-panel\">\n<div class=\"row\">\n<div class=\"col s12\">\n<h1>\n                            <i class=\"mdi-content-select-all green-text\"></i>\n                            <span class=\"red-text\">{{RES.LBL_HEADING}}</span>  <!--{{RES.CUSTOMER_MASTER.CUST_LABAL}}Customer-->\n                        </h1>\n\n</div>\n<button class=\"btn waves-effect waves-light indigo {{ _amaxCrmSyinc.isRtl() ? 'right' : 'left'}}\"\n                    (click)=\"openSmsSettings()\">\n                <i class=\"mdi-action-settings\"></i> {{RES.LBL_SETTING}}\n            </button>\n\n</div>\n        <div style=\"overflow: hidden;\">\n            <div class=\"col s12\">&nbsp;</div>\n            <div id=\"SmsSettingsPannel\" class=\"col s12 animated slideInDown\" *ngIf=\"openSettrings\">\n               <div class=\"col s12\">\n                    <label>{{RES.LBL_SMS_PROVIDERS}}</label>\n                    <select class=\"browser-default\" [(ngModel)]= \"SelectedProvider.value\">\n                        \n                        <option value=\"1\">Sms 2 you</option>\n                        <option value=\"2\">019 Sms</option>\n                        \n                    </select>\n                </div>\n                <div class=\"input-field col s6\">\n                    \n                    <input type=\"text\" id=\"UserName\" class=\"form-control\" [(ngModel)]= \"SelectedData.UserName\">\n                    <label for=\"UserName\" class=\"active\">{{RES.LBL_SMS_USERNAME}}</label>\n                </div>\n                <div class=\"input-field col s6\">\n                    \n                    <input class=\"form-control\" type=\"password\" id=\"Password\" [(ngModel)]= \"SelectedData.Value\"/>\n                    <label for=\"Password\" class=\"active\">{{RES.SMS_PASSWORD}}</label>\n                </div>\n                \n                <div class=\"input-field col s12\">\n                    \n                    <input class=\"form-control\" id=\"PhNo\" type=\"text\" [(ngModel)]=\"SenderPhoneNumber\">\n                    <label for=\"PhNo\" class=\"active\">{{RES.LBL_SENDER_PHONE}}</label>\n                </div>\n                <div class=\"col s12\">&nbsp;</div>\n                <div class=\"col s12\">\n                    <button class=\"btn waves-effect waves-light green accent-4\" (click)=\"saveSmsSettings()\" style=\"width:200px!important;\">\n                        <i class=\"mdi-content-save\"></i> {{RES.LBL_SAVE_SETTING}}\n                    </button>\n                    <button class=\"btn waves-effect waves-light  grey lighten-2\" (click)=\"closeSmsSettings()\"style=\"width:200px!important;\">\n                        <i class=\"mdi-navigation-close\"></i> {{RES.LBL_CLOSE_SETTINGS}}\n                    </button>\n                </div>\n            </div>\n            <div class=\"col s12\" *ngIf=\"!openSettrings\">\n                <div class=\"row\">\n                    <div class=\"col s6\">\n                        <div class=\"row\">\n                            <div class=\"col s12\">\n                                <label>{{RES.LBL_GROUPS}}</label>\n                                <div class=\"k-content {{KendoRTLCSS}}\" style=\"max-height: 230px;overflow-y: auto; padding: 20px 10px 40px; margin-left:10px;\">\n                                    <div id=\"groupTree\" style=\"overflow: visible;\"> Loading...</div>\n                                </div>\n                            </div>\n                        </div>\n                    </div>\n                    <div class=\"col s6\">\n                        <div class=\"row\">\n                            <div class=\"col s12\">\n                                <label>{{RES.LBL_PHONE_TYPES}}</label>\n                                <mx-select [data]=\"PhoneTypeListData\" label=\"Label\" selectedval=\"All\" firstvalue=\"All\" \n                                           (onData)=\"SelectedPhoneType = $event\" cssclass=\"browser-default\" id=\"PhontTypesel\"></mx-select>\n                            </div>\n                            <div class=\"col s12\">&nbsp;</div>\n                            <div class=\"col s12\">\n                                <div class=\"row\">\n                                    <details>\n                                        <summary>{{RES.LBL_SEND_LATER}}</summary>\n                                        <div class=\"col s6\">\n                                            <label>{{RES.SMS_LBL_DATE}}</label>\n                                            <div class=\"k-content\">\n                                                <input class=\"form-control\" id=\"sendLaterDate\">\n                                            </div>\n                                        </div>\n                                        <div class=\"col s3\">\n                                            <label>{{RES.SMS_LBL_HR}}</label>\n                                            <select class=\"browser-default\" id=\"sendLaterHour\">\n                                                <option>01</option>\n                                                <option>02</option>\n                                                <option>03</option>\n                                                <option>04</option>\n                                                <option>05</option>\n                                                <option>06</option>\n                                                <option>07</option>\n                                                <option>08</option>\n                                                <option>09</option>\n                                                <option>10</option>\n                                                <option>11</option>\n                                                <option>12</option>\n                                                <option>13</option>\n                                                <option>14</option>\n                                                <option>15</option>\n                                                <option>16</option>\n                                                <option>17</option>\n                                                <option>18</option>\n                                                <option>19</option>\n                                                <option>20</option>\n                                                <option>21</option>\n                                                <option>22</option>\n                                                <option>23</option>\n                                                <option>24</option>\n                                            </select>\n                                        </div>\n                                        <div class=\"col s3\">\n                                            <label>{{RES.SMS_LBL_MIN}}</label>\n                                            <select class=\"browser-default\" id=\"sendLaterMin\">\n                                                <option>00</option>\n                                                <option>05</option>\n                                                <option>10</option>\n                                                <option>15</option>\n                                                <option>20</option>\n                                                <option>25</option>\n                                                <option>30</option>\n                                                <option>35</option>\n                                                <option>40</option>\n                                                <option>45</option>\n                                                <option>50</option>\n                                                <option>55</option>\n                                                <option>60</option>\n                                            </select>\n                                        </div>\n                                    </details>\n                                </div>\n                            </div>\n                            <div class=\"col s12\">&nbsp;</div>\n                            <div class=\"col s12\">\n                                <label>{{RES.LBL_MESSAGE}}</label>\n                                <textarea cols=\"50\" #msg (keyup)=\"message=msg.value\" class=\"form-control\"\n                                          placeholder=\"{{RES.SMS_TXT_PH_MESSAGE}}\" (change)=\"SetdefaultMsgValue()\" id=\"Messagetxtar\" [(ngModel)]= \"message\"></textarea>\n\n                                <span>{{RES.SMS_LBL_MAXCHAR}} : {{msg.value.length||0}}</span>\n                            </div>\n                        </div>\n                    </div>\n                    <div class=\"col s12\" id=\"SelectedCustomers\">&nbsp;</div>\n                    <div class=\"col s12\">\n                        <button class=\"btn waves-effect waves-light green accent-4\" style=\"width:175px!important;\" (click)=\"SendToSelectedGroups()\">{{RES.SMS_BTN_SENDMESSAGE}}</button>\n                    </div>\n                    <div class=\"space-4\"><div>\n\n                </div>\n            </div>\n        <br/><br/>\n        </div>\n    ",
                        directives: [select_1.SelectInputComponent],
                        providers: [AmaxService_1.AmaxService, AmaxCrmSyinc_1.AmaxCrmSyinc]
                    }), 
                    __metadata('design:paramtypes', [AmaxService_1.AmaxService, ResourceService_1.ResourceService, AmaxCrmSyinc_1.AmaxCrmSyinc])
                ], AmaxSmsComponent);
                return AmaxSmsComponent;
            }());
            exports_1("AmaxSmsComponent", AmaxSmsComponent);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldi9hbWF4L3Ntcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztZQTZLQTtnQkF1QkksMEJBQW9CLFlBQXlCLEVBQVUsZ0JBQWlDLEVBQVUsYUFBMkI7b0JBQXpHLGlCQUFZLEdBQVosWUFBWSxDQUFhO29CQUFVLHFCQUFnQixHQUFoQixnQkFBZ0IsQ0FBaUI7b0JBQVUsa0JBQWEsR0FBYixhQUFhLENBQWM7b0JBckJySCxrQkFBYSxHQUFZLEtBQUssQ0FBQztvQkFHdkMsaUJBQVksR0FBVyxFQUFFLENBQUM7b0JBRzFCLHFCQUFnQixHQUFXLEVBQUUsQ0FBQztvQkFFOUIsa0JBQWEsR0FBWSxLQUFLLENBQUM7b0JBRy9CLHNCQUFpQixHQUFXLEVBQUUsQ0FBQztvQkFJL0IsZ0JBQVcsR0FBVyxFQUFFLENBQUM7b0JBQ3pCLGlCQUFZLEdBQVcsRUFBRSxDQUFDO29CQUMxQixjQUFTLEdBQVcsRUFBRSxDQUFDO29CQUtuQixJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUM7b0JBQ2hDLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQztvQkFDN0IsSUFBSSxDQUFDLGlCQUFpQixHQUFHLEVBQUUsQ0FBQztvQkFDNUIsSUFBSSxDQUFDLGlCQUFpQixDQUFDLEtBQUssR0FBRyxFQUFFLENBQUM7b0JBQ2xDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLEdBQUcsRUFBRSxDQUFDO29CQUNqQyxJQUFJLEtBQUssR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDO29CQUMvQyxJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBQyxZQUFZLENBQUMsQ0FBQztvQkFDbEUsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sR0FBRyxDQUFDLElBQUksT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJLEdBQUcsQ0FBQzt3QkFDeEMsT0FBTyxHQUFHLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDbkQsSUFBSSxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUM7Z0JBRTNCLENBQUM7Z0JBQ0QsNkNBQWtCLEdBQWxCO29CQUNJLGlCQUFpQjtvQkFDakIsSUFBSSxLQUFLLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQztvQkFDL0MsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsWUFBWSxFQUFFLElBQUksQ0FBQyxPQUFPLEVBQUUsRUFBRSxDQUFDLENBQUM7b0JBR3hFLGlCQUFpQjtnQkFDckIsQ0FBQztnQkFDRCxtQ0FBUSxHQUFSO29CQUNJLFdBQVc7b0JBRGYsaUJBcUNDO29CQWxDRyxxR0FBcUc7b0JBQ3JHLG9FQUFvRTtvQkFNcEUsaUJBQWlCO29CQUNqQix1QkFBdUI7b0JBR3ZCLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUFDLFFBQVEsR0FBRyxxQkFBUyxDQUFDLGdCQUFnQixFQUFFLFVBQUEsSUFBSSxJQUFHLE9BQUEsS0FBSSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQTdCLENBQTZCLENBQUMsQ0FBQztvQkFDbkcsSUFBSSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLHFCQUFxQixDQUFDLFlBQVksQ0FBQyxDQUFDO29CQUNsRSxXQUFXO29CQUVYLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7d0JBQ1osRUFBRSxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLHFCQUFTLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUM7NEJBQ3BELFlBQVksQ0FBQyxPQUFPLENBQUMscUJBQVMsQ0FBQyxnQkFBZ0IsRUFBRSxxQkFBUyxDQUFDLGVBQWUsQ0FBQyxDQUFDO3dCQUNoRixDQUFDO3dCQUNELElBQUksQ0FBQyxRQUFRLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQzt3QkFDN0MsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUN4QixJQUFJLENBQUMsV0FBVyxHQUFHLE9BQU8sQ0FBQzt3QkFDL0IsQ0FBQzt3QkFDRCxJQUFJLENBQUMsYUFBYSxDQUFDLG9CQUFvQixDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMscUJBQVMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUM7b0JBQzlGLENBQUM7b0JBRUQsdUJBQXVCO29CQUN2QixJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7b0JBQ2YsZUFBZTtvQkFDZiw4REFBOEQ7b0JBQzlELDhDQUE4QztvQkFDOUMscURBQXFEO29CQUNyRCx5QkFBeUI7Z0JBRTdCLENBQUM7Z0JBRUQsb0JBQW9CO2dCQUNwQixrQ0FBa0M7Z0JBQ2xDLCtCQUErQjtnQkFDL0IsR0FBRztnQkFDSCxvQkFBb0I7Z0JBQ3BCLDhCQUE4QjtnQkFDOUIsZ0NBQWdDO2dCQUNoQywyRUFBMkU7Z0JBQzNFLGVBQWU7Z0JBQ2YsR0FBRztnQkFDSCxxQkFBcUI7Z0JBQ3JCLHFFQUFxRTtnQkFDckUsc0JBQXNCO2dCQUN0QixtQ0FBbUM7Z0JBQ25DLGFBQWE7Z0JBQ2IsR0FBRztnQkFRSCwwQ0FBZSxHQUFmO29CQUNHLFlBQVk7b0JBQ1gsSUFBSSxVQUFVLEdBQUcsRUFBRSxRQUFRLEVBQUUsRUFBRSxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUUsZ0JBQWdCLEVBQUUsRUFBRSxFQUFFLGlCQUFpQixFQUFFLEVBQUUsRUFBRSxDQUFDO29CQUMxRixVQUFVLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDO29CQUNqRCw2Q0FBNkM7b0JBRTdDLHdFQUF3RTtvQkFDeEUsa0VBQWtFO29CQUVsRSxVQUFVLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQztvQkFDMUQsVUFBVSxDQUFDLGlCQUFpQixHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQztvQkFFdEQsRUFBRSxDQUFDLENBQUMsVUFBVSxDQUFDLFFBQVEsSUFBSSxJQUFJLENBQUMsWUFBWSxDQUFDLEtBQUssSUFBSSxVQUFVLENBQUMsZ0JBQWdCLElBQUksVUFBVSxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQzt3QkFDaEgsSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMscUJBQVMsQ0FBQyxXQUFXLEVBQUUsVUFBVSxDQUFDLENBQUM7d0JBQ2pFLElBQUksS0FBSyxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUM7d0JBQy9DLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLFFBQVEsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO3dCQUNsRixJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztvQkFDNUIsQ0FBQztvQkFBQyxJQUFJLENBQUMsQ0FBQzt3QkFDSixPQUFPLENBQUMsS0FBSyxDQUFDOzRCQUNWLE9BQU8sRUFBRSw2QkFBNkI7NEJBQ3RDLFNBQVMsRUFBRSxJQUFJLENBQUMsWUFBWTs0QkFDNUIsT0FBTyxFQUFFO2dDQUNMLEVBQUUsRUFBRTtvQ0FDQSxjQUFjO29DQUNkLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUztpQ0FDNUI7NkJBQ0o7eUJBQ0osQ0FBQyxDQUFDO29CQUNQLENBQUM7Z0JBQ0wsQ0FBQztnQkFDRCwwQ0FBZSxHQUFmO29CQUNJLFdBQVc7b0JBQ1gsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7b0JBQzFCLG9GQUFvRjtvQkFDcEYsSUFBSSxLQUFLLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQztvQkFDL0MsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsUUFBUSxDQUFDLENBQUM7b0JBQzdELElBQUksVUFBVSxHQUFHLEVBQUUsQ0FBQztvQkFDcEIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7d0JBQ2hCLFVBQVUsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO29CQUNuRSxZQUFZO29CQUNYLEVBQUUsQ0FBQyxDQUFDLFVBQVUsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO3dCQUNyQixHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRTs0QkFDeEMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLElBQUksVUFBVSxDQUFDLFFBQVEsQ0FBQztnQ0FDaEQsSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBRyw4Q0FBOEM7d0JBRS9HLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFOzRCQUM1QyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssSUFBSSxVQUFVLENBQUMsZ0JBQWdCLENBQUM7Z0NBQUMsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBRTlHLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxVQUFVLENBQUMsaUJBQWlCLENBQUM7b0JBQzFELENBQUM7b0JBQ0QsSUFBSSxDQUFDLENBQUM7d0JBQ0YsSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDO3dCQUNoQyxJQUFJLENBQUMsWUFBWSxDQUFDLEtBQUssR0FBRyxFQUFFLENBQUM7d0JBQzdCLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxFQUFFLENBQUM7b0JBQ2hDLENBQUM7Z0JBQ0wsQ0FBQztnQkFDRCwyQ0FBZ0IsR0FBaEI7b0JBQ0ksSUFBSSxDQUFDLGFBQWEsR0FBRyxLQUFLLENBQUM7b0JBQzNCLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztnQkFDbkIsQ0FBQztnQkFFRCxvQ0FBUyxHQUFUO2dCQUNBLENBQUM7Z0JBRUQsb0NBQVMsR0FBVDtnQkFDQSxDQUFDO2dCQUdELDRDQUFpQixHQUFqQixVQUFrQixJQUFTO29CQUN2QixJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQztvQkFDcEIsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUN4QyxDQUFDO2dCQUNELDRDQUFpQixHQUFqQixVQUFrQixJQUFTO29CQUV2QixJQUFJLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDO29CQUM5QixJQUFJLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUN2RCxDQUFDO2dCQUNELCtDQUFvQixHQUFwQixVQUFxQixJQUFTO29CQUMzQixZQUFZO29CQUNYLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7b0JBQ3ZDLElBQUksR0FBRyxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBQ2pDLFVBQVUsQ0FBQzt3QkFDUCxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsYUFBYSxDQUFDOzRCQUMvQixZQUFZLEVBQUUsSUFBSTs0QkFDbEIsVUFBVSxFQUFFO2dDQUNSLGFBQWEsRUFBRSxJQUFJOzZCQUN0Qjs0QkFDRCxVQUFVLEVBQUUsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTO3lCQUNqQyxDQUFDLENBQUM7d0JBQ0gsTUFBTSxDQUFDLGdCQUFnQixDQUFDLENBQUMsZUFBZSxDQUFDOzRCQUNyQyxNQUFNLEVBQUUsWUFBWTt5QkFDdkIsQ0FBQyxDQUFDO3dCQUNILGdCQUFnQixFQUFFLENBQUM7b0JBQ3ZCLENBQUMsRUFDRyxJQUFJLENBQUMsQ0FBQztnQkFDZCxDQUFDO2dCQUdELDRDQUFpQixHQUFqQjtvQkFDSSxJQUFJLGNBQWMsR0FBRyxFQUFFLENBQUM7b0JBQ3hCLHdCQUFhLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxFQUFFLGNBQWMsQ0FBQyxDQUFDO29CQUMzRyxNQUFNLENBQUMsY0FBYyxDQUFDO2dCQUMxQixDQUFDO2dCQUVELCtDQUFvQixHQUFwQjtvQkFBQSxpQkFnT0M7b0JBL05HLG9GQUFvRjtvQkFDcEYsUUFBUSxDQUFDO29CQUNULEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLGlCQUFpQixJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsaUJBQWlCLENBQUMsS0FBSyxJQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUM7d0JBQzVHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDO29CQUNyQyxDQUFDO29CQUNELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxLQUFLLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzt3QkFDM0UsT0FBTyxDQUFDLEtBQUssQ0FBQzs0QkFDVixPQUFPLEVBQUUsZ0RBQWdEOzRCQUN6RCxTQUFTLEVBQUUsSUFBSSxDQUFDLFlBQVk7NEJBQzVCLE9BQU8sRUFBRTtnQ0FDTCxFQUFFLEVBQUU7b0NBQ0EsY0FBYztvQ0FDZCxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVM7aUNBQzVCOzZCQUNKO3lCQUNKLENBQUMsQ0FBQzt3QkFDSCxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7d0JBQ3ZCLE1BQU0sQ0FBQztvQkFDWCxDQUFDO29CQUNELElBQUksZUFBZSxHQUFHLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO29CQUMvQyxJQUFJLE1BQU0sR0FBRyxJQUFJLENBQUM7b0JBRWxCLEVBQUUsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDO3dCQUFDLE1BQU0sR0FBRyxvQkFBb0IsQ0FBQztvQkFDL0Qsd0dBQXdHO29CQUN4Ryw0REFBNEQ7b0JBRTVELEVBQUUsQ0FBQyxDQUFDLE1BQU0sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO3dCQUNqQixPQUFPLENBQUMsS0FBSyxDQUFDOzRCQUNWLE9BQU8sRUFBRSxNQUFNOzRCQUNmLFNBQVMsRUFBRSxJQUFJLENBQUMsWUFBWTs0QkFDNUIsT0FBTyxFQUFFO2dDQUNMLEVBQUUsRUFBRTtvQ0FDQSxjQUFjO29DQUNkLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUztpQ0FDNUI7NkJBQ0o7eUJBQ0osQ0FBQyxDQUFDO3dCQUNILE1BQU0sQ0FBQztvQkFDWCxDQUFDO29CQUFBLENBQUM7b0JBQ0YsSUFBSSxTQUFTLEdBQUcsTUFBTSxDQUFDLGdCQUFnQixDQUFDLENBQUMsR0FBRyxFQUFFLEdBQUcsR0FBRyxHQUFHLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFHLEdBQUcsR0FBRyxNQUFNLENBQUMsZUFBZSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUM7b0JBQzVILEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxNQUFNLElBQUksRUFBRSxDQUFDO3dCQUFDLFNBQVMsR0FBRyxFQUFFLENBQUM7b0JBRTNDLElBQUksV0FBVyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMscUJBQVMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO29CQUNuRixFQUFFLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7d0JBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQzs0QkFDVixPQUFPLEVBQUUsd0JBQXdCOzRCQUNqQyxTQUFTLEVBQUUsSUFBSSxDQUFDLFlBQVk7NEJBQzVCLE9BQU8sRUFBRTtnQ0FDTCxFQUFFLEVBQUU7b0NBQ0EsY0FBYztvQ0FDZCxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVM7aUNBQzVCOzZCQUNKO3lCQUNKLENBQUMsQ0FBQzt3QkFDSCxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7d0JBQ3ZCLE1BQU0sQ0FBQyxLQUFLLENBQUM7b0JBQ2pCLENBQUM7b0JBQ0QsSUFBSSxDQUFDLENBQUM7d0JBQ0YsV0FBVyxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQztvQkFDaEQsQ0FBQztvQkFDRCxJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FDckIsV0FBVyxDQUFDLFFBQVEsRUFDcEIsV0FBVyxDQUFDLEtBQUssRUFDakIsSUFBSSxDQUFDLE9BQU8sRUFDWixJQUFJLENBQUMsaUJBQWlCLEVBQUUsRUFDeEIsSUFBSSxDQUFDLGlCQUFpQixDQUFDLEtBQUssRUFDMUIsV0FBVyxDQUFDLGdCQUFnQixFQUM5QixDQUFDLElBQUksQ0FBQyxhQUFhLEVBQ25CLElBQUksQ0FBQyxhQUFhLEVBQ2xCLFdBQVcsQ0FBQyxpQkFBaUIsRUFDN0IsU0FBUyxDQUNaLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDWixPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUNuQixZQUFZO3dCQUNYLElBQUksS0FBSyxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDO3dCQUV4Qzs7Ozs7OzZCQU1LO3dCQUNMLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUM7NEJBQ3RCLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO2dDQUVaLE9BQU8sQ0FBQyxLQUFLLENBQUM7b0NBQ1YsT0FBTyxFQUFFLEtBQUssQ0FBQyxHQUFHO29DQUNsQixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7b0NBQzVCLE9BQU8sRUFBRTt3Q0FDTCxFQUFFLEVBQUU7NENBQ0EsY0FBYzs0Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7eUNBQzVCO3FDQUNKO2lDQUNKLENBQUMsQ0FBQztnQ0FDSCxLQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7Z0NBQ3ZCLE1BQU0sQ0FBQzs0QkFDWCxDQUFDOzRCQUNELElBQUksZUFBZSxHQUFHLEtBQUssQ0FBQyxlQUFlLENBQUM7NEJBQzVDLElBQUksY0FBYyxHQUFHLEtBQUssQ0FBQyxjQUFjLENBQUM7NEJBRTFDLEVBQUUsQ0FBQyxDQUFDLGVBQWUsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUN0QixFQUFFLENBQUMsQ0FBQyxlQUFlLEdBQUcsY0FBYyxDQUFDLENBQUMsQ0FBQztvQ0FDbkMsSUFBSSxPQUFPLEdBQUcsb0JBQW9CLEdBQUcsY0FBYyxDQUFDO29DQUNwRCxPQUFPLElBQUksZ0NBQWdDLEdBQUcsZUFBZSxDQUFDO29DQUM5RCxPQUFPLElBQUksdUJBQXVCLENBQUM7b0NBQ25DLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7d0NBQ25CLEtBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO3dDQUMxQixLQUFJLENBQUMsb0JBQW9CLEVBQUUsQ0FBQztvQ0FDaEMsQ0FBQztnQ0FDTCxDQUFDOzRCQUNMLENBQUM7NEJBQUMsSUFBSSxDQUFDLENBQUM7Z0NBQ0osRUFBRSxDQUFDLENBQUMsT0FBTyxlQUFlLElBQUksV0FBVyxDQUFDO29DQUN0QyxPQUFPLENBQUMsS0FBSyxDQUFDO3dDQUNWLE9BQU8sRUFBRSxnQkFBZ0I7d0NBQ3pCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTt3Q0FDNUIsT0FBTyxFQUFFOzRDQUNMLEVBQUUsRUFBRTtnREFDQSxjQUFjO2dEQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUzs2Q0FDNUI7eUNBQ0o7cUNBQ0osQ0FBQyxDQUFDO2dDQUNQLElBQUk7b0NBQ0EsT0FBTyxDQUFDLEtBQUssQ0FBQzt3Q0FDVixPQUFPLEVBQUUsMEJBQTBCO3dDQUNuQyxTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7d0NBQzVCLE9BQU8sRUFBRTs0Q0FDTCxFQUFFLEVBQUU7Z0RBQ0EsY0FBYztnREFDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7NkNBQzVCO3lDQUNKO3FDQUNKLENBQUMsQ0FBQzs0QkFDWCxDQUFDO3dCQUNMLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLGFBQWEsR0FBRyxLQUFLLENBQUM7NEJBQzNCLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO2dDQUNuQixLQUFLLENBQUM7b0NBQ0YsT0FBTyxDQUFDLEtBQUssQ0FBQzt3Q0FDVixPQUFPLEVBQUUsS0FBSyxDQUFDLE9BQU87d0NBQ3RCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTt3Q0FDNUIsT0FBTyxFQUFFOzRDQUNMLEVBQUUsRUFBRTtnREFDQSxjQUFjO2dEQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUzs2Q0FDNUI7eUNBQ0o7cUNBQ0osQ0FBQyxDQUFDO29DQUNILEtBQUssQ0FBQztnQ0FDVixLQUFLLENBQUM7b0NBQ0YsRUFBRSxDQUFDLENBQUMsS0FBSSxDQUFDLGdCQUFnQixDQUFDLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO3dDQUNuQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxLQUFLLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7NENBQzdFLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0RBQ1YsT0FBTyxFQUFFLDZCQUE2QjtnREFDdEMsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dEQUM1QixPQUFPLEVBQUU7b0RBQ0wsRUFBRSxFQUFFO3dEQUNBLGNBQWM7d0RBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FEQUM1QjtpREFDSjs2Q0FDSixDQUFDLENBQUM7NENBQ0gsS0FBSSxDQUFDLGVBQWUsRUFBRSxDQUFDOzRDQUN2QixNQUFNLENBQUMsS0FBSyxDQUFDO3dDQUNqQixDQUFDO29DQUNMLENBQUM7b0NBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQzt3Q0FDMUMsT0FBTyxDQUFDLEtBQUssQ0FBQzs0Q0FDVixPQUFPLEVBQUUsd0JBQXdCOzRDQUNqQyxTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7NENBQzVCLE9BQU8sRUFBRTtnREFDTCxFQUFFLEVBQUU7b0RBQ0EsY0FBYztvREFDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7aURBQzVCOzZDQUNKO3lDQUNKLENBQUMsQ0FBQztvQ0FDUCxDQUFDO29DQUNELEtBQUssQ0FBQztnQ0FDVjtvQ0FDSSxPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDOzRCQUMxQixDQUFDO3dCQUNMLENBQUM7b0JBQ0wsQ0FBQyxFQUNLLFVBQUEsR0FBRzt3QkFDRCxFQUFFLENBQUMsQ0FBQyxPQUFPLEdBQUcsQ0FBQyxLQUFLLElBQUksUUFBUSxDQUFDLENBQUMsQ0FBQzs0QkFDL0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSztnQ0FDcEMsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUM1QixPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFBQyxJQUFJLENBQUMsQ0FBQzs0QkFDSixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxrQ0FBa0M7Z0NBQzNDLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7b0JBQ0wsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUM7NEJBQ1IsT0FBTyxFQUFFLCtCQUErQjs0QkFDeEMsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZOzRCQUM1QixPQUFPLEVBQUU7Z0NBQ0wsRUFBRSxFQUFFO29DQUNBLGNBQWM7b0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO2lDQUM1Qjs2QkFDSjt5QkFDSixDQUFDLENBQUM7b0JBQ1AsQ0FBQyxDQUNBLENBQUE7Z0JBQ1QsQ0FBQztnQkFHRCxrQ0FBTyxHQUFQO29CQUNHLFlBQVk7b0JBRGYsaUJBZ0ZDO29CQTdFRyxJQUFJLENBQUMsV0FBVyxHQUFHO3dCQUNmLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsQ0FBQyxFQUFFO3dCQUMvQixFQUFFLElBQUksRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRTtxQkFDaEMsQ0FBQztvQkFDRixJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDNUMsa0RBQWtEO29CQUNsRCxzRUFBc0U7b0JBRXRFLElBQUksQ0FBQyxZQUFZLENBQUMsbUJBQW1CLEVBQUUsQ0FBQyxTQUFTLENBRTdDLFVBQUMsSUFBSTt3QkFDRCxJQUFJLEdBQUcsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUVqQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsYUFBYSxDQUFDOzRCQUMvQixZQUFZLEVBQUUsSUFBSTs0QkFDbEIsVUFBVSxFQUFFO2dDQUNSLGFBQWEsRUFBRSxJQUFJOzZCQUN0Qjs0QkFDRCw0QkFBNEI7NEJBQzVCLFVBQVUsRUFBRSxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVM7eUJBQ2pDLENBQUMsQ0FBQzt3QkFDSCxNQUFNLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxlQUFlLENBQUM7NEJBQ3JDLE1BQU0sRUFBRSxZQUFZO3lCQUN2QixDQUFDLENBQUM7b0JBQ1AsQ0FBQyxFQUNELFVBQUMsR0FBRztvQkFFSixDQUFDLEVBQ0Q7b0JBRUEsQ0FBQyxDQUVKLENBQUM7b0JBQ0YsNENBQTRDO29CQUM1QywwQkFBMEI7b0JBQzFCLEtBQUs7b0JBR0wscUZBQXFGO29CQUNyRixrRkFBa0Y7b0JBQ2xGLElBQUksQ0FBQyxZQUFZLENBQUMsaUJBQWlCLENBQUM7d0JBQ2hDLGNBQWMsRUFBRTs0QkFDWixLQUFLLEVBQUUsdU9BTUY7NEJBQ0wsVUFBVSxFQUFFLEVBQUU7eUJBQ2pCO3dCQUNELGFBQWEsRUFBRTs0QkFDWCxLQUFLLEVBQUUsK0VBQStFOzRCQUN0RixVQUFVLEVBQUUsRUFBRTt5QkFDakI7cUJBQ0osQ0FBQyxDQUFDLFNBQVMsQ0FDUixVQUFDLElBQUk7d0JBRUQsV0FBVzt3QkFDWCxPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUNsQixJQUFJLEdBQUcsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUVqQyxLQUFJLENBQUMsT0FBTyxHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQzt3QkFDNUMsS0FBSSxDQUFDLGlCQUFpQixHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQzt3QkFDckQsSUFBSSxXQUFXLEdBQUcsRUFBRSxDQUFDO3dCQUNyQixNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUksQ0FBQyxpQkFBaUIsRUFBRTs0QkFDaEMsV0FBVyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7NEJBRXpCLE1BQU0sQ0FBQyxLQUFLLENBQUM7d0JBQ2pCLENBQUMsQ0FBQyxDQUFDO3dCQUVILDJEQUEyRDtvQkFDL0QsQ0FBQyxFQUNELFVBQUMsS0FBSyxJQUFPLENBQUMsRUFDZCxjQUFRLENBQUMsQ0FDUixDQUFDO2dCQUVWLENBQUM7Z0JBdnFCTDtvQkFBQyxnQkFBUyxDQUFDO3dCQUNQLElBQUksRUFBRSxVQUFVO3dCQUNoQixLQUFLLEVBQUUsQ0FBQywwQkFBZSxFQUFFLCtCQUFvQixDQUFDO3dCQUM5QyxRQUFRLEVBQUUsOHBTQTJKVDt3QkFDRCxVQUFVLEVBQUUsQ0FBQyw2QkFBb0IsQ0FBQzt3QkFDbEMsU0FBUyxFQUFFLENBQUMseUJBQVcsRUFBRSwyQkFBWSxDQUFDO3FCQUN6QyxDQUFDOztvQ0FBQTtnQkFraUJGLHVCQUFDO1lBQUQsQ0FqaUJBLEFBaWlCQyxJQUFBO1lBamlCRCwrQ0FpaUJDLENBQUEiLCJmaWxlIjoiZGV2L2FtYXgvc21zLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtDb21wb25lbnQsIE9uSW5pdH0gZnJvbSBcImFuZ3VsYXIyL2NvcmVcIjtcclxuaW1wb3J0IHtTZWxlY3RJbnB1dENvbXBvbmVudH0gZnJvbSBcIi4uL2NvbW9uQ29tcG9uZW50cy9iYXNpY0NvbXBvbmVudHMvc2VsZWN0XCJcclxuaW1wb3J0IHtBbWF4U2VydmljZX0gZnJvbSBcIi4uL3NlcnZpY2VzL0FtYXhTZXJ2aWNlXCI7XHJcbmltcG9ydCB7R3JvdXBGaWx0ZXJQaXBlLCBHcm91cFBhcmVuRmlsdGVyUGlwZSwgS2VuZG9fdXRpbGl0eX0gZnJvbSBcIi4uL2FtYXhVdGlsXCI7XHJcbmltcG9ydCB7UmVzb3VyY2VTZXJ2aWNlfSBmcm9tIFwiLi4vc2VydmljZXMvUmVzb3VyY2VTZXJ2aWNlXCI7XHJcbmltcG9ydCB7TG9jYWxEaWN0LCBjcm1Db25maWd9IGZyb20gXCIuLi9jcm1jb25maWdcIjtcclxuaW1wb3J0IHtBbWF4Q3JtU3lpbmN9IGZyb20gXCIuLi9zZXJ2aWNlcy9BbWF4Q3JtU3lpbmNcIjtcclxuXHJcbmRlY2xhcmUgdmFyIGpRdWVyeTtcclxuZGVjbGFyZSB2YXIgc3dpdGNoX2RpcmVjdGlvbjtcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgbmFtZTogJ2FtYXgtc21zJyxcclxuICAgIHBpcGVzOiBbR3JvdXBGaWx0ZXJQaXBlLCBHcm91cFBhcmVuRmlsdGVyUGlwZV0sXHJcbiAgICB0ZW1wbGF0ZTogYDxkaXYgY2xhc3M9XCJyb3dcIiAqbmdJZj1cIlJFU1wiPlxyXG5cclxuICAgIDxkaXYgY2xhc3M9XCJjb2wgczEyIGNhcmQtcGFuZWxcIj5cclxuPGRpdiBjbGFzcz1cInJvd1wiPlxyXG48ZGl2IGNsYXNzPVwiY29sIHMxMlwiPlxyXG48aDE+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aSBjbGFzcz1cIm1kaS1jb250ZW50LXNlbGVjdC1hbGwgZ3JlZW4tdGV4dFwiPjwvaT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwicmVkLXRleHRcIj57e1JFUy5MQkxfSEVBRElOR319PC9zcGFuPiAgPCEtLXt7UkVTLkNVU1RPTUVSX01BU1RFUi5DVVNUX0xBQkFMfX1DdXN0b21lci0tPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2gxPlxyXG5cclxuPC9kaXY+XHJcbjxidXR0b24gY2xhc3M9XCJidG4gd2F2ZXMtZWZmZWN0IHdhdmVzLWxpZ2h0IGluZGlnbyB7eyBfYW1heENybVN5aW5jLmlzUnRsKCkgPyAncmlnaHQnIDogJ2xlZnQnfX1cIlxyXG4gICAgICAgICAgICAgICAgICAgIChjbGljayk9XCJvcGVuU21zU2V0dGluZ3MoKVwiPlxyXG4gICAgICAgICAgICAgICAgPGkgY2xhc3M9XCJtZGktYWN0aW9uLXNldHRpbmdzXCI+PC9pPiB7e1JFUy5MQkxfU0VUVElOR319XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuPC9kaXY+XHJcbiAgICAgICAgPGRpdiBzdHlsZT1cIm92ZXJmbG93OiBoaWRkZW47XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wgczEyXCI+Jm5ic3A7PC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgaWQ9XCJTbXNTZXR0aW5nc1Bhbm5lbFwiIGNsYXNzPVwiY29sIHMxMiBhbmltYXRlZCBzbGlkZUluRG93blwiICpuZ0lmPVwib3BlblNldHRyaW5nc1wiPlxyXG4gICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sIHMxMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbD57e1JFUy5MQkxfU01TX1BST1ZJREVSU319PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8c2VsZWN0IGNsYXNzPVwiYnJvd3Nlci1kZWZhdWx0XCIgWyhuZ01vZGVsKV09IFwiU2VsZWN0ZWRQcm92aWRlci52YWx1ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIjFcIj5TbXMgMiB5b3U8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIjJcIj4wMTkgU21zPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiaW5wdXQtZmllbGQgY29sIHM2XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgaWQ9XCJVc2VyTmFtZVwiIGNsYXNzPVwiZm9ybS1jb250cm9sXCIgWyhuZ01vZGVsKV09IFwiU2VsZWN0ZWREYXRhLlVzZXJOYW1lXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGZvcj1cIlVzZXJOYW1lXCIgY2xhc3M9XCJhY3RpdmVcIj57e1JFUy5MQkxfU01TX1VTRVJOQU1FfX08L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiaW5wdXQtZmllbGQgY29sIHM2XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0IGNsYXNzPVwiZm9ybS1jb250cm9sXCIgdHlwZT1cInBhc3N3b3JkXCIgaWQ9XCJQYXNzd29yZFwiIFsobmdNb2RlbCldPSBcIlNlbGVjdGVkRGF0YS5WYWx1ZVwiLz5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgZm9yPVwiUGFzc3dvcmRcIiBjbGFzcz1cImFjdGl2ZVwiPnt7UkVTLlNNU19QQVNTV09SRH19PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiaW5wdXQtZmllbGQgY29sIHMxMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dCBjbGFzcz1cImZvcm0tY29udHJvbFwiIGlkPVwiUGhOb1wiIHR5cGU9XCJ0ZXh0XCIgWyhuZ01vZGVsKV09XCJTZW5kZXJQaG9uZU51bWJlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBmb3I9XCJQaE5vXCIgY2xhc3M9XCJhY3RpdmVcIj57e1JFUy5MQkxfU0VOREVSX1BIT05FfX08L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sIHMxMlwiPiZuYnNwOzwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbCBzMTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuIHdhdmVzLWVmZmVjdCB3YXZlcy1saWdodCBncmVlbiBhY2NlbnQtNFwiIChjbGljayk9XCJzYXZlU21zU2V0dGluZ3MoKVwiIHN0eWxlPVwid2lkdGg6MjAwcHghaW1wb3J0YW50O1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aSBjbGFzcz1cIm1kaS1jb250ZW50LXNhdmVcIj48L2k+IHt7UkVTLkxCTF9TQVZFX1NFVFRJTkd9fVxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3M9XCJidG4gd2F2ZXMtZWZmZWN0IHdhdmVzLWxpZ2h0ICBncmV5IGxpZ2h0ZW4tMlwiIChjbGljayk9XCJjbG9zZVNtc1NldHRpbmdzKClcInN0eWxlPVwid2lkdGg6MjAwcHghaW1wb3J0YW50O1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aSBjbGFzcz1cIm1kaS1uYXZpZ2F0aW9uLWNsb3NlXCI+PC9pPiB7e1JFUy5MQkxfQ0xPU0VfU0VUVElOR1N9fVxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sIHMxMlwiICpuZ0lmPVwiIW9wZW5TZXR0cmluZ3NcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJyb3dcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sIHM2XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJyb3dcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wgczEyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsPnt7UkVTLkxCTF9HUk9VUFN9fTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImstY29udGVudCB7e0tlbmRvUlRMQ1NTfX1cIiBzdHlsZT1cIm1heC1oZWlnaHQ6IDIzMHB4O292ZXJmbG93LXk6IGF1dG87IHBhZGRpbmc6IDIwcHggMTBweCA0MHB4OyBtYXJnaW4tbGVmdDoxMHB4O1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGlkPVwiZ3JvdXBUcmVlXCIgc3R5bGU9XCJvdmVyZmxvdzogdmlzaWJsZTtcIj4gTG9hZGluZy4uLjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wgczZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInJvd1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbCBzMTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWw+e3tSRVMuTEJMX1BIT05FX1RZUEVTfX08L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxteC1zZWxlY3QgW2RhdGFdPVwiUGhvbmVUeXBlTGlzdERhdGFcIiBsYWJlbD1cIkxhYmVsXCIgc2VsZWN0ZWR2YWw9XCJBbGxcIiBmaXJzdHZhbHVlPVwiQWxsXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAob25EYXRhKT1cIlNlbGVjdGVkUGhvbmVUeXBlID0gJGV2ZW50XCIgY3NzY2xhc3M9XCJicm93c2VyLWRlZmF1bHRcIiBpZD1cIlBob250VHlwZXNlbFwiPjwvbXgtc2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sIHMxMlwiPiZuYnNwOzwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbCBzMTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwicm93XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkZXRhaWxzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN1bW1hcnk+e3tSRVMuTEJMX1NFTkRfTEFURVJ9fTwvc3VtbWFyeT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wgczZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWw+e3tSRVMuU01TX0xCTF9EQVRFfX08L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJrLWNvbnRlbnRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IGNsYXNzPVwiZm9ybS1jb250cm9sXCIgaWQ9XCJzZW5kTGF0ZXJEYXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wgczNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWw+e3tSRVMuU01TX0xCTF9IUn19PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0IGNsYXNzPVwiYnJvd3Nlci1kZWZhdWx0XCIgaWQ9XCJzZW5kTGF0ZXJIb3VyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24+MDE8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbj4wMjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uPjAzPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24+MDQ8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbj4wNTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uPjA2PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24+MDc8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbj4wODwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uPjA5PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24+MTA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbj4xMTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uPjEyPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24+MTM8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbj4xNDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uPjE1PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24+MTY8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbj4xNzwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uPjE4PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24+MTk8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbj4yMDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uPjIxPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24+MjI8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbj4yMzwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uPjI0PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wgczNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWw+e3tSRVMuU01TX0xCTF9NSU59fTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdCBjbGFzcz1cImJyb3dzZXItZGVmYXVsdFwiIGlkPVwic2VuZExhdGVyTWluXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24+MDA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbj4wNTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uPjEwPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24+MTU8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbj4yMDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uPjI1PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24+MzA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbj4zNTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uPjQwPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24+NDU8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbj41MDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uPjU1PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24+NjA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2RldGFpbHM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wgczEyXCI+Jm5ic3A7PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sIHMxMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbD57e1JFUy5MQkxfTUVTU0FHRX19PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGV4dGFyZWEgY29scz1cIjUwXCIgI21zZyAoa2V5dXApPVwibWVzc2FnZT1tc2cudmFsdWVcIiBjbGFzcz1cImZvcm0tY29udHJvbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwie3tSRVMuU01TX1RYVF9QSF9NRVNTQUdFfX1cIiAoY2hhbmdlKT1cIlNldGRlZmF1bHRNc2dWYWx1ZSgpXCIgaWQ9XCJNZXNzYWdldHh0YXJcIiBbKG5nTW9kZWwpXT0gXCJtZXNzYWdlXCI+PC90ZXh0YXJlYT5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3tSRVMuU01TX0xCTF9NQVhDSEFSfX0gOiB7e21zZy52YWx1ZS5sZW5ndGh8fDB9fTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sIHMxMlwiIGlkPVwiU2VsZWN0ZWRDdXN0b21lcnNcIj4mbmJzcDs8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sIHMxMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuIHdhdmVzLWVmZmVjdCB3YXZlcy1saWdodCBncmVlbiBhY2NlbnQtNFwiIHN0eWxlPVwid2lkdGg6MTc1cHghaW1wb3J0YW50O1wiIChjbGljayk9XCJTZW5kVG9TZWxlY3RlZEdyb3VwcygpXCI+e3tSRVMuU01TX0JUTl9TRU5ETUVTU0FHRX19PC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInNwYWNlLTRcIj48ZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8YnIvPjxici8+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICBgLFxyXG4gICAgZGlyZWN0aXZlczogW1NlbGVjdElucHV0Q29tcG9uZW50XSxcclxuICAgIHByb3ZpZGVyczogW0FtYXhTZXJ2aWNlLCBBbWF4Q3JtU3lpbmNdXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBBbWF4U21zQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcclxuICAgIHByaXZhdGUgUkVTOiBhbnk7XHJcbiAgICBwcml2YXRlIG9wZW5TZXR0cmluZ3M6IGJvb2xlYW4gPSBmYWxzZTtcclxuXHJcbiAgICBTbXNEYXRhOiBBcnJheTxhbnk+O1xyXG4gICAgU2VsZWN0ZWREYXRhOiBPYmplY3QgPSB7fTtcclxuICAgIHNlbGVjdGVkVmFsdWU6IHN0cmluZztcclxuICAgIFNtc1Byb3ZpZGVyOiBBcnJheTxhbnk+O1xyXG4gICAgU2VsZWN0ZWRQcm92aWRlcjogT2JqZWN0ID0ge307XHJcblxyXG4gICAgQ29uZmlybWVkU2VuZDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgTGFuZ3VhZ2U6IHN0cmluZztcclxuICAgIFBob25lVHlwZUxpc3REYXRhOiBBcnJheTxhbnk+O1xyXG4gICAgU2VsZWN0ZWRQaG9uZVR5cGU6IE9iamVjdCA9IHt9O1xyXG4gICAgdXNlck5hbWU6IHN0cmluZztcclxuICAgIG1lc3NhZ2U6IHN0cmluZztcclxuICAgIFNlbmRlclBob25lTnVtYmVyOiBzdHJpbmc7XHJcbiAgICBLZW5kb1JUTENTUzogc3RyaW5nID0gXCJcIjtcclxuICAgIENoYW5nZURpYWxvZzogc3RyaW5nID0gXCJcIjtcclxuICAgIENIQU5HRURJUjogc3RyaW5nID0gXCJcIjtcclxuXHJcblxyXG5cclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgX2FtYXhTZXJ2aWNlOiBBbWF4U2VydmljZSwgcHJpdmF0ZSBfcmVzb3VyY2VTZXJ2aWNlOiBSZXNvdXJjZVNlcnZpY2UsIHByaXZhdGUgX2FtYXhDcm1TeWluYzogQW1heENybVN5aW5jKSB7XHJcbiAgICAgICAgdGhpcy5TZWxlY3RlZERhdGEuVXNlck5hbWUgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMuU2VsZWN0ZWREYXRhLlZhbHVlID0gXCJcIjtcclxuICAgICAgICB0aGlzLlNlbmRlclBob25lTnVtYmVyID0gXCJcIjtcclxuICAgICAgICB0aGlzLlNlbGVjdGVkUGhvbmVUeXBlLlZhbHVlID0gXCJcIjtcclxuICAgICAgICB0aGlzLlNlbGVjdGVkUHJvdmlkZXIudmFsdWUgPSBcIlwiO1xyXG4gICAgICAgIHZhciBlbXBpZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiZW1wbG95ZWVpZFwiKTtcclxuICAgICAgICB2YXIgbWVzc2FnZSA9IHRoaXMuX3Jlc291cmNlU2VydmljZS5nZXRDb29raWUoZW1waWQrXCJTTVNNZXNzYWdlXCIpO1xyXG4gICAgICAgIGlmIChtZXNzYWdlLmxlbmd0aCA+IDAgJiYgbWVzc2FnZVswXSA9PSBcIj1cIilcclxuICAgICAgICAgICAgbWVzc2FnZSA9IG1lc3NhZ2Uuc3Vic3RyaW5nKDEsIG1lc3NhZ2UubGVuZ3RoKTtcclxuICAgICAgICB0aGlzLm1lc3NhZ2UgPSBtZXNzYWdlO1xyXG5cclxuICAgIH1cclxuICAgIFNldGRlZmF1bHRNc2dWYWx1ZSgpIHtcclxuICAgICAgICAvL2FsZXJ0KCdIZWxsbycpO1xyXG4gICAgICAgIHZhciBlbXBpZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiZW1wbG95ZWVpZFwiKTtcclxuICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2Uuc2V0Q29va2llKGVtcGlkICsgXCJTTVNNZXNzYWdlXCIsIHRoaXMubWVzc2FnZSwgMTApO1xyXG5cclxuICAgICAgICBcclxuICAgICAgICAvL2FsZXJ0KG1lc3NhZ2UpO1xyXG4gICAgfVxyXG4gICAgbmdPbkluaXQoKSB7XHJcbiAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICBcclxuICAgICAgICAvL3RoaXMuX2FtYXhDcm1TeWluYy5vbignbHNzZXQuJyArIExvY2FsRGljdC5sYW5ndWFnZVJlc291cmNlLCBkYXRhPT4gdGhpcy5SRVMgPSBkYXRhW1wiU0NSRUVOX1NNU1wiXSk7XHJcbiAgICAgICAgLy90aGlzLlJFUyA9IHRoaXMuX2FtYXhDcm1TeWluYy5mZXRjaExhbmd1YWdlUmVzb3VyY2UoXCJTQ1JFRU5fU01TXCIpO1xyXG5cclxuXHJcblxyXG5cclxuXHJcbiAgICAgICAgLy9hbGVydCgnaGVsbG8nKTtcclxuICAgICAgICAvL2xvYWRpbmdMYW5ndWFnZSBzdGFydFxyXG4gICAgICAgIFxyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMuX2FtYXhDcm1TeWluYy5vbignbHNzZXQuJyArIExvY2FsRGljdC5sYW5ndWFnZVJlc291cmNlLCBkYXRhPT4gdGhpcy5SRVMgPSBkYXRhW1wiU0NSRUVOX1NNU1wiXSk7XHJcbiAgICAgICAgdGhpcy5SRVMgPSB0aGlzLl9hbWF4Q3JtU3lpbmMuZmV0Y2hMYW5ndWFnZVJlc291cmNlKFwiU0NSRUVOX1NNU1wiKTtcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG5cclxuICAgICAgICBpZiAoIXRoaXMuUkVTKSB7XHJcbiAgICAgICAgICAgIGlmICghbG9jYWxTdG9yYWdlLmdldEl0ZW0oTG9jYWxEaWN0LnNlbGVjdGVkTGFuZ3VhZ2UpKSB7XHJcbiAgICAgICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShMb2NhbERpY3Quc2VsZWN0ZWRMYW5ndWFnZSwgY3JtQ29uZmlnLmZhbGJhY2tMYW5ndWFnZSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdGhpcy5MYW5ndWFnZSA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwibGFuZ1wiKTtcclxuICAgICAgICAgICAgaWYgKHRoaXMuTGFuZ3VhZ2UgPT0gXCJoZVwiKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLktlbmRvUlRMQ1NTID0gXCJrLXJ0bFwiO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRoaXMuX2FtYXhDcm1TeWluYy5sb2FkTGFuZ3VhZ2VSZXNvdXJjZShsb2NhbFN0b3JhZ2UuZ2V0SXRlbShMb2NhbERpY3Quc2VsZWN0ZWRMYW5ndWFnZSkpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgICAgICAvL2xvYWRpbmdMYW5ndWFnZSBzdGFydFxyXG4gICAgICAgIHRoaXMuYWxsQmluZCgpO1xyXG4gICAgICAgIC8vYWxlcnQoJ0J5ZScpO1xyXG4gICAgICAgIC8vdmFyIG1lc3NhZ2UgPSB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZ2V0Q29va2llKFwiU01TTWVzc2FnZVwiKTtcclxuICAgICAgICAvL2lmIChtZXNzYWdlLmxlbmd0aCA+IDAgJiYgbWVzc2FnZVswXSA9PSBcIj1cIilcclxuICAgICAgICAvLyAgICBtZXNzYWdlID0gbWVzc2FnZS5zdWJzdHJpbmcoMSwgbWVzc2FnZS5sZW5ndGgpO1xyXG4gICAgICAgIC8vdGhpcy5tZXNzYWdlID0gbWVzc2FnZTtcclxuICAgICAgICBcclxuICAgIH1cclxuXHJcbiAgICAvL3NhdmVTbXNTZXR0aW5ncygpe1xyXG4gICAgLy8gICAgYWxlcnQoXCJTbXMgU2V0dGluZyBzYXZlZC5cIik7XHJcbiAgICAvLyAgICB0aGlzLm9wZW5TZXR0cmluZ3M9ZmFsc2U7XHJcbiAgICAvL31cclxuICAgIC8vb3BlblNtc1NldHRpbmdzKCl7XHJcbiAgICAvLyAgICB0aGlzLm9wZW5TZXR0cmluZ3M9dHJ1ZTtcclxuICAgIC8vICAgIC8vc2V0VGltZW91dChmdW5jdGlvbiAoKSB7XHJcbiAgICAvLyAgICAvLyAgICBqUXVlcnkoJyNTbXNTZXR0aW5nc1Bhbm5lbCcpLmFkZENsYXNzKCdhbmltYXRlZCBib3VuY2VJbkRvd24nKTtcclxuICAgIC8vICAgIC8vfSwyMDApO1xyXG4gICAgLy99XHJcbiAgICAvL2Nsb3NlU21zU2V0dGluZ3MoKXtcclxuICAgIC8vICAgIGpRdWVyeSgnI1Ntc1NldHRpbmdzUGFubmVsJykuYWRkQ2xhc3MoJ2FuaW1hdGVkIHNsaWRlT3V0RG93bicpO1xyXG4gICAgLy8gICAgc2V0VGltZW91dCgoKT0+e1xyXG4gICAgLy8gICAgICAgIHRoaXMub3BlblNldHRyaW5ncz1mYWxzZTtcclxuICAgIC8vICAgIH0sMjAwKTtcclxuICAgIC8vfVxyXG5cclxuXHJcblxyXG5cclxuXHJcblxyXG4gICAgXHJcbiAgICBzYXZlU21zU2V0dGluZ3MoKSB7XHJcbiAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICB2YXIganNvbk9iamVjdCA9IHsgVXNlck5hbWU6IFwiXCIsIFZhbHVlOiBcIlwiLCBTZWxlY3RlZFByb3ZpZGVyOiBcIlwiLCBTZW5kZXJQaG9uZU51bWJlcjogXCJcIiB9O1xyXG4gICAgICAgIGpzb25PYmplY3QuVXNlck5hbWUgPSB0aGlzLlNlbGVjdGVkRGF0YS5Vc2VyTmFtZTtcclxuICAgICAgICAvL2pzb25PYmplY3QuVmFsdWUgPSB0aGlzLlNlbGVjdGVkRGF0YS5WYWx1ZTtcclxuXHJcbiAgICAgICAgLy9qc29uT2JqZWN0LlVzZXJOYW1lID0gJChcIiNVc2VyX3R4dFwiKS52YWw7Ly90aGlzLlNlbGVjdGVkRGF0YS5Vc2VyTmFtZTtcclxuICAgICAgICAvL2pzb25PYmplY3QuVmFsdWUgPSAkKFwiI1Bhc3NfdHh0XCIpLnZhbDsvL3RoaXMuU2VsZWN0ZWREYXRhLlZhbHVlO1xyXG5cclxuICAgICAgICBqc29uT2JqZWN0LlNlbGVjdGVkUHJvdmlkZXIgPSB0aGlzLlNlbGVjdGVkUHJvdmlkZXIudmFsdWU7XHJcbiAgICAgICAganNvbk9iamVjdC5TZW5kZXJQaG9uZU51bWJlciA9IHRoaXMuU2VuZGVyUGhvbmVOdW1iZXI7XHJcbiAgICAgICAgXHJcbiAgICAgICAgaWYgKGpzb25PYmplY3QuVXNlck5hbWUgJiYgdGhpcy5TZWxlY3RlZERhdGEuVmFsdWUgJiYganNvbk9iamVjdC5TZWxlY3RlZFByb3ZpZGVyICYmIGpzb25PYmplY3QuU2VuZGVyUGhvbmVOdW1iZXIpIHtcclxuICAgICAgICAgICAgdGhpcy5fYW1heENybVN5aW5jLnN0b3JlTG9jYWwoTG9jYWxEaWN0LlNtc1NldHRpbmdzLCBqc29uT2JqZWN0KTtcclxuICAgICAgICAgICAgdmFyIGVtcGlkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJlbXBsb3llZWlkXCIpO1xyXG4gICAgICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2Uuc2V0Q29va2llKGVtcGlkICsgXCJTTVNEZXRcIiwgSlNPTi5zdHJpbmdpZnkoanNvbk9iamVjdCksIDEwKTtcclxuICAgICAgICAgICAgdGhpcy5jbG9zZVNtc1NldHRpbmdzKCk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICBtZXNzYWdlOiBcIlBsZWFzZSBWYXJpZnllIHRoZSBzZXR0aW5nc1wiLFxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBvcGVuU21zU2V0dGluZ3MoKSB7XHJcbiAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICB0aGlzLm9wZW5TZXR0cmluZ3MgPSB0cnVlO1xyXG4gICAgICAgIC8vdmFyIGpzb25PYmplY3QgPSBKU09OLnBhcnNlKHRoaXMuX2FtYXhDcm1TeWluYy5mZXRjaExvY2FsKExvY2FsRGljdC5TbXNTZXR0aW5ncykpO1xyXG4gICAgICAgIHZhciBlbXBpZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiZW1wbG95ZWVpZFwiKTtcclxuICAgICAgICB2YXIgZGF0YSA9IHRoaXMuX3Jlc291cmNlU2VydmljZS5nZXRDb29raWUoZW1waWQgKyBcIlNNU0RldFwiKTtcclxuICAgICAgICB2YXIganNvbk9iamVjdCA9IHt9O1xyXG4gICAgICAgIGlmIChkYXRhLmxlbmd0aCA+IDApXHJcbiAgICAgICAgICAgIGpzb25PYmplY3QgPSBqUXVlcnkucGFyc2VKU09OKGRhdGEuc3Vic3RyaW5nKDEsIGRhdGEubGVuZ3RoKSk7XHJcbiAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICBpZiAoanNvbk9iamVjdCAhPSBudWxsKSB7XHJcbiAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgdGhpcy5TbXNEYXRhLmxlbmd0aDsgaSsrKVxyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuU21zRGF0YVtpXS5Vc2VyTmFtZSA9PSBqc29uT2JqZWN0LlVzZXJOYW1lKVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuU2VsZWN0ZWREYXRhLlVzZXJOYW1lID0gdGhpcy5TbXNEYXRhW2ldLlVzZXJOYW1lOyAgIC8vJiYgdGhpcy5TbXNEYXRhW2ldLlZhbHVlID09IGpzb25PYmplY3QuVmFsdWVcclxuXHJcbiAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgdGhpcy5TbXNQcm92aWRlci5sZW5ndGg7IGkrKylcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLlNtc1Byb3ZpZGVyW2ldLnZhbHVlID09IGpzb25PYmplY3QuU2VsZWN0ZWRQcm92aWRlcikgdGhpcy5TZWxlY3RlZFByb3ZpZGVyID0gdGhpcy5TbXNQcm92aWRlcltpXTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuU2VuZGVyUGhvbmVOdW1iZXIgPSBqc29uT2JqZWN0LlNlbmRlclBob25lTnVtYmVyO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5TZWxlY3RlZERhdGEuVXNlck5hbWUgPSBcIlwiO1xyXG4gICAgICAgICAgICB0aGlzLlNlbGVjdGVkRGF0YS5WYWx1ZSA9IFwiXCI7XHJcbiAgICAgICAgICAgIHRoaXMuU2VuZGVyUGhvbmVOdW1iZXIgPSBcIlwiO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIGNsb3NlU21zU2V0dGluZ3MoKSB7XHJcbiAgICAgICAgdGhpcy5vcGVuU2V0dHJpbmdzID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5hbGxCaW5kKCk7XHJcbiAgICB9XHJcblxyXG4gICAgZG9Ob3RoaW5nKCkge1xyXG4gICAgfVxyXG5cclxuICAgIG9wZW5Nb2RlbCgpIHtcclxuICAgIH1cclxuXHJcblxyXG4gICAgc2V0U21zQ29tcGFueUxpc3QoZGF0YTogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5TbXNEYXRhID0gZGF0YTtcclxuICAgICAgICB0aGlzLlNlbGVjdGVkRGF0YSA9IHRoaXMuU21zRGF0YVswXTtcclxuICAgIH1cclxuICAgIGJpbmRQaG9uZVR5cGVMaXN0KGRhdGE6IGFueSk6IHZvaWQge1xyXG5cclxuICAgICAgICB0aGlzLlBob25lVHlwZUxpc3REYXRhID0gZGF0YTtcclxuICAgICAgICB0aGlzLlNlbGVjdGVkUGhvbmVUeXBlID0gdGhpcy5QaG9uZVR5cGVMaXN0RGF0YVswXTtcclxuICAgIH1cclxuICAgIGJpbmRHZW5lcmFsR3JvdXBUcmVlKGRhdGE6IGFueSk6IHZvaWQge1xyXG4gICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAgalF1ZXJ5KFwiI2dyb3VwVHJlZVwiKS5odG1sKFwiTG9kaW5nLi4uXCIpO1xyXG4gICAgICAgIHZhciByZXMgPSBqUXVlcnkucGFyc2VKU09OKGRhdGEpO1xyXG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgICAgICBqUXVlcnkoXCIjZ3JvdXBUcmVlXCIpLmtlbmRvVHJlZVZpZXcoe1xyXG4gICAgICAgICAgICAgICAgbG9hZE9uRGVtYW5kOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgY2hlY2tib3hlczoge1xyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrQ2hpbGRyZW46IHRydWVcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICBkYXRhU291cmNlOiByZXMuRGF0YS5rZW5kb1RyZWVcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIGpRdWVyeShcIiNzZW5kTGF0ZXJEYXRlXCIpLmtlbmRvRGF0ZVBpY2tlcih7XHJcbiAgICAgICAgICAgICAgICBmb3JtYXQ6IFwiZGQtTU0teXl5eVwiXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICBzd2l0Y2hfZGlyZWN0aW9uKCk7XHJcbiAgICAgICAgfSxcclxuICAgICAgICAgICAgMTAwMCk7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIGdldFNlbGVjdGVkR3JvdXBzKCk6IEFycmF5PG51bWJlcj4ge1xyXG4gICAgICAgIHZhciBfQ2hlY2tlZEdyb3VwcyA9IFtdO1xyXG4gICAgICAgIEtlbmRvX3V0aWxpdHkuY2hlY2tlZE5vZGVJZHMoalF1ZXJ5KFwiI2dyb3VwVHJlZVwiKS5kYXRhKFwia2VuZG9UcmVlVmlld1wiKS5kYXRhU291cmNlLnZpZXcoKSwgX0NoZWNrZWRHcm91cHMpO1xyXG4gICAgICAgIHJldHVybiBfQ2hlY2tlZEdyb3VwcztcclxuICAgIH1cclxuXHJcbiAgICBTZW5kVG9TZWxlY3RlZEdyb3VwcygpIHtcclxuICAgICAgICAvL3VzZXJuYW1lOnN0cmluZyxjb21wYW55OnN0cmluZyxtZXNzYWdlOnN0cmluZyxncm91cHM6QXJyYXk8YW55PixwaG9uZVR5cGVJZDpudW1iZXJcclxuICAgICAgICBkZWJ1Z2dlcjtcclxuICAgICAgICBpZiAodGhpcy5TZWxlY3RlZFBob25lVHlwZSA9PSB1bmRlZmluZWQgfHwgdGhpcy5TZWxlY3RlZFBob25lVHlwZSA9PSBudWxsIHx8IHRoaXMuU2VsZWN0ZWRQaG9uZVR5cGUuVmFsdWU9PVwiXCIpIHtcclxuICAgICAgICAgICAgdGhpcy5TZWxlY3RlZFBob25lVHlwZS5WYWx1ZSA9IDA7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICh0aGlzLlNlbGVjdGVkUGhvbmVUeXBlLlZhbHVlID09IDEgJiYgdGhpcy5TZW5kZXJQaG9uZU51bWJlci5sZW5ndGggIT0gMTApIHtcclxuICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICBtZXNzYWdlOiBcIlNlbmRlciBNdXN0IGJlIDEwIERpZ2l0IHZhbGlkIGNlbGxwaG9uZSBudW1iZXJcIixcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIHRoaXMub3BlblNtc1NldHRpbmdzKCk7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgdmFyIF9zZWxlY3RlZEdyb3VwcyA9IHRoaXMuZ2V0U2VsZWN0ZWRHcm91cHMoKTtcclxuICAgICAgICB2YXIgc3RhdHVzID0gXCJva1wiO1xyXG5cclxuICAgICAgICBpZiAoX3NlbGVjdGVkR3JvdXBzLmxlbmd0aCA9PSAwKSBzdGF0dXMgPSBcIk5vIGdyb3VwcyBzZWxlY3RlZFwiO1xyXG4gICAgICAgIC8vZWxzZSBpZiAoIXRoaXMuU2VsZWN0ZWREYXRhLlVzZXJOYW1lIHx8ICF0aGlzLlNlbGVjdGVkRGF0YS5WYWx1ZSkgc3RhdHVzID0gXCJQbGVhc2Ugc2VsZWN0IGEgcHJvdmlkZXJcIjtcclxuICAgICAgICAvL2Vsc2UgaWYgKCF0aGlzLm1lc3NhZ2UpIHN0YXR1cyA9IFwiTWVzc2FnZSBjYW4ndCBiZSBlbXB0eVwiO1xyXG5cclxuICAgICAgICBpZiAoc3RhdHVzICE9IFwib2tcIikge1xyXG4gICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHN0YXR1cyxcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9O1xyXG4gICAgICAgIHZhciBzZW5kbGF0ZXIgPSBqUXVlcnkoJyNzZW5kTGF0ZXJEYXRlJykudmFsKCkgKyBcIiBcIiArIGpRdWVyeSgnI3NlbmRMYXRlckhvdXInKS52YWwoKSArIFwiOlwiICsgalF1ZXJ5KCcjc2VuZExhdGVyTWluJykudmFsKCk7XHJcbiAgICAgICAgaWYgKHNlbmRsYXRlci5sZW5ndGggIT0gMTYpIHNlbmRsYXRlciA9IFwiXCI7XHJcblxyXG4gICAgICAgIHZhciBzbXNTZXR0aW5ncyA9IEpTT04ucGFyc2UodGhpcy5fYW1heENybVN5aW5jLmZldGNoTG9jYWwoTG9jYWxEaWN0LlNtc1NldHRpbmdzKSk7XHJcbiAgICAgICAgaWYgKCFzbXNTZXR0aW5ncykge1xyXG4gICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiU21zIFNldHRpbmdzIG5vdCBmb3VuZFwiLFxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgdGhpcy5vcGVuU21zU2V0dGluZ3MoKTtcclxuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgc21zU2V0dGluZ3MuVmFsdWUgPSB0aGlzLlNlbGVjdGVkRGF0YS5WYWx1ZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5fYW1heFNlcnZpY2UuU2VuZFNtcyhcclxuICAgICAgICAgICAgc21zU2V0dGluZ3MuVXNlck5hbWUsXHJcbiAgICAgICAgICAgIHNtc1NldHRpbmdzLlZhbHVlLFxyXG4gICAgICAgICAgICB0aGlzLm1lc3NhZ2UsXHJcbiAgICAgICAgICAgIHRoaXMuZ2V0U2VsZWN0ZWRHcm91cHMoKSxcclxuICAgICAgICAgICAgdGhpcy5TZWxlY3RlZFBob25lVHlwZS5WYWx1ZVxyXG4gICAgICAgICAgICAsIHNtc1NldHRpbmdzLlNlbGVjdGVkUHJvdmlkZXIsXHJcbiAgICAgICAgICAgICF0aGlzLkNvbmZpcm1lZFNlbmQsXHJcbiAgICAgICAgICAgIHRoaXMuQ29uZmlybWVkU2VuZCxcclxuICAgICAgICAgICAgc21zU2V0dGluZ3MuU2VuZGVyUGhvbmVOdW1iZXIsXHJcbiAgICAgICAgICAgIHNlbmRsYXRlclxyXG4gICAgICAgICkuc3Vic2NyaWJlKGRhdGE9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGRhdGEpO1xyXG4gICAgICAgICAgIC8vIGRlYnVnZ2VyO1xyXG4gICAgICAgICAgICB2YXIgX2RhdGEgPSBqUXVlcnkucGFyc2VKU09OKGRhdGEpLkRhdGE7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAvKmpRdWVyeShcIiNTZWxlY3RlZEN1c3RvbWVyc1wiKS5rZW5kb0dyaWQoe1xyXG4gICAgICAgICAgICAgICAgZGF0YVNvdXJjZToge1xyXG4gICAgICAgICAgICAgICAgICAgIGRhdGE6IF9kYXRhLkN1c3RvbWVyc1xyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIGhlaWdodDogMzUwLFxyXG4gICAgICAgICAgICAgICAgc2VsZWN0YWJsZTogXCJtdWx0aXBsZVwiXHJcbiAgICAgICAgICAgIH0pOyovXHJcbiAgICAgICAgICAgIGlmICghdGhpcy5Db25maXJtZWRTZW5kKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoX2RhdGEuZXJyKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBfZGF0YS5lcnIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm9wZW5TbXNTZXR0aW5ncygpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHZhciBSZW1haW5pbmdDcmVkaXQgPSBfZGF0YS5SZW1haW5pbmdDcmVkaXQ7XHJcbiAgICAgICAgICAgICAgICB2YXIgVG90YWxDdXN0b21lcnMgPSBfZGF0YS5Ub3RhbEN1c3RvbWVycztcclxuXHJcbiAgICAgICAgICAgICAgICBpZiAoUmVtYWluaW5nQ3JlZGl0ID4gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChSZW1haW5pbmdDcmVkaXQgPiBUb3RhbEN1c3RvbWVycykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgbWVzc2FnZSA9IFwiVG90YWwgY3VzdG9tZXJzIDogXCIgKyBUb3RhbEN1c3RvbWVycztcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZSArPSBcIlxcblJlbWFpbmluZyBDcmVhZGl0IGZvciBzbXMgOiBcIiArIFJlbWFpbmluZ0NyZWRpdDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZSArPSBcIlxcblxcblByb2NpZGUgdG8gc2VuZCA/XCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChjb25maXJtKG1lc3NhZ2UpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLkNvbmZpcm1lZFNlbmQgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5TZW5kVG9TZWxlY3RlZEdyb3VwcygpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIFJlbWFpbmluZ0NyZWRpdCAhPSAndW5kZWZpbmVkJylcclxuICAgICAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBcIk5vIFNNUyBjcmVhZGl0XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIGVsc2VcclxuICAgICAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBcIkVycm9yIHByb2Nlc3NpbmcgcmVxdWVzdFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuQ29uZmlybWVkU2VuZCA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgc3dpdGNoIChfZGF0YS5zdGF0dXMpIHtcclxuICAgICAgICAgICAgICAgICAgICBjYXNlIDE6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogX2RhdGEubWVzc2FnZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMDpcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuU2VsZWN0ZWRQcm92aWRlci52YWx1ZSA9PSAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoX2RhdGEuZXJyLmluZGV4T2YoXCJFUlJPUlwiKSA+IC0xICYmIF9kYXRhLmVyci5pbmRleE9mKFwiU0VOREVSX1BSRUZJWFwiKSA+IC0xKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiSW52YWxpZCBTZW5kZXIgUGhvbmUgTnVtYmVyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm9wZW5TbXNTZXR0aW5ncygpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmICh0aGlzLlNlbGVjdGVkUHJvdmlkZXIudmFsdWUgPT0gMikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogXCJVbmFibGUgVG8gU2VuZCBNZXNzYWdlXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZGF0YSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgICAgICwgZXJyPT4ge1xyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBlcnIuX2JvZHkgPT0gJ3N0cmluZycpIHtcclxuICAgICAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogSlNPTi5wYXJzZShlcnIuX2JvZHkpLmVycm9yLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBcIlVuYWJsZSB0byBjb25uZWN0IHRvIHRoZSBTZXJ2aWNlXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiU21zIHNlbmQgcmVzcG9uY2UgY29tcGxlYXRlZCFcIixcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICApXHJcbiAgICB9XHJcblxyXG5cclxuICAgIGFsbEJpbmQoKSB7XHJcbiAgICAgICAvLyBkZWJ1Z2dlcjtcclxuXHJcbiAgICAgICAgdGhpcy5TbXNQcm92aWRlciA9IFtcclxuICAgICAgICAgICAgeyBuYW1lOiBcIlNtcyAyIFlvdVwiLCB2YWx1ZTogMSB9LFxyXG4gICAgICAgICAgICB7IG5hbWU6IFwiMDE5IFNtc1wiLCB2YWx1ZTogMiB9XHJcbiAgICAgICAgXTtcclxuICAgICAgICB0aGlzLlNlbGVjdGVkUHJvdmlkZXIgPSB0aGlzLlNtc1Byb3ZpZGVyWzBdO1xyXG4gICAgICAgIC8vYWxlcnQodGhpcy5fYW1heFNlcnZpY2UuR2V0R2VuZXJhbEdyb3VwVHJlZSgwKSk7XHJcbiAgICAgICAgLy90aGlzLmJpbmRHZW5lcmFsR3JvdXBUcmVlKHRoaXMuX2FtYXhTZXJ2aWNlLkdldEdlbmVyYWxHcm91cFRyZWUoMCkpO1xyXG5cclxuICAgICAgICB0aGlzLl9hbWF4U2VydmljZS5HZXRHZW5lcmFsR3JvdXBUcmVlKCkuc3Vic2NyaWJlKFxuXG4gICAgICAgICAgICAoZGF0YSkgPT4ge1xuICAgICAgICAgICAgICAgIHZhciByZXMgPSBqUXVlcnkucGFyc2VKU09OKGRhdGEpO1xuXG4gICAgICAgICAgICAgICAgalF1ZXJ5KFwiI2dyb3VwVHJlZVwiKS5rZW5kb1RyZWVWaWV3KHtcbiAgICAgICAgICAgICAgICAgICAgbG9hZE9uRGVtYW5kOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICBjaGVja2JveGVzOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjaGVja0NoaWxkcmVuOiB0cnVlXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIC8vY2hlY2s6IHRoaXMub25Hcm91cFNlbGVjdCxcbiAgICAgICAgICAgICAgICAgICAgZGF0YVNvdXJjZTogcmVzLkRhdGEua2VuZG9UcmVlXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgalF1ZXJ5KFwiI3NlbmRMYXRlckRhdGVcIikua2VuZG9EYXRlUGlja2VyKHtcclxuICAgICAgICAgICAgICAgICAgICBmb3JtYXQ6IFwiZGQtTU0teXl5eVwiXHJcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAoZXJyKSA9PiB7XG5cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAoKSA9PiB7XG5cbiAgICAgICAgICAgIH1cblxuICAgICAgICApO1xyXG4gICAgICAgIC8valF1ZXJ5KFwiI3NlbmRMYXRlckRhdGVcIikua2VuZG9EYXRlUGlja2VyKHtcclxuICAgICAgICAvLyAgICBmb3JtYXQ6IFwiZGQtTU0teXl5eVwiXHJcbiAgICAgICAgLy99KTtcclxuXHJcblxyXG4gICAgICAgIC8vdGhpcy5iaW5kUGhvbmVUeXBlTGlzdCh0aGlzLl9yZXNvdXJjZVNlcnZpY2UuR2V0TG9jYWxTdG9yYWdlKFwiQ2VsbFBob25lVHlwZUxpc3RcIikpO1xyXG4gICAgICAgIC8vdGhpcy5zZXRTbXNDb21wYW55TGlzdCh0aGlzLl9yZXNvdXJjZVNlcnZpY2UuR2V0TG9jYWxTdG9yYWdlKFwiU21zQ29tcGFueUxpc3RcIikpO1xyXG4gICAgICAgIHRoaXMuX2FtYXhTZXJ2aWNlLkdldERhdGFGcm9tU2VydmVyKHtcbiAgICAgICAgICAgIFNtc0NvbXBhbnlMaXN0OiB7XG4gICAgICAgICAgICAgICAgdXFlcnk6IGBcbiAgICAgICAgICAgICAgICAgICAgICAgIFNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVzZXJzbXMgQVMgVXNlck5hbWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFzc3dvcmRzbXMgQVMgVmFsdWVcbiAgICAgICAgICAgICAgICAgICAgICAgIGZyb21cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBBcHBsaWNhdGlvbkluZm9cbiAgICAgICAgICAgICAgICAgICAgYCxcbiAgICAgICAgICAgICAgICBwYXJhbWV0ZXJzOiB7fVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIFBob25lVHlwZUxpc3Q6IHtcbiAgICAgICAgICAgICAgICB1cWVyeTogXCJTRUxFQ1QgaWQgQVMgVmFsdWUsIGNvbnRlbnRIZWIrJyAoJysgY29udGVudGVuZyArJyknIEFTIExhYmVsIEZST00gUGhvbmVUeXBlc1wiLFxuICAgICAgICAgICAgICAgIHBhcmFtZXRlcnM6IHt9XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pLnN1YnNjcmliZShcbiAgICAgICAgICAgIChkYXRhKSA9PiB7XG5cbiAgICAgICAgICAgICAgICAvL2RlYnVnZ2VyO1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGRhdGEpO1xuICAgICAgICAgICAgICAgIHZhciByZXMgPSBqUXVlcnkucGFyc2VKU09OKGRhdGEpO1xuXG4gICAgICAgICAgICAgICAgdGhpcy5TbXNEYXRhID0gcmVzLkRhdGEuZGF0YS5TbXNDb21wYW55TGlzdDtcbiAgICAgICAgICAgICAgICB0aGlzLlBob25lVHlwZUxpc3REYXRhID0gcmVzLkRhdGEuZGF0YS5QaG9uZVR5cGVMaXN0O1xuICAgICAgICAgICAgICAgIHZhciBwaG9uZXR5cGVpZCA9IFwiXCI7XG4gICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5QaG9uZVR5cGVMaXN0RGF0YSwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBwaG9uZXR5cGVpZCA9IHRoaXMuTGFiZWw7XG5cbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIC8valF1ZXJ5KFwiI1Bob250VHlwZXNlbFwiKS5hdHRyKFwic2VsZWN0ZWR2YWxcIiwgcGhvbmV0eXBlaWQpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIChlcnJvcikgPT4geyB9LFxuICAgICAgICAgICAgKCkgPT4geyB9XG4gICAgICAgICAgICApO1xyXG5cclxuICAgIH1cclxuICAgIFxyXG4gICAgLy9uZ09uSW5pdCgpIHtcclxuICAgIC8vICAgIGRlYnVnZ2VyO1xyXG4gICAgLy8gICAgYWxlcnQoJ2hlbGxvJyk7XHJcbiAgICAvLyAgICAvL2xvYWRpbmdMYW5ndWFnZSBzdGFydFxyXG4gICAgLy8gICAgdGhpcy5fYW1heENybVN5aW5jLm9uKCdsc3NldC4nICsgTG9jYWxEaWN0Lmxhbmd1YWdlUmVzb3VyY2UsIGRhdGE9PiB0aGlzLlJFUyA9IGRhdGFbXCJTQ1JFRU5fU01TXCJdKTtcclxuICAgIC8vICAgIHRoaXMuUkVTID0gdGhpcy5fYW1heENybVN5aW5jLmZldGNoTGFuZ3VhZ2VSZXNvdXJjZShcIlNDUkVFTl9TTVNcIik7XHJcbiAgICAvLyAgICBpZiAoIXRoaXMuUkVTKSB7XHJcbiAgICAvLyAgICAgICAgaWYgKCFsb2NhbFN0b3JhZ2UuZ2V0SXRlbShMb2NhbERpY3Quc2VsZWN0ZWRMYW5ndWFnZSkpIHtcclxuICAgIC8vICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oTG9jYWxEaWN0LnNlbGVjdGVkTGFuZ3VhZ2UsIGNybUNvbmZpZy5mYWxiYWNrTGFuZ3VhZ2UpO1xyXG4gICAgLy8gICAgICAgIH1cclxuICAgIC8vICAgICAgICB0aGlzLl9hbWF4Q3JtU3lpbmMubG9hZExhbmd1YWdlUmVzb3VyY2UobG9jYWxTdG9yYWdlLmdldEl0ZW0oTG9jYWxEaWN0LnNlbGVjdGVkTGFuZ3VhZ2UpKTtcclxuICAgIC8vICAgIH1cclxuICAgIC8vICAgIC8vbG9hZGluZ0xhbmd1YWdlIHN0YXJ0XHJcbiAgICAvLyAgICB0aGlzLmFsbEJpbmQoKTtcclxuICAgIC8vICAgIGFsZXJ0KCdCeWUnKTtcclxuICAgIC8vfVxyXG5cclxuXHJcblxyXG5cclxuXHJcblxyXG5cclxuXHJcblxyXG5cclxufVxyXG5cclxuXHJcblxyXG5cclxuIl19
