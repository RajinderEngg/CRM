System.register(['angular2/common', "../../services/ResourceService", "angular2/router", "angular2/core", "../../services/CustomerService", "../../services/ChargeCreditService", '../../autocomplete/autocomplete-container', '../../autocomplete/autocomplete.component'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var common_1, ResourceService_1, router_1, core_1, CustomerService_1, ChargeCreditService_1, autocomplete_container_1, autocomplete_component_1;
    var AUTOCOMPLETE_DIRECTIVES, AmaxTerminals;
    return {
        setters:[
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (ResourceService_1_1) {
                ResourceService_1 = ResourceService_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (CustomerService_1_1) {
                CustomerService_1 = CustomerService_1_1;
            },
            function (ChargeCreditService_1_1) {
                ChargeCreditService_1 = ChargeCreditService_1_1;
            },
            function (autocomplete_container_1_1) {
                autocomplete_container_1 = autocomplete_container_1_1;
            },
            function (autocomplete_component_1_1) {
                autocomplete_component_1 = autocomplete_component_1_1;
            }],
        execute: function() {
            exports_1("AUTOCOMPLETE_DIRECTIVES", AUTOCOMPLETE_DIRECTIVES = [autocomplete_component_1.Autocomplete, autocomplete_container_1.AutocompleteContainer]);
            AmaxTerminals = (function () {
                function AmaxTerminals(_resourceService, _customerService, _routeParams, _ChargeCreditService) {
                    this._resourceService = _resourceService;
                    this._customerService = _customerService;
                    this._routeParams = _routeParams;
                    this._ChargeCreditService = _ChargeCreditService;
                    this.modelInput = {};
                    this.RES = {};
                    this.Formtype = "TERMINAL_SCREEN";
                    this.Lang = "";
                    this.CustomerId = -1;
                    this.BaseAppUrl = "";
                    this._TerminalList = [];
                    this.TerminalNumber = "";
                    this.ChangeDialog = "";
                    this.CHANGEDIR = "";
                    this.RES.TERMINAL_SCREEN = {};
                    this.BaseAppUrl = _resourceService.AppUrl;
                    this.CustomerId = _routeParams.params.Id;
                }
                AmaxTerminals.prototype.BackPage = function () {
                    document.location = this.BaseAppUrl + "Customer/Add/" + this.CustomerId;
                };
                AmaxTerminals.prototype.NextPage = function () {
                    if (this.TerminalNumber != undefined && this.TerminalNumber != null && this.TerminalNumber != "") {
                        document.location = this.BaseAppUrl + "ChargeCredit/" + this.CustomerId + "/" + this.TerminalNumber;
                    }
                    else {
                        bootbox.alert({
                            message: 'Please select Terminal number first',
                            className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                    }
                };
                AmaxTerminals.prototype.ChangeTerminal = function (TerminalObj) {
                    this.TerminalNumber = TerminalObj.Value;
                };
                AmaxTerminals.prototype.ngOnInit = function () {
                    var _this = this;
                    if (localStorage.getItem("lang") == "") {
                        localStorage.setItem("lang", "en");
                    }
                    this.Lang = localStorage.getItem("lang");
                    this._resourceService.GetLangRes(this.Formtype, this.Lang).subscribe(function (response) {
                        //debugger;
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.RES = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //Terminals
                    this._customerService.CheckIsOpenCharge().subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._TerminalList = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxTerminals.$inject = ['$scope', '$location', '$anchorScroll'];
                AmaxTerminals = __decorate([
                    core_1.Component({
                        templateUrl: './app/amax/Charge_Credit/templates/Terminals.html',
                        directives: [common_1.NgSwitch, common_1.NgSwitchWhen, common_1.NgSwitchDefault, AUTOCOMPLETE_DIRECTIVES, common_1.CORE_DIRECTIVES, common_1.FORM_DIRECTIVES],
                        providers: [CustomerService_1.CustomerService, ResourceService_1.ResourceService, ChargeCreditService_1.ChargeCreditService]
                    }), 
                    __metadata('design:paramtypes', [ResourceService_1.ResourceService, CustomerService_1.CustomerService, router_1.RouteParams, ChargeCreditService_1.ChargeCreditService])
                ], AmaxTerminals);
                return AmaxTerminals;
            }());
            exports_1("AmaxTerminals", AmaxTerminals);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldi9hbWF4L0NoYXJnZV9DcmVkaXQvVGVybWluYWxzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7UUFXYSx1QkFBdUI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7WUFBdkIscUNBQUEsdUJBQXVCLEdBQUcsQ0FBQyxxQ0FBWSxFQUFFLDhDQUFxQixDQUFDLENBQUEsQ0FBQztZQVM3RTtnQkFhSSx1QkFBb0IsZ0JBQWlDLEVBQVUsZ0JBQWlDLEVBQVUsWUFBeUIsRUFBVSxvQkFBeUM7b0JBQWxLLHFCQUFnQixHQUFoQixnQkFBZ0IsQ0FBaUI7b0JBQVUscUJBQWdCLEdBQWhCLGdCQUFnQixDQUFpQjtvQkFBVSxpQkFBWSxHQUFaLFlBQVksQ0FBYTtvQkFBVSx5QkFBb0IsR0FBcEIsb0JBQW9CLENBQXFCO29CQVp0TCxlQUFVLEdBQUcsRUFBRSxDQUFDO29CQUNoQixRQUFHLEdBQVcsRUFBRSxDQUFDO29CQUNqQixhQUFRLEdBQVUsaUJBQWlCLENBQUM7b0JBQ3BDLFNBQUksR0FBVyxFQUFFLENBQUM7b0JBQ2xCLGVBQVUsR0FBVyxDQUFDLENBQUMsQ0FBQztvQkFFeEIsZUFBVSxHQUFXLEVBQUUsQ0FBQztvQkFDeEIsa0JBQWEsR0FBRyxFQUFFLENBQUM7b0JBQ25CLG1CQUFjLEdBQVcsRUFBRSxDQUFDO29CQUM1QixpQkFBWSxHQUFXLEVBQUUsQ0FBQztvQkFDMUIsY0FBUyxHQUFXLEVBQUUsQ0FBQztvQkFJbkIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLEdBQUcsRUFBRSxDQUFDO29CQUM5QixJQUFJLENBQUMsVUFBVSxHQUFHLGdCQUFnQixDQUFDLE1BQU0sQ0FBQztvQkFDMUMsSUFBSSxDQUFDLFVBQVUsR0FBRyxZQUFZLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztnQkFFN0MsQ0FBQztnQkFDRCxnQ0FBUSxHQUFSO29CQUNJLFFBQVEsQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLFVBQVUsR0FBRyxlQUFlLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQztnQkFDNUUsQ0FBQztnQkFDRCxnQ0FBUSxHQUFSO29CQUNJLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFjLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxjQUFjLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxjQUFjLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzt3QkFDL0YsUUFBUSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsVUFBVSxHQUFHLGVBQWUsR0FBRyxJQUFJLENBQUMsVUFBVSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDO29CQUN4RyxDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUNGLE9BQU8sQ0FBQyxLQUFLLENBQUM7NEJBQ1YsT0FBTyxFQUFFLHFDQUFxQzs0QkFDOUMsU0FBUyxFQUFFLElBQUksQ0FBQyxZQUFZOzRCQUM1QixPQUFPLEVBQUU7Z0NBQ0wsRUFBRSxFQUFFO29DQUNBLGNBQWM7b0NBQ2QsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO2lDQUM1Qjs2QkFDSjt5QkFDSixDQUFDLENBQUM7b0JBQ1AsQ0FBQztnQkFDTCxDQUFDO2dCQUNELHNDQUFjLEdBQWQsVUFBZSxXQUFXO29CQUN0QixJQUFJLENBQUMsY0FBYyxHQUFHLFdBQVcsQ0FBQyxLQUFLLENBQUM7Z0JBRTVDLENBQUM7Z0JBRUQsZ0NBQVEsR0FBUjtvQkFBQSxpQkF3REM7b0JBdkRHLEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzt3QkFDckMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUM7b0JBQ3ZDLENBQUM7b0JBQ0QsSUFBSSxDQUFDLElBQUksR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUkxQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7d0JBQ3pFLFdBQVc7d0JBQ1gsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLEdBQUcsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO3dCQUM3QixDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUdGLFdBQVc7b0JBQ1osSUFBSSxDQUFDLGdCQUFnQixDQUFDLGlCQUFpQixFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFDdkQsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLGFBQWEsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO3dCQUN2QyxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO2dCQUNQLENBQUM7Z0JBL0ZNLHFCQUFPLEdBQUcsQ0FBQyxRQUFRLEVBQUUsV0FBVyxFQUFFLGVBQWUsQ0FBQyxDQUFDO2dCQWI5RDtvQkFBQyxnQkFBUyxDQUFDO3dCQUVQLFdBQVcsRUFBRSxtREFBbUQ7d0JBQ2hFLFVBQVUsRUFBRSxDQUFDLGlCQUFRLEVBQUUscUJBQVksRUFBRSx3QkFBZSxFQUFFLHVCQUF1QixFQUFFLHdCQUFlLEVBQUUsd0JBQWUsQ0FBQzt3QkFDaEgsU0FBUyxFQUFFLENBQUMsaUNBQWUsRUFBRSxpQ0FBZSxFQUFFLHlDQUFtQixDQUFDO3FCQUNyRSxDQUFDOztpQ0FBQTtnQkF3R0Ysb0JBQUM7WUFBRCxDQXRHQSxBQXNHQyxJQUFBO1lBdEdELHlDQXNHQyxDQUFBIiwiZmlsZSI6ImRldi9hbWF4L0NoYXJnZV9DcmVkaXQvVGVybWluYWxzLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtOZ1N3aXRjaCwgTmdTd2l0Y2hXaGVuLCBOZ1N3aXRjaERlZmF1bHQsIENPUkVfRElSRUNUSVZFUywgRk9STV9ESVJFQ1RJVkVTfSBmcm9tICdhbmd1bGFyMi9jb21tb24nXHJcbmltcG9ydCB7UmVzb3VyY2VTZXJ2aWNlfSBmcm9tIFwiLi4vLi4vc2VydmljZXMvUmVzb3VyY2VTZXJ2aWNlXCI7XHJcbmltcG9ydCB7Um91dGVQYXJhbXN9IGZyb20gXCJhbmd1bGFyMi9yb3V0ZXJcIjtcclxuaW1wb3J0IHtDb21wb25lbnQsIE91dHB1dCwgSW5wdXQsIEV2ZW50RW1pdHRlciwgT25Jbml0fSBmcm9tIFwiYW5ndWxhcjIvY29yZVwiO1xyXG5pbXBvcnQge0N1c3RvbWVyU2VydmljZX0gZnJvbSBcIi4uLy4uL3NlcnZpY2VzL0N1c3RvbWVyU2VydmljZVwiO1xyXG5pbXBvcnQge0NoYXJnZUNyZWRpdFNlcnZpY2V9IGZyb20gXCIuLi8uLi9zZXJ2aWNlcy9DaGFyZ2VDcmVkaXRTZXJ2aWNlXCI7XHJcbmltcG9ydCB7IGpzb25RIH0gZnJvbSAnLi4vLi4vanNvblEnO1xyXG5pbXBvcnQge0dyb3VwRmlsdGVyUGlwZSwgR3JvdXBQYXJlbkZpbHRlclBpcGUsIEtlbmRvX3V0aWxpdHl9IGZyb20gXCIuLi8uLi9hbWF4VXRpbFwiO1xyXG5pbXBvcnQge0F1dG9jb21wbGV0ZUNvbnRhaW5lcn0gZnJvbSAnLi4vLi4vYXV0b2NvbXBsZXRlL2F1dG9jb21wbGV0ZS1jb250YWluZXInO1xyXG5pbXBvcnQge0F1dG9jb21wbGV0ZX0gZnJvbSAnLi4vLi4vYXV0b2NvbXBsZXRlL2F1dG9jb21wbGV0ZS5jb21wb25lbnQnO1xyXG5cclxuZXhwb3J0IGNvbnN0IEFVVE9DT01QTEVURV9ESVJFQ1RJVkVTID0gW0F1dG9jb21wbGV0ZSwgQXV0b2NvbXBsZXRlQ29udGFpbmVyXTtcclxuZGVjbGFyZSB2YXIgalF1ZXJ5O1xyXG5AQ29tcG9uZW50KHtcclxuXHJcbiAgICB0ZW1wbGF0ZVVybDogJy4vYXBwL2FtYXgvQ2hhcmdlX0NyZWRpdC90ZW1wbGF0ZXMvVGVybWluYWxzLmh0bWwnLFxyXG4gICAgZGlyZWN0aXZlczogW05nU3dpdGNoLCBOZ1N3aXRjaFdoZW4sIE5nU3dpdGNoRGVmYXVsdCwgQVVUT0NPTVBMRVRFX0RJUkVDVElWRVMsIENPUkVfRElSRUNUSVZFUywgRk9STV9ESVJFQ1RJVkVTXSxcclxuICAgIHByb3ZpZGVyczogW0N1c3RvbWVyU2VydmljZSwgUmVzb3VyY2VTZXJ2aWNlLCBDaGFyZ2VDcmVkaXRTZXJ2aWNlXVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEFtYXhUZXJtaW5hbHMgaW1wbGVtZW50cyBPbkluaXQge1xyXG4gICAgbW9kZWxJbnB1dCA9IHt9O1xyXG4gICAgUkVTOiBPYmplY3QgPSB7fTtcclxuICAgIEZvcm10eXBlOiBzdHJpbmcgPVwiVEVSTUlOQUxfU0NSRUVOXCI7XHJcbiAgICBMYW5nOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgQ3VzdG9tZXJJZDogbnVtYmVyID0gLTE7XHJcbiAgICBzdGF0aWMgJGluamVjdCA9IFsnJHNjb3BlJywgJyRsb2NhdGlvbicsICckYW5jaG9yU2Nyb2xsJ107XHJcbiAgICBCYXNlQXBwVXJsOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgX1Rlcm1pbmFsTGlzdCA9IFtdO1xyXG4gICAgVGVybWluYWxOdW1iZXI6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBDaGFuZ2VEaWFsb2c6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBDSEFOR0VESVI6IHN0cmluZyA9IFwiXCI7XHJcblxyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBfcmVzb3VyY2VTZXJ2aWNlOiBSZXNvdXJjZVNlcnZpY2UsIHByaXZhdGUgX2N1c3RvbWVyU2VydmljZTogQ3VzdG9tZXJTZXJ2aWNlLCBwcml2YXRlIF9yb3V0ZVBhcmFtczogUm91dGVQYXJhbXMsIHByaXZhdGUgX0NoYXJnZUNyZWRpdFNlcnZpY2U6IENoYXJnZUNyZWRpdFNlcnZpY2UpIHtcclxuICAgICAgICBcclxuICAgICAgICB0aGlzLlJFUy5URVJNSU5BTF9TQ1JFRU4gPSB7fTtcclxuICAgICAgICB0aGlzLkJhc2VBcHBVcmwgPSBfcmVzb3VyY2VTZXJ2aWNlLkFwcFVybDtcclxuICAgICAgICB0aGlzLkN1c3RvbWVySWQgPSBfcm91dGVQYXJhbXMucGFyYW1zLklkO1xyXG4gICAgICAgXHJcbiAgICB9XHJcbiAgICBCYWNrUGFnZSgpIHtcclxuICAgICAgICBkb2N1bWVudC5sb2NhdGlvbiA9IHRoaXMuQmFzZUFwcFVybCArIFwiQ3VzdG9tZXIvQWRkL1wiICsgdGhpcy5DdXN0b21lcklkO1xyXG4gICAgfVxyXG4gICAgTmV4dFBhZ2UoKSB7XHJcbiAgICAgICAgaWYgKHRoaXMuVGVybWluYWxOdW1iZXIgIT0gdW5kZWZpbmVkICYmIHRoaXMuVGVybWluYWxOdW1iZXIgIT0gbnVsbCAmJiB0aGlzLlRlcm1pbmFsTnVtYmVyICE9IFwiXCIpIHtcclxuICAgICAgICAgICAgZG9jdW1lbnQubG9jYXRpb24gPSB0aGlzLkJhc2VBcHBVcmwgKyBcIkNoYXJnZUNyZWRpdC9cIiArIHRoaXMuQ3VzdG9tZXJJZCArIFwiL1wiICsgdGhpcy5UZXJtaW5hbE51bWJlcjtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgbWVzc2FnZTogJ1BsZWFzZSBzZWxlY3QgVGVybWluYWwgbnVtYmVyIGZpcnN0JyxcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgQ2hhbmdlVGVybWluYWwoVGVybWluYWxPYmopIHtcclxuICAgICAgICB0aGlzLlRlcm1pbmFsTnVtYmVyID0gVGVybWluYWxPYmouVmFsdWU7XHJcbiAgICAgICAgXHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkluaXQoKSB7XHJcbiAgICAgICAgaWYgKGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwibGFuZ1wiKSA9PSBcIlwiKSB7XHJcbiAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwibGFuZ1wiLCBcImVuXCIpO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLkxhbmcgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImxhbmdcIik7XHJcbiAgICAgICAgXHJcbiAgICAgIFxyXG4gICAgICAgIFxyXG4gICAgICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLkdldExhbmdSZXModGhpcy5Gb3JtdHlwZSwgdGhpcy5MYW5nKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgIH1cclxuICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgdGhpcy5SRVMgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgIH1cclxuICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgIH0pOyAgICAgICAgICBcclxuXHJcbiAgICAgICBcclxuICAgICAgICAvL1Rlcm1pbmFsc1xyXG4gICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkNoZWNrSXNPcGVuQ2hhcmdlKCkuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9UZXJtaW5hbExpc3QgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==
