System.register(['angular2/common', "../../services/ResourceService", "angular2/router", "angular2/core", "../../services/CustomerService", "../../services/ChargeCreditService", '../../autocomplete/autocomplete-container', '../../autocomplete/autocomplete.component'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var common_1, ResourceService_1, router_1, core_1, CustomerService_1, ChargeCreditService_1, autocomplete_container_1, autocomplete_component_1;
    var AUTOCOMPLETE_DIRECTIVES, AmaxChargeCredit;
    return {
        setters:[
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (ResourceService_1_1) {
                ResourceService_1 = ResourceService_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (CustomerService_1_1) {
                CustomerService_1 = CustomerService_1_1;
            },
            function (ChargeCreditService_1_1) {
                ChargeCreditService_1 = ChargeCreditService_1_1;
            },
            function (autocomplete_container_1_1) {
                autocomplete_container_1 = autocomplete_container_1_1;
            },
            function (autocomplete_component_1_1) {
                autocomplete_component_1 = autocomplete_component_1_1;
            }],
        execute: function() {
            exports_1("AUTOCOMPLETE_DIRECTIVES", AUTOCOMPLETE_DIRECTIVES = [autocomplete_component_1.Autocomplete, autocomplete_container_1.AutocompleteContainer]);
            AmaxChargeCredit = (function () {
                function AmaxChargeCredit(_resourceService, _customerService, _routeParams, _ChargeCreditService) {
                    this._resourceService = _resourceService;
                    this._customerService = _customerService;
                    this._routeParams = _routeParams;
                    this._ChargeCreditService = _ChargeCreditService;
                    this.modelInput = {};
                    this.modelInputTemp = {};
                    this.RES = {};
                    this.Formtype = "CHARGECREDIT_SCREEN";
                    this.Lang = "";
                    this.CustomerId = -1;
                    this.BaseAppUrl = "";
                    this._TerminalList = [];
                    this.TerminalNumber = "";
                    this.RemPaymentsText = "";
                    this.NumOfPaymentsText = "";
                    this.Isbtndisable = "";
                    this.MsgClass = "";
                    this.ChangeDialog = "";
                    this.CHANGEDIR = "";
                    this.IsCreditCancel = false;
                    this.IsCreditNoOfPay = false;
                    this.Installments = 0;
                    this.InstallmentPay = 0;
                    this.isfindcreditCardOwnerID = true;
                    this.PrintUrl = "https://secure.cardcom.co.il/Note/ProgramNote.aspx"; /*?DealNumber=" + oDealNumber + "&DisplayData=3&Termianl=" + oTermianl + "&DefPrint=false";*/
                    this._Mnths = [];
                    this._Years = [];
                    this._ChargeTypes = [];
                    this._Currency = [];
                    this._CreditTypes = [];
                    this.RES.CHARGECREDIT_SCREEN = {};
                    this.BaseAppUrl = _resourceService.AppUrl;
                    this.modelInput.CustomerId = _routeParams.params.Id;
                    this.modelInput.oTerminalNumber = _routeParams.params.TermNo;
                    this.modelInput.oCurrency = "Nis";
                    this.modelInput.ChargeType = "0";
                    // this.OpenDiv();
                    this.modelInput.CreditType = "0";
                    //this.modelInputTemp.DealNumber = "test";
                    //this.modelInputTemp.oTerminalNumber = "test";
                    //    modelInput.oCurrency        
                }
                AmaxChargeCredit.prototype.ChangeOwnerId = function () {
                    this.isfindcreditCardOwnerID = false;
                };
                AmaxChargeCredit.prototype.CalculateConstPay = function () {
                    if (this.modelInput.oSumToBill != undefined && this.modelInput.oSumToBill != null && this.modelInput.oSumToBill != ""
                        && this.modelInput.ofirstpaymentsum != undefined && this.modelInput.ofirstpaymentsum != null && this.modelInput.ofirstpaymentsum != ""
                        && this.modelInput.oNumOfPayments != undefined && this.modelInput.oNumOfPayments != null && this.modelInput.oNumOfPayments != "") {
                        var RemAmt = parseFloat(this.modelInput.oSumToBill) - parseFloat(this.modelInput.ofirstpaymentsum);
                        if (RemAmt >= 0) {
                            if (parseInt(this.modelInput.oNumOfPayments) == 1) {
                                if (RemAmt > 0) {
                                    bootbox.alert({
                                        message: "Please give full amount in first payment or increase th no of payments",
                                        className: this.ChangeDialog,
                                        buttons: {
                                            ok: {
                                                //label: 'Ok',
                                                className: this.CHANGEDIR
                                            }
                                        }
                                    });
                                }
                                else {
                                    this.NumOfPaymentsText = this.modelInput.oNumOfPayments + " payments, first payment: " + this.modelInput.ofirstpaymentsum;
                                    this.RemPaymentsText = this.modelInput.ofirstpaymentsum + " and 0 payments of 0";
                                }
                            }
                            else if (parseInt(this.modelInput.oNumOfPayments) > 1) {
                                //debugger;
                                this.InstallmentPay = parseFloat(RemAmt / parseFloat(this.modelInput.oNumOfPayments - 1));
                                this.modelInput.oconstpatment = this.InstallmentPay;
                                this.NumOfPaymentsText = this.modelInput.oNumOfPayments + " payments, first payment: " + this.modelInput.ofirstpaymentsum;
                                this.RemPaymentsText = this.modelInput.ofirstpaymentsum + " and " + parseFloat(this.modelInput.oNumOfPayments - 1) + " payments of " +
                                    this.InstallmentPay.toFixed(2);
                                this.modelInput.oNumOfPayments = parseFloat(this.modelInput.oNumOfPayments) + 1;
                            }
                        }
                    }
                };
                AmaxChargeCredit.prototype.ChangeCreditType = function (obj) {
                    this.modelInput.CreditType = obj.Value;
                    if (obj.Value != 0) {
                        this.IsCreditNoOfPay = true;
                    }
                    else {
                        this.IsCreditNoOfPay = false;
                    }
                    this.modelInput.ofirstpaymentsum = "";
                    this.modelInput.oNumOfPayments = "";
                    this.NumOfPaymentsText = "";
                    this.RemPaymentsText;
                };
                AmaxChargeCredit.prototype.OpenDiv = function () {
                    var savetext = "";
                    this.modelInput.ChargeType = jQuery("#Chargetype").val();
                    //debugger;
                    var chrgtype = this.modelInput.ChargeType;
                    jQuery.each(this._ChargeTypes, function () {
                        if (this.Value == chrgtype) {
                            savetext = this.Text;
                            return false;
                        }
                    });
                    this.SAVE_BTN_TEXT = savetext;
                    if (this.modelInput.ChargeType != "0") {
                        this.IsCreditCancel = true;
                    }
                    else if (this.modelInput.ChargeType == "0") {
                        this.IsCreditCancel = false;
                    }
                    this.modelInput.ouserpassword = "";
                };
                AmaxChargeCredit.prototype.CheckCreditCardDet = function () {
                    var _this = this;
                    if (jQuery("input:checked").val() != undefined && jQuery("input:checked").val() != null) {
                        if (this.modelInput.UseToken != undefined && this.modelInput.UseToken != null) { }
                        else {
                            this.modelInput.UseToken = false;
                        }
                        this.modelInput.CompanySlika = "1";
                        if (this.modelInput.CreditType == "0") {
                            this.modelInput.oNumOfPayments = "1";
                        }
                        else {
                            if (this.modelInput.oNumOfPayments != undefined && this.modelInput.oNumOfPayments != null) {
                                if (this.modelInput.oNumOfPayments != "") {
                                    this.modelInput.oNumOfPayments = parseInt(this.modelInput.oNumOfPayments + 1);
                                }
                                else {
                                    this.modelInput.oNumOfPayments = "1";
                                }
                            }
                        }
                        if (this.modelInput.ChargeType == "0") {
                            this.modelInput.odealtype = "1";
                        }
                        else if (this.modelInput.ChargeType == "1") {
                            this.modelInput.odealtype = "51";
                        }
                        else if (this.modelInput.ChargeType == "2") {
                            this.modelInput.odealtype = "52";
                        }
                        if (this.modelInput.odealtype == "1") {
                            //swal({
                            //    title: "Are you sure?",
                            //    text: "Note that you requested charge the customer, will continue!",
                            //    type: "warning",
                            //    showCancelButton: true,
                            //    confirmButtonColor: "#DD6B55",
                            //    confirmButtonText: "Yes",
                            //    cancelButtonText: "No",
                            //    closeOnConfirm: false,
                            //    closeOnCancel: false
                            //},
                            //    function (isConfirm) {
                            //        if (isConfirm) {
                            //        }
                            //        else {
                            //            return false;
                            //        }
                            //    });
                            //bootbox.confirm({
                            //    message: "Note that you requested charge the customer, will continue?",
                            //    buttons: {
                            //        confirm: {
                            //            label: 'Yes',
                            //            className: 'btn-success'
                            //        },
                            //        cancel: {
                            //            label: 'No',
                            //            className: 'btn-danger'
                            //        }
                            //    },
                            //    callback: function (result) {
                            //        if (result == false) {
                            //            return false;
                            //        }
                            //        //console.log('This was logged in the callback: ' + result);
                            //    }
                            //});
                            if (confirm("Note that you requested charge the customer, will continue?") == true) { }
                            else {
                                return false;
                            }
                        }
                        var IsInsert = "";
                        this._ChargeCreditService.IsInsertTotblLastUpdate(this.modelInput.CustomerId).subscribe(function (resp) {
                            var response = jQuery.parseJSON(resp);
                            if (response.IsError == true) {
                                bootbox.alert({
                                    message: response.ErrMsg,
                                    className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                            else {
                                IsInsert = response.Data;
                                if (IsInsert.length > 0) {
                                    //swal({
                                    //    title: "Are you sure?",
                                    //    text: IsInsert,
                                    //    type: "warning",
                                    //    showCancelButton: true,
                                    //    confirmButtonColor: "#DD6B55",
                                    //    confirmButtonText: "Yes",
                                    //    cancelButtonText: "No",
                                    //    closeOnConfirm: false,
                                    //    closeOnCancel: false
                                    //},
                                    //    function (isConfirm) {
                                    //        if (isConfirm) {
                                    //            this._ChargeCreditService.InsertTotblLastUpdate(this.modelInput.CustomerId, this.modelInput.oSumToBill).subscribe(resp=> {
                                    //                var response1 = jQuery.parseJSON(resp);
                                    //                if (response1.IsError == true) {
                                    //                    swal(response1.ErrMsg);
                                    //                }
                                    //                else {
                                    //                }
                                    //            }, error=> {
                                    //                console.log(error);
                                    //            }, () => {
                                    //                console.log("CallCompleted")
                                    //            });
                                    //        }
                                    //        else {
                                    //            return false;
                                    //        }
                                    //    });
                                    if (confirm(IsInsert) == true) {
                                        _this._ChargeCreditService.InsertTotblLastUpdate(_this.modelInput.CustomerId, _this.modelInput.oSumToBill).subscribe(function (resp) {
                                            var response1 = jQuery.parseJSON(resp);
                                            if (response1.IsError == true) {
                                                bootbox.alert({
                                                    message: response1.ErrMsg,
                                                    className: _this.ChangeDialog,
                                                    buttons: {
                                                        ok: {
                                                            //label: 'Ok',
                                                            className: _this.CHANGEDIR
                                                        }
                                                    }
                                                });
                                            }
                                            else {
                                            }
                                        }, function (error) {
                                            console.log(error);
                                        }, function () {
                                            console.log("CallCompleted");
                                        });
                                    }
                                    else {
                                        return false;
                                    }
                                }
                            }
                        }, function (error) {
                            console.log(error);
                        }, function () {
                            console.log("CallCompleted");
                        });
                        if (this.isfindcreditCardOwnerID == false) {
                            //swal({
                            //    title: "Are you sure?",
                            //    text: "You want to update a customer ID card!",
                            //    type: "warning",
                            //    showCancelButton: true,
                            //    confirmButtonColor: "#DD6B55",
                            //    confirmButtonText: "Yes",
                            //    cancelButtonText: "No",
                            //    closeOnConfirm: false,
                            //    closeOnCancel: false
                            //},
                            //    function (isConfirm) {
                            //        if (isConfirm) {
                            //            this._ChargeCreditService.UpdateOwnerId(this.modelInput.CustomerId, this.modelInput.oCardOwnerId).subscribe(resp=> {
                            //                var response = jQuery.parseJSON(resp);
                            //                if (response.IsError == true) {
                            //                    swal(response.ErrMsg);
                            //                }
                            //                else {
                            //                }
                            //            }, error=> {
                            //                console.log(error);
                            //            }, () => {
                            //                console.log("CallCompleted")
                            //            });
                            //        }
                            //        else {
                            //            return false;
                            //        }
                            //    });
                            if (confirm("You want to update a customer ID card?") == true) {
                                this._ChargeCreditService.UpdateOwnerId(this.modelInput.CustomerId, this.modelInput.oCardOwnerId).subscribe(function (resp) {
                                    var response = jQuery.parseJSON(resp);
                                    if (response.IsError == true) {
                                        bootbox.alert({
                                            message: response.ErrMsg,
                                            className: _this.ChangeDialog,
                                            buttons: {
                                                ok: {
                                                    //label: 'Ok',
                                                    className: _this.CHANGEDIR
                                                }
                                            }
                                        });
                                    }
                                    else {
                                    }
                                }, function (error) {
                                    console.log(error);
                                }, function () {
                                    console.log("CallCompleted");
                                });
                            }
                            else {
                                return false;
                            }
                        }
                        var jdata = JSON.stringify(this.modelInput);
                        this._ChargeCreditService.Save(jdata).subscribe(function (resp) {
                            var response = jQuery.parseJSON(resp);
                            if (response.IsError == true) {
                                bootbox.alert({
                                    message: response.ErrMsg,
                                    className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                            else {
                                bootbox.alert({
                                    message: response.ErrMsg,
                                    className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        }
                                    }
                                });
                                // document.location = this.BaseAppUrl + "ChargeCredit/" + this.modelInput.CustomerId + "/" + this.modelInput.oTerminalNumber;
                                _this.modelInput.DealNumber = response.Data.DealNumber;
                                _this.modelInputTemp = _this.modelInput;
                                _this.modelInput = {};
                                _this.modelInput.oTerminalNumber = _this._routeParams.params.TermNo;
                                _this.modelInput.CustomerId = _this._routeParams.params.Id;
                                _this.modelInput.oCurrency = "Nis";
                                _this.modelInput.ChargeType = "0";
                                _this._ChargeTypes = [];
                                _this._ChargeCreditService.BindChargeTypeList().subscribe(function (resp) {
                                    //debugger;
                                    var response = jQuery.parseJSON(resp);
                                    if (response.IsError == true) {
                                        bootbox.alert({
                                            message: response.ErrMsg,
                                            className: _this.ChangeDialog,
                                            buttons: {
                                                ok: {
                                                    //label: 'Ok',
                                                    className: _this.CHANGEDIR
                                                }
                                            }
                                        });
                                    }
                                    else {
                                        _this._ChargeTypes = response.Data;
                                        var savetext = "";
                                        var chrgtype = _this.modelInput.ChargeType;
                                        jQuery.each(_this._ChargeTypes, function () {
                                            if (this.Value == chrgtype) {
                                                savetext = this.Text;
                                                return false;
                                            }
                                        });
                                        _this.SAVE_BTN_TEXT = savetext;
                                    }
                                }, function (error) {
                                    console.log(error);
                                }, function () {
                                    console.log("CallCompleted");
                                });
                                _this.modelInput.CreditType = "0";
                                _this._ChargeCreditService.BindTermDet(_this.modelInput.oTerminalNumber).subscribe(function (resp) {
                                    //debugger;
                                    var response = jQuery.parseJSON(resp);
                                    if (response.IsError == true) {
                                        bootbox.alert({
                                            message: response.ErrMsg,
                                            className: _this.ChangeDialog,
                                            buttons: {
                                                ok: {
                                                    //label: 'Ok',
                                                    className: _this.CHANGEDIR
                                                }
                                            }
                                        });
                                    }
                                    else {
                                        _this.modelInput.ousername = response.Data.instituteName;
                                    }
                                }, function (error) {
                                    console.log(error);
                                }, function () {
                                    console.log("CallCompleted");
                                });
                                _this._customerService.GetCompleteCustDet(_this.modelInput.CustomerId).subscribe(function (resp) {
                                    //debugger;
                                    var response = jQuery.parseJSON(resp);
                                    if (response.IsError == true) {
                                        bootbox.alert({
                                            message: response.ErrMsg,
                                            className: _this.ChangeDialog,
                                            buttons: {
                                                ok: {
                                                    //label: 'Ok',
                                                    className: _this.CHANGEDIR
                                                }
                                            }
                                        });
                                    }
                                    else {
                                        _this.modelInput.CustomerName = response.Data.fname + " " + response.Data.lname;
                                        _this.modelInput.oCardOwnerId = response.Data.CustomerCode;
                                    }
                                }, function (error) {
                                    console.log(error);
                                }, function () {
                                    console.log("CallCompleted");
                                });
                                //debugger;
                                //var PrintUrl = this.PrintUrl + "?DealNumber=" + response.Data.DealNumber +
                                //    "&DisplayData=3&Termianl=" + this.modelInput.oTerminalNumber +
                                //    "&DefPrint=false";
                                _this.PrintData(response.Data.DealNumber, _this.modelInput.oTerminalNumber);
                            }
                        }, function (error) {
                            console.log(error);
                        }, function () {
                            console.log("CallCompleted");
                        });
                    }
                    else {
                        bootbox.alert({
                            message: 'Please select credit type',
                            className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                    }
                };
                AmaxChargeCredit.prototype.ClearCardNo = function () {
                    this.modelInput.oCardNumber = "";
                };
                AmaxChargeCredit.prototype.PrintPrevData = function () {
                    //debugger;
                    if (this.modelInputTemp.DealNumber != undefined && this.modelInputTemp.DealNumber != null
                        && this.modelInputTemp.oTerminalNumber != undefined && this.modelInputTemp.oTerminalNumber != null) {
                        this.PrintData(this.modelInputTemp.DealNumber, this.modelInputTemp.oTerminalNumber);
                    }
                    else {
                        bootbox.alert({
                            message: "Please do any transection and then click on print button",
                            className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                    }
                };
                AmaxChargeCredit.prototype.CancelBtn = function () {
                    document.location = this.BaseAppUrl + "Customer/Add/" + this._routeParams.params.Id;
                };
                AmaxChargeCredit.prototype.PrintData = function (DealNumber, Terminal) {
                    var _this = this;
                    var PrintData = "";
                    this._ChargeCreditService.getPrint(DealNumber, Terminal).subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            PrintData = response.Data;
                            //var OpenWindow = window.open("");
                            var windowObject = window.open('', 'Print', 'scrollbars=yes,resizable=yes,width=1050,height=650');
                            windowObject.document.write(PrintData);
                            windowObject.document.close();
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxChargeCredit.prototype.OpenNewReceipt = function () {
                    if (this.modelInput != undefined) {
                        var emid = localStorage.getItem("employeeid");
                        document.location = this.BaseAppUrl + "ReceiptSelect/" + emid;
                    }
                };
                AmaxChargeCredit.prototype.ngOnInit = function () {
                    var _this = this;
                    if (localStorage.getItem("lang") == "") {
                        localStorage.setItem("lang", "en");
                    }
                    this.Lang = localStorage.getItem("lang");
                    this._resourceService.GetLangRes(this.Formtype, this.Lang).subscribe(function (response) {
                        //debugger;
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.RES = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._ChargeCreditService.BindTermDet(this.modelInput.oTerminalNumber).subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.modelInput.ousername = response.Data.instituteName;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._customerService.GetCompleteCustDet(this.modelInput.CustomerId).subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.modelInput.CustomerName = response.Data.fname + " " + response.Data.lname;
                            _this.modelInput.oCardOwnerId = response.Data.CustomerCode;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._ChargeCreditService.BindCurrencyList().subscribe(function (resp) {
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Currency = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._ChargeCreditService.BindCreditTypeList().subscribe(function (resp) {
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            //debugger;
                            _this._CreditTypes = response.Data;
                            var rbid = "#" + _this.modelInput.CreditType.toString();
                            jQuery(rbid).prop("checked", true);
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._ChargeCreditService.BindChargeTypeList().subscribe(function (resp) {
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._ChargeTypes = response.Data;
                            var savetext = "";
                            var chrgtype = _this.modelInput.ChargeType;
                            jQuery.each(_this._ChargeTypes, function () {
                                if (this.Value == chrgtype) {
                                    savetext = this.Text;
                                    return false;
                                }
                            });
                            _this.SAVE_BTN_TEXT = savetext;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._ChargeCreditService.BindYears().subscribe(function (resp) {
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Years = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._ChargeCreditService.BindMonths().subscribe(function (resp) {
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Mnths = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    window.setTimeout(function () { $("[name='CreditType']:first").attr("checked", true); }, 1000);
                };
                AmaxChargeCredit.$inject = ['$scope', '$location', '$anchorScroll'];
                AmaxChargeCredit = __decorate([
                    core_1.Component({
                        templateUrl: './app/amax/Charge_Credit/templates/ChargeCredit.html',
                        directives: [common_1.NgSwitch, common_1.NgSwitchWhen, common_1.NgSwitchDefault, AUTOCOMPLETE_DIRECTIVES, common_1.CORE_DIRECTIVES, common_1.FORM_DIRECTIVES],
                        providers: [CustomerService_1.CustomerService, ResourceService_1.ResourceService, ChargeCreditService_1.ChargeCreditService]
                    }), 
                    __metadata('design:paramtypes', [ResourceService_1.ResourceService, CustomerService_1.CustomerService, router_1.RouteParams, ChargeCreditService_1.ChargeCreditService])
                ], AmaxChargeCredit);
                return AmaxChargeCredit;
            }());
            exports_1("AmaxChargeCredit", AmaxChargeCredit);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldi9hbWF4L0NoYXJnZV9DcmVkaXQvQ2hhcmdlQ3JlZGl0Q2FyZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7O1FBV2EsdUJBQXVCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1lBQXZCLHFDQUFBLHVCQUF1QixHQUFHLENBQUMscUNBQVksRUFBRSw4Q0FBcUIsQ0FBQyxDQUFBLENBQUM7WUFTN0U7Z0JBK0JJLDBCQUFvQixnQkFBaUMsRUFBVSxnQkFBaUMsRUFBVSxZQUF5QixFQUFVLG9CQUF5QztvQkFBbEsscUJBQWdCLEdBQWhCLGdCQUFnQixDQUFpQjtvQkFBVSxxQkFBZ0IsR0FBaEIsZ0JBQWdCLENBQWlCO29CQUFVLGlCQUFZLEdBQVosWUFBWSxDQUFhO29CQUFVLHlCQUFvQixHQUFwQixvQkFBb0IsQ0FBcUI7b0JBOUJ0TCxlQUFVLEdBQUcsRUFBRSxDQUFDO29CQUNoQixtQkFBYyxHQUFHLEVBQUUsQ0FBQztvQkFDcEIsUUFBRyxHQUFXLEVBQUUsQ0FBQztvQkFDakIsYUFBUSxHQUFVLHFCQUFxQixDQUFDO29CQUN4QyxTQUFJLEdBQVcsRUFBRSxDQUFDO29CQUNsQixlQUFVLEdBQVcsQ0FBQyxDQUFDLENBQUM7b0JBRXhCLGVBQVUsR0FBVyxFQUFFLENBQUM7b0JBQ3hCLGtCQUFhLEdBQUcsRUFBRSxDQUFDO29CQUNuQixtQkFBYyxHQUFXLEVBQUUsQ0FBQztvQkFDNUIsb0JBQWUsR0FBVyxFQUFFLENBQUM7b0JBQzdCLHNCQUFpQixHQUFXLEVBQUUsQ0FBQztvQkFDL0IsaUJBQVksR0FBVyxFQUFFLENBQUM7b0JBQzFCLGFBQVEsR0FBVyxFQUFFLENBQUM7b0JBQ3RCLGlCQUFZLEdBQVcsRUFBRSxDQUFDO29CQUMxQixjQUFTLEdBQVcsRUFBRSxDQUFDO29CQUd2QixtQkFBYyxHQUFZLEtBQUssQ0FBQztvQkFDaEMsb0JBQWUsR0FBWSxLQUFLLENBQUM7b0JBQ2pDLGlCQUFZLEdBQUssQ0FBQyxDQUFDO29CQUNuQixtQkFBYyxHQUFRLENBQUMsQ0FBQztvQkFDeEIsNEJBQXVCLEdBQVksSUFBSSxDQUFDO29CQUN4QyxhQUFRLEdBQVcsb0RBQW9ELENBQUMsQ0FBQSw2RkFBNkY7b0JBQ3JLLFdBQU0sR0FBRyxFQUFFLENBQUM7b0JBQ1osV0FBTSxHQUFHLEVBQUUsQ0FBQztvQkFDWixpQkFBWSxHQUFHLEVBQUUsQ0FBQztvQkFDbEIsY0FBUyxHQUFHLEVBQUUsQ0FBQztvQkFDZixpQkFBWSxHQUFHLEVBQUUsQ0FBQztvQkFJZCxJQUFJLENBQUMsR0FBRyxDQUFDLG1CQUFtQixHQUFHLEVBQUUsQ0FBQztvQkFDbEMsSUFBSSxDQUFDLFVBQVUsR0FBRyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUM7b0JBQzFDLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLFlBQVksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO29CQUNwRCxJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsR0FBRyxZQUFZLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztvQkFFN0QsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEdBQUcsS0FBSyxDQUFDO29CQUNsQyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBRyxHQUFHLENBQUM7b0JBQ2xDLGtCQUFrQjtvQkFDakIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsR0FBRyxDQUFDO29CQUNqQywwQ0FBMEM7b0JBQzFDLCtDQUErQztvQkFDbkQsa0NBQWtDO2dCQUNsQyxDQUFDO2dCQUNELHdDQUFhLEdBQWI7b0JBQ0ksSUFBSSxDQUFDLHVCQUF1QixHQUFHLEtBQUssQ0FBQztnQkFDekMsQ0FBQztnQkFDRCw0Q0FBaUIsR0FBakI7b0JBQ0ksRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxFQUFFOzJCQUM5RyxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixJQUFJLEVBQUU7MkJBQ25JLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzt3QkFDbkksSUFBSSxNQUFNLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLENBQUMsQ0FBQzt3QkFDbkcsRUFBRSxDQUFDLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7NEJBQ2QsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDaEQsRUFBRSxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7b0NBQ2IsT0FBTyxDQUFDLEtBQUssQ0FBQzt3Q0FDVixPQUFPLEVBQUUsd0VBQXdFO3dDQUNqRixTQUFTLEVBQUUsSUFBSSxDQUFDLFlBQVk7d0NBQzVCLE9BQU8sRUFBRTs0Q0FDTCxFQUFFLEVBQUU7Z0RBQ0EsY0FBYztnREFDZCxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVM7NkNBQzVCO3lDQUNKO3FDQUNKLENBQUMsQ0FBQztnQ0FDUCxDQUFDO2dDQUNELElBQUksQ0FBQyxDQUFDO29DQUNGLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyw0QkFBNEIsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixDQUFDO29DQUMxSCxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLEdBQUMsc0JBQXNCLENBQUM7Z0NBQ25GLENBQUM7NEJBQ0wsQ0FBQzs0QkFDRCxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDcEQsV0FBVztnQ0FDWCxJQUFJLENBQUMsY0FBYyxHQUFHLFVBQVUsQ0FBQyxNQUFNLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQzFGLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUM7Z0NBRXBELElBQUksQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyw0QkFBNEIsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixDQUFDO2dDQUMxSCxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLEdBQUcsT0FBTyxHQUFHLFVBQVUsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxDQUFDLENBQUMsR0FBRyxlQUFlO29DQUNoSSxJQUFJLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDbkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxDQUFDOzRCQUVwRixDQUFDO3dCQUNMLENBQUM7b0JBQ0wsQ0FBQztnQkFDTCxDQUFDO2dCQUNELDJDQUFnQixHQUFoQixVQUFpQixHQUFHO29CQUVoQixJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDO29CQUN2QyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ2pCLElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDO29CQUNoQyxDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUNGLElBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSyxDQUFDO29CQUVqQyxDQUFDO29CQUNELElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLEdBQUcsRUFBRSxDQUFDO29CQUN0QyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxFQUFFLENBQUM7b0JBQ3BDLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxFQUFFLENBQUM7b0JBQzVCLElBQUksQ0FBQyxlQUFlLENBQUM7Z0JBQ3pCLENBQUM7Z0JBQ0Qsa0NBQU8sR0FBUDtvQkFDSSxJQUFJLFFBQVEsR0FBRyxFQUFFLENBQUM7b0JBQ2xCLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQztvQkFDekQsV0FBVztvQkFDWCxJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQztvQkFDMUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFO3dCQUUzQixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxJQUFJLFFBQVEsQ0FBQyxDQUFDLENBQUM7NEJBRXpCLFFBQVEsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDOzRCQUNyQixNQUFNLENBQUMsS0FBSyxDQUFDO3dCQUNqQixDQUFDO29CQUNMLENBQUMsQ0FBQyxDQUFDO29CQUNILElBQUksQ0FBQyxhQUFhLEdBQUcsUUFBUSxDQUFDO29CQUM5QixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxHQUFHLENBQUMsQ0FBQyxDQUFDO3dCQUNwQyxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQztvQkFDL0IsQ0FBQztvQkFDRCxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksR0FBRyxDQUFDLENBQUMsQ0FBQzt3QkFDekMsSUFBSSxDQUFDLGNBQWMsR0FBRyxLQUFLLENBQUM7b0JBR2hDLENBQUM7b0JBQ0QsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEdBQUcsRUFBRSxDQUFDO2dCQUN2QyxDQUFDO2dCQUNELDZDQUFrQixHQUFsQjtvQkFBQSxpQkF1WEM7b0JBdFhHLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsQ0FBQyxHQUFHLEVBQUUsSUFBSSxTQUFTLElBQUksTUFBTSxDQUFDLGVBQWUsQ0FBQyxDQUFDLEdBQUcsRUFBRSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7d0JBQ3RGLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFBQyxJQUFJLENBQUMsQ0FBQzs0QkFDckYsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO3dCQUNyQyxDQUFDO3dCQUNELElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxHQUFHLEdBQUcsQ0FBQzt3QkFFbkMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksR0FBRyxDQUFDLENBQUMsQ0FBQzs0QkFDcEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsR0FBRyxDQUFDO3dCQUV6QyxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO2dDQUN4RixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO29DQUN2QyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsQ0FBQyxDQUFDLENBQUM7Z0NBQ2xGLENBQUM7Z0NBQ0QsSUFBSSxDQUFDLENBQUM7b0NBQ0YsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsR0FBRyxDQUFDO2dDQUN6QyxDQUFDOzRCQUNMLENBQUM7d0JBQ0wsQ0FBQzt3QkFDRCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxHQUFHLENBQUMsQ0FBQyxDQUFDOzRCQUNwQyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsR0FBRyxHQUFHLENBQUM7d0JBQ3BDLENBQUM7d0JBQ0QsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLEdBQUcsQ0FBQyxDQUFDLENBQUM7NEJBQ3pDLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQzt3QkFDckMsQ0FBQzt3QkFDRCxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksR0FBRyxDQUFDLENBQUMsQ0FBQzs0QkFDekMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDO3dCQUNyQyxDQUFDO3dCQUNELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxJQUFJLEdBQUcsQ0FBQyxDQUFDLENBQUM7NEJBQ25DLFFBQVE7NEJBQ1IsNkJBQTZCOzRCQUM3QiwwRUFBMEU7NEJBQzFFLHNCQUFzQjs0QkFDdEIsNkJBQTZCOzRCQUM3QixvQ0FBb0M7NEJBQ3BDLCtCQUErQjs0QkFDL0IsNkJBQTZCOzRCQUM3Qiw0QkFBNEI7NEJBQzVCLDBCQUEwQjs0QkFDMUIsSUFBSTs0QkFDSiw0QkFBNEI7NEJBQzVCLDBCQUEwQjs0QkFDMUIsV0FBVzs0QkFDWCxnQkFBZ0I7NEJBQ2hCLDJCQUEyQjs0QkFDM0IsV0FBVzs0QkFDWCxTQUFTOzRCQUVULG1CQUFtQjs0QkFDbkIsNkVBQTZFOzRCQUM3RSxnQkFBZ0I7NEJBQ2hCLG9CQUFvQjs0QkFDcEIsMkJBQTJCOzRCQUMzQixzQ0FBc0M7NEJBQ3RDLFlBQVk7NEJBQ1osbUJBQW1COzRCQUNuQiwwQkFBMEI7NEJBQzFCLHFDQUFxQzs0QkFDckMsV0FBVzs0QkFDWCxRQUFROzRCQUNSLG1DQUFtQzs0QkFDbkMsZ0NBQWdDOzRCQUNoQywyQkFBMkI7NEJBQzNCLFdBQVc7NEJBQ1gsc0VBQXNFOzRCQUN0RSxPQUFPOzRCQUNQLEtBQUs7NEJBR0wsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLDZEQUE2RCxDQUFDLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7NEJBQ3ZGLElBQUksQ0FBQyxDQUFDO2dDQUNGLE1BQU0sQ0FBQyxLQUFLLENBQUM7NEJBQ2pCLENBQUM7d0JBQ0wsQ0FBQzt3QkFDRCxJQUFJLFFBQVEsR0FBRyxFQUFFLENBQUM7d0JBQ2xCLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7NEJBRXhGLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7NEJBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQztnQ0FDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztvQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07b0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtvQ0FDNUIsT0FBTyxFQUFFO3dDQUNMLEVBQUUsRUFBRTs0Q0FDQSxjQUFjOzRDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUzt5Q0FDNUI7cUNBQ0o7aUNBQ0osQ0FBQyxDQUFDOzRCQUNQLENBQUM7NEJBQ0QsSUFBSSxDQUFDLENBQUM7Z0NBQ0YsUUFBUSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7Z0NBQ3pCLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQ0FFdEIsUUFBUTtvQ0FDUiw2QkFBNkI7b0NBQzdCLHFCQUFxQjtvQ0FDckIsc0JBQXNCO29DQUN0Qiw2QkFBNkI7b0NBQzdCLG9DQUFvQztvQ0FDcEMsK0JBQStCO29DQUMvQiw2QkFBNkI7b0NBQzdCLDRCQUE0QjtvQ0FDNUIsMEJBQTBCO29DQUMxQixJQUFJO29DQUNKLDRCQUE0QjtvQ0FDNUIsMEJBQTBCO29DQUMxQix3SUFBd0k7b0NBRXhJLHlEQUF5RDtvQ0FDekQsa0RBQWtEO29DQUNsRCw2Q0FBNkM7b0NBQzdDLG1CQUFtQjtvQ0FDbkIsd0JBQXdCO29DQUN4QixtQkFBbUI7b0NBQ25CLDBCQUEwQjtvQ0FDMUIscUNBQXFDO29DQUNyQyx3QkFBd0I7b0NBQ3hCLDhDQUE4QztvQ0FDOUMsaUJBQWlCO29DQUNqQixXQUFXO29DQUNYLGdCQUFnQjtvQ0FDaEIsMkJBQTJCO29DQUMzQixXQUFXO29DQUNYLFNBQVM7b0NBRVQsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7d0NBRTVCLEtBQUksQ0FBQyxvQkFBb0IsQ0FBQyxxQkFBcUIsQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsRUFBRSxLQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7NENBRWxILElBQUksU0FBUyxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7NENBQ3ZDLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQztnREFDNUIsT0FBTyxDQUFDLEtBQUssQ0FBQztvREFDVixPQUFPLEVBQUUsU0FBUyxDQUFDLE1BQU07b0RBQ3pCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtvREFDNUIsT0FBTyxFQUFFO3dEQUNMLEVBQUUsRUFBRTs0REFDQSxjQUFjOzREQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUzt5REFDNUI7cURBQ0o7aURBQ0osQ0FBQyxDQUFDOzRDQUNQLENBQUM7NENBQ0QsSUFBSSxDQUFDLENBQUM7NENBQ04sQ0FBQzt3Q0FDTCxDQUFDLEVBQUUsVUFBQSxLQUFLOzRDQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7d0NBQ3ZCLENBQUMsRUFBRTs0Q0FDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO3dDQUNoQyxDQUFDLENBQUMsQ0FBQztvQ0FDUCxDQUFDO29DQUNELElBQUksQ0FBQyxDQUFDO3dDQUNGLE1BQU0sQ0FBQyxLQUFLLENBQUM7b0NBQ2pCLENBQUM7Z0NBQ0wsQ0FBQzs0QkFDTCxDQUFDO3dCQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7NEJBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQzt3QkFDdkIsQ0FBQyxFQUFFOzRCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7d0JBQ2hDLENBQUMsQ0FBQyxDQUFDO3dCQUlILEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyx1QkFBdUIsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDOzRCQUV4QyxRQUFROzRCQUNSLDZCQUE2Qjs0QkFDN0IscURBQXFEOzRCQUNyRCxzQkFBc0I7NEJBQ3RCLDZCQUE2Qjs0QkFDN0Isb0NBQW9DOzRCQUNwQywrQkFBK0I7NEJBQy9CLDZCQUE2Qjs0QkFDN0IsNEJBQTRCOzRCQUM1QiwwQkFBMEI7NEJBQzFCLElBQUk7NEJBQ0osNEJBQTRCOzRCQUM1QiwwQkFBMEI7NEJBQzFCLGtJQUFrSTs0QkFFbEksd0RBQXdEOzRCQUN4RCxpREFBaUQ7NEJBQ2pELDRDQUE0Qzs0QkFDNUMsbUJBQW1COzRCQUNuQix3QkFBd0I7NEJBQ3hCLG1CQUFtQjs0QkFDbkIsMEJBQTBCOzRCQUMxQixxQ0FBcUM7NEJBQ3JDLHdCQUF3Qjs0QkFDeEIsOENBQThDOzRCQUM5QyxpQkFBaUI7NEJBQ2pCLFdBQVc7NEJBQ1gsZ0JBQWdCOzRCQUNoQiwyQkFBMkI7NEJBQzNCLFdBQVc7NEJBQ1gsU0FBUzs0QkFFVCxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsd0NBQXdDLENBQUMsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO2dDQUM1RCxJQUFJLENBQUMsb0JBQW9CLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTtvQ0FFNUcsSUFBSSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQztvQ0FDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO3dDQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDOzRDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTs0Q0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZOzRDQUM1QixPQUFPLEVBQUU7Z0RBQ0wsRUFBRSxFQUFFO29EQUNBLGNBQWM7b0RBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO2lEQUM1Qjs2Q0FDSjt5Q0FDSixDQUFDLENBQUM7b0NBQ1AsQ0FBQztvQ0FDRCxJQUFJLENBQUMsQ0FBQztvQ0FDTixDQUFDO2dDQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7b0NBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztnQ0FDdkIsQ0FBQyxFQUFFO29DQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7Z0NBQ2hDLENBQUMsQ0FBQyxDQUFDOzRCQUNQLENBQUM7NEJBQ0QsSUFBSSxDQUFDLENBQUM7Z0NBQ0YsTUFBTSxDQUFDLEtBQUssQ0FBQzs0QkFDakIsQ0FBQzt3QkFFTCxDQUFDO3dCQUNELElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO3dCQUM1QyxJQUFJLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7NEJBRWhELElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7NEJBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQztnQ0FDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztvQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07b0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtvQ0FDNUIsT0FBTyxFQUFFO3dDQUNMLEVBQUUsRUFBRTs0Q0FDQSxjQUFjOzRDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUzt5Q0FDNUI7cUNBQ0o7aUNBQ0osQ0FBQyxDQUFDOzRCQUNQLENBQUM7NEJBQ0QsSUFBSSxDQUFDLENBQUM7Z0NBQ0YsT0FBTyxDQUFDLEtBQUssQ0FBQztvQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07b0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtvQ0FDNUIsT0FBTyxFQUFFO3dDQUNMLEVBQUUsRUFBRTs0Q0FDQSxjQUFjOzRDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUzt5Q0FDNUI7cUNBQ0o7aUNBQ0osQ0FBQyxDQUFDO2dDQUVILDhIQUE4SDtnQ0FDOUgsS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUM7Z0NBQ3RELEtBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSSxDQUFDLFVBQVUsQ0FBQztnQ0FDdEMsS0FBSSxDQUFDLFVBQVUsR0FBRyxFQUFFLENBQUM7Z0NBQ3JCLEtBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxHQUFHLEtBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztnQ0FDbEUsS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsS0FBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO2dDQUN6RCxLQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUM7Z0NBQ2xDLEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLEdBQUcsQ0FBQztnQ0FDakMsS0FBSSxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUM7Z0NBQ3ZCLEtBQUksQ0FBQyxvQkFBb0IsQ0FBQyxrQkFBa0IsRUFBRSxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7b0NBQ3pELFdBQVc7b0NBQ1gsSUFBSSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQztvQ0FDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO3dDQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDOzRDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTs0Q0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZOzRDQUM1QixPQUFPLEVBQUU7Z0RBQ0wsRUFBRSxFQUFFO29EQUNBLGNBQWM7b0RBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO2lEQUM1Qjs2Q0FDSjt5Q0FDSixDQUFDLENBQUM7b0NBQ1AsQ0FBQztvQ0FDRCxJQUFJLENBQUMsQ0FBQzt3Q0FDRixLQUFJLENBQUMsWUFBWSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7d0NBQ2xDLElBQUksUUFBUSxHQUFHLEVBQUUsQ0FBQzt3Q0FDbEIsSUFBSSxRQUFRLEdBQUcsS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUM7d0NBQzFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLFlBQVksRUFBRTs0Q0FFM0IsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssSUFBSSxRQUFRLENBQUMsQ0FBQyxDQUFDO2dEQUV6QixRQUFRLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQztnREFDckIsTUFBTSxDQUFDLEtBQUssQ0FBQzs0Q0FDakIsQ0FBQzt3Q0FDTCxDQUFDLENBQUMsQ0FBQzt3Q0FDSCxLQUFJLENBQUMsYUFBYSxHQUFHLFFBQVEsQ0FBQztvQ0FFbEMsQ0FBQztnQ0FDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO29DQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7Z0NBQ3ZCLENBQUMsRUFBRTtvQ0FDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO2dDQUNoQyxDQUFDLENBQUMsQ0FBQztnQ0FDSCxLQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBRyxHQUFHLENBQUM7Z0NBQ2pDLEtBQUksQ0FBQyxvQkFBb0IsQ0FBQyxXQUFXLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO29DQUNqRixXQUFXO29DQUNYLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7b0NBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzt3Q0FDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQzs0Q0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07NENBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTs0Q0FDNUIsT0FBTyxFQUFFO2dEQUNMLEVBQUUsRUFBRTtvREFDQSxjQUFjO29EQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztpREFDNUI7NkNBQ0o7eUNBQ0osQ0FBQyxDQUFDO29DQUNQLENBQUM7b0NBQ0QsSUFBSSxDQUFDLENBQUM7d0NBQ0YsS0FBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUM7b0NBRTVELENBQUM7Z0NBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSztvQ0FDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO2dDQUN2QixDQUFDLEVBQUU7b0NBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtnQ0FDaEMsQ0FBQyxDQUFDLENBQUM7Z0NBQ0gsS0FBSSxDQUFDLGdCQUFnQixDQUFDLGtCQUFrQixDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTtvQ0FDL0UsV0FBVztvQ0FDWCxJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO29DQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7d0NBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7NENBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNOzRDQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7NENBQzVCLE9BQU8sRUFBRTtnREFDTCxFQUFFLEVBQUU7b0RBQ0EsY0FBYztvREFDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7aURBQzVCOzZDQUNKO3lDQUNKLENBQUMsQ0FBQztvQ0FDUCxDQUFDO29DQUNELElBQUksQ0FBQyxDQUFDO3dDQUNGLEtBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxHQUFHLEdBQUcsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQzt3Q0FDL0UsS0FBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUM7b0NBQzlELENBQUM7Z0NBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSztvQ0FDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO2dDQUN2QixDQUFDLEVBQUU7b0NBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtnQ0FDaEMsQ0FBQyxDQUFDLENBQUM7Z0NBQ0gsV0FBVztnQ0FDWCw0RUFBNEU7Z0NBQzVFLG9FQUFvRTtnQ0FDcEUsd0JBQXdCO2dDQUN4QixLQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLEtBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxDQUFDLENBQUM7NEJBQzlFLENBQUM7d0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzs0QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO3dCQUN2QixDQUFDLEVBQUU7NEJBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTt3QkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBRVAsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixPQUFPLENBQUMsS0FBSyxDQUFDOzRCQUNWLE9BQU8sRUFBRSwyQkFBMkI7NEJBQ3BDLFNBQVMsRUFBRSxJQUFJLENBQUMsWUFBWTs0QkFDNUIsT0FBTyxFQUFFO2dDQUNMLEVBQUUsRUFBRTtvQ0FDQSxjQUFjO29DQUNkLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUztpQ0FDNUI7NkJBQ0o7eUJBQ0osQ0FBQyxDQUFDO29CQUNQLENBQUM7Z0JBQ0wsQ0FBQztnQkFDRCxzQ0FBVyxHQUFYO29CQUNJLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxHQUFHLEVBQUUsQ0FBQztnQkFDckMsQ0FBQztnQkFDRCx3Q0FBYSxHQUFiO29CQUNJLFdBQVc7b0JBQ1gsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxVQUFVLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsVUFBVSxJQUFJLElBQUk7MkJBQ2xGLElBQUksQ0FBQyxjQUFjLENBQUMsZUFBZSxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsY0FBYyxDQUFDLGVBQWUsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO3dCQUNyRyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsZUFBZSxDQUFDLENBQUM7b0JBQ3hGLENBQUM7b0JBQ0QsSUFBSSxDQUFDLENBQUM7d0JBQ0YsT0FBTyxDQUFDLEtBQUssQ0FBQzs0QkFDVixPQUFPLEVBQUUsMERBQTBEOzRCQUNuRSxTQUFTLEVBQUUsSUFBSSxDQUFDLFlBQVk7NEJBQzVCLE9BQU8sRUFBRTtnQ0FDTCxFQUFFLEVBQUU7b0NBQ0EsY0FBYztvQ0FDZCxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVM7aUNBQzVCOzZCQUNKO3lCQUNKLENBQUMsQ0FBQztvQkFDUCxDQUFDO2dCQUNMLENBQUM7Z0JBQ0Qsb0NBQVMsR0FBVDtvQkFDSSxRQUFRLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxVQUFVLEdBQUcsZUFBZSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztnQkFDeEYsQ0FBQztnQkFDRCxvQ0FBUyxHQUFULFVBQVUsVUFBVSxFQUFDLFFBQVE7b0JBQTdCLGlCQTZCQztvQkE1QkcsSUFBSSxTQUFTLEdBQUcsRUFBRSxDQUFDO29CQUNuQixJQUFJLENBQUMsb0JBQW9CLENBQUMsUUFBUSxDQUFDLFVBQVUsRUFBQyxRQUFRLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUNsRSxXQUFXO3dCQUNYLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsU0FBUyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7NEJBQzFCLG1DQUFtQzs0QkFDbkMsSUFBSSxZQUFZLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsT0FBTyxFQUFDLG9EQUFvRCxDQUFDLENBQUM7NEJBQ2pHLFlBQVksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDOzRCQUN2QyxZQUFZLENBQUMsUUFBUSxDQUFDLEtBQUssRUFBRSxDQUFDO3dCQUNsQyxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO2dCQUNQLENBQUM7Z0JBRUQseUNBQWMsR0FBZDtvQkFDSSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUM7d0JBQy9CLElBQUksSUFBSSxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUM7d0JBQzlDLFFBQVEsQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLFVBQVUsR0FBRyxnQkFBZ0IsR0FBRyxJQUFJLENBQUM7b0JBQ2xFLENBQUM7Z0JBQ0wsQ0FBQztnQkFDRCxtQ0FBUSxHQUFSO29CQUFBLGlCQXlOQztvQkF4TkcsRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO3dCQUNyQyxZQUFZLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQztvQkFDdkMsQ0FBQztvQkFDRCxJQUFJLENBQUMsSUFBSSxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBSzFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFDekUsV0FBVzt3QkFDWCxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtnQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUM1QixPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsR0FBRyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7d0JBQzdCLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBRUgsSUFBSSxDQUFDLG9CQUFvQixDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQ2pGLFdBQVc7d0JBQ1gsSUFBSSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtnQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUM1QixPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQzt3QkFFNUQsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFFSCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUMvRSxXQUFXO3dCQUNYLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLEdBQUcsR0FBRyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDOzRCQUMvRSxLQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQzt3QkFDOUQsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFFSCxJQUFJLENBQUMsb0JBQW9CLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUN2RCxJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO2dDQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQzVCLE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEtBQUksQ0FBQyxTQUFTLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzt3QkFFbkMsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFFSCxJQUFJLENBQUMsb0JBQW9CLENBQUMsa0JBQWtCLEVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUN6RCxJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO2dDQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQzVCLE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLFdBQVc7NEJBQ1gsS0FBSSxDQUFDLFlBQVksR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDOzRCQUNsQyxJQUFJLElBQUksR0FBRyxHQUFHLEdBQUcsS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsUUFBUSxFQUFFLENBQUM7NEJBQ3ZELE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDO3dCQUN2QyxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUVILElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxrQkFBa0IsRUFBRSxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBRXpELElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLFlBQVksR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDOzRCQUNsQyxJQUFJLFFBQVEsR0FBRyxFQUFFLENBQUM7NEJBQ2xCLElBQUksUUFBUSxHQUFHLEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDOzRCQUMxQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUksQ0FBQyxZQUFZLEVBQUU7Z0NBRTNCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLElBQUksUUFBUSxDQUFDLENBQUMsQ0FBQztvQ0FFekIsUUFBUSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUM7b0NBQ3JCLE1BQU0sQ0FBQyxLQUFLLENBQUM7Z0NBQ2pCLENBQUM7NEJBQ0wsQ0FBQyxDQUFDLENBQUM7NEJBQ0gsS0FBSSxDQUFDLGFBQWEsR0FBRyxRQUFRLENBQUM7d0JBRWxDLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBRUgsSUFBSSxDQUFDLG9CQUFvQixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQ2hELElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLE1BQU0sR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO3dCQUVoQyxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUVILElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUNqRCxJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO2dDQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQzVCLE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEtBQUksQ0FBQyxNQUFNLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzt3QkFFaEMsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFDSCxNQUFNLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxDQUFDLDJCQUEyQixDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsQ0FBQztnQkFDakcsQ0FBQztnQkF0d0JNLHdCQUFPLEdBQUcsQ0FBQyxRQUFRLEVBQUUsV0FBVyxFQUFFLGVBQWUsQ0FBQyxDQUFDO2dCQWQ5RDtvQkFBQyxnQkFBUyxDQUFDO3dCQUVQLFdBQVcsRUFBRSxzREFBc0Q7d0JBQ25FLFVBQVUsRUFBRSxDQUFDLGlCQUFRLEVBQUUscUJBQVksRUFBRSx3QkFBZSxFQUFFLHVCQUF1QixFQUFFLHdCQUFlLEVBQUUsd0JBQWUsQ0FBQzt3QkFDaEgsU0FBUyxFQUFFLENBQUMsaUNBQWUsRUFBRSxpQ0FBZSxFQUFFLHlDQUFtQixDQUFDO3FCQUNyRSxDQUFDOztvQ0FBQTtnQkFneEJGLHVCQUFDO1lBQUQsQ0E5d0JBLEFBOHdCQyxJQUFBO1lBOXdCRCwrQ0E4d0JDLENBQUEiLCJmaWxlIjoiZGV2L2FtYXgvQ2hhcmdlX0NyZWRpdC9DaGFyZ2VDcmVkaXRDYXJkLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtOZ1N3aXRjaCwgTmdTd2l0Y2hXaGVuLCBOZ1N3aXRjaERlZmF1bHQsIENPUkVfRElSRUNUSVZFUywgRk9STV9ESVJFQ1RJVkVTfSBmcm9tICdhbmd1bGFyMi9jb21tb24nXHJcbmltcG9ydCB7UmVzb3VyY2VTZXJ2aWNlfSBmcm9tIFwiLi4vLi4vc2VydmljZXMvUmVzb3VyY2VTZXJ2aWNlXCI7XHJcbmltcG9ydCB7Um91dGVQYXJhbXN9IGZyb20gXCJhbmd1bGFyMi9yb3V0ZXJcIjtcclxuaW1wb3J0IHtDb21wb25lbnQsIE91dHB1dCwgSW5wdXQsIEV2ZW50RW1pdHRlciwgT25Jbml0fSBmcm9tIFwiYW5ndWxhcjIvY29yZVwiO1xyXG5pbXBvcnQge0N1c3RvbWVyU2VydmljZX0gZnJvbSBcIi4uLy4uL3NlcnZpY2VzL0N1c3RvbWVyU2VydmljZVwiO1xyXG5pbXBvcnQge0NoYXJnZUNyZWRpdFNlcnZpY2V9IGZyb20gXCIuLi8uLi9zZXJ2aWNlcy9DaGFyZ2VDcmVkaXRTZXJ2aWNlXCI7XHJcbmltcG9ydCB7IGpzb25RIH0gZnJvbSAnLi4vLi4vanNvblEnO1xyXG5pbXBvcnQge0dyb3VwRmlsdGVyUGlwZSwgR3JvdXBQYXJlbkZpbHRlclBpcGUsIEtlbmRvX3V0aWxpdHl9IGZyb20gXCIuLi8uLi9hbWF4VXRpbFwiO1xyXG5pbXBvcnQge0F1dG9jb21wbGV0ZUNvbnRhaW5lcn0gZnJvbSAnLi4vLi4vYXV0b2NvbXBsZXRlL2F1dG9jb21wbGV0ZS1jb250YWluZXInO1xyXG5pbXBvcnQge0F1dG9jb21wbGV0ZX0gZnJvbSAnLi4vLi4vYXV0b2NvbXBsZXRlL2F1dG9jb21wbGV0ZS5jb21wb25lbnQnO1xyXG5cclxuZXhwb3J0IGNvbnN0IEFVVE9DT01QTEVURV9ESVJFQ1RJVkVTID0gW0F1dG9jb21wbGV0ZSwgQXV0b2NvbXBsZXRlQ29udGFpbmVyXTtcclxuZGVjbGFyZSB2YXIgalF1ZXJ5O1xyXG5AQ29tcG9uZW50KHtcclxuXHJcbiAgICB0ZW1wbGF0ZVVybDogJy4vYXBwL2FtYXgvQ2hhcmdlX0NyZWRpdC90ZW1wbGF0ZXMvQ2hhcmdlQ3JlZGl0Lmh0bWwnLFxyXG4gICAgZGlyZWN0aXZlczogW05nU3dpdGNoLCBOZ1N3aXRjaFdoZW4sIE5nU3dpdGNoRGVmYXVsdCwgQVVUT0NPTVBMRVRFX0RJUkVDVElWRVMsIENPUkVfRElSRUNUSVZFUywgRk9STV9ESVJFQ1RJVkVTXSxcclxuICAgIHByb3ZpZGVyczogW0N1c3RvbWVyU2VydmljZSwgUmVzb3VyY2VTZXJ2aWNlLCBDaGFyZ2VDcmVkaXRTZXJ2aWNlXVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEFtYXhDaGFyZ2VDcmVkaXQgaW1wbGVtZW50cyBPbkluaXQge1xyXG4gICAgbW9kZWxJbnB1dCA9IHt9O1xyXG4gICAgbW9kZWxJbnB1dFRlbXAgPSB7fTtcclxuICAgIFJFUzogT2JqZWN0ID0ge307XHJcbiAgICBGb3JtdHlwZTogc3RyaW5nID1cIkNIQVJHRUNSRURJVF9TQ1JFRU5cIjtcclxuICAgIExhbmc6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBDdXN0b21lcklkOiBudW1iZXIgPSAtMTtcclxuICAgIHN0YXRpYyAkaW5qZWN0ID0gWyckc2NvcGUnLCAnJGxvY2F0aW9uJywgJyRhbmNob3JTY3JvbGwnXTtcclxuICAgIEJhc2VBcHBVcmw6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBfVGVybWluYWxMaXN0ID0gW107XHJcbiAgICBUZXJtaW5hbE51bWJlcjogc3RyaW5nID0gXCJcIjtcclxuICAgIFJlbVBheW1lbnRzVGV4dDogc3RyaW5nID0gXCJcIjtcclxuICAgIE51bU9mUGF5bWVudHNUZXh0OiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgSXNidG5kaXNhYmxlOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgTXNnQ2xhc3M6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBDaGFuZ2VEaWFsb2c6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBDSEFOR0VESVI6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBTaG93TG9hZGVyOiBib29sZWFuO1xyXG4gICAgU0FWRV9CVE5fVEVYVDogc3RyaW5nO1xyXG4gICAgSXNDcmVkaXRDYW5jZWw6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIElzQ3JlZGl0Tm9PZlBheTogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgSW5zdGFsbG1lbnRzOmFueT0wO1xyXG4gICAgSW5zdGFsbG1lbnRQYXk6IGFueSA9IDA7XHJcbiAgICBpc2ZpbmRjcmVkaXRDYXJkT3duZXJJRDogYm9vbGVhbiA9IHRydWU7XHJcbiAgICBQcmludFVybDogc3RyaW5nID0gXCJodHRwczovL3NlY3VyZS5jYXJkY29tLmNvLmlsL05vdGUvUHJvZ3JhbU5vdGUuYXNweFwiOy8qP0RlYWxOdW1iZXI9XCIgKyBvRGVhbE51bWJlciArIFwiJkRpc3BsYXlEYXRhPTMmVGVybWlhbmw9XCIgKyBvVGVybWlhbmwgKyBcIiZEZWZQcmludD1mYWxzZVwiOyovXHJcbiAgICBfTW50aHMgPSBbXTtcclxuICAgIF9ZZWFycyA9IFtdO1xyXG4gICAgX0NoYXJnZVR5cGVzID0gW107XHJcbiAgICBfQ3VycmVuY3kgPSBbXTtcclxuICAgIF9DcmVkaXRUeXBlcyA9IFtdO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgX3Jlc291cmNlU2VydmljZTogUmVzb3VyY2VTZXJ2aWNlLCBwcml2YXRlIF9jdXN0b21lclNlcnZpY2U6IEN1c3RvbWVyU2VydmljZSwgcHJpdmF0ZSBfcm91dGVQYXJhbXM6IFJvdXRlUGFyYW1zLCBwcml2YXRlIF9DaGFyZ2VDcmVkaXRTZXJ2aWNlOiBDaGFyZ2VDcmVkaXRTZXJ2aWNlKSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5SRVMuQ0hBUkdFQ1JFRElUX1NDUkVFTiA9IHt9O1xyXG4gICAgICAgIHRoaXMuQmFzZUFwcFVybCA9IF9yZXNvdXJjZVNlcnZpY2UuQXBwVXJsO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkID0gX3JvdXRlUGFyYW1zLnBhcmFtcy5JZDtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQub1Rlcm1pbmFsTnVtYmVyID0gX3JvdXRlUGFyYW1zLnBhcmFtcy5UZXJtTm87XHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0Lm9DdXJyZW5jeSA9IFwiTmlzXCI7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkNoYXJnZVR5cGUgPSBcIjBcIjtcclxuICAgICAgIC8vIHRoaXMuT3BlbkRpdigpO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DcmVkaXRUeXBlID0gXCIwXCI7XHJcbiAgICAgICAgLy90aGlzLm1vZGVsSW5wdXRUZW1wLkRlYWxOdW1iZXIgPSBcInRlc3RcIjtcclxuICAgICAgICAvL3RoaXMubW9kZWxJbnB1dFRlbXAub1Rlcm1pbmFsTnVtYmVyID0gXCJ0ZXN0XCI7XHJcbiAgICAvLyAgICBtb2RlbElucHV0Lm9DdXJyZW5jeSAgICAgICAgXHJcbiAgICB9XHJcbiAgICBDaGFuZ2VPd25lcklkKCkge1xyXG4gICAgICAgIHRoaXMuaXNmaW5kY3JlZGl0Q2FyZE93bmVySUQgPSBmYWxzZTtcclxuICAgIH1cclxuICAgIENhbGN1bGF0ZUNvbnN0UGF5KCkge1xyXG4gICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQub1N1bVRvQmlsbCAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0Lm9TdW1Ub0JpbGwgIT0gbnVsbCAmJiB0aGlzLm1vZGVsSW5wdXQub1N1bVRvQmlsbCAhPSBcIlwiXHJcbiAgICAgICAgICAgICYmIHRoaXMubW9kZWxJbnB1dC5vZmlyc3RwYXltZW50c3VtICE9IHVuZGVmaW5lZCAmJiB0aGlzLm1vZGVsSW5wdXQub2ZpcnN0cGF5bWVudHN1bSAhPSBudWxsICYmIHRoaXMubW9kZWxJbnB1dC5vZmlyc3RwYXltZW50c3VtICE9IFwiXCJcclxuICAgICAgICAgICAgJiYgdGhpcy5tb2RlbElucHV0Lm9OdW1PZlBheW1lbnRzICE9IHVuZGVmaW5lZCAmJiB0aGlzLm1vZGVsSW5wdXQub051bU9mUGF5bWVudHMgIT0gbnVsbCAmJiB0aGlzLm1vZGVsSW5wdXQub051bU9mUGF5bWVudHMgIT0gXCJcIikge1xyXG4gICAgICAgICAgICB2YXIgUmVtQW10ID0gcGFyc2VGbG9hdCh0aGlzLm1vZGVsSW5wdXQub1N1bVRvQmlsbCkgLSBwYXJzZUZsb2F0KHRoaXMubW9kZWxJbnB1dC5vZmlyc3RwYXltZW50c3VtKTtcclxuICAgICAgICAgICAgaWYgKFJlbUFtdCA+PSAwKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAocGFyc2VJbnQodGhpcy5tb2RlbElucHV0Lm9OdW1PZlBheW1lbnRzKSA9PSAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKFJlbUFtdCA+IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBcIlBsZWFzZSBnaXZlIGZ1bGwgYW1vdW50IGluIGZpcnN0IHBheW1lbnQgb3IgaW5jcmVhc2UgdGggbm8gb2YgcGF5bWVudHNcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLk51bU9mUGF5bWVudHNUZXh0ID0gdGhpcy5tb2RlbElucHV0Lm9OdW1PZlBheW1lbnRzICsgXCIgcGF5bWVudHMsIGZpcnN0IHBheW1lbnQ6IFwiICsgdGhpcy5tb2RlbElucHV0Lm9maXJzdHBheW1lbnRzdW07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuUmVtUGF5bWVudHNUZXh0ID0gdGhpcy5tb2RlbElucHV0Lm9maXJzdHBheW1lbnRzdW0rXCIgYW5kIDAgcGF5bWVudHMgb2YgMFwiO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKHBhcnNlSW50KHRoaXMubW9kZWxJbnB1dC5vTnVtT2ZQYXltZW50cykgPiAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLkluc3RhbGxtZW50UGF5ID0gcGFyc2VGbG9hdChSZW1BbXQgLyBwYXJzZUZsb2F0KHRoaXMubW9kZWxJbnB1dC5vTnVtT2ZQYXltZW50cyAtIDEpKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQub2NvbnN0cGF0bWVudCA9IHRoaXMuSW5zdGFsbG1lbnRQYXk7XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5OdW1PZlBheW1lbnRzVGV4dCA9IHRoaXMubW9kZWxJbnB1dC5vTnVtT2ZQYXltZW50cyArIFwiIHBheW1lbnRzLCBmaXJzdCBwYXltZW50OiBcIiArIHRoaXMubW9kZWxJbnB1dC5vZmlyc3RwYXltZW50c3VtO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuUmVtUGF5bWVudHNUZXh0ID0gdGhpcy5tb2RlbElucHV0Lm9maXJzdHBheW1lbnRzdW0gKyBcIiBhbmQgXCIgKyBwYXJzZUZsb2F0KHRoaXMubW9kZWxJbnB1dC5vTnVtT2ZQYXltZW50cyAtIDEpICsgXCIgcGF5bWVudHMgb2YgXCIgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLkluc3RhbGxtZW50UGF5LnRvRml4ZWQoMik7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0Lm9OdW1PZlBheW1lbnRzID0gcGFyc2VGbG9hdCh0aGlzLm1vZGVsSW5wdXQub051bU9mUGF5bWVudHMpICsgMTtcclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIENoYW5nZUNyZWRpdFR5cGUob2JqKSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkNyZWRpdFR5cGUgPSBvYmouVmFsdWU7XHJcbiAgICAgICAgaWYgKG9iai5WYWx1ZSAhPSAwKSB7XHJcbiAgICAgICAgICAgIHRoaXMuSXNDcmVkaXROb09mUGF5ID0gdHJ1ZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuSXNDcmVkaXROb09mUGF5ID0gZmFsc2U7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQub2ZpcnN0cGF5bWVudHN1bSA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0Lm9OdW1PZlBheW1lbnRzID0gXCJcIjtcclxuICAgICAgICB0aGlzLk51bU9mUGF5bWVudHNUZXh0ID0gXCJcIjtcclxuICAgICAgICB0aGlzLlJlbVBheW1lbnRzVGV4dDtcclxuICAgIH1cclxuICAgIE9wZW5EaXYoKSB7XHJcbiAgICAgICAgdmFyIHNhdmV0ZXh0ID0gXCJcIjtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ2hhcmdlVHlwZSA9IGpRdWVyeShcIiNDaGFyZ2V0eXBlXCIpLnZhbCgpO1xyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgdmFyIGNocmd0eXBlID0gdGhpcy5tb2RlbElucHV0LkNoYXJnZVR5cGU7XHJcbiAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5fQ2hhcmdlVHlwZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICBcclxuICAgICAgICAgICAgaWYgKHRoaXMuVmFsdWUgPT0gY2hyZ3R5cGUpIHtcclxuXHJcbiAgICAgICAgICAgICAgICBzYXZldGV4dCA9IHRoaXMuVGV4dDtcclxuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHRoaXMuU0FWRV9CVE5fVEVYVCA9IHNhdmV0ZXh0O1xyXG4gICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ2hhcmdlVHlwZSAhPSBcIjBcIikge1xyXG4gICAgICAgICAgICB0aGlzLklzQ3JlZGl0Q2FuY2VsID0gdHJ1ZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSBpZiAodGhpcy5tb2RlbElucHV0LkNoYXJnZVR5cGUgPT0gXCIwXCIpIHtcclxuICAgICAgICAgICAgdGhpcy5Jc0NyZWRpdENhbmNlbCA9IGZhbHNlOyBcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQub3VzZXJwYXNzd29yZCA9IFwiXCI7XHJcbiAgICB9XHJcbiAgICBDaGVja0NyZWRpdENhcmREZXQoKSB7XHJcbiAgICAgICAgaWYgKGpRdWVyeShcImlucHV0OmNoZWNrZWRcIikudmFsKCkgIT0gdW5kZWZpbmVkICYmIGpRdWVyeShcImlucHV0OmNoZWNrZWRcIikudmFsKCkgIT0gbnVsbCkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LlVzZVRva2VuICE9IHVuZGVmaW5lZCAmJiB0aGlzLm1vZGVsSW5wdXQuVXNlVG9rZW4gIT0gbnVsbCkgeyB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LlVzZVRva2VuID0gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkNvbXBhbnlTbGlrYSA9IFwiMVwiO1xyXG5cclxuICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5DcmVkaXRUeXBlID09IFwiMFwiKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQub051bU9mUGF5bWVudHMgPSBcIjFcIjtcclxuXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0Lm9OdW1PZlBheW1lbnRzICE9IHVuZGVmaW5lZCAmJiB0aGlzLm1vZGVsSW5wdXQub051bU9mUGF5bWVudHMgIT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQub051bU9mUGF5bWVudHMgIT0gXCJcIikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQub051bU9mUGF5bWVudHMgPSBwYXJzZUludCh0aGlzLm1vZGVsSW5wdXQub051bU9mUGF5bWVudHMgKyAxKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5vTnVtT2ZQYXltZW50cyA9IFwiMVwiO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkNoYXJnZVR5cGUgPT0gXCIwXCIpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5vZGVhbHR5cGUgPSBcIjFcIjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIGlmICh0aGlzLm1vZGVsSW5wdXQuQ2hhcmdlVHlwZSA9PSBcIjFcIikge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0Lm9kZWFsdHlwZSA9IFwiNTFcIjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIGlmICh0aGlzLm1vZGVsSW5wdXQuQ2hhcmdlVHlwZSA9PSBcIjJcIikge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0Lm9kZWFsdHlwZSA9IFwiNTJcIjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0Lm9kZWFsdHlwZSA9PSBcIjFcIikge1xyXG4gICAgICAgICAgICAgICAgLy9zd2FsKHtcclxuICAgICAgICAgICAgICAgIC8vICAgIHRpdGxlOiBcIkFyZSB5b3Ugc3VyZT9cIixcclxuICAgICAgICAgICAgICAgIC8vICAgIHRleHQ6IFwiTm90ZSB0aGF0IHlvdSByZXF1ZXN0ZWQgY2hhcmdlIHRoZSBjdXN0b21lciwgd2lsbCBjb250aW51ZSFcIixcclxuICAgICAgICAgICAgICAgIC8vICAgIHR5cGU6IFwid2FybmluZ1wiLFxyXG4gICAgICAgICAgICAgICAgLy8gICAgc2hvd0NhbmNlbEJ1dHRvbjogdHJ1ZSxcclxuICAgICAgICAgICAgICAgIC8vICAgIGNvbmZpcm1CdXR0b25Db2xvcjogXCIjREQ2QjU1XCIsXHJcbiAgICAgICAgICAgICAgICAvLyAgICBjb25maXJtQnV0dG9uVGV4dDogXCJZZXNcIixcclxuICAgICAgICAgICAgICAgIC8vICAgIGNhbmNlbEJ1dHRvblRleHQ6IFwiTm9cIixcclxuICAgICAgICAgICAgICAgIC8vICAgIGNsb3NlT25Db25maXJtOiBmYWxzZSxcclxuICAgICAgICAgICAgICAgIC8vICAgIGNsb3NlT25DYW5jZWw6IGZhbHNlXHJcbiAgICAgICAgICAgICAgICAvL30sXHJcbiAgICAgICAgICAgICAgICAvLyAgICBmdW5jdGlvbiAoaXNDb25maXJtKSB7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgaWYgKGlzQ29uZmlybSkge1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC8vICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC8vICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgICAgIC8vYm9vdGJveC5jb25maXJtKHtcclxuICAgICAgICAgICAgICAgIC8vICAgIG1lc3NhZ2U6IFwiTm90ZSB0aGF0IHlvdSByZXF1ZXN0ZWQgY2hhcmdlIHRoZSBjdXN0b21lciwgd2lsbCBjb250aW51ZT9cIixcclxuICAgICAgICAgICAgICAgIC8vICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICBjb25maXJtOiB7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgIGxhYmVsOiAnWWVzJyxcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgY2xhc3NOYW1lOiAnYnRuLXN1Y2Nlc3MnXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICBjYW5jZWw6IHtcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgbGFiZWw6ICdObycsXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgIGNsYXNzTmFtZTogJ2J0bi1kYW5nZXInXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLy8gICAgfSxcclxuICAgICAgICAgICAgICAgIC8vICAgIGNhbGxiYWNrOiBmdW5jdGlvbiAocmVzdWx0KSB7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgaWYgKHJlc3VsdCA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgIC8vY29uc29sZS5sb2coJ1RoaXMgd2FzIGxvZ2dlZCBpbiB0aGUgY2FsbGJhY2s6ICcgKyByZXN1bHQpO1xyXG4gICAgICAgICAgICAgICAgLy8gICAgfVxyXG4gICAgICAgICAgICAgICAgLy99KTtcclxuXHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKGNvbmZpcm0oXCJOb3RlIHRoYXQgeW91IHJlcXVlc3RlZCBjaGFyZ2UgdGhlIGN1c3RvbWVyLCB3aWxsIGNvbnRpbnVlP1wiKSA9PSB0cnVlKSB7IH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB2YXIgSXNJbnNlcnQgPSBcIlwiO1xyXG4gICAgICAgICAgICB0aGlzLl9DaGFyZ2VDcmVkaXRTZXJ2aWNlLklzSW5zZXJ0VG90YmxMYXN0VXBkYXRlKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBJc0luc2VydCA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKElzSW5zZXJ0Lmxlbmd0aCA+IDApIHtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vc3dhbCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgIHRpdGxlOiBcIkFyZSB5b3Ugc3VyZT9cIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gICAgdGV4dDogSXNJbnNlcnQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgIHR5cGU6IFwid2FybmluZ1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICBzaG93Q2FuY2VsQnV0dG9uOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICBjb25maXJtQnV0dG9uQ29sb3I6IFwiI0RENkI1NVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICBjb25maXJtQnV0dG9uVGV4dDogXCJZZXNcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gICAgY2FuY2VsQnV0dG9uVGV4dDogXCJOb1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICBjbG9zZU9uQ29uZmlybTogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgIGNsb3NlT25DYW5jZWw6IGZhbHNlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gICAgZnVuY3Rpb24gKGlzQ29uZmlybSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgICAgaWYgKGlzQ29uZmlybSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgIHRoaXMuX0NoYXJnZUNyZWRpdFNlcnZpY2UuSW5zZXJ0VG90YmxMYXN0VXBkYXRlKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkLCB0aGlzLm1vZGVsSW5wdXQub1N1bVRvQmlsbCkuc3Vic2NyaWJlKHJlc3A9PiB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICAgICB2YXIgcmVzcG9uc2UxID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlMS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgIHN3YWwocmVzcG9uc2UxLkVyck1zZyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gICAgICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGNvbmZpcm0oSXNJbnNlcnQpID09IHRydWUpIHtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9DaGFyZ2VDcmVkaXRTZXJ2aWNlLkluc2VydFRvdGJsTGFzdFVwZGF0ZSh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCwgdGhpcy5tb2RlbElucHV0Lm9TdW1Ub0JpbGwpLnN1YnNjcmliZShyZXNwPT4ge1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgcmVzcG9uc2UxID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UxLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlMS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgICAgICB9KTtcclxuXHJcblxyXG5cclxuICAgICAgICAgICAgaWYgKHRoaXMuaXNmaW5kY3JlZGl0Q2FyZE93bmVySUQgPT0gZmFsc2UpIHtcclxuXHJcbiAgICAgICAgICAgICAgICAvL3N3YWwoe1xyXG4gICAgICAgICAgICAgICAgLy8gICAgdGl0bGU6IFwiQXJlIHlvdSBzdXJlP1wiLFxyXG4gICAgICAgICAgICAgICAgLy8gICAgdGV4dDogXCJZb3Ugd2FudCB0byB1cGRhdGUgYSBjdXN0b21lciBJRCBjYXJkIVwiLFxyXG4gICAgICAgICAgICAgICAgLy8gICAgdHlwZTogXCJ3YXJuaW5nXCIsXHJcbiAgICAgICAgICAgICAgICAvLyAgICBzaG93Q2FuY2VsQnV0dG9uOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgLy8gICAgY29uZmlybUJ1dHRvbkNvbG9yOiBcIiNERDZCNTVcIixcclxuICAgICAgICAgICAgICAgIC8vICAgIGNvbmZpcm1CdXR0b25UZXh0OiBcIlllc1wiLFxyXG4gICAgICAgICAgICAgICAgLy8gICAgY2FuY2VsQnV0dG9uVGV4dDogXCJOb1wiLFxyXG4gICAgICAgICAgICAgICAgLy8gICAgY2xvc2VPbkNvbmZpcm06IGZhbHNlLFxyXG4gICAgICAgICAgICAgICAgLy8gICAgY2xvc2VPbkNhbmNlbDogZmFsc2VcclxuICAgICAgICAgICAgICAgIC8vfSxcclxuICAgICAgICAgICAgICAgIC8vICAgIGZ1bmN0aW9uIChpc0NvbmZpcm0pIHtcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICBpZiAoaXNDb25maXJtKSB7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgIHRoaXMuX0NoYXJnZUNyZWRpdFNlcnZpY2UuVXBkYXRlT3duZXJJZCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCwgdGhpcy5tb2RlbElucHV0Lm9DYXJkT3duZXJJZCkuc3Vic2NyaWJlKHJlc3A9PiB7XHJcblxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgICAgICAgICBzd2FsKHJlc3BvbnNlLkVyck1zZyk7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvLyAgICB9KTtcclxuICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIGlmIChjb25maXJtKFwiWW91IHdhbnQgdG8gdXBkYXRlIGEgY3VzdG9tZXIgSUQgY2FyZD9cIikgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX0NoYXJnZUNyZWRpdFNlcnZpY2UuVXBkYXRlT3duZXJJZCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCwgdGhpcy5tb2RlbElucHV0Lm9DYXJkT3duZXJJZCkuc3Vic2NyaWJlKHJlc3A9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3ApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgICAgICAgICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB2YXIgamRhdGEgPSBKU09OLnN0cmluZ2lmeSh0aGlzLm1vZGVsSW5wdXQpO1xyXG4gICAgICAgICAgICB0aGlzLl9DaGFyZ2VDcmVkaXRTZXJ2aWNlLlNhdmUoamRhdGEpLnN1YnNjcmliZShyZXNwPT4ge1xyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICB2YXIgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3ApO1xyXG4gICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgLy8gZG9jdW1lbnQubG9jYXRpb24gPSB0aGlzLkJhc2VBcHBVcmwgKyBcIkNoYXJnZUNyZWRpdC9cIiArIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkICsgXCIvXCIgKyB0aGlzLm1vZGVsSW5wdXQub1Rlcm1pbmFsTnVtYmVyO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5EZWFsTnVtYmVyID0gcmVzcG9uc2UuRGF0YS5EZWFsTnVtYmVyO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dFRlbXAgPSB0aGlzLm1vZGVsSW5wdXQ7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0ID0ge307XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0Lm9UZXJtaW5hbE51bWJlciA9IHRoaXMuX3JvdXRlUGFyYW1zLnBhcmFtcy5UZXJtTm87XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQgPSB0aGlzLl9yb3V0ZVBhcmFtcy5wYXJhbXMuSWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0Lm9DdXJyZW5jeSA9IFwiTmlzXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkNoYXJnZVR5cGUgPSBcIjBcIjtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9DaGFyZ2VUeXBlcyA9IFtdO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX0NoYXJnZUNyZWRpdFNlcnZpY2UuQmluZENoYXJnZVR5cGVMaXN0KCkuc3Vic2NyaWJlKHJlc3A9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX0NoYXJnZVR5cGVzID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBzYXZldGV4dCA9IFwiXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgY2hyZ3R5cGUgPSB0aGlzLm1vZGVsSW5wdXQuQ2hhcmdlVHlwZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMuX0NoYXJnZVR5cGVzLCBmdW5jdGlvbiAoKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLlZhbHVlID09IGNocmd0eXBlKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzYXZldGV4dCA9IHRoaXMuVGV4dDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5TQVZFX0JUTl9URVhUID0gc2F2ZXRleHQ7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICAgICAgICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DcmVkaXRUeXBlID0gXCIwXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fQ2hhcmdlQ3JlZGl0U2VydmljZS5CaW5kVGVybURldCh0aGlzLm1vZGVsSW5wdXQub1Rlcm1pbmFsTnVtYmVyKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0Lm91c2VybmFtZSA9IHJlc3BvbnNlLkRhdGEuaW5zdGl0dXRlTmFtZTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgICAgICAgICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkdldENvbXBsZXRlQ3VzdERldCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCkuc3Vic2NyaWJlKHJlc3A9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lck5hbWUgPSByZXNwb25zZS5EYXRhLmZuYW1lICsgXCIgXCIgKyByZXNwb25zZS5EYXRhLmxuYW1lO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0Lm9DYXJkT3duZXJJZCA9IHJlc3BvbnNlLkRhdGEuQ3VzdG9tZXJDb2RlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICAgICAgICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgLy92YXIgUHJpbnRVcmwgPSB0aGlzLlByaW50VXJsICsgXCI/RGVhbE51bWJlcj1cIiArIHJlc3BvbnNlLkRhdGEuRGVhbE51bWJlciArXHJcbiAgICAgICAgICAgICAgICAgICAgLy8gICAgXCImRGlzcGxheURhdGE9MyZUZXJtaWFubD1cIiArIHRoaXMubW9kZWxJbnB1dC5vVGVybWluYWxOdW1iZXIgK1xyXG4gICAgICAgICAgICAgICAgICAgIC8vICAgIFwiJkRlZlByaW50PWZhbHNlXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5QcmludERhdGEocmVzcG9uc2UuRGF0YS5EZWFsTnVtYmVyLCB0aGlzLm1vZGVsSW5wdXQub1Rlcm1pbmFsTnVtYmVyKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgIG1lc3NhZ2U6ICdQbGVhc2Ugc2VsZWN0IGNyZWRpdCB0eXBlJyxcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgQ2xlYXJDYXJkTm8oKSB7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0Lm9DYXJkTnVtYmVyID0gXCJcIjtcclxuICAgIH1cclxuICAgIFByaW50UHJldkRhdGEoKSB7XHJcbiAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0VGVtcC5EZWFsTnVtYmVyICE9IHVuZGVmaW5lZCAmJiB0aGlzLm1vZGVsSW5wdXRUZW1wLkRlYWxOdW1iZXIgIT0gbnVsbFxyXG4gICAgICAgICAgICAmJiB0aGlzLm1vZGVsSW5wdXRUZW1wLm9UZXJtaW5hbE51bWJlciAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0VGVtcC5vVGVybWluYWxOdW1iZXIgIT0gbnVsbCkge1xyXG4gICAgICAgICAgICB0aGlzLlByaW50RGF0YSh0aGlzLm1vZGVsSW5wdXRUZW1wLkRlYWxOdW1iZXIsIHRoaXMubW9kZWxJbnB1dFRlbXAub1Rlcm1pbmFsTnVtYmVyKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgbWVzc2FnZTogXCJQbGVhc2UgZG8gYW55IHRyYW5zZWN0aW9uIGFuZCB0aGVuIGNsaWNrIG9uIHByaW50IGJ1dHRvblwiLFxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBDYW5jZWxCdG4oKSB7XHJcbiAgICAgICAgZG9jdW1lbnQubG9jYXRpb24gPSB0aGlzLkJhc2VBcHBVcmwgKyBcIkN1c3RvbWVyL0FkZC9cIiArIHRoaXMuX3JvdXRlUGFyYW1zLnBhcmFtcy5JZDtcclxuICAgIH1cclxuICAgIFByaW50RGF0YShEZWFsTnVtYmVyLFRlcm1pbmFsKSB7XHJcbiAgICAgICAgdmFyIFByaW50RGF0YSA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5fQ2hhcmdlQ3JlZGl0U2VydmljZS5nZXRQcmludChEZWFsTnVtYmVyLFRlcm1pbmFsKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgUHJpbnREYXRhID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgIC8vdmFyIE9wZW5XaW5kb3cgPSB3aW5kb3cub3BlbihcIlwiKTtcclxuICAgICAgICAgICAgICAgIHZhciB3aW5kb3dPYmplY3QgPSB3aW5kb3cub3BlbignJywgJ1ByaW50Jywnc2Nyb2xsYmFycz15ZXMscmVzaXphYmxlPXllcyx3aWR0aD0xMDUwLGhlaWdodD02NTAnKTtcclxuICAgICAgICAgICAgICAgIHdpbmRvd09iamVjdC5kb2N1bWVudC53cml0ZShQcmludERhdGEpO1xyXG4gICAgICAgICAgICAgICAgd2luZG93T2JqZWN0LmRvY3VtZW50LmNsb3NlKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgT3Blbk5ld1JlY2VpcHQoKSB7XHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dCAhPSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgdmFyIGVtaWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImVtcGxveWVlaWRcIik7XHJcbiAgICAgICAgICAgIGRvY3VtZW50LmxvY2F0aW9uID0gdGhpcy5CYXNlQXBwVXJsICsgXCJSZWNlaXB0U2VsZWN0L1wiICsgZW1pZDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBuZ09uSW5pdCgpIHtcclxuICAgICAgICBpZiAobG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJsYW5nXCIpID09IFwiXCIpIHtcclxuICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJsYW5nXCIsIFwiZW5cIik7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuTGFuZyA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwibGFuZ1wiKTtcclxuICAgICAgICBcclxuICAgICAgXHJcbiAgICAgICAgXHJcbiAgICAgICBcclxuICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5HZXRMYW5nUmVzKHRoaXMuRm9ybXR5cGUsIHRoaXMuTGFuZykuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICB9XHJcbiAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgIHRoaXMuUkVTID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICB9XHJcbiAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICB9KTsgICAgICAgICAgXHJcblxyXG4gICAgICAgdGhpcy5fQ2hhcmdlQ3JlZGl0U2VydmljZS5CaW5kVGVybURldCh0aGlzLm1vZGVsSW5wdXQub1Rlcm1pbmFsTnVtYmVyKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgIHZhciByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcCk7XHJcbiAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQub3VzZXJuYW1lID0gcmVzcG9uc2UuRGF0YS5pbnN0aXR1dGVOYW1lO1xyXG5cclxuICAgICAgICAgICB9XHJcbiAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICB9KTtcclxuXHJcbiAgICAgICB0aGlzLl9jdXN0b21lclNlcnZpY2UuR2V0Q29tcGxldGVDdXN0RGV0KHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgIHZhciByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcCk7XHJcbiAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJOYW1lID0gcmVzcG9uc2UuRGF0YS5mbmFtZSArIFwiIFwiICsgcmVzcG9uc2UuRGF0YS5sbmFtZTtcclxuICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0Lm9DYXJkT3duZXJJZCA9IHJlc3BvbnNlLkRhdGEuQ3VzdG9tZXJDb2RlO1xyXG4gICAgICAgICAgIH1cclxuICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgIH0pO1xyXG5cclxuICAgICAgIHRoaXMuX0NoYXJnZUNyZWRpdFNlcnZpY2UuQmluZEN1cnJlbmN5TGlzdCgpLnN1YnNjcmliZShyZXNwPT4ge1xyXG4gICAgICAgICAgIHZhciByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcCk7XHJcbiAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICB0aGlzLl9DdXJyZW5jeSA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgIH1cclxuICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgIH0pO1xyXG5cclxuICAgICAgIHRoaXMuX0NoYXJnZUNyZWRpdFNlcnZpY2UuQmluZENyZWRpdFR5cGVMaXN0KCkuc3Vic2NyaWJlKHJlc3A9PiB7XHJcbiAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICB9XHJcbiAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgIHRoaXMuX0NyZWRpdFR5cGVzID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgdmFyIHJiaWQgPSBcIiNcIiArIHRoaXMubW9kZWxJbnB1dC5DcmVkaXRUeXBlLnRvU3RyaW5nKCk7XHJcbiAgICAgICAgICAgICAgIGpRdWVyeShyYmlkKS5wcm9wKFwiY2hlY2tlZFwiLCB0cnVlKTtcclxuICAgICAgICAgICB9XHJcbiAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICB9KTtcclxuXHJcbiAgICAgICB0aGlzLl9DaGFyZ2VDcmVkaXRTZXJ2aWNlLkJpbmRDaGFyZ2VUeXBlTGlzdCgpLnN1YnNjcmliZShyZXNwPT4ge1xyXG4gICAgICAgICAgIFxyXG4gICAgICAgICAgIHZhciByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcCk7XHJcbiAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICB0aGlzLl9DaGFyZ2VUeXBlcyA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgIHZhciBzYXZldGV4dCA9IFwiXCI7XHJcbiAgICAgICAgICAgICAgIHZhciBjaHJndHlwZSA9IHRoaXMubW9kZWxJbnB1dC5DaGFyZ2VUeXBlO1xyXG4gICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLl9DaGFyZ2VUeXBlcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5WYWx1ZSA9PSBjaHJndHlwZSkge1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICBzYXZldGV4dCA9IHRoaXMuVGV4dDtcclxuICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICB0aGlzLlNBVkVfQlROX1RFWFQgPSBzYXZldGV4dDtcclxuICAgICAgICAgICAgICBcclxuICAgICAgICAgICB9XHJcbiAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICB9KTtcclxuICAgICAgIFxyXG4gICAgICAgdGhpcy5fQ2hhcmdlQ3JlZGl0U2VydmljZS5CaW5kWWVhcnMoKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICB2YXIgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3ApO1xyXG4gICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgIH1cclxuICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgdGhpcy5fWWVhcnMgPSByZXNwb25zZS5EYXRhO1xyXG5cclxuICAgICAgICAgICB9XHJcbiAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICB9KTtcclxuXHJcbiAgICAgICB0aGlzLl9DaGFyZ2VDcmVkaXRTZXJ2aWNlLkJpbmRNb250aHMoKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICB2YXIgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3ApO1xyXG4gICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgIH1cclxuICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgdGhpcy5fTW50aHMgPSByZXNwb25zZS5EYXRhO1xyXG5cclxuICAgICAgICAgICB9XHJcbiAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICB9KTtcclxuICAgICAgIHdpbmRvdy5zZXRUaW1lb3V0KGZ1bmN0aW9uICgpIHsgJChcIltuYW1lPSdDcmVkaXRUeXBlJ106Zmlyc3RcIikuYXR0cihcImNoZWNrZWRcIiwgdHJ1ZSk7IH0sMTAwMCk7XHJcbiAgICB9XHJcbn1cclxuIl19
