System.register(['angular2/common', "../../services/ResourceService", "angular2/router", "angular2/core", "../../services/CustomerService", "../../amaxUtil", '../../autocomplete/autocomplete-container', '../../autocomplete/autocomplete.component', '../../comonComponents/basicComponents'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var common_1, ResourceService_1, router_1, core_1, CustomerService_1, amaxUtil_1, autocomplete_container_1, autocomplete_component_1, basicComponents_1;
    var AUTOCOMPLETE_DIRECTIVES, AmaxCustomers;
    return {
        setters:[
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (ResourceService_1_1) {
                ResourceService_1 = ResourceService_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (CustomerService_1_1) {
                CustomerService_1 = CustomerService_1_1;
            },
            function (amaxUtil_1_1) {
                amaxUtil_1 = amaxUtil_1_1;
            },
            function (autocomplete_container_1_1) {
                autocomplete_container_1 = autocomplete_container_1_1;
            },
            function (autocomplete_component_1_1) {
                autocomplete_component_1 = autocomplete_component_1_1;
            },
            function (basicComponents_1_1) {
                basicComponents_1 = basicComponents_1_1;
            }],
        execute: function() {
            exports_1("AUTOCOMPLETE_DIRECTIVES", AUTOCOMPLETE_DIRECTIVES = [autocomplete_component_1.Autocomplete, autocomplete_container_1.AutocompleteContainer]);
            AmaxCustomers = (function () {
                function AmaxCustomers(_resourceService, _customerService, _routeParams) {
                    this._resourceService = _resourceService;
                    this._customerService = _customerService;
                    this._routeParams = _routeParams;
                    this.modelInput = {};
                    this.TempmodelInput = {};
                    this.custSearchData = [];
                    this.RES = {};
                    this.SelectedPhType = {};
                    this.tempstreetmsg = "";
                    this.Formtype = "CUSTOMER_MASTER";
                    this.Lang = "";
                    //modelInput.lname= "";
                    this.ShowMore = false;
                    this.IsRecordEditMode = false;
                    this.ShowMoreText = "More";
                    this.ShowLoader = false;
                    this.ShowMsg = false;
                    this.ShowGroups = true;
                    this.GroupText = "Show Groups";
                    this.Msg = "";
                    this.MsgClass = "text-primary";
                    this.Isbtndisable = "";
                    this.IsFileAsSaveBtn = "";
                    this.IsFileAsCancelBtn = "";
                    this.languageArray = [];
                    this.Address = {};
                    this.PhoneModel = {};
                    this.EmailModel = {};
                    this.IsShowAll = false;
                    this.CustList = {};
                    this.SAVE_BTN_TEXT = "";
                    this.BTN_PHADD = "";
                    this.EditPhoneData = {};
                    this.EditAddressData = {};
                    this.EditEmailData = {};
                    this.IsFileAstxtShow = false;
                    this.FILEAS_BTN_TEXT = "";
                    this.cssFileAsBtn = "";
                    this.IsCancel = false;
                    this.SearchVal = "";
                    this.EnterCount = 0;
                    this.CustIdText = "";
                    this.BaseAppUrl = "";
                    this.PhIndex = 0;
                    this.KendoRTLCSS = "";
                    this.CHANGEDIR = "";
                    this.ChangeDialog = "";
                    //IsFileAsSave: boolean = false;
                    //Email: string = "";
                    //CustomerEmail: Object = {};
                    //modelInput.CustomerEmails = [];
                    this._CustTypes = [];
                    this._Sources = [];
                    this._Employees = [];
                    this._Suffixes = [];
                    this._PhoneTypes = [];
                    this._AddressTypes = [];
                    this._Groups = [];
                    this._Countries = [];
                    this._States = [];
                    this._Cities = [];
                    this.selectedCar = '';
                    this.asyncSelectedCar = '';
                    this.autocompleteLoading = false;
                    this.autocompleteNoResults = false;
                    this.autocompleteSelect = false;
                    this._previousasyncSelectedCar = '';
                    this.modelInput.BirthDate = "";
                    this.modelInput.CustomerAddresses = [];
                    this.modelInput.CustomerPhones = [];
                    this.modelInput.CustomerEmails = [];
                    this.modelInput.CustomerGroups = [];
                    this.Address.CountryCode = "";
                    this.Address.StateId = "";
                    this.modelInput.employeeid = "";
                    this.modelInput.CustomerType = "";
                    this.modelInput.CameFromCustomer = "";
                    this.modelInput.Safixid = "";
                    this.modelInput.Gender = "0";
                    this.PhoneModel.PhoneTypeId = "";
                    this.RES.CUSTOMER_MASTER = {};
                    this.IsShowAll = false;
                    this.SAVE_BTN_TEXT = this.RES.CUSTOMER_MASTER.APP_BTN_SAVE;
                    this.BTN_PHADD = this.RES.CUSTOMER_MASTER.APP_BTN_PHADD;
                    this.ADD_NEW_CUST_TEXT = this.RES.CUSTOMER_MASTER.APP_LBL_NEW_CUST;
                    this.modelInput.CustomerEmails = [{ Email: "", EmailName: "", Newslettere: true, publish: 1, NewsOrder: "News1", EPublishOrder: "EPub1" }];
                    this.modelInput.CustomerPhones = [{ PhoneTypeId: "", Prefix: "", Area: "", Phone: "", IsSms: 1, Comments: "", IsShowRemarks: false, phpublish: 1, SMSOrder: "SMS1", PublishOrder: "Pub1" }];
                    // debugger;
                    var empid = localStorage.getItem("employeeid");
                    var ccode = this._resourceService.getCookie(empid + "ccode");
                    if (ccode.length > 0)
                        ccode = ccode.substring(1, ccode.length);
                    this.modelInput.CustomerAddresses = [{
                            Street: "", Street2: "", CityName: "", Zip: "", CountryCode: ccode, StateId: "", AddressTypeId: "",
                            ForDelivery: true, MainAddress: true, MainOrder: "MainAddr1", DelvryOrder: "Delvry1"
                        }];
                    var custtype = this._resourceService.getCookie(empid + "cust");
                    if (custtype.length > 0) {
                        custtype = custtype.substring(1, custtype.length);
                    }
                    this.modelInput.CustomerType = custtype;
                    var emp = this._resourceService.getCookie(empid + "emp");
                    if (emp.length > 0)
                        emp = emp.substring(1, emp.length);
                    this.modelInput.employeeid = emp;
                    var source = this._resourceService.getCookie(empid + "src");
                    if (source.length > 0)
                        source = source.substring(1, source.length);
                    else {
                    }
                    this.modelInput.CameFromCustomer = source;
                    this.CSSTEXT = "mdi-content-add";
                    this.cssFileAsBtn = "mdi-content-create";
                    this.IsFileAstxtShow = false;
                    clearTimeout(this.StopTimeOut);
                    this.modelInput.CustomerId = _routeParams.params.Id;
                    this.BaseAppUrl = _resourceService.AppUrl;
                    this.TempmodelInput = this.modelInput;
                    //alert(this._resourceService.getCookie(empid + "cust"));
                    //this.ShowMoreText = "More";
                }
                AmaxCustomers.prototype.getCurrentContext = function () {
                    return this;
                };
                AmaxCustomers.prototype.dateSelectionChange = function (evt) {
                    console.log(evt);
                    this.modelInput.BirthDate = evt;
                    // alert(this.modelInput.BirthDate);
                    //this.validateLogin();
                };
                AmaxCustomers.prototype.getAsyncData = function (context) {
                    var _this = this;
                    var SrchVal = context.asyncSelectedCar;
                    // if (SrchVal != undefined && SrchVal != null && SrchVal != "") {
                    // debugger;
                    if (this._previousasyncSelectedCar == context.asyncSelectedCar) {
                        //clearTimeout(this.StopTimeOut);
                        return this._cachedResult;
                    }
                    else {
                        //alert(this._previousasyncSelectedCar + " | " + context.asyncSelectedCar);
                        if (context.asyncSelectedCar != "") {
                            this._previousasyncSelectedCar = context.asyncSelectedCar;
                            //  this.StopTimeOut = setTimeout(() => {
                            //    alert(SrchVal);
                            this._customerService.GetCompleteSearch(SrchVal).subscribe(function (response) {
                                // debugger;
                                response = jQuery.parseJSON(response);
                                if (response.IsError == true) {
                                    //alert(response.ErrMsg);
                                    bootbox.alert({ message: response.ErrMsg,
                                        className: _this.ChangeDialog,
                                        buttons: {
                                            ok: {
                                                //label: 'Ok',
                                                className: _this.CHANGEDIR
                                            }
                                        }
                                    });
                                }
                                else {
                                    context.carsExample1 = response.Data;
                                }
                            }, function (error) {
                                console.log(error);
                            }, function () {
                                console.log("CallCompleted");
                            });
                            // }, 500);
                            this._cachedResult = context.carsExample1;
                        }
                        else {
                            this._cachedResult = [];
                        }
                        return this._cachedResult;
                    }
                };
                AmaxCustomers.prototype.changeAutocompleteLoading = function (e) {
                    this.autocompleteLoading = e;
                };
                AmaxCustomers.prototype.changeAutocompleteNoResults = function (e) {
                    this.autocompleteSelect = false;
                    this.autocompleteNoResults = e;
                };
                AmaxCustomers.prototype.autocompleteOnSelect = function (e) {
                    var _this = this;
                    this.autocompleteSelect = true;
                    console.log("Selected value: " + e.item);
                    var CompData = e.item.split('|');
                    //debugger;
                    if (e.item != undefined && e.item != "" && e.item != null) {
                        //alert(CompData[0]);
                        this._customerService.GetCompleteCustDet(CompData[0].trim()).subscribe(function (response) {
                            //debugger;
                            response = jQuery.parseJSON(response);
                            if (response.IsError == true) {
                                //alert(response.ErrMsg);
                                bootbox.alert({ message: response.ErrMsg,
                                    className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                            else {
                                _this.modelInput = response.Data;
                                // alert(this.modelInput.BirthDate);
                                _this.SAVE_BTN_TEXT = _this.RES.CUSTOMER_MASTER.APP_BTN_UPDATE;
                                _this.ADD_NEW_CUST_TEXT = _this.RES.CUSTOMER_MASTER.APP_LBL_UPDATE_CUST;
                                _this.CSSTEXT = "mdi-content-create";
                                if (_this.modelInput.CustomerEmails.length == 0) {
                                    _this.modelInput.CustomerEmails = [{ Email: "", EmailName: _this.modelInput.FileAs, Newslettere: false }];
                                }
                                if (_this.modelInput.CustomerPhones.length == 0) {
                                    var phid = "";
                                    jQuery.each(_this._PhoneTypes, function () {
                                        if (this.Text == "CellPhone") {
                                            phid = this.Value;
                                            return false;
                                        }
                                    });
                                    _this.modelInput.CustomerPhones = [{ PhoneTypeId: phid, Prefix: "", Area: "", Phone: "", IsSms: 0, Comments: "", phpublish: 0 }];
                                }
                                if (_this.modelInput.CustomerAddresses.length == 0) {
                                    var empid = localStorage.getItem("employeeid");
                                    var ccode = _this._resourceService.getCookie(empid + "ccode");
                                    if (ccode.length > 0)
                                        ccode = ccode.substring(1, ccode.length);
                                    var adid = "";
                                    var comptext = "Home";
                                    if (_this.modelInput.Company != "" && _this.modelInput.Company != undefined && _this.modelInput.Company != null) {
                                        comptext = "Work";
                                    }
                                    jQuery.each(_this._AddressTypes, function () {
                                        if (this.Text == comptext) {
                                            adid = this.Value;
                                            return false;
                                        }
                                    });
                                    _this.modelInput.CustomerAddresses = [{ Street: "", Street2: "", CityName: "", Zip: "", CountryCode: ccode, StateId: "", AddressTypeId: adid, ForDelivery: false, MainAddress: false }];
                                }
                                _this.CustIdText = "( " + _this.modelInput.CustomerId + " )";
                                _this.IsFileAstxtShow = false;
                                //this.IsCancel = true;
                                //this.HideShowFileAstxt();
                                _this.CancelFileAstxt();
                                _this.IsShowAll = true;
                                //this.bindGroup();
                                //alert(this.RES);
                                _this.bindGroupTree(true);
                            }
                        }, function (error) {
                            console.log(error);
                        }, function () {
                            console.log("CallCompleted");
                        });
                    }
                };
                AmaxCustomers.prototype.OpenNewReceipt = function () {
                    if (this.modelInput != undefined && this.modelInput.CustomerId != undefined && this.modelInput.CustomerId >= 0) {
                        var custId = this.modelInput.CustomerId;
                        if (custId != -1) {
                            var emid = localStorage.getItem("employeeid");
                            document.location = this.BaseAppUrl + "ReceiptSelect/" + emid;
                        }
                    }
                };
                AmaxCustomers.prototype.OpenChargeCreditPage = function () {
                    var _this = this;
                    this.Isbtndisable = "disabled";
                    this._customerService.CheckIsOpenCharge().subscribe(function (response) {
                        console.log(response);
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    } } });
                        }
                        else {
                            //debugger;
                            if (response.Data != undefined && response.Data != null && response.Data.length == 1) {
                                var custId = -1;
                                if (_this.TempmodelInput != undefined && _this.TempmodelInput.CustomerId != undefined && _this.TempmodelInput.CustomerId >= 0) {
                                    custId = _this.TempmodelInput.CustomerId;
                                }
                                if (_this.modelInput != undefined && _this.modelInput.CustomerId != undefined && _this.modelInput.CustomerId >= 0) {
                                    custId = _this.modelInput.CustomerId;
                                }
                                if (custId != -1) {
                                    document.location = _this.BaseAppUrl + "ChargeCredit/" + custId + "/" + response.Data[0].Value;
                                }
                                else {
                                    bootbox.alert({
                                        message: 'Please save new or load previous customer and then click on charge credit button',
                                        className: _this.ChangeDialog,
                                        buttons: {
                                            ok: {
                                                //label: 'Ok',
                                                className: _this.CHANGEDIR
                                            }
                                        }
                                    });
                                }
                            }
                            else if (response.Data != undefined && response.Data != null && response.Data.length > 1) {
                                //debugger;
                                var custId = -1;
                                if (_this.TempmodelInput != undefined && _this.TempmodelInput.CustomerId != undefined && _this.TempmodelInput.CustomerId >= 0) {
                                    custId = _this.TempmodelInput.CustomerId;
                                }
                                if (_this.modelInput != undefined && _this.modelInput.CustomerId != undefined && _this.modelInput.CustomerId >= 0) {
                                    custId = _this.modelInput.CustomerId;
                                }
                                if (custId != -1) {
                                    document.location = _this.BaseAppUrl + "Terminals/Show/" + custId;
                                }
                                else {
                                    bootbox.alert({
                                        message: 'Please save new or load previous customer and then click on charge credit button',
                                        className: _this.ChangeDialog,
                                        buttons: {
                                            ok: {
                                                //label: 'Ok',
                                                className: _this.CHANGEDIR
                                            }
                                        }
                                    });
                                }
                            }
                            else {
                                bootbox.alert({
                                    message: _this.RES.CUSTOMER_MASTER.APP_MSG_CHARGECREDIT,
                                    className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        } }
                                });
                            }
                        }
                        _this.ShowMsg = true;
                        _this.Msg = response.ErrMsg;
                    }, function (error) { return console.log(error); }, function () { return console.log("Save Call Compleated"); });
                    this.Isbtndisable = "";
                };
                AmaxCustomers.prototype.StopTimer = function () {
                    bootbox.alert({
                        message: 'From Stop Timer' + this.StopTimeOut, className: this.ChangeDialog,
                        buttons: {
                            ok: {
                                //label: 'Ok',
                                className: this.CHANGEDIR
                            }
                        }
                    });
                    clearTimeout(this.StopTimeOut);
                };
                AmaxCustomers.prototype.SetdefaultPage = function () {
                    var _this = this;
                    document.location = this.BaseAppUrl + "Customer/Add/-1";
                    this.IsFileAstxtShow = true;
                    this.IsCancel = true;
                    var empid = localStorage.getItem("employeeid");
                    this.asyncSelectedCar = "";
                    this.modelInput = {};
                    this.modelInput.BirthDate = "";
                    this.modelInput.CustomerId = -1;
                    this.CustIdText = "";
                    this.HideShowFileAstxt();
                    var custtype = this._resourceService.getCookie(empid + "cust");
                    if (custtype.length > 0)
                        custtype = custtype.substring(1, custtype.length);
                    this.modelInput.CustomerType = custtype;
                    var emp = this._resourceService.getCookie(empid + "emp");
                    if (emp.length > 0)
                        emp = emp.substring(1, emp.length);
                    this.modelInput.employeeid = emp;
                    var source = this._resourceService.getCookie(empid + "src");
                    if (source.length > 0)
                        source = source.substring(1, source.length);
                    this.modelInput.CameFromCustomer = source;
                    this.ShowMore = false;
                    //this.ShowMoreText = "More"; 
                    this.ShowMoreText = this.RES.CUSTOMER_MASTER.APP_LNK_LBL_MORE;
                    this.SAVE_BTN_TEXT = this.RES.CUSTOMER_MASTER.APP_BTN_SAVE;
                    this.CSSTEXT = "mdi-content-add";
                    this.ADD_NEW_CUST_TEXT = this.RES.CUSTOMER_MASTER.APP_LBL_NEW_CUST;
                    this.ShowGroups = true;
                    this.showhideGroups();
                    //this.GroupText = this.RES.CUSTOMER_MASTER.APP_LBL_SHOWGROUPS;
                    var phid = "";
                    var SMS = 0;
                    var publish = 0;
                    var epublish = 0;
                    jQuery.each(this._PhoneTypes, function () {
                        if (this.Text == "CellPhone") {
                            phid = this.Value;
                            SMS = 1;
                            publish = 1;
                            epublish = 1;
                            return false;
                        }
                    });
                    this.modelInput.CustomerPhones = [{ PhoneTypeId: phid, Prefix: "", Area: "", Phone: "", IsSms: SMS, Comments: "", phpublish: publish }];
                    //debugger;
                    this.modelInput.CustomerEmails = [{ Email: "", EmailName: "", Newslettere: false, publish: epublish }];
                    var cntrycode = this._resourceService.getCookie(empid + "ccode");
                    if (cntrycode.length > 0)
                        cntrycode = cntrycode.substring(1, cntrycode.length);
                    var adid = "";
                    jQuery.each(this._AddressTypes, function () {
                        if (this.Text == "Home") {
                            adid = this.Value;
                            return false;
                        }
                    });
                    this.modelInput.CustomerAddresses = [{ Street: "", Street2: "", CityName: "", Zip: "", CountryCode: cntrycode, StateId: "", AddressTypeId: adid, ForDelivery: false, MainAddress: false }];
                    this.modelInput.CustomerGroups = [];
                    this.Address.CountryCode = "";
                    this.Address.StateId = "";
                    this.modelInput.Safixid = "";
                    this.modelInput.Gender = "0";
                    this.ShowMsg = false;
                    this.Msg = "";
                    this.IsShowAll = false;
                    this._customerService.GetGeneralGroups(this.IsShowAll).subscribe(function (data) {
                        // debugger;
                        if (_this.IsShowAll == false) {
                            jQuery("#groupTree").html("Loding...");
                            var res = jQuery.parseJSON(data).Data;
                            jQuery("#groupTree").kendoTreeView({
                                loadOnDemand: true,
                                checkboxes: {
                                    checkChildren: true
                                },
                                //check: this.onGroupSelect,
                                dataSource: res
                            });
                        }
                        else {
                            jQuery("#groupTree1").html("Loding...");
                            var res = jQuery.parseJSON(data).Data;
                            jQuery("#groupTree1").kendoTreeView({
                                loadOnDemand: true,
                                checkboxes: {
                                    checkChildren: true
                                },
                                //check: this.onGroupSelect,
                                dataSource: res
                            });
                        }
                    }, function (err) {
                    }, function () {
                    });
                };
                AmaxCustomers.prototype.CancelFileAstxt = function () {
                    this.IsFileAstxtShow = true;
                    this.IsFileAstxtShow = false;
                    this.IsCancel = true;
                    jQuery("#FileAstxt").hide();
                    jQuery("#FileAsSpn").show();
                    this.FILEAS_BTN_TEXT = this.RES.CUSTOMER_MASTER.APP_BTN_FILEAS;
                    if (this.modelInput.CustomerId != undefined && this.modelInput.CustomerId != null && parseInt(this.modelInput.CustomerId) > -1) {
                        jQuery("#FileAsSaveBtn").show();
                        this.cssFileAsBtn = "mdi-content-create";
                        jQuery("#FileAsCancelBtn").hide();
                    }
                    else {
                        jQuery("#FileAsSaveBtn").hide();
                        jQuery("#FileAsCancelBtn").hide();
                    }
                };
                AmaxCustomers.prototype.HideShowFileAstxt = function () {
                    var _this = this;
                    if (this.IsFileAstxtShow == false) {
                        this.IsFileAstxtShow = true;
                        jQuery("#FileAstxt").show();
                        jQuery("#FileAsSpn").hide();
                        this.IsCancel = false;
                        this.FILEAS_BTN_TEXT = this.RES.CUSTOMER_MASTER.APP_BTN_SAVEFILEAS;
                        // alert(this.modelInput.CustomerId);
                        if (this.modelInput.CustomerId != undefined && this.modelInput.CustomerId != null && parseInt(this.modelInput.CustomerId) > -1) {
                            jQuery("#FileAsSaveBtn").show();
                            this.cssFileAsBtn = "mdi-content-save";
                            jQuery("#FileAsCancelBtn").show();
                        }
                        else {
                            jQuery("#FileAsSaveBtn").hide();
                            jQuery("#FileAsCancelBtn").hide();
                        }
                    }
                    else {
                        this.IsFileAstxtShow = false;
                        jQuery("#FileAstxt").hide();
                        jQuery("#FileAsSpn").show();
                        this.FILEAS_BTN_TEXT = this.RES.CUSTOMER_MASTER.APP_BTN_FILEAS;
                        if (this.modelInput.CustomerId != undefined && this.modelInput.CustomerId != null && parseInt(this.modelInput.CustomerId) > -1) {
                            jQuery("#FileAsSaveBtn").show();
                            this.cssFileAsBtn = "mdi-content-create";
                            jQuery("#FileAsCancelBtn").hide();
                            if (this.modelInput.FileAs != "" && this.modelInput.FileAs != undefined && this.modelInput.FileAs != null && this.IsCancel == false) {
                                this._customerService.SaveFileAs(this.modelInput.CustomerId, this.modelInput.FileAs).subscribe(function (response) {
                                    response = jQuery.parseJSON(response);
                                    //alert('hello');
                                    if (response.IsError == true) {
                                        //alert(response.ErrMsg);
                                        bootbox.alert({
                                            message: response.ErrMsg, className: _this.ChangeDialog,
                                            buttons: {
                                                ok: {
                                                    //label: 'Ok',
                                                    className: _this.CHANGEDIR
                                                }
                                            }
                                        });
                                    }
                                    //this.IsFileAsSave = false;
                                    bootbox.alert({
                                        message: response.ErrMsg, className: _this.ChangeDialog,
                                        buttons: {
                                            ok: {
                                                //label: 'Ok',
                                                className: _this.CHANGEDIR
                                            }
                                        }
                                    });
                                    _this.IsCancel = true;
                                    //}
                                    //else {
                                    //}
                                });
                            }
                            else {
                                bootbox.alert({
                                    message: this.RES.CUSTOMER_MASTER.APP_EMPTYFILEAS, className: this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: this.CHANGEDIR
                                        }
                                    }
                                });
                                this.bindFileAs();
                                this.IsFileAstxtShow = false;
                                this.HideShowFileAstxt();
                            }
                        }
                        else {
                            jQuery("#FileAsSaveBtn").hide();
                            jQuery("#FileAsCancelBtn").hide();
                        }
                    }
                };
                AmaxCustomers.prototype.SetEmailName = function () {
                    if (this.modelInput.FileAs != undefined && this.modelInput.FileAs != null) {
                        if (this.modelInput.CustomerEmails.length > 0) {
                            this.modelInput.CustomerEmails[this.modelInput.CustomerEmails.length - 1].EmailName = this.modelInput.FileAs;
                        }
                    }
                };
                AmaxCustomers.prototype.CheckCustWithSameName = function () {
                };
                AmaxCustomers.prototype.SetDefaultCust = function () {
                    //alert();
                    //debugger;
                };
                AmaxCustomers.prototype.setdefaultAddress = function () {
                    this.bindFileAs();
                    this.CheckCustWithfnamelnamecompphsemails();
                    var adid = "";
                    var adtext = "Home";
                    if (this.modelInput.Company != "" && this.modelInput.Company != undefined) {
                        adtext = "Work";
                    }
                    jQuery.each(this._AddressTypes, function () {
                        if (this.Text == adtext) {
                            adid = this.Value;
                            return false;
                        }
                    });
                    this.modelInput.CustomerAddresses[this.modelInput.CustomerAddresses.length - 1].AddressTypeId = adid;
                };
                AmaxCustomers.prototype.bindFileAs = function () {
                    if (this.modelInput.FileAs == "" || this.modelInput.FileAs == undefined) {
                        //debugger;
                        if ((this.modelInput.Company == "" || this.modelInput.Company == undefined)) {
                            var fileastext = "";
                            if (this.modelInput.fname != "" && this.modelInput.fname != undefined && this.modelInput.lname != "" && this.modelInput.lname != undefined) {
                                fileastext = this.modelInput.lname + " " + this.modelInput.fname;
                            }
                            else if (this.modelInput.fname != "" && this.modelInput.fname != undefined && (this.modelInput.lname == "" || this.modelInput.lname == undefined)) {
                                fileastext = " " + this.modelInput.fname;
                            }
                            else if ((this.modelInput.fname == "" || this.modelInput.fname == undefined) && (this.modelInput.lname != "" && this.modelInput.lname != undefined)) {
                                fileastext = this.modelInput.lname + " ";
                            }
                            this.modelInput.FileAs = fileastext;
                        }
                        else if ((this.modelInput.lname == "" || this.modelInput.lname == undefined) && (this.modelInput.fname == "" || this.modelInput.lname == undefined)) {
                            var fileastext = "";
                            if ((this.modelInput.Company != "" && this.modelInput.Company != undefined)) {
                                fileastext = this.modelInput.Company;
                            }
                            this.modelInput.FileAs = fileastext;
                        }
                        else
                            this.modelInput.FileAs = "(" + this.modelInput.Company + ") " + this.modelInput.lname + " " + this.modelInput.fname; //+ " " & m_strSpouse
                        if (this.modelInput.CustomerEmails.length > 0) {
                            this.modelInput.CustomerEmails[this.modelInput.CustomerEmails.length - 1].EmailName = this.modelInput.FileAs;
                        }
                    }
                    this.SetEmailName();
                };
                AmaxCustomers.prototype.bindGroup = function () {
                    //alert(this.IsShowAll); this function is calling on click of checkbox
                    var isshow = false;
                    if (this.IsShowAll == true) {
                        isshow = false;
                        this.IsShowAll = false;
                    }
                    else {
                        this.IsShowAll = true;
                        isshow = true;
                    }
                    this.bindGroupTree(isshow);
                };
                AmaxCustomers.prototype.saveCustomerData = function () {
                    var _this = this;
                    //debugger;
                    this.Isbtndisable = "disabled";
                    this.ShowLoader = true;
                    this.getSelectedGroups();
                    var count = 0;
                    if (this.modelInput.CustomerAddresses != undefined && this.modelInput.CustomerAddresses != null) {
                        jQuery.each(this.modelInput.CustomerAddresses, function () {
                            if (this.MainAddress == true) {
                                count = count + 1;
                            }
                            if (count > 1) {
                                //bootbox.alert("Main Address sholud be only one");
                                this.Isbtndisable = "";
                                this.ShowLoader = false;
                                return false;
                            }
                        });
                    }
                    //alert(this.modelInput.BirthDate);
                    if (this.modelInput.BirthDate != "") {
                        if (moment(this.modelInput.BirthDate, "DD-MM-YYYY", true).isValid() == false) {
                            bootbox.alert({ message: "Birthdate is not valid" });
                            this.Isbtndisable = "";
                            this.ShowLoader = false;
                            return false;
                        }
                    }
                    if (count <= 1 || this.modelInput.CustomerAddresses == undefined || this.modelInput.CustomerAddresses == null) {
                        if (this.modelInput.CustomerPhones != undefined && this.modelInput.CustomerPhones != null) {
                            var phtemp = [];
                            jQuery('input[name^="ph"]').each(function () {
                                phtemp.push(jQuery(this).val());
                            });
                            var artemp = [];
                            jQuery('input[name^="ar"]').each(function () {
                                artemp.push(jQuery(this).val());
                            });
                            var pretemp = [];
                            jQuery('input[name^="pre"]').each(function () {
                                pretemp.push(jQuery(this).val());
                            });
                            var i = 0;
                            jQuery.each(this.modelInput.CustomerPhones, function () {
                                if (this.IsSms == true) {
                                    this.IsSms = "1";
                                }
                                else {
                                    this.IsSms = "0";
                                }
                                if (this.phpublish == true) {
                                    this.phpublish = "1";
                                }
                                else {
                                    this.phpublish = "0";
                                }
                                this.Phone = phtemp[i];
                                this.Area = artemp[i];
                                this.Prefix = pretemp[i];
                                i++;
                                //var temp = this.PhoneTypeId.split(';');
                                //this.PhoneTypeId = parseInt(temp[1]);
                                //this.PhoneType = temp[0];
                            });
                        }
                        if (this.modelInput.CustomerEmails != undefined && this.modelInput.CustomerEmails != null) {
                            jQuery.each(this.modelInput.CustomerEmails, function () {
                                if (this.publish == true) {
                                    this.publish = "1";
                                }
                                else {
                                    this.publish = "0";
                                }
                                i++;
                            });
                        }
                        var jdata = JSON.stringify(this.modelInput);
                        console.log(jdata);
                        this._customerService.AddCustomer(jdata).subscribe(function (response) {
                            console.log(response);
                            response = jQuery.parseJSON(response);
                            _this.Isbtndisable = "";
                            _this.ShowLoader = false;
                            if (response.IsError == true) {
                                //alert(response.ErrMsg);
                                _this.MsgClass = "text-danger";
                            }
                            else {
                                //alert(response.ErrMsg);
                                _this.MsgClass = "text-success";
                                var empid = localStorage.getItem("employeeid");
                                _this._resourceService.setCookie(empid + "cust", _this.modelInput.CustomerType, 10);
                                _this._resourceService.setCookie(empid + "emp", _this.modelInput.employeeid, 10);
                                _this._resourceService.setCookie(empid + "src", _this.modelInput.CameFromCustomer, 10);
                                if (_this.modelInput.CustomerAddresses.length > 0)
                                    _this._resourceService.setCookie(empid + "ccode", _this.modelInput.CustomerAddresses[_this.modelInput.CustomerAddresses.length - 1].CountryCode, 10);
                                // debugger;
                                //document.location = this.BaseAppUrl + "Customer/Add/-1";
                                //debugger;
                                _this.TempmodelInput = response.Data;
                                _this.modelInput = response.Data;
                                _this.editCustDet(_this.modelInput);
                            }
                            _this.ShowMsg = true;
                            _this.Msg = response.ErrMsg;
                        }, function (error) { return console.log(error); }, function () { return console.log("Save Call Compleated"); });
                    }
                    else {
                        bootbox.alert({
                            message: this.RES.CUSTOMER_MASTER.APP_MSG_ISMAINADD, className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                        this.Isbtndisable = "";
                        this.ShowLoader = false;
                    }
                };
                AmaxCustomers.prototype.CheckCustWithfnamelnamecompphsemails = function () {
                    var _this = this;
                    var jdata = JSON.stringify(this.modelInput);
                    //debugger;
                    var fname = "";
                    var lname = "";
                    var company = "";
                    var phones = "";
                    var emails = "";
                    if (this.modelInput.fname == undefined)
                        fname = "";
                    else
                        fname = this.modelInput.fname;
                    if (this.modelInput.lname == undefined)
                        lname = "";
                    else
                        lname = this.modelInput.lname;
                    if (this.modelInput.Company == undefined)
                        company = "";
                    else
                        company = this.modelInput.Company;
                    jQuery('input[name^="ph"]').each(function () {
                        if (jQuery(this).val() != "" && jQuery(this).val() != undefined && jQuery(this).val() != null && jQuery(this).val().length >= 3) {
                            phones += jQuery(this).val() + "','";
                        }
                    });
                    if (phones.length > 0)
                        phones = phones.substring(0, phones.length - 3);
                    jQuery.each(this.modelInput.CustomerEmails, function () {
                        if (this.Email != "" && this.Email != undefined && this.Email != null && this.Email.length >= 3) {
                            emails += this.Email + "','";
                        }
                    });
                    if (emails.length > 0)
                        emails = emails.substring(0, emails.length - 3);
                    if ((fname != "" && fname.length >= 2 && lname != "" && lname.length >= 2)
                        || (company != "" && company.length >= 3)
                        || (phones != "")
                        || (emails != "")) {
                        this._customerService.GetCustomersSearchData(fname, lname, company, phones, emails).subscribe(function (response) {
                            //debugger;
                            response = jQuery.parseJSON(response);
                            if (response.IsError == true) {
                                bootbox.alert({
                                    message: response.ErrMsg, className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                            else {
                                _this.CustList = {};
                                _this.CustList = response.Data;
                                if (response.Data != null && response.Data != undefined) {
                                    _this.custSearchData = response.Data;
                                    jQuery('#CustModal').openModal();
                                }
                            }
                        }, function (error) {
                            console.log(error);
                        }, function () {
                            console.log("CallCompleted");
                        });
                    }
                    //this.bindFileAs();
                };
                AmaxCustomers.prototype.CheckCustWithfnamelname = function (fname, lname, company) {
                    var _this = this;
                    var jdata = JSON.stringify(this.modelInput);
                    //debugger;
                    if (this.modelInput.fname == undefined)
                        fname = "";
                    else
                        fname = this.modelInput.fname;
                    if (this.modelInput.lname == undefined)
                        lname = "";
                    else
                        lname = this.modelInput.lname;
                    if (this.modelInput.Company == undefined)
                        company = "";
                    else
                        company = this.modelInput.Company;
                    this._customerService.CheckCustWithSameName(fname, lname, company).subscribe(function (response) {
                        //debugger;
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.CustList = {};
                            _this.CustList = response.Data;
                            if (response.Data != null && response.Data != undefined) {
                                _this.custSearchData = response.Data;
                                jQuery("#CustModal").openModal();
                            }
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //this.bindFileAs();
                };
                AmaxCustomers.prototype.CheckCustWithEmail = function () {
                    //var Email = "";
                    //if (this.EmailModel.Email != "" && this.EmailModel.Email != undefined)
                    //    Email = this.EmailModel.Email;
                    //this._customerService.CheckCustWithSameEmail(Email).subscribe(response=> {
                    //    //debugger;
                    //    response = jQuery.parseJSON(response);
                    //    if (response.IsError == true) {
                    //        alert(response.ErrMsg);
                    //    }
                    //    else {
                    //        this.CustList = {};
                    //        this.CustList = response.Data;
                    //        if (response.Data != null && response.Data != undefined) {
                    //            this.custSearchData = response.Data;
                    //            jQuery("#CustModal").modal("show");
                    //        }
                    //        //alert(this.RES);
                    //    }
                    //}, error=> {
                    //    console.log(error);
                    //}, () => {
                    //    console.log("CallCompleted")
                    //});
                };
                AmaxCustomers.prototype.CheckCustWithPhone = function () {
                    var _this = this;
                    var Phone = "";
                    if (this.PhoneModel.Phone != "" && this.PhoneModel.Phone != undefined)
                        Phone = this.PhoneModel.Phone;
                    this._customerService.CheckCustWithSamePhone(this.PhoneModel.Phone).subscribe(function (response) {
                        //debugger;
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.CustList = {};
                            _this.CustList = response.Data;
                            if (response.Data != null && response.Data != undefined) {
                                _this.custSearchData = response.Data;
                                jQuery("#CustModal").openModal();
                            }
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxCustomers.prototype.ShowRemarks = function (PhObj) {
                    jQuery.each(this.modelInput.CustomerPhones, function () {
                        if (this == PhObj) {
                            this.IsShowRemarks = true;
                        }
                    });
                };
                AmaxCustomers.prototype.showAddPopup = function () {
                    this.Address = {};
                    this.PhoneModel = {};
                    this.PhoneModel.PhoneTypeId = "";
                    this.Address.CountryCode = "";
                    this.Address.StateId = "";
                    this.Address.CityName = "";
                    this.Address.AddressTypeId = "";
                    this.EmailModel = {};
                    this.BTN_PHADD = this.RES.CUSTOMER_MASTER.APP_BTN_PHADD;
                };
                AmaxCustomers.prototype.showhideGroups = function () {
                    //debugger;
                    if (this.ShowGroups == false) {
                        this.ShowGroups = true;
                        this.GroupText = this.RES.CUSTOMER_MASTER.APP_LBL_HIDEGROUP;
                        jQuery("#GrpDiv").show(1000);
                    }
                    else {
                        this.ShowGroups = false;
                        this.GroupText = this.RES.CUSTOMER_MASTER.APP_LBL_SHOWGROUPS;
                        jQuery("#GrpDiv").hide(1000);
                    }
                };
                AmaxCustomers.prototype.CanaddAddress = function (adobj) {
                    //alert('Hello');
                    return (adobj.Street != undefined && adobj.Street != "")
                        && (adobj.Street2 != undefined && adobj.Street2 != "")
                        && (adobj.Zip != undefined && adobj.Zip != "")
                        && (adobj.CountryCode != undefined && adobj.CountryCode != "")
                        && (adobj.AddressTypeId != undefined && adobj.AddressTypeId != "");
                };
                AmaxCustomers.prototype.AddAddresses = function (adobj) {
                    var IsMainAdd = false;
                    adobj.CityName = jQuery("#City").val();
                    if (this.CanaddAddress(adobj)) {
                        var empid = localStorage.getItem("employeeid");
                        this._resourceService.setCookie(empid + "ccode", adobj.CountryCode, 10);
                        var adid = "";
                        var adtext = "Home";
                        if (this.modelInput.Company != "" && this.modelInput.Company != undefined) {
                            adtext = "Work";
                        }
                        jQuery.each(this._AddressTypes, function () {
                            if (this.Text == adtext) {
                                adid = this.Value;
                                return false;
                            }
                        });
                        var AddresObj = { Street: "", Street2: "", CityName: "", Zip: "", CountryCode: adobj.CountryCode, StateId: "", AddressTypeId: adid, ForDelivery: false, MainAddress: false, MainOrder: "MainAddr" + (this.modelInput.CustomerAddresses.length + 1).toString(), DelvryOrder: "Delvry" + (this.modelInput.CustomerAddresses.length + 1).toString() };
                        //jQuery.each(this.modelInput.CustomerAddresses, function () {
                        //    if (this.MainAddress == true && adobj.MainAddress == true && this != adobj) {
                        //        adobj.MainAddress = false;
                        //        return false;
                        //    }
                        //});
                        if (IsMainAdd == false) {
                            this.modelInput.CustomerAddresses.push(AddresObj);
                        }
                    }
                    else {
                        var msg = '';
                        if (adobj.Street == undefined || adobj.Street == "") {
                            //msg += '\nStreet is not filled'; APP_AL_MSG_STREET
                            msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_MSG_STREET;
                        }
                        if (adobj.Street2 == undefined || adobj.Street2 == "") {
                            //msg += '\nArea is not filled';
                            msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_MSG_AREA;
                        }
                        //if (adobj.CityName == undefined || adobj.CityName == "")
                        //    //msg += '\nCity is not filled'; 
                        //    msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_MSG_CITY;
                        if (adobj.Zip == undefined || adobj.Zip == "") {
                            //msg += '\nZip is not filled'; 
                            msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_MSG_ZIP;
                        }
                        if (adobj.CountryCode == undefined || adobj.CountryCode == "") {
                            //msg += '\nCountry is not selected';
                            msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_MSG_COUNTRY;
                        }
                        //if (this.Address.StateId == undefined || this.Address.StateId == "") {
                        //    msg += '\nState is not selected';
                        //}
                        if (adobj.AddressTypeId == undefined || adobj.AddressTypeId == "") {
                            //msg += '\nAddress type is not selected';
                            msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_MSG_ADTYPE;
                        }
                        bootbox.alert({
                            message: msg, className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                    }
                };
                AmaxCustomers.prototype.CanaddPhone = function (phoneObj) {
                    //debugger;
                    //alert(this.PhoneModel.PhoneTypeId + ' ' + this.PhoneModel.PhoneType + ' ' + this.PhoneModel.Prefix + ' ' + this.PhoneModel.Area + ' ' + this.PhoneModel.Phone);
                    return (phoneObj.PhoneTypeId != undefined && phoneObj.PhoneTypeId != "");
                    // && (this.PhoneModel.PhoneType != undefined&& this.PhoneModel.PhoneType != "" )
                    //&& (this.PhoneModel.Prefix != undefined&& this.PhoneModel.Prefix != ""  )
                    //&& (this.PhoneModel.Area != undefined&&this.PhoneModel.Area != ""  )
                    //&& (phoneObj.Phone != undefined && phoneObj.Phone != "");
                    //&& (this.PhoneModel.Prefix != undefined && this.PhoneModel.Prefix.length != 3);            ;
                };
                AmaxCustomers.prototype.AddPhones = function (phoneObj) {
                    if (this.CanaddPhone(phoneObj)) {
                        debugger;
                        //if (this.IsRecordEditMode == false) {
                        var phid = "";
                        var SMS = 0;
                        var publish = 0;
                        jQuery.each(this._PhoneTypes, function () {
                            if (this.Text == "CellPhone") {
                                phid = this.Value;
                                SMS = 1;
                                publish = 1;
                                return false;
                            }
                        });
                        var PhoneObj = { PhoneTypeId: phid, PhoneType: "", Prefix: "", Area: "", Phone: "", IsSms: SMS, Comments: "", IsShowRemarks: false, phpublish: publish, SMSOrder: "SMS" + (this.modelInput.CustomerPhones.length + 1).toString(), PublishOrder: "Pub" + (this.modelInput.CustomerPhones.length + 1).toString() };
                        this.modelInput.CustomerPhones.push(PhoneObj);
                    }
                    else {
                        var msg = '';
                        if (phoneObj.PhoneTypeId == undefined || phoneObj.PhoneTypeId == "") {
                            //msg += '\nPhone type is not selected';
                            msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_REGMSG_PHTYPE;
                        }
                        //if (phoneObj.Phone == undefined || phoneObj.Phone == "") {
                        //    //msg += '\nPhone number is not filled';
                        //    msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_REGMSG_PHNO;
                        //}
                        //if (this.PhoneModel.Prefix.length!=3) {
                        //    msg += '\nPrefix must of 3 numeric digits';
                        //}
                        bootbox.alert({
                            message: msg, className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                    }
                };
                AmaxCustomers.prototype.CanaddEmail = function (EmailObj) {
                    //debugger;
                    //alert('Hello');
                    return (EmailObj.EmailName != undefined && EmailObj.EmailName != "");
                    //(EmailObj.Email != undefined && EmailObj.Email != "") &&
                };
                AmaxCustomers.prototype.AddEmails = function (EmailObj) {
                    //debugger;
                    if (this.CanaddEmail(EmailObj)) {
                        var epublish = 0;
                        jQuery.each(this._PhoneTypes, function () {
                            if (this.Text == "CellPhone") {
                                epublish = 1;
                                return false;
                            }
                        });
                        //if (this.IsRecordEditMode == false) {
                        var eObj = {};
                        eObj.Email = "";
                        eObj.EmailName = this.modelInput.FileAs;
                        eObj.Newslettere = true;
                        eObj.publish = epublish;
                        eObj.NewsOrder = "News" + (this.modelInput.CustomerEmails.length + 1).toString();
                        eObj.EPublishOrder = "EPub" + (this.modelInput.CustomerEmails.length + 1).toString();
                        this.modelInput.CustomerEmails.push(eObj);
                    }
                    else {
                        var msg = '';
                        //if (EmailObj.Email == undefined || EmailObj.Email == "")
                        //    //msg += '\nEmail is not filled';
                        //    msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_REGMSG_EMAIL;
                        if (EmailObj.EmailName == undefined || EmailObj.EmailName == "") {
                            //msg += '\nName is not filled';
                            msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_REGMSG_ENAME;
                        }
                        bootbox.alert({
                            message: msg, className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                    }
                    // this.modelInput.CustomerAddresses = this.CustomerAddresses;
                };
                AmaxCustomers.prototype.editCustDet = function (Obj) {
                    var _this = this;
                    this._customerService.GetCompleteCustDet(Obj.CustomerId).subscribe(function (response) {
                        // debugger;
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.modelInput = response.Data;
                            _this.SAVE_BTN_TEXT = _this.RES.CUSTOMER_MASTER.APP_BTN_UPDATE;
                            //this.ADD_NEW_CUST_TEXT = this.RES.CUSTOMER_MASTER.APP_LBL_UPDATE_CUST;
                            _this.CSSTEXT = "mdi-content-add";
                            if (_this.modelInput.CustomerEmails.length == 0) {
                                _this.modelInput.CustomerEmails = [{ Email: "", EmailName: _this.modelInput.FileAs, Newslettere: false, publish: 0, NewsOrder: "News1", EPublishOrder: "EPub1" }];
                            }
                            else {
                                var count = 1;
                                jQuery.each(_this.modelInput.CustomerEmails, function () {
                                    this.NewsOrder = "News" + count;
                                    this.EPublishOrder = "EPub" + count++;
                                });
                            }
                            if (_this.modelInput.CustomerPhones.length == 0) {
                                var phid = "";
                                jQuery.each(_this._PhoneTypes, function () {
                                    if (this.Text == "CellPhone") {
                                        phid = this.Value;
                                        return false;
                                    }
                                });
                                _this.modelInput.CustomerPhones = [{ PhoneTypeId: phid, Prefix: "", Area: "", Phone: "", IsSms: 0, Comments: "", phpublish: 0, SMSOrder: "SMS1", PublishOrder: "Pub1" }];
                            }
                            else {
                                var count = 1;
                                jQuery.each(_this.modelInput.CustomerPhones, function () {
                                    this.SMSOrder = "SMS" + count;
                                    this.PublishOrder = "Pub" + count++;
                                });
                            }
                            if (_this.modelInput.CustomerAddresses.length == 0) {
                                var empid = localStorage.getItem("employeeid");
                                var ccode = _this._resourceService.getCookie(empid + "ccode");
                                if (ccode.length > 0)
                                    ccode = ccode.substring(1, ccode.length);
                                var adid = "";
                                var comptext = "Home";
                                if (_this.modelInput.Company != "" && _this.modelInput.Company != undefined && _this.modelInput.Company != null) {
                                    comptext = "Work";
                                }
                                jQuery.each(_this._AddressTypes, function () {
                                    if (this.Text == comptext) {
                                        adid = this.Value;
                                        return false;
                                    }
                                });
                                _this.modelInput.CustomerAddresses = [{ Street: "", Street2: "", CityName: "", Zip: "", CountryCode: ccode, StateId: "", AddressTypeId: adid, ForDelivery: false, MainAddress: false, MainOrder: "MainAddr1", DelvryOrder: "Delvry1" }];
                            }
                            else {
                                var count = 1;
                                jQuery.each(_this.modelInput.CustomerAddresses, function () {
                                    this.MainOrder = "MainAddr" + count;
                                    this.DelvryOrder = "Delvry" + count++;
                                });
                            }
                            //var treeview = jQuery("#groupTree").data("kendoTreeView");
                            //var bar = treeview.findById("Bar");
                            //jQuery.each(this.modelInput.CustomerGroups, function () {
                            //    var data = jQuery("#groupTree").data("kendoTreeView").dataSource.getByUid(this.CustomerGeneralGroupId);
                            //    if (data) {
                            //        data.set("checked", true);
                            //    }
                            //    //var GroupNode = treeview.findById(this.CustomerGeneralGroupId);
                            //    //treeview.dataItem(GroupNode).set("checked", true);
                            //});
                            _this.CustIdText = "( " + _this.modelInput.CustomerId + " )";
                            _this.IsFileAstxtShow = false;
                            _this.HideShowFileAstxt();
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxCustomers.prototype.CheckPhoneType = function (PhoneObj) {
                    var _this = this;
                    //debugger;
                    //alert(PhoneObj.PhoneTypeId + " | " + jQuery("#PhoneType").val());
                    var pretemp = [];
                    jQuery('select[name^="phtype"]').each(function () {
                        pretemp.push(jQuery(this).val());
                    });
                    var index = 0;
                    jQuery.each(this.modelInput.CustomerPhones, function () {
                        if (this == PhoneObj) {
                            return false;
                        }
                        index = index + 1;
                    });
                    if (pretemp[index] != undefined && pretemp[index] != null && pretemp[index] != "") {
                        var PhoneTypeId = pretemp[index];
                        this._customerService.GetPhoneTypeDet(PhoneTypeId).subscribe(function (data) {
                            //debugger;
                            //
                            var response = jQuery.parseJSON(data);
                            if (response.IsError == true) {
                                bootbox.alert({
                                    message: response.ErrMsg, className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                            else {
                                if (response.Data != undefined && response.Data != null && response.Data != "") {
                                    //debugger;
                                    //alert(index + " | " + this.modelInput.CustomerPhones[index].IsSms + " | " + response.Data.Text);
                                    if (response.Data.Text == "1") {
                                        _this.modelInput.CustomerPhones[index].IsSms = 1;
                                        _this.modelInput.CustomerPhones[index].phpublish = 1;
                                        _this.modelInput.CustomerEmails[_this.modelInput.CustomerEmails.length - 1].publish = 1;
                                    }
                                    else {
                                        _this.modelInput.CustomerPhones[index].phpublish = 0;
                                        _this.modelInput.CustomerPhones[index].IsSms = 0;
                                        _this.modelInput.CustomerEmails[_this.modelInput.CustomerEmails.length - 1].publish = 0;
                                    }
                                }
                            }
                            //var treeviewDataSource = jQuery("#groupTree").data("kendoTreeView").dataSource.view();
                        }, function (err) {
                        }, function () {
                        });
                    }
                };
                AmaxCustomers.prototype.editEmailDet = function (EmailObj) {
                    //debugger;
                    var index = 0;
                    this.IsRecordEditMode = true;
                    this.BTN_PHADD = this.RES.CUSTOMER_MASTER.APP_BTN_PHEDIT;
                    this.EmailModel.Email = EmailObj.Email;
                    this.EmailModel.EmailName = EmailObj.EmailName;
                    this.EmailModel.Newslettere = EmailObj.Newslettere;
                    this.EditEmailData = {};
                    this.EditEmailData = EmailObj;
                };
                AmaxCustomers.prototype.delEmailDet = function (EmailObj) {
                    //debugger;
                    var index = 0;
                    jQuery.each(this.modelInput.CustomerEmails, function () {
                        if (this == EmailObj) {
                            return false;
                        }
                        index = index + 1;
                    });
                    this.modelInput.CustomerEmails.splice(index, 1);
                };
                AmaxCustomers.prototype.editAddressDet = function (AddressObj) {
                    //debugger;
                    var index = 0;
                    this.IsRecordEditMode = true;
                    this.BTN_PHADD = this.RES.CUSTOMER_MASTER.APP_BTN_PHEDIT;
                    // AddressObj.CityName = jQuery("#City").val();
                    this.Address.Street = AddressObj.Street;
                    this.Address.Street2 = AddressObj.Street2;
                    this.Address.CityName = AddressObj.CityName;
                    this.Address.Zip = AddressObj.Zip;
                    this.Address.CountryCode = AddressObj.CountryCode;
                    this.Address.StateId = AddressObj.StateId;
                    this.Address.AddressTypeId = AddressObj.AddressTypeId;
                    this.Address.MainAddress = AddressObj.MainAddress;
                    this.Address.ForDelivery = AddressObj.ForDelivery;
                    this.EditAddressData = {};
                    this.EditAddressData = AddressObj;
                };
                AmaxCustomers.prototype.delAddressDet = function (AddressObj) {
                    // debugger; 
                    var index = 0;
                    jQuery.each(this.modelInput.CustomerAddresses, function () {
                        if (this == AddressObj) {
                            return false;
                        }
                        index = index + 1;
                    });
                    this.modelInput.CustomerAddresses.splice(index, 1);
                };
                AmaxCustomers.prototype.editPhoneDet = function (PhoneObj) {
                    var index = 0;
                    this.BTN_PHADD = this.RES.CUSTOMER_MASTER.APP_BTN_PHEDIT;
                    var temp = PhoneObj.PhoneTypeId.split(';');
                    this.PhoneModel.PhoneTypeId = PhoneObj.PhoneType + ";" + PhoneObj.PhoneTypeId;
                    this.PhoneModel.PhoneType = PhoneObj.PhoneType;
                    this.PhoneModel.Prefix = PhoneObj.Prefix;
                    this.PhoneModel.Area = PhoneObj.Area;
                    this.PhoneModel.Phone = PhoneObj.Phone;
                    this.PhoneModel.IsSms = PhoneObj.IsSms;
                    this.PhoneModel.Comments = PhoneObj.Comments;
                    this.EditPhoneData = {};
                    this.EditPhoneData = PhoneObj;
                };
                AmaxCustomers.prototype.delPhoneDet = function (PhoneObj) {
                    var index = 0;
                    jQuery.each(this.modelInput.CustomerPhones, function () {
                        if (this == PhoneObj) {
                            return false;
                        }
                        index = index + 1;
                    });
                    this.modelInput.CustomerPhones.splice(index, 1);
                };
                AmaxCustomers.prototype.getSelectedGroups = function () {
                    this.modelInput.CustomerGroups = [];
                    var _CheckedGroups = [];
                    if (this.IsShowAll == false) {
                        amaxUtil_1.Kendo_utility.checkedNodeIds(jQuery("#groupTree").data("kendoTreeView").dataSource.view(), _CheckedGroups);
                    }
                    else {
                        amaxUtil_1.Kendo_utility.checkedNodeIds(jQuery("#groupTree1").data("kendoTreeView").dataSource.view(), _CheckedGroups);
                    }
                    for (var i = 0; i < _CheckedGroups.length; i++) {
                        var GObj = {};
                        GObj.CustomerGeneralGroupId = _CheckedGroups[i];
                        this.modelInput.CustomerGroups.push(GObj);
                    }
                };
                AmaxCustomers.prototype.More = function () {
                    // alert("call");
                    if (this.ShowMore == true) {
                        this.ShowMore = false;
                        //this.ShowMoreText = "More";
                        this.ShowMoreText = this.RES.CUSTOMER_MASTER.APP_LNK_LBL_MORE;
                    }
                    else {
                        this.ShowMore = true;
                        //this.ShowMoreText = "Less"; 
                        this.ShowMoreText = this.RES.CUSTOMER_MASTER.APP_LNK_LBL_LESS;
                    }
                };
                AmaxCustomers.prototype.bindGroupTree = function (Isshowall) {
                    var _this = this;
                    this._customerService.GetGeneralGroups(Isshowall).subscribe(function (data) {
                        //debugger;
                        //
                        //alert(Isshowall);
                        if (Isshowall == false) {
                            jQuery("#groupTree").html("Loding...");
                            var res = jQuery.parseJSON(data).Data;
                            jQuery("#groupTree").kendoTreeView({
                                loadOnDemand: true,
                                checkboxes: {
                                    checkChildren: true
                                },
                                //check: this.onGroupSelect,
                                dataSource: res
                            });
                            var grpids = "";
                            jQuery.each(_this.modelInput.CustomerGroups, function () {
                                grpids += this.CustomerGeneralGroupId + ";";
                            });
                            if (grpids.length > 0) {
                                amaxUtil_1.Kendo_utility.checkingNodeIds(jQuery("#groupTree").data("kendoTreeView").dataSource.view(), grpids.substring(0, grpids.length - 1));
                            }
                        }
                        else {
                            jQuery("#groupTree1").html("Loding...");
                            var res = jQuery.parseJSON(data).Data;
                            jQuery("#groupTree1").kendoTreeView({
                                loadOnDemand: true,
                                checkboxes: {
                                    checkChildren: true
                                },
                                //check: this.onGroupSelect,
                                dataSource: res
                            });
                            var grpids = "";
                            jQuery.each(_this.modelInput.CustomerGroups, function () {
                                grpids += this.CustomerGeneralGroupId + ";";
                            });
                            if (grpids.length > 0) {
                                amaxUtil_1.Kendo_utility.checkingNodeIds(jQuery("#groupTree1").data("kendoTreeView").dataSource.view(), grpids.substring(0, grpids.length - 1));
                            }
                        }
                        //var treeviewDataSource = jQuery("#groupTree").data("kendoTreeView").dataSource.view();
                    }, function (err) {
                    }, function () {
                    });
                };
                AmaxCustomers.prototype.GetDataForSearch = function (event) {
                    //this.SearchVal = jQuery("#Searchtxt").val();
                    //alert(event.keyCode);
                    //if (this.SearchVal != undefined && this.SearchVal != "" && this.SearchVal != null && event.keyCode == 13) {
                    //alert(this.autocompleteSelect + " " + this.autocompleteNoResults);
                    //    this.EnterCount++;
                    //    if (this.EnterCount >= 2) {
                    //        this._customerService.GetCompleteSearch(this.SearchVal).subscribe(response=> {
                    //            response = jQuery.parseJSON(response);
                    //            if (response.IsError == true) {
                    //                alert(response.ErrMsg);
                    //            }
                    //            else {
                    //                this.CustList = {};
                    //                this.CustList = response.Data;
                    //                if (response.Data != null && response.Data != undefined) {
                    //                    this.custSearchData = response.Data;
                    //                    jQuery("#CustModal").modal("show");
                    //                }
                    //            }
                    //        }, error=> {
                    //            console.log(error);
                    //        }, () => {
                    //            console.log("CallCompleted")
                    //        });
                    //        this.EnterCount = 0;
                    //    }
                    //}
                    //this.SearchVal = "";
                };
                AmaxCustomers.prototype.ngOnInit = function () {
                    var _this = this;
                    // debugger;
                    //bootbox.alert("This is the default alert!");
                    if (localStorage.getItem("lang") == "") {
                        localStorage.setItem("lang", "en");
                    }
                    if (this._resourceService.getCookie("lang") == "") {
                        this._resourceService.setCookie("lang", "en", 10);
                    }
                    this.IsCancel = false;
                    this.showhideGroups();
                    this.IsFileAstxtShow = true;
                    //this.modelInput.CustomerId = -1;
                    if (this.modelInput.CustomerId >= 0) {
                        //this.IsFileAstxtShow = false;
                        this.editCustDet(this.modelInput);
                        this.SAVE_BTN_TEXT = this.RES.CUSTOMER_MASTER.APP_BTN_UPDATE;
                        //this.ADD_NEW_CUST_TEXT = this.RES.CUSTOMER_MASTER.APP_LBL_UPDATE_CUST;
                        //this.CSSTEXT = "mdi-content-add";
                        if (this.modelInput.CustomerAddresses.length == 0) {
                            var empid = localStorage.getItem("employeeid");
                            var ccode = this._resourceService.getCookie(empid + "ccode");
                            if (ccode.length > 0)
                                ccode = ccode.substring(1, ccode.length);
                            var adid = "";
                            var comptext = "Home";
                            if (this.modelInput.Company != "" && this.modelInput.Company != undefined && this.modelInput.Company != null) {
                                comptext = "Work";
                            }
                            jQuery.each(this._AddressTypes, function () {
                                if (this.Text == comptext) {
                                    adid = this.Value;
                                    return false;
                                }
                            });
                            this.modelInput.CustomerAddresses = [{ Street: "", Street2: "", CityName: "", Zip: "", CountryCode: ccode, StateId: "", AddressTypeId: adid, ForDelivery: false, MainAddress: false, MainOrder: "MainAddr1", DelvryOrder: "Delvry1" }];
                        }
                        this.CustIdText = "( " + this.modelInput.CustomerId + " )";
                        this.IsFileAstxtShow = false;
                    }
                    this.Lang = this._resourceService.getCookie("lang");
                    if (this.Lang.length > 0) {
                        this.Lang = this.Lang.substring(1, this.Lang.length);
                    }
                    this.HideShowFileAstxt();
                    //this.RES = jQuery.parseJSON(this._customerService.GetLangRes(this.Formtype, this.Lang)).Data; //jQuery.parseJSON(localStorage.getItem("langresource"));
                    if (this.Lang == "he") {
                        this.KendoRTLCSS = "k-rtl";
                        this.CHANGEDIR = "rtlmodal";
                        this.ChangeDialog = "input_right";
                    }
                    else {
                        this.CHANGEDIR = "ltrmodal";
                        this.ChangeDialog = "input_left";
                    }
                    this._resourceService.GetLangRes(this.Formtype, this.Lang).subscribe(function (response) {
                        //debugger;
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.RES = response.Data;
                            _this.ShowMoreText = _this.RES.CUSTOMER_MASTER.APP_LNK_LBL_MORE;
                            _this.GroupText = _this.RES.CUSTOMER_MASTER.APP_LBL_SHOWGROUPS;
                            _this.SAVE_BTN_TEXT = _this.RES.CUSTOMER_MASTER.APP_BTN_SAVE;
                            _this.ADD_NEW_CUST_TEXT = _this.RES.CUSTOMER_MASTER.APP_LBL_NEW_CUST;
                            _this.FILEAS_BTN_TEXT = _this.RES.CUSTOMER_MASTER.APP_BTN_FILEAS;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //this.ShowMoreText = "More";
                    ////Cities
                    var CountryCode = this.Address.CountryCode;
                    var StateName = this.Address.StateId;
                    this._customerService.GetCities(CountryCode, StateName).subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            var typeaheadSource = [];
                            jQuery.each(response.Data, function () {
                                var newtemp = {};
                                newtemp.id = this.Value;
                                newtemp.name = this.Text;
                                typeaheadSource.push(newtemp);
                            });
                            _this._Cities = response.Data;
                            jQuery('#City').typeahead({
                                //data: this._Cities,
                                source: typeaheadSource,
                                //display: "text",
                                dataType: "JSON",
                            });
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this.languageArray = this._resourceService.GetAvailableLanguages();
                    this._customerService.GetCustomerTypes().subscribe(function (resp) {
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._CustTypes = response.Data;
                            if (_this.modelInput.CustomerType == "" || _this.modelInput.CustomerType == undefined || _this.modelInput.CustomerType == null) {
                                var CusttypeId;
                                jQuery.each(_this._CustTypes, function () {
                                    CusttypeId = this.Value;
                                    return false;
                                });
                                _this.modelInput.CustomerType = CusttypeId;
                            }
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    ////Sources
                    this._customerService.GetSources().subscribe(function (resp) {
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Sources = response.Data;
                            if (_this.modelInput.CameFromCustomer == "" || _this.modelInput.CameFromCustomer == undefined || _this.modelInput.CameFromCustomer == null) {
                                var Source;
                                jQuery.each(_this._Sources, function () {
                                    Source = this.Value;
                                    return false;
                                });
                                _this.modelInput.CameFromCustomer = Source;
                            }
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //GetEmployees
                    this._customerService.GetEmployees().subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Employees = response.Data;
                            if (_this.modelInput.employeeid == "" || _this.modelInput.employeeid == undefined || _this.modelInput.employeeid == null) {
                                var empid;
                                jQuery.each(_this._Employees, function () {
                                    empid = this.Value;
                                    return false;
                                });
                                _this.modelInput.employeeid = empid;
                            }
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //GetSuffixes
                    this._customerService.GetSuffixes().subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Suffixes = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //GetPhoneTypes
                    this._customerService.GetPhoneTypes().subscribe(function (response) {
                        // debugger;
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._PhoneTypes = response.Data;
                            var phid = "";
                            jQuery.each(_this._PhoneTypes, function () {
                                if (this.Text == "CellPhone") {
                                    phid = this.Value;
                                    return false;
                                }
                            });
                            _this.modelInput.CustomerPhones[0].PhoneTypeId = phid;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    var epublish = 0;
                    if (this.modelInput.CustomerPhones.length == 0) {
                        var phid = "";
                        jQuery.each(this._PhoneTypes, function () {
                            if (this.Text == "CellPhone") {
                                phid = this.Value;
                                epublish = 1;
                                return false;
                            }
                        });
                        this.modelInput.CustomerPhones = [{ PhoneTypeId: phid, Prefix: "", Area: "", Phone: "", IsSms: epublish, Comments: "", phpublish: epublish, SMSOrder: "SMS1", PublishOrder: "Pub1" }];
                    }
                    if (this.modelInput.CustomerEmails.length == 0) {
                        this.modelInput.CustomerEmails = [{ Email: "", EmailName: this.modelInput.FileAs, Newslettere: false, publish: epublish, NewsOrder: "News1", EPublishOrder: "EPub1" }];
                    }
                    //GetAddressTypes
                    this._customerService.GetAddressTypes().subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._AddressTypes = response.Data;
                            // debugger;
                            var adid = "";
                            jQuery.each(_this._AddressTypes, function () {
                                if (this.Text == "Home") {
                                    adid = this.Value;
                                    return false;
                                }
                            });
                            _this.modelInput.CustomerAddresses[0].AddressTypeId = adid;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //Groups
                    this._customerService.GetGroups().subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Groups = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    ////Countries
                    this._customerService.GetCountries().subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Countries = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    ////States
                    var CountryCode = this.Address.CountryCode;
                    this._customerService.GetStates(CountryCode).subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._States = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //Tree Group
                    //this.bindGroupTree(this.IsShowAll);
                    this._customerService.GetGeneralGroups(this.IsShowAll).subscribe(function (data) {
                        // debugger;
                        if (_this.IsShowAll == false) {
                            jQuery("#groupTree").html("Loding...");
                            var res = jQuery.parseJSON(data).Data;
                            jQuery("#groupTree").kendoTreeView({
                                loadOnDemand: true,
                                checkboxes: {
                                    checkChildren: true
                                },
                                //check: this.onGroupSelect,
                                dataSource: res
                            });
                            var grpids = "";
                            jQuery.each(_this.modelInput.CustomerGroups, function () {
                                grpids += this.CustomerGeneralGroupId + ";";
                            });
                            if (grpids.length > 0) {
                                amaxUtil_1.Kendo_utility.checkingNodeIds(jQuery("#groupTree").data("kendoTreeView").dataSource.view(), grpids.substring(0, grpids.length - 1));
                            }
                        }
                        else {
                            jQuery("#groupTree1").html("Loding...");
                            var res = jQuery.parseJSON(data).Data;
                            jQuery("#groupTree1").kendoTreeView({
                                loadOnDemand: true,
                                checkboxes: {
                                    checkChildren: true
                                },
                                //check: this.onGroupSelect,
                                dataSource: res
                            });
                            var grpids = "";
                            jQuery.each(_this.modelInput.CustomerGroups, function () {
                                grpids += this.CustomerGeneralGroupId + ";";
                            });
                            if (grpids.length > 0) {
                                amaxUtil_1.Kendo_utility.checkingNodeIds(jQuery("#groupTree1").data("kendoTreeView").dataSource.view(), grpids.substring(0, grpids.length - 1));
                            }
                        }
                    }, function (err) {
                    }, function () {
                    });
                    //alert(moment().format('D MMM YYYY'));       
                    // this.baseUrl + "Dropdown/BindAutoCompleteSrch"
                    var SrchData = null;
                    //alert('Hi');
                    jQuery("#EmailTable tbody tr td a[name=delEbtn]").not(":last").hide();
                    jQuery("#EmailTable tbody tr a[name=addEbtn]").not(":last").show();
                    //$('.modal').modal();
                };
                AmaxCustomers.$inject = ['$scope', '$location', '$anchorScroll'];
                AmaxCustomers = __decorate([
                    core_1.Component({
                        templateUrl: './app/amax/Customer/templates/customer.html',
                        directives: [common_1.NgSwitch, common_1.NgSwitchWhen, common_1.NgSwitchDefault, AUTOCOMPLETE_DIRECTIVES, common_1.CORE_DIRECTIVES, common_1.FORM_DIRECTIVES, basicComponents_1.AmaxDate],
                        providers: [CustomerService_1.CustomerService, ResourceService_1.ResourceService]
                    }), 
                    __metadata('design:paramtypes', [ResourceService_1.ResourceService, CustomerService_1.CustomerService, router_1.RouteParams])
                ], AmaxCustomers);
                return AmaxCustomers;
            }());
            exports_1("AmaxCustomers", AmaxCustomers);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldi9hbWF4L0N1c3RvbWVyTm90ZXMvQ3VzdG9tZXJOb3Rlcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7O1FBV2EsdUJBQXVCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1lBQXZCLHFDQUFBLHVCQUF1QixHQUFHLENBQUMscUNBQVksRUFBRSw4Q0FBcUIsQ0FBQyxDQUFBLENBQUM7WUFXN0U7Z0JBaUZJLHVCQUFvQixnQkFBaUMsRUFBVSxnQkFBaUMsRUFBVSxZQUF5QjtvQkFBL0cscUJBQWdCLEdBQWhCLGdCQUFnQixDQUFpQjtvQkFBVSxxQkFBZ0IsR0FBaEIsZ0JBQWdCLENBQWlCO29CQUFVLGlCQUFZLEdBQVosWUFBWSxDQUFhO29CQWhGbkksZUFBVSxHQUFHLEVBQUUsQ0FBQztvQkFDaEIsbUJBQWMsR0FBRyxFQUFFLENBQUM7b0JBQ3BCLG1CQUFjLEdBQVcsRUFBRSxDQUFDO29CQUM1QixRQUFHLEdBQVcsRUFBRSxDQUFDO29CQUNqQixtQkFBYyxHQUFXLEVBQUUsQ0FBQztvQkFDNUIsa0JBQWEsR0FBVyxFQUFFLENBQUM7b0JBQzNCLGFBQVEsR0FBVSxpQkFBaUIsQ0FBQztvQkFDcEMsU0FBSSxHQUFTLEVBQUUsQ0FBQztvQkFDaEIsdUJBQXVCO29CQUN2QixhQUFRLEdBQVksS0FBSyxDQUFDO29CQUMxQixxQkFBZ0IsR0FBWSxLQUFLLENBQUM7b0JBQ2xDLGlCQUFZLEdBQVcsTUFBTSxDQUFDO29CQUU5QixlQUFVLEdBQVksS0FBSyxDQUFDO29CQUM1QixZQUFPLEdBQVksS0FBSyxDQUFDO29CQUN6QixlQUFVLEdBQVksSUFBSSxDQUFDO29CQUMzQixjQUFTLEdBQVMsYUFBYSxDQUFDO29CQUNoQyxRQUFHLEdBQVcsRUFBRSxDQUFDO29CQUNqQixhQUFRLEdBQVcsY0FBYyxDQUFDO29CQUNsQyxpQkFBWSxHQUFXLEVBQUUsQ0FBQztvQkFDMUIsb0JBQWUsR0FBVyxFQUFFLENBQUM7b0JBQzdCLHNCQUFpQixHQUFXLEVBQUUsQ0FBQztvQkFDL0Isa0JBQWEsR0FBRyxFQUFFLENBQUM7b0JBRW5CLFlBQU8sR0FBVyxFQUFFLENBQUM7b0JBQ3JCLGVBQVUsR0FBVyxFQUFFLENBQUM7b0JBQ3hCLGVBQVUsR0FBVyxFQUFFLENBQUM7b0JBQ3hCLGNBQVMsR0FBWSxLQUFLLENBQUM7b0JBQzNCLGFBQVEsR0FBVyxFQUFFLENBQUM7b0JBQ3RCLGtCQUFhLEdBQVcsRUFBRSxDQUFDO29CQUUzQixjQUFTLEdBQVcsRUFBRSxDQUFDO29CQUN2QixrQkFBYSxHQUFXLEVBQUUsQ0FBQztvQkFDM0Isb0JBQWUsR0FBVyxFQUFFLENBQUM7b0JBQzdCLGtCQUFhLEdBQVcsRUFBRSxDQUFDO29CQUszQixvQkFBZSxHQUFZLEtBQUssQ0FBQztvQkFDakMsb0JBQWUsR0FBVyxFQUFFLENBQUM7b0JBQzdCLGlCQUFZLEdBQVcsRUFBRSxDQUFDO29CQUMxQixhQUFRLEdBQVksS0FBSyxDQUFDO29CQUMxQixjQUFTLEdBQVcsRUFBRSxDQUFDO29CQUN2QixlQUFVLEdBQVcsQ0FBQyxDQUFDO29CQUV2QixlQUFVLEdBQVcsRUFBRSxDQUFDO29CQUV4QixlQUFVLEdBQVcsRUFBRSxDQUFDO29CQUN4QixZQUFPLEdBQVcsQ0FBQyxDQUFDO29CQUNwQixnQkFBVyxHQUFXLEVBQUUsQ0FBQztvQkFDekIsY0FBUyxHQUFXLEVBQUUsQ0FBQztvQkFDdkIsaUJBQVksR0FBVyxFQUFFLENBQUM7b0JBQzFCLGdDQUFnQztvQkFFaEMscUJBQXFCO29CQUNyQiw2QkFBNkI7b0JBQzdCLGlDQUFpQztvQkFFakMsZUFBVSxHQUFHLEVBQUUsQ0FBQztvQkFDaEIsYUFBUSxHQUFHLEVBQUUsQ0FBQztvQkFDZCxlQUFVLEdBQUcsRUFBRSxDQUFDO29CQUNoQixjQUFTLEdBQUcsRUFBRSxDQUFDO29CQUNmLGdCQUFXLEdBQUcsRUFBRSxDQUFDO29CQUNqQixrQkFBYSxHQUFHLEVBQUUsQ0FBQztvQkFDbkIsWUFBTyxHQUFHLEVBQUUsQ0FBQztvQkFDYixlQUFVLEdBQUcsRUFBRSxDQUFDO29CQUNoQixZQUFPLEdBQUcsRUFBRSxDQUFDO29CQUNiLFlBQU8sR0FBRyxFQUFFLENBQUM7b0JBRUwsZ0JBQVcsR0FBVyxFQUFFLENBQUM7b0JBQ3pCLHFCQUFnQixHQUFXLEVBQUUsQ0FBQztvQkFDOUIsd0JBQW1CLEdBQVksS0FBSyxDQUFDO29CQUNyQywwQkFBcUIsR0FBWSxLQUFLLENBQUM7b0JBQ3ZDLHVCQUFrQixHQUFZLEtBQUssQ0FBQztvQkE0RXBDLDhCQUF5QixHQUFTLEVBQUUsQ0FBQztvQkFwRXpDLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxHQUFHLEVBQUUsQ0FBQztvQkFDL0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsR0FBRyxFQUFFLENBQUM7b0JBQ3ZDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLEVBQUUsQ0FBQztvQkFDcEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDO29CQUNwQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxFQUFFLENBQUM7b0JBQ3BDLElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxHQUFDLEVBQUUsQ0FBQztvQkFDNUIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLEdBQUcsRUFBRSxDQUFDO29CQUMxQixJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBRyxFQUFFLENBQUM7b0JBQ2hDLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxHQUFHLEVBQUUsQ0FBQztvQkFDbEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsR0FBRyxFQUFFLENBQUM7b0JBQ3RDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztvQkFDN0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsR0FBRyxDQUFDO29CQUM3QixJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsR0FBRyxFQUFFLENBQUM7b0JBQ2pDLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxHQUFHLEVBQUUsQ0FBQztvQkFDOUIsSUFBSSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUM7b0JBQ3ZCLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsWUFBWSxDQUFDO29CQUMzRCxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGFBQWEsQ0FBQztvQkFDeEQsSUFBSSxDQUFDLGlCQUFpQixHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGdCQUFnQixDQUFDO29CQUNuRSxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxDQUFDLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFLFdBQVcsRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFFLENBQUMsRUFBRSxTQUFTLEVBQUUsT0FBTyxFQUFFLGFBQWEsRUFBQyxPQUFPLEVBQUUsQ0FBQyxDQUFBO29CQUN6SSxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxDQUFDLEVBQUUsV0FBVyxFQUFFLEVBQUUsRUFBRSxNQUFNLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsQ0FBQyxFQUFFLFFBQVEsRUFBRSxFQUFFLEVBQUUsYUFBYSxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsQ0FBQyxFQUFFLFFBQVEsRUFBRSxNQUFNLEVBQUMsWUFBWSxFQUFFLE1BQU0sRUFBQyxDQUFDLENBQUE7b0JBQzFMLFlBQVk7b0JBQ1gsSUFBSSxLQUFLLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQztvQkFFL0MsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsT0FBTyxDQUFDLENBQUM7b0JBQzdELEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO3dCQUNqQixLQUFLLEdBQUcsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUU3QyxJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixHQUFHLENBQUM7NEJBQ2pDLE1BQU0sRUFBRSxFQUFFLEVBQUUsT0FBTyxFQUFFLEVBQUUsRUFBRSxRQUFRLEVBQUUsRUFBRSxFQUFFLEdBQUcsRUFBRSxFQUFFLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRSxPQUFPLEVBQUUsRUFBRSxFQUFFLGFBQWEsRUFBRSxFQUFFOzRCQUNsRyxXQUFXLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFFLFdBQVcsRUFBRSxXQUFXLEVBQUUsU0FBUzt5QkFDdkYsQ0FBQyxDQUFBO29CQUtGLElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLE1BQU0sQ0FBQyxDQUFDO29CQUMvRCxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBRXRCLFFBQVEsR0FBRyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQ3RELENBQUM7b0JBQ0QsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEdBQUcsUUFBUSxDQUFDO29CQUd4QyxJQUFJLEdBQUcsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUMsQ0FBQztvQkFDekQsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7d0JBQ2YsR0FBRyxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDdkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsR0FBRyxDQUFDO29CQUVqQyxJQUFJLE1BQU0sR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUMsQ0FBQztvQkFDNUQsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7d0JBQ2xCLE1BQU0sR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQ2hELElBQUksQ0FBQyxDQUFDO29CQUVOLENBQUM7b0JBQ0QsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsR0FBRyxNQUFNLENBQUM7b0JBQzFDLElBQUksQ0FBQyxPQUFPLEdBQUcsaUJBQWlCLENBQUM7b0JBQ2pDLElBQUksQ0FBQyxZQUFZLEdBQUcsb0JBQW9CLENBQUM7b0JBQ3pDLElBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSyxDQUFDO29CQUM3QixZQUFZLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO29CQUMvQixJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBRyxZQUFZLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztvQkFDcEQsSUFBSSxDQUFDLFVBQVUsR0FBRyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUM7b0JBQzFDLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQztvQkFFdEMseURBQXlEO29CQUN6RCw2QkFBNkI7Z0JBRWpDLENBQUM7Z0JBeEVPLHlDQUFpQixHQUF6QjtvQkFFSSxNQUFNLENBQUMsSUFBSSxDQUFDO2dCQUNoQixDQUFDO2dCQXlFRCwyQ0FBbUIsR0FBbkIsVUFBb0IsR0FBRztvQkFDbkIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztvQkFDakIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEdBQUcsR0FBRyxDQUFDO29CQUNqQyxvQ0FBb0M7b0JBQ25DLHVCQUF1QjtnQkFDM0IsQ0FBQztnQkFFTSxvQ0FBWSxHQUFwQixVQUFxQixPQUFZO29CQUFqQyxpQkFzREU7b0JBcERFLElBQUksT0FBTyxHQUFHLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQztvQkFFeEMsa0VBQWtFO29CQUc5RCxZQUFZO29CQUNmLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyx5QkFBeUIsSUFBSSxPQUFPLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDO3dCQUN6RCxpQ0FBaUM7d0JBQ2pDLE1BQU0sQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDO29CQUM5QixDQUFDO29CQUNMLElBQUksQ0FBQyxDQUFDO3dCQUNGLDJFQUEyRTt3QkFDdkUsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLGdCQUFnQixJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7NEJBQ2pDLElBQUksQ0FBQyx5QkFBeUIsR0FBRyxPQUFPLENBQUMsZ0JBQWdCLENBQUM7NEJBQzVELHlDQUF5Qzs0QkFDdkMscUJBQXFCOzRCQUNqQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsaUJBQWlCLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTtnQ0FDaEUsWUFBWTtnQ0FDWCxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQztnQ0FDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO29DQUMzQix5QkFBeUI7b0NBQ3pCLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBQyxPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07d0NBQ3RDLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTt3Q0FDekIsT0FBTyxFQUFFOzRDQUNMLEVBQUUsRUFBRTtnREFDQSxjQUFjO2dEQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUzs2Q0FDNUI7eUNBQ0o7cUNBQ0osQ0FBQyxDQUFDO2dDQUNQLENBQUM7Z0NBQ0QsSUFBSSxDQUFDLENBQUM7b0NBQ0YsT0FBTyxDQUFDLFlBQVksR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO2dDQUd6QyxDQUFDOzRCQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7Z0NBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQzs0QkFDdkIsQ0FBQyxFQUFFO2dDQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7NEJBQ2hDLENBQUMsQ0FBQyxDQUFDOzRCQUNSLFdBQVc7NEJBRVYsSUFBSSxDQUFDLGFBQWEsR0FBRyxPQUFPLENBQUMsWUFBWSxDQUFDO3dCQUM5QyxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLElBQUksQ0FBQyxhQUFhLEdBQUcsRUFBRSxDQUFDO3dCQUM1QixDQUFDO3dCQUNELE1BQU0sQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDO29CQUM5QixDQUFDO2dCQUdSLENBQUM7Z0JBRU8saURBQXlCLEdBQWpDLFVBQWtDLENBQVU7b0JBQ3hDLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxDQUFDLENBQUM7Z0JBQ2pDLENBQUM7Z0JBRU8sbURBQTJCLEdBQW5DLFVBQW9DLENBQVU7b0JBQzFDLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxLQUFLLENBQUM7b0JBQ2hDLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxDQUFDLENBQUM7Z0JBQ25DLENBQUM7Z0JBQ08sNENBQW9CLEdBQTVCLFVBQTZCLENBQU07b0JBQW5DLGlCQWtGQztvQkFqRkcsSUFBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQztvQkFDL0IsT0FBTyxDQUFDLEdBQUcsQ0FBQyxxQkFBbUIsQ0FBQyxDQUFDLElBQU0sQ0FBQyxDQUFDO29CQUN6QyxJQUFJLFFBQVEsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztvQkFDakMsV0FBVztvQkFDWCxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxJQUFJLFNBQVMsSUFBSSxDQUFDLENBQUMsSUFBSSxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7d0JBQ3hELHFCQUFxQjt3QkFDckIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGtCQUFrQixDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7NEJBQzNFLFdBQVc7NEJBQ1gsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7NEJBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQztnQ0FDM0IseUJBQXlCO2dDQUN6QixPQUFPLENBQUMsS0FBSyxDQUFDLEVBQUMsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO29DQUNuQyxTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7b0NBQzVCLE9BQU8sRUFBRTt3Q0FDTCxFQUFFLEVBQUU7NENBQ0EsY0FBYzs0Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7eUNBQzVCO3FDQUNKO2lDQUNKLENBQUMsQ0FBQzs0QkFDUCxDQUFDOzRCQUNELElBQUksQ0FBQyxDQUFDO2dDQUNGLEtBQUksQ0FBQyxVQUFVLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQztnQ0FDakMsb0NBQW9DO2dDQUNuQyxLQUFJLENBQUMsYUFBYSxHQUFHLEtBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGNBQWMsQ0FBQztnQ0FDN0QsS0FBSSxDQUFDLGlCQUFpQixHQUFHLEtBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLG1CQUFtQixDQUFDO2dDQUN0RSxLQUFJLENBQUMsT0FBTyxHQUFHLG9CQUFvQixDQUFDO2dDQUNwQyxFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztvQ0FDN0MsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsQ0FBQyxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFBO2dDQUMzRyxDQUFDO2dDQUNELEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO29DQUM3QyxJQUFJLElBQUksR0FBRyxFQUFFLENBQUM7b0NBQ2QsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsV0FBVyxFQUFFO3dDQUMxQixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLFdBQVcsQ0FBQyxDQUFDLENBQUM7NENBRTNCLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDOzRDQUNsQixNQUFNLENBQUMsS0FBSyxDQUFDO3dDQUNqQixDQUFDO29DQUNMLENBQUMsQ0FBQyxDQUFDO29DQUVILEtBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLENBQUMsRUFBRSxXQUFXLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUUsUUFBUSxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztnQ0FHcEksQ0FBQztnQ0FDRCxFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO29DQUNoRCxJQUFJLEtBQUssR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDO29DQUUvQyxJQUFJLEtBQUssR0FBRyxLQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxPQUFPLENBQUMsQ0FBQztvQ0FDN0QsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7d0NBQ2pCLEtBQUssR0FBRyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7b0NBQzdDLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQztvQ0FDZCxJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUM7b0NBQ3RCLEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxJQUFJLEVBQUUsSUFBSSxLQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sSUFBSSxTQUFTLElBQUksS0FBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzt3Q0FDM0csUUFBUSxHQUFHLE1BQU0sQ0FBQztvQ0FDdEIsQ0FBQztvQ0FDRCxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUksQ0FBQyxhQUFhLEVBQUU7d0NBQzVCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksUUFBUSxDQUFDLENBQUMsQ0FBQzs0Q0FDeEIsSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7NENBQ2xCLE1BQU0sQ0FBQyxLQUFLLENBQUM7d0NBQ2pCLENBQUM7b0NBQ0wsQ0FBQyxDQUFDLENBQUM7b0NBRUgsS0FBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsR0FBRyxDQUFDLEVBQUUsTUFBTSxFQUFFLEVBQUUsRUFBRSxPQUFPLEVBQUUsRUFBRSxFQUFFLFFBQVEsRUFBRSxFQUFFLEVBQUUsR0FBRyxFQUFFLEVBQUUsRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLE9BQU8sRUFBRSxFQUFFLEVBQUUsYUFBYSxFQUFFLElBQUksRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDO2dDQUMzTCxDQUFDO2dDQUVELEtBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxHQUFHLEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztnQ0FDM0QsS0FBSSxDQUFDLGVBQWUsR0FBRyxLQUFLLENBQUM7Z0NBQzdCLHVCQUF1QjtnQ0FDdkIsMkJBQTJCO2dDQUMzQixLQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7Z0NBQ3ZCLEtBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDO2dDQUN0QixtQkFBbUI7Z0NBQ25CLGtCQUFrQjtnQ0FDbEIsS0FBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsQ0FBQzs0QkFDN0IsQ0FBQzt3QkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLOzRCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7d0JBQ3ZCLENBQUMsRUFBRTs0QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO3dCQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFDUCxDQUFDO2dCQUNMLENBQUM7Z0JBQ0Qsc0NBQWMsR0FBZDtvQkFDSSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDN0csSUFBSSxNQUFNLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUM7d0JBQ3hDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7NEJBQ2YsSUFBSSxJQUFJLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQzs0QkFDOUMsUUFBUSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsVUFBVSxHQUFHLGdCQUFnQixHQUFHLElBQUksQ0FBQzt3QkFDbEUsQ0FBQztvQkFDTCxDQUFDO2dCQUNMLENBQUM7Z0JBQ0QsNENBQW9CLEdBQXBCO29CQUFBLGlCQXlGQztvQkF4RkcsSUFBSSxDQUFDLFlBQVksR0FBRyxVQUFVLENBQUM7b0JBQy9CLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxpQkFBaUIsRUFBRSxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7d0JBQ3hELE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQ3RCLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUd0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUN0RCxPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QixFQUFFLEVBQUMsQ0FBQyxDQUFDO3dCQUNsQixDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLFdBQVc7NEJBQ1gsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksSUFBSSxTQUFTLElBQUksUUFBUSxDQUFDLElBQUksSUFBSSxJQUFJLElBQUksUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDbkYsSUFBSSxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7Z0NBQ2hCLEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxjQUFjLElBQUksU0FBUyxJQUFJLEtBQUksQ0FBQyxjQUFjLENBQUMsVUFBVSxJQUFJLFNBQVMsSUFBSSxLQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO29DQUN6SCxNQUFNLEdBQUcsS0FBSSxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUE7Z0NBQzNDLENBQUM7Z0NBQ0QsRUFBRSxDQUFDLENBQUMsS0FBSSxDQUFDLFVBQVUsSUFBSSxTQUFTLElBQUksS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksU0FBUyxJQUFJLEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7b0NBQzdHLE1BQU0sR0FBRyxLQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQTtnQ0FDdkMsQ0FBQztnQ0FDRCxFQUFFLENBQUMsQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO29DQUNmLFFBQVEsQ0FBQyxRQUFRLEdBQUcsS0FBSSxDQUFDLFVBQVUsR0FBRyxlQUFlLEdBQUcsTUFBTSxHQUFHLEdBQUcsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztnQ0FDbEcsQ0FBQztnQ0FDRCxJQUFJLENBQUMsQ0FBQztvQ0FFRixPQUFPLENBQUMsS0FBSyxDQUFDO3dDQUNWLE9BQU8sRUFBRSxrRkFBa0Y7d0NBQzNGLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTt3Q0FDNUIsT0FBTyxFQUFFOzRDQUNMLEVBQUUsRUFBRTtnREFDQSxjQUFjO2dEQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUzs2Q0FDNUI7eUNBRUo7cUNBQ0osQ0FBQyxDQUFDO2dDQUNQLENBQUM7NEJBQ0wsQ0FBQzs0QkFDRCxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksSUFBSSxTQUFTLElBQUksUUFBUSxDQUFDLElBQUksSUFBSSxJQUFJLElBQUksUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDdkYsV0FBVztnQ0FDWCxJQUFJLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQztnQ0FDaEIsRUFBRSxDQUFDLENBQUMsS0FBSSxDQUFDLGNBQWMsSUFBSSxTQUFTLElBQUksS0FBSSxDQUFDLGNBQWMsQ0FBQyxVQUFVLElBQUksU0FBUyxJQUFJLEtBQUksQ0FBQyxjQUFjLENBQUMsVUFBVSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7b0NBQ3pILE1BQU0sR0FBRyxLQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQTtnQ0FDM0MsQ0FBQztnQ0FDRCxFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsVUFBVSxJQUFJLFNBQVMsSUFBSSxLQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxTQUFTLElBQUksS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztvQ0FDN0csTUFBTSxHQUFHLEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFBO2dDQUN2QyxDQUFDO2dDQUNELEVBQUUsQ0FBQyxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7b0NBQ2YsUUFBUSxDQUFDLFFBQVEsR0FBRyxLQUFJLENBQUMsVUFBVSxHQUFHLGlCQUFpQixHQUFHLE1BQU0sQ0FBQztnQ0FDckUsQ0FBQztnQ0FDRCxJQUFJLENBQUMsQ0FBQztvQ0FDRixPQUFPLENBQUMsS0FBSyxDQUFDO3dDQUNWLE9BQU8sRUFBRSxrRkFBa0Y7d0NBQzNGLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTt3Q0FDNUIsT0FBTyxFQUFFOzRDQUNMLEVBQUUsRUFBRTtnREFDQSxjQUFjO2dEQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUzs2Q0FDNUI7eUNBQ0o7cUNBQ0osQ0FBQyxDQUFDO2dDQUNQLENBQUM7NEJBRUwsQ0FBQzs0QkFDRCxJQUFJLENBQUMsQ0FBQztnQ0FDRixPQUFPLENBQUMsS0FBSyxDQUFDO29DQUNWLE9BQU8sRUFBRSxLQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxvQkFBb0I7b0NBQ3RELFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtvQ0FDNUIsT0FBTyxFQUFFO3dDQUNMLEVBQUUsRUFBRTs0Q0FDQSxjQUFjOzRDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUzt5Q0FDNUIsRUFBQztpQ0FDVCxDQUFDLENBQUM7NEJBQ1AsQ0FBQzt3QkFDTCxDQUFDO3dCQUNELEtBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO3dCQUNwQixLQUFJLENBQUMsR0FBRyxHQUFHLFFBQVEsQ0FBQyxNQUFNLENBQUM7b0JBQy9CLENBQUMsRUFDRyxVQUFBLEtBQUssSUFBRyxPQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEVBQWxCLENBQWtCLEVBQzFCLGNBQU0sT0FBQSxPQUFPLENBQUMsR0FBRyxDQUFDLHNCQUFzQixDQUFDLEVBQW5DLENBQW1DLENBQzVDLENBQUM7b0JBQ0YsSUFBSSxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUM7Z0JBQzNCLENBQUM7Z0JBQ0QsaUNBQVMsR0FBVDtvQkFDSSxPQUFPLENBQUMsS0FBSyxDQUFDO3dCQUNWLE9BQU8sRUFBRSxpQkFBaUIsR0FBRyxJQUFJLENBQUMsV0FBVyxFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsWUFBWTt3QkFDM0UsT0FBTyxFQUFFOzRCQUNMLEVBQUUsRUFBRTtnQ0FDQSxjQUFjO2dDQUNkLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUzs2QkFDNUI7eUJBQ0o7cUJBQ0osQ0FBQyxDQUFDO29CQUNILFlBQVksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7Z0JBQ25DLENBQUM7Z0JBQ0Qsc0NBQWMsR0FBZDtvQkFBQSxpQkFvSEM7b0JBbkhHLFFBQVEsQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLFVBQVUsR0FBRyxpQkFBaUIsQ0FBQztvQkFDeEQsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUM7b0JBQzVCLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO29CQUVyQixJQUFJLEtBQUssR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDO29CQUMvQyxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsRUFBRSxDQUFDO29CQUUzQixJQUFJLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztvQkFDckIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEdBQUcsRUFBRSxDQUFDO29CQUMvQixJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBRyxDQUFDLENBQUMsQ0FBQztvQkFDaEMsSUFBSSxDQUFDLFVBQVUsR0FBRyxFQUFFLENBQUM7b0JBQ3JCLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO29CQUN6QixJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxNQUFNLENBQUMsQ0FBQztvQkFDL0QsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7d0JBQ3BCLFFBQVEsR0FBRyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQ3RELElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxHQUFHLFFBQVEsQ0FBQztvQkFDeEMsSUFBSSxHQUFHLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDLENBQUM7b0JBQ3pELEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO3dCQUNmLEdBQUcsR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQ3ZDLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLEdBQUcsQ0FBQztvQkFDakMsSUFBSSxNQUFNLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDLENBQUM7b0JBQzVELEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO3dCQUNsQixNQUFNLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUNoRCxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixHQUFHLE1BQU0sQ0FBQztvQkFFMUMsSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7b0JBQ3RCLDhCQUE4QjtvQkFDOUIsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxnQkFBZ0IsQ0FBQztvQkFDOUQsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUM7b0JBQzNELElBQUksQ0FBQyxPQUFPLEdBQUcsaUJBQWlCLENBQUM7b0JBQ2pDLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxnQkFBZ0IsQ0FBQztvQkFDbkUsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7b0JBQ3ZCLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztvQkFDdEIsK0RBQStEO29CQUkvRCxJQUFJLElBQUksR0FBRyxFQUFFLENBQUM7b0JBQ2QsSUFBSSxHQUFHLEdBQUcsQ0FBQyxDQUFDO29CQUNaLElBQUksT0FBTyxHQUFHLENBQUMsQ0FBQztvQkFDaEIsSUFBSSxRQUFRLEdBQUcsQ0FBQyxDQUFDO29CQUNqQixNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUU7d0JBQzFCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksV0FBVyxDQUFDLENBQUMsQ0FBQzs0QkFFM0IsSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7NEJBQ2xCLEdBQUcsR0FBRyxDQUFDLENBQUM7NEJBQ1IsT0FBTyxHQUFHLENBQUMsQ0FBQzs0QkFDWixRQUFRLEdBQUcsQ0FBQyxDQUFDOzRCQUNiLE1BQU0sQ0FBQyxLQUFLLENBQUM7d0JBQ2pCLENBQUM7b0JBQ0wsQ0FBQyxDQUFDLENBQUM7b0JBRUgsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsQ0FBQyxFQUFFLFdBQVcsRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLEVBQUUsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLEdBQUcsRUFBRSxRQUFRLEVBQUUsRUFBRSxFQUFFLFNBQVMsRUFBRSxPQUFPLEVBQUUsQ0FBQyxDQUFBO29CQUN2SSxXQUFXO29CQUVYLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLENBQUMsRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFFLFNBQVMsRUFBRSxFQUFFLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQTtvQkFDdEcsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsT0FBTyxDQUFDLENBQUM7b0JBQ2pFLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO3dCQUNyQixTQUFTLEdBQUcsU0FBUyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUV6RCxJQUFJLElBQUksR0FBRyxFQUFFLENBQUM7b0JBQ2QsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFO3dCQUM1QixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLE1BQU0sQ0FBQyxDQUFDLENBQUM7NEJBRXRCLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDOzRCQUNsQixNQUFNLENBQUMsS0FBSyxDQUFDO3dCQUNqQixDQUFDO29CQUVMLENBQUMsQ0FBQyxDQUFDO29CQUdILElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLEdBQUcsQ0FBQyxFQUFFLE1BQU0sRUFBRSxFQUFFLEVBQUUsT0FBTyxFQUFFLEVBQUUsRUFBRSxRQUFRLEVBQUUsRUFBRSxFQUFFLEdBQUcsRUFBRSxFQUFFLEVBQUUsV0FBVyxFQUFFLFNBQVMsRUFBRSxPQUFPLEVBQUUsRUFBRSxFQUFFLGFBQWEsRUFBRSxJQUFJLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQTtvQkFDMUwsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDO29CQUNwQyxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsR0FBRyxFQUFFLENBQUM7b0JBQzlCLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztvQkFDMUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEdBQUcsRUFBRSxDQUFDO29CQUM3QixJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxHQUFHLENBQUM7b0JBQzdCLElBQUksQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDO29CQUNyQixJQUFJLENBQUMsR0FBRyxHQUFHLEVBQUUsQ0FBQztvQkFDZCxJQUFJLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQztvQkFDdkIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxTQUFTLENBQzVELFVBQUMsSUFBSTt3QkFDRCxZQUFZO3dCQUNaLEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxTQUFTLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQzs0QkFDMUIsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQzs0QkFDdkMsSUFBSSxHQUFHLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUE7NEJBQ3JDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxhQUFhLENBQUM7Z0NBQy9CLFlBQVksRUFBRSxJQUFJO2dDQUNsQixVQUFVLEVBQUU7b0NBQ1IsYUFBYSxFQUFFLElBQUk7aUNBQ3RCO2dDQUNELDRCQUE0QjtnQ0FDNUIsVUFBVSxFQUFFLEdBQUc7NkJBQ2xCLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7NEJBQ3hDLElBQUksR0FBRyxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFBOzRCQUNyQyxNQUFNLENBQUMsYUFBYSxDQUFDLENBQUMsYUFBYSxDQUFDO2dDQUNoQyxZQUFZLEVBQUUsSUFBSTtnQ0FDbEIsVUFBVSxFQUFFO29DQUNSLGFBQWEsRUFBRSxJQUFJO2lDQUN0QjtnQ0FDRCw0QkFBNEI7Z0NBQzVCLFVBQVUsRUFBRSxHQUFHOzZCQUNsQixDQUFDLENBQUM7d0JBQ1AsQ0FBQztvQkFDTCxDQUFDLEVBQ0QsVUFBQyxHQUFHO29CQUVKLENBQUMsRUFDRDtvQkFFQSxDQUFDLENBQ0osQ0FBQztnQkFDTixDQUFDO2dCQUNELHVDQUFlLEdBQWY7b0JBQ0ksSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUM7b0JBQzVCLElBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSyxDQUFDO29CQUM3QixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQztvQkFDckIsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO29CQUM1QixNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQzVCLElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsY0FBYyxDQUFDO29CQUMvRCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksSUFBSSxJQUFJLFFBQVEsQ0FBRSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxHQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDN0gsTUFBTSxDQUFDLGdCQUFnQixDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7d0JBQ2hDLElBQUksQ0FBQyxZQUFZLEdBQUcsb0JBQW9CLENBQUM7d0JBQ3pDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO29CQUN0QyxDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUNGLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO3dCQUNoQyxNQUFNLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztvQkFDdEMsQ0FBQztnQkFDTCxDQUFDO2dCQUVELHlDQUFpQixHQUFqQjtvQkFBQSxpQkFvRkM7b0JBbEZHLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQzt3QkFDaEMsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUM7d0JBQzVCLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQzt3QkFDNUIsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO3dCQUM1QixJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQzt3QkFDdEIsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxrQkFBa0IsQ0FBQzt3QkFDcEUscUNBQXFDO3dCQUNwQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksSUFBSSxJQUFJLFFBQVEsQ0FBRSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxHQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs0QkFDN0gsTUFBTSxDQUFDLGdCQUFnQixDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7NEJBQ2hDLElBQUksQ0FBQyxZQUFZLEdBQUcsa0JBQWtCLENBQUM7NEJBQ3ZDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO3dCQUN0QyxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDOzRCQUNoQyxNQUFNLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQzt3QkFDdEMsQ0FBQztvQkFDTCxDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUNGLElBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSyxDQUFDO3dCQUM3QixNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7d0JBQzVCLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQzt3QkFDNUIsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxjQUFjLENBQUM7d0JBRS9ELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxJQUFJLElBQUksUUFBUSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOzRCQUMzSCxNQUFNLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQzs0QkFDaEMsSUFBSSxDQUFDLFlBQVksR0FBRyxvQkFBb0IsQ0FBQzs0QkFDekMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7NEJBRWxDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxRQUFRLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQztnQ0FDbEksSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7b0NBQ25HLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO29DQUN0QyxpQkFBaUI7b0NBQ2pCLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzt3Q0FDM0IseUJBQXlCO3dDQUN6QixPQUFPLENBQUMsS0FBSyxDQUFDOzRDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTs0Q0FDdEQsT0FBTyxFQUFFO2dEQUNMLEVBQUUsRUFBRTtvREFDQSxjQUFjO29EQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztpREFDNUI7NkNBQ0o7eUNBQ0osQ0FBQyxDQUFDO29DQUNQLENBQUM7b0NBQ0QsNEJBQTRCO29DQUM1QixPQUFPLENBQUMsS0FBSyxDQUFDO3dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTt3Q0FDdEQsT0FBTyxFQUFFOzRDQUNMLEVBQUUsRUFBRTtnREFDQSxjQUFjO2dEQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUzs2Q0FDNUI7eUNBQ0o7cUNBQ0osQ0FBQyxDQUFDO29DQUNILEtBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO29DQUNyQixHQUFHO29DQUNILFFBQVE7b0NBRVIsR0FBRztnQ0FDUCxDQUFDLENBQUMsQ0FBQzs0QkFDUCxDQUFDOzRCQUNELElBQUksQ0FBQyxDQUFDO2dDQUNGLE9BQU8sQ0FBQyxLQUFLLENBQUM7b0NBQ1YsT0FBTyxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGVBQWUsRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLFlBQVk7b0NBQy9FLE9BQU8sRUFBRTt3Q0FDTCxFQUFFLEVBQUU7NENBQ0EsY0FBYzs0Q0FDZCxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVM7eUNBQzVCO3FDQUNKO2lDQUNKLENBQUMsQ0FBQztnQ0FDSCxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7Z0NBQ2xCLElBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSyxDQUFDO2dDQUM3QixJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQzs0QkFDN0IsQ0FBQzt3QkFDTCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDOzRCQUNoQyxNQUFNLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQzt3QkFDdEMsQ0FBQztvQkFDTCxDQUFDO2dCQUVMLENBQUM7Z0JBQ0Qsb0NBQVksR0FBWjtvQkFDSSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzt3QkFDeEUsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7NEJBQzVDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUM7d0JBQ2pILENBQUM7b0JBQ0wsQ0FBQztnQkFDTCxDQUFDO2dCQUNELDZDQUFxQixHQUFyQjtnQkFFQSxDQUFDO2dCQUNELHNDQUFjLEdBQWQ7b0JBQ0ksVUFBVTtvQkFDVixXQUFXO2dCQUVmLENBQUM7Z0JBRUQseUNBQWlCLEdBQWpCO29CQUVJLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztvQkFDbEIsSUFBSSxDQUFDLG9DQUFvQyxFQUFFLENBQUM7b0JBQzVDLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQztvQkFDZCxJQUFJLE1BQU0sR0FBRyxNQUFNLENBQUM7b0JBRXBCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDO3dCQUN4RSxNQUFNLEdBQUcsTUFBTSxDQUFDO29CQUVwQixDQUFDO29CQUNELE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRTt3QkFDNUIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxNQUFNLENBQUMsQ0FBQyxDQUFDOzRCQUN0QixJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQzs0QkFDbEIsTUFBTSxDQUFDLEtBQUssQ0FBQzt3QkFDakIsQ0FBQztvQkFFTCxDQUFDLENBQUMsQ0FBQztvQkFFSCxJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7Z0JBQ3pHLENBQUM7Z0JBQ0Qsa0NBQVUsR0FBVjtvQkFFSSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQzt3QkFDdEUsV0FBVzt3QkFDWCxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sSUFBSSxTQUFTLENBQUUsQ0FBQyxDQUFELENBQUM7NEJBQ3pFLElBQUksVUFBVSxHQUFHLEVBQUUsQ0FBQzs0QkFDcEIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQztnQ0FDekksVUFBVSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQzs0QkFFckUsQ0FBQzs0QkFDRCxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLFNBQVMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQ2hKLFVBQVUsR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUM7NEJBQzdDLENBQUM7NEJBQ0QsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDbEosVUFBVSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxHQUFHLEdBQUcsQ0FBQzs0QkFDN0MsQ0FBQzs0QkFDRCxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxVQUFVLENBQUM7d0JBQ3hDLENBQUM7d0JBQ0QsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs0QkFDbEosSUFBSSxVQUFVLEdBQUcsRUFBRSxDQUFDOzRCQUNwQixFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQzFFLFVBQVUsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQzs0QkFDekMsQ0FBQzs0QkFDRCxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxVQUFVLENBQUM7d0JBQ3hDLENBQUM7d0JBQ0QsSUFBSTs0QkFDQSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEdBQUcsSUFBSSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLHFCQUFxQjt3QkFDOUksRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7NEJBQzVDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUM7d0JBQ2pILENBQUM7b0JBQ0wsQ0FBQztvQkFDRCxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7Z0JBQ3hCLENBQUM7Z0JBQ0QsaUNBQVMsR0FBVDtvQkFDSSxzRUFBc0U7b0JBQ3RFLElBQUksTUFBTSxHQUFHLEtBQUssQ0FBQztvQkFDbkIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO3dCQUN6QixNQUFNLEdBQUcsS0FBSyxDQUFBO3dCQUNkLElBQUksQ0FBQyxTQUFTLEdBQUcsS0FBSyxDQUFDO29CQUMzQixDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUNGLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDO3dCQUN0QixNQUFNLEdBQUcsSUFBSSxDQUFDO29CQUNsQixDQUFDO29CQUVELElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBQy9CLENBQUM7Z0JBQ0Qsd0NBQWdCLEdBQWhCO29CQUFBLGlCQXVJQztvQkF0SUcsV0FBVztvQkFDWCxJQUFJLENBQUMsWUFBWSxHQUFHLFVBQVUsQ0FBQztvQkFDL0IsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7b0JBQ3ZCLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO29CQUV6QixJQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7b0JBQ2QsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO3dCQUM5RixNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLEVBQUU7NEJBQzNDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQztnQ0FDM0IsS0FBSyxHQUFHLEtBQUssR0FBRyxDQUFDLENBQUM7NEJBQ3RCLENBQUM7NEJBQ0QsRUFBRSxDQUFDLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQ1osbURBQW1EO2dDQUVuRCxJQUFJLENBQUMsWUFBWSxHQUFHLEVBQUUsQ0FBQztnQ0FDdkIsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7Z0NBQ3hCLE1BQU0sQ0FBQyxLQUFLLENBQUM7NEJBQ2pCLENBQUM7d0JBQ0wsQ0FBQyxDQUFDLENBQUM7b0JBQ1AsQ0FBQztvQkFDRCxtQ0FBbUM7b0JBQ25DLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7d0JBQ2xDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSxZQUFZLEVBQUUsSUFBSSxDQUFDLENBQUMsT0FBTyxFQUFFLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQzs0QkFDM0UsT0FBTyxDQUFDLEtBQUssQ0FBQyxFQUFFLE9BQU8sRUFBRSx3QkFBd0IsRUFBRSxDQUFDLENBQUM7NEJBRXJELElBQUksQ0FBQyxZQUFZLEdBQUcsRUFBRSxDQUFDOzRCQUN2QixJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQzs0QkFDeEIsTUFBTSxDQUFDLEtBQUssQ0FBQzt3QkFDakIsQ0FBQztvQkFDTCxDQUFDO29CQUNELEVBQUUsQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO3dCQUU1RyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDeEYsSUFBSSxNQUFNLEdBQUcsRUFBRSxDQUFDOzRCQUNoQixNQUFNLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0NBQzdCLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7NEJBQ3BDLENBQUMsQ0FBQyxDQUFDOzRCQUNILElBQUksTUFBTSxHQUFHLEVBQUUsQ0FBQzs0QkFDaEIsTUFBTSxDQUFDLG1CQUFtQixDQUFDLENBQUMsSUFBSSxDQUFDO2dDQUM3QixNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDOzRCQUNwQyxDQUFDLENBQUMsQ0FBQzs0QkFDSCxJQUFJLE9BQU8sR0FBRyxFQUFFLENBQUM7NEJBQ2pCLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLElBQUksQ0FBQztnQ0FDOUIsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQzs0QkFDckMsQ0FBQyxDQUFDLENBQUM7NEJBQ0gsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDOzRCQUNWLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUU7Z0NBQ3hDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQztvQ0FDckIsSUFBSSxDQUFDLEtBQUssR0FBRyxHQUFHLENBQUM7Z0NBQ3JCLENBQUM7Z0NBQ0QsSUFBSSxDQUFDLENBQUM7b0NBQ0YsSUFBSSxDQUFDLEtBQUssR0FBRyxHQUFHLENBQUM7Z0NBQ3JCLENBQUM7Z0NBQ0QsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO29DQUN6QixJQUFJLENBQUMsU0FBUyxHQUFHLEdBQUcsQ0FBQztnQ0FDekIsQ0FBQztnQ0FDRCxJQUFJLENBQUMsQ0FBQztvQ0FDRixJQUFJLENBQUMsU0FBUyxHQUFHLEdBQUcsQ0FBQztnQ0FDekIsQ0FBQztnQ0FDRCxJQUFJLENBQUMsS0FBSyxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDdkIsSUFBSSxDQUFDLElBQUksR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQ3RCLElBQUksQ0FBQyxNQUFNLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUN6QixDQUFDLEVBQUUsQ0FBQztnQ0FDSix5Q0FBeUM7Z0NBQ3pDLHVDQUF1QztnQ0FDdkMsMkJBQTJCOzRCQUMvQixDQUFDLENBQUMsQ0FBQzt3QkFFUCxDQUFDO3dCQUNELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUN4RixNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxFQUFFO2dDQUN4QyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7b0NBQ3ZCLElBQUksQ0FBQyxPQUFPLEdBQUcsR0FBRyxDQUFDO2dDQUN2QixDQUFDO2dDQUNELElBQUksQ0FBQyxDQUFDO29DQUNGLElBQUksQ0FBQyxPQUFPLEdBQUcsR0FBRyxDQUFDO2dDQUN2QixDQUFDO2dDQUNELENBQUMsRUFBRSxDQUFDOzRCQUNSLENBQUMsQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7d0JBQzVDLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUE7d0JBQ2xCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTs0QkFDdkQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQzs0QkFDdEIsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7NEJBQ3RDLEtBQUksQ0FBQyxZQUFZLEdBQUcsRUFBRSxDQUFDOzRCQUN2QixLQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQzs0QkFFeEIsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO2dDQUMzQix5QkFBeUI7Z0NBQ3pCLEtBQUksQ0FBQyxRQUFRLEdBQUcsYUFBYSxDQUFDOzRCQUNsQyxDQUFDOzRCQUNELElBQUksQ0FBQyxDQUFDO2dDQUNGLHlCQUF5QjtnQ0FFekIsS0FBSSxDQUFDLFFBQVEsR0FBRyxjQUFjLENBQUM7Z0NBQy9CLElBQUksS0FBSyxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUM7Z0NBQy9DLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLE1BQU0sRUFBRSxLQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksRUFBRSxFQUFFLENBQUMsQ0FBQztnQ0FDbEYsS0FBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsS0FBSyxFQUFFLEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxFQUFFLEVBQUUsQ0FBQyxDQUFDO2dDQUMvRSxLQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxLQUFLLEVBQUUsS0FBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsRUFBRSxFQUFFLENBQUMsQ0FBQztnQ0FDckYsRUFBRSxDQUFDLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLEdBQUMsQ0FBQyxDQUFDO29DQUMzQyxLQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxPQUFPLEVBQUUsS0FBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxXQUFXLEVBQUUsRUFBRSxDQUFDLENBQUM7Z0NBQ3ZKLFlBQVk7Z0NBQ1gsMERBQTBEO2dDQUMxRCxXQUFXO2dDQUNYLEtBQUksQ0FBQyxjQUFjLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQztnQ0FDcEMsS0FBSSxDQUFDLFVBQVUsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO2dDQUNoQyxLQUFJLENBQUMsV0FBVyxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQzs0QkFNdEMsQ0FBQzs0QkFDRCxLQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQzs0QkFDcEIsS0FBSSxDQUFDLEdBQUcsR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDO3dCQUMvQixDQUFDLEVBQ0csVUFBQSxLQUFLLElBQUcsT0FBQSxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxFQUFsQixDQUFrQixFQUMxQixjQUFNLE9BQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQkFBc0IsQ0FBQyxFQUFuQyxDQUFtQyxDQUM1QyxDQUFDO29CQUNOLENBQUM7b0JBQ0QsSUFBSSxDQUFDLENBQUM7d0JBQ0YsT0FBTyxDQUFDLEtBQUssQ0FBQzs0QkFDVixPQUFPLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsaUJBQWlCLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxZQUFZOzRCQUNqRixPQUFPLEVBQUU7Z0NBQ0wsRUFBRSxFQUFFO29DQUNBLGNBQWM7b0NBQ2QsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO2lDQUM1Qjs2QkFDSjt5QkFDSixDQUFDLENBQUM7d0JBQ0gsSUFBSSxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUM7d0JBQ3ZCLElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO29CQUM1QixDQUFDO2dCQUNMLENBQUM7Z0JBRUQsNERBQW9DLEdBQXBDO29CQUFBLGlCQTBFQztvQkF6RUcsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7b0JBQzVDLFdBQVc7b0JBQ1gsSUFBSSxLQUFLLEdBQUcsRUFBRSxDQUFDO29CQUNmLElBQUksS0FBSyxHQUFHLEVBQUUsQ0FBQztvQkFDZixJQUFJLE9BQU8sR0FBRyxFQUFFLENBQUM7b0JBQ2pCLElBQUksTUFBTSxHQUFHLEVBQUUsQ0FBQztvQkFDaEIsSUFBSSxNQUFNLEdBQUcsRUFBRSxDQUFDO29CQUVoQixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssSUFBSSxTQUFTLENBQUM7d0JBQ25DLEtBQUssR0FBRyxFQUFFLENBQUM7b0JBQ2YsSUFBSTt3QkFDQSxLQUFLLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUM7b0JBRWxDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLFNBQVMsQ0FBQzt3QkFDbkMsS0FBSyxHQUFHLEVBQUUsQ0FBQztvQkFDZixJQUFJO3dCQUNBLEtBQUssR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQztvQkFDbEMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLElBQUksU0FBUyxDQUFDO3dCQUNyQyxPQUFPLEdBQUcsRUFBRSxDQUFDO29CQUNqQixJQUFJO3dCQUNBLE9BQU8sR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQztvQkFFdEMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLENBQUMsSUFBSSxDQUFDO3dCQUU3QixFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxFQUFFLElBQUksRUFBRSxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLEVBQUUsSUFBSSxTQUFTLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsRUFBRSxJQUFJLElBQUksSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsTUFBTSxJQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7NEJBQzVILE1BQU0sSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxFQUFFLEdBQUcsS0FBSyxDQUFDO3dCQUN6QyxDQUFDO29CQUNMLENBQUMsQ0FBQyxDQUFDO29CQUNILEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO3dCQUFDLE1BQU0sR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDO29CQUN2RSxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxFQUFFO3dCQUN4QyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsS0FBSyxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsS0FBSyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sSUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDOzRCQUM1RixNQUFNLElBQUksSUFBSSxDQUFDLEtBQUssR0FBQyxLQUFLLENBQUM7d0JBQy9CLENBQUM7b0JBRUwsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7d0JBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7b0JBQ3ZFLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxJQUFJLEVBQUUsSUFBSSxLQUFLLENBQUMsTUFBTSxJQUFJLENBQUMsSUFBSSxLQUFLLElBQUksRUFBRSxJQUFJLEtBQUssQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDOzJCQUNuRSxDQUFDLE9BQU8sSUFBSSxFQUFFLElBQUksT0FBTyxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUM7MkJBQ3RDLENBQUMsTUFBTSxJQUFJLEVBQUUsQ0FBQzsyQkFDZCxDQUFDLE1BQU0sSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBRXBCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxzQkFBc0IsQ0FBQyxLQUFLLEVBQUUsS0FBSyxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsTUFBTSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTs0QkFDbEcsV0FBVzs0QkFDWCxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzs0QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO2dDQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO29DQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtvQ0FDdEQsT0FBTyxFQUFFO3dDQUNMLEVBQUUsRUFBRTs0Q0FDQSxjQUFjOzRDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUzt5Q0FDNUI7cUNBQ0o7aUNBQ0osQ0FBQyxDQUFDOzRCQUNQLENBQUM7NEJBQ0QsSUFBSSxDQUFDLENBQUM7Z0NBQ0YsS0FBSSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUM7Z0NBQ25CLEtBQUksQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQztnQ0FDOUIsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksSUFBSSxJQUFJLElBQUksUUFBUSxDQUFDLElBQUksSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDO29DQUN0RCxLQUFJLENBQUMsY0FBYyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7b0NBQ3BDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxTQUFTLEVBQUUsQ0FBQTtnQ0FHcEMsQ0FBQzs0QkFFTCxDQUFDO3dCQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7NEJBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQzt3QkFDdkIsQ0FBQyxFQUFFOzRCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7d0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUNQLENBQUM7b0JBQ0Qsb0JBQW9CO2dCQUN4QixDQUFDO2dCQUlELCtDQUF1QixHQUF2QixVQUF3QixLQUFLLEVBQUUsS0FBSyxFQUFDLE9BQU87b0JBQTVDLGlCQThDQztvQkE3Q0csSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7b0JBQzVDLFdBQVc7b0JBQ1gsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLElBQUksU0FBUyxDQUFDO3dCQUNuQyxLQUFLLEdBQUcsRUFBRSxDQUFDO29CQUNmLElBQUk7d0JBQ0EsS0FBSyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDO29CQUVsQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssSUFBSSxTQUFTLENBQUM7d0JBQ25DLEtBQUssR0FBRyxFQUFFLENBQUM7b0JBQ2YsSUFBSTt3QkFDQSxLQUFLLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUM7b0JBQ2xDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxJQUFJLFNBQVMsQ0FBQzt3QkFDckMsT0FBTyxHQUFHLEVBQUUsQ0FBQztvQkFDakIsSUFBSTt3QkFDQSxPQUFPLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUM7b0JBQ3RDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxxQkFBcUIsQ0FBQyxLQUFLLEVBQUUsS0FBSyxFQUFFLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7d0JBQ2pGLFdBQVc7d0JBQ1gsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQ3RELE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEtBQUksQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDOzRCQUNuQixLQUFJLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7NEJBQzlCLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLElBQUksSUFBSSxJQUFJLFFBQVEsQ0FBQyxJQUFJLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQztnQ0FDdEQsS0FBSSxDQUFDLGNBQWMsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO2dDQUNwQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsU0FBUyxFQUFFLENBQUM7NEJBRXJDLENBQUM7d0JBRUwsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFDSCxvQkFBb0I7Z0JBQ3hCLENBQUM7Z0JBS0QsMENBQWtCLEdBQWxCO29CQUVJLGlCQUFpQjtvQkFDakIsd0VBQXdFO29CQUN4RSxvQ0FBb0M7b0JBQ3BDLDRFQUE0RTtvQkFDNUUsaUJBQWlCO29CQUNqQiw0Q0FBNEM7b0JBQzVDLHFDQUFxQztvQkFDckMsaUNBQWlDO29CQUNqQyxPQUFPO29CQUNQLFlBQVk7b0JBQ1osNkJBQTZCO29CQUM3Qix3Q0FBd0M7b0JBQ3hDLG9FQUFvRTtvQkFDcEUsa0RBQWtEO29CQUNsRCxpREFBaUQ7b0JBQ2pELFdBQVc7b0JBQ1gsNEJBQTRCO29CQUM1QixPQUFPO29CQUNQLGNBQWM7b0JBQ2QseUJBQXlCO29CQUN6QixZQUFZO29CQUNaLGtDQUFrQztvQkFDbEMsS0FBSztnQkFDVCxDQUFDO2dCQUNELDBDQUFrQixHQUFsQjtvQkFBQSxpQkFnQ0M7b0JBL0JHLElBQUksS0FBSyxHQUFHLEVBQUUsQ0FBQztvQkFDZixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLElBQUksU0FBUyxDQUFDO3dCQUNsRSxLQUFLLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUM7b0JBQ2xDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxzQkFBc0IsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7d0JBQ2xGLFdBQVc7d0JBQ1gsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQ3RELE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEtBQUksQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDOzRCQUNuQixLQUFJLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7NEJBQzlCLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLElBQUksSUFBSSxJQUFJLFFBQVEsQ0FBQyxJQUFJLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQztnQ0FDdEQsS0FBSSxDQUFDLGNBQWMsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO2dDQUNwQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsU0FBUyxFQUFFLENBQUM7NEJBQ3JDLENBQUM7d0JBRUwsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztnQkFDUCxDQUFDO2dCQUNELG1DQUFXLEdBQVgsVUFBWSxLQUFLO29CQUNiLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUU7d0JBQ3hDLEVBQUUsQ0FBQyxDQUFDLElBQUksSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDOzRCQUNoQixJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQzt3QkFDOUIsQ0FBQztvQkFFTCxDQUFDLENBQUMsQ0FBQztnQkFDUCxDQUFDO2dCQUNELG9DQUFZLEdBQVo7b0JBQ0ksSUFBSSxDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7b0JBQ2xCLElBQUksQ0FBQyxVQUFVLEdBQUcsRUFBRSxDQUFDO29CQUNyQixJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsR0FBRyxFQUFFLENBQUM7b0JBQ2pDLElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxHQUFHLEVBQUUsQ0FBQztvQkFDOUIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLEdBQUcsRUFBRSxDQUFDO29CQUMxQixJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUM7b0JBQzNCLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxHQUFHLEVBQUUsQ0FBQztvQkFDaEMsSUFBSSxDQUFDLFVBQVUsR0FBRyxFQUFFLENBQUM7b0JBQ3JCLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsYUFBYSxDQUFBO2dCQUczRCxDQUFDO2dCQUNELHNDQUFjLEdBQWQ7b0JBQ0ksV0FBVztvQkFDWCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUM7d0JBQzNCLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO3dCQUN2QixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGlCQUFpQixDQUFDO3dCQUM1RCxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO29CQUNqQyxDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUNGLElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO3dCQUN4QixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGtCQUFrQixDQUFDO3dCQUM3RCxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO29CQUNqQyxDQUFDO2dCQUVMLENBQUM7Z0JBR0QscUNBQWEsR0FBYixVQUFjLEtBQUs7b0JBQ2YsaUJBQWlCO29CQUNqQixNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxJQUFJLFNBQVMsSUFBSSxLQUFLLENBQUMsTUFBTSxJQUFJLEVBQUUsQ0FBQzsyQkFDakQsQ0FBQyxLQUFLLENBQUMsT0FBTyxJQUFJLFNBQVMsSUFBSSxLQUFLLENBQUMsT0FBTyxJQUFJLEVBQUUsQ0FBQzsyQkFFbkQsQ0FBQyxLQUFLLENBQUMsR0FBRyxJQUFJLFNBQVMsSUFBSSxLQUFLLENBQUMsR0FBRyxJQUFJLEVBQUUsQ0FBQzsyQkFDM0MsQ0FBQyxLQUFLLENBQUMsV0FBVyxJQUFJLFNBQVMsSUFBSSxLQUFLLENBQUMsV0FBVyxJQUFJLEVBQUUsQ0FBRTsyQkFFNUQsQ0FBQyxLQUFLLENBQUMsYUFBYSxJQUFJLFNBQVMsSUFBSSxLQUFLLENBQUMsYUFBYSxJQUFJLEVBQUUsQ0FBQyxDQUFDO2dCQUMzRSxDQUFDO2dCQUNELG9DQUFZLEdBQVosVUFBYSxLQUFLO29CQUVkLElBQUksU0FBUyxHQUFHLEtBQUssQ0FBQztvQkFDdEIsS0FBSyxDQUFDLFFBQVEsR0FBRyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUM7b0JBRXZDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUU1QixJQUFJLEtBQUssR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDO3dCQUMvQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxPQUFPLEVBQUUsS0FBSyxDQUFDLFdBQVcsRUFBRSxFQUFFLENBQUMsQ0FBQzt3QkFDeEUsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDO3dCQUNkLElBQUksTUFBTSxHQUFHLE1BQU0sQ0FBQzt3QkFDcEIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUM7NEJBQ3hFLE1BQU0sR0FBRyxNQUFNLENBQUM7d0JBQ3BCLENBQUM7d0JBQ0QsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFOzRCQUM1QixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLE1BQU0sQ0FBQyxDQUFDLENBQUM7Z0NBQ3RCLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO2dDQUNsQixNQUFNLENBQUMsS0FBSyxDQUFDOzRCQUNqQixDQUFDO3dCQUVMLENBQUMsQ0FBQyxDQUFDO3dCQUNILElBQUksU0FBUyxHQUFHLEVBQUUsTUFBTSxFQUFFLEVBQUUsRUFBRSxPQUFPLEVBQUUsRUFBRSxFQUFFLFFBQVEsRUFBRSxFQUFFLEVBQUUsR0FBRyxFQUFFLEVBQUUsRUFBRSxXQUFXLEVBQUUsS0FBSyxDQUFDLFdBQVcsRUFBRSxPQUFPLEVBQUUsRUFBRSxFQUFFLGFBQWEsRUFBRSxJQUFJLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFHLFNBQVMsRUFBRSxVQUFVLEdBQUcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sR0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxXQUFXLEVBQUUsUUFBUSxHQUFHLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLEdBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQzt3QkFFNVUsOERBQThEO3dCQUM5RCxtRkFBbUY7d0JBRW5GLG9DQUFvQzt3QkFDcEMsdUJBQXVCO3dCQUN2QixPQUFPO3dCQUNQLEtBQUs7d0JBQ0wsRUFBRSxDQUFDLENBQUMsU0FBUyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUM7NEJBQ3JCLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO3dCQUN0RCxDQUFDO29CQUVULENBQUM7b0JBQ0QsSUFBSSxDQUFDLENBQUM7d0JBQ0YsSUFBSSxHQUFHLEdBQUcsRUFBRSxDQUFDO3dCQUNiLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLElBQUksU0FBUyxJQUFJLEtBQUssQ0FBQyxNQUFNLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzs0QkFDbEQsb0RBQW9EOzRCQUNwRCxHQUFHLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGlCQUFpQixDQUFDO3dCQUM3RCxDQUFDO3dCQUNELEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLElBQUksU0FBUyxJQUFJLEtBQUssQ0FBQyxPQUFPLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzs0QkFDcEQsZ0NBQWdDOzRCQUNoQyxHQUFHLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGVBQWUsQ0FBQzt3QkFDM0QsQ0FBQzt3QkFDRCwwREFBMEQ7d0JBQzFELHVDQUF1Qzt3QkFDdkMsNkRBQTZEO3dCQUM3RCxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxJQUFJLFNBQVMsSUFBSSxLQUFLLENBQUMsR0FBRyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7NEJBQzVDLGdDQUFnQzs0QkFDaEMsR0FBRyxJQUFJLElBQUksR0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxjQUFjLENBQUM7d0JBQ3hELENBQUM7d0JBQ0QsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLFdBQVcsSUFBSSxTQUFTLElBQUksS0FBSyxDQUFDLFdBQVcsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDOzRCQUM1RCxxQ0FBcUM7NEJBQ3JDLEdBQUcsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsa0JBQWtCLENBQUM7d0JBQzlELENBQUM7d0JBQ0Qsd0VBQXdFO3dCQUN4RSx1Q0FBdUM7d0JBQ3ZDLEdBQUc7d0JBQ0gsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLGFBQWEsSUFBSSxTQUFTLElBQUksS0FBSyxDQUFDLGFBQWEsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDOzRCQUNoRSwwQ0FBMEM7NEJBQzFDLEdBQUcsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsaUJBQWlCLENBQUM7d0JBQzdELENBQUM7d0JBQ0QsT0FBTyxDQUFDLEtBQUssQ0FBQzs0QkFDVixPQUFPLEVBQUUsR0FBRyxFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsWUFBWTs0QkFDMUMsT0FBTyxFQUFFO2dDQUNMLEVBQUUsRUFBRTtvQ0FDQSxjQUFjO29DQUNkLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUztpQ0FDNUI7NkJBQ0o7eUJBQ0osQ0FBQyxDQUFDO29CQUNQLENBQUM7Z0JBRUwsQ0FBQztnQkFDRCxtQ0FBVyxHQUFYLFVBQVksUUFBUTtvQkFDaEIsV0FBVztvQkFDWCxpS0FBaUs7b0JBQ2pLLE1BQU0sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxXQUFXLElBQUksU0FBUyxJQUFJLFFBQVEsQ0FBQyxXQUFXLElBQUksRUFBRSxDQUFDLENBQUE7b0JBQ3BFLGlGQUFpRjtvQkFDakYsMkVBQTJFO29CQUMzRSxzRUFBc0U7b0JBQ3RFLDJEQUEyRDtvQkFDM0QsOEZBQThGO2dCQUN0RyxDQUFDO2dCQUNELGlDQUFTLEdBQVQsVUFBVSxRQUFRO29CQUNkLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUU3QixRQUFRLENBQUM7d0JBQ1QsdUNBQXVDO3dCQUN2QyxJQUFJLElBQUksR0FBRyxFQUFFLENBQUM7d0JBQ2QsSUFBSSxHQUFHLEdBQUcsQ0FBQyxDQUFDO3dCQUNaLElBQUksT0FBTyxHQUFHLENBQUMsQ0FBQzt3QkFDaEIsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFOzRCQUMxQixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLFdBQVcsQ0FBQyxDQUFDLENBQUM7Z0NBRTNCLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO2dDQUNsQixHQUFHLEdBQUcsQ0FBQyxDQUFDO2dDQUNSLE9BQU8sR0FBRyxDQUFDLENBQUM7Z0NBQ1osTUFBTSxDQUFDLEtBQUssQ0FBQzs0QkFDakIsQ0FBQzt3QkFDTCxDQUFDLENBQUMsQ0FBQzt3QkFDSCxJQUFJLFFBQVEsR0FBRyxFQUFFLFdBQVcsRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRSxNQUFNLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFLFFBQVEsRUFBRSxFQUFFLEVBQUUsYUFBYSxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxLQUFLLEdBQUcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsWUFBWSxFQUFFLEtBQUssR0FBRyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDO3dCQUVqVCxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7b0JBSWxELENBQUM7b0JBQ0QsSUFBSSxDQUFDLENBQUM7d0JBQ0YsSUFBSSxHQUFHLEdBQUcsRUFBRSxDQUFDO3dCQUNiLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxXQUFXLElBQUksU0FBUyxJQUFJLFFBQVEsQ0FBQyxXQUFXLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzs0QkFDbEUsd0NBQXdDOzRCQUN4QyxHQUFHLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLG9CQUFvQixDQUFDO3dCQUNoRSxDQUFDO3dCQUNELDREQUE0RDt3QkFDNUQsOENBQThDO3dCQUM5QyxnRUFBZ0U7d0JBQ2hFLEdBQUc7d0JBQ0gseUNBQXlDO3dCQUN6QyxpREFBaUQ7d0JBQ2pELEdBQUc7d0JBQ0gsT0FBTyxDQUFDLEtBQUssQ0FBQzs0QkFDVixPQUFPLEVBQUUsR0FBRyxFQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsWUFBWTs0QkFDekMsT0FBTyxFQUFFO2dDQUNMLEVBQUUsRUFBRTtvQ0FDQSxjQUFjO29DQUNkLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUztpQ0FDNUI7NkJBQ0o7eUJBQ0osQ0FBQyxDQUFDO29CQUVQLENBQUM7Z0JBRUwsQ0FBQztnQkFDRCxtQ0FBVyxHQUFYLFVBQVksUUFBUTtvQkFDaEIsV0FBVztvQkFDWCxpQkFBaUI7b0JBQ2pCLE1BQU0sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxTQUFTLElBQUksU0FBUyxJQUFJLFFBQVEsQ0FBQyxTQUFTLElBQUksRUFBRSxDQUFDLENBQUM7b0JBQ3JFLDBEQUEwRDtnQkFFOUQsQ0FBQztnQkFDRCxpQ0FBUyxHQUFULFVBQVUsUUFBUTtvQkFDZCxXQUFXO29CQUNYLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUM3QixJQUFJLFFBQVEsR0FBRyxDQUFDLENBQUM7d0JBQ2pCLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRTs0QkFDM0IsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxXQUFXLENBQUMsQ0FBQyxDQUFDO2dDQUkzQixRQUFRLEdBQUcsQ0FBQyxDQUFDO2dDQUNaLE1BQU0sQ0FBQyxLQUFLLENBQUM7NEJBQ2pCLENBQUM7d0JBQ0wsQ0FBQyxDQUFDLENBQUM7d0JBQ0gsdUNBQXVDO3dCQUN2QyxJQUFJLElBQUksR0FBRyxFQUFFLENBQUM7d0JBQ2QsSUFBSSxDQUFDLEtBQUssR0FBRyxFQUFFLENBQUM7d0JBQ2hCLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUM7d0JBQ3hDLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDO3dCQUN4QixJQUFJLENBQUMsT0FBTyxHQUFHLFFBQVEsQ0FBQzt3QkFDeEIsSUFBSSxDQUFDLFNBQVMsR0FBRSxNQUFNLEdBQUcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxNQUFNLEdBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUM7d0JBQzlFLElBQUksQ0FBQyxhQUFhLEdBQUUsTUFBTSxHQUFHLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRSxDQUFDO3dCQUNoRixJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBR2xELENBQUM7b0JBQ0QsSUFBSSxDQUFDLENBQUM7d0JBQ0YsSUFBSSxHQUFHLEdBQUcsRUFBRSxDQUFDO3dCQUNiLDBEQUEwRDt3QkFDMUQsdUNBQXVDO3dCQUN2QyxpRUFBaUU7d0JBQ2pFLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxTQUFTLElBQUksU0FBUyxJQUFJLFFBQVEsQ0FBQyxTQUFTLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzs0QkFDOUQsZ0NBQWdDOzRCQUNoQyxHQUFHLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLG1CQUFtQixDQUFDO3dCQUMvRCxDQUFDO3dCQUNELE9BQU8sQ0FBQyxLQUFLLENBQUM7NEJBQ1YsT0FBTyxFQUFFLEdBQUcsRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLFlBQVk7NEJBQzFDLE9BQU8sRUFBRTtnQ0FDTCxFQUFFLEVBQUU7b0NBQ0EsY0FBYztvQ0FDZCxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVM7aUNBQzVCOzZCQUNKO3lCQUNKLENBQUMsQ0FBQztvQkFFUCxDQUFDO29CQUVELDhEQUE4RDtnQkFDbEUsQ0FBQztnQkFFRCxtQ0FBVyxHQUFYLFVBQVksR0FBRztvQkFBZixpQkEyR0M7b0JBMUdHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFDeEUsWUFBWTt3QkFDWCxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDdEQsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLFVBQVUsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDOzRCQUNoQyxLQUFJLENBQUMsYUFBYSxHQUFHLEtBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGNBQWMsQ0FBQzs0QkFDN0Qsd0VBQXdFOzRCQUN4RSxLQUFJLENBQUMsT0FBTyxHQUFHLGlCQUFpQixDQUFDOzRCQUNqQyxFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDN0MsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsQ0FBQyxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsT0FBTyxFQUFFLENBQUMsRUFBRSxTQUFTLEVBQUUsT0FBTyxFQUFFLGFBQWEsRUFBRSxPQUFPLEVBQUUsQ0FBQyxDQUFBOzRCQUNuSyxDQUFDOzRCQUNELElBQUksQ0FBQyxDQUFDO2dDQUNGLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQztnQ0FFZCxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxFQUFFO29DQUN4QyxJQUFJLENBQUMsU0FBUyxHQUFHLE1BQU0sR0FBRyxLQUFLLENBQUM7b0NBQ2hDLElBQUksQ0FBQyxhQUFhLEdBQUcsTUFBTSxHQUFHLEtBQUssRUFBRSxDQUFDO2dDQUMxQyxDQUFDLENBQUMsQ0FBQzs0QkFDUCxDQUFDOzRCQUNELEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUM3QyxJQUFJLElBQUksR0FBRyxFQUFFLENBQUM7Z0NBRWQsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsV0FBVyxFQUFFO29DQUUxQixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLFdBQVcsQ0FBQyxDQUFDLENBQUM7d0NBRTNCLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO3dDQUNsQixNQUFNLENBQUMsS0FBSyxDQUFDO29DQUNqQixDQUFDO2dDQUNMLENBQUMsQ0FBQyxDQUFDO2dDQUVILEtBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLENBQUMsRUFBRSxXQUFXLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUUsUUFBUSxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsQ0FBQyxFQUFFLFFBQVEsRUFBRSxNQUFNLEVBQUUsWUFBWSxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUM7NEJBRzVLLENBQUM7NEJBQ0QsSUFBSSxDQUFDLENBQUM7Z0NBQ0YsSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO2dDQUNkLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUU7b0NBRXhDLElBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSyxHQUFHLEtBQUssQ0FBQztvQ0FDOUIsSUFBSSxDQUFDLFlBQVksR0FBRyxLQUFLLEdBQUcsS0FBSyxFQUFFLENBQUM7Z0NBQ3hDLENBQUMsQ0FBQyxDQUFDOzRCQUNQLENBQUM7NEJBQ0QsRUFBRSxDQUFDLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDaEQsSUFBSSxLQUFLLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQztnQ0FFL0MsSUFBSSxLQUFLLEdBQUcsS0FBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsT0FBTyxDQUFDLENBQUM7Z0NBQzdELEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO29DQUNqQixLQUFLLEdBQUcsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dDQUM3QyxJQUFJLElBQUksR0FBRyxFQUFFLENBQUM7Z0NBQ2QsSUFBSSxRQUFRLEdBQUcsTUFBTSxDQUFDO2dDQUN0QixFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sSUFBSSxFQUFFLElBQUksS0FBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLElBQUksU0FBUyxJQUFJLEtBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7b0NBQzNHLFFBQVEsR0FBRyxNQUFNLENBQUM7Z0NBQ3RCLENBQUM7Z0NBQ0QsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsYUFBYSxFQUFFO29DQUM1QixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLFFBQVEsQ0FBQyxDQUFDLENBQUM7d0NBRXhCLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO3dDQUNsQixNQUFNLENBQUMsS0FBSyxDQUFDO29DQUNqQixDQUFDO2dDQUVMLENBQUMsQ0FBQyxDQUFDO2dDQUNILEtBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLEdBQUcsQ0FBQyxFQUFFLE1BQU0sRUFBRSxFQUFFLEVBQUUsT0FBTyxFQUFFLEVBQUUsRUFBRSxRQUFRLEVBQUUsRUFBRSxFQUFFLEdBQUcsRUFBRSxFQUFFLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRSxPQUFPLEVBQUUsRUFBRSxFQUFFLGFBQWEsRUFBRSxJQUFJLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxXQUFXLEVBQUUsV0FBVyxFQUFFLFNBQVMsRUFBRSxDQUFDLENBQUM7NEJBQzNPLENBQUM7NEJBQ0QsSUFBSSxDQUFDLENBQUM7Z0NBQ0YsSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO2dDQUNsQixNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLEVBQUU7b0NBQzNDLElBQUksQ0FBQyxTQUFTLEdBQUcsVUFBVSxHQUFHLEtBQUssQ0FBQztvQ0FDcEMsSUFBSSxDQUFDLFdBQVcsR0FBRyxRQUFRLEdBQUcsS0FBSyxFQUFFLENBQUM7Z0NBQzFDLENBQUMsQ0FBQyxDQUFDOzRCQUNILENBQUM7NEJBQ0QsNERBQTREOzRCQUU1RCxxQ0FBcUM7NEJBR3JDLDJEQUEyRDs0QkFDM0QsNkdBQTZHOzRCQUM3RyxpQkFBaUI7NEJBQ2pCLG9DQUFvQzs0QkFDcEMsT0FBTzs0QkFDUCx1RUFBdUU7NEJBQ3ZFLDBEQUEwRDs0QkFDMUQsS0FBSzs0QkFDTCxLQUFJLENBQUMsVUFBVSxHQUFHLElBQUksR0FBRyxLQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7NEJBQzNELEtBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSyxDQUFDOzRCQUM3QixLQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQzt3QkFHN0IsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztnQkFDUCxDQUFDO2dCQUNELHNDQUFjLEdBQWQsVUFBZSxRQUFRO29CQUF2QixpQkErREM7b0JBOURHLFdBQVc7b0JBQ1gsbUVBQW1FO29CQUNuRSxJQUFJLE9BQU8sR0FBRyxFQUFFLENBQUM7b0JBQ2pCLE1BQU0sQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDLElBQUksQ0FBQzt3QkFDbEMsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQztvQkFDckMsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO29CQUNkLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUU7d0JBQ3hDLEVBQUUsQ0FBQyxDQUFDLElBQUksSUFBSSxRQUFRLENBQUMsQ0FBQyxDQUFDOzRCQUVuQixNQUFNLENBQUMsS0FBSyxDQUFBO3dCQUNoQixDQUFDO3dCQUNELEtBQUssR0FBRyxLQUFLLEdBQUcsQ0FBQyxDQUFDO29CQUN0QixDQUFDLENBQUMsQ0FBQztvQkFFSCxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLElBQUksU0FBUyxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsSUFBSSxJQUFJLElBQUksT0FBTyxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7d0JBQ2hGLElBQUksV0FBVyxHQUFHLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQzt3QkFDakMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMsQ0FBQyxTQUFTLENBQ3hELFVBQUMsSUFBSTs0QkFDRCxXQUFXOzRCQUNYLEVBQUU7NEJBQ0YsSUFBSSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzs0QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO2dDQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO29DQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtvQ0FDdEQsT0FBTyxFQUFFO3dDQUNMLEVBQUUsRUFBRTs0Q0FDQSxjQUFjOzRDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUzt5Q0FDNUI7cUNBQ0o7aUNBQ0osQ0FBQyxDQUFDOzRCQUNQLENBQUM7NEJBQ0QsSUFBSSxDQUFDLENBQUM7Z0NBQ0YsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksSUFBSSxTQUFTLElBQUksUUFBUSxDQUFDLElBQUksSUFBSSxJQUFJLElBQUksUUFBUSxDQUFDLElBQUksSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO29DQUU3RSxXQUFXO29DQUVYLGtHQUFrRztvQ0FDbEcsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksR0FBRyxDQUFDLENBQUMsQ0FBQzt3Q0FDNUIsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQzt3Q0FDaEQsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQzt3Q0FDcEQsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLE9BQU8sR0FBRyxDQUFDLENBQUM7b0NBQzFGLENBQUM7b0NBQ0QsSUFBSSxDQUFDLENBQUM7d0NBQ0YsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQzt3Q0FDcEQsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQzt3Q0FDaEQsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLE9BQU8sR0FBRyxDQUFDLENBQUM7b0NBQzFGLENBQUM7Z0NBRUwsQ0FBQzs0QkFFTCxDQUFDOzRCQUNELHdGQUF3Rjt3QkFDNUYsQ0FBQyxFQUNELFVBQUMsR0FBRzt3QkFFSixDQUFDLEVBQ0Q7d0JBRUEsQ0FBQyxDQUFDLENBQUM7b0JBQ1AsQ0FBQztnQkFDVCxDQUFDO2dCQUNELG9DQUFZLEdBQVosVUFBYSxRQUFRO29CQUNqQixXQUFXO29CQUNYLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQztvQkFDZCxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDO29CQUM3QixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGNBQWMsQ0FBQztvQkFJekQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLEdBQUcsUUFBUSxDQUFDLEtBQUssQ0FBQztvQkFDdkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEdBQUcsUUFBUSxDQUFDLFNBQVMsQ0FBQztvQkFDL0MsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLFdBQVcsQ0FBQztvQkFHbkQsSUFBSSxDQUFDLGFBQWEsR0FBRyxFQUFFLENBQUM7b0JBQ3hCLElBQUksQ0FBQyxhQUFhLEdBQUcsUUFBUSxDQUFDO2dCQUNsQyxDQUFDO2dCQUNELG1DQUFXLEdBQVgsVUFBWSxRQUFRO29CQUNoQixXQUFXO29CQUNYLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQztvQkFDZCxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxFQUFFO3dCQUN4QyxFQUFFLENBQUMsQ0FBQyxJQUFJLElBQUksUUFBUSxDQUFDLENBQUMsQ0FBQzs0QkFDbkIsTUFBTSxDQUFDLEtBQUssQ0FBQTt3QkFDaEIsQ0FBQzt3QkFDRCxLQUFLLEdBQUcsS0FBSyxHQUFHLENBQUMsQ0FBQztvQkFFdEIsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQztnQkFDcEQsQ0FBQztnQkFFRCxzQ0FBYyxHQUFkLFVBQWUsVUFBVTtvQkFDckIsV0FBVztvQkFDWCxJQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7b0JBQ2QsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQztvQkFDN0IsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxjQUFjLENBQUM7b0JBRTFELCtDQUErQztvQkFFOUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQztvQkFDeEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLEdBQUcsVUFBVSxDQUFDLE9BQU8sQ0FBQztvQkFDMUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLEdBQUcsVUFBVSxDQUFDLFFBQVEsQ0FBQztvQkFDNUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLEdBQUcsVUFBVSxDQUFDLEdBQUcsQ0FBQztvQkFDbEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEdBQUcsVUFBVSxDQUFDLFdBQVcsQ0FBQztvQkFDbEQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLEdBQUcsVUFBVSxDQUFDLE9BQU8sQ0FBQztvQkFDMUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLEdBQUcsVUFBVSxDQUFDLGFBQWEsQ0FBQztvQkFDdEQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEdBQUcsVUFBVSxDQUFDLFdBQVcsQ0FBQztvQkFDbEQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEdBQUcsVUFBVSxDQUFDLFdBQVcsQ0FBQztvQkFHbEQsSUFBSSxDQUFDLGVBQWUsR0FBRyxFQUFFLENBQUM7b0JBQzFCLElBQUksQ0FBQyxlQUFlLEdBQUcsVUFBVSxDQUFDO2dCQUN0QyxDQUFDO2dCQUVELHFDQUFhLEdBQWIsVUFBYyxVQUFVO29CQUNyQixhQUFhO29CQUNaLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQztvQkFDZCxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLEVBQUU7d0JBQzNDLEVBQUUsQ0FBQyxDQUFDLElBQUksSUFBSSxVQUFVLENBQUMsQ0FBQyxDQUFDOzRCQUNyQixNQUFNLENBQUMsS0FBSyxDQUFBO3dCQUNoQixDQUFDO3dCQUNELEtBQUssR0FBRyxLQUFLLEdBQUcsQ0FBQyxDQUFDO29CQUN0QixDQUFDLENBQUMsQ0FBQztvQkFDSCxJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0JBQ3ZELENBQUM7Z0JBQ0Qsb0NBQVksR0FBWixVQUFhLFFBQVE7b0JBRWpCLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQztvQkFDZCxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGNBQWMsQ0FBQTtvQkFDeEQsSUFBSSxJQUFJLEdBQUcsUUFBUSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7b0JBRTNDLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxHQUFHLFFBQVEsQ0FBQyxTQUFTLEdBQUcsR0FBRyxHQUFHLFFBQVEsQ0FBQyxXQUFXLENBQUM7b0JBRTlFLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxHQUFHLFFBQVEsQ0FBQyxTQUFTLENBQUM7b0JBQy9DLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxHQUFHLFFBQVEsQ0FBQyxNQUFNLENBQUM7b0JBQ3pDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7b0JBQ3JDLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxHQUFHLFFBQVEsQ0FBQyxLQUFLLENBQUM7b0JBQ3ZDLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxHQUFHLFFBQVEsQ0FBQyxLQUFLLENBQUM7b0JBQ3ZDLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQyxRQUFRLENBQUM7b0JBQzdDLElBQUksQ0FBQyxhQUFhLEdBQUcsRUFBRSxDQUFDO29CQUN4QixJQUFJLENBQUMsYUFBYSxHQUFHLFFBQVEsQ0FBQztnQkFDbEMsQ0FBQztnQkFDRCxtQ0FBVyxHQUFYLFVBQVksUUFBUTtvQkFFaEIsSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO29CQUNkLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUU7d0JBQ3hDLEVBQUUsQ0FBQyxDQUFDLElBQUksSUFBSSxRQUFRLENBQUMsQ0FBQyxDQUFDOzRCQUNuQixNQUFNLENBQUMsS0FBSyxDQUFBO3dCQUNoQixDQUFDO3dCQUNELEtBQUssR0FBRyxLQUFLLEdBQUcsQ0FBQyxDQUFDO29CQUN0QixDQUFDLENBQUMsQ0FBQztvQkFDSCxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDO2dCQUNwRCxDQUFDO2dCQUdELHlDQUFpQixHQUFqQjtvQkFDSSxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxFQUFFLENBQUM7b0JBQ3BDLElBQUksY0FBYyxHQUFHLEVBQUUsQ0FBQztvQkFDeEIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDO3dCQUMxQix3QkFBYSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsRUFBRSxjQUFjLENBQUMsQ0FBQztvQkFDL0csQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFFRix3QkFBYSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsRUFBRSxjQUFjLENBQUMsQ0FBQztvQkFDaEgsQ0FBQztvQkFDRCxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUMsQ0FBQyxHQUFDLGNBQWMsQ0FBQyxNQUFNLEVBQUMsQ0FBQyxFQUFFLEVBQUMsQ0FBQzt3QkFDeEMsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDO3dCQUNkLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ2hELElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFFOUMsQ0FBQztnQkFFTCxDQUFDO2dCQUVELDRCQUFJLEdBQUo7b0JBQ0csaUJBQWlCO29CQUNoQixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7d0JBQ3hCLElBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO3dCQUV0Qiw2QkFBNkI7d0JBQzdCLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsZ0JBQWdCLENBQUM7b0JBQ2xFLENBQUM7b0JBQ0QsSUFBSSxDQUFDLENBQUM7d0JBQ04sSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7d0JBQ3JCLDhCQUE4Qjt3QkFDOUIsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxnQkFBZ0IsQ0FBQztvQkFDOUQsQ0FBQztnQkFDTCxDQUFDO2dCQUNELHFDQUFhLEdBQWIsVUFBYyxTQUFTO29CQUF2QixpQkFzREM7b0JBckRHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsQ0FBQyxTQUFTLENBQ3ZELFVBQUMsSUFBSTt3QkFDRCxXQUFXO3dCQUNYLEVBQUU7d0JBQ0YsbUJBQW1CO3dCQUNuQixFQUFFLENBQUMsQ0FBQyxTQUFTLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQzs0QkFDckIsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQzs0QkFDdkMsSUFBSSxHQUFHLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUE7NEJBQ3JDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxhQUFhLENBQUM7Z0NBQy9CLFlBQVksRUFBRSxJQUFJO2dDQUNsQixVQUFVLEVBQUU7b0NBQ1IsYUFBYSxFQUFFLElBQUk7aUNBQ3RCO2dDQUNELDRCQUE0QjtnQ0FDNUIsVUFBVSxFQUFFLEdBQUc7NkJBQ2xCLENBQUMsQ0FBQzs0QkFDSCxJQUFJLE1BQU0sR0FBRyxFQUFFLENBQUM7NEJBRWhCLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUU7Z0NBQ3hDLE1BQU0sSUFBSSxJQUFJLENBQUMsc0JBQXNCLEdBQUcsR0FBRyxDQUFDOzRCQUNoRCxDQUFDLENBQUMsQ0FBQzs0QkFDSCxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQ3BCLHdCQUFhLENBQUMsZUFBZSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxFQUFFLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQTs0QkFDdkksQ0FBQzt3QkFDTCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7NEJBQ3hDLElBQUksR0FBRyxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFBOzRCQUNyQyxNQUFNLENBQUMsYUFBYSxDQUFDLENBQUMsYUFBYSxDQUFDO2dDQUNoQyxZQUFZLEVBQUUsSUFBSTtnQ0FDbEIsVUFBVSxFQUFFO29DQUNSLGFBQWEsRUFBRSxJQUFJO2lDQUN0QjtnQ0FDRCw0QkFBNEI7Z0NBQzVCLFVBQVUsRUFBRSxHQUFHOzZCQUNsQixDQUFDLENBQUM7NEJBQ0gsSUFBSSxNQUFNLEdBQUcsRUFBRSxDQUFDOzRCQUNoQixNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxFQUFFO2dDQUN4QyxNQUFNLElBQUksSUFBSSxDQUFDLHNCQUFzQixHQUFHLEdBQUcsQ0FBQzs0QkFDaEQsQ0FBQyxDQUFDLENBQUM7NEJBQ0gsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUNwQix3QkFBYSxDQUFDLGVBQWUsQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsRUFBRSxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUE7NEJBQ3hJLENBQUM7d0JBQ0wsQ0FBQzt3QkFDRCx3RkFBd0Y7b0JBQzVGLENBQUMsRUFDRCxVQUFDLEdBQUc7b0JBRUosQ0FBQyxFQUNEO29CQUVBLENBQUMsQ0FDSixDQUFDO2dCQUNOLENBQUM7Z0JBQ0Qsd0NBQWdCLEdBQWhCLFVBQWlCLEtBQVU7b0JBRXZCLDhDQUE4QztvQkFDOUMsdUJBQXVCO29CQUN2Qiw2R0FBNkc7b0JBQ3pHLG9FQUFvRTtvQkFDeEUsd0JBQXdCO29CQUN4QixpQ0FBaUM7b0JBQ2pDLHdGQUF3RjtvQkFFeEYsb0RBQW9EO29CQUNwRCw2Q0FBNkM7b0JBQzdDLHlDQUF5QztvQkFDekMsZUFBZTtvQkFDZixvQkFBb0I7b0JBQ3BCLHFDQUFxQztvQkFDckMsZ0RBQWdEO29CQUNoRCw0RUFBNEU7b0JBQzVFLDBEQUEwRDtvQkFDMUQseURBQXlEO29CQUV6RCxtQkFBbUI7b0JBRW5CLGVBQWU7b0JBQ2Ysc0JBQXNCO29CQUN0QixpQ0FBaUM7b0JBQ2pDLG9CQUFvQjtvQkFDcEIsMENBQTBDO29CQUMxQyxhQUFhO29CQUNiLDhCQUE4QjtvQkFDOUIsT0FBTztvQkFFUCxHQUFHO29CQUNILHNCQUFzQjtnQkFDMUIsQ0FBQztnQkFHRCxnQ0FBUSxHQUFSO29CQUFBLGlCQXFlQztvQkFuZUUsWUFBWTtvQkFDWCw4Q0FBOEM7b0JBQzlDLEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzt3QkFDckMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUM7b0JBQ3ZDLENBQUM7b0JBQ0QsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO3dCQUVoRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsRUFBRSxDQUFDLENBQUM7b0JBQ3RELENBQUM7b0JBQ0QsSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7b0JBQ3RCLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztvQkFDdEIsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUM7b0JBRTVCLGtDQUFrQztvQkFFbEMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDbEMsK0JBQStCO3dCQUMvQixJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQzt3QkFFbEMsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxjQUFjLENBQUM7d0JBQzdELHdFQUF3RTt3QkFDeEUsbUNBQW1DO3dCQUVuQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDOzRCQUNoRCxJQUFJLEtBQUssR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDOzRCQUUvQyxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxPQUFPLENBQUMsQ0FBQzs0QkFDN0QsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7Z0NBQ2pCLEtBQUssR0FBRyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7NEJBQzdDLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQzs0QkFDZCxJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUM7NEJBQ3RCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQztnQ0FDM0csUUFBUSxHQUFHLE1BQU0sQ0FBQzs0QkFDdEIsQ0FBQzs0QkFDRCxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUU7Z0NBQzVCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksUUFBUSxDQUFDLENBQUMsQ0FBQztvQ0FFeEIsSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7b0NBQ2xCLE1BQU0sQ0FBQyxLQUFLLENBQUM7Z0NBQ2pCLENBQUM7NEJBRUwsQ0FBQyxDQUFDLENBQUM7NEJBQ0gsSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsR0FBRyxDQUFDLEVBQUUsTUFBTSxFQUFFLEVBQUUsRUFBRSxPQUFPLEVBQUUsRUFBRSxFQUFFLFFBQVEsRUFBRSxFQUFFLEVBQUUsR0FBRyxFQUFFLEVBQUUsRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLE9BQU8sRUFBRSxFQUFFLEVBQUUsYUFBYSxFQUFFLElBQUksRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFFLFdBQVcsRUFBRSxXQUFXLEVBQUUsU0FBUyxFQUFFLENBQUMsQ0FBQzt3QkFDM08sQ0FBQzt3QkFDRCxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUE7d0JBQzFELElBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSyxDQUFDO29CQUVqQyxDQUFDO29CQUNELElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDcEQsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDdkIsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDekQsQ0FBQztvQkFDRCxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztvQkFDMUIseUpBQXlKO29CQUV4SixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7d0JBQ3BCLElBQUksQ0FBQyxXQUFXLEdBQUcsT0FBTyxDQUFDO3dCQUMzQixJQUFJLENBQUMsU0FBUyxHQUFHLFVBQVUsQ0FBQzt3QkFDNUIsSUFBSSxDQUFDLFlBQVksR0FBRyxhQUFhLENBQUM7b0JBSXRDLENBQUM7b0JBQ0QsSUFBSSxDQUFDLENBQUM7d0JBQ0YsSUFBSSxDQUFDLFNBQVMsR0FBRyxVQUFVLENBQUM7d0JBQzVCLElBQUksQ0FBQyxZQUFZLEdBQUcsWUFBWSxDQUFDO29CQUNyQyxDQUFDO29CQUdGLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFDekUsV0FBVzt3QkFDWCxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDdEQsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLEdBQUcsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDOzRCQUN6QixLQUFJLENBQUMsWUFBWSxHQUFHLEtBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGdCQUFnQixDQUFDOzRCQUM5RCxLQUFJLENBQUMsU0FBUyxHQUFHLEtBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGtCQUFrQixDQUFDOzRCQUM3RCxLQUFJLENBQUMsYUFBYSxHQUFHLEtBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLFlBQVksQ0FBQzs0QkFDM0QsS0FBSSxDQUFDLGlCQUFpQixHQUFHLEtBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGdCQUFnQixDQUFDOzRCQUNuRSxLQUFJLENBQUMsZUFBZSxHQUFHLEtBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGNBQWMsQ0FBQzt3QkFFbkUsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFDSCw2QkFBNkI7b0JBRTdCLFVBQVU7b0JBQ1YsSUFBSSxXQUFXLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUM7b0JBQzNDLElBQUksU0FBUyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDO29CQUNyQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLFdBQVcsRUFBRSxTQUFTLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUN0RSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDdEQsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsSUFBSSxlQUFlLEdBQUcsRUFBRSxDQUFDOzRCQUN6QixNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUU7Z0NBQ3ZCLElBQUksT0FBTyxHQUFHLEVBQUUsQ0FBQztnQ0FDakIsT0FBTyxDQUFDLEVBQUUsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO2dDQUN4QixPQUFPLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUM7Z0NBQ3pCLGVBQWUsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7NEJBQ2xDLENBQUMsQ0FBQyxDQUFDOzRCQUNILEtBQUksQ0FBQyxPQUFPLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzs0QkFDN0IsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQztnQ0FDdEIscUJBQXFCO2dDQUNyQixNQUFNLEVBQUUsZUFBZTtnQ0FDdkIsa0JBQWtCO2dDQUNsQixRQUFRLEVBQUUsTUFBTTs2QkFJbkIsQ0FBQyxDQUFDO3dCQUNQLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBT0YsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMscUJBQXFCLEVBQUUsQ0FBQztvQkFDbkUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFFbkQsSUFBSSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDdEQsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLFVBQVUsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDOzRCQUNoQyxFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksSUFBSSxFQUFFLElBQUksS0FBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLElBQUksU0FBUyxJQUFJLEtBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7Z0NBQzFILElBQUksVUFBVSxDQUFDO2dDQUNmLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLFVBQVUsRUFBRTtvQ0FDekIsVUFBVSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7b0NBQ3hCLE1BQU0sQ0FBQyxLQUFLLENBQUM7Z0NBQ2pCLENBQUMsQ0FBQyxDQUFDO2dDQUNILEtBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxHQUFHLFVBQVUsQ0FBQzs0QkFDOUMsQ0FBQzt3QkFDTCxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUdILFdBQVc7b0JBQ1gsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsRUFBRSxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQzdDLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQ3RELE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEtBQUksQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzs0QkFDOUIsRUFBRSxDQUFDLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsSUFBSSxFQUFFLElBQUksS0FBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsSUFBSSxTQUFTLElBQUksS0FBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO2dDQUN0SSxJQUFJLE1BQU0sQ0FBQztnQ0FDWCxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUksQ0FBQyxRQUFRLEVBQUU7b0NBQ3ZCLE1BQU0sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO29DQUNwQixNQUFNLENBQUMsS0FBSyxDQUFDO2dDQUNqQixDQUFDLENBQUMsQ0FBQztnQ0FDSCxLQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixHQUFHLE1BQU0sQ0FBQzs0QkFDOUMsQ0FBQzt3QkFDTCxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUVILGNBQWM7b0JBQ2QsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksRUFBRSxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7d0JBQ25ELFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUN0RCxPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsVUFBVSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7NEJBQ2hDLEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLEVBQUUsSUFBSSxLQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxTQUFTLElBQUksS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQztnQ0FDcEgsSUFBSSxLQUFLLENBQUM7Z0NBQ1YsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsVUFBVSxFQUFFO29DQUN6QixLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztvQ0FDbkIsTUFBTSxDQUFDLEtBQUssQ0FBQztnQ0FDakIsQ0FBQyxDQUFDLENBQUM7Z0NBQ0gsS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDOzRCQUN2QyxDQUFDO3dCQUNMLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsYUFBYTtvQkFDYixJQUFJLENBQUMsZ0JBQWdCLENBQUMsV0FBVyxFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFDbEQsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQ3RELE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEtBQUksQ0FBQyxTQUFTLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzt3QkFDbkMsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFDSCxlQUFlO29CQUNmLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxhQUFhLEVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUNyRCxZQUFZO3dCQUNYLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUN0RCxPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsV0FBVyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7NEJBQ2pDLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQzs0QkFDZCxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUksQ0FBQyxXQUFXLEVBQUU7Z0NBQzFCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksV0FBVyxDQUFDLENBQUMsQ0FBQztvQ0FFM0IsSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7b0NBQ2xCLE1BQU0sQ0FBQyxLQUFLLENBQUM7Z0NBQ2pCLENBQUM7NEJBQ0wsQ0FBQyxDQUFDLENBQUM7NEJBQ0gsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQzt3QkFDekQsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFHSCxJQUFJLFFBQVEsR0FBRyxDQUFDLENBQUM7b0JBQ2pCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUM3QyxJQUFJLElBQUksR0FBRyxFQUFFLENBQUM7d0JBRWQsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFOzRCQUMxQixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLFdBQVcsQ0FBQyxDQUFDLENBQUM7Z0NBRTNCLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO2dDQUNsQixRQUFRLEdBQUcsQ0FBQyxDQUFDO2dDQUNiLE1BQU0sQ0FBQyxLQUFLLENBQUM7NEJBQ2pCLENBQUM7d0JBQ0wsQ0FBQyxDQUFDLENBQUM7d0JBRUgsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsQ0FBQyxFQUFFLFdBQVcsRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLEVBQUUsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUUsRUFBRSxFQUFFLFNBQVMsRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRSxZQUFZLEVBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQztvQkFHekwsQ0FBQztvQkFDRCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDN0MsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsQ0FBQyxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxTQUFTLEVBQUUsT0FBTyxFQUFFLGFBQWEsRUFBQyxPQUFPLEVBQUUsQ0FBQyxDQUFBO29CQUN6SyxDQUFDO29CQUVELGlCQUFpQjtvQkFDakIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGVBQWUsRUFBRSxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7d0JBQ3RELFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUN0RCxPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsYUFBYSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7NEJBQ3BDLFlBQVk7NEJBQ1gsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDOzRCQUNkLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLGFBQWEsRUFBRTtnQ0FDNUIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxNQUFNLENBQUMsQ0FBQyxDQUFDO29DQUV0QixJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztvQ0FDbEIsTUFBTSxDQUFDLEtBQUssQ0FBQztnQ0FDakIsQ0FBQzs0QkFFTCxDQUFDLENBQUMsQ0FBQzs0QkFDSCxLQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7d0JBQzlELENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsUUFBUTtvQkFFUixJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFDaEQsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQ3RELE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEtBQUksQ0FBQyxPQUFPLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzt3QkFDakMsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFDSCxhQUFhO29CQUViLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLEVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUNuRCxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDdEQsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLFVBQVUsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO3dCQUNwQyxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUNILFVBQVU7b0JBQ1YsSUFBSSxXQUFXLEdBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUM7b0JBQzFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFDM0QsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQ3RELE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEtBQUksQ0FBQyxPQUFPLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzt3QkFDakMsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFHSCxZQUFZO29CQUVaLHFDQUFxQztvQkFDckMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxTQUFTLENBQzVELFVBQUMsSUFBSTt3QkFDRixZQUFZO3dCQUNYLEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxTQUFTLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQzs0QkFDMUIsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQzs0QkFDdkMsSUFBSSxHQUFHLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUE7NEJBQ3JDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxhQUFhLENBQUM7Z0NBQy9CLFlBQVksRUFBRSxJQUFJO2dDQUNsQixVQUFVLEVBQUU7b0NBQ1IsYUFBYSxFQUFFLElBQUk7aUNBQ3RCO2dDQUNELDRCQUE0QjtnQ0FDNUIsVUFBVSxFQUFFLEdBQUc7NkJBRWxCLENBQUMsQ0FBQzs0QkFDSCxJQUFJLE1BQU0sR0FBRyxFQUFFLENBQUM7NEJBQ2hCLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUU7Z0NBQ3hDLE1BQU0sSUFBSSxJQUFJLENBQUMsc0JBQXNCLEdBQUcsR0FBRyxDQUFDOzRCQUNoRCxDQUFDLENBQUMsQ0FBQzs0QkFDSCxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQ3BCLHdCQUFhLENBQUMsZUFBZSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxFQUFFLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQTs0QkFDdkksQ0FBQzt3QkFDTCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7NEJBQ3hDLElBQUksR0FBRyxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFBOzRCQUNyQyxNQUFNLENBQUMsYUFBYSxDQUFDLENBQUMsYUFBYSxDQUFDO2dDQUNoQyxZQUFZLEVBQUUsSUFBSTtnQ0FDbEIsVUFBVSxFQUFFO29DQUNSLGFBQWEsRUFBRSxJQUFJO2lDQUN0QjtnQ0FDRCw0QkFBNEI7Z0NBQzVCLFVBQVUsRUFBRSxHQUFHOzZCQUNsQixDQUFDLENBQUM7NEJBQ0gsSUFBSSxNQUFNLEdBQUcsRUFBRSxDQUFDOzRCQUNoQixNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxFQUFFO2dDQUN4QyxNQUFNLElBQUksSUFBSSxDQUFDLHNCQUFzQixHQUFHLEdBQUcsQ0FBQzs0QkFDaEQsQ0FBQyxDQUFDLENBQUM7NEJBQ0gsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUNwQix3QkFBYSxDQUFDLGVBQWUsQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsRUFBRSxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUE7NEJBQ3hJLENBQUM7d0JBQ0wsQ0FBQztvQkFDTCxDQUFDLEVBQ0QsVUFBQyxHQUFHO29CQUVKLENBQUMsRUFDRDtvQkFFQSxDQUFDLENBQ0osQ0FBQztvQkFFRiw4Q0FBOEM7b0JBQy9DLGlEQUFpRDtvQkFDaEQsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDO29CQUVwQixjQUFjO29CQUNkLE1BQU0sQ0FBQyx5Q0FBeUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztvQkFDdEUsTUFBTSxDQUFDLHNDQUFzQyxDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO29CQUNuRSxzQkFBc0I7Z0JBRTFCLENBQUM7Z0JBaGtFTSxxQkFBTyxHQUFHLENBQUMsUUFBUSxFQUFFLFdBQVcsRUFBRSxlQUFlLENBQUMsQ0FBQztnQkF2RDlEO29CQUFDLGdCQUFTLENBQUM7d0JBRVAsV0FBVyxFQUFFLDZDQUE2Qzt3QkFDMUQsVUFBVSxFQUFFLENBQUMsaUJBQVEsRUFBRSxxQkFBWSxFQUFFLHdCQUFlLEVBQUUsdUJBQXVCLEVBQUUsd0JBQWUsRUFBRSx3QkFBZSxFQUFFLDBCQUFRLENBQUM7d0JBQzFILFNBQVMsRUFBRSxDQUFDLGlDQUFlLEVBQUUsaUNBQWUsQ0FBQztxQkFDaEQsQ0FBQzs7aUNBQUE7Z0JBbW5FRixvQkFBQztZQUFELENBam5FQSxBQWluRUMsSUFBQTtZQWpuRUQseUNBaW5FQyxDQUFBIiwiZmlsZSI6ImRldi9hbWF4L0N1c3RvbWVyTm90ZXMvQ3VzdG9tZXJOb3Rlcy5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7TmdTd2l0Y2gsIE5nU3dpdGNoV2hlbiwgTmdTd2l0Y2hEZWZhdWx0LCBDT1JFX0RJUkVDVElWRVMsIEZPUk1fRElSRUNUSVZFU30gZnJvbSAnYW5ndWxhcjIvY29tbW9uJ1xyXG5pbXBvcnQge1Jlc291cmNlU2VydmljZX0gZnJvbSBcIi4uLy4uL3NlcnZpY2VzL1Jlc291cmNlU2VydmljZVwiO1xyXG5pbXBvcnQge1JvdXRlUGFyYW1zfSBmcm9tIFwiYW5ndWxhcjIvcm91dGVyXCI7XHJcbmltcG9ydCB7Q29tcG9uZW50LCBPdXRwdXQsIElucHV0LCBFdmVudEVtaXR0ZXIsIE9uSW5pdH0gZnJvbSBcImFuZ3VsYXIyL2NvcmVcIjtcclxuaW1wb3J0IHtDdXN0b21lclNlcnZpY2V9IGZyb20gXCIuLi8uLi9zZXJ2aWNlcy9DdXN0b21lclNlcnZpY2VcIjtcclxuaW1wb3J0IHsganNvblEgfSBmcm9tICcuLi8uLi9qc29uUSc7XHJcbmltcG9ydCB7R3JvdXBGaWx0ZXJQaXBlLCBHcm91cFBhcmVuRmlsdGVyUGlwZSwgS2VuZG9fdXRpbGl0eX0gZnJvbSBcIi4uLy4uL2FtYXhVdGlsXCI7XHJcbmltcG9ydCB7QXV0b2NvbXBsZXRlQ29udGFpbmVyfSBmcm9tICcuLi8uLi9hdXRvY29tcGxldGUvYXV0b2NvbXBsZXRlLWNvbnRhaW5lcic7XHJcbmltcG9ydCB7QXV0b2NvbXBsZXRlfSBmcm9tICcuLi8uLi9hdXRvY29tcGxldGUvYXV0b2NvbXBsZXRlLmNvbXBvbmVudCc7XHJcbmltcG9ydCB7IEFtYXhEYXRlIH0gZnJvbSAnLi4vLi4vY29tb25Db21wb25lbnRzL2Jhc2ljQ29tcG9uZW50cyc7XHJcblxyXG5leHBvcnQgY29uc3QgQVVUT0NPTVBMRVRFX0RJUkVDVElWRVMgPSBbQXV0b2NvbXBsZXRlLCBBdXRvY29tcGxldGVDb250YWluZXJdO1xyXG5kZWNsYXJlIHZhciBqUXVlcnk7XHJcbmRlY2xhcmUgdmFyIHN3YWw7XHJcbmRlY2xhcmUgdmFyIG1vbWVudDtcclxuQENvbXBvbmVudCh7XHJcblxyXG4gICAgdGVtcGxhdGVVcmw6ICcuL2FwcC9hbWF4L0N1c3RvbWVyL3RlbXBsYXRlcy9jdXN0b21lci5odG1sJyxcclxuICAgIGRpcmVjdGl2ZXM6IFtOZ1N3aXRjaCwgTmdTd2l0Y2hXaGVuLCBOZ1N3aXRjaERlZmF1bHQsIEFVVE9DT01QTEVURV9ESVJFQ1RJVkVTLCBDT1JFX0RJUkVDVElWRVMsIEZPUk1fRElSRUNUSVZFUywgQW1heERhdGVdLFxyXG4gICAgcHJvdmlkZXJzOiBbQ3VzdG9tZXJTZXJ2aWNlLCBSZXNvdXJjZVNlcnZpY2VdXHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgQW1heEN1c3RvbWVycyBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcbiAgICBtb2RlbElucHV0ID0ge307XHJcbiAgICBUZW1wbW9kZWxJbnB1dCA9IHt9O1xyXG4gICAgY3VzdFNlYXJjaERhdGE6IE9iamVjdCA9IFtdO1xyXG4gICAgUkVTOiBPYmplY3QgPSB7fTtcclxuICAgIFNlbGVjdGVkUGhUeXBlOiBPYmplY3QgPSB7fTtcclxuICAgIHRlbXBzdHJlZXRtc2c6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBGb3JtdHlwZTogc3RyaW5nID1cIkNVU1RPTUVSX01BU1RFUlwiO1xyXG4gICAgTGFuZzogc3RyaW5nPVwiXCI7XHJcbiAgICAvL21vZGVsSW5wdXQubG5hbWU9IFwiXCI7XHJcbiAgICBTaG93TW9yZTogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgSXNSZWNvcmRFZGl0TW9kZTogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgU2hvd01vcmVUZXh0OiBzdHJpbmcgPSBcIk1vcmVcIjtcclxuXHJcbiAgICBTaG93TG9hZGVyOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBTaG93TXNnOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBTaG93R3JvdXBzOiBib29sZWFuID0gdHJ1ZTtcclxuICAgIEdyb3VwVGV4dDogc3RyaW5nPVwiU2hvdyBHcm91cHNcIjtcclxuICAgIE1zZzogc3RyaW5nID0gXCJcIjtcclxuICAgIE1zZ0NsYXNzOiBzdHJpbmcgPSBcInRleHQtcHJpbWFyeVwiO1xyXG4gICAgSXNidG5kaXNhYmxlOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgSXNGaWxlQXNTYXZlQnRuOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgSXNGaWxlQXNDYW5jZWxCdG46IHN0cmluZyA9IFwiXCI7XHJcbiAgICBsYW5ndWFnZUFycmF5ID0gW107XHJcblxyXG4gICAgQWRkcmVzczogT2JqZWN0ID0ge307XHJcbiAgICBQaG9uZU1vZGVsOiBPYmplY3QgPSB7fTtcclxuICAgIEVtYWlsTW9kZWw6IE9iamVjdCA9IHt9O1xyXG4gICAgSXNTaG93QWxsOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBDdXN0TGlzdDogT2JqZWN0ID0ge307XHJcbiAgICBTQVZFX0JUTl9URVhUOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgXHJcbiAgICBCVE5fUEhBREQ6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBFZGl0UGhvbmVEYXRhOiBPYmplY3QgPSB7fTtcclxuICAgIEVkaXRBZGRyZXNzRGF0YTogT2JqZWN0ID0ge307XHJcbiAgICBFZGl0RW1haWxEYXRhOiBPYmplY3QgPSB7fTtcclxuICAgIGFkSWQ6IHN0cmluZztcclxuICAgIElzRmlsZUFzT3BlbjogYm9vbGVhbjtcclxuICAgIEFERF9ORVdfQ1VTVF9URVhUOiBzdHJpbmc7XHJcbiAgICBDU1NURVhUOiBzdHJpbmc7XHJcbiAgICBJc0ZpbGVBc3R4dFNob3c6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIEZJTEVBU19CVE5fVEVYVDogc3RyaW5nID0gXCJcIjtcclxuICAgIGNzc0ZpbGVBc0J0bjogc3RyaW5nID0gXCJcIjtcclxuICAgIElzQ2FuY2VsOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBTZWFyY2hWYWw6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBFbnRlckNvdW50OiBudW1iZXIgPSAwO1xyXG4gICAgU3RvcFRpbWVPdXQ6IGFueTtcclxuICAgIEN1c3RJZFRleHQ6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBzdGF0aWMgJGluamVjdCA9IFsnJHNjb3BlJywgJyRsb2NhdGlvbicsICckYW5jaG9yU2Nyb2xsJ107XHJcbiAgICBCYXNlQXBwVXJsOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgUGhJbmRleDogbnVtYmVyID0gMDtcclxuICAgIEtlbmRvUlRMQ1NTOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgQ0hBTkdFRElSOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgQ2hhbmdlRGlhbG9nOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgLy9Jc0ZpbGVBc1NhdmU6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIFxyXG4gICAgLy9FbWFpbDogc3RyaW5nID0gXCJcIjtcclxuICAgIC8vQ3VzdG9tZXJFbWFpbDogT2JqZWN0ID0ge307XHJcbiAgICAvL21vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMgPSBbXTtcclxuICAgIFxyXG4gICAgX0N1c3RUeXBlcyA9IFtdO1xyXG4gICAgX1NvdXJjZXMgPSBbXTtcclxuICAgIF9FbXBsb3llZXMgPSBbXTtcclxuICAgIF9TdWZmaXhlcyA9IFtdO1xyXG4gICAgX1Bob25lVHlwZXMgPSBbXTtcclxuICAgIF9BZGRyZXNzVHlwZXMgPSBbXTtcclxuICAgIF9Hcm91cHMgPSBbXTtcclxuICAgIF9Db3VudHJpZXMgPSBbXTtcclxuICAgIF9TdGF0ZXMgPSBbXTtcclxuICAgIF9DaXRpZXMgPSBbXTtcclxuXHJcbiAgICBwcml2YXRlIHNlbGVjdGVkQ2FyOiBzdHJpbmcgPSAnJztcclxuICAgIHByaXZhdGUgYXN5bmNTZWxlY3RlZENhcjogc3RyaW5nID0gJyc7XHJcbiAgICBwcml2YXRlIGF1dG9jb21wbGV0ZUxvYWRpbmc6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHByaXZhdGUgYXV0b2NvbXBsZXRlTm9SZXN1bHRzOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwcml2YXRlIGF1dG9jb21wbGV0ZVNlbGVjdDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgXHJcbiAgICBwcml2YXRlIGdldEN1cnJlbnRDb250ZXh0KCkge1xyXG4gICAgICAgIFxyXG4gICAgICAgIHJldHVybiB0aGlzO1xyXG4gICAgfVxyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBfcmVzb3VyY2VTZXJ2aWNlOiBSZXNvdXJjZVNlcnZpY2UsIHByaXZhdGUgX2N1c3RvbWVyU2VydmljZTogQ3VzdG9tZXJTZXJ2aWNlLCBwcml2YXRlIF9yb3V0ZVBhcmFtczogUm91dGVQYXJhbXMpIHtcclxuICAgICAgICBcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQmlydGhEYXRlID0gXCJcIjtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMgPSBbXTtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXMgPSBbXTtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMgPSBbXTtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJHcm91cHMgPSBbXTtcclxuICAgICAgICB0aGlzLkFkZHJlc3MuQ291bnRyeUNvZGU9XCJcIjtcclxuICAgICAgICB0aGlzLkFkZHJlc3MuU3RhdGVJZCA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LmVtcGxveWVlaWQgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclR5cGUgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DYW1lRnJvbUN1c3RvbWVyID0gXCJcIjtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuU2FmaXhpZCA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkdlbmRlciA9IFwiMFwiO1xyXG4gICAgICAgIHRoaXMuUGhvbmVNb2RlbC5QaG9uZVR5cGVJZCA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSID0ge307XHJcbiAgICAgICAgdGhpcy5Jc1Nob3dBbGwgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLlNBVkVfQlROX1RFWFQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0JUTl9TQVZFO1xyXG4gICAgICAgIHRoaXMuQlROX1BIQUREID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9CVE5fUEhBREQ7XHJcbiAgICAgICAgdGhpcy5BRERfTkVXX0NVU1RfVEVYVCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfTEJMX05FV19DVVNUO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlscyA9IFt7IEVtYWlsOiBcIlwiLCBFbWFpbE5hbWU6IFwiXCIsIE5ld3NsZXR0ZXJlOiB0cnVlLCBwdWJsaXNoOiAxLCBOZXdzT3JkZXI6IFwiTmV3czFcIiwgRVB1Ymxpc2hPcmRlcjpcIkVQdWIxXCIgfV1cclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXMgPSBbeyBQaG9uZVR5cGVJZDogXCJcIiwgUHJlZml4OiBcIlwiLCBBcmVhOiBcIlwiLCBQaG9uZTogXCJcIiwgSXNTbXM6IDEsIENvbW1lbnRzOiBcIlwiLCBJc1Nob3dSZW1hcmtzOiBmYWxzZSwgcGhwdWJsaXNoOiAxLCBTTVNPcmRlcjogXCJTTVMxXCIsUHVibGlzaE9yZGVyOiBcIlB1YjFcIn1dXHJcbiAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICB2YXIgZW1waWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImVtcGxveWVlaWRcIik7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdmFyIGNjb2RlID0gdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmdldENvb2tpZShlbXBpZCArIFwiY2NvZGVcIik7XHJcbiAgICAgICAgaWYgKGNjb2RlLmxlbmd0aCA+IDApXHJcbiAgICAgICAgICAgIGNjb2RlID0gY2NvZGUuc3Vic3RyaW5nKDEsIGNjb2RlLmxlbmd0aCk7XHJcblxyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3NlcyA9IFt7XHJcbiAgICAgICAgICAgIFN0cmVldDogXCJcIiwgU3RyZWV0MjogXCJcIiwgQ2l0eU5hbWU6IFwiXCIsIFppcDogXCJcIiwgQ291bnRyeUNvZGU6IGNjb2RlLCBTdGF0ZUlkOiBcIlwiLCBBZGRyZXNzVHlwZUlkOiBcIlwiLFxyXG4gICAgICAgICAgICBGb3JEZWxpdmVyeTogdHJ1ZSwgTWFpbkFkZHJlc3M6IHRydWUsIE1haW5PcmRlcjogXCJNYWluQWRkcjFcIiwgRGVsdnJ5T3JkZXI6IFwiRGVsdnJ5MVwiXHJcbiAgICAgICAgfV1cclxuXHJcbiAgICAgICAgXHJcbiAgICAgICAgXHJcblxyXG4gICAgICAgIHZhciBjdXN0dHlwZSA9IHRoaXMuX3Jlc291cmNlU2VydmljZS5nZXRDb29raWUoZW1waWQgKyBcImN1c3RcIik7XHJcbiAgICAgICAgaWYgKGN1c3R0eXBlLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIGN1c3R0eXBlID0gY3VzdHR5cGUuc3Vic3RyaW5nKDEsIGN1c3R0eXBlLmxlbmd0aCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclR5cGUgPSBjdXN0dHlwZTtcclxuXHJcblxyXG4gICAgICAgIHZhciBlbXAgPSB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZ2V0Q29va2llKGVtcGlkICsgXCJlbXBcIik7XHJcbiAgICAgICAgaWYgKGVtcC5sZW5ndGggPiAwKVxyXG4gICAgICAgICAgICBlbXAgPSBlbXAuc3Vic3RyaW5nKDEsIGVtcC5sZW5ndGgpO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5lbXBsb3llZWlkID0gZW1wO1xyXG5cclxuICAgICAgICB2YXIgc291cmNlID0gdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmdldENvb2tpZShlbXBpZCArIFwic3JjXCIpO1xyXG4gICAgICAgIGlmIChzb3VyY2UubGVuZ3RoID4gMClcclxuICAgICAgICAgICAgc291cmNlID0gc291cmNlLnN1YnN0cmluZygxLCBzb3VyY2UubGVuZ3RoKTtcclxuICAgICAgICBlbHNlIHtcclxuXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DYW1lRnJvbUN1c3RvbWVyID0gc291cmNlO1xyXG4gICAgICAgIHRoaXMuQ1NTVEVYVCA9IFwibWRpLWNvbnRlbnQtYWRkXCI7XHJcbiAgICAgICAgdGhpcy5jc3NGaWxlQXNCdG4gPSBcIm1kaS1jb250ZW50LWNyZWF0ZVwiO1xyXG4gICAgICAgIHRoaXMuSXNGaWxlQXN0eHRTaG93ID0gZmFsc2U7XHJcbiAgICAgICAgY2xlYXJUaW1lb3V0KHRoaXMuU3RvcFRpbWVPdXQpO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkID0gX3JvdXRlUGFyYW1zLnBhcmFtcy5JZDtcclxuICAgICAgICB0aGlzLkJhc2VBcHBVcmwgPSBfcmVzb3VyY2VTZXJ2aWNlLkFwcFVybDtcclxuICAgICAgICB0aGlzLlRlbXBtb2RlbElucHV0ID0gdGhpcy5tb2RlbElucHV0O1xyXG4gICAgICAgIFxyXG4gICAgICAgIC8vYWxlcnQodGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmdldENvb2tpZShlbXBpZCArIFwiY3VzdFwiKSk7XHJcbiAgICAgICAgLy90aGlzLlNob3dNb3JlVGV4dCA9IFwiTW9yZVwiO1xyXG4gICAgICAgIFxyXG4gICAgfVxyXG4gICAgcHJpdmF0ZSBfY2FjaGVkUmVzdWx0OiBhbnk7XHJcbiAgICBwcml2YXRlIF9wcmV2aW91c2FzeW5jU2VsZWN0ZWRDYXI6IHN0cmluZz0nJztcclxuICAgIFxyXG4gICAgZGF0ZVNlbGVjdGlvbkNoYW5nZShldnQpIHtcclxuICAgICAgICBjb25zb2xlLmxvZyhldnQpO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5CaXJ0aERhdGUgPSBldnQ7XHJcbiAgICAgICAvLyBhbGVydCh0aGlzLm1vZGVsSW5wdXQuQmlydGhEYXRlKTtcclxuICAgICAgICAvL3RoaXMudmFsaWRhdGVMb2dpbigpO1xyXG4gICAgfVxuXHJcbiAgIHByaXZhdGUgZ2V0QXN5bmNEYXRhKGNvbnRleHQ6IGFueSk6IEZ1bmN0aW9uIHtcclxuICAgICAgICBcclxuICAgICAgIHZhciBTcmNoVmFsID0gY29udGV4dC5hc3luY1NlbGVjdGVkQ2FyO1xyXG4gICAgICBcclxuICAgICAgLy8gaWYgKFNyY2hWYWwgIT0gdW5kZWZpbmVkICYmIFNyY2hWYWwgIT0gbnVsbCAmJiBTcmNoVmFsICE9IFwiXCIpIHtcclxuXHJcbiAgICAgICBcclxuICAgICAgICAgIC8vIGRlYnVnZ2VyO1xyXG4gICAgICAgaWYgKHRoaXMuX3ByZXZpb3VzYXN5bmNTZWxlY3RlZENhciA9PSBjb250ZXh0LmFzeW5jU2VsZWN0ZWRDYXIpIHtcclxuICAgICAgICAgICAgICAgLy9jbGVhclRpbWVvdXQodGhpcy5TdG9wVGltZU91dCk7XHJcbiAgICAgICAgICAgICAgIHJldHVybiB0aGlzLl9jYWNoZWRSZXN1bHQ7XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgLy9hbGVydCh0aGlzLl9wcmV2aW91c2FzeW5jU2VsZWN0ZWRDYXIgKyBcIiB8IFwiICsgY29udGV4dC5hc3luY1NlbGVjdGVkQ2FyKTtcclxuICAgICAgICAgICAgICAgaWYgKGNvbnRleHQuYXN5bmNTZWxlY3RlZENhciAhPSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICB0aGlzLl9wcmV2aW91c2FzeW5jU2VsZWN0ZWRDYXIgPSBjb250ZXh0LmFzeW5jU2VsZWN0ZWRDYXI7XHJcbiAgICAgICAgICAgICAgICAgLy8gIHRoaXMuU3RvcFRpbWVPdXQgPSBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgIC8vICAgIGFsZXJ0KFNyY2hWYWwpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRDb21wbGV0ZVNlYXJjaChTcmNoVmFsKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vYWxlcnQocmVzcG9uc2UuRXJyTXNnKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe21lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRleHQuY2Fyc0V4YW1wbGUxID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vcmV0dXJuIGNvbnRleHQuY2Fyc0V4YW1wbGUxO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgLy8gfSwgNTAwKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICB0aGlzLl9jYWNoZWRSZXN1bHQgPSBjb250ZXh0LmNhcnNFeGFtcGxlMTtcclxuICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgIHRoaXMuX2NhY2hlZFJlc3VsdCA9IFtdO1xyXG4gICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgIHJldHVybiB0aGlzLl9jYWNoZWRSZXN1bHQ7XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgICAgIFxyXG4gICAgICAgIFxyXG4gICAgfVxyXG4gICBcclxuICAgIHByaXZhdGUgY2hhbmdlQXV0b2NvbXBsZXRlTG9hZGluZyhlOiBib29sZWFuKSB7XHJcbiAgICAgICAgdGhpcy5hdXRvY29tcGxldGVMb2FkaW5nID0gZTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIGNoYW5nZUF1dG9jb21wbGV0ZU5vUmVzdWx0cyhlOiBib29sZWFuKSB7XHJcbiAgICAgICAgdGhpcy5hdXRvY29tcGxldGVTZWxlY3QgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLmF1dG9jb21wbGV0ZU5vUmVzdWx0cyA9IGU7XHJcbiAgICB9XHJcbiAgICBwcml2YXRlIGF1dG9jb21wbGV0ZU9uU2VsZWN0KGU6IGFueSkge1xyXG4gICAgICAgIHRoaXMuYXV0b2NvbXBsZXRlU2VsZWN0ID0gdHJ1ZTtcclxuICAgICAgICBjb25zb2xlLmxvZyhgU2VsZWN0ZWQgdmFsdWU6ICR7ZS5pdGVtfWApO1xyXG4gICAgICAgIHZhciBDb21wRGF0YSA9IGUuaXRlbS5zcGxpdCgnfCcpO1xyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgaWYgKGUuaXRlbSAhPSB1bmRlZmluZWQgJiYgZS5pdGVtICE9IFwiXCIgJiYgZS5pdGVtICE9IG51bGwpIHtcclxuICAgICAgICAgICAgLy9hbGVydChDb21wRGF0YVswXSk7XHJcbiAgICAgICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRDb21wbGV0ZUN1c3REZXQoQ29tcERhdGFbMF0udHJpbSgpKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAvL2FsZXJ0KHJlc3BvbnNlLkVyck1zZyk7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7bWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgICAgLy8gYWxlcnQodGhpcy5tb2RlbElucHV0LkJpcnRoRGF0ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5TQVZFX0JUTl9URVhUID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9CVE5fVVBEQVRFO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuQUREX05FV19DVVNUX1RFWFQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0xCTF9VUERBVEVfQ1VTVDtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLkNTU1RFWFQgPSBcIm1kaS1jb250ZW50LWNyZWF0ZVwiO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMubGVuZ3RoID09IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzID0gW3sgRW1haWw6IFwiXCIsIEVtYWlsTmFtZTogdGhpcy5tb2RlbElucHV0LkZpbGVBcywgTmV3c2xldHRlcmU6IGZhbHNlIH1dXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXMubGVuZ3RoID09IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHBoaWQgPSBcIlwiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLl9QaG9uZVR5cGVzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5UZXh0ID09IFwiQ2VsbFBob25lXCIpIHtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGhpZCA9IHRoaXMuVmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lcyA9IFt7IFBob25lVHlwZUlkOiBwaGlkLCBQcmVmaXg6IFwiXCIsIEFyZWE6IFwiXCIsIFBob25lOiBcIlwiLCBJc1NtczogMCwgQ29tbWVudHM6IFwiXCIsIHBocHVibGlzaDogMCB9XTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMubGVuZ3RoID09IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGVtcGlkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJlbXBsb3llZWlkXCIpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGNjb2RlID0gdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmdldENvb2tpZShlbXBpZCArIFwiY2NvZGVcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChjY29kZS5sZW5ndGggPiAwKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2NvZGUgPSBjY29kZS5zdWJzdHJpbmcoMSwgY2NvZGUubGVuZ3RoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGFkaWQgPSBcIlwiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgY29tcHRleHQgPSBcIkhvbWVcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5Db21wYW55ICE9IFwiXCIgJiYgdGhpcy5tb2RlbElucHV0LkNvbXBhbnkgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dC5Db21wYW55ICE9IG51bGwpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbXB0ZXh0ID0gXCJXb3JrXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5fQWRkcmVzc1R5cGVzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5UZXh0ID09IGNvbXB0ZXh0KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWRpZCA9IHRoaXMuVmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3NlcyA9IFt7IFN0cmVldDogXCJcIiwgU3RyZWV0MjogXCJcIiwgQ2l0eU5hbWU6IFwiXCIsIFppcDogXCJcIiwgQ291bnRyeUNvZGU6IGNjb2RlLCBTdGF0ZUlkOiBcIlwiLCBBZGRyZXNzVHlwZUlkOiBhZGlkLCBGb3JEZWxpdmVyeTogZmFsc2UsIE1haW5BZGRyZXNzOiBmYWxzZSB9XTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuQ3VzdElkVGV4dCA9IFwiKCBcIiArIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkICsgXCIgKVwiO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuSXNGaWxlQXN0eHRTaG93ID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgLy90aGlzLklzQ2FuY2VsID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICAvL3RoaXMuSGlkZVNob3dGaWxlQXN0eHQoKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLkNhbmNlbEZpbGVBc3R4dCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuSXNTaG93QWxsID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICAvL3RoaXMuYmluZEdyb3VwKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9hbGVydCh0aGlzLlJFUyk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5iaW5kR3JvdXBUcmVlKHRydWUpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIE9wZW5OZXdSZWNlaXB0KCkge1xyXG4gICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkICE9IHVuZGVmaW5lZCAmJiB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCA+PSAwKSB7XHJcbiAgICAgICAgICAgIHZhciBjdXN0SWQgPSB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZDtcclxuICAgICAgICAgICAgaWYgKGN1c3RJZCAhPSAtMSkge1xyXG4gICAgICAgICAgICAgICAgdmFyIGVtaWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImVtcGxveWVlaWRcIik7XHJcbiAgICAgICAgICAgICAgICBkb2N1bWVudC5sb2NhdGlvbiA9IHRoaXMuQmFzZUFwcFVybCArIFwiUmVjZWlwdFNlbGVjdC9cIiArIGVtaWQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBPcGVuQ2hhcmdlQ3JlZGl0UGFnZSgpIHtcclxuICAgICAgICB0aGlzLklzYnRuZGlzYWJsZSA9IFwiZGlzYWJsZWRcIjtcclxuICAgICAgICB0aGlzLl9jdXN0b21lclNlcnZpY2UuQ2hlY2tJc09wZW5DaGFyZ2UoKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgXHJcblxyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczogeyAgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gfX0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5EYXRhICE9IHVuZGVmaW5lZCAmJiByZXNwb25zZS5EYXRhICE9IG51bGwgJiYgcmVzcG9uc2UuRGF0YS5sZW5ndGggPT0gMSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBjdXN0SWQgPSAtMTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5UZW1wbW9kZWxJbnB1dCAhPSB1bmRlZmluZWQgJiYgdGhpcy5UZW1wbW9kZWxJbnB1dC5DdXN0b21lcklkICE9IHVuZGVmaW5lZCAmJiB0aGlzLlRlbXBtb2RlbElucHV0LkN1c3RvbWVySWQgPj0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjdXN0SWQgPSB0aGlzLlRlbXBtb2RlbElucHV0LkN1c3RvbWVySWRcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dCAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkID49IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY3VzdElkID0gdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWRcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGN1c3RJZCAhPSAtMSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBkb2N1bWVudC5sb2NhdGlvbiA9IHRoaXMuQmFzZUFwcFVybCArIFwiQ2hhcmdlQ3JlZGl0L1wiICsgY3VzdElkICsgXCIvXCIgKyByZXNwb25zZS5EYXRhWzBdLlZhbHVlO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogJ1BsZWFzZSBzYXZlIG5ldyBvciBsb2FkIHByZXZpb3VzIGN1c3RvbWVyIGFuZCB0aGVuIGNsaWNrIG9uIGNoYXJnZSBjcmVkaXQgYnV0dG9uJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIGlmIChyZXNwb25zZS5EYXRhICE9IHVuZGVmaW5lZCAmJiByZXNwb25zZS5EYXRhICE9IG51bGwgJiYgcmVzcG9uc2UuRGF0YS5sZW5ndGggPiAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgY3VzdElkID0gLTE7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuVGVtcG1vZGVsSW5wdXQgIT0gdW5kZWZpbmVkICYmIHRoaXMuVGVtcG1vZGVsSW5wdXQuQ3VzdG9tZXJJZCAhPSB1bmRlZmluZWQgJiYgdGhpcy5UZW1wbW9kZWxJbnB1dC5DdXN0b21lcklkID49IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY3VzdElkID0gdGhpcy5UZW1wbW9kZWxJbnB1dC5DdXN0b21lcklkXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkICE9IHVuZGVmaW5lZCAmJiB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCA+PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGN1c3RJZCA9IHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChjdXN0SWQgIT0gLTEpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZG9jdW1lbnQubG9jYXRpb24gPSB0aGlzLkJhc2VBcHBVcmwgKyBcIlRlcm1pbmFscy9TaG93L1wiICsgY3VzdElkO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiAnUGxlYXNlIHNhdmUgbmV3IG9yIGxvYWQgcHJldmlvdXMgY3VzdG9tZXIgYW5kIHRoZW4gY2xpY2sgb24gY2hhcmdlIGNyZWRpdCBidXR0b24nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAvLyBhbGVydChyZXNwb25zZS5EYXRhLmxlbmd0aCArICcgVGVybWluYWwgU2NyZWVuIGhlbGxvJyk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9NU0dfQ0hBUkdFQ1JFRElULFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0aGlzLlNob3dNc2cgPSB0cnVlO1xyXG4gICAgICAgICAgICB0aGlzLk1zZyA9IHJlc3BvbnNlLkVyck1zZztcclxuICAgICAgICB9LFxyXG4gICAgICAgICAgICBlcnJvcj0+IGNvbnNvbGUubG9nKGVycm9yKSxcclxuICAgICAgICAgICAgKCkgPT4gY29uc29sZS5sb2coXCJTYXZlIENhbGwgQ29tcGxlYXRlZFwiKVxyXG4gICAgICAgICk7XHJcbiAgICAgICAgdGhpcy5Jc2J0bmRpc2FibGUgPSBcIlwiO1xyXG4gICAgfVxyXG4gICAgU3RvcFRpbWVyKCk6IG9ic2VydmFibGUge1xyXG4gICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICBtZXNzYWdlOiAnRnJvbSBTdG9wIFRpbWVyJyArIHRoaXMuU3RvcFRpbWVPdXQsIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgICAgICBjbGVhclRpbWVvdXQodGhpcy5TdG9wVGltZU91dCk7XHJcbiAgICB9XHJcbiAgICBTZXRkZWZhdWx0UGFnZSgpe1xyXG4gICAgICAgIGRvY3VtZW50LmxvY2F0aW9uID0gdGhpcy5CYXNlQXBwVXJsICsgXCJDdXN0b21lci9BZGQvLTFcIjtcclxuICAgICAgICB0aGlzLklzRmlsZUFzdHh0U2hvdyA9IHRydWU7XHJcbiAgICAgICAgdGhpcy5Jc0NhbmNlbCA9IHRydWU7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdmFyIGVtcGlkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJlbXBsb3llZWlkXCIpO1xyXG4gICAgICAgIHRoaXMuYXN5bmNTZWxlY3RlZENhciA9IFwiXCI7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0ID0ge307XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkJpcnRoRGF0ZSA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQgPSAtMTtcclxuICAgICAgICB0aGlzLkN1c3RJZFRleHQgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMuSGlkZVNob3dGaWxlQXN0eHQoKTtcclxuICAgICAgICB2YXIgY3VzdHR5cGUgPSB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZ2V0Q29va2llKGVtcGlkICsgXCJjdXN0XCIpO1xyXG4gICAgICAgIGlmIChjdXN0dHlwZS5sZW5ndGggPiAwKVxyXG4gICAgICAgICAgICBjdXN0dHlwZSA9IGN1c3R0eXBlLnN1YnN0cmluZygxLCBjdXN0dHlwZS5sZW5ndGgpO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclR5cGUgPSBjdXN0dHlwZTtcclxuICAgICAgICB2YXIgZW1wID0gdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmdldENvb2tpZShlbXBpZCArIFwiZW1wXCIpO1xyXG4gICAgICAgIGlmIChlbXAubGVuZ3RoID4gMClcclxuICAgICAgICAgICAgZW1wID0gZW1wLnN1YnN0cmluZygxLCBlbXAubGVuZ3RoKTtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuZW1wbG95ZWVpZCA9IGVtcDtcclxuICAgICAgICB2YXIgc291cmNlID0gdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmdldENvb2tpZShlbXBpZCArIFwic3JjXCIpO1xyXG4gICAgICAgIGlmIChzb3VyY2UubGVuZ3RoID4gMClcclxuICAgICAgICAgICAgc291cmNlID0gc291cmNlLnN1YnN0cmluZygxLCBzb3VyY2UubGVuZ3RoKTtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ2FtZUZyb21DdXN0b21lciA9IHNvdXJjZTtcclxuXHJcbiAgICAgICAgdGhpcy5TaG93TW9yZSA9IGZhbHNlO1xyXG4gICAgICAgIC8vdGhpcy5TaG93TW9yZVRleHQgPSBcIk1vcmVcIjsgXHJcbiAgICAgICAgdGhpcy5TaG93TW9yZVRleHQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0xOS19MQkxfTU9SRTtcclxuICAgICAgICB0aGlzLlNBVkVfQlROX1RFWFQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0JUTl9TQVZFO1xyXG4gICAgICAgIHRoaXMuQ1NTVEVYVCA9IFwibWRpLWNvbnRlbnQtYWRkXCI7XHJcbiAgICAgICAgdGhpcy5BRERfTkVXX0NVU1RfVEVYVCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfTEJMX05FV19DVVNUO1xyXG4gICAgICAgIHRoaXMuU2hvd0dyb3VwcyA9IHRydWU7XHJcbiAgICAgICAgdGhpcy5zaG93aGlkZUdyb3VwcygpO1xyXG4gICAgICAgIC8vdGhpcy5Hcm91cFRleHQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0xCTF9TSE9XR1JPVVBTO1xyXG5cclxuICAgICAgICBcclxuXHJcbiAgICAgICAgdmFyIHBoaWQgPSBcIlwiO1xyXG4gICAgICAgIHZhciBTTVMgPSAwO1xyXG4gICAgICAgIHZhciBwdWJsaXNoID0gMDtcclxuICAgICAgICB2YXIgZXB1Ymxpc2ggPSAwO1xyXG4gICAgICAgIGpRdWVyeS5lYWNoKHRoaXMuX1Bob25lVHlwZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuVGV4dCA9PSBcIkNlbGxQaG9uZVwiKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgcGhpZCA9IHRoaXMuVmFsdWU7XHJcbiAgICAgICAgICAgICAgICBTTVMgPSAxO1xyXG4gICAgICAgICAgICAgICAgcHVibGlzaCA9IDE7XHJcbiAgICAgICAgICAgICAgICBlcHVibGlzaCA9IDE7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzID0gW3sgUGhvbmVUeXBlSWQ6IHBoaWQsIFByZWZpeDogXCJcIiwgQXJlYTogXCJcIiwgUGhvbmU6IFwiXCIsIElzU21zOiBTTVMsIENvbW1lbnRzOiBcIlwiLCBwaHB1Ymxpc2g6IHB1Ymxpc2ggfV1cclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG5cclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMgPSBbeyBFbWFpbDogXCJcIiwgRW1haWxOYW1lOiBcIlwiLCBOZXdzbGV0dGVyZTogZmFsc2UsIHB1Ymxpc2g6IGVwdWJsaXNoIH1dXHJcbiAgICAgICAgdmFyIGNudHJ5Y29kZSA9IHRoaXMuX3Jlc291cmNlU2VydmljZS5nZXRDb29raWUoZW1waWQgKyBcImNjb2RlXCIpO1xyXG4gICAgICAgIGlmIChjbnRyeWNvZGUubGVuZ3RoID4gMClcclxuICAgICAgICAgICAgY250cnljb2RlID0gY250cnljb2RlLnN1YnN0cmluZygxLCBjbnRyeWNvZGUubGVuZ3RoKTtcclxuXHJcbiAgICAgICAgdmFyIGFkaWQgPSBcIlwiO1xyXG4gICAgICAgIGpRdWVyeS5lYWNoKHRoaXMuX0FkZHJlc3NUeXBlcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5UZXh0ID09IFwiSG9tZVwiKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgYWRpZCA9IHRoaXMuVmFsdWU7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgfSk7XHJcblxyXG5cclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMgPSBbeyBTdHJlZXQ6IFwiXCIsIFN0cmVldDI6IFwiXCIsIENpdHlOYW1lOiBcIlwiLCBaaXA6IFwiXCIsIENvdW50cnlDb2RlOiBjbnRyeWNvZGUsIFN0YXRlSWQ6IFwiXCIsIEFkZHJlc3NUeXBlSWQ6IGFkaWQsIEZvckRlbGl2ZXJ5OiBmYWxzZSwgTWFpbkFkZHJlc3M6IGZhbHNlIH1dXHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyR3JvdXBzID0gW107XHJcbiAgICAgICAgdGhpcy5BZGRyZXNzLkNvdW50cnlDb2RlID0gXCJcIjtcclxuICAgICAgICB0aGlzLkFkZHJlc3MuU3RhdGVJZCA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LlNhZml4aWQgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5HZW5kZXIgPSBcIjBcIjtcclxuICAgICAgICB0aGlzLlNob3dNc2cgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLk1zZyA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5Jc1Nob3dBbGwgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLl9jdXN0b21lclNlcnZpY2UuR2V0R2VuZXJhbEdyb3Vwcyh0aGlzLklzU2hvd0FsbCkuc3Vic2NyaWJlKFxyXG4gICAgICAgICAgICAoZGF0YSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5Jc1Nob3dBbGwgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkoXCIjZ3JvdXBUcmVlXCIpLmh0bWwoXCJMb2RpbmcuLi5cIik7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIHJlcyA9IGpRdWVyeS5wYXJzZUpTT04oZGF0YSkuRGF0YVxyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeShcIiNncm91cFRyZWVcIikua2VuZG9UcmVlVmlldyh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRPbkRlbWFuZDogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tib3hlczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tDaGlsZHJlbjogdHJ1ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2NoZWNrOiB0aGlzLm9uR3JvdXBTZWxlY3QsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhdGFTb3VyY2U6IHJlc1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5KFwiI2dyb3VwVHJlZTFcIikuaHRtbChcIkxvZGluZy4uLlwiKTtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgcmVzID0galF1ZXJ5LnBhcnNlSlNPTihkYXRhKS5EYXRhXHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5KFwiI2dyb3VwVHJlZTFcIikua2VuZG9UcmVlVmlldyh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRPbkRlbWFuZDogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tib3hlczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tDaGlsZHJlbjogdHJ1ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2NoZWNrOiB0aGlzLm9uR3JvdXBTZWxlY3QsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhdGFTb3VyY2U6IHJlc1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAoZXJyKSA9PiB7XHJcblxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAoKSA9PiB7XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgKTtcclxuICAgIH1cclxuICAgIENhbmNlbEZpbGVBc3R4dCgpIHtcclxuICAgICAgICB0aGlzLklzRmlsZUFzdHh0U2hvdyA9IHRydWU7XHJcbiAgICAgICAgdGhpcy5Jc0ZpbGVBc3R4dFNob3cgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLklzQ2FuY2VsID0gdHJ1ZTtcclxuICAgICAgICBqUXVlcnkoXCIjRmlsZUFzdHh0XCIpLmhpZGUoKTtcclxuICAgICAgICBqUXVlcnkoXCIjRmlsZUFzU3BuXCIpLnNob3coKTtcclxuICAgICAgICB0aGlzLkZJTEVBU19CVE5fVEVYVCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfQlROX0ZJTEVBUztcclxuICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkICE9IG51bGwgJiYgcGFyc2VJbnQoIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkKSA+LTEpIHtcclxuICAgICAgICAgICAgalF1ZXJ5KFwiI0ZpbGVBc1NhdmVCdG5cIikuc2hvdygpO1xyXG4gICAgICAgICAgICB0aGlzLmNzc0ZpbGVBc0J0biA9IFwibWRpLWNvbnRlbnQtY3JlYXRlXCI7XHJcbiAgICAgICAgICAgIGpRdWVyeShcIiNGaWxlQXNDYW5jZWxCdG5cIikuaGlkZSgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgalF1ZXJ5KFwiI0ZpbGVBc1NhdmVCdG5cIikuaGlkZSgpO1xyXG4gICAgICAgICAgICBqUXVlcnkoXCIjRmlsZUFzQ2FuY2VsQnRuXCIpLmhpZGUoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBcclxuICAgIEhpZGVTaG93RmlsZUFzdHh0KCk6IG9ic2VydmFibGUge1xyXG4gICAgICAgXHJcbiAgICAgICAgaWYgKHRoaXMuSXNGaWxlQXN0eHRTaG93ID09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuSXNGaWxlQXN0eHRTaG93ID0gdHJ1ZTtcclxuICAgICAgICAgICAgalF1ZXJ5KFwiI0ZpbGVBc3R4dFwiKS5zaG93KCk7XHJcbiAgICAgICAgICAgIGpRdWVyeShcIiNGaWxlQXNTcG5cIikuaGlkZSgpO1xyXG4gICAgICAgICAgICB0aGlzLklzQ2FuY2VsID0gZmFsc2U7XHJcbiAgICAgICAgICAgIHRoaXMuRklMRUFTX0JUTl9URVhUID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9CVE5fU0FWRUZJTEVBUztcclxuICAgICAgICAgICAvLyBhbGVydCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCk7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQgIT0gbnVsbCAmJiBwYXJzZUludCggdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQpID4tMSkge1xyXG4gICAgICAgICAgICAgICAgalF1ZXJ5KFwiI0ZpbGVBc1NhdmVCdG5cIikuc2hvdygpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jc3NGaWxlQXNCdG4gPSBcIm1kaS1jb250ZW50LXNhdmVcIjtcclxuICAgICAgICAgICAgICAgIGpRdWVyeShcIiNGaWxlQXNDYW5jZWxCdG5cIikuc2hvdygpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgalF1ZXJ5KFwiI0ZpbGVBc1NhdmVCdG5cIikuaGlkZSgpO1xyXG4gICAgICAgICAgICAgICAgalF1ZXJ5KFwiI0ZpbGVBc0NhbmNlbEJ0blwiKS5oaWRlKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuSXNGaWxlQXN0eHRTaG93ID0gZmFsc2U7XHJcbiAgICAgICAgICAgIGpRdWVyeShcIiNGaWxlQXN0eHRcIikuaGlkZSgpO1xyXG4gICAgICAgICAgICBqUXVlcnkoXCIjRmlsZUFzU3BuXCIpLnNob3coKTtcclxuICAgICAgICAgICAgdGhpcy5GSUxFQVNfQlROX1RFWFQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0JUTl9GSUxFQVM7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkICE9IG51bGwgJiYgcGFyc2VJbnQodGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQpPi0xKSB7XHJcbiAgICAgICAgICAgICAgICBqUXVlcnkoXCIjRmlsZUFzU2F2ZUJ0blwiKS5zaG93KCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNzc0ZpbGVBc0J0biA9IFwibWRpLWNvbnRlbnQtY3JlYXRlXCI7XHJcbiAgICAgICAgICAgICAgICBqUXVlcnkoXCIjRmlsZUFzQ2FuY2VsQnRuXCIpLmhpZGUoKTtcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5GaWxlQXMgIT0gXCJcIiAmJiB0aGlzLm1vZGVsSW5wdXQuRmlsZUFzICE9IHVuZGVmaW5lZCAmJiB0aGlzLm1vZGVsSW5wdXQuRmlsZUFzICE9IG51bGwgJiYgdGhpcy5Jc0NhbmNlbCA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5TYXZlRmlsZUFzKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkLCB0aGlzLm1vZGVsSW5wdXQuRmlsZUFzKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vYWxlcnQoJ2hlbGxvJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vYWxlcnQocmVzcG9uc2UuRXJyTXNnKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZywgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLy90aGlzLklzRmlsZUFzU2F2ZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZywgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5Jc0NhbmNlbCA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2Vsc2Uge1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgLy99XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9FTVBUWUZJTEVBUywgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYmluZEZpbGVBcygpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuSXNGaWxlQXN0eHRTaG93ID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5IaWRlU2hvd0ZpbGVBc3R4dCgpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgalF1ZXJ5KFwiI0ZpbGVBc1NhdmVCdG5cIikuaGlkZSgpO1xyXG4gICAgICAgICAgICAgICAgalF1ZXJ5KFwiI0ZpbGVBc0NhbmNlbEJ0blwiKS5oaWRlKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICB9XHJcbiAgICBTZXRFbWFpbE5hbWUoKTogb2JzZXJ2YWJsZSB7XHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5GaWxlQXMgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dC5GaWxlQXMgIT0gbnVsbCkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlsc1t0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMubGVuZ3RoIC0gMV0uRW1haWxOYW1lID0gdGhpcy5tb2RlbElucHV0LkZpbGVBcztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIENoZWNrQ3VzdFdpdGhTYW1lTmFtZSgpOiBvYnNlcnZhYmxlIHtcclxuXHJcbiAgICB9XHJcbiAgICBTZXREZWZhdWx0Q3VzdCgpIHtcclxuICAgICAgICAvL2FsZXJ0KCk7XHJcbiAgICAgICAgLy9kZWJ1Z2dlcjtcclxuXHJcbiAgICB9XHJcblxyXG4gICAgc2V0ZGVmYXVsdEFkZHJlc3MoKSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5iaW5kRmlsZUFzKCk7XHJcbiAgICAgICAgdGhpcy5DaGVja0N1c3RXaXRoZm5hbWVsbmFtZWNvbXBwaHNlbWFpbHMoKTtcclxuICAgICAgICB2YXIgYWRpZCA9IFwiXCI7XHJcbiAgICAgICAgdmFyIGFkdGV4dCA9IFwiSG9tZVwiO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkNvbXBhbnkgIT0gXCJcIiAmJiB0aGlzLm1vZGVsSW5wdXQuQ29tcGFueSAhPSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgYWR0ZXh0ID0gXCJXb3JrXCI7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgIH1cclxuICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLl9BZGRyZXNzVHlwZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuVGV4dCA9PSBhZHRleHQpIHtcclxuICAgICAgICAgICAgICAgIGFkaWQgPSB0aGlzLlZhbHVlO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3Nlc1t0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMubGVuZ3RoIC0gMV0uQWRkcmVzc1R5cGVJZCA9IGFkaWQ7XHJcbiAgICB9XHJcbiAgICBiaW5kRmlsZUFzKCk6IG9ic2VydmFibGUge1xyXG4gICAgICAgIFxyXG4gICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuRmlsZUFzID09IFwiXCIgfHwgdGhpcy5tb2RlbElucHV0LkZpbGVBcyA9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgaWYgKCh0aGlzLm1vZGVsSW5wdXQuQ29tcGFueSA9PSBcIlwiIHx8IHRoaXMubW9kZWxJbnB1dC5Db21wYW55ID09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgdmFyIGZpbGVhc3RleHQgPSBcIlwiO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5mbmFtZSAhPSBcIlwiICYmIHRoaXMubW9kZWxJbnB1dC5mbmFtZSAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0LmxuYW1lICE9IFwiXCIgJiYgdGhpcy5tb2RlbElucHV0LmxuYW1lICE9IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGZpbGVhc3RleHQgPSB0aGlzLm1vZGVsSW5wdXQubG5hbWUgKyBcIiBcIiArIHRoaXMubW9kZWxJbnB1dC5mbmFtZTtcclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKHRoaXMubW9kZWxJbnB1dC5mbmFtZSAhPSBcIlwiICYmIHRoaXMubW9kZWxJbnB1dC5mbmFtZSAhPSB1bmRlZmluZWQgJiYgKHRoaXMubW9kZWxJbnB1dC5sbmFtZSA9PSBcIlwiIHx8IHRoaXMubW9kZWxJbnB1dC5sbmFtZSA9PSB1bmRlZmluZWQpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZmlsZWFzdGV4dCA9IFwiIFwiICsgdGhpcy5tb2RlbElucHV0LmZuYW1lO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSBpZiAoKHRoaXMubW9kZWxJbnB1dC5mbmFtZSA9PSBcIlwiIHx8IHRoaXMubW9kZWxJbnB1dC5mbmFtZSA9PSB1bmRlZmluZWQpICYmICh0aGlzLm1vZGVsSW5wdXQubG5hbWUgIT0gXCJcIiAmJiB0aGlzLm1vZGVsSW5wdXQubG5hbWUgIT0gdW5kZWZpbmVkKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGZpbGVhc3RleHQgPSB0aGlzLm1vZGVsSW5wdXQubG5hbWUgKyBcIiBcIjtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5GaWxlQXMgPSBmaWxlYXN0ZXh0O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2UgaWYgKCh0aGlzLm1vZGVsSW5wdXQubG5hbWUgPT0gXCJcIiB8fCB0aGlzLm1vZGVsSW5wdXQubG5hbWUgPT0gdW5kZWZpbmVkKSAmJiAodGhpcy5tb2RlbElucHV0LmZuYW1lID09IFwiXCIgfHwgdGhpcy5tb2RlbElucHV0LmxuYW1lID09IHVuZGVmaW5lZCkpIHtcclxuICAgICAgICAgICAgICAgIHZhciBmaWxlYXN0ZXh0ID0gXCJcIjtcclxuICAgICAgICAgICAgICAgIGlmICgodGhpcy5tb2RlbElucHV0LkNvbXBhbnkgIT0gXCJcIiAmJiB0aGlzLm1vZGVsSW5wdXQuQ29tcGFueSAhPSB1bmRlZmluZWQpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZmlsZWFzdGV4dCA9IHRoaXMubW9kZWxJbnB1dC5Db21wYW55O1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkZpbGVBcyA9IGZpbGVhc3RleHQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZVxyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkZpbGVBcyA9IFwiKFwiICsgdGhpcy5tb2RlbElucHV0LkNvbXBhbnkgKyBcIikgXCIgKyB0aGlzLm1vZGVsSW5wdXQubG5hbWUgKyBcIiBcIiArIHRoaXMubW9kZWxJbnB1dC5mbmFtZTsgLy8rIFwiIFwiICYgbV9zdHJTcG91c2VcclxuICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlscy5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHNbdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzLmxlbmd0aCAtIDFdLkVtYWlsTmFtZSA9IHRoaXMubW9kZWxJbnB1dC5GaWxlQXM7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5TZXRFbWFpbE5hbWUoKTtcclxuICAgIH1cclxuICAgIGJpbmRHcm91cCgpOiB2b2lkIHtcclxuICAgICAgICAvL2FsZXJ0KHRoaXMuSXNTaG93QWxsKTsgdGhpcyBmdW5jdGlvbiBpcyBjYWxsaW5nIG9uIGNsaWNrIG9mIGNoZWNrYm94XHJcbiAgICAgICAgdmFyIGlzc2hvdyA9IGZhbHNlO1xyXG4gICAgICAgIGlmICh0aGlzLklzU2hvd0FsbCA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgIGlzc2hvdyA9IGZhbHNlXHJcbiAgICAgICAgICAgIHRoaXMuSXNTaG93QWxsID0gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLklzU2hvd0FsbCA9IHRydWU7XHJcbiAgICAgICAgICAgIGlzc2hvdyA9IHRydWU7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLmJpbmRHcm91cFRyZWUoaXNzaG93KTtcclxuICAgIH1cclxuICAgIHNhdmVDdXN0b21lckRhdGEoKTogdm9pZCB7XHJcbiAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICB0aGlzLklzYnRuZGlzYWJsZSA9IFwiZGlzYWJsZWRcIjtcclxuICAgICAgICB0aGlzLlNob3dMb2FkZXIgPSB0cnVlO1xyXG4gICAgICAgIHRoaXMuZ2V0U2VsZWN0ZWRHcm91cHMoKTtcclxuICAgICAgIFxyXG4gICAgICAgIHZhciBjb3VudCA9IDA7XHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3NlcyAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzICE9IG51bGwpIHtcclxuICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5NYWluQWRkcmVzcyA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY291bnQgPSBjb3VudCArIDE7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBpZiAoY291bnQgPiAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9ib290Ym94LmFsZXJ0KFwiTWFpbiBBZGRyZXNzIHNob2x1ZCBiZSBvbmx5IG9uZVwiKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5Jc2J0bmRpc2FibGUgPSBcIlwiO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuU2hvd0xvYWRlciA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vYWxlcnQodGhpcy5tb2RlbElucHV0LkJpcnRoRGF0ZSk7XHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5CaXJ0aERhdGUgIT0gXCJcIikge1xyXG4gICAgICAgICAgICBpZiAobW9tZW50KHRoaXMubW9kZWxJbnB1dC5CaXJ0aERhdGUsIFwiREQtTU0tWVlZWVwiLCB0cnVlKS5pc1ZhbGlkKCkgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoeyBtZXNzYWdlOiBcIkJpcnRoZGF0ZSBpcyBub3QgdmFsaWRcIiB9KTtcclxuXHJcbiAgICAgICAgICAgICAgICB0aGlzLklzYnRuZGlzYWJsZSA9IFwiXCI7XHJcbiAgICAgICAgICAgICAgICB0aGlzLlNob3dMb2FkZXIgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoY291bnQgPD0gMSB8fCB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMgPT0gdW5kZWZpbmVkIHx8IHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3NlcyA9PSBudWxsKSB7XHJcblxyXG4gICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzICE9IHVuZGVmaW5lZCAmJiB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXMgIT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgdmFyIHBodGVtcCA9IFtdO1xyXG4gICAgICAgICAgICAgICAgalF1ZXJ5KCdpbnB1dFtuYW1lXj1cInBoXCJdJykuZWFjaChmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcGh0ZW1wLnB1c2goalF1ZXJ5KHRoaXMpLnZhbCgpKTtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgdmFyIGFydGVtcCA9IFtdO1xyXG4gICAgICAgICAgICAgICAgalF1ZXJ5KCdpbnB1dFtuYW1lXj1cImFyXCJdJykuZWFjaChmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYXJ0ZW1wLnB1c2goalF1ZXJ5KHRoaXMpLnZhbCgpKTtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgdmFyIHByZXRlbXAgPSBbXTtcclxuICAgICAgICAgICAgICAgIGpRdWVyeSgnaW5wdXRbbmFtZV49XCJwcmVcIl0nKS5lYWNoKGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgICAgICBwcmV0ZW1wLnB1c2goalF1ZXJ5KHRoaXMpLnZhbCgpKTtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgdmFyIGkgPSAwO1xyXG4gICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuSXNTbXMgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLklzU21zID0gXCIxXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLklzU21zID0gXCIwXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLnBocHVibGlzaCA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucGhwdWJsaXNoID0gXCIxXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnBocHVibGlzaCA9IFwiMFwiO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB0aGlzLlBob25lID0gcGh0ZW1wW2ldO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuQXJlYSA9IGFydGVtcFtpXTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLlByZWZpeCA9IHByZXRlbXBbaV07XHJcbiAgICAgICAgICAgICAgICAgICAgaSsrO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vdmFyIHRlbXAgPSB0aGlzLlBob25lVHlwZUlkLnNwbGl0KCc7Jyk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy90aGlzLlBob25lVHlwZUlkID0gcGFyc2VJbnQodGVtcFsxXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy90aGlzLlBob25lVHlwZSA9IHRlbXBbMF07XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlscyAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzICE9IG51bGwpIHtcclxuICAgICAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlscywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLnB1Ymxpc2ggPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnB1Ymxpc2ggPSBcIjFcIjtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucHVibGlzaCA9IFwiMFwiO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBpKys7XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB2YXIgamRhdGEgPSBKU09OLnN0cmluZ2lmeSh0aGlzLm1vZGVsSW5wdXQpO1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhqZGF0YSlcclxuICAgICAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkFkZEN1c3RvbWVyKGpkYXRhKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhyZXNwb25zZSk7XHJcbiAgICAgICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5Jc2J0bmRpc2FibGUgPSBcIlwiO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5TaG93TG9hZGVyID0gZmFsc2U7XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIC8vYWxlcnQocmVzcG9uc2UuRXJyTXNnKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLk1zZ0NsYXNzID0gXCJ0ZXh0LWRhbmdlclwiO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9hbGVydChyZXNwb25zZS5FcnJNc2cpO1xyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuTXNnQ2xhc3MgPSBcInRleHQtc3VjY2Vzc1wiO1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBlbXBpZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiZW1wbG95ZWVpZFwiKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2Uuc2V0Q29va2llKGVtcGlkICsgXCJjdXN0XCIsIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclR5cGUsIDEwKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2Uuc2V0Q29va2llKGVtcGlkICsgXCJlbXBcIiwgdGhpcy5tb2RlbElucHV0LmVtcGxveWVlaWQsIDEwKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2Uuc2V0Q29va2llKGVtcGlkICsgXCJzcmNcIiwgdGhpcy5tb2RlbElucHV0LkNhbWVGcm9tQ3VzdG9tZXIsIDEwKTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzLmxlbmd0aD4wKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2Uuc2V0Q29va2llKGVtcGlkICsgXCJjY29kZVwiLCB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXNbdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzLmxlbmd0aCAtIDFdLkNvdW50cnlDb2RlLCAxMCk7XHJcbiAgICAgICAgICAgICAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgICAgICAvL2RvY3VtZW50LmxvY2F0aW9uID0gdGhpcy5CYXNlQXBwVXJsICsgXCJDdXN0b21lci9BZGQvLTFcIjtcclxuICAgICAgICAgICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuVGVtcG1vZGVsSW5wdXQgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dCA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5lZGl0Q3VzdERldCh0aGlzLm1vZGVsSW5wdXQpO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vdGhpcy5TZXRkZWZhdWx0UGFnZSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIFJlc2V0IGZvcm0gdmFsdWVzXHJcbiAgICAgICAgICAgICAgICAgICAgLy90aGlzLl9DdXN0VHlwZXMgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgdGhpcy5TaG93TXNnID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIHRoaXMuTXNnID0gcmVzcG9uc2UuRXJyTXNnO1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgZXJyb3I9PiBjb25zb2xlLmxvZyhlcnJvciksXHJcbiAgICAgICAgICAgICAgICAoKSA9PiBjb25zb2xlLmxvZyhcIlNhdmUgQ2FsbCBDb21wbGVhdGVkXCIpXHJcbiAgICAgICAgICAgICk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfTVNHX0lTTUFJTkFERCwgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgdGhpcy5Jc2J0bmRpc2FibGUgPSBcIlwiO1xyXG4gICAgICAgICAgICB0aGlzLlNob3dMb2FkZXIgPSBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgQ2hlY2tDdXN0V2l0aGZuYW1lbG5hbWVjb21wcGhzZW1haWxzKCk6IG9ic2VydmFibGUge1xyXG4gICAgICAgIHZhciBqZGF0YSA9IEpTT04uc3RyaW5naWZ5KHRoaXMubW9kZWxJbnB1dCk7XHJcbiAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICB2YXIgZm5hbWUgPSBcIlwiO1xyXG4gICAgICAgIHZhciBsbmFtZSA9IFwiXCI7XHJcbiAgICAgICAgdmFyIGNvbXBhbnkgPSBcIlwiO1xyXG4gICAgICAgIHZhciBwaG9uZXMgPSBcIlwiO1xyXG4gICAgICAgIHZhciBlbWFpbHMgPSBcIlwiO1xyXG4gICAgICAgIFxyXG4gICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuZm5hbWUgPT0gdW5kZWZpbmVkKVxyXG4gICAgICAgICAgICBmbmFtZSA9IFwiXCI7XHJcbiAgICAgICAgZWxzZVxyXG4gICAgICAgICAgICBmbmFtZSA9IHRoaXMubW9kZWxJbnB1dC5mbmFtZTtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5sbmFtZSA9PSB1bmRlZmluZWQpXHJcbiAgICAgICAgICAgIGxuYW1lID0gXCJcIjtcclxuICAgICAgICBlbHNlXHJcbiAgICAgICAgICAgIGxuYW1lID0gdGhpcy5tb2RlbElucHV0LmxuYW1lO1xyXG4gICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ29tcGFueSA9PSB1bmRlZmluZWQpXHJcbiAgICAgICAgICAgIGNvbXBhbnkgPSBcIlwiO1xyXG4gICAgICAgIGVsc2VcclxuICAgICAgICAgICAgY29tcGFueSA9IHRoaXMubW9kZWxJbnB1dC5Db21wYW55O1xyXG4gICAgICAgIFxyXG4gICAgICAgIGpRdWVyeSgnaW5wdXRbbmFtZV49XCJwaFwiXScpLmVhY2goZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgaWYgKGpRdWVyeSh0aGlzKS52YWwoKSAhPSBcIlwiICYmIGpRdWVyeSh0aGlzKS52YWwoKSAhPSB1bmRlZmluZWQgJiYgalF1ZXJ5KHRoaXMpLnZhbCgpICE9IG51bGwgJiYgalF1ZXJ5KHRoaXMpLnZhbCgpLmxlbmd0aD49Mykge1xyXG4gICAgICAgICAgICAgICAgcGhvbmVzICs9IGpRdWVyeSh0aGlzKS52YWwoKSArIFwiJywnXCI7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgICAgICBpZiAocGhvbmVzLmxlbmd0aCA+IDApIHBob25lcyA9IHBob25lcy5zdWJzdHJpbmcoMCwgcGhvbmVzLmxlbmd0aCAtIDMpO1xyXG4gICAgICAgIGpRdWVyeS5lYWNoKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlscywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5FbWFpbCAhPSBcIlwiICYmIHRoaXMuRW1haWwgIT0gdW5kZWZpbmVkICYmIHRoaXMuRW1haWwgIT0gbnVsbCAmJiB0aGlzLkVtYWlsLmxlbmd0aD49Mykge1xyXG4gICAgICAgICAgICAgICAgZW1haWxzICs9IHRoaXMuRW1haWwrXCInLCdcIjtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICB9KTtcclxuICAgICAgICBpZiAoZW1haWxzLmxlbmd0aCA+IDApIGVtYWlscyA9IGVtYWlscy5zdWJzdHJpbmcoMCwgZW1haWxzLmxlbmd0aCAtIDMpO1xyXG4gICAgICAgIGlmICgoZm5hbWUgIT0gXCJcIiAmJiBmbmFtZS5sZW5ndGggPj0gMiAmJiBsbmFtZSAhPSBcIlwiICYmIGxuYW1lLmxlbmd0aCA+PSAyKVxyXG4gICAgICAgICAgICB8fCAoY29tcGFueSAhPSBcIlwiICYmIGNvbXBhbnkubGVuZ3RoID49IDMpXHJcbiAgICAgICAgICAgIHx8IChwaG9uZXMgIT0gXCJcIilcclxuICAgICAgICAgICAgfHwgKGVtYWlscyAhPSBcIlwiKSkge1xyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkdldEN1c3RvbWVyc1NlYXJjaERhdGEoZm5hbWUsIGxuYW1lLCBjb21wYW55LCBwaG9uZXMsIGVtYWlscykuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZywgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5DdXN0TGlzdCA9IHt9O1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuQ3VzdExpc3QgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5EYXRhICE9IG51bGwgJiYgcmVzcG9uc2UuRGF0YSAhPSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jdXN0U2VhcmNoRGF0YSA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGpRdWVyeSgnI0N1c3RNb2RhbCcpLm9wZW5Nb2RhbCgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8valF1ZXJ5KCcjQ3VzdE1vZGFsJykubW9kYWwoJ29wZW4nKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9qUXVlcnkoXCIjQ3VzdE1vZGFsXCIpLnNob3coMTAwMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8vYWxlcnQodGhpcy5SRVMpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgICAvL3RoaXMuYmluZEZpbGVBcygpO1xyXG4gICAgfVxyXG5cclxuXHJcblxyXG4gICAgQ2hlY2tDdXN0V2l0aGZuYW1lbG5hbWUoZm5hbWUsIGxuYW1lLGNvbXBhbnkpOiBvYnNlcnZhYmxlIHtcclxuICAgICAgICB2YXIgamRhdGEgPSBKU09OLnN0cmluZ2lmeSh0aGlzLm1vZGVsSW5wdXQpO1xyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5mbmFtZSA9PSB1bmRlZmluZWQpXHJcbiAgICAgICAgICAgIGZuYW1lID0gXCJcIjtcclxuICAgICAgICBlbHNlXHJcbiAgICAgICAgICAgIGZuYW1lID0gdGhpcy5tb2RlbElucHV0LmZuYW1lO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LmxuYW1lID09IHVuZGVmaW5lZClcclxuICAgICAgICAgICAgbG5hbWUgPSBcIlwiO1xyXG4gICAgICAgIGVsc2VcclxuICAgICAgICAgICAgbG5hbWUgPSB0aGlzLm1vZGVsSW5wdXQubG5hbWU7XHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5Db21wYW55ID09IHVuZGVmaW5lZClcclxuICAgICAgICAgICAgY29tcGFueSA9IFwiXCI7XHJcbiAgICAgICAgZWxzZVxyXG4gICAgICAgICAgICBjb21wYW55ID0gdGhpcy5tb2RlbElucHV0LkNvbXBhbnk7XHJcbiAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkNoZWNrQ3VzdFdpdGhTYW1lTmFtZShmbmFtZSwgbG5hbWUsIGNvbXBhbnkpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuQ3VzdExpc3QgPSB7fTtcclxuICAgICAgICAgICAgICAgIHRoaXMuQ3VzdExpc3QgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLkRhdGEgIT0gbnVsbCAmJiByZXNwb25zZS5EYXRhICE9IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY3VzdFNlYXJjaERhdGEgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeShcIiNDdXN0TW9kYWxcIikub3Blbk1vZGFsKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9qUXVlcnkoXCIjQ3VzdE1vZGFsXCIpLnNob3coMTAwMCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvL2FsZXJ0KHRoaXMuUkVTKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuICAgICAgICAvL3RoaXMuYmluZEZpbGVBcygpO1xyXG4gICAgfVxyXG5cclxuXHJcblxyXG5cclxuICAgIENoZWNrQ3VzdFdpdGhFbWFpbCgpOiBvYnNlcnZhYmxlIHtcclxuICAgICAgICBcclxuICAgICAgICAvL3ZhciBFbWFpbCA9IFwiXCI7XHJcbiAgICAgICAgLy9pZiAodGhpcy5FbWFpbE1vZGVsLkVtYWlsICE9IFwiXCIgJiYgdGhpcy5FbWFpbE1vZGVsLkVtYWlsICE9IHVuZGVmaW5lZClcclxuICAgICAgICAvLyAgICBFbWFpbCA9IHRoaXMuRW1haWxNb2RlbC5FbWFpbDtcclxuICAgICAgICAvL3RoaXMuX2N1c3RvbWVyU2VydmljZS5DaGVja0N1c3RXaXRoU2FtZUVtYWlsKEVtYWlsKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgLy8gICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAvLyAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgIC8vICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAvLyAgICAgICAgYWxlcnQocmVzcG9uc2UuRXJyTXNnKTtcclxuICAgICAgICAvLyAgICB9XHJcbiAgICAgICAgLy8gICAgZWxzZSB7XHJcbiAgICAgICAgLy8gICAgICAgIHRoaXMuQ3VzdExpc3QgPSB7fTtcclxuICAgICAgICAvLyAgICAgICAgdGhpcy5DdXN0TGlzdCA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgLy8gICAgICAgIGlmIChyZXNwb25zZS5EYXRhICE9IG51bGwgJiYgcmVzcG9uc2UuRGF0YSAhPSB1bmRlZmluZWQpIHtcclxuICAgICAgICAvLyAgICAgICAgICAgIHRoaXMuY3VzdFNlYXJjaERhdGEgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgIC8vICAgICAgICAgICAgalF1ZXJ5KFwiI0N1c3RNb2RhbFwiKS5tb2RhbChcInNob3dcIik7XHJcbiAgICAgICAgLy8gICAgICAgIH1cclxuICAgICAgICAvLyAgICAgICAgLy9hbGVydCh0aGlzLlJFUyk7XHJcbiAgICAgICAgLy8gICAgfVxyXG4gICAgICAgIC8vfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgLy8gICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIC8vfSwgKCkgPT4ge1xyXG4gICAgICAgIC8vICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIC8vfSk7XHJcbiAgICB9XHJcbiAgICBDaGVja0N1c3RXaXRoUGhvbmUoKTogb2JzZXJ2YWJsZSB7XHJcbiAgICAgICAgdmFyIFBob25lID0gXCJcIjtcclxuICAgICAgICBpZiAodGhpcy5QaG9uZU1vZGVsLlBob25lICE9IFwiXCIgJiYgdGhpcy5QaG9uZU1vZGVsLlBob25lICE9IHVuZGVmaW5lZClcclxuICAgICAgICAgICAgUGhvbmUgPSB0aGlzLlBob25lTW9kZWwuUGhvbmU7XHJcbiAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkNoZWNrQ3VzdFdpdGhTYW1lUGhvbmUodGhpcy5QaG9uZU1vZGVsLlBob25lKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZywgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLkN1c3RMaXN0ID0ge307XHJcbiAgICAgICAgICAgICAgICB0aGlzLkN1c3RMaXN0ID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5EYXRhICE9IG51bGwgJiYgcmVzcG9uc2UuRGF0YSAhPSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmN1c3RTZWFyY2hEYXRhID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkoXCIjQ3VzdE1vZGFsXCIpLm9wZW5Nb2RhbCgpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLy9hbGVydCh0aGlzLlJFUyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcbiAgICBTaG93UmVtYXJrcyhQaE9iaik6IE9ic2VydmFibGUge1xyXG4gICAgICAgIGpRdWVyeS5lYWNoKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICBpZiAodGhpcyA9PSBQaE9iaikge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5Jc1Nob3dSZW1hcmtzID0gdHJ1ZTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICB9KTtcclxuICAgIH1cclxuICAgIHNob3dBZGRQb3B1cCgpOiBvYnNlcnZhYmxlIHtcclxuICAgICAgICB0aGlzLkFkZHJlc3MgPSB7fTtcclxuICAgICAgICB0aGlzLlBob25lTW9kZWwgPSB7fTtcclxuICAgICAgICB0aGlzLlBob25lTW9kZWwuUGhvbmVUeXBlSWQgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMuQWRkcmVzcy5Db3VudHJ5Q29kZSA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5BZGRyZXNzLlN0YXRlSWQgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMuQWRkcmVzcy5DaXR5TmFtZSA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5BZGRyZXNzLkFkZHJlc3NUeXBlSWQgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMuRW1haWxNb2RlbCA9IHt9O1xyXG4gICAgICAgIHRoaXMuQlROX1BIQUREID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9CVE5fUEhBRERcclxuICAgICAgICBcclxuXHJcbiAgICB9XHJcbiAgICBzaG93aGlkZUdyb3VwcygpOiBvYnNlcnZhYmxlIHtcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgIGlmICh0aGlzLlNob3dHcm91cHMgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgdGhpcy5TaG93R3JvdXBzID0gdHJ1ZTtcclxuICAgICAgICAgICAgdGhpcy5Hcm91cFRleHQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0xCTF9ISURFR1JPVVA7XHJcbiAgICAgICAgICAgIGpRdWVyeShcIiNHcnBEaXZcIikuc2hvdygxMDAwKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuU2hvd0dyb3VwcyA9IGZhbHNlO1xyXG4gICAgICAgICAgICB0aGlzLkdyb3VwVGV4dCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfTEJMX1NIT1dHUk9VUFM7XHJcbiAgICAgICAgICAgIGpRdWVyeShcIiNHcnBEaXZcIikuaGlkZSgxMDAwKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgfVxyXG5cclxuXHJcbiAgICBDYW5hZGRBZGRyZXNzKGFkb2JqKTogYm9vbGVhbiB7XHJcbiAgICAgICAgLy9hbGVydCgnSGVsbG8nKTtcclxuICAgICAgICByZXR1cm4gKGFkb2JqLlN0cmVldCAhPSB1bmRlZmluZWQgJiYgYWRvYmouU3RyZWV0ICE9IFwiXCIpXHJcbiAgICAgICAgICAgICYmIChhZG9iai5TdHJlZXQyICE9IHVuZGVmaW5lZCAmJiBhZG9iai5TdHJlZXQyICE9IFwiXCIpXHJcbiAgICAgICAgICAgIC8vJiYgKGFkb2JqLkNpdHlOYW1lICE9IHVuZGVmaW5lZCAmJiBhZG9iai5DaXR5TmFtZSAhPSBcIlwiKVxyXG4gICAgICAgICAgICAmJiAoYWRvYmouWmlwICE9IHVuZGVmaW5lZCAmJiBhZG9iai5aaXAgIT0gXCJcIikgXHJcbiAgICAgICAgICAgICYmIChhZG9iai5Db3VudHJ5Q29kZSAhPSB1bmRlZmluZWQgJiYgYWRvYmouQ291bnRyeUNvZGUgIT0gXCJcIiApXHJcbiAgICAgICAgICAgIC8vJiYgKHRoaXMuQWRkcmVzcy5TdGF0ZUlkICE9IHVuZGVmaW5lZCAmJiB0aGlzLkFkZHJlc3MuU3RhdGVJZCAhPSBcIlwiKVxyXG4gICAgICAgICAgICAmJiAoYWRvYmouQWRkcmVzc1R5cGVJZCAhPSB1bmRlZmluZWQgJiYgYWRvYmouQWRkcmVzc1R5cGVJZCAhPSBcIlwiKTtcclxuICAgIH1cclxuICAgIEFkZEFkZHJlc3NlcyhhZG9iaik6IG9ic2VydmFibGUge1xyXG4gICAgICAgIFxyXG4gICAgICAgIHZhciBJc01haW5BZGQgPSBmYWxzZTtcclxuICAgICAgICBhZG9iai5DaXR5TmFtZSA9IGpRdWVyeShcIiNDaXR5XCIpLnZhbCgpO1xyXG4gICAgICAgIFxyXG4gICAgICAgIGlmICh0aGlzLkNhbmFkZEFkZHJlc3MoYWRvYmopKSB7XHJcblxyXG4gICAgICAgICAgICB2YXIgZW1waWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImVtcGxveWVlaWRcIik7XHJcbiAgICAgICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5zZXRDb29raWUoZW1waWQgKyBcImNjb2RlXCIsIGFkb2JqLkNvdW50cnlDb2RlLCAxMCk7XHJcbiAgICAgICAgICAgIHZhciBhZGlkID0gXCJcIjtcclxuICAgICAgICAgICAgdmFyIGFkdGV4dCA9IFwiSG9tZVwiO1xyXG4gICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkNvbXBhbnkgIT0gXCJcIiAmJiB0aGlzLm1vZGVsSW5wdXQuQ29tcGFueSAhPSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgIGFkdGV4dCA9IFwiV29ya1wiO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMuX0FkZHJlc3NUeXBlcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuVGV4dCA9PSBhZHRleHQpIHtcclxuICAgICAgICAgICAgICAgICAgICBhZGlkID0gdGhpcy5WYWx1ZTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgdmFyIEFkZHJlc09iaiA9IHsgU3RyZWV0OiBcIlwiLCBTdHJlZXQyOiBcIlwiLCBDaXR5TmFtZTogXCJcIiwgWmlwOiBcIlwiLCBDb3VudHJ5Q29kZTogYWRvYmouQ291bnRyeUNvZGUsIFN0YXRlSWQ6IFwiXCIsIEFkZHJlc3NUeXBlSWQ6IGFkaWQsIEZvckRlbGl2ZXJ5OiBmYWxzZSwgTWFpbkFkZHJlc3M6IGZhbHNlLCwgTWFpbk9yZGVyOiBcIk1haW5BZGRyXCIgKyAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzLmxlbmd0aCsxKS50b1N0cmluZygpLCBEZWx2cnlPcmRlcjogXCJEZWx2cnlcIiArICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMubGVuZ3RoKzEpLnRvU3RyaW5nKCkgfTtcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgLy9qUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgIC8vICAgIGlmICh0aGlzLk1haW5BZGRyZXNzID09IHRydWUgJiYgYWRvYmouTWFpbkFkZHJlc3MgPT0gdHJ1ZSAmJiB0aGlzICE9IGFkb2JqKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgIGFkb2JqLk1haW5BZGRyZXNzID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgLy8gICAgfVxyXG4gICAgICAgICAgICAgICAgLy99KTtcclxuICAgICAgICAgICAgICAgIGlmIChJc01haW5BZGQgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMucHVzaChBZGRyZXNPYmopO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHZhciBtc2cgPSAnJztcclxuICAgICAgICAgICAgaWYgKGFkb2JqLlN0cmVldCA9PSB1bmRlZmluZWQgfHwgYWRvYmouU3RyZWV0ID09IFwiXCIpIHtcclxuICAgICAgICAgICAgICAgIC8vbXNnICs9ICdcXG5TdHJlZXQgaXMgbm90IGZpbGxlZCc7IEFQUF9BTF9NU0dfU1RSRUVUXHJcbiAgICAgICAgICAgICAgICBtc2cgKz0gJ1xcbicgKyB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0FMX01TR19TVFJFRVQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKGFkb2JqLlN0cmVldDIgPT0gdW5kZWZpbmVkIHx8IGFkb2JqLlN0cmVldDIgPT0gXCJcIikge1xyXG4gICAgICAgICAgICAgICAgLy9tc2cgKz0gJ1xcbkFyZWEgaXMgbm90IGZpbGxlZCc7XHJcbiAgICAgICAgICAgICAgICBtc2cgKz0gJ1xcbicgKyB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0FMX01TR19BUkVBO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8vaWYgKGFkb2JqLkNpdHlOYW1lID09IHVuZGVmaW5lZCB8fCBhZG9iai5DaXR5TmFtZSA9PSBcIlwiKVxyXG4gICAgICAgICAgICAvLyAgICAvL21zZyArPSAnXFxuQ2l0eSBpcyBub3QgZmlsbGVkJzsgXHJcbiAgICAgICAgICAgIC8vICAgIG1zZyArPSAnXFxuJyArIHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfQUxfTVNHX0NJVFk7XHJcbiAgICAgICAgICAgIGlmIChhZG9iai5aaXAgPT0gdW5kZWZpbmVkIHx8IGFkb2JqLlppcCA9PSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICAvL21zZyArPSAnXFxuWmlwIGlzIG5vdCBmaWxsZWQnOyBcclxuICAgICAgICAgICAgICAgIG1zZyArPSAnXFxuJyt0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0FMX01TR19aSVA7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKGFkb2JqLkNvdW50cnlDb2RlID09IHVuZGVmaW5lZCB8fCBhZG9iai5Db3VudHJ5Q29kZSA9PSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICAvL21zZyArPSAnXFxuQ291bnRyeSBpcyBub3Qgc2VsZWN0ZWQnO1xyXG4gICAgICAgICAgICAgICAgbXNnICs9ICdcXG4nICsgdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9BTF9NU0dfQ09VTlRSWTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAvL2lmICh0aGlzLkFkZHJlc3MuU3RhdGVJZCA9PSB1bmRlZmluZWQgfHwgdGhpcy5BZGRyZXNzLlN0YXRlSWQgPT0gXCJcIikge1xyXG4gICAgICAgICAgICAvLyAgICBtc2cgKz0gJ1xcblN0YXRlIGlzIG5vdCBzZWxlY3RlZCc7XHJcbiAgICAgICAgICAgIC8vfVxyXG4gICAgICAgICAgICBpZiAoYWRvYmouQWRkcmVzc1R5cGVJZCA9PSB1bmRlZmluZWQgfHwgYWRvYmouQWRkcmVzc1R5cGVJZCA9PSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICAvL21zZyArPSAnXFxuQWRkcmVzcyB0eXBlIGlzIG5vdCBzZWxlY3RlZCc7XHJcbiAgICAgICAgICAgICAgICBtc2cgKz0gJ1xcbicgKyB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0FMX01TR19BRFRZUEU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICBtZXNzYWdlOiBtc2csIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgIH1cclxuICAgIENhbmFkZFBob25lKHBob25lT2JqKTogYm9vbGVhbiB7XHJcbiAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAvL2FsZXJ0KHRoaXMuUGhvbmVNb2RlbC5QaG9uZVR5cGVJZCArICcgJyArIHRoaXMuUGhvbmVNb2RlbC5QaG9uZVR5cGUgKyAnICcgKyB0aGlzLlBob25lTW9kZWwuUHJlZml4ICsgJyAnICsgdGhpcy5QaG9uZU1vZGVsLkFyZWEgKyAnICcgKyB0aGlzLlBob25lTW9kZWwuUGhvbmUpO1xyXG4gICAgICAgIHJldHVybiAocGhvbmVPYmouUGhvbmVUeXBlSWQgIT0gdW5kZWZpbmVkICYmIHBob25lT2JqLlBob25lVHlwZUlkICE9IFwiXCIpXHJcbiAgICAgICAgICAgIC8vICYmICh0aGlzLlBob25lTW9kZWwuUGhvbmVUeXBlICE9IHVuZGVmaW5lZCYmIHRoaXMuUGhvbmVNb2RlbC5QaG9uZVR5cGUgIT0gXCJcIiApXHJcbiAgICAgICAgICAgIC8vJiYgKHRoaXMuUGhvbmVNb2RlbC5QcmVmaXggIT0gdW5kZWZpbmVkJiYgdGhpcy5QaG9uZU1vZGVsLlByZWZpeCAhPSBcIlwiICApXHJcbiAgICAgICAgICAgIC8vJiYgKHRoaXMuUGhvbmVNb2RlbC5BcmVhICE9IHVuZGVmaW5lZCYmdGhpcy5QaG9uZU1vZGVsLkFyZWEgIT0gXCJcIiAgKVxyXG4gICAgICAgICAgICAvLyYmIChwaG9uZU9iai5QaG9uZSAhPSB1bmRlZmluZWQgJiYgcGhvbmVPYmouUGhvbmUgIT0gXCJcIik7XHJcbiAgICAgICAgICAgIC8vJiYgKHRoaXMuUGhvbmVNb2RlbC5QcmVmaXggIT0gdW5kZWZpbmVkICYmIHRoaXMuUGhvbmVNb2RlbC5QcmVmaXgubGVuZ3RoICE9IDMpOyAgICAgICAgICAgIDtcclxuICAgIH1cclxuICAgIEFkZFBob25lcyhwaG9uZU9iaik6IG9ic2VydmFibGUge1xyXG4gICAgICAgIGlmICh0aGlzLkNhbmFkZFBob25lKHBob25lT2JqKSkge1xyXG5cclxuICAgICAgICAgICAgZGVidWdnZXI7XHJcbiAgICAgICAgICAgIC8vaWYgKHRoaXMuSXNSZWNvcmRFZGl0TW9kZSA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICB2YXIgcGhpZCA9IFwiXCI7XHJcbiAgICAgICAgICAgIHZhciBTTVMgPSAwO1xyXG4gICAgICAgICAgICB2YXIgcHVibGlzaCA9IDA7XHJcbiAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMuX1Bob25lVHlwZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLlRleHQgPT0gXCJDZWxsUGhvbmVcIikge1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBwaGlkID0gdGhpcy5WYWx1ZTtcclxuICAgICAgICAgICAgICAgICAgICBTTVMgPSAxO1xyXG4gICAgICAgICAgICAgICAgICAgIHB1Ymxpc2ggPSAxO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIHZhciBQaG9uZU9iaiA9IHsgUGhvbmVUeXBlSWQ6IHBoaWQsIFBob25lVHlwZTogXCJcIiwgUHJlZml4OiBcIlwiLCBBcmVhOiBcIlwiLCBQaG9uZTogXCJcIiwgSXNTbXM6IFNNUywgQ29tbWVudHM6IFwiXCIsIElzU2hvd1JlbWFya3M6IGZhbHNlLCBwaHB1Ymxpc2g6IHB1Ymxpc2gsIFNNU09yZGVyOiBcIlNNU1wiICsgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lcy5sZW5ndGggKyAxKS50b1N0cmluZygpLCBQdWJsaXNoT3JkZXI6IFwiUHViXCIgKyAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzLmxlbmd0aCArIDEpLnRvU3RyaW5nKCkgfTtcclxuICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lcy5wdXNoKFBob25lT2JqKTtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAvL3RoaXMuQ2hlY2tDdXN0V2l0aGZuYW1lbG5hbWVjb21wcGhzZW1haWxzKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICB2YXIgbXNnID0gJyc7XHJcbiAgICAgICAgICAgIGlmIChwaG9uZU9iai5QaG9uZVR5cGVJZCA9PSB1bmRlZmluZWQgfHwgcGhvbmVPYmouUGhvbmVUeXBlSWQgPT0gXCJcIikge1xyXG4gICAgICAgICAgICAgICAgLy9tc2cgKz0gJ1xcblBob25lIHR5cGUgaXMgbm90IHNlbGVjdGVkJztcclxuICAgICAgICAgICAgICAgIG1zZyArPSAnXFxuJyArIHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfQUxfUkVHTVNHX1BIVFlQRTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAvL2lmIChwaG9uZU9iai5QaG9uZSA9PSB1bmRlZmluZWQgfHwgcGhvbmVPYmouUGhvbmUgPT0gXCJcIikge1xyXG4gICAgICAgICAgICAvLyAgICAvL21zZyArPSAnXFxuUGhvbmUgbnVtYmVyIGlzIG5vdCBmaWxsZWQnO1xyXG4gICAgICAgICAgICAvLyAgICBtc2cgKz0gJ1xcbicgKyB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0FMX1JFR01TR19QSE5PO1xyXG4gICAgICAgICAgICAvL31cclxuICAgICAgICAgICAgLy9pZiAodGhpcy5QaG9uZU1vZGVsLlByZWZpeC5sZW5ndGghPTMpIHtcclxuICAgICAgICAgICAgLy8gICAgbXNnICs9ICdcXG5QcmVmaXggbXVzdCBvZiAzIG51bWVyaWMgZGlnaXRzJztcclxuICAgICAgICAgICAgLy99XHJcbiAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgbWVzc2FnZTogbXNnLGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgIH1cclxuICAgIENhbmFkZEVtYWlsKEVtYWlsT2JqKTogYm9vbGVhbiB7XHJcbiAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAvL2FsZXJ0KCdIZWxsbycpO1xyXG4gICAgICAgIHJldHVybiAoRW1haWxPYmouRW1haWxOYW1lICE9IHVuZGVmaW5lZCAmJiBFbWFpbE9iai5FbWFpbE5hbWUgIT0gXCJcIik7XHJcbiAgICAgICAgLy8oRW1haWxPYmouRW1haWwgIT0gdW5kZWZpbmVkICYmIEVtYWlsT2JqLkVtYWlsICE9IFwiXCIpICYmXHJcbiAgICAgICAgICAgICBcclxuICAgIH1cclxuICAgIEFkZEVtYWlscyhFbWFpbE9iaik6IG9ic2VydmFibGUge1xyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgaWYgKHRoaXMuQ2FuYWRkRW1haWwoRW1haWxPYmopKSB7XHJcbiAgICAgICAgICAgIHZhciBlcHVibGlzaCA9IDA7XHJcbiAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMuX1Bob25lVHlwZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgaWYgKHRoaXMuVGV4dCA9PSBcIkNlbGxQaG9uZVwiKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgZXB1Ymxpc2ggPSAxO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIC8vaWYgKHRoaXMuSXNSZWNvcmRFZGl0TW9kZSA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICB2YXIgZU9iaiA9IHt9O1xyXG4gICAgICAgICAgICBlT2JqLkVtYWlsID0gXCJcIjtcclxuICAgICAgICAgICAgZU9iai5FbWFpbE5hbWUgPSB0aGlzLm1vZGVsSW5wdXQuRmlsZUFzO1xyXG4gICAgICAgICAgICBlT2JqLk5ld3NsZXR0ZXJlID0gdHJ1ZTtcclxuICAgICAgICAgICAgZU9iai5wdWJsaXNoID0gZXB1Ymxpc2g7XHJcbiAgICAgICAgICAgIGVPYmouTmV3c09yZGVyPSBcIk5ld3NcIiArICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMubGVuZ3RoKzEpLnRvU3RyaW5nKCk7XHJcbiAgICAgICAgICAgIGVPYmouRVB1Ymxpc2hPcmRlcj0gXCJFUHViXCIgKyAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzLmxlbmd0aCArIDEpLnRvU3RyaW5nKCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMucHVzaChlT2JqKTtcclxuICAgICAgICAgICAgICAgIC8vdGhpcy5DaGVja0N1c3RXaXRoZm5hbWVsbmFtZWNvbXBwaHNlbWFpbHMoKTtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICB2YXIgbXNnID0gJyc7XHJcbiAgICAgICAgICAgIC8vaWYgKEVtYWlsT2JqLkVtYWlsID09IHVuZGVmaW5lZCB8fCBFbWFpbE9iai5FbWFpbCA9PSBcIlwiKVxyXG4gICAgICAgICAgICAvLyAgICAvL21zZyArPSAnXFxuRW1haWwgaXMgbm90IGZpbGxlZCc7XHJcbiAgICAgICAgICAgIC8vICAgIG1zZyArPSAnXFxuJyArIHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfQUxfUkVHTVNHX0VNQUlMO1xyXG4gICAgICAgICAgICBpZiAoRW1haWxPYmouRW1haWxOYW1lID09IHVuZGVmaW5lZCB8fCBFbWFpbE9iai5FbWFpbE5hbWUgPT0gXCJcIikge1xyXG4gICAgICAgICAgICAgICAgLy9tc2cgKz0gJ1xcbk5hbWUgaXMgbm90IGZpbGxlZCc7XHJcbiAgICAgICAgICAgICAgICBtc2cgKz0gJ1xcbicgKyB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0FMX1JFR01TR19FTkFNRTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgIG1lc3NhZ2U6IG1zZywgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgICAgIC8vIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3NlcyA9IHRoaXMuQ3VzdG9tZXJBZGRyZXNzZXM7XHJcbiAgICB9XHJcbiAgICBcclxuICAgIGVkaXRDdXN0RGV0KE9iaikge1xyXG4gICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRDb21wbGV0ZUN1c3REZXQoT2JqLkN1c3RvbWVySWQpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dCA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICB0aGlzLlNBVkVfQlROX1RFWFQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0JUTl9VUERBVEU7XHJcbiAgICAgICAgICAgICAgICAvL3RoaXMuQUREX05FV19DVVNUX1RFWFQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0xCTF9VUERBVEVfQ1VTVDtcclxuICAgICAgICAgICAgICAgIHRoaXMuQ1NTVEVYVCA9IFwibWRpLWNvbnRlbnQtYWRkXCI7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzLmxlbmd0aCA9PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzID0gW3sgRW1haWw6IFwiXCIsIEVtYWlsTmFtZTogdGhpcy5tb2RlbElucHV0LkZpbGVBcywgTmV3c2xldHRlcmU6IGZhbHNlLCBwdWJsaXNoOiAwLCBOZXdzT3JkZXI6IFwiTmV3czFcIiwgRVB1Ymxpc2hPcmRlcjogXCJFUHViMVwiIH1dXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgY291bnQgPSAxO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5OZXdzT3JkZXIgPSBcIk5ld3NcIiArIGNvdW50O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLkVQdWJsaXNoT3JkZXIgPSBcIkVQdWJcIiArIGNvdW50Kys7XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzLmxlbmd0aCA9PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIHBoaWQgPSBcIlwiO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLl9QaG9uZVR5cGVzLCBmdW5jdGlvbiAoKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5UZXh0ID09IFwiQ2VsbFBob25lXCIpIHtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwaGlkID0gdGhpcy5WYWx1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXMgPSBbeyBQaG9uZVR5cGVJZDogcGhpZCwgUHJlZml4OiBcIlwiLCBBcmVhOiBcIlwiLCBQaG9uZTogXCJcIiwgSXNTbXM6IDAsIENvbW1lbnRzOiBcIlwiLCBwaHB1Ymxpc2g6IDAsIFNNU09yZGVyOiBcIlNNUzFcIiwgUHVibGlzaE9yZGVyOiBcIlB1YjFcIiB9XTtcclxuICAgICAgICAgICAgICAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBjb3VudCA9IDE7XHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzLCBmdW5jdGlvbiAoKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLlNNU09yZGVyID0gXCJTTVNcIiArIGNvdW50O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLlB1Ymxpc2hPcmRlciA9IFwiUHViXCIgKyBjb3VudCsrO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3Nlcy5sZW5ndGggPT0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBlbXBpZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiZW1wbG95ZWVpZFwiKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIGNjb2RlID0gdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmdldENvb2tpZShlbXBpZCArIFwiY2NvZGVcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGNjb2RlLmxlbmd0aCA+IDApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNjb2RlID0gY2NvZGUuc3Vic3RyaW5nKDEsIGNjb2RlLmxlbmd0aCk7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIGFkaWQgPSBcIlwiO1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBjb21wdGV4dCA9IFwiSG9tZVwiO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ29tcGFueSAhPSBcIlwiICYmIHRoaXMubW9kZWxJbnB1dC5Db21wYW55ICE9IHVuZGVmaW5lZCAmJiB0aGlzLm1vZGVsSW5wdXQuQ29tcGFueSAhPSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbXB0ZXh0ID0gXCJXb3JrXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMuX0FkZHJlc3NUeXBlcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5UZXh0ID09IGNvbXB0ZXh0KSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYWRpZCA9IHRoaXMuVmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzID0gW3sgU3RyZWV0OiBcIlwiLCBTdHJlZXQyOiBcIlwiLCBDaXR5TmFtZTogXCJcIiwgWmlwOiBcIlwiLCBDb3VudHJ5Q29kZTogY2NvZGUsIFN0YXRlSWQ6IFwiXCIsIEFkZHJlc3NUeXBlSWQ6IGFkaWQsIEZvckRlbGl2ZXJ5OiBmYWxzZSwgTWFpbkFkZHJlc3M6IGZhbHNlLCBNYWluT3JkZXI6IFwiTWFpbkFkZHIxXCIsIERlbHZyeU9yZGVyOiBcIkRlbHZyeTFcIiB9XTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBjb3VudCA9IDE7XHJcbiAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLk1haW5PcmRlciA9IFwiTWFpbkFkZHJcIiArIGNvdW50O1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuRGVsdnJ5T3JkZXIgPSBcIkRlbHZyeVwiICsgY291bnQrKztcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLy92YXIgdHJlZXZpZXcgPSBqUXVlcnkoXCIjZ3JvdXBUcmVlXCIpLmRhdGEoXCJrZW5kb1RyZWVWaWV3XCIpO1xyXG5cclxuICAgICAgICAgICAgICAgIC8vdmFyIGJhciA9IHRyZWV2aWV3LmZpbmRCeUlkKFwiQmFyXCIpO1xyXG5cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgLy9qUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJHcm91cHMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgIC8vICAgIHZhciBkYXRhID0galF1ZXJ5KFwiI2dyb3VwVHJlZVwiKS5kYXRhKFwia2VuZG9UcmVlVmlld1wiKS5kYXRhU291cmNlLmdldEJ5VWlkKHRoaXMuQ3VzdG9tZXJHZW5lcmFsR3JvdXBJZCk7XHJcbiAgICAgICAgICAgICAgICAvLyAgICBpZiAoZGF0YSkge1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgIGRhdGEuc2V0KFwiY2hlY2tlZFwiLCB0cnVlKTtcclxuICAgICAgICAgICAgICAgIC8vICAgIH1cclxuICAgICAgICAgICAgICAgIC8vICAgIC8vdmFyIEdyb3VwTm9kZSA9IHRyZWV2aWV3LmZpbmRCeUlkKHRoaXMuQ3VzdG9tZXJHZW5lcmFsR3JvdXBJZCk7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAvL3RyZWV2aWV3LmRhdGFJdGVtKEdyb3VwTm9kZSkuc2V0KFwiY2hlY2tlZFwiLCB0cnVlKTtcclxuICAgICAgICAgICAgICAgIC8vfSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLkN1c3RJZFRleHQgPSBcIiggXCIgKyB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCArIFwiIClcIjtcclxuICAgICAgICAgICAgICAgIHRoaXMuSXNGaWxlQXN0eHRTaG93ID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB0aGlzLkhpZGVTaG93RmlsZUFzdHh0KCk7XHJcblxyXG4gICAgICAgICAgICAgICAgLy9hbGVydCh0aGlzLlJFUyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcbiAgICBDaGVja1Bob25lVHlwZShQaG9uZU9iaikge1xyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgLy9hbGVydChQaG9uZU9iai5QaG9uZVR5cGVJZCArIFwiIHwgXCIgKyBqUXVlcnkoXCIjUGhvbmVUeXBlXCIpLnZhbCgpKTtcclxuICAgICAgICB2YXIgcHJldGVtcCA9IFtdO1xyXG4gICAgICAgIGpRdWVyeSgnc2VsZWN0W25hbWVePVwicGh0eXBlXCJdJykuZWFjaChmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIHByZXRlbXAucHVzaChqUXVlcnkodGhpcykudmFsKCkpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHZhciBpbmRleCA9IDA7XHJcbiAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzID09IFBob25lT2JqKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaW5kZXggPSBpbmRleCArIDE7XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGlmIChwcmV0ZW1wW2luZGV4XSAhPSB1bmRlZmluZWQgJiYgcHJldGVtcFtpbmRleF0gIT0gbnVsbCAmJiBwcmV0ZW1wW2luZGV4XSAhPSBcIlwiKSB7XHJcbiAgICAgICAgICAgIHZhciBQaG9uZVR5cGVJZCA9IHByZXRlbXBbaW5kZXhdO1xyXG4gICAgICAgICAgICB0aGlzLl9jdXN0b21lclNlcnZpY2UuR2V0UGhvbmVUeXBlRGV0KFBob25lVHlwZUlkKS5zdWJzY3JpYmUoXHJcbiAgICAgICAgICAgICAgICAoZGF0YSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9cclxuICAgICAgICAgICAgICAgICAgICB2YXIgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKGRhdGEpO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuRGF0YSAhPSB1bmRlZmluZWQgJiYgcmVzcG9uc2UuRGF0YSAhPSBudWxsICYmIHJlc3BvbnNlLkRhdGEgIT0gXCJcIikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2FsZXJ0KGluZGV4ICsgXCIgfCBcIiArIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lc1tpbmRleF0uSXNTbXMgKyBcIiB8IFwiICsgcmVzcG9uc2UuRGF0YS5UZXh0KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5EYXRhLlRleHQgPT0gXCIxXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXNbaW5kZXhdLklzU21zID0gMTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXNbaW5kZXhdLnBocHVibGlzaCA9IDE7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzW3RoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlscy5sZW5ndGggLSAxXS5wdWJsaXNoID0gMTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lc1tpbmRleF0ucGhwdWJsaXNoID0gMDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXNbaW5kZXhdLklzU21zID0gMDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHNbdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzLmxlbmd0aCAtIDFdLnB1Ymxpc2ggPSAwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2FsZXJ0KHRoaXMuUkVTKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgLy92YXIgdHJlZXZpZXdEYXRhU291cmNlID0galF1ZXJ5KFwiI2dyb3VwVHJlZVwiKS5kYXRhKFwia2VuZG9UcmVlVmlld1wiKS5kYXRhU291cmNlLnZpZXcoKTtcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAoZXJyKSA9PiB7XHJcblxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICgpID0+IHtcclxuXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgZWRpdEVtYWlsRGV0KEVtYWlsT2JqKTogb2JzZXJ2YWJsZSB7XHJcbiAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICB2YXIgaW5kZXggPSAwO1xyXG4gICAgICAgIHRoaXMuSXNSZWNvcmRFZGl0TW9kZSA9IHRydWU7XHJcbiAgICAgICAgdGhpcy5CVE5fUEhBREQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0JUTl9QSEVESVQ7XHJcbiAgICAgICAgXHJcblxyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMuRW1haWxNb2RlbC5FbWFpbCA9IEVtYWlsT2JqLkVtYWlsO1xyXG4gICAgICAgIHRoaXMuRW1haWxNb2RlbC5FbWFpbE5hbWUgPSBFbWFpbE9iai5FbWFpbE5hbWU7XHJcbiAgICAgICAgdGhpcy5FbWFpbE1vZGVsLk5ld3NsZXR0ZXJlID0gRW1haWxPYmouTmV3c2xldHRlcmU7XHJcblxyXG5cclxuICAgICAgICB0aGlzLkVkaXRFbWFpbERhdGEgPSB7fTtcclxuICAgICAgICB0aGlzLkVkaXRFbWFpbERhdGEgPSBFbWFpbE9iajtcclxuICAgIH1cclxuICAgIGRlbEVtYWlsRGV0KEVtYWlsT2JqKTogb2JzZXJ2YWJsZSB7XHJcbiAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICB2YXIgaW5kZXggPSAwO1xyXG4gICAgICAgIGpRdWVyeS5lYWNoKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlscywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICBpZiAodGhpcyA9PSBFbWFpbE9iaikge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaW5kZXggPSBpbmRleCArIDE7XHJcblxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlscy5zcGxpY2UoaW5kZXgsIDEpO1xyXG4gICAgfVxyXG5cclxuICAgIGVkaXRBZGRyZXNzRGV0KEFkZHJlc3NPYmopOiBvYnNlcnZhYmxlIHtcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgIHZhciBpbmRleCA9IDA7XHJcbiAgICAgICAgdGhpcy5Jc1JlY29yZEVkaXRNb2RlID0gdHJ1ZTtcclxuICAgICAgICB0aGlzLkJUTl9QSEFERCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfQlROX1BIRURJVDtcclxuICAgICAgICBcclxuICAgICAgIC8vIEFkZHJlc3NPYmouQ2l0eU5hbWUgPSBqUXVlcnkoXCIjQ2l0eVwiKS52YWwoKTtcclxuXHJcbiAgICAgICAgdGhpcy5BZGRyZXNzLlN0cmVldCA9IEFkZHJlc3NPYmouU3RyZWV0O1xyXG4gICAgICAgIHRoaXMuQWRkcmVzcy5TdHJlZXQyID0gQWRkcmVzc09iai5TdHJlZXQyO1xyXG4gICAgICAgIHRoaXMuQWRkcmVzcy5DaXR5TmFtZSA9IEFkZHJlc3NPYmouQ2l0eU5hbWU7XHJcbiAgICAgICAgdGhpcy5BZGRyZXNzLlppcCA9IEFkZHJlc3NPYmouWmlwO1xyXG4gICAgICAgIHRoaXMuQWRkcmVzcy5Db3VudHJ5Q29kZSA9IEFkZHJlc3NPYmouQ291bnRyeUNvZGU7XHJcbiAgICAgICAgdGhpcy5BZGRyZXNzLlN0YXRlSWQgPSBBZGRyZXNzT2JqLlN0YXRlSWQ7XHJcbiAgICAgICAgdGhpcy5BZGRyZXNzLkFkZHJlc3NUeXBlSWQgPSBBZGRyZXNzT2JqLkFkZHJlc3NUeXBlSWQ7XHJcbiAgICAgICAgdGhpcy5BZGRyZXNzLk1haW5BZGRyZXNzID0gQWRkcmVzc09iai5NYWluQWRkcmVzcztcclxuICAgICAgICB0aGlzLkFkZHJlc3MuRm9yRGVsaXZlcnkgPSBBZGRyZXNzT2JqLkZvckRlbGl2ZXJ5O1xyXG5cclxuXHJcbiAgICAgICAgdGhpcy5FZGl0QWRkcmVzc0RhdGEgPSB7fTtcclxuICAgICAgICB0aGlzLkVkaXRBZGRyZXNzRGF0YSA9IEFkZHJlc3NPYmo7XHJcbiAgICB9XHJcblxyXG4gICAgZGVsQWRkcmVzc0RldChBZGRyZXNzT2JqKTogb2JzZXJ2YWJsZSB7XHJcbiAgICAgICAvLyBkZWJ1Z2dlcjsgXHJcbiAgICAgICAgdmFyIGluZGV4ID0gMDtcclxuICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMgPT0gQWRkcmVzc09iaikge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaW5kZXggPSBpbmRleCArIDE7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzLnNwbGljZShpbmRleCwgMSk7XHJcbiAgICB9XHJcbiAgICBlZGl0UGhvbmVEZXQoUGhvbmVPYmopOiBvYnNlcnZhYmxlIHtcclxuICAgICAgICBcclxuICAgICAgICB2YXIgaW5kZXggPSAwO1xyXG4gICAgICAgIHRoaXMuQlROX1BIQUREID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9CVE5fUEhFRElUXHJcbiAgICAgICAgdmFyIHRlbXAgPSBQaG9uZU9iai5QaG9uZVR5cGVJZC5zcGxpdCgnOycpO1xyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMuUGhvbmVNb2RlbC5QaG9uZVR5cGVJZCA9IFBob25lT2JqLlBob25lVHlwZSArIFwiO1wiICsgUGhvbmVPYmouUGhvbmVUeXBlSWQ7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5QaG9uZU1vZGVsLlBob25lVHlwZSA9IFBob25lT2JqLlBob25lVHlwZTtcclxuICAgICAgICB0aGlzLlBob25lTW9kZWwuUHJlZml4ID0gUGhvbmVPYmouUHJlZml4O1xyXG4gICAgICAgIHRoaXMuUGhvbmVNb2RlbC5BcmVhID0gUGhvbmVPYmouQXJlYTtcclxuICAgICAgICB0aGlzLlBob25lTW9kZWwuUGhvbmUgPSBQaG9uZU9iai5QaG9uZTtcclxuICAgICAgICB0aGlzLlBob25lTW9kZWwuSXNTbXMgPSBQaG9uZU9iai5Jc1NtcztcclxuICAgICAgICB0aGlzLlBob25lTW9kZWwuQ29tbWVudHMgPSBQaG9uZU9iai5Db21tZW50cztcclxuICAgICAgICB0aGlzLkVkaXRQaG9uZURhdGEgPSB7fTtcclxuICAgICAgICB0aGlzLkVkaXRQaG9uZURhdGEgPSBQaG9uZU9iajtcclxuICAgIH1cclxuICAgIGRlbFBob25lRGV0KFBob25lT2JqKTogb2JzZXJ2YWJsZSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdmFyIGluZGV4ID0gMDtcclxuICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMgPT0gUGhvbmVPYmopIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGluZGV4ID0gaW5kZXggKyAxO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lcy5zcGxpY2UoaW5kZXgsIDEpO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICBnZXRTZWxlY3RlZEdyb3VwcygpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJHcm91cHMgPSBbXTtcclxuICAgICAgICB2YXIgX0NoZWNrZWRHcm91cHMgPSBbXTtcclxuICAgICAgICBpZiAodGhpcy5Jc1Nob3dBbGwgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgS2VuZG9fdXRpbGl0eS5jaGVja2VkTm9kZUlkcyhqUXVlcnkoXCIjZ3JvdXBUcmVlXCIpLmRhdGEoXCJrZW5kb1RyZWVWaWV3XCIpLmRhdGFTb3VyY2UudmlldygpLCBfQ2hlY2tlZEdyb3Vwcyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgIFxyXG4gICAgICAgICAgICBLZW5kb191dGlsaXR5LmNoZWNrZWROb2RlSWRzKGpRdWVyeShcIiNncm91cFRyZWUxXCIpLmRhdGEoXCJrZW5kb1RyZWVWaWV3XCIpLmRhdGFTb3VyY2UudmlldygpLCBfQ2hlY2tlZEdyb3Vwcyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGZvciAodmFyIGkgPSAwO2k8X0NoZWNrZWRHcm91cHMubGVuZ3RoO2krKyl7XHJcbiAgICAgICAgICAgIHZhciBHT2JqID0ge307XHJcbiAgICAgICAgICAgIEdPYmouQ3VzdG9tZXJHZW5lcmFsR3JvdXBJZCA9IF9DaGVja2VkR3JvdXBzW2ldO1xyXG4gICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJHcm91cHMucHVzaChHT2JqKTtcclxuICAgICBcclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICB9XHJcblxyXG4gICAgTW9yZSgpOiBvYnNlcnZhYmxlIHtcclxuICAgICAgIC8vIGFsZXJ0KFwiY2FsbFwiKTtcclxuICAgICAgICBpZiAodGhpcy5TaG93TW9yZSA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuU2hvd01vcmUgPSBmYWxzZTtcclxuXHJcbiAgICAgICAgICAgIC8vdGhpcy5TaG93TW9yZVRleHQgPSBcIk1vcmVcIjtcclxuICAgICAgICAgICAgdGhpcy5TaG93TW9yZVRleHQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0xOS19MQkxfTU9SRTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgdGhpcy5TaG93TW9yZSA9IHRydWU7XHJcbiAgICAgICAgLy90aGlzLlNob3dNb3JlVGV4dCA9IFwiTGVzc1wiOyBcclxuICAgICAgICB0aGlzLlNob3dNb3JlVGV4dCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfTE5LX0xCTF9MRVNTO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIGJpbmRHcm91cFRyZWUoSXNzaG93YWxsKTogb2JzZXJ2YWJsZSB7XHJcbiAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkdldEdlbmVyYWxHcm91cHMoSXNzaG93YWxsKS5zdWJzY3JpYmUoXHJcbiAgICAgICAgICAgIChkYXRhKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgLy9cclxuICAgICAgICAgICAgICAgIC8vYWxlcnQoSXNzaG93YWxsKTtcclxuICAgICAgICAgICAgICAgIGlmIChJc3Nob3dhbGwgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkoXCIjZ3JvdXBUcmVlXCIpLmh0bWwoXCJMb2RpbmcuLi5cIik7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIHJlcyA9IGpRdWVyeS5wYXJzZUpTT04oZGF0YSkuRGF0YVxyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeShcIiNncm91cFRyZWVcIikua2VuZG9UcmVlVmlldyh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRPbkRlbWFuZDogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tib3hlczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tDaGlsZHJlbjogdHJ1ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2NoZWNrOiB0aGlzLm9uR3JvdXBTZWxlY3QsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhdGFTb3VyY2U6IHJlc1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBncnBpZHMgPSBcIlwiO1xyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckdyb3VwcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBncnBpZHMgKz0gdGhpcy5DdXN0b21lckdlbmVyYWxHcm91cElkICsgXCI7XCI7XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGdycGlkcy5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEtlbmRvX3V0aWxpdHkuY2hlY2tpbmdOb2RlSWRzKGpRdWVyeShcIiNncm91cFRyZWVcIikuZGF0YShcImtlbmRvVHJlZVZpZXdcIikuZGF0YVNvdXJjZS52aWV3KCksIGdycGlkcy5zdWJzdHJpbmcoMCwgZ3JwaWRzLmxlbmd0aCAtIDEpKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeShcIiNncm91cFRyZWUxXCIpLmh0bWwoXCJMb2RpbmcuLi5cIik7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIHJlcyA9IGpRdWVyeS5wYXJzZUpTT04oZGF0YSkuRGF0YVxyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeShcIiNncm91cFRyZWUxXCIpLmtlbmRvVHJlZVZpZXcoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsb2FkT25EZW1hbmQ6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrYm94ZXM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrQ2hpbGRyZW46IHRydWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9jaGVjazogdGhpcy5vbkdyb3VwU2VsZWN0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkYXRhU291cmNlOiByZXNcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgZ3JwaWRzID0gXCJcIjtcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJHcm91cHMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZ3JwaWRzICs9IHRoaXMuQ3VzdG9tZXJHZW5lcmFsR3JvdXBJZCArIFwiO1wiO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChncnBpZHMubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBLZW5kb191dGlsaXR5LmNoZWNraW5nTm9kZUlkcyhqUXVlcnkoXCIjZ3JvdXBUcmVlMVwiKS5kYXRhKFwia2VuZG9UcmVlVmlld1wiKS5kYXRhU291cmNlLnZpZXcoKSwgZ3JwaWRzLnN1YnN0cmluZygwLCBncnBpZHMubGVuZ3RoIC0gMSkpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLy92YXIgdHJlZXZpZXdEYXRhU291cmNlID0galF1ZXJ5KFwiI2dyb3VwVHJlZVwiKS5kYXRhKFwia2VuZG9UcmVlVmlld1wiKS5kYXRhU291cmNlLnZpZXcoKTtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgKGVycikgPT4ge1xyXG5cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgKCkgPT4ge1xyXG5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICk7XHJcbiAgICB9XHJcbiAgICBHZXREYXRhRm9yU2VhcmNoKGV2ZW50OiBhbnkpOiBvYnNlcnZhYmxlIHtcclxuICAgICAgICBcclxuICAgICAgICAvL3RoaXMuU2VhcmNoVmFsID0galF1ZXJ5KFwiI1NlYXJjaHR4dFwiKS52YWwoKTtcclxuICAgICAgICAvL2FsZXJ0KGV2ZW50LmtleUNvZGUpO1xyXG4gICAgICAgIC8vaWYgKHRoaXMuU2VhcmNoVmFsICE9IHVuZGVmaW5lZCAmJiB0aGlzLlNlYXJjaFZhbCAhPSBcIlwiICYmIHRoaXMuU2VhcmNoVmFsICE9IG51bGwgJiYgZXZlbnQua2V5Q29kZSA9PSAxMykge1xyXG4gICAgICAgICAgICAvL2FsZXJ0KHRoaXMuYXV0b2NvbXBsZXRlU2VsZWN0ICsgXCIgXCIgKyB0aGlzLmF1dG9jb21wbGV0ZU5vUmVzdWx0cyk7XHJcbiAgICAgICAgLy8gICAgdGhpcy5FbnRlckNvdW50Kys7XHJcbiAgICAgICAgLy8gICAgaWYgKHRoaXMuRW50ZXJDb3VudCA+PSAyKSB7XHJcbiAgICAgICAgLy8gICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRDb21wbGV0ZVNlYXJjaCh0aGlzLlNlYXJjaFZhbCkuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgLy8gICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgIC8vICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgIC8vICAgICAgICAgICAgICAgIGFsZXJ0KHJlc3BvbnNlLkVyck1zZyk7XHJcbiAgICAgICAgLy8gICAgICAgICAgICB9XHJcbiAgICAgICAgLy8gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAvLyAgICAgICAgICAgICAgICB0aGlzLkN1c3RMaXN0ID0ge307XHJcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgdGhpcy5DdXN0TGlzdCA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLkRhdGEgIT0gbnVsbCAmJiByZXNwb25zZS5EYXRhICE9IHVuZGVmaW5lZCkge1xyXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICB0aGlzLmN1c3RTZWFyY2hEYXRhID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgalF1ZXJ5KFwiI0N1c3RNb2RhbFwiKS5tb2RhbChcInNob3dcIik7XHJcblxyXG4gICAgICAgIC8vICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8gICAgICAgICAgICB9XHJcbiAgICAgICAgLy8gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgIC8vICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIC8vICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgLy8gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICAvLyAgICAgICAgfSk7XHJcbiAgICAgICAgLy8gICAgICAgIHRoaXMuRW50ZXJDb3VudCA9IDA7XHJcbiAgICAgICAgLy8gICAgfVxyXG4gICAgICAgICAgICAgICBcclxuICAgICAgICAvL31cclxuICAgICAgICAvL3RoaXMuU2VhcmNoVmFsID0gXCJcIjtcclxuICAgIH1cclxuXHJcblxyXG4gICAgbmdPbkluaXQoKSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICAvL2Jvb3Rib3guYWxlcnQoXCJUaGlzIGlzIHRoZSBkZWZhdWx0IGFsZXJ0IVwiKTtcclxuICAgICAgICBpZiAobG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJsYW5nXCIpID09IFwiXCIpIHtcclxuICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJsYW5nXCIsIFwiZW5cIik7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICh0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZ2V0Q29va2llKFwibGFuZ1wiKSA9PSBcIlwiKSB7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2Uuc2V0Q29va2llKFwibGFuZ1wiLCBcImVuXCIsIDEwKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5Jc0NhbmNlbCA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMuc2hvd2hpZGVHcm91cHMoKTtcclxuICAgICAgICB0aGlzLklzRmlsZUFzdHh0U2hvdyA9IHRydWU7XHJcbiAgICAgICAgXHJcbiAgICAgICAgLy90aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCA9IC0xO1xyXG4gICAgICAgIFxyXG4gICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCA+PSAwKSB7XHJcbiAgICAgICAgICAgIC8vdGhpcy5Jc0ZpbGVBc3R4dFNob3cgPSBmYWxzZTtcclxuICAgICAgICAgICAgdGhpcy5lZGl0Q3VzdERldCh0aGlzLm1vZGVsSW5wdXQpO1xyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgdGhpcy5TQVZFX0JUTl9URVhUID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9CVE5fVVBEQVRFO1xyXG4gICAgICAgICAgICAvL3RoaXMuQUREX05FV19DVVNUX1RFWFQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0xCTF9VUERBVEVfQ1VTVDtcclxuICAgICAgICAgICAgLy90aGlzLkNTU1RFWFQgPSBcIm1kaS1jb250ZW50LWFkZFwiO1xyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3Nlcy5sZW5ndGggPT0gMCkge1xyXG4gICAgICAgICAgICAgICAgdmFyIGVtcGlkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJlbXBsb3llZWlkXCIpO1xyXG5cclxuICAgICAgICAgICAgICAgIHZhciBjY29kZSA9IHRoaXMuX3Jlc291cmNlU2VydmljZS5nZXRDb29raWUoZW1waWQgKyBcImNjb2RlXCIpO1xyXG4gICAgICAgICAgICAgICAgaWYgKGNjb2RlLmxlbmd0aCA+IDApXHJcbiAgICAgICAgICAgICAgICAgICAgY2NvZGUgPSBjY29kZS5zdWJzdHJpbmcoMSwgY2NvZGUubGVuZ3RoKTtcclxuICAgICAgICAgICAgICAgIHZhciBhZGlkID0gXCJcIjtcclxuICAgICAgICAgICAgICAgIHZhciBjb21wdGV4dCA9IFwiSG9tZVwiO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5Db21wYW55ICE9IFwiXCIgJiYgdGhpcy5tb2RlbElucHV0LkNvbXBhbnkgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dC5Db21wYW55ICE9IG51bGwpIHtcclxuICAgICAgICAgICAgICAgICAgICBjb21wdGV4dCA9IFwiV29ya1wiO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5fQWRkcmVzc1R5cGVzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuVGV4dCA9PSBjb21wdGV4dCkge1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgYWRpZCA9IHRoaXMuVmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMgPSBbeyBTdHJlZXQ6IFwiXCIsIFN0cmVldDI6IFwiXCIsIENpdHlOYW1lOiBcIlwiLCBaaXA6IFwiXCIsIENvdW50cnlDb2RlOiBjY29kZSwgU3RhdGVJZDogXCJcIiwgQWRkcmVzc1R5cGVJZDogYWRpZCwgRm9yRGVsaXZlcnk6IGZhbHNlLCBNYWluQWRkcmVzczogZmFsc2UsIE1haW5PcmRlcjogXCJNYWluQWRkcjFcIiwgRGVsdnJ5T3JkZXI6IFwiRGVsdnJ5MVwiIH1dO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRoaXMuQ3VzdElkVGV4dCA9IFwiKCBcIiArIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkICsgXCIgKVwiXHJcbiAgICAgICAgICAgIHRoaXMuSXNGaWxlQXN0eHRTaG93ID0gZmFsc2U7XHJcbiAgICAgICAgICAgIC8vdGhpcy5IaWRlU2hvd0ZpbGVBc3R4dCgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLkxhbmcgPSB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZ2V0Q29va2llKFwibGFuZ1wiKTtcclxuICAgICAgICBpZiAodGhpcy5MYW5nLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgdGhpcy5MYW5nID0gdGhpcy5MYW5nLnN1YnN0cmluZygxLCB0aGlzLkxhbmcubGVuZ3RoKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5IaWRlU2hvd0ZpbGVBc3R4dCgpO1xyXG4gICAgICAgLy90aGlzLlJFUyA9IGpRdWVyeS5wYXJzZUpTT04odGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkdldExhbmdSZXModGhpcy5Gb3JtdHlwZSwgdGhpcy5MYW5nKSkuRGF0YTsgLy9qUXVlcnkucGFyc2VKU09OKGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwibGFuZ3Jlc291cmNlXCIpKTtcclxuICAgICAgICBcclxuICAgICAgICBpZiAodGhpcy5MYW5nID09IFwiaGVcIikge1xyXG4gICAgICAgICAgICB0aGlzLktlbmRvUlRMQ1NTID0gXCJrLXJ0bFwiO1xyXG4gICAgICAgICAgICB0aGlzLkNIQU5HRURJUiA9IFwicnRsbW9kYWxcIjtcclxuICAgICAgICAgICAgdGhpcy5DaGFuZ2VEaWFsb2cgPSBcImlucHV0X3JpZ2h0XCI7XHJcbiAgICAgICAgICAgIC8valF1ZXJ5KFwiLmJvb3Rib3gtY2xvc2UtYnV0dG9uXCIpLmNzcyhcImZsb2F0XCIsIFwibGVmdCFpbXBvcnRhbnRcIik7XHJcbiAgICAgICAgICAgIC8valF1ZXJ5KFwiLm1vZGFsLWZvb3RlciBidXR0b246YmVmb3JlXCIpLmNzcyhcImZsb2F0XCIsIFwibGVmdCFpbXBvcnRhbnRcIik7XHJcbiAgICAgICAgICAgIC8valF1ZXJ5KFwiLm1vZGFsLWZvb3RlciBidXR0b246YWZ0ZXJcIikuY3NzKFwiZmxvYXRcIiwgXCJsZWZ0IWltcG9ydGFudFwiKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuQ0hBTkdFRElSID0gXCJsdHJtb2RhbFwiO1xyXG4gICAgICAgICAgICB0aGlzLkNoYW5nZURpYWxvZyA9IFwiaW5wdXRfbGVmdFwiO1xyXG4gICAgICAgIH1cclxuXHJcblxyXG4gICAgICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLkdldExhbmdSZXModGhpcy5Gb3JtdHlwZSwgdGhpcy5MYW5nKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICB0aGlzLlJFUyA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgIHRoaXMuU2hvd01vcmVUZXh0ID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9MTktfTEJMX01PUkU7XHJcbiAgICAgICAgICAgICAgIHRoaXMuR3JvdXBUZXh0ID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9MQkxfU0hPV0dST1VQUztcclxuICAgICAgICAgICAgICAgdGhpcy5TQVZFX0JUTl9URVhUID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9CVE5fU0FWRTtcclxuICAgICAgICAgICAgICAgdGhpcy5BRERfTkVXX0NVU1RfVEVYVCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfTEJMX05FV19DVVNUO1xyXG4gICAgICAgICAgICAgICB0aGlzLkZJTEVBU19CVE5fVEVYVCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfQlROX0ZJTEVBUztcclxuICAgICAgICAgICAgICAgLy9hbGVydCh0aGlzLlJFUyk7XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgfSk7XHJcbiAgICAgICAvL3RoaXMuU2hvd01vcmVUZXh0ID0gXCJNb3JlXCI7XHJcbiAgICAgICBcclxuICAgICAgIC8vLy9DaXRpZXNcclxuICAgICAgIHZhciBDb3VudHJ5Q29kZSA9IHRoaXMuQWRkcmVzcy5Db3VudHJ5Q29kZTtcclxuICAgICAgIHZhciBTdGF0ZU5hbWUgPSB0aGlzLkFkZHJlc3MuU3RhdGVJZDtcclxuICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRDaXRpZXMoQ291bnRyeUNvZGUsIFN0YXRlTmFtZSkuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZywgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICB9XHJcbiAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgIHZhciB0eXBlYWhlYWRTb3VyY2UgPSBbXTtcclxuICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2gocmVzcG9uc2UuRGF0YSwgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgICAgdmFyIG5ld3RlbXAgPSB7fTtcclxuICAgICAgICAgICAgICAgICAgIG5ld3RlbXAuaWQgPSB0aGlzLlZhbHVlO1xyXG4gICAgICAgICAgICAgICAgICAgbmV3dGVtcC5uYW1lID0gdGhpcy5UZXh0O1xyXG4gICAgICAgICAgICAgICAgICAgdHlwZWFoZWFkU291cmNlLnB1c2gobmV3dGVtcCk7XHJcbiAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICB0aGlzLl9DaXRpZXMgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICBqUXVlcnkoJyNDaXR5JykudHlwZWFoZWFkKHtcclxuICAgICAgICAgICAgICAgICAgIC8vZGF0YTogdGhpcy5fQ2l0aWVzLFxyXG4gICAgICAgICAgICAgICAgICAgc291cmNlOiB0eXBlYWhlYWRTb3VyY2UsXHJcbiAgICAgICAgICAgICAgICAgICAvL2Rpc3BsYXk6IFwidGV4dFwiLFxyXG4gICAgICAgICAgICAgICAgICAgZGF0YVR5cGU6IFwiSlNPTlwiLFxyXG4gICAgICAgICAgICAgICAgICAgLy9oaW50OiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgLy9oaWdobGlnaHQ6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAvL21pbkxlbmd0aDogMSxcclxuICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgfSk7XHJcblxyXG4gICAgICAgXHJcbiAgICAgICBcclxuICAgICAgICAgIFxyXG5cclxuXHJcbiAgICAgICAgdGhpcy5sYW5ndWFnZUFycmF5ID0gdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLkdldEF2YWlsYWJsZUxhbmd1YWdlcygpO1xyXG4gICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRDdXN0b21lclR5cGVzKCkuc3Vic2NyaWJlKHJlc3A9PiB7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICB2YXIgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3ApO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fQ3VzdFR5cGVzID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJUeXBlID09IFwiXCIgfHwgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyVHlwZSA9PSB1bmRlZmluZWQgfHwgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyVHlwZSA9PSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIEN1c3R0eXBlSWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5fQ3VzdFR5cGVzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEN1c3R0eXBlSWQgPSB0aGlzLlZhbHVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyVHlwZSA9IEN1c3R0eXBlSWQ7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIFxyXG4gICAgICAgIC8vLy9Tb3VyY2VzXHJcbiAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkdldFNvdXJjZXMoKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX1NvdXJjZXMgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5DYW1lRnJvbUN1c3RvbWVyID09IFwiXCIgfHwgdGhpcy5tb2RlbElucHV0LkNhbWVGcm9tQ3VzdG9tZXIgPT0gdW5kZWZpbmVkIHx8IHRoaXMubW9kZWxJbnB1dC5DYW1lRnJvbUN1c3RvbWVyID09IG51bGwpIHtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgU291cmNlO1xyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMuX1NvdXJjZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgU291cmNlID0gdGhpcy5WYWx1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DYW1lRnJvbUN1c3RvbWVyID0gU291cmNlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICAvL0dldEVtcGxveWVlc1xyXG4gICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRFbXBsb3llZXMoKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZywgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9FbXBsb3llZXMgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5lbXBsb3llZWlkID09IFwiXCIgfHwgdGhpcy5tb2RlbElucHV0LmVtcGxveWVlaWQgPT0gdW5kZWZpbmVkIHx8IHRoaXMubW9kZWxJbnB1dC5lbXBsb3llZWlkID09IG51bGwpIHtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgZW1waWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5fRW1wbG95ZWVzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGVtcGlkID0gdGhpcy5WYWx1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5lbXBsb3llZWlkID0gZW1waWQ7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgLy9HZXRTdWZmaXhlc1xyXG4gICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRTdWZmaXhlcygpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX1N1ZmZpeGVzID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuICAgICAgICAvL0dldFBob25lVHlwZXNcclxuICAgICAgICB0aGlzLl9jdXN0b21lclNlcnZpY2UuR2V0UGhvbmVUeXBlcygpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX1Bob25lVHlwZXMgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgdmFyIHBoaWQgPSBcIlwiO1xyXG4gICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5fUGhvbmVUeXBlcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLlRleHQgPT0gXCJDZWxsUGhvbmVcIikge1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgcGhpZCA9IHRoaXMuVmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lc1swXS5QaG9uZVR5cGVJZCA9IHBoaWQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgfSk7XHJcblxyXG5cclxuICAgICAgICB2YXIgZXB1Ymxpc2ggPSAwO1xyXG4gICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXMubGVuZ3RoID09IDApIHtcclxuICAgICAgICAgICAgdmFyIHBoaWQgPSBcIlwiO1xyXG5cclxuICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5fUGhvbmVUeXBlcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuVGV4dCA9PSBcIkNlbGxQaG9uZVwiKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHBoaWQgPSB0aGlzLlZhbHVlO1xyXG4gICAgICAgICAgICAgICAgICAgIGVwdWJsaXNoID0gMTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzID0gW3sgUGhvbmVUeXBlSWQ6IHBoaWQsIFByZWZpeDogXCJcIiwgQXJlYTogXCJcIiwgUGhvbmU6IFwiXCIsIElzU21zOiBlcHVibGlzaCwgQ29tbWVudHM6IFwiXCIsIHBocHVibGlzaDogZXB1Ymxpc2gsIFNNU09yZGVyOiBcIlNNUzFcIiwgUHVibGlzaE9yZGVyOlwiUHViMVwiIH1dO1xyXG4gICAgICAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzLmxlbmd0aCA9PSAwKSB7XHJcbiAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlscyA9IFt7IEVtYWlsOiBcIlwiLCBFbWFpbE5hbWU6IHRoaXMubW9kZWxJbnB1dC5GaWxlQXMsIE5ld3NsZXR0ZXJlOiBmYWxzZSwgcHVibGlzaDogZXB1Ymxpc2gsIE5ld3NPcmRlcjogXCJOZXdzMVwiLCBFUHVibGlzaE9yZGVyOlwiRVB1YjFcIiB9XVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy9HZXRBZGRyZXNzVHlwZXNcclxuICAgICAgICB0aGlzLl9jdXN0b21lclNlcnZpY2UuR2V0QWRkcmVzc1R5cGVzKCkuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fQWRkcmVzc1R5cGVzID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICB2YXIgYWRpZCA9IFwiXCI7XHJcbiAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLl9BZGRyZXNzVHlwZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5UZXh0ID09IFwiSG9tZVwiKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhZGlkID0gdGhpcy5WYWx1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3Nlc1swXS5BZGRyZXNzVHlwZUlkID0gYWRpZDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuICAgICAgICAvL0dyb3Vwc1xyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRHcm91cHMoKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZywgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9Hcm91cHMgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIC8vLy9Db3VudHJpZXNcclxuICAgICAgICBcclxuICAgICAgICB0aGlzLl9jdXN0b21lclNlcnZpY2UuR2V0Q291bnRyaWVzKCkuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fQ291bnRyaWVzID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuICAgICAgICAvLy8vU3RhdGVzXHJcbiAgICAgICAgdmFyIENvdW50cnlDb2RlPSB0aGlzLkFkZHJlc3MuQ291bnRyeUNvZGU7XHJcbiAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkdldFN0YXRlcyhDb3VudHJ5Q29kZSkuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fU3RhdGVzID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuICAgICAgICBcclxuICAgICAgICBcclxuICAgICAgICAvL1RyZWUgR3JvdXBcclxuXHJcbiAgICAgICAgLy90aGlzLmJpbmRHcm91cFRyZWUodGhpcy5Jc1Nob3dBbGwpO1xyXG4gICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRHZW5lcmFsR3JvdXBzKHRoaXMuSXNTaG93QWxsKS5zdWJzY3JpYmUoXHJcbiAgICAgICAgICAgIChkYXRhKSA9PiB7XHJcbiAgICAgICAgICAgICAgIC8vIGRlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuSXNTaG93QWxsID09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5KFwiI2dyb3VwVHJlZVwiKS5odG1sKFwiTG9kaW5nLi4uXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciByZXMgPSBqUXVlcnkucGFyc2VKU09OKGRhdGEpLkRhdGFcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkoXCIjZ3JvdXBUcmVlXCIpLmtlbmRvVHJlZVZpZXcoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsb2FkT25EZW1hbmQ6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrYm94ZXM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrQ2hpbGRyZW46IHRydWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9jaGVjazogdGhpcy5vbkdyb3VwU2VsZWN0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkYXRhU291cmNlOiByZXNcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIGdycGlkcyA9IFwiXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5tb2RlbElucHV0LkN1c3RvbWVyR3JvdXBzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGdycGlkcyArPSB0aGlzLkN1c3RvbWVyR2VuZXJhbEdyb3VwSWQgKyBcIjtcIjtcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoZ3JwaWRzLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgS2VuZG9fdXRpbGl0eS5jaGVja2luZ05vZGVJZHMoalF1ZXJ5KFwiI2dyb3VwVHJlZVwiKS5kYXRhKFwia2VuZG9UcmVlVmlld1wiKS5kYXRhU291cmNlLnZpZXcoKSwgZ3JwaWRzLnN1YnN0cmluZygwLCBncnBpZHMubGVuZ3RoIC0gMSkpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5KFwiI2dyb3VwVHJlZTFcIikuaHRtbChcIkxvZGluZy4uLlwiKTtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgcmVzID0galF1ZXJ5LnBhcnNlSlNPTihkYXRhKS5EYXRhXHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5KFwiI2dyb3VwVHJlZTFcIikua2VuZG9UcmVlVmlldyh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRPbkRlbWFuZDogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tib3hlczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tDaGlsZHJlbjogdHJ1ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2NoZWNrOiB0aGlzLm9uR3JvdXBTZWxlY3QsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhdGFTb3VyY2U6IHJlc1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBncnBpZHMgPSBcIlwiO1xyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckdyb3VwcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBncnBpZHMgKz0gdGhpcy5DdXN0b21lckdlbmVyYWxHcm91cElkICsgXCI7XCI7XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGdycGlkcy5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEtlbmRvX3V0aWxpdHkuY2hlY2tpbmdOb2RlSWRzKGpRdWVyeShcIiNncm91cFRyZWUxXCIpLmRhdGEoXCJrZW5kb1RyZWVWaWV3XCIpLmRhdGFTb3VyY2UudmlldygpLCBncnBpZHMuc3Vic3RyaW5nKDAsIGdycGlkcy5sZW5ndGggLSAxKSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIChlcnIpID0+IHtcclxuXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICgpID0+IHtcclxuXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICApO1xyXG4gICAgICAgIFxyXG4gICAgICAgIC8vYWxlcnQobW9tZW50KCkuZm9ybWF0KCdEIE1NTSBZWVlZJykpOyAgICAgICBcclxuICAgICAgIC8vIHRoaXMuYmFzZVVybCArIFwiRHJvcGRvd24vQmluZEF1dG9Db21wbGV0ZVNyY2hcIlxyXG4gICAgICAgIHZhciBTcmNoRGF0YSA9IG51bGw7XHJcbiAgICAgICAgICAgXHJcbiAgICAgICAgLy9hbGVydCgnSGknKTtcclxuICAgICAgICBqUXVlcnkoXCIjRW1haWxUYWJsZSB0Ym9keSB0ciB0ZCBhW25hbWU9ZGVsRWJ0bl1cIikubm90KFwiOmxhc3RcIikuaGlkZSgpO1xyXG4gICAgICAgIGpRdWVyeShcIiNFbWFpbFRhYmxlIHRib2R5IHRyIGFbbmFtZT1hZGRFYnRuXVwiKS5ub3QoXCI6bGFzdFwiKS5zaG93KCk7XHJcbiAgICAgICAgLy8kKCcubW9kYWwnKS5tb2RhbCgpO1xyXG4gICAgICAgIFxyXG4gICAgfVxyXG59XHJcbiJdfQ==
