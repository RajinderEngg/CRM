System.register(["angular2/core", 'angular2/common', "../../services/ResourceService", "angular2/router", "../../services/RecieptService", "../../services/CustomerService", '../../comonComponents/basicComponents', "../../services/ChargeCreditService"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, common_1, ResourceService_1, router_1, RecieptService_1, CustomerService_1, basicComponents_1, ChargeCreditService_1;
    var AmaxReceiptCreate;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (ResourceService_1_1) {
                ResourceService_1 = ResourceService_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (RecieptService_1_1) {
                RecieptService_1 = RecieptService_1_1;
            },
            function (CustomerService_1_1) {
                CustomerService_1 = CustomerService_1_1;
            },
            function (basicComponents_1_1) {
                basicComponents_1 = basicComponents_1_1;
            },
            function (ChargeCreditService_1_1) {
                ChargeCreditService_1 = ChargeCreditService_1_1;
            }],
        execute: function() {
            AmaxReceiptCreate = (function () {
                // @ViewChild('RTLDiv') private myScrollContainer: ElementRef;
                function AmaxReceiptCreate(_resourceService, _RecieptService, _CustomerService, _routeParams, _ChargeCreditService) {
                    this._resourceService = _resourceService;
                    this._RecieptService = _RecieptService;
                    this._CustomerService = _CustomerService;
                    this._routeParams = _routeParams;
                    this._ChargeCreditService = _ChargeCreditService;
                    this.RES = {};
                    this.Formtype = "SCREEN_RECEIPTCREATE";
                    this.Lang = "";
                    this._Banks = [];
                    this._CustomerNotes = [];
                    this._Addresses = [];
                    this._PayTypes = [];
                    this._Accounts = [];
                    this._Goals = [];
                    this._ProjectCats = [];
                    this._Projects = [];
                    this._Currencies = [];
                    this.ModelData = [];
                    this._ThankLetters = [];
                    this.RowCount = 0;
                    this.Isbtndisable = "";
                    this.SAVE_BTN_TEXT = "Save";
                    this.MsgClass = "text-primary";
                    this.modelInput = {};
                    this.saveInput = {};
                    this.ChangeDialog = "";
                    this.CHANGEDIR = "";
                    this.ShowMoreText = "";
                    this.ShowMore = false;
                    this.IsBankDetShow = false;
                    this.RES.SCREEN_RECEIPTCREATE = {};
                    this.modelInput = {};
                    this.modelInput.AddModel = {};
                    this.IsBankDetShow = false;
                    this.modelInput.ReceiptTypeId = _routeParams.params.ReceiptTypeId;
                    //this.baseUrl = "http://localhost:3000/#/";
                    // debugger;
                    // alert(this.modelInput.ReceiptTypeId);
                    this.baseUrl = _resourceService.AppUrl;
                    this.modelInput.CustomerId = _routeParams.params.Id;
                    this.modelInput.CustomerName = "";
                    this.modelInput.AddModel.ReferenceDate = "";
                    this.ShowMoreText = "More";
                    this.modelInput.AddModel.ValueDate = moment(new Date()).format('DD-MM-YYYY');
                }
                AmaxReceiptCreate.prototype.dateVSelectionChange = function (evt) {
                    console.log(evt);
                    this.modelInput.AddModel.ValueDate = evt;
                    // alert(this.modelInput.BirthDate);
                    //this.validateLogin();
                };
                AmaxReceiptCreate.prototype.dateSelectionChange = function (evt) {
                    console.log(evt);
                    this.modelInput.AddModel.ReferenceDate = evt;
                    // alert(this.modelInput.BirthDate);
                    //this.validateLogin();
                };
                AmaxReceiptCreate.prototype.More = function () {
                    // alert("call");
                    if (this.ShowMore == true) {
                        this.ShowMore = false;
                        this.ShowMoreText = "More";
                    }
                    else {
                        this.ShowMore = true;
                        this.ShowMoreText = "Less";
                    }
                };
                AmaxReceiptCreate.prototype.BankDetailShow = function () {
                    //alert('Hello');
                    //debugger;
                    this.modelInput.AddModel.PayTypeId = jQuery("#PayType").val();
                    var PayType = this.modelInput.AddModel.PayTypeId;
                    var PayTypeId = "";
                    jQuery.each(this._PayTypes, function () {
                        if ((this.Value + " - " + this.Text) == PayType) {
                            PayTypeId = this.Value + " - " + this.Text;
                            return false;
                        }
                    });
                    if (PayTypeId != "") {
                        var PTI = PayTypeId.toString().split('-');
                        var PT = "";
                        for (var i = 1; i < PTI.length; i++) {
                            PT += PTI[i] + "-";
                            if (PT.length > 0)
                                PT = PT.substring(0, PT.length - 1);
                            if (PT.toLowerCase().trim() != "cash" && PT.toLowerCase().trim() != "מזומן") {
                                this.IsBankDetShow = true;
                            }
                            else {
                                this.IsBankDetShow = false;
                            }
                        }
                    }
                };
                AmaxReceiptCreate.prototype.saveReceiptData = function (IsExit) {
                    var _this = this;
                    var EmpName = jQuery("#EmpId").val();
                    this._RecieptService.GetEmployeeFromEmpName(EmpName).subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.modelInput.EmployeeId = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    if (this.modelInput.CustomerId != null && this.modelInput.CustomerId != "" && this.modelInput.CustomerId != undefined
                        && this.modelInput.CurrencyId != null && this.modelInput.CurrencyId != "" && this.modelInput.CurrencyId != undefined
                        && this.ModelData.length > 0
                        && this.modelInput.associationId != null && this.modelInput.associationId != "" && this.modelInput.associationId != undefined
                        && this.modelInput.EmployeeId != null && this.modelInput.EmployeeId != "-1" && this.modelInput.EmployeeId != undefined
                        && this.modelInput.ThanksLetterId != null && this.modelInput.ThanksLetterId != "" && this.modelInput.ThanksLetterId != undefined
                        && this.modelInput.PrinterId != null && this.modelInput.PrinterId != "" && this.modelInput.PrinterId != undefined
                        && this.modelInput.RecieptNo != null && this.modelInput.RecieptNo != "" && this.modelInput.RecieptNo != undefined) {
                        this.saveInput.CurrencyId = this.modelInput.CurrencyId;
                        this.saveInput.RecieptType = this.modelInput.ReceiptTypeId;
                        this.saveInput.RecieptNo = this.modelInput.RecieptNo;
                        this.saveInput.RecieptDate = this.modelInput.RecieptDate;
                        this.saveInput.CustomerId = this.modelInput.CustomerId;
                        this.saveInput.CustomerName = this.modelInput.CustomerName;
                        this.saveInput.AddressId = this.modelInput.AddressId;
                        this.saveInput.CustomerNote = this.modelInput.CustomerNote;
                        this.saveInput.FreeLine = this.modelInput.FreeLine;
                        this.saveInput.associationId = this.modelInput.associationId;
                        this.saveInput.EmployeeId = this.modelInput.EmployeeId;
                        this.saveInput.ThanksLetterId = this.modelInput.ThanksLetterId;
                        this.saveInput.PaymentRequest = this.modelInput.PaymentRequest;
                        this.saveInput.Total = this.modelInput.Total;
                        this.saveInput.TotalInLeadCurrent = this.modelInput.TotalInLeadCurrent;
                        this.saveInput.TotalInWords = this.modelInput.TotalInWords;
                        this.saveInput.PrinterId = this.modelInput.PrinterId;
                        this.saveInput.ReceiptLines = [];
                        this.saveInput.ReceiptLines = this.ModelData;
                        var LineCount = 0;
                        jQuery.each(this.saveInput.ReceiptLines, function () {
                            this.RecieptRoWID = LineCount++;
                        });
                        var jdata = JSON.stringify(this.saveInput);
                        this._RecieptService.AddReceipt(jdata).subscribe(function (response) {
                            console.log(response);
                            response = jQuery.parseJSON(response);
                            _this.Isbtndisable = "";
                            //this.ShowLoader = false;
                            if (response.IsError == true) {
                                //alert(response.ErrMsg);
                                _this.MsgClass = "text-danger";
                            }
                            else {
                                //alert(response.ErrMsg);
                                //this._CustTypes = response.Data;
                                bootbox.alert({
                                    message: response.ErrMsg,
                                    className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        }
                                    }
                                });
                                //debugger;
                                if (IsExit == true) {
                                    document.location = _this.baseUrl + "ReceiptSelect/" + _this.modelInput.EmployeeId + " /" + _this.modelInput.CustomerId;
                                }
                                else {
                                    //document.location = this.baseUrl + "ReceiptCreate/" + this.modelInput.CustomerId + " /" + this.modelInput.ReceiptId;
                                    _this.RowCount = 0;
                                    window.scrollTo(0, 0);
                                    var PrevReceiptType = _this.modelInput.RecieptType;
                                    _this.modelInput = {};
                                    _this.modelInput.AddModel = {};
                                    _this.saveInput = {};
                                    _this.saveInput.ReceiptLines = [];
                                    _this.ModelData = [];
                                    //this.modelInput.RecieptType = PrevReceiptType;
                                    _this._RecieptService.GetRecieptType(_this._routeParams.params.ReceiptTypeId).subscribe(function (resp) {
                                        // debugger;
                                        var response = jQuery.parseJSON(resp);
                                        if (response.IsError == true) {
                                            bootbox.alert({
                                                message: response.ErrMsg,
                                                className: _this.ChangeDialog,
                                                buttons: {
                                                    ok: {
                                                        //label: 'Ok',
                                                        className: _this.CHANGEDIR
                                                    }
                                                }
                                            });
                                        }
                                        else {
                                            _this.modelInput.RecieptType = response.Data[0].RecieptNameEng;
                                            _this.modelInput.CurrencyId = response.Data[0].CurrencyId;
                                        }
                                    }, function (error) {
                                        console.log(error);
                                    }, function () {
                                        console.log("CallCompleted");
                                    });
                                    var PayTypeDefault;
                                    jQuery.each(_this._PayTypes, function () {
                                        if (this.Text.toLowerCase() == "cash" || this.Text == "מזומן") {
                                            PayTypeDefault = this.Value + " - " + this.Text;
                                            this.IsBankDetShow = false;
                                            return false;
                                        }
                                    });
                                    _this.modelInput.AddModel.PayTypeId = PayTypeDefault;
                                    _this.IsBankDetShow = false;
                                    _this._RecieptService.GetEmployee().subscribe(function (resp) {
                                        //debugger;
                                        var response = jQuery.parseJSON(resp);
                                        if (response.IsError == true) {
                                            bootbox.alert({
                                                message: response.ErrMsg,
                                                className: _this.ChangeDialog,
                                                buttons: {
                                                    ok: {
                                                        //label: 'Ok',
                                                        className: _this.CHANGEDIR
                                                    }
                                                }
                                            });
                                        }
                                        else {
                                            //debugger;
                                            _this.modelInput.EmployeeId = response.Data[0].Value;
                                            _this.modelInput.EmployeeName = response.Data[0].Text;
                                        }
                                    }, function (error) {
                                        console.log(error);
                                    }, function () {
                                        console.log("CallCompleted");
                                    });
                                    _this._RecieptService.GetReceiptDetail().subscribe(function (resp) {
                                        // debugger;
                                        var response = jQuery.parseJSON(resp);
                                        if (response.IsError == true) {
                                            bootbox.alert({
                                                message: response.ErrMsg,
                                                className: _this.ChangeDialog,
                                                buttons: {
                                                    ok: {
                                                        //label: 'Ok',
                                                        className: _this.CHANGEDIR
                                                    }
                                                }
                                            });
                                        }
                                        else {
                                            _this.modelInput.RecieptNo = response.Data.Value;
                                            _this.modelInput.RecieptDate = response.Data.Text;
                                        }
                                    }, function (error) {
                                        console.log(error);
                                    }, function () {
                                        console.log("CallCompleted");
                                    });
                                }
                            }
                        }, function (error) { return console.log(error); }, function () { return console.log("Save Call Compleated"); });
                    }
                    else {
                        var msg = "";
                        if (this.modelInput.CustomerId == null || this.modelInput.CustomerId == "" || this.modelInput.CustomerId == undefined) {
                            msg += "<br>Please enter customerid";
                        }
                        if (this.modelInput.CurrencyId == null || this.modelInput.CurrencyId == "" || this.modelInput.CurrencyId == undefined) {
                            msg += "<br>Please select currency";
                        }
                        if (this.modelInput.associationId == null || this.modelInput.associationId == "" || this.modelInput.associationId == undefined) {
                            msg += "<br>Please enter Deposited By";
                        }
                        if (this.modelInput.EmployeeId == null || this.modelInput.EmployeeId == "" || this.modelInput.EmployeeId == undefined) {
                            msg += "<br>Please enter valid employee";
                        }
                        if (this.modelInput.ThanksLetterId == null || this.modelInput.ThanksLetterId == "" || this.modelInput.ThanksLetterId == undefined) {
                            msg += "<br>Please select print template";
                        }
                        if (this.modelInput.PrinterId == null || this.modelInput.PrinterId == "" || this.modelInput.PrinterId == undefined) {
                            msg += "<br>Please set printer name in database";
                        }
                        if (this.modelInput.RecieptNo == null || this.modelInput.RecieptNo == "" || this.modelInput.RecieptNo == undefined) {
                            msg += "<br>Receipt no is not set";
                        }
                        if (this.ModelData.length == 0) {
                            msg += "<br>Please atleast one amount detail in grid";
                        }
                        bootbox.alert({
                            message: msg,
                            className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                    }
                };
                AmaxReceiptCreate.prototype.delModel = function (ModelObj) {
                    //debugger;
                    if (this.ModelData.length > 1) {
                        var index = 0;
                        jQuery.each(this.ModelData, function () {
                            if (this == ModelObj) {
                                return false;
                            }
                            index = index + 1;
                        });
                        this.ModelData.splice(index, 1);
                    }
                };
                AmaxReceiptCreate.prototype.DupModel = function (ModelObj) {
                    var MObj = {};
                    this.RowCount++;
                    ModelObj.RecieptRoWID = this.RowCount;
                    MObj = ModelObj;
                    this.ModelData.push(MObj);
                };
                AmaxReceiptCreate.prototype.AddModel = function () {
                    this.modelInput.AddModel.Bank = jQuery("#Bank").val();
                    if (this.modelInput.AddModel.Amount != null && this.modelInput.AddModel.Amount != "" && this.modelInput.AddModel.Amount != undefined
                        && this.modelInput.AddModel.PayTypeId != null && this.modelInput.AddModel.PayTypeId != "" && this.modelInput.AddModel.PayTypeId != undefined
                        && this.modelInput.AddModel.ProjectId != null && this.modelInput.AddModel.ProjectId != "" && this.modelInput.AddModel.ProjectId != undefined
                        && this.modelInput.AddModel.DonationTypeId != null && this.modelInput.AddModel.DonationTypeId != "" && this.modelInput.AddModel.DonationTypeId != undefined
                        && this.modelInput.AddModel.AccountId != null && this.modelInput.AddModel.AccountId != "" && this.modelInput.AddModel.AccountId != undefined) {
                        var PayType = this.modelInput.AddModel.PayTypeId.toString().split('-');
                        this.modelInput.AddModel.PayTypeId = PayType[0];
                        var PaytypeName = "";
                        for (var i = 1; i < PayType.length; i++) {
                            PaytypeName += PayType[i] + "-";
                        }
                        debugger;
                        this.AddModel.BankId = "0";
                        this.AddModel.DepositeRemark = jQuery("#Remarks").val();
                        this.RowCount++;
                        //alert(this.RowCount.toString());
                        this.modelInput.AddModel.RecieptRoWID = this.RowCount;
                        this.modelInput.AddModel.PayType = PaytypeName.substring(0, PaytypeName.length - 1);
                        var DonationType = this.modelInput.AddModel.DonationTypeId.toString().split('-');
                        this.modelInput.AddModel.DonationTypeId = DonationType[0].trim();
                        var DonationName = "";
                        for (var i = 1; i < DonationType.length; i++) {
                            DonationName += DonationType[i] + "-";
                        }
                        this.modelInput.AddModel.DonationType = DonationName.substring(0, DonationName.length - 1);
                        var Project = this.modelInput.AddModel.ProjectId.toString().split('-');
                        this.modelInput.AddModel.ProjectId = Project[0].trim();
                        var ProjectName = "";
                        for (var i = 1; i < Project.length; i++) {
                            ProjectName += Project[i] + "-";
                        }
                        this.modelInput.AddModel.Project = ProjectName.substring(0, ProjectName.length - 1);
                        var ProjectCategory = this.modelInput.AddModel.ProjectCategoryId.toString().split('-');
                        this.modelInput.AddModel.ProjectCategoryId = ProjectCategory[0].trim();
                        var ProjectCategoryName = "";
                        for (var i = 1; i < ProjectCategory.length; i++) {
                            ProjectCategoryName += ProjectCategory[i] + "-";
                        }
                        this.modelInput.AddModel.ProjectCategory = ProjectCategoryName.substring(0, ProjectCategoryName.length - 1);
                        var Account = this.modelInput.AddModel.AccountId.toString().split('-');
                        this.modelInput.AddModel.AccountId = Account[0].trim();
                        var AccountName = "";
                        for (var i = 1; i < Account.length; i++) {
                            AccountName += Account[i] + "-";
                        }
                        this.modelInput.AddModel.Account = AccountName.substring(0, AccountName.length - 1);
                        this.ModelData.push(this.modelInput.AddModel);
                        this.modelInput.AddModel = {};
                        debugger;
                        var PayTypeDefault;
                        jQuery.each(this._PayTypes, function () {
                            if (this.Text.toLowerCase() == "cash" || this.Text == "מזומן") {
                                PayTypeDefault = this.Value + " - " + this.Text;
                                this.IsBankDetShow = false;
                                return false;
                            }
                            else {
                                this.IsBankDetShow = true;
                            }
                        });
                        this.modelInput.AddModel.PayTypeId = PayTypeDefault;
                        this.IsBankDetShow = false;
                    }
                    else {
                        var msg = "";
                        if (this.modelInput.AddModel.Amount == null || this.modelInput.AddModel.Amount == "" || this.modelInput.AddModel.Amount == undefined) {
                            msg += "<br>Please enter amount";
                        }
                        if (this.modelInput.AddModel.PayTypeId == null || this.modelInput.AddModel.PayTypeId == "" || this.modelInput.AddModel.PayTypeId == undefined) {
                            msg += "<br>Please select paytype";
                        }
                        if (this.modelInput.AddModel.ProjectId == null || this.modelInput.AddModel.ProjectId == "" || this.modelInput.AddModel.ProjectId == undefined) {
                            msg += "<br>Please select project";
                        }
                        if (this.modelInput.AddModel.DonationTypeId == null || this.modelInput.AddModel.DonationTypeId == "" || this.modelInput.AddModel.DonationTypeId == undefined) {
                            msg += "<br>Please select goal";
                        }
                        if (this.modelInput.AddModel.AccountId == null || this.modelInput.AddModel.AccountId == "" || this.modelInput.AddModel.AccountId == undefined) {
                            msg += "<br>Please select account";
                        }
                        if (this.modelInput.AddModel.BankId == null || this.modelInput.AddModel.BankId == "" || this.modelInput.AddModel.BankId == undefined) {
                            msg += "<br>Please select bank";
                        }
                        //if (this.modelInput.AddModel.Goal == null || this.modelInput.AddModel.Goal == "" || this.modelInput.AddModel.Goal == undefined) {
                        //}
                        bootbox.alert({
                            message: msg,
                            className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                    }
                };
                AmaxReceiptCreate.prototype.OpenNotes = function () {
                    jQuery('#NoteModal').openModal();
                };
                AmaxReceiptCreate.prototype.OpenTemplates = function () {
                    jQuery('#TemplateModal').openModal();
                };
                AmaxReceiptCreate.prototype.ChooseNote = function (objct) {
                    this.modelInput.CustomerNote = objct.Text;
                    this.modelInput.CustomerNoteId = objct.Value;
                };
                AmaxReceiptCreate.prototype.ChooseThanksLetters = function (objct) {
                    this.modelInput.ThanksLetterName = objct.Text;
                    this.modelInput.ThanksLetterId = objct.Value;
                };
                AmaxReceiptCreate.prototype.GetCustomerDetail = function () {
                    var _this = this;
                    var CustId = this.modelInput.CustomerId;
                    this._CustomerService.GetCompleteCustDet(CustId).subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            response = response.Data;
                            _this._Addresses = response.CustomerAddresses;
                            var Mainaddress;
                            jQuery.each(response.CustomerAddresses, function () {
                                if (this.MainAddress == true) {
                                    Mainaddress = this.AddressId;
                                }
                            });
                            _this.modelInput.AddressId = Mainaddress;
                            _this.modelInput.CustomerId = response.CustomerId;
                            _this.modelInput.CustomerName = response.lname + " " + response.fname;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxReceiptCreate.prototype.BindProjects = function () {
                    var CatDet = jQuery("#ProjectCategory").val();
                    var CatIds = CatDet.split('-');
                    var CatId = CatIds[0].trim();
                    this.BindProjectFromProjCat(CatId);
                };
                AmaxReceiptCreate.prototype.BindProjectFromProjCat = function (CatId) {
                    var _this = this;
                    this._RecieptService.GetProjects(CatId).subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Projects = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxReceiptCreate.prototype.ngOnInit = function () {
                    var _this = this;
                    window.scrollTo(0, 0);
                    //  alert("ddd");
                    this.Lang = localStorage.getItem("lang");
                    this._resourceService.GetLangRes(this.Formtype, this.Lang).subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.RES = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._RecieptService.GetCustomerNotes().subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._CustomerNotes = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._RecieptService.GetBanks().subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            //this._Banks = response.Data;
                            var typeaheadSource = [];
                            jQuery.each(response.Data, function () {
                                var newtemp = {};
                                newtemp.id = this.Value;
                                newtemp.name = this.Text;
                                typeaheadSource.push(newtemp);
                            });
                            _this._Banks = response.Data;
                            jQuery('#Bank').typeahead({
                                //data: this._Cities,
                                source: typeaheadSource,
                                //display: "text",
                                dataType: "JSON",
                            });
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._RecieptService.GetThanksLetters(this.modelInput.ReceiptTypeId).subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._ThankLetters = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._RecieptService.GetAssociation().subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            //debugger;
                            _this.modelInput.associationId = response.Data[0].Value;
                            _this.modelInput.associationName = response.Data[0].Text;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._RecieptService.GetPrinter().subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            //debugger;
                            _this.modelInput.PrinterId = response.Data[0].Value;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._RecieptService.GetEmployee().subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            //debugger;
                            _this.modelInput.EmployeeId = response.Data[0].Value;
                            _this.modelInput.EmployeeName = response.Data[0].Text;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._RecieptService.GetPayType().subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._PayTypes = response.Data;
                            var PayTypeDefault;
                            jQuery.each(_this._PayTypes, function () {
                                if (this.Text.toLowerCase() == "cash" || this.Text == "מזומן") {
                                    PayTypeDefault = this.Value + " - " + this.Text;
                                    this.IsBankDetShow = false;
                                    return false;
                                }
                                else {
                                    this.IsBankDetShow = true;
                                }
                            });
                            _this.modelInput.AddModel.PayTypeId = PayTypeDefault;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._RecieptService.GetAccounts().subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Accounts = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._RecieptService.GetGoals().subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Goals = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._RecieptService.GetProjectCats().subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._ProjectCats = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this.BindProjectFromProjCat(-1);
                    this._RecieptService.GetCurrenciesFDB().subscribe(function (resp) {
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Currencies = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._RecieptService.GetRecieptType(this._routeParams.params.ReceiptTypeId).subscribe(function (resp) {
                        // debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.modelInput.RecieptType = response.Data[0].RecieptNameEng;
                            _this.modelInput.CurrencyId = response.Data[0].CurrencyId;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._RecieptService.GetReceiptDetail().subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.modelInput.RecieptNo = response.Data.Value;
                            _this.modelInput.RecieptDate = response.Data.Text;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    var CustId = this.modelInput.CustomerId;
                    this.GetCustomerDetail(CustId);
                };
                AmaxReceiptCreate.$inject = ['$scope', '$location', '$anchorScroll'];
                AmaxReceiptCreate = __decorate([
                    core_1.Component({
                        templateUrl: './app/amax/Receipt/templates/ReceiptCreate.html',
                        directives: [common_1.NgSwitch, common_1.NgSwitchWhen, common_1.NgSwitchDefault, basicComponents_1.AmaxDate],
                        providers: [RecieptService_1.RecieptService, ResourceService_1.ResourceService, CustomerService_1.CustomerService, ChargeCreditService_1.ChargeCreditService]
                    }), 
                    __metadata('design:paramtypes', [ResourceService_1.ResourceService, RecieptService_1.RecieptService, CustomerService_1.CustomerService, router_1.RouteParams, ChargeCreditService_1.ChargeCreditService])
                ], AmaxReceiptCreate);
                return AmaxReceiptCreate;
            }());
            exports_1("AmaxReceiptCreate", AmaxReceiptCreate);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldi9hbWF4L1JlY2VpcHQvUmVjZWlwdENyZWF0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztZQW1CQTtnQkE0QkcsOERBQThEO2dCQUM3RCwyQkFBb0IsZ0JBQWlDLEVBQVUsZUFBK0IsRUFBVSxnQkFBaUMsRUFBVSxZQUF5QixFQUFVLG9CQUF5QztvQkFBM00scUJBQWdCLEdBQWhCLGdCQUFnQixDQUFpQjtvQkFBVSxvQkFBZSxHQUFmLGVBQWUsQ0FBZ0I7b0JBQVUscUJBQWdCLEdBQWhCLGdCQUFnQixDQUFpQjtvQkFBVSxpQkFBWSxHQUFaLFlBQVksQ0FBYTtvQkFBVSx5QkFBb0IsR0FBcEIsb0JBQW9CLENBQXFCO29CQTNCL04sUUFBRyxHQUFXLEVBQUUsQ0FBQztvQkFDakIsYUFBUSxHQUFXLHNCQUFzQixDQUFDO29CQUMxQyxTQUFJLEdBQVcsRUFBRSxDQUFDO29CQUNsQixXQUFNLEdBQUcsRUFBRSxDQUFDO29CQUNaLG1CQUFjLEdBQUcsRUFBRSxDQUFDO29CQUNwQixlQUFVLEdBQUcsRUFBRSxDQUFDO29CQUNoQixjQUFTLEdBQUcsRUFBRSxDQUFDO29CQUNmLGNBQVMsR0FBRyxFQUFFLENBQUM7b0JBQ2YsV0FBTSxHQUFHLEVBQUUsQ0FBQztvQkFDWixpQkFBWSxHQUFHLEVBQUUsQ0FBQztvQkFDbEIsY0FBUyxHQUFHLEVBQUUsQ0FBQztvQkFDZixnQkFBVyxHQUFHLEVBQUUsQ0FBQztvQkFDakIsY0FBUyxHQUFHLEVBQUUsQ0FBQztvQkFDZixrQkFBYSxHQUFHLEVBQUUsQ0FBQztvQkFDbkIsYUFBUSxHQUFVLENBQUMsQ0FBQztvQkFDcEIsaUJBQVksR0FBVyxFQUFFLENBQUM7b0JBQzFCLGtCQUFhLEdBQVMsTUFBTSxDQUFDO29CQUM3QixhQUFRLEdBQVcsY0FBYyxDQUFDO29CQUNsQyxlQUFVLEdBQVcsRUFBRSxDQUFDO29CQUN4QixjQUFTLEdBQVcsRUFBRSxDQUFDO29CQUN2QixpQkFBWSxHQUFXLEVBQUUsQ0FBQztvQkFDMUIsY0FBUyxHQUFXLEVBQUUsQ0FBQztvQkFDdkIsaUJBQVksR0FBVyxFQUFFLENBQUM7b0JBQzFCLGFBQVEsR0FBWSxLQUFLLENBQUM7b0JBQzFCLGtCQUFhLEdBQVksS0FBSyxDQUFDO29CQUszQixJQUFJLENBQUMsR0FBRyxDQUFDLG9CQUFvQixHQUFHLEVBQUUsQ0FBQztvQkFDbkMsSUFBSSxDQUFDLFVBQVUsR0FBRyxFQUFFLENBQUM7b0JBQ3JCLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQztvQkFDOUIsSUFBSSxDQUFDLGFBQWEsR0FBRyxLQUFLLENBQUM7b0JBQzNCLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxHQUFHLFlBQVksQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDO29CQUNsRSw0Q0FBNEM7b0JBQzlDLFlBQVk7b0JBQ1gsd0NBQXdDO29CQUN2QyxJQUFJLENBQUMsT0FBTyxHQUFHLGdCQUFnQixDQUFDLE1BQU0sQ0FBQztvQkFDdkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsWUFBWSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7b0JBQ3BELElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxHQUFHLEVBQUUsQ0FBQztvQkFDbEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsYUFBYSxHQUFHLEVBQUUsQ0FBQztvQkFDNUMsSUFBSSxDQUFDLFlBQVksR0FBRyxNQUFNLENBQUM7b0JBQzNCLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLFNBQVMsR0FBQyxNQUFNLENBQUMsSUFBSSxJQUFJLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQztnQkFDL0UsQ0FBQztnQkFDRCxnREFBb0IsR0FBcEIsVUFBcUIsR0FBRztvQkFDcEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztvQkFDakIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsU0FBUyxHQUFHLEdBQUcsQ0FBQztvQkFDekMsb0NBQW9DO29CQUNwQyx1QkFBdUI7Z0JBQzNCLENBQUM7Z0JBR0QsK0NBQW1CLEdBQW5CLFVBQW9CLEdBQUc7b0JBQ25CLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7b0JBQ2pCLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLGFBQWEsR0FBRyxHQUFHLENBQUM7b0JBQzdDLG9DQUFvQztvQkFDcEMsdUJBQXVCO2dCQUMzQixDQUFDO2dCQUVELGdDQUFJLEdBQUo7b0JBQ0ksaUJBQWlCO29CQUNqQixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7d0JBQ3hCLElBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO3dCQUV0QixJQUFJLENBQUMsWUFBWSxHQUFHLE1BQU0sQ0FBQztvQkFFL0IsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQzt3QkFDckIsSUFBSSxDQUFDLFlBQVksR0FBRyxNQUFNLENBQUM7b0JBRS9CLENBQUM7Z0JBQ0wsQ0FBQztnQkFDRCwwQ0FBYyxHQUFkO29CQUNJLGlCQUFpQjtvQkFDakIsV0FBVztvQkFDWCxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxTQUFTLEdBQUcsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDO29CQUM5RCxJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUM7b0JBQ2pELElBQUksU0FBUyxHQUFHLEVBQUUsQ0FBQztvQkFDbkIsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFO3dCQUN4QixFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLEdBQUMsS0FBSyxHQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxPQUFPLENBQUMsQ0FBQyxDQUFDOzRCQUMxQyxTQUFTLEdBQUcsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQzs0QkFDM0MsTUFBTSxDQUFDLEtBQUssQ0FBQTt3QkFDaEIsQ0FBQztvQkFFTCxDQUFDLENBQUMsQ0FBQztvQkFDSCxFQUFFLENBQUMsQ0FBQyxTQUFTLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzt3QkFDbEIsSUFBSSxHQUFHLEdBQUcsU0FBUyxDQUFDLFFBQVEsRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQzt3QkFDMUMsSUFBSSxFQUFFLEdBQUcsRUFBRSxDQUFDO3dCQUNaLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsR0FBRyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDOzRCQUNsQyxFQUFFLElBQUksR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQzs0QkFFbkIsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7Z0NBQ2QsRUFBRSxHQUFHLEVBQUUsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7NEJBQ3hDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxJQUFJLEVBQUUsSUFBSSxNQUFNLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRSxDQUFDLElBQUksRUFBRSxJQUFJLE9BQU8sQ0FBQyxDQUFDLENBQUM7Z0NBQzFFLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDOzRCQUM5QixDQUFDOzRCQUNELElBQUksQ0FBQyxDQUFDO2dDQUNGLElBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDOzRCQUMvQixDQUFDO3dCQUNMLENBQUM7b0JBQ0wsQ0FBQztnQkFDTCxDQUFDO2dCQUNELDJDQUFlLEdBQWYsVUFBZ0IsTUFBTTtvQkFBdEIsaUJBZ1BDO29CQTdPRyxJQUFJLE9BQU8sR0FBRyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUM7b0JBQ3JDLElBQUksQ0FBQyxlQUFlLENBQUMsc0JBQXNCLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDL0QsV0FBVzt3QkFDWCxJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO2dDQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQzVCLE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7d0JBRS9DLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBRUgsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxTQUFTOzJCQUM5RyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLFNBQVM7MkJBQ2pILElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxHQUFHLENBQUM7MkJBQ3pCLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLElBQUksU0FBUzsyQkFDMUgsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxTQUFTOzJCQUNuSCxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxJQUFJLFNBQVM7MkJBQzdILElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLElBQUksU0FBUzsyQkFDOUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsSUFBSSxTQUM1RyxDQUFDLENBQUMsQ0FBQzt3QkFFQyxJQUFJLENBQUMsU0FBUyxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQzt3QkFDdkQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUM7d0JBQzNELElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDO3dCQUNyRCxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQzt3QkFDekQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUM7d0JBQ3ZELElBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDO3dCQUMzRCxJQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQzt3QkFDckQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUM7d0JBQzNELElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDO3dCQUNuRCxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQzt3QkFDN0QsSUFBSSxDQUFDLFNBQVMsQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUM7d0JBQ3ZELElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDO3dCQUMvRCxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQzt3QkFDL0QsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUM7d0JBQzdDLElBQUksQ0FBQyxTQUFTLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxrQkFBa0IsQ0FBQzt3QkFDdkUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUM7d0JBQzNELElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDO3dCQUdyRCxJQUFJLENBQUMsU0FBUyxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUM7d0JBQ2pDLElBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUM7d0JBQzdDLElBQUksU0FBUyxHQUFHLENBQUMsQ0FBQzt3QkFDbEIsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFlBQVksRUFBRTs0QkFDckMsSUFBSSxDQUFDLFlBQVksR0FBRyxTQUFTLEVBQUUsQ0FBQzt3QkFFcEMsQ0FBQyxDQUFDLENBQUM7d0JBQ0gsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7d0JBQzNDLElBQUksQ0FBQyxlQUFlLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7NEJBQ3JELE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUM7NEJBQ3RCLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDOzRCQUN0QyxLQUFJLENBQUMsWUFBWSxHQUFHLEVBQUUsQ0FBQzs0QkFDdkIsMEJBQTBCOzRCQUUxQixFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7Z0NBQzNCLHlCQUF5QjtnQ0FDekIsS0FBSSxDQUFDLFFBQVEsR0FBRyxhQUFhLENBQUM7NEJBQ2xDLENBQUM7NEJBQ0QsSUFBSSxDQUFDLENBQUM7Z0NBQ0YseUJBQXlCO2dDQUV6QixrQ0FBa0M7Z0NBQ2xDLE9BQU8sQ0FBQyxLQUFLLENBQUM7b0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO29DQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7b0NBQzVCLE9BQU8sRUFBRTt3Q0FDTCxFQUFFLEVBQUU7NENBQ0EsY0FBYzs0Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7eUNBQzVCO3FDQUNKO2lDQUNKLENBQUMsQ0FBQztnQ0FDSCxXQUFXO2dDQUNYLEVBQUUsQ0FBQyxDQUFDLE1BQU0sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO29DQUNqQixRQUFRLENBQUMsUUFBUSxHQUFHLEtBQUksQ0FBQyxPQUFPLEdBQUcsZ0JBQWdCLEdBQUcsS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsSUFBSSxHQUFHLEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDO2dDQUN6SCxDQUFDO2dDQUNELElBQUksQ0FBQyxDQUFDO29DQUNGLHNIQUFzSDtvQ0FDdEgsS0FBSSxDQUFDLFFBQVEsR0FBRyxDQUFDLENBQUM7b0NBQ2xCLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO29DQUN0QixJQUFJLGVBQWUsR0FBRyxLQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQztvQ0FDbEQsS0FBSSxDQUFDLFVBQVUsR0FBRyxFQUFFLENBQUM7b0NBQ3JCLEtBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQztvQ0FDOUIsS0FBSSxDQUFDLFNBQVMsR0FBRyxFQUFFLENBQUM7b0NBQ3BCLEtBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxHQUFHLEVBQUUsQ0FBQztvQ0FDakMsS0FBSSxDQUFDLFNBQVMsR0FBRyxFQUFFLENBQUM7b0NBQ3BCLGdEQUFnRDtvQ0FDaEQsS0FBSSxDQUFDLGVBQWUsQ0FBQyxjQUFjLENBQUMsS0FBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3Q0FDdEYsWUFBWTt3Q0FDWixJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO3dDQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NENBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0RBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO2dEQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0RBQzVCLE9BQU8sRUFBRTtvREFDTCxFQUFFLEVBQUU7d0RBQ0EsY0FBYzt3REFDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cURBQzVCO2lEQUNKOzZDQUNKLENBQUMsQ0FBQzt3Q0FDUCxDQUFDO3dDQUNELElBQUksQ0FBQyxDQUFDOzRDQUNGLEtBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDOzRDQUM5RCxLQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQzt3Q0FFN0QsQ0FBQztvQ0FDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dDQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0NBQ3ZCLENBQUMsRUFBRTt3Q0FDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29DQUNoQyxDQUFDLENBQUMsQ0FBQztvQ0FDSCxJQUFJLGNBQWMsQ0FBQztvQ0FDbkIsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsU0FBUyxFQUFFO3dDQUN4QixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxJQUFJLE1BQU0sSUFBSSxJQUFJLENBQUMsSUFBSSxJQUFJLE9BQU8sQ0FBQyxDQUFDLENBQUM7NENBQzVELGNBQWMsR0FBRyxJQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDOzRDQUNoRCxJQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQzs0Q0FDM0IsTUFBTSxDQUFDLEtBQUssQ0FBQTt3Q0FDaEIsQ0FBQztvQ0FFTCxDQUFDLENBQUMsQ0FBQztvQ0FDSCxLQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxTQUFTLEdBQUcsY0FBYyxDQUFDO29DQUNwRCxLQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztvQ0FFM0IsS0FBSSxDQUFDLGVBQWUsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dDQUM3QyxXQUFXO3dDQUNYLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7d0NBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0Q0FDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnREFDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0RBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnREFDNUIsT0FBTyxFQUFFO29EQUNMLEVBQUUsRUFBRTt3REFDQSxjQUFjO3dEQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxREFDNUI7aURBQ0o7NkNBQ0osQ0FBQyxDQUFDO3dDQUNQLENBQUM7d0NBQ0QsSUFBSSxDQUFDLENBQUM7NENBQ0YsV0FBVzs0Q0FDWCxLQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQzs0Q0FDcEQsS0FBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7d0NBRXpELENBQUM7b0NBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3Q0FDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29DQUN2QixDQUFDLEVBQUU7d0NBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQ0FDaEMsQ0FBQyxDQUFDLENBQUM7b0NBRUgsS0FBSSxDQUFDLGVBQWUsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0NBQ25ELFlBQVk7d0NBQ1gsSUFBSSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzt3Q0FDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRDQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dEQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtnREFDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dEQUM1QixPQUFPLEVBQUU7b0RBQ0wsRUFBRSxFQUFFO3dEQUNBLGNBQWM7d0RBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FEQUM1QjtpREFDSjs2Q0FDSixDQUFDLENBQUM7d0NBQ1AsQ0FBQzt3Q0FDRCxJQUFJLENBQUMsQ0FBQzs0Q0FDRixLQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQzs0Q0FDaEQsS0FBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7d0NBRXJELENBQUM7b0NBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3Q0FDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29DQUN2QixDQUFDLEVBQUU7d0NBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQ0FDaEMsQ0FBQyxDQUFDLENBQUM7Z0NBQ1AsQ0FBQzs0QkFDTCxDQUFDO3dCQUVMLENBQUMsRUFDRyxVQUFBLEtBQUssSUFBRyxPQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEVBQWxCLENBQWtCLEVBQzFCLGNBQU0sT0FBQSxPQUFPLENBQUMsR0FBRyxDQUFDLHNCQUFzQixDQUFDLEVBQW5DLENBQW1DLENBQzVDLENBQUM7b0JBRU4sQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixJQUFJLEdBQUcsR0FBRyxFQUFFLENBQUM7d0JBQ2IsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDOzRCQUNwSCxHQUFHLElBQUksNkJBQTZCLENBQUM7d0JBQ3pDLENBQUM7d0JBQ0QsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDOzRCQUNwSCxHQUFHLElBQUksNEJBQTRCLENBQUM7d0JBQ3hDLENBQUM7d0JBQ0QsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDOzRCQUM3SCxHQUFHLElBQUksK0JBQStCLENBQUM7d0JBQzNDLENBQUM7d0JBQ0QsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDOzRCQUNwSCxHQUFHLElBQUksaUNBQWlDLENBQUM7d0JBQzdDLENBQUM7d0JBQ0QsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDOzRCQUNoSSxHQUFHLElBQUksa0NBQWtDLENBQUM7d0JBQzlDLENBQUM7d0JBQ0QsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDOzRCQUNqSCxHQUFHLElBQUkseUNBQXlDLENBQUM7d0JBQ3JELENBQUM7d0JBQ0QsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDOzRCQUNqSCxHQUFHLElBQUksMkJBQTJCLENBQUM7d0JBQ3ZDLENBQUM7d0JBQ0QsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQzs0QkFDN0IsR0FBRyxJQUFJLDhDQUE4QyxDQUFDO3dCQUMxRCxDQUFDO3dCQUNELE9BQU8sQ0FBQyxLQUFLLENBQUM7NEJBQ1YsT0FBTyxFQUFFLEdBQUc7NEJBQ1osU0FBUyxFQUFFLElBQUksQ0FBQyxZQUFZOzRCQUM1QixPQUFPLEVBQUU7Z0NBQ0wsRUFBRSxFQUFFO29DQUNBLGNBQWM7b0NBQ2QsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO2lDQUM1Qjs2QkFDSjt5QkFDSixDQUFDLENBQUM7b0JBQ1AsQ0FBQztnQkFDTCxDQUFDO2dCQUVELG9DQUFRLEdBQVIsVUFBUyxRQUFRO29CQUNiLFdBQVc7b0JBQ1gsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDNUIsSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO3dCQUNkLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRTs0QkFDeEIsRUFBRSxDQUFDLENBQUMsSUFBSSxJQUFJLFFBQVEsQ0FBQyxDQUFDLENBQUM7Z0NBQ25CLE1BQU0sQ0FBQyxLQUFLLENBQUE7NEJBQ2hCLENBQUM7NEJBQ0QsS0FBSyxHQUFHLEtBQUssR0FBRyxDQUFDLENBQUM7d0JBRXRCLENBQUMsQ0FBQyxDQUFDO3dCQUNILElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQztvQkFDcEMsQ0FBQztnQkFDTCxDQUFDO2dCQUNELG9DQUFRLEdBQVIsVUFBUyxRQUFRO29CQUNiLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQztvQkFDZCxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUE7b0JBRWYsUUFBUSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDO29CQUN0QyxJQUFJLEdBQUcsUUFBUSxDQUFDO29CQUNoQixJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDOUIsQ0FBQztnQkFDRCxvQ0FBUSxHQUFSO29CQUNJLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLElBQUksR0FBRyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUM7b0JBQ3RELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLE1BQU0sSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsTUFBTSxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxNQUFNLElBQUksU0FBUzsyQkFDN0gsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsU0FBUyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxTQUFTLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLFNBQVMsSUFBSSxTQUFTOzJCQUN6SSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxTQUFTLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLFNBQVMsSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsU0FBUyxJQUFJLFNBQVM7MkJBQ3pJLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLGNBQWMsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsY0FBYyxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxjQUFjLElBQUksU0FBUzsyQkFDeEosSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsU0FBUyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxTQUFTLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLFNBQVMsSUFBSSxTQUV2SSxDQUFDLENBQUMsQ0FBQzt3QkFDQyxJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsUUFBUSxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO3dCQUN2RSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxTQUFTLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUNoRCxJQUFJLFdBQVcsR0FBRyxFQUFFLENBQUM7d0JBQ3JCLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsT0FBTyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDOzRCQUN0QyxXQUFXLElBQUksT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFDLEdBQUcsQ0FBQzt3QkFDbEMsQ0FBQzt3QkFDRCxRQUFRLENBQUM7d0JBQ1QsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsR0FBRyxDQUFDO3dCQUMzQixJQUFJLENBQUMsUUFBUSxDQUFDLGNBQWMsR0FBRyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUM7d0JBQ3hELElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQzt3QkFDaEIsa0NBQWtDO3dCQUNsQyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQzt3QkFDdEQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsT0FBTyxHQUFHLFdBQVcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLFdBQVcsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7d0JBRXBGLElBQUksWUFBWSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7d0JBQ2pGLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLGNBQWMsR0FBRyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7d0JBQ2pFLElBQUksWUFBWSxHQUFHLEVBQUUsQ0FBQzt3QkFDdEIsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxZQUFZLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUM7NEJBQzNDLFlBQVksSUFBSSxZQUFZLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDO3dCQUMxQyxDQUFDO3dCQUNELElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLFlBQVksR0FBRyxZQUFZLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxZQUFZLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDO3dCQUUzRixJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsUUFBUSxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO3dCQUN2RSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxTQUFTLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO3dCQUN2RCxJQUFJLFdBQVcsR0FBRyxFQUFFLENBQUM7d0JBQ3JCLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsT0FBTyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDOzRCQUN0QyxXQUFXLElBQUksT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQzt3QkFDcEMsQ0FBQzt3QkFDRCxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxPQUFPLEdBQUcsV0FBVyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsV0FBVyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQzt3QkFFcEYsSUFBSSxlQUFlLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsaUJBQWlCLENBQUMsUUFBUSxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO3dCQUN2RixJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxpQkFBaUIsR0FBRyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7d0JBQ3ZFLElBQUksbUJBQW1CLEdBQUcsRUFBRSxDQUFDO3dCQUM3QixHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLGVBQWUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQzs0QkFDOUMsbUJBQW1CLElBQUksZUFBZSxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQzt3QkFDcEQsQ0FBQzt3QkFDRCxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxlQUFlLEdBQUcsbUJBQW1CLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxtQkFBbUIsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7d0JBRTVHLElBQUksT0FBTyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7d0JBQ3ZFLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLFNBQVMsR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7d0JBQ3ZELElBQUksV0FBVyxHQUFHLEVBQUUsQ0FBQzt3QkFDckIsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxPQUFPLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUM7NEJBQ3RDLFdBQVcsSUFBSSxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDO3dCQUNwQyxDQUFDO3dCQUNELElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLE9BQU8sR0FBRyxXQUFXLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxXQUFXLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDO3dCQUVwRixJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUU5QyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUM7d0JBRTlCLFFBQVEsQ0FBQzt3QkFDVCxJQUFJLGNBQWMsQ0FBQzt3QkFDbkIsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFOzRCQUN4QixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxJQUFJLE1BQU0sSUFBSSxJQUFJLENBQUMsSUFBSSxJQUFJLE9BQU8sQ0FBQyxDQUFDLENBQUM7Z0NBQzVELGNBQWMsR0FBRyxJQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO2dDQUNoRCxJQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztnQ0FDM0IsTUFBTSxDQUFDLEtBQUssQ0FBQTs0QkFDaEIsQ0FBQzs0QkFDRCxJQUFJLENBQUMsQ0FBQztnQ0FDRixJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQzs0QkFDOUIsQ0FBQzt3QkFFTCxDQUFDLENBQUMsQ0FBQzt3QkFDSCxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxTQUFTLEdBQUcsY0FBYyxDQUFDO3dCQUNwRCxJQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztvQkFFL0IsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixJQUFJLEdBQUcsR0FBRyxFQUFFLENBQUM7d0JBQ2IsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsTUFBTSxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxNQUFNLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLE1BQU0sSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDOzRCQUNuSSxHQUFHLElBQUkseUJBQXlCLENBQUM7d0JBQ3JDLENBQUM7d0JBQ0QsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsU0FBUyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxTQUFTLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLFNBQVMsSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDOzRCQUM1SSxHQUFHLElBQUksMkJBQTJCLENBQUM7d0JBQ3ZDLENBQUM7d0JBQ0QsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsU0FBUyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxTQUFTLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLFNBQVMsSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDOzRCQUM1SSxHQUFHLElBQUksMkJBQTJCLENBQUM7d0JBQ3ZDLENBQUM7d0JBQ0QsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsY0FBYyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxjQUFjLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLGNBQWMsSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDOzRCQUMzSixHQUFHLElBQUksd0JBQXdCLENBQUM7d0JBQ3BDLENBQUM7d0JBQ0QsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsU0FBUyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxTQUFTLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLFNBQVMsSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDOzRCQUM1SSxHQUFHLElBQUksMkJBQTJCLENBQUM7d0JBQ3ZDLENBQUM7d0JBQ0QsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsTUFBTSxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxNQUFNLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLE1BQU0sSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDOzRCQUNuSSxHQUFHLElBQUksd0JBQXdCLENBQUM7d0JBQ3BDLENBQUM7d0JBQ0QsbUlBQW1JO3dCQUVuSSxHQUFHO3dCQUNILE9BQU8sQ0FBQyxLQUFLLENBQUM7NEJBQ1YsT0FBTyxFQUFFLEdBQUc7NEJBQ1osU0FBUyxFQUFFLElBQUksQ0FBQyxZQUFZOzRCQUM1QixPQUFPLEVBQUU7Z0NBQ0wsRUFBRSxFQUFFO29DQUNBLGNBQWM7b0NBQ2QsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO2lDQUM1Qjs2QkFDSjt5QkFDSixDQUFDLENBQUM7b0JBQ1AsQ0FBQztnQkFDTCxDQUFDO2dCQUNELHFDQUFTLEdBQVQ7b0JBQ0ksTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDO2dCQUNyQyxDQUFDO2dCQUNELHlDQUFhLEdBQWI7b0JBRUksTUFBTSxDQUFDLGdCQUFnQixDQUFDLENBQUMsU0FBUyxFQUFFLENBQUM7Z0JBQ3pDLENBQUM7Z0JBQ0Qsc0NBQVUsR0FBVixVQUFXLEtBQUs7b0JBQ1osSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQztvQkFDMUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQztnQkFDakQsQ0FBQztnQkFDRCwrQ0FBbUIsR0FBbkIsVUFBb0IsS0FBSztvQkFDckIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDO29CQUM5QyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDO2dCQUNqRCxDQUFDO2dCQUNELDZDQUFpQixHQUFqQjtvQkFBQSxpQkFzQ0M7b0JBckNHLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDO29CQUN4QyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsa0JBQWtCLENBQUMsTUFBTSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDM0QsV0FBVzt3QkFDWCxJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO2dDQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQzVCLE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLFFBQVEsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDOzRCQUN6QixLQUFJLENBQUMsVUFBVSxHQUFHLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQzs0QkFDN0MsSUFBSSxXQUFXLENBQUM7NEJBQ2hCLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLGlCQUFpQixFQUFFO2dDQUNwQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7b0NBQzNCLFdBQVcsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDO2dDQUVqQyxDQUFDOzRCQUNMLENBQUMsQ0FBQyxDQUFDOzRCQUNILEtBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxHQUFHLFdBQVcsQ0FBQzs0QkFDeEMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsUUFBUSxDQUFDLFVBQVUsQ0FBQzs0QkFDakQsS0FBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEdBQUcsUUFBUSxDQUFDLEtBQUssR0FBRyxHQUFHLEdBQUcsUUFBUSxDQUFDLEtBQUssQ0FBQzt3QkFFekUsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztnQkFFUCxDQUFDO2dCQUNELHdDQUFZLEdBQVo7b0JBQ0ksSUFBSSxNQUFNLEdBQUcsTUFBTSxDQUFDLGtCQUFrQixDQUFDLENBQUMsR0FBRyxFQUFFLENBQUM7b0JBQzlDLElBQUksTUFBTSxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7b0JBQy9CLElBQUksS0FBSyxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztvQkFDN0IsSUFBSSxDQUFDLHNCQUFzQixDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUN2QyxDQUFDO2dCQUNELGtEQUFzQixHQUF0QixVQUF1QixLQUFLO29CQUE1QixpQkF5QkM7b0JBeEJHLElBQUksQ0FBQyxlQUFlLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQ2xELFdBQVc7d0JBQ1gsSUFBSSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtnQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUM1QixPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsU0FBUyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7d0JBRW5DLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7Z0JBQ1AsQ0FBQztnQkFDRCxvQ0FBUSxHQUFSO29CQUFBLGlCQWtZQztvQkFqWUcsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7b0JBRXhCLGlCQUFpQjtvQkFDZixJQUFJLENBQUMsSUFBSSxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQ3pDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFFekUsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLEdBQUcsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO3dCQUM3QixDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUVILElBQUksQ0FBQyxlQUFlLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUNsRCxXQUFXO3dCQUNYLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLGNBQWMsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO3dCQUV4QyxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUNILElBQUksQ0FBQyxlQUFlLENBQUMsUUFBUSxFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDMUMsV0FBVzt3QkFDWCxJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO2dDQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQzVCLE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLDhCQUE4Qjs0QkFDOUIsSUFBSSxlQUFlLEdBQUcsRUFBRSxDQUFDOzRCQUN6QixNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUU7Z0NBQ3ZCLElBQUksT0FBTyxHQUFHLEVBQUUsQ0FBQztnQ0FDakIsT0FBTyxDQUFDLEVBQUUsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO2dDQUN4QixPQUFPLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUM7Z0NBQ3pCLGVBQWUsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7NEJBQ2xDLENBQUMsQ0FBQyxDQUFDOzRCQUNILEtBQUksQ0FBQyxNQUFNLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzs0QkFDNUIsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQztnQ0FDdEIscUJBQXFCO2dDQUNyQixNQUFNLEVBQUUsZUFBZTtnQ0FDdkIsa0JBQWtCO2dDQUNsQixRQUFRLEVBQUUsTUFBTTs2QkFJbkIsQ0FBQyxDQUFDO3dCQUNQLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBR0gsSUFBSSxDQUFDLGVBQWUsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQy9FLFdBQVc7d0JBQ1gsSUFBSSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtnQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUM1QixPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsYUFBYSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7d0JBRXZDLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsSUFBSSxDQUFDLGVBQWUsQ0FBQyxjQUFjLEVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUNoRCxXQUFXO3dCQUNYLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsV0FBVzs0QkFDWCxLQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQzs0QkFDdkQsS0FBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7d0JBRTVELENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsSUFBSSxDQUFDLGVBQWUsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUM1QyxXQUFXO3dCQUNYLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsV0FBVzs0QkFDWCxLQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQzt3QkFFdkQsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFDSCxJQUFJLENBQUMsZUFBZSxDQUFDLFdBQVcsRUFBRSxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQzdDLFdBQVc7d0JBQ1gsSUFBSSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtnQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUM1QixPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixXQUFXOzRCQUNYLEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDOzRCQUNwRCxLQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQzt3QkFFekQsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFDSCxJQUFJLENBQUMsZUFBZSxDQUFDLFVBQVUsRUFBRSxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQzVDLFdBQVc7d0JBQ1gsSUFBSSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtnQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUM1QixPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsU0FBUyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7NEJBQy9CLElBQUksY0FBYyxDQUFDOzRCQUNuQixNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUksQ0FBQyxTQUFTLEVBQUU7Z0NBQ3hCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLElBQUksTUFBTSxJQUFJLElBQUksQ0FBQyxJQUFJLElBQUksT0FBTyxDQUFDLENBQUMsQ0FBQztvQ0FDNUQsY0FBYyxHQUFHLElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUM7b0NBQ2hELElBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDO29DQUMzQixNQUFNLENBQUMsS0FBSyxDQUFBO2dDQUNoQixDQUFDO2dDQUNELElBQUksQ0FBQyxDQUFDO29DQUNGLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO2dDQUM5QixDQUFDOzRCQUVMLENBQUMsQ0FBQyxDQUFDOzRCQUNILEtBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLFNBQVMsR0FBRyxjQUFjLENBQUM7d0JBRXhELENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBRUgsSUFBSSxDQUFDLGVBQWUsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUM3QyxXQUFXO3dCQUNYLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLFNBQVMsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO3dCQUVuQyxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUVILElBQUksQ0FBQyxlQUFlLENBQUMsUUFBUSxFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDMUMsV0FBVzt3QkFDWCxJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO2dDQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQzVCLE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEtBQUksQ0FBQyxNQUFNLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzt3QkFFaEMsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFFSCxJQUFJLENBQUMsZUFBZSxDQUFDLGNBQWMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQ2hELFdBQVc7d0JBQ1gsSUFBSSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtnQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUM1QixPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsWUFBWSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7d0JBRXRDLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsSUFBSSxDQUFDLHNCQUFzQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ2hDLElBQUksQ0FBQyxlQUFlLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUNsRCxJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO2dDQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQzVCLE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEtBQUksQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzt3QkFFckMsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFDSCxJQUFJLENBQUMsZUFBZSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUN2RixZQUFZO3dCQUNYLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUM7NEJBQzlELEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDO3dCQUU3RCxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUVILElBQUksQ0FBQyxlQUFlLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUNsRCxXQUFXO3dCQUNYLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7NEJBQ2hELEtBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO3dCQUVyRCxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUNILElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDO29CQUN4QyxJQUFJLENBQUMsaUJBQWlCLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBRW5DLENBQUM7Z0JBNzVCTSx5QkFBTyxHQUFHLENBQUMsUUFBUSxFQUFFLFdBQVcsRUFBRSxlQUFlLENBQUMsQ0FBQztnQkFsQzlEO29CQUFDLGdCQUFTLENBQUM7d0JBRVAsV0FBVyxFQUFFLGlEQUFpRDt3QkFDOUQsVUFBVSxFQUFFLENBQUMsaUJBQVEsRUFBRSxxQkFBWSxFQUFFLHdCQUFlLEVBQUUsMEJBQVEsQ0FBQzt3QkFDL0QsU0FBUyxFQUFFLENBQUMsK0JBQWMsRUFBRSxpQ0FBZSxFQUFFLGlDQUFlLEVBQUUseUNBQW1CLENBQUM7cUJBQ3JGLENBQUM7O3FDQUFBO2dCQTI3QkYsd0JBQUM7WUFBRCxDQXo3QkEsQUF5N0JDLElBQUE7WUF6N0JELGlEQXk3QkMsQ0FBQSIsImZpbGUiOiJkZXYvYW1heC9SZWNlaXB0L1JlY2VpcHRDcmVhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge0NvbXBvbmVudCwgT3V0cHV0LCBJbnB1dCwgRXZlbnRFbWl0dGVyLCBPbkluaXR9IGZyb20gXCJhbmd1bGFyMi9jb3JlXCI7XHJcbmltcG9ydCB7TmdTd2l0Y2gsIE5nU3dpdGNoV2hlbiwgTmdTd2l0Y2hEZWZhdWx0fSBmcm9tICdhbmd1bGFyMi9jb21tb24nXHJcbmltcG9ydCB7UmVzb3VyY2VTZXJ2aWNlfSBmcm9tIFwiLi4vLi4vc2VydmljZXMvUmVzb3VyY2VTZXJ2aWNlXCI7XHJcbmltcG9ydCB7Um91dGVQYXJhbXN9IGZyb20gXCJhbmd1bGFyMi9yb3V0ZXJcIjtcclxuaW1wb3J0IHtSZWNpZXB0U2VydmljZX0gZnJvbSBcIi4uLy4uL3NlcnZpY2VzL1JlY2llcHRTZXJ2aWNlXCI7XHJcbmltcG9ydCB7Q3VzdG9tZXJTZXJ2aWNlfSBmcm9tIFwiLi4vLi4vc2VydmljZXMvQ3VzdG9tZXJTZXJ2aWNlXCI7XHJcbmltcG9ydCB7IGpzb25RIH0gZnJvbSAnLi4vLi4vanNvblEnO1xyXG5pbXBvcnQge0dyb3VwRmlsdGVyUGlwZSwgR3JvdXBQYXJlbkZpbHRlclBpcGUsIEtlbmRvX3V0aWxpdHl9IGZyb20gXCIuLi8uLi9hbWF4VXRpbFwiO1xyXG5pbXBvcnQgeyBBbWF4RGF0ZSB9IGZyb20gJy4uLy4uL2NvbW9uQ29tcG9uZW50cy9iYXNpY0NvbXBvbmVudHMnO1xyXG5pbXBvcnQge0NoYXJnZUNyZWRpdFNlcnZpY2V9IGZyb20gXCIuLi8uLi9zZXJ2aWNlcy9DaGFyZ2VDcmVkaXRTZXJ2aWNlXCI7XHJcbmRlY2xhcmUgdmFyIGpRdWVyeTtcclxuZGVjbGFyZSB2YXIgbW9tZW50O1xyXG5AQ29tcG9uZW50KHtcclxuXHJcbiAgICB0ZW1wbGF0ZVVybDogJy4vYXBwL2FtYXgvUmVjZWlwdC90ZW1wbGF0ZXMvUmVjZWlwdENyZWF0ZS5odG1sJyxcclxuICAgIGRpcmVjdGl2ZXM6IFtOZ1N3aXRjaCwgTmdTd2l0Y2hXaGVuLCBOZ1N3aXRjaERlZmF1bHQsIEFtYXhEYXRlXSxcclxuICAgIHByb3ZpZGVyczogW1JlY2llcHRTZXJ2aWNlLCBSZXNvdXJjZVNlcnZpY2UsIEN1c3RvbWVyU2VydmljZSwgQ2hhcmdlQ3JlZGl0U2VydmljZV1cclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBBbWF4UmVjZWlwdENyZWF0ZSBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcbiAgICBiYXNlVXJsOiBzdHJpbmc7XHJcbiAgICBSRVM6IE9iamVjdCA9IHt9O1xyXG4gICAgRm9ybXR5cGU6IHN0cmluZyA9IFwiU0NSRUVOX1JFQ0VJUFRDUkVBVEVcIjtcclxuICAgIExhbmc6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBfQmFua3MgPSBbXTtcclxuICAgIF9DdXN0b21lck5vdGVzID0gW107XHJcbiAgICBfQWRkcmVzc2VzID0gW107XHJcbiAgICBfUGF5VHlwZXMgPSBbXTtcclxuICAgIF9BY2NvdW50cyA9IFtdO1xyXG4gICAgX0dvYWxzID0gW107XHJcbiAgICBfUHJvamVjdENhdHMgPSBbXTtcclxuICAgIF9Qcm9qZWN0cyA9IFtdO1xyXG4gICAgX0N1cnJlbmNpZXMgPSBbXTtcclxuICAgIE1vZGVsRGF0YSA9IFtdO1xyXG4gICAgX1RoYW5rTGV0dGVycyA9IFtdO1xyXG4gICAgUm93Q291bnQ6bnVtYmVyID0gMDtcclxuICAgIElzYnRuZGlzYWJsZTogc3RyaW5nID0gXCJcIjtcclxuICAgIFNBVkVfQlROX1RFWFQ6IHN0cmluZz1cIlNhdmVcIjtcclxuICAgIE1zZ0NsYXNzOiBzdHJpbmcgPSBcInRleHQtcHJpbWFyeVwiO1xyXG4gICAgbW9kZWxJbnB1dDogT2JqZWN0ID0ge307XHJcbiAgICBzYXZlSW5wdXQ6IE9iamVjdCA9IHt9O1xyXG4gICAgQ2hhbmdlRGlhbG9nOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgQ0hBTkdFRElSOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgU2hvd01vcmVUZXh0OiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgU2hvd01vcmU6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIElzQmFua0RldFNob3c6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHN0YXRpYyAkaW5qZWN0ID0gWyckc2NvcGUnLCAnJGxvY2F0aW9uJywgJyRhbmNob3JTY3JvbGwnXTtcclxuICAgLy8gQFZpZXdDaGlsZCgnUlRMRGl2JykgcHJpdmF0ZSBteVNjcm9sbENvbnRhaW5lcjogRWxlbWVudFJlZjtcclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgX3Jlc291cmNlU2VydmljZTogUmVzb3VyY2VTZXJ2aWNlLCBwcml2YXRlIF9SZWNpZXB0U2VydmljZTogUmVjaWVwdFNlcnZpY2UsIHByaXZhdGUgX0N1c3RvbWVyU2VydmljZTogQ3VzdG9tZXJTZXJ2aWNlLCBwcml2YXRlIF9yb3V0ZVBhcmFtczogUm91dGVQYXJhbXMsIHByaXZhdGUgX0NoYXJnZUNyZWRpdFNlcnZpY2U6IENoYXJnZUNyZWRpdFNlcnZpY2UpIHtcclxuICAgICAgICBcclxuICAgICAgICB0aGlzLlJFUy5TQ1JFRU5fUkVDRUlQVENSRUFURSA9IHt9O1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dCA9IHt9O1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5BZGRNb2RlbCA9IHt9O1xyXG4gICAgICAgIHRoaXMuSXNCYW5rRGV0U2hvdyA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0VHlwZUlkID0gX3JvdXRlUGFyYW1zLnBhcmFtcy5SZWNlaXB0VHlwZUlkO1xyXG4gICAgICAgIC8vdGhpcy5iYXNlVXJsID0gXCJodHRwOi8vbG9jYWxob3N0OjMwMDAvIy9cIjtcclxuICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAvLyBhbGVydCh0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdFR5cGVJZCk7XHJcbiAgICAgICAgdGhpcy5iYXNlVXJsID0gX3Jlc291cmNlU2VydmljZS5BcHBVcmw7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQgPSBfcm91dGVQYXJhbXMucGFyYW1zLklkO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lck5hbWUgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5BZGRNb2RlbC5SZWZlcmVuY2VEYXRlID0gXCJcIjtcclxuICAgICAgICB0aGlzLlNob3dNb3JlVGV4dCA9IFwiTW9yZVwiO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5BZGRNb2RlbC5WYWx1ZURhdGU9bW9tZW50KG5ldyBEYXRlKCkpLmZvcm1hdCgnREQtTU0tWVlZWScpO1xyXG4gICAgfVxyXG4gICAgZGF0ZVZTZWxlY3Rpb25DaGFuZ2UoZXZ0KSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coZXZ0KTtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQWRkTW9kZWwuVmFsdWVEYXRlID0gZXZ0O1xyXG4gICAgICAgIC8vIGFsZXJ0KHRoaXMubW9kZWxJbnB1dC5CaXJ0aERhdGUpO1xyXG4gICAgICAgIC8vdGhpcy52YWxpZGF0ZUxvZ2luKCk7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIGRhdGVTZWxlY3Rpb25DaGFuZ2UoZXZ0KSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coZXZ0KTtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQWRkTW9kZWwuUmVmZXJlbmNlRGF0ZSA9IGV2dDtcclxuICAgICAgICAvLyBhbGVydCh0aGlzLm1vZGVsSW5wdXQuQmlydGhEYXRlKTtcclxuICAgICAgICAvL3RoaXMudmFsaWRhdGVMb2dpbigpO1xyXG4gICAgfVxuXHJcbiAgICBNb3JlKCl7XHJcbiAgICAgICAgLy8gYWxlcnQoXCJjYWxsXCIpO1xyXG4gICAgICAgIGlmICh0aGlzLlNob3dNb3JlID09IHRydWUpIHtcclxuICAgICAgICAgICAgdGhpcy5TaG93TW9yZSA9IGZhbHNlO1xyXG5cclxuICAgICAgICAgICAgdGhpcy5TaG93TW9yZVRleHQgPSBcIk1vcmVcIjtcclxuICAgICAgICAgICAgLy90aGlzLlNob3dNb3JlVGV4dCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfTE5LX0xCTF9NT1JFO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5TaG93TW9yZSA9IHRydWU7XHJcbiAgICAgICAgICAgIHRoaXMuU2hvd01vcmVUZXh0ID0gXCJMZXNzXCI7IFxyXG4gICAgICAgICAgICAvL3RoaXMuU2hvd01vcmVUZXh0ID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9MTktfTEJMX0xFU1M7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgQmFua0RldGFpbFNob3coKSB7XHJcbiAgICAgICAgLy9hbGVydCgnSGVsbG8nKTtcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5BZGRNb2RlbC5QYXlUeXBlSWQgPSBqUXVlcnkoXCIjUGF5VHlwZVwiKS52YWwoKTtcclxuICAgICAgICB2YXIgUGF5VHlwZSA9IHRoaXMubW9kZWxJbnB1dC5BZGRNb2RlbC5QYXlUeXBlSWQ7XHJcbiAgICAgICAgdmFyIFBheVR5cGVJZCA9IFwiXCI7XHJcbiAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5fUGF5VHlwZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgaWYgKCh0aGlzLlZhbHVlK1wiIC0gXCIrdGhpcy5UZXh0KSA9PSBQYXlUeXBlKSB7XHJcbiAgICAgICAgICAgICAgICBQYXlUeXBlSWQgPSB0aGlzLlZhbHVlICsgXCIgLSBcIiArIHRoaXMuVGV4dDtcclxuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGlmIChQYXlUeXBlSWQgIT0gXCJcIikge1xyXG4gICAgICAgICAgICB2YXIgUFRJID0gUGF5VHlwZUlkLnRvU3RyaW5nKCkuc3BsaXQoJy0nKTtcclxuICAgICAgICAgICAgdmFyIFBUID0gXCJcIjtcclxuICAgICAgICAgICAgZm9yICh2YXIgaSA9IDE7IGkgPCBQVEkubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgIFBUICs9IFBUSVtpXSArIFwiLVwiO1xyXG5cclxuICAgICAgICAgICAgICAgIGlmIChQVC5sZW5ndGggPiAwKVxyXG4gICAgICAgICAgICAgICAgICAgIFBUID0gUFQuc3Vic3RyaW5nKDAsIFBULmxlbmd0aCAtIDEpO1xyXG4gICAgICAgICAgICAgICAgaWYgKFBULnRvTG93ZXJDYXNlKCkudHJpbSgpICE9IFwiY2FzaFwiICYmIFBULnRvTG93ZXJDYXNlKCkudHJpbSgpICE9IFwi157XlteV157Xn1wiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5Jc0JhbmtEZXRTaG93ID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuSXNCYW5rRGV0U2hvdyA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgc2F2ZVJlY2VpcHREYXRhKElzRXhpdCkge1xyXG5cclxuXHJcbiAgICAgICAgdmFyIEVtcE5hbWUgPSBqUXVlcnkoXCIjRW1wSWRcIikudmFsKCk7XHJcbiAgICAgICAgdGhpcy5fUmVjaWVwdFNlcnZpY2UuR2V0RW1wbG95ZWVGcm9tRW1wTmFtZShFbXBOYW1lKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkVtcGxveWVlSWQgPSByZXNwb25zZS5EYXRhO1xyXG5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkICE9IG51bGwgJiYgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQgIT0gXCJcIiAmJiB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCAhPSB1bmRlZmluZWRcclxuICAgICAgICAgICAgJiYgdGhpcy5tb2RlbElucHV0LkN1cnJlbmN5SWQgIT0gbnVsbCAmJiB0aGlzLm1vZGVsSW5wdXQuQ3VycmVuY3lJZCAhPSBcIlwiICYmIHRoaXMubW9kZWxJbnB1dC5DdXJyZW5jeUlkICE9IHVuZGVmaW5lZFxyXG4gICAgICAgICAgICAmJiB0aGlzLk1vZGVsRGF0YS5sZW5ndGggPiAwXHJcbiAgICAgICAgICAgICYmIHRoaXMubW9kZWxJbnB1dC5hc3NvY2lhdGlvbklkICE9IG51bGwgJiYgdGhpcy5tb2RlbElucHV0LmFzc29jaWF0aW9uSWQgIT0gXCJcIiAmJiB0aGlzLm1vZGVsSW5wdXQuYXNzb2NpYXRpb25JZCAhPSB1bmRlZmluZWRcclxuICAgICAgICAgICAgJiYgdGhpcy5tb2RlbElucHV0LkVtcGxveWVlSWQgIT0gbnVsbCAmJiB0aGlzLm1vZGVsSW5wdXQuRW1wbG95ZWVJZCAhPSBcIi0xXCIgJiYgdGhpcy5tb2RlbElucHV0LkVtcGxveWVlSWQgIT0gdW5kZWZpbmVkXHJcbiAgICAgICAgICAgICYmIHRoaXMubW9kZWxJbnB1dC5UaGFua3NMZXR0ZXJJZCAhPSBudWxsICYmIHRoaXMubW9kZWxJbnB1dC5UaGFua3NMZXR0ZXJJZCAhPSBcIlwiICYmIHRoaXMubW9kZWxJbnB1dC5UaGFua3NMZXR0ZXJJZCAhPSB1bmRlZmluZWRcclxuICAgICAgICAgICAgJiYgdGhpcy5tb2RlbElucHV0LlByaW50ZXJJZCAhPSBudWxsICYmIHRoaXMubW9kZWxJbnB1dC5QcmludGVySWQgIT0gXCJcIiAmJiB0aGlzLm1vZGVsSW5wdXQuUHJpbnRlcklkICE9IHVuZGVmaW5lZFxyXG4gICAgICAgICAgICAmJiB0aGlzLm1vZGVsSW5wdXQuUmVjaWVwdE5vICE9IG51bGwgJiYgdGhpcy5tb2RlbElucHV0LlJlY2llcHRObyAhPSBcIlwiICYmIHRoaXMubW9kZWxJbnB1dC5SZWNpZXB0Tm8gIT0gdW5kZWZpbmVkXHJcbiAgICAgICAgKSB7XHJcbiAgICAgICAgICAgXHJcbiAgICAgICAgICAgIHRoaXMuc2F2ZUlucHV0LkN1cnJlbmN5SWQgPSB0aGlzLm1vZGVsSW5wdXQuQ3VycmVuY3lJZDtcclxuICAgICAgICAgICAgdGhpcy5zYXZlSW5wdXQuUmVjaWVwdFR5cGUgPSB0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdFR5cGVJZDtcclxuICAgICAgICAgICAgdGhpcy5zYXZlSW5wdXQuUmVjaWVwdE5vID0gdGhpcy5tb2RlbElucHV0LlJlY2llcHRObztcclxuICAgICAgICAgICAgdGhpcy5zYXZlSW5wdXQuUmVjaWVwdERhdGUgPSB0aGlzLm1vZGVsSW5wdXQuUmVjaWVwdERhdGU7XHJcbiAgICAgICAgICAgIHRoaXMuc2F2ZUlucHV0LkN1c3RvbWVySWQgPSB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZDtcclxuICAgICAgICAgICAgdGhpcy5zYXZlSW5wdXQuQ3VzdG9tZXJOYW1lID0gdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyTmFtZTtcclxuICAgICAgICAgICAgdGhpcy5zYXZlSW5wdXQuQWRkcmVzc0lkID0gdGhpcy5tb2RlbElucHV0LkFkZHJlc3NJZDtcclxuICAgICAgICAgICAgdGhpcy5zYXZlSW5wdXQuQ3VzdG9tZXJOb3RlID0gdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyTm90ZTtcclxuICAgICAgICAgICAgdGhpcy5zYXZlSW5wdXQuRnJlZUxpbmUgPSB0aGlzLm1vZGVsSW5wdXQuRnJlZUxpbmU7XHJcbiAgICAgICAgICAgIHRoaXMuc2F2ZUlucHV0LmFzc29jaWF0aW9uSWQgPSB0aGlzLm1vZGVsSW5wdXQuYXNzb2NpYXRpb25JZDtcclxuICAgICAgICAgICAgdGhpcy5zYXZlSW5wdXQuRW1wbG95ZWVJZCA9IHRoaXMubW9kZWxJbnB1dC5FbXBsb3llZUlkO1xyXG4gICAgICAgICAgICB0aGlzLnNhdmVJbnB1dC5UaGFua3NMZXR0ZXJJZCA9IHRoaXMubW9kZWxJbnB1dC5UaGFua3NMZXR0ZXJJZDtcclxuICAgICAgICAgICAgdGhpcy5zYXZlSW5wdXQuUGF5bWVudFJlcXVlc3QgPSB0aGlzLm1vZGVsSW5wdXQuUGF5bWVudFJlcXVlc3Q7XHJcbiAgICAgICAgICAgIHRoaXMuc2F2ZUlucHV0LlRvdGFsID0gdGhpcy5tb2RlbElucHV0LlRvdGFsO1xyXG4gICAgICAgICAgICB0aGlzLnNhdmVJbnB1dC5Ub3RhbEluTGVhZEN1cnJlbnQgPSB0aGlzLm1vZGVsSW5wdXQuVG90YWxJbkxlYWRDdXJyZW50O1xyXG4gICAgICAgICAgICB0aGlzLnNhdmVJbnB1dC5Ub3RhbEluV29yZHMgPSB0aGlzLm1vZGVsSW5wdXQuVG90YWxJbldvcmRzO1xyXG4gICAgICAgICAgICB0aGlzLnNhdmVJbnB1dC5QcmludGVySWQgPSB0aGlzLm1vZGVsSW5wdXQuUHJpbnRlcklkO1xyXG4gICAgICAgICAgICBcclxuXHJcbiAgICAgICAgICAgIHRoaXMuc2F2ZUlucHV0LlJlY2VpcHRMaW5lcyA9IFtdO1xyXG4gICAgICAgICAgICB0aGlzLnNhdmVJbnB1dC5SZWNlaXB0TGluZXMgPSB0aGlzLk1vZGVsRGF0YTtcclxuICAgICAgICAgICAgdmFyIExpbmVDb3VudCA9IDA7XHJcbiAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMuc2F2ZUlucHV0LlJlY2VpcHRMaW5lcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5SZWNpZXB0Um9XSUQgPSBMaW5lQ291bnQrKztcclxuXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB2YXIgamRhdGEgPSBKU09OLnN0cmluZ2lmeSh0aGlzLnNhdmVJbnB1dCk7XHJcbiAgICAgICAgICAgIHRoaXMuX1JlY2llcHRTZXJ2aWNlLkFkZFJlY2VpcHQoamRhdGEpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLklzYnRuZGlzYWJsZSA9IFwiXCI7XHJcbiAgICAgICAgICAgICAgICAvL3RoaXMuU2hvd0xvYWRlciA9IGZhbHNlO1xyXG5cclxuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAvL2FsZXJ0KHJlc3BvbnNlLkVyck1zZyk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5Nc2dDbGFzcyA9IFwidGV4dC1kYW5nZXJcIjtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIC8vYWxlcnQocmVzcG9uc2UuRXJyTXNnKTtcclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAvL3RoaXMuX0N1c3RUeXBlcyA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKElzRXhpdCA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRvY3VtZW50LmxvY2F0aW9uID0gdGhpcy5iYXNlVXJsICsgXCJSZWNlaXB0U2VsZWN0L1wiICsgdGhpcy5tb2RlbElucHV0LkVtcGxveWVlSWQgKyBcIiAvXCIgKyB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZDtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vZG9jdW1lbnQubG9jYXRpb24gPSB0aGlzLmJhc2VVcmwgKyBcIlJlY2VpcHRDcmVhdGUvXCIgKyB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCArIFwiIC9cIiArIHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0SWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuUm93Q291bnQgPSAwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB3aW5kb3cuc2Nyb2xsVG8oMCwgMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBQcmV2UmVjZWlwdFR5cGUgPSB0aGlzLm1vZGVsSW5wdXQuUmVjaWVwdFR5cGU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dCA9IHt9O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQWRkTW9kZWwgPSB7fTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zYXZlSW5wdXQgPSB7fTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zYXZlSW5wdXQuUmVjZWlwdExpbmVzID0gW107XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuTW9kZWxEYXRhID0gW107XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vdGhpcy5tb2RlbElucHV0LlJlY2llcHRUeXBlID0gUHJldlJlY2VpcHRUeXBlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9SZWNpZXB0U2VydmljZS5HZXRSZWNpZXB0VHlwZSh0aGlzLl9yb3V0ZVBhcmFtcy5wYXJhbXMuUmVjZWlwdFR5cGVJZCkuc3Vic2NyaWJlKHJlc3A9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LlJlY2llcHRUeXBlID0gcmVzcG9uc2UuRGF0YVswXS5SZWNpZXB0TmFtZUVuZztcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VycmVuY3lJZCA9IHJlc3BvbnNlLkRhdGFbMF0uQ3VycmVuY3lJZDtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBQYXlUeXBlRGVmYXVsdDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5fUGF5VHlwZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLlRleHQudG9Mb3dlckNhc2UoKSA9PSBcImNhc2hcIiB8fCB0aGlzLlRleHQgPT0gXCLXnteW15XXntefXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQYXlUeXBlRGVmYXVsdCA9IHRoaXMuVmFsdWUgKyBcIiAtIFwiICsgdGhpcy5UZXh0O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuSXNCYW5rRGV0U2hvdyA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5BZGRNb2RlbC5QYXlUeXBlSWQgPSBQYXlUeXBlRGVmYXVsdDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5Jc0JhbmtEZXRTaG93ID0gZmFsc2U7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9SZWNpZXB0U2VydmljZS5HZXRFbXBsb3llZSgpLnN1YnNjcmliZShyZXNwPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuRW1wbG95ZWVJZCA9IHJlc3BvbnNlLkRhdGFbMF0uVmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkVtcGxveWVlTmFtZSA9IHJlc3BvbnNlLkRhdGFbMF0uVGV4dDtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9SZWNpZXB0U2VydmljZS5HZXRSZWNlaXB0RGV0YWlsKCkuc3Vic2NyaWJlKHJlc3A9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGRlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuUmVjaWVwdE5vID0gcmVzcG9uc2UuRGF0YS5WYWx1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuUmVjaWVwdERhdGUgPSByZXNwb25zZS5EYXRhLlRleHQ7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIH0gICAgICAgIFxyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIGVycm9yPT4gY29uc29sZS5sb2coZXJyb3IpLFxyXG4gICAgICAgICAgICAgICAgKCkgPT4gY29uc29sZS5sb2coXCJTYXZlIENhbGwgQ29tcGxlYXRlZFwiKVxyXG4gICAgICAgICAgICApO1xyXG5cclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHZhciBtc2cgPSBcIlwiO1xyXG4gICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQgPT0gbnVsbCB8fCB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCA9PSBcIlwiIHx8IHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkID09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgbXNnICs9IFwiPGJyPlBsZWFzZSBlbnRlciBjdXN0b21lcmlkXCI7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5DdXJyZW5jeUlkID09IG51bGwgfHwgdGhpcy5tb2RlbElucHV0LkN1cnJlbmN5SWQgPT0gXCJcIiB8fCB0aGlzLm1vZGVsSW5wdXQuQ3VycmVuY3lJZCA9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgIG1zZyArPSBcIjxicj5QbGVhc2Ugc2VsZWN0IGN1cnJlbmN5XCI7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5hc3NvY2lhdGlvbklkID09IG51bGwgfHwgdGhpcy5tb2RlbElucHV0LmFzc29jaWF0aW9uSWQgPT0gXCJcIiB8fCB0aGlzLm1vZGVsSW5wdXQuYXNzb2NpYXRpb25JZCA9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgIG1zZyArPSBcIjxicj5QbGVhc2UgZW50ZXIgRGVwb3NpdGVkIEJ5XCI7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5FbXBsb3llZUlkID09IG51bGwgfHwgdGhpcy5tb2RlbElucHV0LkVtcGxveWVlSWQgPT0gXCJcIiB8fCB0aGlzLm1vZGVsSW5wdXQuRW1wbG95ZWVJZCA9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgIG1zZyArPSBcIjxicj5QbGVhc2UgZW50ZXIgdmFsaWQgZW1wbG95ZWVcIjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LlRoYW5rc0xldHRlcklkID09IG51bGwgfHwgdGhpcy5tb2RlbElucHV0LlRoYW5rc0xldHRlcklkID09IFwiXCIgfHwgdGhpcy5tb2RlbElucHV0LlRoYW5rc0xldHRlcklkID09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgbXNnICs9IFwiPGJyPlBsZWFzZSBzZWxlY3QgcHJpbnQgdGVtcGxhdGVcIjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LlByaW50ZXJJZCA9PSBudWxsIHx8IHRoaXMubW9kZWxJbnB1dC5QcmludGVySWQgPT0gXCJcIiB8fCB0aGlzLm1vZGVsSW5wdXQuUHJpbnRlcklkID09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgbXNnICs9IFwiPGJyPlBsZWFzZSBzZXQgcHJpbnRlciBuYW1lIGluIGRhdGFiYXNlXCI7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5SZWNpZXB0Tm8gPT0gbnVsbCB8fCB0aGlzLm1vZGVsSW5wdXQuUmVjaWVwdE5vID09IFwiXCIgfHwgdGhpcy5tb2RlbElucHV0LlJlY2llcHRObyA9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgIG1zZyArPSBcIjxicj5SZWNlaXB0IG5vIGlzIG5vdCBzZXRcIjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAodGhpcy5Nb2RlbERhdGEubGVuZ3RoID09IDApIHtcclxuICAgICAgICAgICAgICAgIG1zZyArPSBcIjxicj5QbGVhc2UgYXRsZWFzdCBvbmUgYW1vdW50IGRldGFpbCBpbiBncmlkXCI7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICBtZXNzYWdlOiBtc2csXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBkZWxNb2RlbChNb2RlbE9iaik6IG9ic2VydmFibGUge1xyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgaWYgKHRoaXMuTW9kZWxEYXRhLmxlbmd0aCA+IDEpIHtcclxuICAgICAgICAgICAgdmFyIGluZGV4ID0gMDtcclxuICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5Nb2RlbERhdGEsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzID09IE1vZGVsT2JqKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBpbmRleCA9IGluZGV4ICsgMTtcclxuXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB0aGlzLk1vZGVsRGF0YS5zcGxpY2UoaW5kZXgsIDEpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIER1cE1vZGVsKE1vZGVsT2JqKSB7XHJcbiAgICAgICAgdmFyIE1PYmogPSB7fTtcclxuICAgICAgICB0aGlzLlJvd0NvdW50KytcclxuXHJcbiAgICAgICAgTW9kZWxPYmouUmVjaWVwdFJvV0lEID0gdGhpcy5Sb3dDb3VudDtcclxuICAgICAgICBNT2JqID0gTW9kZWxPYmo7XHJcbiAgICAgICAgdGhpcy5Nb2RlbERhdGEucHVzaChNT2JqKTtcclxuICAgIH1cclxuICAgIEFkZE1vZGVsKCkge1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5BZGRNb2RlbC5CYW5rID0galF1ZXJ5KFwiI0JhbmtcIikudmFsKCk7XHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5BZGRNb2RlbC5BbW91bnQgIT0gbnVsbCAmJiB0aGlzLm1vZGVsSW5wdXQuQWRkTW9kZWwuQW1vdW50ICE9IFwiXCIgJiYgdGhpcy5tb2RlbElucHV0LkFkZE1vZGVsLkFtb3VudCAhPSB1bmRlZmluZWRcclxuICAgICAgICAgICAgJiYgdGhpcy5tb2RlbElucHV0LkFkZE1vZGVsLlBheVR5cGVJZCAhPSBudWxsICYmIHRoaXMubW9kZWxJbnB1dC5BZGRNb2RlbC5QYXlUeXBlSWQgIT0gXCJcIiAmJiB0aGlzLm1vZGVsSW5wdXQuQWRkTW9kZWwuUGF5VHlwZUlkICE9IHVuZGVmaW5lZFxyXG4gICAgICAgICAgICAmJiB0aGlzLm1vZGVsSW5wdXQuQWRkTW9kZWwuUHJvamVjdElkICE9IG51bGwgJiYgdGhpcy5tb2RlbElucHV0LkFkZE1vZGVsLlByb2plY3RJZCAhPSBcIlwiICYmIHRoaXMubW9kZWxJbnB1dC5BZGRNb2RlbC5Qcm9qZWN0SWQgIT0gdW5kZWZpbmVkXHJcbiAgICAgICAgICAgICYmIHRoaXMubW9kZWxJbnB1dC5BZGRNb2RlbC5Eb25hdGlvblR5cGVJZCAhPSBudWxsICYmIHRoaXMubW9kZWxJbnB1dC5BZGRNb2RlbC5Eb25hdGlvblR5cGVJZCAhPSBcIlwiICYmIHRoaXMubW9kZWxJbnB1dC5BZGRNb2RlbC5Eb25hdGlvblR5cGVJZCAhPSB1bmRlZmluZWRcclxuICAgICAgICAgICAgJiYgdGhpcy5tb2RlbElucHV0LkFkZE1vZGVsLkFjY291bnRJZCAhPSBudWxsICYmIHRoaXMubW9kZWxJbnB1dC5BZGRNb2RlbC5BY2NvdW50SWQgIT0gXCJcIiAmJiB0aGlzLm1vZGVsSW5wdXQuQWRkTW9kZWwuQWNjb3VudElkICE9IHVuZGVmaW5lZFxyXG4gICAgICAgICAgICAvLyYmIHRoaXMubW9kZWxJbnB1dC5BZGRNb2RlbC5CYW5rICE9IG51bGwgJiYgdGhpcy5tb2RlbElucHV0LkFkZE1vZGVsLkJhbmsgIT0gXCJcIiAmJiB0aGlzLm1vZGVsSW5wdXQuQWRkTW9kZWwuQmFuayAhPSB1bmRlZmluZWRcclxuICAgICAgICApIHtcclxuICAgICAgICAgICAgdmFyIFBheVR5cGUgPSB0aGlzLm1vZGVsSW5wdXQuQWRkTW9kZWwuUGF5VHlwZUlkLnRvU3RyaW5nKCkuc3BsaXQoJy0nKTtcclxuICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkFkZE1vZGVsLlBheVR5cGVJZCA9IFBheVR5cGVbMF07XHJcbiAgICAgICAgICAgIHZhciBQYXl0eXBlTmFtZSA9IFwiXCI7XHJcbiAgICAgICAgICAgIGZvciAodmFyIGkgPSAxOyBpIDwgUGF5VHlwZS5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgUGF5dHlwZU5hbWUgKz0gUGF5VHlwZVtpXStcIi1cIjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBkZWJ1Z2dlcjtcclxuICAgICAgICAgICAgdGhpcy5BZGRNb2RlbC5CYW5rSWQgPSBcIjBcIjtcclxuICAgICAgICAgICAgdGhpcy5BZGRNb2RlbC5EZXBvc2l0ZVJlbWFyayA9IGpRdWVyeShcIiNSZW1hcmtzXCIpLnZhbCgpO1xyXG4gICAgICAgICAgICB0aGlzLlJvd0NvdW50Kys7XHJcbiAgICAgICAgICAgIC8vYWxlcnQodGhpcy5Sb3dDb3VudC50b1N0cmluZygpKTtcclxuICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkFkZE1vZGVsLlJlY2llcHRSb1dJRCA9IHRoaXMuUm93Q291bnQ7XHJcbiAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5BZGRNb2RlbC5QYXlUeXBlID0gUGF5dHlwZU5hbWUuc3Vic3RyaW5nKDAsIFBheXR5cGVOYW1lLmxlbmd0aCAtIDEpO1xyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgdmFyIERvbmF0aW9uVHlwZSA9IHRoaXMubW9kZWxJbnB1dC5BZGRNb2RlbC5Eb25hdGlvblR5cGVJZC50b1N0cmluZygpLnNwbGl0KCctJyk7XHJcbiAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5BZGRNb2RlbC5Eb25hdGlvblR5cGVJZCA9IERvbmF0aW9uVHlwZVswXS50cmltKCk7XHJcbiAgICAgICAgICAgIHZhciBEb25hdGlvbk5hbWUgPSBcIlwiO1xyXG4gICAgICAgICAgICBmb3IgKHZhciBpID0gMTsgaSA8IERvbmF0aW9uVHlwZS5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgRG9uYXRpb25OYW1lICs9IERvbmF0aW9uVHlwZVtpXSArIFwiLVwiO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5BZGRNb2RlbC5Eb25hdGlvblR5cGUgPSBEb25hdGlvbk5hbWUuc3Vic3RyaW5nKDAsIERvbmF0aW9uTmFtZS5sZW5ndGggLSAxKTtcclxuXHJcbiAgICAgICAgICAgIHZhciBQcm9qZWN0ID0gdGhpcy5tb2RlbElucHV0LkFkZE1vZGVsLlByb2plY3RJZC50b1N0cmluZygpLnNwbGl0KCctJyk7XHJcbiAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5BZGRNb2RlbC5Qcm9qZWN0SWQgPSBQcm9qZWN0WzBdLnRyaW0oKTtcclxuICAgICAgICAgICAgdmFyIFByb2plY3ROYW1lID0gXCJcIjtcclxuICAgICAgICAgICAgZm9yICh2YXIgaSA9IDE7IGkgPCBQcm9qZWN0Lmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICBQcm9qZWN0TmFtZSArPSBQcm9qZWN0W2ldICsgXCItXCI7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkFkZE1vZGVsLlByb2plY3QgPSBQcm9qZWN0TmFtZS5zdWJzdHJpbmcoMCwgUHJvamVjdE5hbWUubGVuZ3RoIC0gMSk7XHJcblxyXG4gICAgICAgICAgICB2YXIgUHJvamVjdENhdGVnb3J5ID0gdGhpcy5tb2RlbElucHV0LkFkZE1vZGVsLlByb2plY3RDYXRlZ29yeUlkLnRvU3RyaW5nKCkuc3BsaXQoJy0nKTtcclxuICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkFkZE1vZGVsLlByb2plY3RDYXRlZ29yeUlkID0gUHJvamVjdENhdGVnb3J5WzBdLnRyaW0oKTtcclxuICAgICAgICAgICAgdmFyIFByb2plY3RDYXRlZ29yeU5hbWUgPSBcIlwiO1xyXG4gICAgICAgICAgICBmb3IgKHZhciBpID0gMTsgaSA8IFByb2plY3RDYXRlZ29yeS5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgUHJvamVjdENhdGVnb3J5TmFtZSArPSBQcm9qZWN0Q2F0ZWdvcnlbaV0gKyBcIi1cIjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQWRkTW9kZWwuUHJvamVjdENhdGVnb3J5ID0gUHJvamVjdENhdGVnb3J5TmFtZS5zdWJzdHJpbmcoMCwgUHJvamVjdENhdGVnb3J5TmFtZS5sZW5ndGggLSAxKTtcclxuXHJcbiAgICAgICAgICAgIHZhciBBY2NvdW50ID0gdGhpcy5tb2RlbElucHV0LkFkZE1vZGVsLkFjY291bnRJZC50b1N0cmluZygpLnNwbGl0KCctJyk7XHJcbiAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5BZGRNb2RlbC5BY2NvdW50SWQgPSBBY2NvdW50WzBdLnRyaW0oKTtcclxuICAgICAgICAgICAgdmFyIEFjY291bnROYW1lID0gXCJcIjtcclxuICAgICAgICAgICAgZm9yICh2YXIgaSA9IDE7IGkgPCBBY2NvdW50Lmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICBBY2NvdW50TmFtZSArPSBBY2NvdW50W2ldICsgXCItXCI7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkFkZE1vZGVsLkFjY291bnQgPSBBY2NvdW50TmFtZS5zdWJzdHJpbmcoMCwgQWNjb3VudE5hbWUubGVuZ3RoIC0gMSk7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICB0aGlzLk1vZGVsRGF0YS5wdXNoKHRoaXMubW9kZWxJbnB1dC5BZGRNb2RlbCk7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQWRkTW9kZWwgPSB7fTtcclxuXHJcbiAgICAgICAgICAgIGRlYnVnZ2VyO1xyXG4gICAgICAgICAgICB2YXIgUGF5VHlwZURlZmF1bHQ7XHJcbiAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMuX1BheVR5cGVzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5UZXh0LnRvTG93ZXJDYXNlKCkgPT0gXCJjYXNoXCIgfHwgdGhpcy5UZXh0ID09IFwi157XlteV157Xn1wiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgUGF5VHlwZURlZmF1bHQgPSB0aGlzLlZhbHVlICsgXCIgLSBcIiArIHRoaXMuVGV4dDtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLklzQmFua0RldFNob3cgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuSXNCYW5rRGV0U2hvdyA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkFkZE1vZGVsLlBheVR5cGVJZCA9IFBheVR5cGVEZWZhdWx0O1xyXG4gICAgICAgICAgICB0aGlzLklzQmFua0RldFNob3cgPSBmYWxzZTtcclxuICAgICAgICAgICAgLy92YXIgTW9kZWxPYmogPSB7IEFtb3VudDogXCJcIiwgVmFsdWVEYXRlOiBcIlwiLCBQYXlUeXBlOiBcIlwiLCBBY2NvdW50OiBcIlwiLCBBY2NvdW50TnVtYmVyOiBcIlwiLCBCcmFuY2g6IFwiXCIsIEJhbms6IFwiXCIsIENyZWRpdENhcmQ6IFwiXCIsIEdvYWw6IFwiXCIsIFByb2plY3RDYXRlZ29yeUlkOiBcIlwiLCBQcm9qZWN0SWQ6IFwiXCIsIFJlbWFya3M6IFwiXCIgfTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHZhciBtc2cgPSBcIlwiOyBcclxuICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5BZGRNb2RlbC5BbW91bnQgPT0gbnVsbCB8fCB0aGlzLm1vZGVsSW5wdXQuQWRkTW9kZWwuQW1vdW50ID09IFwiXCIgfHwgdGhpcy5tb2RlbElucHV0LkFkZE1vZGVsLkFtb3VudCA9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgIG1zZyArPSBcIjxicj5QbGVhc2UgZW50ZXIgYW1vdW50XCI7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5BZGRNb2RlbC5QYXlUeXBlSWQgPT0gbnVsbCB8fCB0aGlzLm1vZGVsSW5wdXQuQWRkTW9kZWwuUGF5VHlwZUlkID09IFwiXCIgfHwgdGhpcy5tb2RlbElucHV0LkFkZE1vZGVsLlBheVR5cGVJZCA9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgIG1zZyArPSBcIjxicj5QbGVhc2Ugc2VsZWN0IHBheXR5cGVcIjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkFkZE1vZGVsLlByb2plY3RJZCA9PSBudWxsIHx8IHRoaXMubW9kZWxJbnB1dC5BZGRNb2RlbC5Qcm9qZWN0SWQgPT0gXCJcIiB8fCB0aGlzLm1vZGVsSW5wdXQuQWRkTW9kZWwuUHJvamVjdElkID09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgbXNnICs9IFwiPGJyPlBsZWFzZSBzZWxlY3QgcHJvamVjdFwiO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQWRkTW9kZWwuRG9uYXRpb25UeXBlSWQgPT0gbnVsbCB8fCB0aGlzLm1vZGVsSW5wdXQuQWRkTW9kZWwuRG9uYXRpb25UeXBlSWQgPT0gXCJcIiB8fCB0aGlzLm1vZGVsSW5wdXQuQWRkTW9kZWwuRG9uYXRpb25UeXBlSWQgPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgICAgICBtc2cgKz0gXCI8YnI+UGxlYXNlIHNlbGVjdCBnb2FsXCI7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5BZGRNb2RlbC5BY2NvdW50SWQgPT0gbnVsbCB8fCB0aGlzLm1vZGVsSW5wdXQuQWRkTW9kZWwuQWNjb3VudElkID09IFwiXCIgfHwgdGhpcy5tb2RlbElucHV0LkFkZE1vZGVsLkFjY291bnRJZCA9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgIG1zZyArPSBcIjxicj5QbGVhc2Ugc2VsZWN0IGFjY291bnRcIjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkFkZE1vZGVsLkJhbmtJZCA9PSBudWxsIHx8IHRoaXMubW9kZWxJbnB1dC5BZGRNb2RlbC5CYW5rSWQgPT0gXCJcIiB8fCB0aGlzLm1vZGVsSW5wdXQuQWRkTW9kZWwuQmFua0lkID09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgbXNnICs9IFwiPGJyPlBsZWFzZSBzZWxlY3QgYmFua1wiO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8vaWYgKHRoaXMubW9kZWxJbnB1dC5BZGRNb2RlbC5Hb2FsID09IG51bGwgfHwgdGhpcy5tb2RlbElucHV0LkFkZE1vZGVsLkdvYWwgPT0gXCJcIiB8fCB0aGlzLm1vZGVsSW5wdXQuQWRkTW9kZWwuR29hbCA9PSB1bmRlZmluZWQpIHtcclxuXHJcbiAgICAgICAgICAgIC8vfVxyXG4gICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgIG1lc3NhZ2U6IG1zZyxcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgT3Blbk5vdGVzKCkge1xyXG4gICAgICAgIGpRdWVyeSgnI05vdGVNb2RhbCcpLm9wZW5Nb2RhbCgpO1xyXG4gICAgfVxyXG4gICAgT3BlblRlbXBsYXRlcygpIHtcclxuXHJcbiAgICAgICAgalF1ZXJ5KCcjVGVtcGxhdGVNb2RhbCcpLm9wZW5Nb2RhbCgpO1xyXG4gICAgfVxyXG4gICAgQ2hvb3NlTm90ZShvYmpjdCkge1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lck5vdGUgPSBvYmpjdC5UZXh0O1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lck5vdGVJZCA9IG9iamN0LlZhbHVlO1xyXG4gICAgfVxyXG4gICAgQ2hvb3NlVGhhbmtzTGV0dGVycyhvYmpjdCkge1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5UaGFua3NMZXR0ZXJOYW1lID0gb2JqY3QuVGV4dDtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuVGhhbmtzTGV0dGVySWQgPSBvYmpjdC5WYWx1ZTtcclxuICAgIH1cclxuICAgIEdldEN1c3RvbWVyRGV0YWlsKCkge1xyXG4gICAgICAgIHZhciBDdXN0SWQgPSB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZDtcclxuICAgICAgICB0aGlzLl9DdXN0b21lclNlcnZpY2UuR2V0Q29tcGxldGVDdXN0RGV0KEN1c3RJZCkuc3Vic2NyaWJlKHJlc3A9PiB7XHJcbiAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgIHZhciByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcCk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHJlc3BvbnNlID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX0FkZHJlc3NlcyA9IHJlc3BvbnNlLkN1c3RvbWVyQWRkcmVzc2VzO1xyXG4gICAgICAgICAgICAgICAgdmFyIE1haW5hZGRyZXNzO1xyXG4gICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2gocmVzcG9uc2UuQ3VzdG9tZXJBZGRyZXNzZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5NYWluQWRkcmVzcyA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIE1haW5hZGRyZXNzID0gdGhpcy5BZGRyZXNzSWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5BZGRyZXNzSWQgPSBNYWluYWRkcmVzcztcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkID0gcmVzcG9uc2UuQ3VzdG9tZXJJZDtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lck5hbWUgPSByZXNwb25zZS5sbmFtZSArIFwiIFwiICsgcmVzcG9uc2UuZm5hbWU7XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIFxyXG4gICAgfVxyXG4gICAgQmluZFByb2plY3RzKCkge1xyXG4gICAgICAgIHZhciBDYXREZXQgPSBqUXVlcnkoXCIjUHJvamVjdENhdGVnb3J5XCIpLnZhbCgpO1xyXG4gICAgICAgIHZhciBDYXRJZHMgPSBDYXREZXQuc3BsaXQoJy0nKTtcclxuICAgICAgICB2YXIgQ2F0SWQgPSBDYXRJZHNbMF0udHJpbSgpO1xyXG4gICAgICAgIHRoaXMuQmluZFByb2plY3RGcm9tUHJvakNhdChDYXRJZCk7XHJcbiAgICB9XHJcbiAgICBCaW5kUHJvamVjdEZyb21Qcm9qQ2F0KENhdElkKSB7XHJcbiAgICAgICAgdGhpcy5fUmVjaWVwdFNlcnZpY2UuR2V0UHJvamVjdHMoQ2F0SWQpLnN1YnNjcmliZShyZXNwPT4ge1xyXG4gICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICB2YXIgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3ApO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9Qcm9qZWN0cyA9IHJlc3BvbnNlLkRhdGE7XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG4gICAgbmdPbkluaXQoKSB7XHJcbiAgICAgICAgd2luZG93LnNjcm9sbFRvKDAsIDApO1xyXG4gICAgIFxyXG4gICAgICAvLyAgYWxlcnQoXCJkZGRcIik7XHJcbiAgICAgICAgdGhpcy5MYW5nID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJsYW5nXCIpO1xyXG4gICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5HZXRMYW5nUmVzKHRoaXMuRm9ybXR5cGUsIHRoaXMuTGFuZykuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5SRVMgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMuX1JlY2llcHRTZXJ2aWNlLkdldEN1c3RvbWVyTm90ZXMoKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fQ3VzdG9tZXJOb3RlcyA9IHJlc3BvbnNlLkRhdGE7XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHRoaXMuX1JlY2llcHRTZXJ2aWNlLkdldEJhbmtzKCkuc3Vic2NyaWJlKHJlc3A9PiB7XHJcbiAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgIHZhciByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcCk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIC8vdGhpcy5fQmFua3MgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgdmFyIHR5cGVhaGVhZFNvdXJjZSA9IFtdO1xyXG4gICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2gocmVzcG9uc2UuRGF0YSwgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBuZXd0ZW1wID0ge307XHJcbiAgICAgICAgICAgICAgICAgICAgbmV3dGVtcC5pZCA9IHRoaXMuVmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgbmV3dGVtcC5uYW1lID0gdGhpcy5UZXh0O1xyXG4gICAgICAgICAgICAgICAgICAgIHR5cGVhaGVhZFNvdXJjZS5wdXNoKG5ld3RlbXApO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9CYW5rcyA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICBqUXVlcnkoJyNCYW5rJykudHlwZWFoZWFkKHtcclxuICAgICAgICAgICAgICAgICAgICAvL2RhdGE6IHRoaXMuX0NpdGllcyxcclxuICAgICAgICAgICAgICAgICAgICBzb3VyY2U6IHR5cGVhaGVhZFNvdXJjZSxcclxuICAgICAgICAgICAgICAgICAgICAvL2Rpc3BsYXk6IFwidGV4dFwiLFxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGFUeXBlOiBcIkpTT05cIixcclxuICAgICAgICAgICAgICAgICAgICAvL2hpbnQ6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgLy9oaWdobGlnaHQ6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgLy9taW5MZW5ndGg6IDEsXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuXHJcblxyXG4gICAgICAgIHRoaXMuX1JlY2llcHRTZXJ2aWNlLkdldFRoYW5rc0xldHRlcnModGhpcy5tb2RlbElucHV0LlJlY2VpcHRUeXBlSWQpLnN1YnNjcmliZShyZXNwPT4ge1xyXG4gICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICB2YXIgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3ApO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9UaGFua0xldHRlcnMgPSByZXNwb25zZS5EYXRhO1xyXG5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuICAgICAgICB0aGlzLl9SZWNpZXB0U2VydmljZS5HZXRBc3NvY2lhdGlvbigpLnN1YnNjcmliZShyZXNwPT4ge1xyXG4gICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICB2YXIgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3ApO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LmFzc29jaWF0aW9uSWQgPSByZXNwb25zZS5EYXRhWzBdLlZhbHVlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LmFzc29jaWF0aW9uTmFtZSA9IHJlc3BvbnNlLkRhdGFbMF0uVGV4dDtcclxuXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgdGhpcy5fUmVjaWVwdFNlcnZpY2UuR2V0UHJpbnRlcigpLnN1YnNjcmliZShyZXNwPT4ge1xyXG4gICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICB2YXIgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3ApO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LlByaW50ZXJJZCA9IHJlc3BvbnNlLkRhdGFbMF0uVmFsdWU7XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHRoaXMuX1JlY2llcHRTZXJ2aWNlLkdldEVtcGxveWVlKCkuc3Vic2NyaWJlKHJlc3A9PiB7XHJcbiAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgIHZhciByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcCk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuRW1wbG95ZWVJZCA9IHJlc3BvbnNlLkRhdGFbMF0uVmFsdWU7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuRW1wbG95ZWVOYW1lID0gcmVzcG9uc2UuRGF0YVswXS5UZXh0O1xyXG5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuICAgICAgICB0aGlzLl9SZWNpZXB0U2VydmljZS5HZXRQYXlUeXBlKCkuc3Vic2NyaWJlKHJlc3A9PiB7XHJcbiAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgIHZhciByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcCk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX1BheVR5cGVzID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgIHZhciBQYXlUeXBlRGVmYXVsdDtcclxuICAgICAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMuX1BheVR5cGVzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuVGV4dC50b0xvd2VyQ2FzZSgpID09IFwiY2FzaFwiIHx8IHRoaXMuVGV4dCA9PSBcItee15bXldee159cIikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBQYXlUeXBlRGVmYXVsdCA9IHRoaXMuVmFsdWUgKyBcIiAtIFwiICsgdGhpcy5UZXh0O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLklzQmFua0RldFNob3cgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLklzQmFua0RldFNob3cgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5BZGRNb2RlbC5QYXlUeXBlSWQgPSBQYXlUeXBlRGVmYXVsdDtcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICB0aGlzLl9SZWNpZXB0U2VydmljZS5HZXRBY2NvdW50cygpLnN1YnNjcmliZShyZXNwPT4ge1xyXG4gICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICB2YXIgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3ApO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9BY2NvdW50cyA9IHJlc3BvbnNlLkRhdGE7XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICB0aGlzLl9SZWNpZXB0U2VydmljZS5HZXRHb2FscygpLnN1YnNjcmliZShyZXNwPT4ge1xyXG4gICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICB2YXIgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3ApO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9Hb2FscyA9IHJlc3BvbnNlLkRhdGE7XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICB0aGlzLl9SZWNpZXB0U2VydmljZS5HZXRQcm9qZWN0Q2F0cygpLnN1YnNjcmliZShyZXNwPT4ge1xyXG4gICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICB2YXIgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3ApO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9Qcm9qZWN0Q2F0cyA9IHJlc3BvbnNlLkRhdGE7XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHRoaXMuQmluZFByb2plY3RGcm9tUHJvakNhdCgtMSk7XHJcbiAgICAgICAgdGhpcy5fUmVjaWVwdFNlcnZpY2UuR2V0Q3VycmVuY2llc0ZEQigpLnN1YnNjcmliZShyZXNwPT4ge1xyXG4gICAgICAgICAgICB2YXIgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3ApO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9DdXJyZW5jaWVzID0gcmVzcG9uc2UuRGF0YTtcclxuXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgdGhpcy5fUmVjaWVwdFNlcnZpY2UuR2V0UmVjaWVwdFR5cGUodGhpcy5fcm91dGVQYXJhbXMucGFyYW1zLlJlY2VpcHRUeXBlSWQpLnN1YnNjcmliZShyZXNwPT4ge1xyXG4gICAgICAgICAgIC8vIGRlYnVnZ2VyO1xyXG4gICAgICAgICAgICB2YXIgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3ApO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuUmVjaWVwdFR5cGUgPSByZXNwb25zZS5EYXRhWzBdLlJlY2llcHROYW1lRW5nO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1cnJlbmN5SWQgPSByZXNwb25zZS5EYXRhWzBdLkN1cnJlbmN5SWQ7XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgdGhpcy5fUmVjaWVwdFNlcnZpY2UuR2V0UmVjZWlwdERldGFpbCgpLnN1YnNjcmliZShyZXNwPT4ge1xyXG4gICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICB2YXIgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3ApO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuUmVjaWVwdE5vID0gcmVzcG9uc2UuRGF0YS5WYWx1ZTtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5SZWNpZXB0RGF0ZSA9IHJlc3BvbnNlLkRhdGEuVGV4dDtcclxuXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgdmFyIEN1c3RJZCA9IHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkO1xyXG4gICAgICAgIHRoaXMuR2V0Q3VzdG9tZXJEZXRhaWwoQ3VzdElkKTtcclxuXHJcbiAgICB9XHJcbn1cclxuIl19
