System.register(["angular2/core", 'angular2/common', "../../services/ResourceService", "angular2/router", "../../services/RecieptService"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, common_1, ResourceService_1, router_1, RecieptService_1;
    var AmaxReceiptSelect;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (ResourceService_1_1) {
                ResourceService_1 = ResourceService_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (RecieptService_1_1) {
                RecieptService_1 = RecieptService_1_1;
            }],
        execute: function() {
            AmaxReceiptSelect = (function () {
                // @ViewChild('RTLDiv') private myScrollContainer: ElementRef;
                function AmaxReceiptSelect(_resourceService, _RecieptService, _routeParams) {
                    this._resourceService = _resourceService;
                    this._RecieptService = _RecieptService;
                    this._routeParams = _routeParams;
                    this.RES = {};
                    this.Formtype = "SCREEN_RECEIPTCHOOSE";
                    this.Lang = "";
                    this.RecieptMode = "1";
                    this._RecieptModes = [];
                    this._Reciepts = [];
                    this.ReceiptTypeId = "-1";
                    this.EmployeeId = "";
                    this.MsgClass = "text-primary";
                    this.modelInput = {};
                    this.ChangeDialog = "";
                    this.CHANGEDIR = "";
                    this.BaseAppUrl = "";
                    this.RES.SCREEN_RECEIPTCHOOSE = {};
                    this.ReceiptTypeId = "-1";
                    this.modelInput = {};
                    //this.baseUrl = "http://localhost:3000/#/";
                    //debugger;
                    this.baseUrl = _resourceService.AppUrl;
                    this.EmployeeId = _routeParams.params.Id;
                    this.RecieptMode = "1";
                    this.BaseAppUrl = _resourceService.AppUrl;
                }
                AmaxReceiptSelect.prototype.NextPage = function () {
                    if (this.ReceiptTypeId != "-1") {
                        var CustId = this._routeParams.params.CustId;
                        document.location = this.BaseAppUrl + "ReceiptCreate/" + CustId + "/" + this.ReceiptTypeId;
                    }
                    else {
                        bootbox.alert({
                            message: "Please select Receipt Name and then click on Next button",
                            className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                    }
                };
                AmaxReceiptSelect.prototype.SelectReceipt = function (RecTypeId) {
                    this.ReceiptTypeId = RecTypeId;
                    //alert(this.ReceiptTypeId);
                    this._resourceService.setCookie("ReceiptTypeIdLast_" + this.EmployeeId, this.ReceiptTypeId, 7);
                };
                AmaxReceiptSelect.prototype.GetReceipts = function (RModel) {
                    var _this = this;
                    this._resourceService.setCookie("ReceiptModeLast_" + this.EmployeeId, RModel, 7);
                    this._RecieptService.GetReceipts(this.EmployeeId, RModel).subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            //debugger;
                            _this._Reciepts = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxReceiptSelect.prototype.ngOnInit = function () {
                    var _this = this;
                    //  alert("ddd");
                    this.Lang = localStorage.getItem("lang");
                    this._resourceService.GetLangRes(this.Formtype, this.Lang).subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.RES = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._RecieptService.GetRecieptModes().subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._RecieptModes = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //if (this.EmployeeId != "") {
                    //debugger;
                    var getMode = this._resourceService.getCookie("ReceiptModeLast_" + this.EmployeeId);
                    if (getMode.length > 0) {
                        this.RecieptMode = getMode.substring(1, getMode.length);
                        if (this.RecieptMode == "4")
                            this.RecieptMode = "1";
                    }
                    else {
                        this.RecieptMode = "1";
                    }
                    this.GetReceipts(this.RecieptMode);
                    var getRecId = this._resourceService.getCookie("ReceiptTypeIdLast_" + this.EmployeeId);
                    if (getRecId.length > 0) {
                        this.ReceiptTypeId = getRecId.substring(1, getRecId.length);
                    }
                    else {
                        this.ReceiptTypeId = "-1";
                    }
                    var rrmode = this.RecieptMode;
                    var recid = this.ReceiptTypeId;
                    window.setTimeout(function () {
                        //alert(rrmode);
                        jQuery("input[name=recmode][value=" + rrmode + "]").prop("checked", true);
                        jQuery("input[name=ReceiptTypeId][value=" + recid + "]").prop("checked", true);
                    }, 1000);
                    //}
                };
                AmaxReceiptSelect.$inject = ['$scope', '$location', '$anchorScroll'];
                AmaxReceiptSelect = __decorate([
                    core_1.Component({
                        templateUrl: './app/amax/Receipt/templates/ReceiptSelect.html',
                        directives: [common_1.NgSwitch, common_1.NgSwitchWhen, common_1.NgSwitchDefault],
                        providers: [RecieptService_1.RecieptService, ResourceService_1.ResourceService]
                    }), 
                    __metadata('design:paramtypes', [ResourceService_1.ResourceService, RecieptService_1.RecieptService, router_1.RouteParams])
                ], AmaxReceiptSelect);
                return AmaxReceiptSelect;
            }());
            exports_1("AmaxReceiptSelect", AmaxReceiptSelect);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldi9hbWF4L1JlY2VpcHQvUmVjZWlwdFNlbGVjdC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztZQWlCQTtnQkFnQkcsOERBQThEO2dCQUM3RCwyQkFBb0IsZ0JBQWlDLEVBQVUsZUFBK0IsRUFBVSxZQUF5QjtvQkFBN0cscUJBQWdCLEdBQWhCLGdCQUFnQixDQUFpQjtvQkFBVSxvQkFBZSxHQUFmLGVBQWUsQ0FBZ0I7b0JBQVUsaUJBQVksR0FBWixZQUFZLENBQWE7b0JBZmpJLFFBQUcsR0FBVyxFQUFFLENBQUM7b0JBQ2pCLGFBQVEsR0FBVyxzQkFBc0IsQ0FBQztvQkFDMUMsU0FBSSxHQUFXLEVBQUUsQ0FBQztvQkFDbEIsZ0JBQVcsR0FBVyxHQUFHLENBQUM7b0JBQzFCLGtCQUFhLEdBQUcsRUFBRSxDQUFDO29CQUNuQixjQUFTLEdBQUcsRUFBRSxDQUFDO29CQUNmLGtCQUFhLEdBQVcsSUFBSSxDQUFDO29CQUM3QixlQUFVLEdBQVcsRUFBRSxDQUFDO29CQUN4QixhQUFRLEdBQVcsY0FBYyxDQUFDO29CQUNsQyxlQUFVLEdBQVcsRUFBRSxDQUFDO29CQUN4QixpQkFBWSxHQUFXLEVBQUUsQ0FBQztvQkFDMUIsY0FBUyxHQUFXLEVBQUUsQ0FBQztvQkFDdkIsZUFBVSxHQUFXLEVBQUUsQ0FBQztvQkFLcEIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsR0FBRyxFQUFFLENBQUM7b0JBQ25DLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO29CQUMxQixJQUFJLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztvQkFDckIsNENBQTRDO29CQUM1QyxXQUFXO29CQUNYLElBQUksQ0FBQyxPQUFPLEdBQUcsZ0JBQWdCLENBQUMsTUFBTSxDQUFDO29CQUN2QyxJQUFJLENBQUMsVUFBVSxHQUFHLFlBQVksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO29CQUN6QyxJQUFJLENBQUMsV0FBVyxHQUFHLEdBQUcsQ0FBQztvQkFDdkIsSUFBSSxDQUFDLFVBQVUsR0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUM7Z0JBQzVDLENBQUM7Z0JBQ0Qsb0NBQVEsR0FBUjtvQkFDSSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7d0JBQzdCLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQzt3QkFDN0MsUUFBUSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsVUFBVSxHQUFHLGdCQUFnQixHQUFHLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQztvQkFDL0YsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixPQUFPLENBQUMsS0FBSyxDQUFDOzRCQUNWLE9BQU8sRUFBRSwwREFBMEQ7NEJBQ25FLFNBQVMsRUFBRSxJQUFJLENBQUMsWUFBWTs0QkFDNUIsT0FBTyxFQUFFO2dDQUNMLEVBQUUsRUFBRTtvQ0FDQSxjQUFjO29DQUNkLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUztpQ0FDNUI7NkJBQ0o7eUJBQ0osQ0FBQyxDQUFDO29CQUVQLENBQUM7Z0JBQ0wsQ0FBQztnQkFDRCx5Q0FBYSxHQUFiLFVBQWMsU0FBUztvQkFDbkIsSUFBSSxDQUFDLGFBQWEsR0FBRyxTQUFTLENBQUM7b0JBQy9CLDRCQUE0QjtvQkFDNUIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxvQkFBb0IsR0FBRyxJQUFJLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0JBQ25HLENBQUM7Z0JBQ0QsdUNBQVcsR0FBWCxVQUFZLE1BQU07b0JBQWxCLGlCQTJCQztvQkExQkcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxrQkFBa0IsR0FBRyxJQUFJLENBQUMsVUFBVSxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQztvQkFDakYsSUFBSSxDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxNQUFNLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUNwRSxXQUFXO3dCQUNYLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsV0FBVzs0QkFDWCxLQUFJLENBQUMsU0FBUyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7d0JBRW5DLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7Z0JBQ1AsQ0FBQztnQkFFRCxvQ0FBUSxHQUFSO29CQUFBLGlCQThFQztvQkE3RUMsaUJBQWlCO29CQUNmLElBQUksQ0FBQyxJQUFJLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDekMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUV6RSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtnQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUM1QixPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsR0FBRyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7d0JBQzdCLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBRUgsSUFBSSxDQUFDLGVBQWUsQ0FBQyxlQUFlLEVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUNqRCxXQUFXO3dCQUNYLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLGFBQWEsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO3dCQUV2QyxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUNILDhCQUE4QjtvQkFDOUIsV0FBVztvQkFDWCxJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztvQkFDcEYsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUNyQixJQUFJLENBQUMsV0FBVyxHQUFHLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQzt3QkFDeEQsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsSUFBSSxHQUFHLENBQUM7NEJBQUMsSUFBSSxDQUFDLFdBQVcsR0FBRyxHQUFHLENBQUM7b0JBQ3hELENBQUM7b0JBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ0osSUFBSSxDQUFDLFdBQVcsR0FBRyxHQUFHLENBQUM7b0JBQzNCLENBQUM7b0JBQ0QsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7b0JBRW5DLElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsb0JBQW9CLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO29CQUN2RixFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ3RCLElBQUksQ0FBQyxhQUFhLEdBQUcsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUNoRSxDQUFDO29CQUFDLElBQUksQ0FBQyxDQUFDO3dCQUNKLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO29CQUM5QixDQUFDO29CQUNELElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUM7b0JBQzlCLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUM7b0JBRS9CLE1BQU0sQ0FBQyxVQUFVLENBQUM7d0JBQ2QsZ0JBQWdCO3dCQUNoQixNQUFNLENBQUMsNEJBQTRCLEdBQUcsTUFBTSxHQUFHLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7d0JBQzFFLE1BQU0sQ0FBQyxrQ0FBa0MsR0FBRyxLQUFLLEdBQUcsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQztvQkFDbkYsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO29CQUVULEdBQUc7Z0JBQ1AsQ0FBQztnQkFqSk0seUJBQU8sR0FBRyxDQUFDLFFBQVEsRUFBRSxXQUFXLEVBQUUsZUFBZSxDQUFDLENBQUM7Z0JBdEI5RDtvQkFBQyxnQkFBUyxDQUFDO3dCQUVQLFdBQVcsRUFBRSxpREFBaUQ7d0JBQzlELFVBQVUsRUFBRSxDQUFDLGlCQUFRLEVBQUUscUJBQVksRUFBRSx3QkFBZSxDQUFDO3dCQUNyRCxTQUFTLEVBQUUsQ0FBQywrQkFBYyxFQUFFLGlDQUFlLENBQUM7cUJBQy9DLENBQUM7O3FDQUFBO2dCQW1LRix3QkFBQztZQUFELENBaktBLEFBaUtDLElBQUE7WUFqS0QsaURBaUtDLENBQUEiLCJmaWxlIjoiZGV2L2FtYXgvUmVjZWlwdC9SZWNlaXB0U2VsZWN0LmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtDb21wb25lbnQsIE91dHB1dCwgSW5wdXQsIEV2ZW50RW1pdHRlciwgT25Jbml0fSBmcm9tIFwiYW5ndWxhcjIvY29yZVwiO1xyXG5pbXBvcnQge05nU3dpdGNoLCBOZ1N3aXRjaFdoZW4sIE5nU3dpdGNoRGVmYXVsdH0gZnJvbSAnYW5ndWxhcjIvY29tbW9uJ1xyXG5pbXBvcnQge1Jlc291cmNlU2VydmljZX0gZnJvbSBcIi4uLy4uL3NlcnZpY2VzL1Jlc291cmNlU2VydmljZVwiO1xyXG5pbXBvcnQge1JvdXRlUGFyYW1zfSBmcm9tIFwiYW5ndWxhcjIvcm91dGVyXCI7XHJcbmltcG9ydCB7UmVjaWVwdFNlcnZpY2V9IGZyb20gXCIuLi8uLi9zZXJ2aWNlcy9SZWNpZXB0U2VydmljZVwiO1xyXG5pbXBvcnQgeyBqc29uUSB9IGZyb20gJy4uLy4uL2pzb25RJztcclxuaW1wb3J0IHtHcm91cEZpbHRlclBpcGUsIEdyb3VwUGFyZW5GaWx0ZXJQaXBlLCBLZW5kb191dGlsaXR5fSBmcm9tIFwiLi4vLi4vYW1heFV0aWxcIjtcclxuXHJcbmRlY2xhcmUgdmFyIGpRdWVyeTtcclxuXHJcbkBDb21wb25lbnQoe1xyXG5cclxuICAgIHRlbXBsYXRlVXJsOiAnLi9hcHAvYW1heC9SZWNlaXB0L3RlbXBsYXRlcy9SZWNlaXB0U2VsZWN0Lmh0bWwnLFxyXG4gICAgZGlyZWN0aXZlczogW05nU3dpdGNoLCBOZ1N3aXRjaFdoZW4sIE5nU3dpdGNoRGVmYXVsdF0sXHJcbiAgICBwcm92aWRlcnM6IFtSZWNpZXB0U2VydmljZSwgUmVzb3VyY2VTZXJ2aWNlXVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEFtYXhSZWNlaXB0U2VsZWN0IGltcGxlbWVudHMgT25Jbml0IHtcclxuICAgIGJhc2VVcmw6IHN0cmluZztcclxuICAgIFJFUzogT2JqZWN0ID0ge307XHJcbiAgICBGb3JtdHlwZTogc3RyaW5nID0gXCJTQ1JFRU5fUkVDRUlQVENIT09TRVwiO1xyXG4gICAgTGFuZzogc3RyaW5nID0gXCJcIjtcclxuICAgIFJlY2llcHRNb2RlOiBzdHJpbmcgPSBcIjFcIjtcclxuICAgIF9SZWNpZXB0TW9kZXMgPSBbXTtcclxuICAgIF9SZWNpZXB0cyA9IFtdO1xyXG4gICAgUmVjZWlwdFR5cGVJZDogc3RyaW5nID0gXCItMVwiO1xyXG4gICAgRW1wbG95ZWVJZDogc3RyaW5nID0gXCJcIjtcclxuICAgIE1zZ0NsYXNzOiBzdHJpbmcgPSBcInRleHQtcHJpbWFyeVwiO1xyXG4gICAgbW9kZWxJbnB1dDogT2JqZWN0ID0ge307XHJcbiAgICBDaGFuZ2VEaWFsb2c6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBDSEFOR0VESVI6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBCYXNlQXBwVXJsOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgc3RhdGljICRpbmplY3QgPSBbJyRzY29wZScsICckbG9jYXRpb24nLCAnJGFuY2hvclNjcm9sbCddO1xyXG4gICAvLyBAVmlld0NoaWxkKCdSVExEaXYnKSBwcml2YXRlIG15U2Nyb2xsQ29udGFpbmVyOiBFbGVtZW50UmVmO1xyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBfcmVzb3VyY2VTZXJ2aWNlOiBSZXNvdXJjZVNlcnZpY2UsIHByaXZhdGUgX1JlY2llcHRTZXJ2aWNlOiBSZWNpZXB0U2VydmljZSwgcHJpdmF0ZSBfcm91dGVQYXJhbXM6IFJvdXRlUGFyYW1zKSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5SRVMuU0NSRUVOX1JFQ0VJUFRDSE9PU0UgPSB7fTtcclxuICAgICAgICB0aGlzLlJlY2VpcHRUeXBlSWQgPSBcIi0xXCI7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0ID0ge307XHJcbiAgICAgICAgLy90aGlzLmJhc2VVcmwgPSBcImh0dHA6Ly9sb2NhbGhvc3Q6MzAwMC8jL1wiO1xyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgdGhpcy5iYXNlVXJsID0gX3Jlc291cmNlU2VydmljZS5BcHBVcmw7XHJcbiAgICAgICAgdGhpcy5FbXBsb3llZUlkID0gX3JvdXRlUGFyYW1zLnBhcmFtcy5JZDtcclxuICAgICAgICB0aGlzLlJlY2llcHRNb2RlID0gXCIxXCI7XHJcbiAgICAgICAgdGhpcy5CYXNlQXBwVXJsPV9yZXNvdXJjZVNlcnZpY2UuQXBwVXJsO1xyXG4gICAgfVxyXG4gICAgTmV4dFBhZ2UoKSB7XHJcbiAgICAgICAgaWYgKHRoaXMuUmVjZWlwdFR5cGVJZCAhPSBcIi0xXCIpIHtcclxuICAgICAgICAgICAgdmFyIEN1c3RJZCA9IHRoaXMuX3JvdXRlUGFyYW1zLnBhcmFtcy5DdXN0SWQ7XHJcbiAgICAgICAgICAgIGRvY3VtZW50LmxvY2F0aW9uID0gdGhpcy5CYXNlQXBwVXJsICsgXCJSZWNlaXB0Q3JlYXRlL1wiICsgQ3VzdElkICsgXCIvXCIgKyB0aGlzLlJlY2VpcHRUeXBlSWQ7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiUGxlYXNlIHNlbGVjdCBSZWNlaXB0IE5hbWUgYW5kIHRoZW4gY2xpY2sgb24gTmV4dCBidXR0b25cIixcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIFNlbGVjdFJlY2VpcHQoUmVjVHlwZUlkKSB7XHJcbiAgICAgICAgdGhpcy5SZWNlaXB0VHlwZUlkID0gUmVjVHlwZUlkO1xyXG4gICAgICAgIC8vYWxlcnQodGhpcy5SZWNlaXB0VHlwZUlkKTtcclxuICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2Uuc2V0Q29va2llKFwiUmVjZWlwdFR5cGVJZExhc3RfXCIgKyB0aGlzLkVtcGxveWVlSWQsIHRoaXMuUmVjZWlwdFR5cGVJZCwgNyk7ICAgXHJcbiAgICB9XHJcbiAgICBHZXRSZWNlaXB0cyhSTW9kZWwpIHtcclxuICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2Uuc2V0Q29va2llKFwiUmVjZWlwdE1vZGVMYXN0X1wiICsgdGhpcy5FbXBsb3llZUlkLCBSTW9kZWwsIDcpOyAgIFxyXG4gICAgICAgIHRoaXMuX1JlY2llcHRTZXJ2aWNlLkdldFJlY2VpcHRzKHRoaXMuRW1wbG95ZWVJZCwgUk1vZGVsKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgIHRoaXMuX1JlY2llcHRzID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25Jbml0KCkge1xyXG4gICAgICAvLyAgYWxlcnQoXCJkZGRcIik7XHJcbiAgICAgICAgdGhpcy5MYW5nID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJsYW5nXCIpO1xyXG4gICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5HZXRMYW5nUmVzKHRoaXMuRm9ybXR5cGUsIHRoaXMuTGFuZykuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5SRVMgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICB0aGlzLl9SZWNpZXB0U2VydmljZS5HZXRSZWNpZXB0TW9kZXMoKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fUmVjaWVwdE1vZGVzID0gcmVzcG9uc2UuRGF0YTtcclxuXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgLy9pZiAodGhpcy5FbXBsb3llZUlkICE9IFwiXCIpIHtcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgIHZhciBnZXRNb2RlID0gdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmdldENvb2tpZShcIlJlY2VpcHRNb2RlTGFzdF9cIiArIHRoaXMuRW1wbG95ZWVJZCk7XHJcbiAgICAgICAgaWYgKGdldE1vZGUubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICB0aGlzLlJlY2llcHRNb2RlID0gZ2V0TW9kZS5zdWJzdHJpbmcoMSwgZ2V0TW9kZS5sZW5ndGgpO1xyXG4gICAgICAgICAgICBpZiAodGhpcy5SZWNpZXB0TW9kZSA9PSBcIjRcIikgdGhpcy5SZWNpZXB0TW9kZSA9IFwiMVwiO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuUmVjaWVwdE1vZGUgPSBcIjFcIjtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5HZXRSZWNlaXB0cyh0aGlzLlJlY2llcHRNb2RlKTtcclxuXHJcbiAgICAgICAgdmFyIGdldFJlY0lkID0gdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmdldENvb2tpZShcIlJlY2VpcHRUeXBlSWRMYXN0X1wiICsgdGhpcy5FbXBsb3llZUlkKTtcclxuICAgICAgICBpZiAoZ2V0UmVjSWQubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICB0aGlzLlJlY2VpcHRUeXBlSWQgPSBnZXRSZWNJZC5zdWJzdHJpbmcoMSwgZ2V0UmVjSWQubGVuZ3RoKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLlJlY2VpcHRUeXBlSWQgPSBcIi0xXCI7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHZhciBycm1vZGUgPSB0aGlzLlJlY2llcHRNb2RlO1xyXG4gICAgICAgIHZhciByZWNpZCA9IHRoaXMuUmVjZWlwdFR5cGVJZDtcclxuXHJcbiAgICAgICAgd2luZG93LnNldFRpbWVvdXQoZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAvL2FsZXJ0KHJybW9kZSk7XHJcbiAgICAgICAgICAgIGpRdWVyeShcImlucHV0W25hbWU9cmVjbW9kZV1bdmFsdWU9XCIgKyBycm1vZGUgKyBcIl1cIikucHJvcChcImNoZWNrZWRcIiwgdHJ1ZSk7XHJcbiAgICAgICAgICAgIGpRdWVyeShcImlucHV0W25hbWU9UmVjZWlwdFR5cGVJZF1bdmFsdWU9XCIgKyByZWNpZCArIFwiXVwiKS5wcm9wKFwiY2hlY2tlZFwiLCB0cnVlKTtcclxuICAgICAgICB9LCAxMDAwKTtcclxuICAgICAgICBcclxuICAgICAgICAvL31cclxuICAgIH1cclxufVxyXG4iXX0=
