System.register(['angular2/core'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1;
    var SelectInputComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            }],
        execute: function() {
            SelectInputComponent = (function () {
                function SelectInputComponent() {
                    this.onData = new core_1.EventEmitter();
                }
                SelectInputComponent.prototype.lblValue = function (item) {
                    return item[this.label];
                };
                SelectInputComponent.prototype.changeSelection = function (selectedOption) {
                    //alert(selectedOption.value);
                    // debugger;
                    localStorage.setItem('lang', selectedOption.value);
                    for (var index = 0; index < this.data.length; index++) {
                        if (this.data[index][this.label] == selectedOption.value) {
                            this.onData.emit(this.data[index]);
                            return true;
                        }
                    }
                    this.onData.emit({});
                    return false;
                };
                SelectInputComponent.prototype.ngOnInit = function () {
                    if (this.selectedval != "" && this.selectedval != undefined && this.selectedval != null)
                        this.default = this.selectedval;
                };
                __decorate([
                    core_1.Input("data"), 
                    __metadata('design:type', Array)
                ], SelectInputComponent.prototype, "data", void 0);
                __decorate([
                    core_1.Input("label"), 
                    __metadata('design:type', String)
                ], SelectInputComponent.prototype, "label", void 0);
                __decorate([
                    core_1.Input("selectedval"), 
                    __metadata('design:type', String)
                ], SelectInputComponent.prototype, "selectedval", void 0);
                __decorate([
                    core_1.Input("firstvalue"), 
                    __metadata('design:type', String)
                ], SelectInputComponent.prototype, "firstvalue", void 0);
                __decorate([
                    core_1.Input("cssclass"), 
                    __metadata('design:type', String)
                ], SelectInputComponent.prototype, "cssclass", void 0);
                __decorate([
                    core_1.Output("onData"), 
                    __metadata('design:type', Object)
                ], SelectInputComponent.prototype, "onData", void 0);
                SelectInputComponent = __decorate([
                    core_1.Component({
                        selector: 'mx-select',
                        template: "\n        <select #opt (change)=\"changeSelection(opt)\" [(ngModel)]=\"default\" class=\"{{cssclass}}\">\n            <option value=\"{{firstvalue}}\">{{firstvalue}}</option>\n            <option *ngFor=\"#item of data\" value=\"{{lblValue(item)}}\">{{lblValue(item)}}</option>\n        </select>\n    "
                    }), 
                    __metadata('design:paramtypes', [])
                ], SelectInputComponent);
                return SelectInputComponent;
            }());
            exports_1("SelectInputComponent", SelectInputComponent);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbW9uQ29tcG9uZW50cy9iYXNpY0NvbXBvbmVudHMvc2VsZWN0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1lBV0E7Z0JBQUE7b0JBY3NCLFdBQU0sR0FBRyxJQUFJLG1CQUFZLEVBQVUsQ0FBQztnQkFzQjFELENBQUM7Z0JBM0JHLHVDQUFRLEdBQVIsVUFBUyxJQUFJO29CQUNULE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUM1QixDQUFDO2dCQUtELDhDQUFlLEdBQWYsVUFBZ0IsY0FBYztvQkFDMUIsOEJBQThCO29CQUM5QixZQUFZO29CQUNaLFlBQVksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQTtvQkFDbEQsR0FBRyxDQUFDLENBQUMsSUFBSSxLQUFLLEdBQUcsQ0FBQyxFQUFFLEtBQUssR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxLQUFLLEVBQUUsRUFBRSxDQUFDO3dCQUNwRCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQzs0QkFDdkQsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDOzRCQUNuQyxNQUFNLENBQUMsSUFBSSxDQUFDO3dCQUNoQixDQUFDO29CQUNMLENBQUM7b0JBQ0QsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7b0JBQ3JCLE1BQU0sQ0FBQyxLQUFLLENBQUM7Z0JBQ2pCLENBQUM7Z0JBRUQsdUNBQVEsR0FBUjtvQkFDSSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsV0FBVyxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsV0FBVyxJQUFJLElBQUksQ0FBQzt3QkFDcEYsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDO2dCQUd4QyxDQUFDO2dCQWxDRDtvQkFBQyxZQUFLLENBQUMsTUFBTSxDQUFDOztrRUFBQTtnQkFDZDtvQkFBQyxZQUFLLENBQUMsT0FBTyxDQUFDOzttRUFBQTtnQkFDZjtvQkFBQyxZQUFLLENBQUMsYUFBYSxDQUFDOzt5RUFBQTtnQkFDckI7b0JBQUMsWUFBSyxDQUFDLFlBQVksQ0FBQzs7d0VBQUE7Z0JBQ3BCO29CQUFDLFlBQUssQ0FBQyxVQUFVLENBQUM7O3NFQUFBO2dCQVNsQjtvQkFBQyxhQUFNLENBQUMsUUFBUSxDQUFDOztvRUFBQTtnQkF2QnJCO29CQUFDLGdCQUFTLENBQUM7d0JBQ1AsUUFBUSxFQUFFLFdBQVc7d0JBQ3JCLFFBQVEsRUFBRSxnVEFLVDtxQkFDSixDQUFDOzt3Q0FBQTtnQkFxQ0YsMkJBQUM7WUFBRCxDQXBDQSxBQW9DQyxJQUFBO1lBcENELHVEQW9DQyxDQUFBIiwiZmlsZSI6ImNvbW9uQ29tcG9uZW50cy9iYXNpY0NvbXBvbmVudHMvc2VsZWN0LmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtDb21wb25lbnQsIElucHV0LCBPdXRwdXQsIEV2ZW50RW1pdHRlciwgT25Jbml0fSBmcm9tICdhbmd1bGFyMi9jb3JlJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdteC1zZWxlY3QnLFxyXG4gICAgdGVtcGxhdGU6IGBcclxuICAgICAgICA8c2VsZWN0ICNvcHQgKGNoYW5nZSk9XCJjaGFuZ2VTZWxlY3Rpb24ob3B0KVwiIFsobmdNb2RlbCldPVwiZGVmYXVsdFwiIGNsYXNzPVwie3tjc3NjbGFzc319XCI+XHJcbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJ7e2ZpcnN0dmFsdWV9fVwiPnt7Zmlyc3R2YWx1ZX19PC9vcHRpb24+XHJcbiAgICAgICAgICAgIDxvcHRpb24gKm5nRm9yPVwiI2l0ZW0gb2YgZGF0YVwiIHZhbHVlPVwie3tsYmxWYWx1ZShpdGVtKX19XCI+e3tsYmxWYWx1ZShpdGVtKX19PC9vcHRpb24+XHJcbiAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICBgXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBTZWxlY3RJbnB1dENvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcbiAgICBASW5wdXQoXCJkYXRhXCIpIGRhdGE6IFtPYmplY3RdO1xyXG4gICAgQElucHV0KFwibGFiZWxcIikgbGFiZWw6IHN0cmluZztcclxuICAgIEBJbnB1dChcInNlbGVjdGVkdmFsXCIpIHNlbGVjdGVkdmFsOiBzdHJpbmc7XHJcbiAgICBASW5wdXQoXCJmaXJzdHZhbHVlXCIpIGZpcnN0dmFsdWU6IHN0cmluZztcclxuICAgIEBJbnB1dChcImNzc2NsYXNzXCIpIGNzc2NsYXNzOiBzdHJpbmc7XHJcbiAgICAvL0BJbnB1dChcInNlbGVjdGVkdmFsXCIpIHNlbGVjdGVkdmFsOiBzdHJpbmc7XHJcblxyXG4gICAgZGVmYXVsdDogc3RyaW5nO1xyXG4gICAgbGJsVmFsdWUoaXRlbSk6IHN0cmluZyB7XHJcbiAgICAgICAgcmV0dXJuIGl0ZW1bdGhpcy5sYWJlbF07XHJcbiAgICB9XHJcblxyXG5cclxuICAgIEBPdXRwdXQoXCJvbkRhdGFcIikgb25EYXRhID0gbmV3IEV2ZW50RW1pdHRlcjxPYmplY3Q+KCk7XHJcblxyXG4gICAgY2hhbmdlU2VsZWN0aW9uKHNlbGVjdGVkT3B0aW9uKTogYm9vbGVhbiB7XHJcbiAgICAgICAgLy9hbGVydChzZWxlY3RlZE9wdGlvbi52YWx1ZSk7XHJcbiAgICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ2xhbmcnLCBzZWxlY3RlZE9wdGlvbi52YWx1ZSlcclxuICAgICAgICBmb3IgKHZhciBpbmRleCA9IDA7IGluZGV4IDwgdGhpcy5kYXRhLmxlbmd0aDsgaW5kZXgrKykge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5kYXRhW2luZGV4XVt0aGlzLmxhYmVsXSA9PSBzZWxlY3RlZE9wdGlvbi52YWx1ZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5vbkRhdGEuZW1pdCh0aGlzLmRhdGFbaW5kZXhdKTtcclxuICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMub25EYXRhLmVtaXQoe30pO1xyXG4gICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uSW5pdCgpOiBhbnkge1xyXG4gICAgICAgIGlmICh0aGlzLnNlbGVjdGVkdmFsICE9IFwiXCIgJiYgdGhpcy5zZWxlY3RlZHZhbCAhPSB1bmRlZmluZWQgJiYgdGhpcy5zZWxlY3RlZHZhbCAhPSBudWxsKVxyXG4gICAgICAgICAgICB0aGlzLmRlZmF1bHQgPSB0aGlzLnNlbGVjdGVkdmFsO1xyXG4gICAgICAgXHJcblxyXG4gICAgfVxyXG59Il19
