System.register(['./basicComponents/select', './basicComponents/treeview', './basicComponents/DateCtl'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var select_1, treeview_1, DateCtl_1;
    return {
        setters:[
            function (select_1_1) {
                select_1 = select_1_1;
            },
            function (treeview_1_1) {
                treeview_1 = treeview_1_1;
            },
            function (DateCtl_1_1) {
                DateCtl_1 = DateCtl_1_1;
            }],
        execute: function() {
            exports_1("SelectInputComponent", select_1.SelectInputComponent);
            exports_1("AmaxTreeView", treeview_1.AmaxTreeView);
            exports_1("AmaxDate", DateCtl_1.AmaxDate);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbW9uQ29tcG9uZW50cy9iYXNpY0NvbXBvbmVudHMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztZQUtJLGdFQUFvQjtZQUNwQixrREFBWTtZQUNaLHlDQUFRIiwiZmlsZSI6ImNvbW9uQ29tcG9uZW50cy9iYXNpY0NvbXBvbmVudHMuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBTZWxlY3RJbnB1dENvbXBvbmVudCB9IGZyb20gJy4vYmFzaWNDb21wb25lbnRzL3NlbGVjdCc7XHJcbmltcG9ydCB7IEFtYXhUcmVlVmlldyB9IGZyb20gJy4vYmFzaWNDb21wb25lbnRzL3RyZWV2aWV3J1xyXG5pbXBvcnQgeyBBbWF4RGF0ZSB9IGZyb20gJy4vYmFzaWNDb21wb25lbnRzL0RhdGVDdGwnXHJcblxyXG5leHBvcnQge1xyXG4gICAgU2VsZWN0SW5wdXRDb21wb25lbnQsXHJcbiAgICBBbWF4VHJlZVZpZXcsXHJcbiAgICBBbWF4RGF0ZVxyXG59Il19
