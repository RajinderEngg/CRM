System.register(["angular2/core", "../comonComponents/basicComponents/select", "../services/AmaxService", "../amaxUtil", "../services/ResourceService", "../crmconfig", "../services/AmaxCrmSyinc"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, select_1, AmaxService_1, amaxUtil_1, ResourceService_1, crmconfig_1, AmaxCrmSyinc_1;
    var AmaxSmsComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (select_1_1) {
                select_1 = select_1_1;
            },
            function (AmaxService_1_1) {
                AmaxService_1 = AmaxService_1_1;
            },
            function (amaxUtil_1_1) {
                amaxUtil_1 = amaxUtil_1_1;
            },
            function (ResourceService_1_1) {
                ResourceService_1 = ResourceService_1_1;
            },
            function (crmconfig_1_1) {
                crmconfig_1 = crmconfig_1_1;
            },
            function (AmaxCrmSyinc_1_1) {
                AmaxCrmSyinc_1 = AmaxCrmSyinc_1_1;
            }],
        execute: function() {
            AmaxSmsComponent = (function () {
                function AmaxSmsComponent(_amaxService, _resourceService, _amaxCrmSyinc) {
                    this._amaxService = _amaxService;
                    this._resourceService = _resourceService;
                    this._amaxCrmSyinc = _amaxCrmSyinc;
                    this.openSettrings = false;
                    this.SelectedData = {};
                    this.SelectedProvider = {};
                    this.ConfirmedSend = false;
                    this.SelectedPhoneType = {};
                    this.KendoRTLCSS = "";
                    this.ChangeDialog = "";
                    this.CHANGEDIR = "";
                    this.SelectedData.UserName = "";
                    this.SelectedData.Value = "";
                    this.SenderPhoneNumber = "";
                    this.SelectedPhoneType.Value = "";
                    this.SelectedProvider.value = "";
                    var empid = localStorage.getItem("employeeid");
                    var message = this._resourceService.getCookie(empid + "SMSMessage");
                    if (message.length > 0 && message[0] == "=")
                        message = message.substring(1, message.length);
                    this.message = message;
                }
                AmaxSmsComponent.prototype.SetdefaultMsgValue = function () {
                    //alert('Hello');
                    var empid = localStorage.getItem("employeeid");
                    this._resourceService.setCookie(empid + "SMSMessage", this.message, 10);
                    //alert(message);
                };
                AmaxSmsComponent.prototype.ngOnInit = function () {
                    //debugger;
                    var _this = this;
                    //this._amaxCrmSyinc.on('lsset.' + LocalDict.languageResource, data=> this.RES = data["SCREEN_SMS"]);
                    //this.RES = this._amaxCrmSyinc.fetchLanguageResource("SCREEN_SMS");
                    //alert('hello');
                    //loadingLanguage start
                    this._amaxCrmSyinc.on('lsset.' + crmconfig_1.LocalDict.languageResource, function (data) { return _this.RES = data["SCREEN_SMS"]; });
                    this.RES = this._amaxCrmSyinc.fetchLanguageResource("SCREEN_SMS");
                    //debugger;
                    if (!this.RES) {
                        if (!localStorage.getItem(crmconfig_1.LocalDict.selectedLanguage)) {
                            localStorage.setItem(crmconfig_1.LocalDict.selectedLanguage, crmconfig_1.crmConfig.falbackLanguage);
                        }
                        this.Language = localStorage.getItem("lang");
                        if (this.Language == "he") {
                            this.KendoRTLCSS = "k-rtl";
                        }
                        this._amaxCrmSyinc.loadLanguageResource(localStorage.getItem(crmconfig_1.LocalDict.selectedLanguage));
                    }
                    //loadingLanguage start
                    this.allBind();
                    //alert('Bye');
                    //var message = this._resourceService.getCookie("SMSMessage");
                    //if (message.length > 0 && message[0] == "=")
                    //    message = message.substring(1, message.length);
                    //this.message = message;
                };
                //saveSmsSettings(){
                //    alert("Sms Setting saved.");
                //    this.openSettrings=false;
                //}
                //openSmsSettings(){
                //    this.openSettrings=true;
                //    //setTimeout(function () {
                //    //    jQuery('#SmsSettingsPannel').addClass('animated bounceInDown');
                //    //},200);
                //}
                //closeSmsSettings(){
                //    jQuery('#SmsSettingsPannel').addClass('animated slideOutDown');
                //    setTimeout(()=>{
                //        this.openSettrings=false;
                //    },200);
                //}
                AmaxSmsComponent.prototype.saveSmsSettings = function () {
                    // debugger;
                    var jsonObject = { UserName: "", Value: "", SelectedProvider: "", SenderPhoneNumber: "" };
                    jsonObject.UserName = this.SelectedData.UserName;
                    //jsonObject.Value = this.SelectedData.Value;
                    //jsonObject.UserName = $("#User_txt").val;//this.SelectedData.UserName;
                    //jsonObject.Value = $("#Pass_txt").val;//this.SelectedData.Value;
                    jsonObject.SelectedProvider = this.SelectedProvider.value;
                    jsonObject.SenderPhoneNumber = this.SenderPhoneNumber;
                    if (jsonObject.UserName && this.SelectedData.Value && jsonObject.SelectedProvider && jsonObject.SenderPhoneNumber) {
                        this._amaxCrmSyinc.storeLocal(crmconfig_1.LocalDict.SmsSettings, jsonObject);
                        var empid = localStorage.getItem("employeeid");
                        this._resourceService.setCookie(empid + "SMSDet", JSON.stringify(jsonObject), 10);
                        this.closeSmsSettings();
                    }
                    else {
                        bootbox.alert({
                            message: "Please Varifye the settings",
                            className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                    }
                };
                AmaxSmsComponent.prototype.openSmsSettings = function () {
                    //debugger;
                    this.openSettrings = true;
                    //var jsonObject = JSON.parse(this._amaxCrmSyinc.fetchLocal(LocalDict.SmsSettings));
                    var empid = localStorage.getItem("employeeid");
                    var data = this._resourceService.getCookie(empid + "SMSDet");
                    var jsonObject = {};
                    if (data.length > 0)
                        jsonObject = jQuery.parseJSON(data.substring(1, data.length));
                    // debugger;
                    if (jsonObject != null) {
                        for (var i = 0; i < this.SmsData.length; i++)
                            if (this.SmsData[i].UserName == jsonObject.UserName)
                                this.SelectedData.UserName = this.SmsData[i].UserName; //&& this.SmsData[i].Value == jsonObject.Value
                        for (var i = 0; i < this.SmsProvider.length; i++)
                            if (this.SmsProvider[i].value == jsonObject.SelectedProvider)
                                this.SelectedProvider = this.SmsProvider[i];
                        this.SenderPhoneNumber = jsonObject.SenderPhoneNumber;
                    }
                    else {
                        this.SelectedData.UserName = "";
                        this.SelectedData.Value = "";
                        this.SenderPhoneNumber = "";
                    }
                };
                AmaxSmsComponent.prototype.closeSmsSettings = function () {
                    this.openSettrings = false;
                    this.allBind();
                };
                AmaxSmsComponent.prototype.doNothing = function () {
                };
                AmaxSmsComponent.prototype.openModel = function () {
                };
                AmaxSmsComponent.prototype.setSmsCompanyList = function (data) {
                    this.SmsData = data;
                    this.SelectedData = this.SmsData[0];
                };
                AmaxSmsComponent.prototype.bindPhoneTypeList = function (data) {
                    this.PhoneTypeListData = data;
                    this.SelectedPhoneType = this.PhoneTypeListData[0];
                };
                AmaxSmsComponent.prototype.bindGeneralGroupTree = function (data) {
                    // debugger;
                    jQuery("#groupTree").html("Loding...");
                    var res = jQuery.parseJSON(data);
                    setTimeout(function () {
                        jQuery("#groupTree").kendoTreeView({
                            loadOnDemand: true,
                            checkboxes: {
                                checkChildren: true
                            },
                            dataSource: res.Data.kendoTree
                        });
                        jQuery("#sendLaterDate").kendoDatePicker({
                            format: "dd-MM-yyyy"
                        });
                        switch_direction();
                    }, 1000);
                };
                AmaxSmsComponent.prototype.getSelectedGroups = function () {
                    var _CheckedGroups = [];
                    amaxUtil_1.Kendo_utility.checkedNodeIds(jQuery("#groupTree").data("kendoTreeView").dataSource.view(), _CheckedGroups);
                    return _CheckedGroups;
                };
                AmaxSmsComponent.prototype.SendToSelectedGroups = function () {
                    var _this = this;
                    //username:string,company:string,message:string,groups:Array<any>,phoneTypeId:number
                    debugger;
                    if (this.SelectedPhoneType == undefined || this.SelectedPhoneType == null || this.SelectedPhoneType.Value == "") {
                        this.SelectedPhoneType.Value = 0;
                    }
                    if (this.SelectedPhoneType.Value == 1 && this.SenderPhoneNumber.length != 10) {
                        bootbox.alert({
                            message: "Sender Must be 10 Digit valid cellphone number",
                            className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                        this.openSmsSettings();
                        return;
                    }
                    var _selectedGroups = this.getSelectedGroups();
                    var status = "ok";
                    if (_selectedGroups.length == 0)
                        status = "No groups selected";
                    //else if (!this.SelectedData.UserName || !this.SelectedData.Value) status = "Please select a provider";
                    //else if (!this.message) status = "Message can't be empty";
                    if (status != "ok") {
                        bootbox.alert({
                            message: status,
                            className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                        return;
                    }
                    ;
                    var sendlater = jQuery('#sendLaterDate').val() + " " + jQuery('#sendLaterHour').val() + ":" + jQuery('#sendLaterMin').val();
                    if (sendlater.length != 16)
                        sendlater = "";
                    var smsSettings = JSON.parse(this._amaxCrmSyinc.fetchLocal(crmconfig_1.LocalDict.SmsSettings));
                    if (!smsSettings) {
                        bootbox.alert({
                            message: "Sms Settings not found",
                            className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                        this.openSmsSettings();
                        return false;
                    }
                    else {
                        smsSettings.Value = this.SelectedData.Value;
                    }
                    this._amaxService.SendSms(smsSettings.UserName, smsSettings.Value, this.message, this.getSelectedGroups(), this.SelectedPhoneType.Value, smsSettings.SelectedProvider, !this.ConfirmedSend, this.ConfirmedSend, smsSettings.SenderPhoneNumber, sendlater).subscribe(function (data) {
                        console.log(data);
                        debugger;
                        var _data = jQuery.parseJSON(data).Data;
                        /*jQuery("#SelectedCustomers").kendoGrid({
                            dataSource: {
                                data: _data.Customers
                            },
                            height: 350,
                            selectable: "multiple"
                        });*/
                        if (!_this.ConfirmedSend) {
                            if (_data.err) {
                                bootbox.alert({
                                    message: _data.err,
                                    className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        }
                                    }
                                });
                                _this.openSmsSettings();
                                return;
                            }
                            if (_data.Error) {
                                bootbox.alert({
                                    message: _data.Error,
                                    className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        }
                                    }
                                });
                                return;
                            }
                            var RemainingCredit = _data.RemainingCredit;
                            var TotalCustomers = _data.TotalCustomers;
                            if (RemainingCredit > 0) {
                                if (RemainingCredit > TotalCustomers) {
                                    var message = "Total customers : " + TotalCustomers;
                                    message += "\nRemaining Creadit for sms : " + RemainingCredit;
                                    message += "\n\nProcide to send ?";
                                    if (confirm(message)) {
                                        _this.ConfirmedSend = true;
                                        _this.SendToSelectedGroups();
                                    }
                                }
                            }
                            else {
                                if (typeof RemainingCredit != 'undefined')
                                    bootbox.alert({
                                        message: "No SMS creadit",
                                        className: _this.ChangeDialog,
                                        buttons: {
                                            ok: {
                                                //label: 'Ok',
                                                className: _this.CHANGEDIR
                                            }
                                        }
                                    });
                                else
                                    bootbox.alert({
                                        message: "Error processing request",
                                        className: _this.ChangeDialog,
                                        buttons: {
                                            ok: {
                                                //label: 'Ok',
                                                className: _this.CHANGEDIR
                                            }
                                        }
                                    });
                            }
                        }
                        else {
                            _this.ConfirmedSend = false;
                            switch (_data.status) {
                                case 1:
                                    bootbox.alert({
                                        message: _data.message,
                                        className: _this.ChangeDialog,
                                        buttons: {
                                            ok: {
                                                //label: 'Ok',
                                                className: _this.CHANGEDIR
                                            }
                                        }
                                    });
                                    break;
                                case 0:
                                    if (_this.SelectedProvider.value == 1) {
                                        if (_data.err.indexOf("ERROR") > -1 && _data.err.indexOf("SENDER_PREFIX") > -1) {
                                            bootbox.alert({
                                                message: "Invalid Sender Phone Number",
                                                className: _this.ChangeDialog,
                                                buttons: {
                                                    ok: {
                                                        //label: 'Ok',
                                                        className: _this.CHANGEDIR
                                                    }
                                                }
                                            });
                                            _this.openSmsSettings();
                                            return false;
                                        }
                                    }
                                    else if (_this.SelectedProvider.value == 2) {
                                        bootbox.alert({
                                            message: "Unable To Send Message",
                                            className: _this.ChangeDialog,
                                            buttons: {
                                                ok: {
                                                    //label: 'Ok',
                                                    className: _this.CHANGEDIR
                                                }
                                            }
                                        });
                                    }
                                    break;
                                default:
                                    console.log(data);
                            }
                        }
                    }, function (err) {
                        if (typeof err._body == 'string') {
                            bootbox.alert({
                                message: JSON.parse(err._body).error,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            bootbox.alert({
                                message: "Unable to connect to the Service",
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                    }, function () {
                        console.log({
                            message: "Sms send responce compleated!",
                            className: _this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: _this.CHANGEDIR
                                }
                            }
                        });
                    });
                };
                AmaxSmsComponent.prototype.allBind = function () {
                    // debugger;
                    var _this = this;
                    this.SmsProvider = [
                        { name: "Sms 2 You", value: 1 },
                        { name: "019 Sms", value: 2 }
                    ];
                    this.SelectedProvider = this.SmsProvider[0];
                    //alert(this._amaxService.GetGeneralGroupTree(0));
                    //this.bindGeneralGroupTree(this._amaxService.GetGeneralGroupTree(0));
                    this._amaxService.GetGeneralGroupTree().subscribe(function (data) {
                        var res = jQuery.parseJSON(data);
                        jQuery("#groupTree").kendoTreeView({
                            loadOnDemand: true,
                            checkboxes: {},
                            ////check: this.onGroupSelect,
                            check: function (e) {
                                this.expandRoot = e.node;
                                this.expand(jQuery(this.expandRoot).find(".k-item").addBack());
                            },
                            dataSource: res.Data.kendoTree
                        });
                        jQuery("#sendLaterDate").kendoDatePicker({
                            format: "dd-MM-yyyy"
                        });
                    }, function (err) {
                    }, function () {
                    });
                    //jQuery("#sendLaterDate").kendoDatePicker({
                    //    format: "dd-MM-yyyy"
                    //});
                    //this.bindPhoneTypeList(this._resourceService.GetLocalStorage("CellPhoneTypeList"));
                    //this.setSmsCompanyList(this._resourceService.GetLocalStorage("SmsCompanyList"));
                    this._amaxService.GetDataFromServer({
                        SmsCompanyList: {
                            uqery: "\n                        Select\n                            usersms AS UserName,\n                            passwordsms AS Value\n                        from\n                            ApplicationInfo\n                    ",
                            parameters: {}
                        },
                        PhoneTypeList: {
                            uqery: "SELECT id AS Value, contentHeb+' ('+ contenteng +')' AS Label FROM PhoneTypes",
                            parameters: {}
                        }
                    }).subscribe(function (data) {
                        //debugger;
                        console.log(data);
                        var res = jQuery.parseJSON(data);
                        _this.SmsData = res.Data.data.SmsCompanyList;
                        _this.PhoneTypeListData = res.Data.data.PhoneTypeList;
                        var phonetypeid = "";
                        jQuery.each(_this.PhoneTypeListData, function () {
                            phonetypeid = this.Label;
                            return false;
                        });
                        //jQuery("#PhontTypesel").attr("selectedval", phonetypeid);
                    }, function (error) { }, function () { });
                };
                AmaxSmsComponent = __decorate([
                    core_1.Component({
                        name: 'amax-sms',
                        pipes: [amaxUtil_1.GroupFilterPipe, amaxUtil_1.GroupParenFilterPipe],
                        template: "<div class=\"row\" *ngIf=\"RES\">\n\n    <div class=\"col s12 card-panel\">\n<div class=\"row\">\n<div class=\"col s12\">\n<h1>\n                            <i class=\"mdi-content-select-all green-text\"></i>\n                            <span class=\"red-text\">{{RES.LBL_HEADING}}</span>  <!--{{RES.CUSTOMER_MASTER.CUST_LABAL}}Customer-->\n                        </h1>\n\n</div>\n<button class=\"btn waves-effect waves-light indigo {{ _amaxCrmSyinc.isRtl() ? 'right' : 'left'}}\"\n                    (click)=\"openSmsSettings()\">\n                <i class=\"mdi-action-settings\"></i> {{RES.LBL_SETTING}}\n            </button>\n\n</div>\n        <div style=\"overflow: hidden;\">\n            <div class=\"col s12\">&nbsp;</div>\n            <div id=\"SmsSettingsPannel\" class=\"col s12 animated slideInDown\" *ngIf=\"openSettrings\">\n               <div class=\"col s12\">\n                    <label>{{RES.LBL_SMS_PROVIDERS}}</label>\n                    <select class=\"browser-default\" [(ngModel)]= \"SelectedProvider.value\">\n                        \n                        <option value=\"1\">Sms 2 you</option>\n                        <option value=\"2\">019 Sms</option>\n                        \n                    </select>\n                </div>\n                <div class=\"input-field col s6\">\n                    \n                    <input type=\"text\" id=\"UserName\" class=\"form-control\" [(ngModel)]= \"SelectedData.UserName\">\n                    <label for=\"UserName\" class=\"active\">{{RES.LBL_SMS_USERNAME}}</label>\n                </div>\n                <div class=\"input-field col s6\">\n                    \n                    <input class=\"form-control\" type=\"password\" id=\"Password\" [(ngModel)]= \"SelectedData.Value\"/>\n                    <label for=\"Password\" class=\"active\">{{RES.SMS_PASSWORD}}</label>\n                </div>\n                \n                <div class=\"input-field col s12\">\n                    \n                    <input class=\"form-control\" id=\"PhNo\" type=\"text\" [(ngModel)]=\"SenderPhoneNumber\">\n                    <label for=\"PhNo\" class=\"active\">{{RES.LBL_SENDER_PHONE}}</label>\n                </div>\n                <div class=\"col s12\">&nbsp;</div>\n                <div class=\"col s12\">\n                    <button class=\"btn waves-effect waves-light green accent-4\" (click)=\"saveSmsSettings()\" style=\"width:200px!important;\">\n                        <i class=\"mdi-content-save\"></i> {{RES.LBL_SAVE_SETTING}}\n                    </button>\n                    <button class=\"btn waves-effect waves-light  grey lighten-2\" (click)=\"closeSmsSettings()\"style=\"width:200px!important;\">\n                        <i class=\"mdi-navigation-close\"></i> {{RES.LBL_CLOSE_SETTINGS}}\n                    </button>\n                </div>\n            </div>\n            <div class=\"col s12\" *ngIf=\"!openSettrings\">\n                <div class=\"row\">\n                    <div class=\"col s6\">\n                        <div class=\"row\">\n                            <div class=\"col s12\">\n                                <label>{{RES.LBL_GROUPS}}</label>\n                                <div class=\"k-content {{KendoRTLCSS}}\" style=\"max-height: 230px;overflow-y: auto; padding: 20px 10px 40px; margin-left:10px;\">\n                                    <div id=\"groupTree\" style=\"overflow: visible;\"> Loading...</div>\n                                </div>\n                            </div>\n                        </div>\n                    </div>\n                    <div class=\"col s6\">\n                        <div class=\"row\">\n                            <div class=\"col s12\">\n                                <label>{{RES.LBL_PHONE_TYPES}}</label>\n                                <mx-select [data]=\"PhoneTypeListData\" label=\"Label\" selectedval=\"All\" firstvalue=\"All\" \n                                           (onData)=\"SelectedPhoneType = $event\" cssclass=\"browser-default\" id=\"PhontTypesel\"></mx-select>\n                            </div>\n                            <div class=\"col s12\">&nbsp;</div>\n                            <div class=\"col s12\">\n                                <div class=\"row\">\n                                    <details>\n                                        <summary>{{RES.LBL_SEND_LATER}}</summary>\n                                        <div class=\"col s6\">\n                                            <label>{{RES.SMS_LBL_DATE}}</label>\n                                            <div class=\"k-content\">\n                                                <input class=\"form-control\" id=\"sendLaterDate\">\n                                            </div>\n                                        </div>\n                                        <div class=\"col s3\">\n                                            <label>{{RES.SMS_LBL_HR}}</label>\n                                            <select class=\"browser-default\" id=\"sendLaterHour\">\n                                                <option>01</option>\n                                                <option>02</option>\n                                                <option>03</option>\n                                                <option>04</option>\n                                                <option>05</option>\n                                                <option>06</option>\n                                                <option>07</option>\n                                                <option>08</option>\n                                                <option>09</option>\n                                                <option>10</option>\n                                                <option>11</option>\n                                                <option>12</option>\n                                                <option>13</option>\n                                                <option>14</option>\n                                                <option>15</option>\n                                                <option>16</option>\n                                                <option>17</option>\n                                                <option>18</option>\n                                                <option>19</option>\n                                                <option>20</option>\n                                                <option>21</option>\n                                                <option>22</option>\n                                                <option>23</option>\n                                                <option>24</option>\n                                            </select>\n                                        </div>\n                                        <div class=\"col s3\">\n                                            <label>{{RES.SMS_LBL_MIN}}</label>\n                                            <select class=\"browser-default\" id=\"sendLaterMin\">\n                                                <option>00</option>\n                                                <option>05</option>\n                                                <option>10</option>\n                                                <option>15</option>\n                                                <option>20</option>\n                                                <option>25</option>\n                                                <option>30</option>\n                                                <option>35</option>\n                                                <option>40</option>\n                                                <option>45</option>\n                                                <option>50</option>\n                                                <option>55</option>\n                                                <option>60</option>\n                                            </select>\n                                        </div>\n                                    </details>\n                                </div>\n                            </div>\n                            <div class=\"col s12\">&nbsp;</div>\n                            <div class=\"col s12\">\n                                <label>{{RES.LBL_MESSAGE}}</label>\n                                <textarea cols=\"50\" #msg (keyup)=\"message=msg.value\" class=\"form-control\"\n                                          placeholder=\"{{RES.SMS_TXT_PH_MESSAGE}}\" (change)=\"SetdefaultMsgValue()\" id=\"Messagetxtar\" [(ngModel)]= \"message\"></textarea>\n\n                                <span>{{RES.SMS_LBL_MAXCHAR}} : {{msg.value.length||0}}</span>\n                            </div>\n                        </div>\n                    </div>\n                    <div class=\"col s12\" id=\"SelectedCustomers\">&nbsp;</div>\n                    <div class=\"col s12\">\n                        <button class=\"btn waves-effect waves-light green accent-4\" style=\"width:175px!important;\" (click)=\"SendToSelectedGroups()\">{{RES.SMS_BTN_SENDMESSAGE}}</button>\n                    </div>\n                    <div class=\"space-4\"><div>\n\n                </div>\n            </div>\n        <br/><br/>\n        </div>\n    ",
                        directives: [select_1.SelectInputComponent],
                        providers: [AmaxService_1.AmaxService, AmaxCrmSyinc_1.AmaxCrmSyinc]
                    }), 
                    __metadata('design:paramtypes', [AmaxService_1.AmaxService, ResourceService_1.ResourceService, AmaxCrmSyinc_1.AmaxCrmSyinc])
                ], AmaxSmsComponent);
                return AmaxSmsComponent;
            }());
            exports_1("AmaxSmsComponent", AmaxSmsComponent);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFtYXgvc21zLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1lBNktBO2dCQXVCSSwwQkFBb0IsWUFBeUIsRUFBVSxnQkFBaUMsRUFBVSxhQUEyQjtvQkFBekcsaUJBQVksR0FBWixZQUFZLENBQWE7b0JBQVUscUJBQWdCLEdBQWhCLGdCQUFnQixDQUFpQjtvQkFBVSxrQkFBYSxHQUFiLGFBQWEsQ0FBYztvQkFyQnJILGtCQUFhLEdBQVksS0FBSyxDQUFDO29CQUd2QyxpQkFBWSxHQUFXLEVBQUUsQ0FBQztvQkFHMUIscUJBQWdCLEdBQVcsRUFBRSxDQUFDO29CQUU5QixrQkFBYSxHQUFZLEtBQUssQ0FBQztvQkFHL0Isc0JBQWlCLEdBQVcsRUFBRSxDQUFDO29CQUkvQixnQkFBVyxHQUFXLEVBQUUsQ0FBQztvQkFDekIsaUJBQVksR0FBVyxFQUFFLENBQUM7b0JBQzFCLGNBQVMsR0FBVyxFQUFFLENBQUM7b0JBS25CLElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQztvQkFDaEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLEdBQUcsRUFBRSxDQUFDO29CQUM3QixJQUFJLENBQUMsaUJBQWlCLEdBQUcsRUFBRSxDQUFDO29CQUM1QixJQUFJLENBQUMsaUJBQWlCLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQztvQkFDbEMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEtBQUssR0FBRyxFQUFFLENBQUM7b0JBQ2pDLElBQUksS0FBSyxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUM7b0JBQy9DLElBQUksT0FBTyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFDLFlBQVksQ0FBQyxDQUFDO29CQUNsRSxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxHQUFHLENBQUMsSUFBSSxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksR0FBRyxDQUFDO3dCQUN4QyxPQUFPLEdBQUcsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUNuRCxJQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQztnQkFFM0IsQ0FBQztnQkFDRCw2Q0FBa0IsR0FBbEI7b0JBQ0ksaUJBQWlCO29CQUNqQixJQUFJLEtBQUssR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDO29CQUMvQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxZQUFZLEVBQUUsSUFBSSxDQUFDLE9BQU8sRUFBRSxFQUFFLENBQUMsQ0FBQztvQkFHeEUsaUJBQWlCO2dCQUNyQixDQUFDO2dCQUNELG1DQUFRLEdBQVI7b0JBQ0ksV0FBVztvQkFEZixpQkFxQ0M7b0JBbENHLHFHQUFxRztvQkFDckcsb0VBQW9FO29CQU1wRSxpQkFBaUI7b0JBQ2pCLHVCQUF1QjtvQkFHdkIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLENBQUMsUUFBUSxHQUFHLHFCQUFTLENBQUMsZ0JBQWdCLEVBQUUsVUFBQSxJQUFJLElBQUcsT0FBQSxLQUFJLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBN0IsQ0FBNkIsQ0FBQyxDQUFDO29CQUNuRyxJQUFJLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMscUJBQXFCLENBQUMsWUFBWSxDQUFDLENBQUM7b0JBQ2xFLFdBQVc7b0JBRVgsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQzt3QkFDWixFQUFFLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMscUJBQVMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQzs0QkFDcEQsWUFBWSxDQUFDLE9BQU8sQ0FBQyxxQkFBUyxDQUFDLGdCQUFnQixFQUFFLHFCQUFTLENBQUMsZUFBZSxDQUFDLENBQUM7d0JBQ2hGLENBQUM7d0JBQ0QsSUFBSSxDQUFDLFFBQVEsR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO3dCQUM3QyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQ3hCLElBQUksQ0FBQyxXQUFXLEdBQUcsT0FBTyxDQUFDO3dCQUMvQixDQUFDO3dCQUNELElBQUksQ0FBQyxhQUFhLENBQUMsb0JBQW9CLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxxQkFBUyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQztvQkFDOUYsQ0FBQztvQkFFRCx1QkFBdUI7b0JBQ3ZCLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztvQkFDZixlQUFlO29CQUNmLDhEQUE4RDtvQkFDOUQsOENBQThDO29CQUM5QyxxREFBcUQ7b0JBQ3JELHlCQUF5QjtnQkFFN0IsQ0FBQztnQkFFRCxvQkFBb0I7Z0JBQ3BCLGtDQUFrQztnQkFDbEMsK0JBQStCO2dCQUMvQixHQUFHO2dCQUNILG9CQUFvQjtnQkFDcEIsOEJBQThCO2dCQUM5QixnQ0FBZ0M7Z0JBQ2hDLDJFQUEyRTtnQkFDM0UsZUFBZTtnQkFDZixHQUFHO2dCQUNILHFCQUFxQjtnQkFDckIscUVBQXFFO2dCQUNyRSxzQkFBc0I7Z0JBQ3RCLG1DQUFtQztnQkFDbkMsYUFBYTtnQkFDYixHQUFHO2dCQVFILDBDQUFlLEdBQWY7b0JBQ0csWUFBWTtvQkFDWCxJQUFJLFVBQVUsR0FBRyxFQUFFLFFBQVEsRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBRSxnQkFBZ0IsRUFBRSxFQUFFLEVBQUUsaUJBQWlCLEVBQUUsRUFBRSxFQUFFLENBQUM7b0JBQzFGLFVBQVUsQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUM7b0JBQ2pELDZDQUE2QztvQkFFN0Msd0VBQXdFO29CQUN4RSxrRUFBa0U7b0JBRWxFLFVBQVUsQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDO29CQUMxRCxVQUFVLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDO29CQUV0RCxFQUFFLENBQUMsQ0FBQyxVQUFVLENBQUMsUUFBUSxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxJQUFJLFVBQVUsQ0FBQyxnQkFBZ0IsSUFBSSxVQUFVLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDO3dCQUNoSCxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxxQkFBUyxDQUFDLFdBQVcsRUFBRSxVQUFVLENBQUMsQ0FBQzt3QkFDakUsSUFBSSxLQUFLLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQzt3QkFDL0MsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsUUFBUSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7d0JBQ2xGLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO29CQUM1QixDQUFDO29CQUFDLElBQUksQ0FBQyxDQUFDO3dCQUNKLE9BQU8sQ0FBQyxLQUFLLENBQUM7NEJBQ1YsT0FBTyxFQUFFLDZCQUE2Qjs0QkFDdEMsU0FBUyxFQUFFLElBQUksQ0FBQyxZQUFZOzRCQUM1QixPQUFPLEVBQUU7Z0NBQ0wsRUFBRSxFQUFFO29DQUNBLGNBQWM7b0NBQ2QsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO2lDQUM1Qjs2QkFDSjt5QkFDSixDQUFDLENBQUM7b0JBQ1AsQ0FBQztnQkFDTCxDQUFDO2dCQUNELDBDQUFlLEdBQWY7b0JBQ0ksV0FBVztvQkFDWCxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQztvQkFDMUIsb0ZBQW9GO29CQUNwRixJQUFJLEtBQUssR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDO29CQUMvQyxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUMsQ0FBQztvQkFDN0QsSUFBSSxVQUFVLEdBQUcsRUFBRSxDQUFDO29CQUNwQixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQzt3QkFDaEIsVUFBVSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7b0JBQ25FLFlBQVk7b0JBQ1gsRUFBRSxDQUFDLENBQUMsVUFBVSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7d0JBQ3JCLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFOzRCQUN4QyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsSUFBSSxVQUFVLENBQUMsUUFBUSxDQUFDO2dDQUNoRCxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFHLDhDQUE4Qzt3QkFFL0csR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUU7NEJBQzVDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxJQUFJLFVBQVUsQ0FBQyxnQkFBZ0IsQ0FBQztnQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFFOUcsSUFBSSxDQUFDLGlCQUFpQixHQUFHLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQztvQkFDMUQsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUM7d0JBQ2hDLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQzt3QkFDN0IsSUFBSSxDQUFDLGlCQUFpQixHQUFHLEVBQUUsQ0FBQztvQkFDaEMsQ0FBQztnQkFDTCxDQUFDO2dCQUNELDJDQUFnQixHQUFoQjtvQkFDSSxJQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztvQkFDM0IsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO2dCQUNuQixDQUFDO2dCQUVELG9DQUFTLEdBQVQ7Z0JBQ0EsQ0FBQztnQkFFRCxvQ0FBUyxHQUFUO2dCQUNBLENBQUM7Z0JBR0QsNENBQWlCLEdBQWpCLFVBQWtCLElBQVM7b0JBQ3ZCLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO29CQUNwQixJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3hDLENBQUM7Z0JBQ0QsNENBQWlCLEdBQWpCLFVBQWtCLElBQVM7b0JBRXZCLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLENBQUM7b0JBQzlCLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3ZELENBQUM7Z0JBQ0QsK0NBQW9CLEdBQXBCLFVBQXFCLElBQVM7b0JBQzNCLFlBQVk7b0JBQ1gsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztvQkFDdkMsSUFBSSxHQUFHLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFDakMsVUFBVSxDQUFDO3dCQUNQLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxhQUFhLENBQUM7NEJBQy9CLFlBQVksRUFBRSxJQUFJOzRCQUNsQixVQUFVLEVBQUU7Z0NBQ1IsYUFBYSxFQUFFLElBQUk7NkJBQ3RCOzRCQUNELFVBQVUsRUFBRSxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVM7eUJBQ2pDLENBQUMsQ0FBQzt3QkFDSCxNQUFNLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxlQUFlLENBQUM7NEJBQ3JDLE1BQU0sRUFBRSxZQUFZO3lCQUN2QixDQUFDLENBQUM7d0JBQ0gsZ0JBQWdCLEVBQUUsQ0FBQztvQkFDdkIsQ0FBQyxFQUNHLElBQUksQ0FBQyxDQUFDO2dCQUNkLENBQUM7Z0JBR0QsNENBQWlCLEdBQWpCO29CQUNJLElBQUksY0FBYyxHQUFHLEVBQUUsQ0FBQztvQkFDeEIsd0JBQWEsQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLEVBQUUsY0FBYyxDQUFDLENBQUM7b0JBQzNHLE1BQU0sQ0FBQyxjQUFjLENBQUM7Z0JBQzFCLENBQUM7Z0JBRUQsK0NBQW9CLEdBQXBCO29CQUFBLGlCQTZPQztvQkE1T0csb0ZBQW9GO29CQUNwRixRQUFRLENBQUM7b0JBQ1QsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLGlCQUFpQixJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsaUJBQWlCLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxLQUFLLElBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQzt3QkFDNUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLEtBQUssR0FBRyxDQUFDLENBQUM7b0JBQ3JDLENBQUM7b0JBQ0QsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLEtBQUssSUFBSSxDQUFDLElBQUksSUFBSSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO3dCQUMzRSxPQUFPLENBQUMsS0FBSyxDQUFDOzRCQUNWLE9BQU8sRUFBRSxnREFBZ0Q7NEJBQ3pELFNBQVMsRUFBRSxJQUFJLENBQUMsWUFBWTs0QkFDNUIsT0FBTyxFQUFFO2dDQUNMLEVBQUUsRUFBRTtvQ0FDQSxjQUFjO29DQUNkLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUztpQ0FDNUI7NkJBQ0o7eUJBQ0osQ0FBQyxDQUFDO3dCQUNILElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQzt3QkFDdkIsTUFBTSxDQUFDO29CQUNYLENBQUM7b0JBQ0QsSUFBSSxlQUFlLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7b0JBQy9DLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQztvQkFFbEIsRUFBRSxDQUFDLENBQUMsZUFBZSxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUM7d0JBQUMsTUFBTSxHQUFHLG9CQUFvQixDQUFDO29CQUMvRCx3R0FBd0c7b0JBQ3hHLDREQUE0RDtvQkFFNUQsRUFBRSxDQUFDLENBQUMsTUFBTSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7d0JBQ2pCLE9BQU8sQ0FBQyxLQUFLLENBQUM7NEJBQ1YsT0FBTyxFQUFFLE1BQU07NEJBQ2YsU0FBUyxFQUFFLElBQUksQ0FBQyxZQUFZOzRCQUM1QixPQUFPLEVBQUU7Z0NBQ0wsRUFBRSxFQUFFO29DQUNBLGNBQWM7b0NBQ2QsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO2lDQUM1Qjs2QkFDSjt5QkFDSixDQUFDLENBQUM7d0JBQ0gsTUFBTSxDQUFDO29CQUNYLENBQUM7b0JBQUEsQ0FBQztvQkFDRixJQUFJLFNBQVMsR0FBRyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxHQUFHLEdBQUcsTUFBTSxDQUFDLGdCQUFnQixDQUFDLENBQUMsR0FBRyxFQUFFLEdBQUcsR0FBRyxHQUFHLE1BQU0sQ0FBQyxlQUFlLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQztvQkFDNUgsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLE1BQU0sSUFBSSxFQUFFLENBQUM7d0JBQUMsU0FBUyxHQUFHLEVBQUUsQ0FBQztvQkFFM0MsSUFBSSxXQUFXLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxxQkFBUyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7b0JBQ25GLEVBQUUsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQzt3QkFDZixPQUFPLENBQUMsS0FBSyxDQUFDOzRCQUNWLE9BQU8sRUFBRSx3QkFBd0I7NEJBQ2pDLFNBQVMsRUFBRSxJQUFJLENBQUMsWUFBWTs0QkFDNUIsT0FBTyxFQUFFO2dDQUNMLEVBQUUsRUFBRTtvQ0FDQSxjQUFjO29DQUNkLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUztpQ0FDNUI7NkJBQ0o7eUJBQ0osQ0FBQyxDQUFDO3dCQUNILElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQzt3QkFDdkIsTUFBTSxDQUFDLEtBQUssQ0FBQztvQkFDakIsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixXQUFXLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDO29CQUNoRCxDQUFDO29CQUNELElBQUksQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUNyQixXQUFXLENBQUMsUUFBUSxFQUNwQixXQUFXLENBQUMsS0FBSyxFQUNqQixJQUFJLENBQUMsT0FBTyxFQUNaLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxFQUN4QixJQUFJLENBQUMsaUJBQWlCLENBQUMsS0FBSyxFQUMxQixXQUFXLENBQUMsZ0JBQWdCLEVBQzlCLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFDbkIsSUFBSSxDQUFDLGFBQWEsRUFDbEIsV0FBVyxDQUFDLGlCQUFpQixFQUM3QixTQUFTLENBQ1osQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUNaLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ2xCLFFBQVEsQ0FBQzt3QkFDVCxJQUFJLEtBQUssR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQzt3QkFFeEM7Ozs7Ozs2QkFNSzt3QkFDTCxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDOzRCQUN0QixFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztnQ0FFWixPQUFPLENBQUMsS0FBSyxDQUFDO29DQUNWLE9BQU8sRUFBRSxLQUFLLENBQUMsR0FBRztvQ0FDbEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO29DQUM1QixPQUFPLEVBQUU7d0NBQ0wsRUFBRSxFQUFFOzRDQUNBLGNBQWM7NENBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3lDQUM1QjtxQ0FDSjtpQ0FDSixDQUFDLENBQUM7Z0NBQ0gsS0FBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO2dDQUN2QixNQUFNLENBQUM7NEJBQ1gsQ0FBQzs0QkFDRCxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztnQ0FDZCxPQUFPLENBQUMsS0FBSyxDQUFDO29DQUNWLE9BQU8sRUFBRSxLQUFLLENBQUMsS0FBSztvQ0FDcEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO29DQUM1QixPQUFPLEVBQUU7d0NBQ0wsRUFBRSxFQUFFOzRDQUNBLGNBQWM7NENBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3lDQUM1QjtxQ0FDSjtpQ0FDSixDQUFDLENBQUM7Z0NBQ0gsTUFBTSxDQUFDOzRCQUNYLENBQUM7NEJBQ0QsSUFBSSxlQUFlLEdBQUcsS0FBSyxDQUFDLGVBQWUsQ0FBQzs0QkFDNUMsSUFBSSxjQUFjLEdBQUcsS0FBSyxDQUFDLGNBQWMsQ0FBQzs0QkFFMUMsRUFBRSxDQUFDLENBQUMsZUFBZSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQ3RCLEVBQUUsQ0FBQyxDQUFDLGVBQWUsR0FBRyxjQUFjLENBQUMsQ0FBQyxDQUFDO29DQUNuQyxJQUFJLE9BQU8sR0FBRyxvQkFBb0IsR0FBRyxjQUFjLENBQUM7b0NBQ3BELE9BQU8sSUFBSSxnQ0FBZ0MsR0FBRyxlQUFlLENBQUM7b0NBQzlELE9BQU8sSUFBSSx1QkFBdUIsQ0FBQztvQ0FDbkMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQzt3Q0FDbkIsS0FBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7d0NBQzFCLEtBQUksQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO29DQUNoQyxDQUFDO2dDQUNMLENBQUM7NEJBQ0wsQ0FBQzs0QkFBQyxJQUFJLENBQUMsQ0FBQztnQ0FDSixFQUFFLENBQUMsQ0FBQyxPQUFPLGVBQWUsSUFBSSxXQUFXLENBQUM7b0NBQ3RDLE9BQU8sQ0FBQyxLQUFLLENBQUM7d0NBQ1YsT0FBTyxFQUFFLGdCQUFnQjt3Q0FDekIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO3dDQUM1QixPQUFPLEVBQUU7NENBQ0wsRUFBRSxFQUFFO2dEQUNBLGNBQWM7Z0RBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTOzZDQUM1Qjt5Q0FDSjtxQ0FDSixDQUFDLENBQUM7Z0NBQ1AsSUFBSTtvQ0FDQSxPQUFPLENBQUMsS0FBSyxDQUFDO3dDQUNWLE9BQU8sRUFBRSwwQkFBMEI7d0NBQ25DLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTt3Q0FDNUIsT0FBTyxFQUFFOzRDQUNMLEVBQUUsRUFBRTtnREFDQSxjQUFjO2dEQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUzs2Q0FDNUI7eUNBQ0o7cUNBQ0osQ0FBQyxDQUFDOzRCQUNYLENBQUM7d0JBQ0wsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQzs0QkFDM0IsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7Z0NBQ25CLEtBQUssQ0FBQztvQ0FDRixPQUFPLENBQUMsS0FBSyxDQUFDO3dDQUNWLE9BQU8sRUFBRSxLQUFLLENBQUMsT0FBTzt3Q0FDdEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO3dDQUM1QixPQUFPLEVBQUU7NENBQ0wsRUFBRSxFQUFFO2dEQUNBLGNBQWM7Z0RBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTOzZDQUM1Qjt5Q0FDSjtxQ0FDSixDQUFDLENBQUM7b0NBQ0gsS0FBSyxDQUFDO2dDQUNWLEtBQUssQ0FBQztvQ0FDRixFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7d0NBQ25DLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLEtBQUssQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs0Q0FDN0UsT0FBTyxDQUFDLEtBQUssQ0FBQztnREFDVixPQUFPLEVBQUUsNkJBQTZCO2dEQUN0QyxTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0RBQzVCLE9BQU8sRUFBRTtvREFDTCxFQUFFLEVBQUU7d0RBQ0EsY0FBYzt3REFDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cURBQzVCO2lEQUNKOzZDQUNKLENBQUMsQ0FBQzs0Q0FDSCxLQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7NENBQ3ZCLE1BQU0sQ0FBQyxLQUFLLENBQUM7d0NBQ2pCLENBQUM7b0NBQ0wsQ0FBQztvQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSSxDQUFDLGdCQUFnQixDQUFDLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO3dDQUMxQyxPQUFPLENBQUMsS0FBSyxDQUFDOzRDQUNWLE9BQU8sRUFBRSx3QkFBd0I7NENBQ2pDLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTs0Q0FDNUIsT0FBTyxFQUFFO2dEQUNMLEVBQUUsRUFBRTtvREFDQSxjQUFjO29EQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztpREFDNUI7NkNBQ0o7eUNBQ0osQ0FBQyxDQUFDO29DQUNQLENBQUM7b0NBQ0QsS0FBSyxDQUFDO2dDQUNWO29DQUNJLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUM7NEJBQzFCLENBQUM7d0JBQ0wsQ0FBQztvQkFDTCxDQUFDLEVBQ0ssVUFBQSxHQUFHO3dCQUNELEVBQUUsQ0FBQyxDQUFDLE9BQU8sR0FBRyxDQUFDLEtBQUssSUFBSSxRQUFRLENBQUMsQ0FBQyxDQUFDOzRCQUMvQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLO2dDQUNwQyxTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQzVCLE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUFDLElBQUksQ0FBQyxDQUFDOzRCQUNKLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLGtDQUFrQztnQ0FDM0MsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUM1QixPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQztvQkFDTCxDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQzs0QkFDUixPQUFPLEVBQUUsK0JBQStCOzRCQUN4QyxTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7NEJBQzVCLE9BQU8sRUFBRTtnQ0FDTCxFQUFFLEVBQUU7b0NBQ0EsY0FBYztvQ0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7aUNBQzVCOzZCQUNKO3lCQUNKLENBQUMsQ0FBQztvQkFDUCxDQUFDLENBQ0EsQ0FBQTtnQkFDVCxDQUFDO2dCQUdELGtDQUFPLEdBQVA7b0JBQ0csWUFBWTtvQkFEZixpQkFxRkM7b0JBbEZHLElBQUksQ0FBQyxXQUFXLEdBQUc7d0JBQ2YsRUFBRSxJQUFJLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUU7d0JBQy9CLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsQ0FBQyxFQUFFO3FCQUNoQyxDQUFDO29CQUNGLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUM1QyxrREFBa0Q7b0JBQ2xELHNFQUFzRTtvQkFFdEUsSUFBSSxDQUFDLFlBQVksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDLFNBQVMsQ0FFN0MsVUFBQyxJQUFJO3dCQUNELElBQUksR0FBRyxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBRWpDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxhQUFhLENBQUM7NEJBQy9CLFlBQVksRUFBRSxJQUFJOzRCQUNsQixVQUFVLEVBQUUsRUFFWDs0QkFDRCw4QkFBOEI7NEJBQzlCLEtBQUssRUFBRSxVQUFVLENBQUM7Z0NBQ2QsSUFBSSxDQUFDLFVBQVUsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO2dDQUV6QixJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7NEJBQ25FLENBQUM7NEJBQ0QsVUFBVSxFQUFFLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUzt5QkFDakMsQ0FBQyxDQUFDO3dCQUNILE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLGVBQWUsQ0FBQzs0QkFDckMsTUFBTSxFQUFFLFlBQVk7eUJBQ3ZCLENBQUMsQ0FBQztvQkFDUCxDQUFDLEVBQ0QsVUFBQyxHQUFHO29CQUVKLENBQUMsRUFDRDtvQkFFQSxDQUFDLENBRUosQ0FBQztvQkFDRiw0Q0FBNEM7b0JBQzVDLDBCQUEwQjtvQkFDMUIsS0FBSztvQkFHTCxxRkFBcUY7b0JBQ3JGLGtGQUFrRjtvQkFDbEYsSUFBSSxDQUFDLFlBQVksQ0FBQyxpQkFBaUIsQ0FBQzt3QkFDaEMsY0FBYyxFQUFFOzRCQUNaLEtBQUssRUFBRSx1T0FNRjs0QkFDTCxVQUFVLEVBQUUsRUFBRTt5QkFDakI7d0JBQ0QsYUFBYSxFQUFFOzRCQUNYLEtBQUssRUFBRSwrRUFBK0U7NEJBQ3RGLFVBQVUsRUFBRSxFQUFFO3lCQUNqQjtxQkFDSixDQUFDLENBQUMsU0FBUyxDQUNSLFVBQUMsSUFBSTt3QkFFRCxXQUFXO3dCQUNYLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ2xCLElBQUksR0FBRyxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBRWpDLEtBQUksQ0FBQyxPQUFPLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDO3dCQUM1QyxLQUFJLENBQUMsaUJBQWlCLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDO3dCQUNyRCxJQUFJLFdBQVcsR0FBRyxFQUFFLENBQUM7d0JBQ3JCLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLGlCQUFpQixFQUFFOzRCQUNoQyxXQUFXLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQzs0QkFFekIsTUFBTSxDQUFDLEtBQUssQ0FBQzt3QkFDakIsQ0FBQyxDQUFDLENBQUM7d0JBRUgsMkRBQTJEO29CQUMvRCxDQUFDLEVBQ0QsVUFBQyxLQUFLLElBQU8sQ0FBQyxFQUNkLGNBQVEsQ0FBQyxDQUNSLENBQUM7Z0JBRVYsQ0FBQztnQkF6ckJMO29CQUFDLGdCQUFTLENBQUM7d0JBQ1AsSUFBSSxFQUFFLFVBQVU7d0JBQ2hCLEtBQUssRUFBRSxDQUFDLDBCQUFlLEVBQUUsK0JBQW9CLENBQUM7d0JBQzlDLFFBQVEsRUFBRSw4cFNBMkpUO3dCQUNELFVBQVUsRUFBRSxDQUFDLDZCQUFvQixDQUFDO3dCQUNsQyxTQUFTLEVBQUUsQ0FBQyx5QkFBVyxFQUFFLDJCQUFZLENBQUM7cUJBQ3pDLENBQUM7O29DQUFBO2dCQW9qQkYsdUJBQUM7WUFBRCxDQW5qQkEsQUFtakJDLElBQUE7WUFuakJELCtDQW1qQkMsQ0FBQSIsImZpbGUiOiJhbWF4L3Ntcy5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7Q29tcG9uZW50LCBPbkluaXR9IGZyb20gXCJhbmd1bGFyMi9jb3JlXCI7XHJcbmltcG9ydCB7U2VsZWN0SW5wdXRDb21wb25lbnR9IGZyb20gXCIuLi9jb21vbkNvbXBvbmVudHMvYmFzaWNDb21wb25lbnRzL3NlbGVjdFwiXHJcbmltcG9ydCB7QW1heFNlcnZpY2V9IGZyb20gXCIuLi9zZXJ2aWNlcy9BbWF4U2VydmljZVwiO1xyXG5pbXBvcnQge0dyb3VwRmlsdGVyUGlwZSwgR3JvdXBQYXJlbkZpbHRlclBpcGUsIEtlbmRvX3V0aWxpdHl9IGZyb20gXCIuLi9hbWF4VXRpbFwiO1xyXG5pbXBvcnQge1Jlc291cmNlU2VydmljZX0gZnJvbSBcIi4uL3NlcnZpY2VzL1Jlc291cmNlU2VydmljZVwiO1xyXG5pbXBvcnQge0xvY2FsRGljdCwgY3JtQ29uZmlnfSBmcm9tIFwiLi4vY3JtY29uZmlnXCI7XHJcbmltcG9ydCB7QW1heENybVN5aW5jfSBmcm9tIFwiLi4vc2VydmljZXMvQW1heENybVN5aW5jXCI7XHJcblxyXG5kZWNsYXJlIHZhciBqUXVlcnk7XHJcbmRlY2xhcmUgdmFyIHN3aXRjaF9kaXJlY3Rpb247XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIG5hbWU6ICdhbWF4LXNtcycsXHJcbiAgICBwaXBlczogW0dyb3VwRmlsdGVyUGlwZSwgR3JvdXBQYXJlbkZpbHRlclBpcGVdLFxyXG4gICAgdGVtcGxhdGU6IGA8ZGl2IGNsYXNzPVwicm93XCIgKm5nSWY9XCJSRVNcIj5cclxuXHJcbiAgICA8ZGl2IGNsYXNzPVwiY29sIHMxMiBjYXJkLXBhbmVsXCI+XHJcbjxkaXYgY2xhc3M9XCJyb3dcIj5cclxuPGRpdiBjbGFzcz1cImNvbCBzMTJcIj5cclxuPGgxPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGkgY2xhc3M9XCJtZGktY29udGVudC1zZWxlY3QtYWxsIGdyZWVuLXRleHRcIj48L2k+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cInJlZC10ZXh0XCI+e3tSRVMuTEJMX0hFQURJTkd9fTwvc3Bhbj4gIDwhLS17e1JFUy5DVVNUT01FUl9NQVNURVIuQ1VTVF9MQUJBTH19Q3VzdG9tZXItLT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9oMT5cclxuXHJcbjwvZGl2PlxyXG48YnV0dG9uIGNsYXNzPVwiYnRuIHdhdmVzLWVmZmVjdCB3YXZlcy1saWdodCBpbmRpZ28ge3sgX2FtYXhDcm1TeWluYy5pc1J0bCgpID8gJ3JpZ2h0JyA6ICdsZWZ0J319XCJcclxuICAgICAgICAgICAgICAgICAgICAoY2xpY2spPVwib3BlblNtc1NldHRpbmdzKClcIj5cclxuICAgICAgICAgICAgICAgIDxpIGNsYXNzPVwibWRpLWFjdGlvbi1zZXR0aW5nc1wiPjwvaT4ge3tSRVMuTEJMX1NFVFRJTkd9fVxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbjwvZGl2PlxyXG4gICAgICAgIDxkaXYgc3R5bGU9XCJvdmVyZmxvdzogaGlkZGVuO1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sIHMxMlwiPiZuYnNwOzwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGlkPVwiU21zU2V0dGluZ3NQYW5uZWxcIiBjbGFzcz1cImNvbCBzMTIgYW5pbWF0ZWQgc2xpZGVJbkRvd25cIiAqbmdJZj1cIm9wZW5TZXR0cmluZ3NcIj5cclxuICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbCBzMTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWw+e3tSRVMuTEJMX1NNU19QUk9WSURFUlN9fTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNlbGVjdCBjbGFzcz1cImJyb3dzZXItZGVmYXVsdFwiIFsobmdNb2RlbCldPSBcIlNlbGVjdGVkUHJvdmlkZXIudmFsdWVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCIxXCI+U21zIDIgeW91PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCIyXCI+MDE5IFNtczwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImlucHV0LWZpZWxkIGNvbCBzNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIGlkPVwiVXNlck5hbWVcIiBjbGFzcz1cImZvcm0tY29udHJvbFwiIFsobmdNb2RlbCldPSBcIlNlbGVjdGVkRGF0YS5Vc2VyTmFtZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBmb3I9XCJVc2VyTmFtZVwiIGNsYXNzPVwiYWN0aXZlXCI+e3tSRVMuTEJMX1NNU19VU0VSTkFNRX19PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImlucHV0LWZpZWxkIGNvbCBzNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dCBjbGFzcz1cImZvcm0tY29udHJvbFwiIHR5cGU9XCJwYXNzd29yZFwiIGlkPVwiUGFzc3dvcmRcIiBbKG5nTW9kZWwpXT0gXCJTZWxlY3RlZERhdGEuVmFsdWVcIi8+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGZvcj1cIlBhc3N3b3JkXCIgY2xhc3M9XCJhY3RpdmVcIj57e1JFUy5TTVNfUEFTU1dPUkR9fTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImlucHV0LWZpZWxkIGNvbCBzMTJcIj5cclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXQgY2xhc3M9XCJmb3JtLWNvbnRyb2xcIiBpZD1cIlBoTm9cIiB0eXBlPVwidGV4dFwiIFsobmdNb2RlbCldPVwiU2VuZGVyUGhvbmVOdW1iZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgZm9yPVwiUGhOb1wiIGNsYXNzPVwiYWN0aXZlXCI+e3tSRVMuTEJMX1NFTkRFUl9QSE9ORX19PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbCBzMTJcIj4mbmJzcDs8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wgczEyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzcz1cImJ0biB3YXZlcy1lZmZlY3Qgd2F2ZXMtbGlnaHQgZ3JlZW4gYWNjZW50LTRcIiAoY2xpY2spPVwic2F2ZVNtc1NldHRpbmdzKClcIiBzdHlsZT1cIndpZHRoOjIwMHB4IWltcG9ydGFudDtcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGkgY2xhc3M9XCJtZGktY29udGVudC1zYXZlXCI+PC9pPiB7e1JFUy5MQkxfU0FWRV9TRVRUSU5HfX1cclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuIHdhdmVzLWVmZmVjdCB3YXZlcy1saWdodCAgZ3JleSBsaWdodGVuLTJcIiAoY2xpY2spPVwiY2xvc2VTbXNTZXR0aW5ncygpXCJzdHlsZT1cIndpZHRoOjIwMHB4IWltcG9ydGFudDtcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGkgY2xhc3M9XCJtZGktbmF2aWdhdGlvbi1jbG9zZVwiPjwvaT4ge3tSRVMuTEJMX0NMT1NFX1NFVFRJTkdTfX1cclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbCBzMTJcIiAqbmdJZj1cIiFvcGVuU2V0dHJpbmdzXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwicm93XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbCBzNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwicm93XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sIHMxMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbD57e1JFUy5MQkxfR1JPVVBTfX08L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJrLWNvbnRlbnQge3tLZW5kb1JUTENTU319XCIgc3R5bGU9XCJtYXgtaGVpZ2h0OiAyMzBweDtvdmVyZmxvdy15OiBhdXRvOyBwYWRkaW5nOiAyMHB4IDEwcHggNDBweDsgbWFyZ2luLWxlZnQ6MTBweDtcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBpZD1cImdyb3VwVHJlZVwiIHN0eWxlPVwib3ZlcmZsb3c6IHZpc2libGU7XCI+IExvYWRpbmcuLi48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sIHM2XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJyb3dcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wgczEyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsPnt7UkVTLkxCTF9QSE9ORV9UWVBFU319PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bXgtc2VsZWN0IFtkYXRhXT1cIlBob25lVHlwZUxpc3REYXRhXCIgbGFiZWw9XCJMYWJlbFwiIHNlbGVjdGVkdmFsPVwiQWxsXCIgZmlyc3R2YWx1ZT1cIkFsbFwiIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKG9uRGF0YSk9XCJTZWxlY3RlZFBob25lVHlwZSA9ICRldmVudFwiIGNzc2NsYXNzPVwiYnJvd3Nlci1kZWZhdWx0XCIgaWQ9XCJQaG9udFR5cGVzZWxcIj48L214LXNlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbCBzMTJcIj4mbmJzcDs8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wgczEyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInJvd1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGV0YWlscz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdW1tYXJ5Pnt7UkVTLkxCTF9TRU5EX0xBVEVSfX08L3N1bW1hcnk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sIHM2XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsPnt7UkVTLlNNU19MQkxfREFURX19PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiay1jb250ZW50XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCBjbGFzcz1cImZvcm0tY29udHJvbFwiIGlkPVwic2VuZExhdGVyRGF0ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sIHMzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsPnt7UkVTLlNNU19MQkxfSFJ9fTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdCBjbGFzcz1cImJyb3dzZXItZGVmYXVsdFwiIGlkPVwic2VuZExhdGVySG91clwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uPjAxPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24+MDI8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbj4wMzwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uPjA0PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24+MDU8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbj4wNjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uPjA3PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24+MDg8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbj4wOTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uPjEwPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24+MTE8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbj4xMjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uPjEzPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24+MTQ8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbj4xNTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uPjE2PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24+MTc8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbj4xODwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uPjE5PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24+MjA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbj4yMTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uPjIyPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24+MjM8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbj4yNDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sIHMzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsPnt7UkVTLlNNU19MQkxfTUlOfX08L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3QgY2xhc3M9XCJicm93c2VyLWRlZmF1bHRcIiBpZD1cInNlbmRMYXRlck1pblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uPjAwPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24+MDU8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbj4xMDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uPjE1PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24+MjA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbj4yNTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uPjMwPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24+MzU8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbj40MDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uPjQ1PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24+NTA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbj41NTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uPjYwPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kZXRhaWxzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sIHMxMlwiPiZuYnNwOzwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbCBzMTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWw+e3tSRVMuTEJMX01FU1NBR0V9fTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRleHRhcmVhIGNvbHM9XCI1MFwiICNtc2cgKGtleXVwKT1cIm1lc3NhZ2U9bXNnLnZhbHVlXCIgY2xhc3M9XCJmb3JtLWNvbnRyb2xcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cInt7UkVTLlNNU19UWFRfUEhfTUVTU0FHRX19XCIgKGNoYW5nZSk9XCJTZXRkZWZhdWx0TXNnVmFsdWUoKVwiIGlkPVwiTWVzc2FnZXR4dGFyXCIgWyhuZ01vZGVsKV09IFwibWVzc2FnZVwiPjwvdGV4dGFyZWE+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnt7UkVTLlNNU19MQkxfTUFYQ0hBUn19IDoge3ttc2cudmFsdWUubGVuZ3RofHwwfX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbCBzMTJcIiBpZD1cIlNlbGVjdGVkQ3VzdG9tZXJzXCI+Jm5ic3A7PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbCBzMTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzcz1cImJ0biB3YXZlcy1lZmZlY3Qgd2F2ZXMtbGlnaHQgZ3JlZW4gYWNjZW50LTRcIiBzdHlsZT1cIndpZHRoOjE3NXB4IWltcG9ydGFudDtcIiAoY2xpY2spPVwiU2VuZFRvU2VsZWN0ZWRHcm91cHMoKVwiPnt7UkVTLlNNU19CVE5fU0VORE1FU1NBR0V9fTwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzcGFjZS00XCI+PGRpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGJyLz48YnIvPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgYCxcclxuICAgIGRpcmVjdGl2ZXM6IFtTZWxlY3RJbnB1dENvbXBvbmVudF0sXHJcbiAgICBwcm92aWRlcnM6IFtBbWF4U2VydmljZSwgQW1heENybVN5aW5jXVxyXG59KVxyXG5leHBvcnQgY2xhc3MgQW1heFNtc0NvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcbiAgICBwcml2YXRlIFJFUzogYW55O1xyXG4gICAgcHJpdmF0ZSBvcGVuU2V0dHJpbmdzOiBib29sZWFuID0gZmFsc2U7XHJcblxyXG4gICAgU21zRGF0YTogQXJyYXk8YW55PjtcclxuICAgIFNlbGVjdGVkRGF0YTogT2JqZWN0ID0ge307XHJcbiAgICBzZWxlY3RlZFZhbHVlOiBzdHJpbmc7XHJcbiAgICBTbXNQcm92aWRlcjogQXJyYXk8YW55PjtcclxuICAgIFNlbGVjdGVkUHJvdmlkZXI6IE9iamVjdCA9IHt9O1xyXG5cclxuICAgIENvbmZpcm1lZFNlbmQ6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIExhbmd1YWdlOiBzdHJpbmc7XHJcbiAgICBQaG9uZVR5cGVMaXN0RGF0YTogQXJyYXk8YW55PjtcclxuICAgIFNlbGVjdGVkUGhvbmVUeXBlOiBPYmplY3QgPSB7fTtcclxuICAgIHVzZXJOYW1lOiBzdHJpbmc7XHJcbiAgICBtZXNzYWdlOiBzdHJpbmc7XHJcbiAgICBTZW5kZXJQaG9uZU51bWJlcjogc3RyaW5nO1xyXG4gICAgS2VuZG9SVExDU1M6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBDaGFuZ2VEaWFsb2c6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBDSEFOR0VESVI6IHN0cmluZyA9IFwiXCI7XHJcblxyXG5cclxuXHJcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIF9hbWF4U2VydmljZTogQW1heFNlcnZpY2UsIHByaXZhdGUgX3Jlc291cmNlU2VydmljZTogUmVzb3VyY2VTZXJ2aWNlLCBwcml2YXRlIF9hbWF4Q3JtU3lpbmM6IEFtYXhDcm1TeWluYykge1xyXG4gICAgICAgIHRoaXMuU2VsZWN0ZWREYXRhLlVzZXJOYW1lID0gXCJcIjtcclxuICAgICAgICB0aGlzLlNlbGVjdGVkRGF0YS5WYWx1ZSA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5TZW5kZXJQaG9uZU51bWJlciA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5TZWxlY3RlZFBob25lVHlwZS5WYWx1ZSA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5TZWxlY3RlZFByb3ZpZGVyLnZhbHVlID0gXCJcIjtcclxuICAgICAgICB2YXIgZW1waWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImVtcGxveWVlaWRcIik7XHJcbiAgICAgICAgdmFyIG1lc3NhZ2UgPSB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZ2V0Q29va2llKGVtcGlkK1wiU01TTWVzc2FnZVwiKTtcclxuICAgICAgICBpZiAobWVzc2FnZS5sZW5ndGggPiAwICYmIG1lc3NhZ2VbMF0gPT0gXCI9XCIpXHJcbiAgICAgICAgICAgIG1lc3NhZ2UgPSBtZXNzYWdlLnN1YnN0cmluZygxLCBtZXNzYWdlLmxlbmd0aCk7XHJcbiAgICAgICAgdGhpcy5tZXNzYWdlID0gbWVzc2FnZTtcclxuXHJcbiAgICB9XHJcbiAgICBTZXRkZWZhdWx0TXNnVmFsdWUoKSB7XHJcbiAgICAgICAgLy9hbGVydCgnSGVsbG8nKTtcclxuICAgICAgICB2YXIgZW1waWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImVtcGxveWVlaWRcIik7XHJcbiAgICAgICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLnNldENvb2tpZShlbXBpZCArIFwiU01TTWVzc2FnZVwiLCB0aGlzLm1lc3NhZ2UsIDEwKTtcclxuXHJcbiAgICAgICAgXHJcbiAgICAgICAgLy9hbGVydChtZXNzYWdlKTtcclxuICAgIH1cclxuICAgIG5nT25Jbml0KCkge1xyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgXHJcbiAgICAgICAgLy90aGlzLl9hbWF4Q3JtU3lpbmMub24oJ2xzc2V0LicgKyBMb2NhbERpY3QubGFuZ3VhZ2VSZXNvdXJjZSwgZGF0YT0+IHRoaXMuUkVTID0gZGF0YVtcIlNDUkVFTl9TTVNcIl0pO1xyXG4gICAgICAgIC8vdGhpcy5SRVMgPSB0aGlzLl9hbWF4Q3JtU3lpbmMuZmV0Y2hMYW5ndWFnZVJlc291cmNlKFwiU0NSRUVOX1NNU1wiKTtcclxuXHJcblxyXG5cclxuXHJcblxyXG4gICAgICAgIC8vYWxlcnQoJ2hlbGxvJyk7XHJcbiAgICAgICAgLy9sb2FkaW5nTGFuZ3VhZ2Ugc3RhcnRcclxuICAgICAgICBcclxuICAgICAgICBcclxuICAgICAgICB0aGlzLl9hbWF4Q3JtU3lpbmMub24oJ2xzc2V0LicgKyBMb2NhbERpY3QubGFuZ3VhZ2VSZXNvdXJjZSwgZGF0YT0+IHRoaXMuUkVTID0gZGF0YVtcIlNDUkVFTl9TTVNcIl0pO1xyXG4gICAgICAgIHRoaXMuUkVTID0gdGhpcy5fYW1heENybVN5aW5jLmZldGNoTGFuZ3VhZ2VSZXNvdXJjZShcIlNDUkVFTl9TTVNcIik7XHJcbiAgICAgICAgLy9kZWJ1Z2dlcjtcclxuXHJcbiAgICAgICAgaWYgKCF0aGlzLlJFUykge1xyXG4gICAgICAgICAgICBpZiAoIWxvY2FsU3RvcmFnZS5nZXRJdGVtKExvY2FsRGljdC5zZWxlY3RlZExhbmd1YWdlKSkge1xyXG4gICAgICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oTG9jYWxEaWN0LnNlbGVjdGVkTGFuZ3VhZ2UsIGNybUNvbmZpZy5mYWxiYWNrTGFuZ3VhZ2UpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRoaXMuTGFuZ3VhZ2UgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImxhbmdcIik7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLkxhbmd1YWdlID09IFwiaGVcIikge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5LZW5kb1JUTENTUyA9IFwiay1ydGxcIjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0aGlzLl9hbWF4Q3JtU3lpbmMubG9hZExhbmd1YWdlUmVzb3VyY2UobG9jYWxTdG9yYWdlLmdldEl0ZW0oTG9jYWxEaWN0LnNlbGVjdGVkTGFuZ3VhZ2UpKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICAgICAgLy9sb2FkaW5nTGFuZ3VhZ2Ugc3RhcnRcclxuICAgICAgICB0aGlzLmFsbEJpbmQoKTtcclxuICAgICAgICAvL2FsZXJ0KCdCeWUnKTtcclxuICAgICAgICAvL3ZhciBtZXNzYWdlID0gdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmdldENvb2tpZShcIlNNU01lc3NhZ2VcIik7XHJcbiAgICAgICAgLy9pZiAobWVzc2FnZS5sZW5ndGggPiAwICYmIG1lc3NhZ2VbMF0gPT0gXCI9XCIpXHJcbiAgICAgICAgLy8gICAgbWVzc2FnZSA9IG1lc3NhZ2Uuc3Vic3RyaW5nKDEsIG1lc3NhZ2UubGVuZ3RoKTtcclxuICAgICAgICAvL3RoaXMubWVzc2FnZSA9IG1lc3NhZ2U7XHJcbiAgICAgICAgXHJcbiAgICB9XHJcblxyXG4gICAgLy9zYXZlU21zU2V0dGluZ3MoKXtcclxuICAgIC8vICAgIGFsZXJ0KFwiU21zIFNldHRpbmcgc2F2ZWQuXCIpO1xyXG4gICAgLy8gICAgdGhpcy5vcGVuU2V0dHJpbmdzPWZhbHNlO1xyXG4gICAgLy99XHJcbiAgICAvL29wZW5TbXNTZXR0aW5ncygpe1xyXG4gICAgLy8gICAgdGhpcy5vcGVuU2V0dHJpbmdzPXRydWU7XHJcbiAgICAvLyAgICAvL3NldFRpbWVvdXQoZnVuY3Rpb24gKCkge1xyXG4gICAgLy8gICAgLy8gICAgalF1ZXJ5KCcjU21zU2V0dGluZ3NQYW5uZWwnKS5hZGRDbGFzcygnYW5pbWF0ZWQgYm91bmNlSW5Eb3duJyk7XHJcbiAgICAvLyAgICAvL30sMjAwKTtcclxuICAgIC8vfVxyXG4gICAgLy9jbG9zZVNtc1NldHRpbmdzKCl7XHJcbiAgICAvLyAgICBqUXVlcnkoJyNTbXNTZXR0aW5nc1Bhbm5lbCcpLmFkZENsYXNzKCdhbmltYXRlZCBzbGlkZU91dERvd24nKTtcclxuICAgIC8vICAgIHNldFRpbWVvdXQoKCk9PntcclxuICAgIC8vICAgICAgICB0aGlzLm9wZW5TZXR0cmluZ3M9ZmFsc2U7XHJcbiAgICAvLyAgICB9LDIwMCk7XHJcbiAgICAvL31cclxuXHJcblxyXG5cclxuXHJcblxyXG5cclxuICAgIFxyXG4gICAgc2F2ZVNtc1NldHRpbmdzKCkge1xyXG4gICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAgdmFyIGpzb25PYmplY3QgPSB7IFVzZXJOYW1lOiBcIlwiLCBWYWx1ZTogXCJcIiwgU2VsZWN0ZWRQcm92aWRlcjogXCJcIiwgU2VuZGVyUGhvbmVOdW1iZXI6IFwiXCIgfTtcclxuICAgICAgICBqc29uT2JqZWN0LlVzZXJOYW1lID0gdGhpcy5TZWxlY3RlZERhdGEuVXNlck5hbWU7XHJcbiAgICAgICAgLy9qc29uT2JqZWN0LlZhbHVlID0gdGhpcy5TZWxlY3RlZERhdGEuVmFsdWU7XHJcblxyXG4gICAgICAgIC8vanNvbk9iamVjdC5Vc2VyTmFtZSA9ICQoXCIjVXNlcl90eHRcIikudmFsOy8vdGhpcy5TZWxlY3RlZERhdGEuVXNlck5hbWU7XHJcbiAgICAgICAgLy9qc29uT2JqZWN0LlZhbHVlID0gJChcIiNQYXNzX3R4dFwiKS52YWw7Ly90aGlzLlNlbGVjdGVkRGF0YS5WYWx1ZTtcclxuXHJcbiAgICAgICAganNvbk9iamVjdC5TZWxlY3RlZFByb3ZpZGVyID0gdGhpcy5TZWxlY3RlZFByb3ZpZGVyLnZhbHVlO1xyXG4gICAgICAgIGpzb25PYmplY3QuU2VuZGVyUGhvbmVOdW1iZXIgPSB0aGlzLlNlbmRlclBob25lTnVtYmVyO1xyXG4gICAgICAgIFxyXG4gICAgICAgIGlmIChqc29uT2JqZWN0LlVzZXJOYW1lICYmIHRoaXMuU2VsZWN0ZWREYXRhLlZhbHVlICYmIGpzb25PYmplY3QuU2VsZWN0ZWRQcm92aWRlciAmJiBqc29uT2JqZWN0LlNlbmRlclBob25lTnVtYmVyKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2FtYXhDcm1TeWluYy5zdG9yZUxvY2FsKExvY2FsRGljdC5TbXNTZXR0aW5ncywganNvbk9iamVjdCk7XHJcbiAgICAgICAgICAgIHZhciBlbXBpZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiZW1wbG95ZWVpZFwiKTtcclxuICAgICAgICAgICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLnNldENvb2tpZShlbXBpZCArIFwiU01TRGV0XCIsIEpTT04uc3RyaW5naWZ5KGpzb25PYmplY3QpLCAxMCk7XHJcbiAgICAgICAgICAgIHRoaXMuY2xvc2VTbXNTZXR0aW5ncygpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgbWVzc2FnZTogXCJQbGVhc2UgVmFyaWZ5ZSB0aGUgc2V0dGluZ3NcIixcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgb3BlblNtc1NldHRpbmdzKCkge1xyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgdGhpcy5vcGVuU2V0dHJpbmdzID0gdHJ1ZTtcclxuICAgICAgICAvL3ZhciBqc29uT2JqZWN0ID0gSlNPTi5wYXJzZSh0aGlzLl9hbWF4Q3JtU3lpbmMuZmV0Y2hMb2NhbChMb2NhbERpY3QuU21zU2V0dGluZ3MpKTtcclxuICAgICAgICB2YXIgZW1waWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImVtcGxveWVlaWRcIik7XHJcbiAgICAgICAgdmFyIGRhdGEgPSB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZ2V0Q29va2llKGVtcGlkICsgXCJTTVNEZXRcIik7XHJcbiAgICAgICAgdmFyIGpzb25PYmplY3QgPSB7fTtcclxuICAgICAgICBpZiAoZGF0YS5sZW5ndGggPiAwKVxyXG4gICAgICAgICAgICBqc29uT2JqZWN0ID0galF1ZXJ5LnBhcnNlSlNPTihkYXRhLnN1YnN0cmluZygxLCBkYXRhLmxlbmd0aCkpO1xyXG4gICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAgaWYgKGpzb25PYmplY3QgIT0gbnVsbCkge1xyXG4gICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHRoaXMuU21zRGF0YS5sZW5ndGg7IGkrKylcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLlNtc0RhdGFbaV0uVXNlck5hbWUgPT0ganNvbk9iamVjdC5Vc2VyTmFtZSlcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLlNlbGVjdGVkRGF0YS5Vc2VyTmFtZSA9IHRoaXMuU21zRGF0YVtpXS5Vc2VyTmFtZTsgICAvLyYmIHRoaXMuU21zRGF0YVtpXS5WYWx1ZSA9PSBqc29uT2JqZWN0LlZhbHVlXHJcblxyXG4gICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHRoaXMuU21zUHJvdmlkZXIubGVuZ3RoOyBpKyspXHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5TbXNQcm92aWRlcltpXS52YWx1ZSA9PSBqc29uT2JqZWN0LlNlbGVjdGVkUHJvdmlkZXIpIHRoaXMuU2VsZWN0ZWRQcm92aWRlciA9IHRoaXMuU21zUHJvdmlkZXJbaV07XHJcblxyXG4gICAgICAgICAgICB0aGlzLlNlbmRlclBob25lTnVtYmVyID0ganNvbk9iamVjdC5TZW5kZXJQaG9uZU51bWJlcjtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuU2VsZWN0ZWREYXRhLlVzZXJOYW1lID0gXCJcIjtcclxuICAgICAgICAgICAgdGhpcy5TZWxlY3RlZERhdGEuVmFsdWUgPSBcIlwiO1xyXG4gICAgICAgICAgICB0aGlzLlNlbmRlclBob25lTnVtYmVyID0gXCJcIjtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBjbG9zZVNtc1NldHRpbmdzKCkge1xyXG4gICAgICAgIHRoaXMub3BlblNldHRyaW5ncyA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMuYWxsQmluZCgpO1xyXG4gICAgfVxyXG5cclxuICAgIGRvTm90aGluZygpIHtcclxuICAgIH1cclxuXHJcbiAgICBvcGVuTW9kZWwoKSB7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIHNldFNtc0NvbXBhbnlMaXN0KGRhdGE6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuU21zRGF0YSA9IGRhdGE7XHJcbiAgICAgICAgdGhpcy5TZWxlY3RlZERhdGEgPSB0aGlzLlNtc0RhdGFbMF07XHJcbiAgICB9XHJcbiAgICBiaW5kUGhvbmVUeXBlTGlzdChkYXRhOiBhbnkpOiB2b2lkIHtcclxuXHJcbiAgICAgICAgdGhpcy5QaG9uZVR5cGVMaXN0RGF0YSA9IGRhdGE7XHJcbiAgICAgICAgdGhpcy5TZWxlY3RlZFBob25lVHlwZSA9IHRoaXMuUGhvbmVUeXBlTGlzdERhdGFbMF07XHJcbiAgICB9XHJcbiAgICBiaW5kR2VuZXJhbEdyb3VwVHJlZShkYXRhOiBhbnkpOiB2b2lkIHtcclxuICAgICAgIC8vIGRlYnVnZ2VyO1xyXG4gICAgICAgIGpRdWVyeShcIiNncm91cFRyZWVcIikuaHRtbChcIkxvZGluZy4uLlwiKTtcclxuICAgICAgICB2YXIgcmVzID0galF1ZXJ5LnBhcnNlSlNPTihkYXRhKTtcclxuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICAgICAgalF1ZXJ5KFwiI2dyb3VwVHJlZVwiKS5rZW5kb1RyZWVWaWV3KHtcclxuICAgICAgICAgICAgICAgIGxvYWRPbkRlbWFuZDogdHJ1ZSxcclxuICAgICAgICAgICAgICAgIGNoZWNrYm94ZXM6IHtcclxuICAgICAgICAgICAgICAgICAgICBjaGVja0NoaWxkcmVuOiB0cnVlXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgZGF0YVNvdXJjZTogcmVzLkRhdGEua2VuZG9UcmVlXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICBqUXVlcnkoXCIjc2VuZExhdGVyRGF0ZVwiKS5rZW5kb0RhdGVQaWNrZXIoe1xyXG4gICAgICAgICAgICAgICAgZm9ybWF0OiBcImRkLU1NLXl5eXlcIlxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgc3dpdGNoX2RpcmVjdGlvbigpO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgICAgIDEwMDApO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICBnZXRTZWxlY3RlZEdyb3VwcygpOiBBcnJheTxudW1iZXI+IHtcclxuICAgICAgICB2YXIgX0NoZWNrZWRHcm91cHMgPSBbXTtcclxuICAgICAgICBLZW5kb191dGlsaXR5LmNoZWNrZWROb2RlSWRzKGpRdWVyeShcIiNncm91cFRyZWVcIikuZGF0YShcImtlbmRvVHJlZVZpZXdcIikuZGF0YVNvdXJjZS52aWV3KCksIF9DaGVja2VkR3JvdXBzKTtcclxuICAgICAgICByZXR1cm4gX0NoZWNrZWRHcm91cHM7XHJcbiAgICB9XHJcblxyXG4gICAgU2VuZFRvU2VsZWN0ZWRHcm91cHMoKSB7XHJcbiAgICAgICAgLy91c2VybmFtZTpzdHJpbmcsY29tcGFueTpzdHJpbmcsbWVzc2FnZTpzdHJpbmcsZ3JvdXBzOkFycmF5PGFueT4scGhvbmVUeXBlSWQ6bnVtYmVyXHJcbiAgICAgICAgZGVidWdnZXI7XHJcbiAgICAgICAgaWYgKHRoaXMuU2VsZWN0ZWRQaG9uZVR5cGUgPT0gdW5kZWZpbmVkIHx8IHRoaXMuU2VsZWN0ZWRQaG9uZVR5cGUgPT0gbnVsbCB8fCB0aGlzLlNlbGVjdGVkUGhvbmVUeXBlLlZhbHVlPT1cIlwiKSB7XHJcbiAgICAgICAgICAgIHRoaXMuU2VsZWN0ZWRQaG9uZVR5cGUuVmFsdWUgPSAwO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodGhpcy5TZWxlY3RlZFBob25lVHlwZS5WYWx1ZSA9PSAxICYmIHRoaXMuU2VuZGVyUGhvbmVOdW1iZXIubGVuZ3RoICE9IDEwKSB7XHJcbiAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgbWVzc2FnZTogXCJTZW5kZXIgTXVzdCBiZSAxMCBEaWdpdCB2YWxpZCBjZWxscGhvbmUgbnVtYmVyXCIsXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB0aGlzLm9wZW5TbXNTZXR0aW5ncygpO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHZhciBfc2VsZWN0ZWRHcm91cHMgPSB0aGlzLmdldFNlbGVjdGVkR3JvdXBzKCk7XHJcbiAgICAgICAgdmFyIHN0YXR1cyA9IFwib2tcIjtcclxuXHJcbiAgICAgICAgaWYgKF9zZWxlY3RlZEdyb3Vwcy5sZW5ndGggPT0gMCkgc3RhdHVzID0gXCJObyBncm91cHMgc2VsZWN0ZWRcIjtcclxuICAgICAgICAvL2Vsc2UgaWYgKCF0aGlzLlNlbGVjdGVkRGF0YS5Vc2VyTmFtZSB8fCAhdGhpcy5TZWxlY3RlZERhdGEuVmFsdWUpIHN0YXR1cyA9IFwiUGxlYXNlIHNlbGVjdCBhIHByb3ZpZGVyXCI7XHJcbiAgICAgICAgLy9lbHNlIGlmICghdGhpcy5tZXNzYWdlKSBzdGF0dXMgPSBcIk1lc3NhZ2UgY2FuJ3QgYmUgZW1wdHlcIjtcclxuXHJcbiAgICAgICAgaWYgKHN0YXR1cyAhPSBcIm9rXCIpIHtcclxuICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICBtZXNzYWdlOiBzdGF0dXMsXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfTtcclxuICAgICAgICB2YXIgc2VuZGxhdGVyID0galF1ZXJ5KCcjc2VuZExhdGVyRGF0ZScpLnZhbCgpICsgXCIgXCIgKyBqUXVlcnkoJyNzZW5kTGF0ZXJIb3VyJykudmFsKCkgKyBcIjpcIiArIGpRdWVyeSgnI3NlbmRMYXRlck1pbicpLnZhbCgpO1xyXG4gICAgICAgIGlmIChzZW5kbGF0ZXIubGVuZ3RoICE9IDE2KSBzZW5kbGF0ZXIgPSBcIlwiO1xyXG5cclxuICAgICAgICB2YXIgc21zU2V0dGluZ3MgPSBKU09OLnBhcnNlKHRoaXMuX2FtYXhDcm1TeWluYy5mZXRjaExvY2FsKExvY2FsRGljdC5TbXNTZXR0aW5ncykpO1xyXG4gICAgICAgIGlmICghc21zU2V0dGluZ3MpIHtcclxuICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICBtZXNzYWdlOiBcIlNtcyBTZXR0aW5ncyBub3QgZm91bmRcIixcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIHRoaXMub3BlblNtc1NldHRpbmdzKCk7XHJcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHNtc1NldHRpbmdzLlZhbHVlID0gdGhpcy5TZWxlY3RlZERhdGEuVmFsdWU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuX2FtYXhTZXJ2aWNlLlNlbmRTbXMoXHJcbiAgICAgICAgICAgIHNtc1NldHRpbmdzLlVzZXJOYW1lLFxyXG4gICAgICAgICAgICBzbXNTZXR0aW5ncy5WYWx1ZSxcclxuICAgICAgICAgICAgdGhpcy5tZXNzYWdlLFxyXG4gICAgICAgICAgICB0aGlzLmdldFNlbGVjdGVkR3JvdXBzKCksXHJcbiAgICAgICAgICAgIHRoaXMuU2VsZWN0ZWRQaG9uZVR5cGUuVmFsdWVcclxuICAgICAgICAgICAgLCBzbXNTZXR0aW5ncy5TZWxlY3RlZFByb3ZpZGVyLFxyXG4gICAgICAgICAgICAhdGhpcy5Db25maXJtZWRTZW5kLFxyXG4gICAgICAgICAgICB0aGlzLkNvbmZpcm1lZFNlbmQsXHJcbiAgICAgICAgICAgIHNtc1NldHRpbmdzLlNlbmRlclBob25lTnVtYmVyLFxyXG4gICAgICAgICAgICBzZW5kbGF0ZXJcclxuICAgICAgICApLnN1YnNjcmliZShkYXRhPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhkYXRhKTtcclxuICAgICAgICAgICAgZGVidWdnZXI7XHJcbiAgICAgICAgICAgIHZhciBfZGF0YSA9IGpRdWVyeS5wYXJzZUpTT04oZGF0YSkuRGF0YTtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIC8qalF1ZXJ5KFwiI1NlbGVjdGVkQ3VzdG9tZXJzXCIpLmtlbmRvR3JpZCh7XHJcbiAgICAgICAgICAgICAgICBkYXRhU291cmNlOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgZGF0YTogX2RhdGEuQ3VzdG9tZXJzXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgaGVpZ2h0OiAzNTAsXHJcbiAgICAgICAgICAgICAgICBzZWxlY3RhYmxlOiBcIm11bHRpcGxlXCJcclxuICAgICAgICAgICAgfSk7Ki9cclxuICAgICAgICAgICAgaWYgKCF0aGlzLkNvbmZpcm1lZFNlbmQpIHtcclxuICAgICAgICAgICAgICAgIGlmIChfZGF0YS5lcnIpIHtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IF9kYXRhLmVycixcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMub3BlblNtc1NldHRpbmdzKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgaWYgKF9kYXRhLkVycm9yKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IF9kYXRhLkVycm9yLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgdmFyIFJlbWFpbmluZ0NyZWRpdCA9IF9kYXRhLlJlbWFpbmluZ0NyZWRpdDtcclxuICAgICAgICAgICAgICAgIHZhciBUb3RhbEN1c3RvbWVycyA9IF9kYXRhLlRvdGFsQ3VzdG9tZXJzO1xyXG5cclxuICAgICAgICAgICAgICAgIGlmIChSZW1haW5pbmdDcmVkaXQgPiAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKFJlbWFpbmluZ0NyZWRpdCA+IFRvdGFsQ3VzdG9tZXJzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBtZXNzYWdlID0gXCJUb3RhbCBjdXN0b21lcnMgOiBcIiArIFRvdGFsQ3VzdG9tZXJzO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlICs9IFwiXFxuUmVtYWluaW5nIENyZWFkaXQgZm9yIHNtcyA6IFwiICsgUmVtYWluaW5nQ3JlZGl0O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlICs9IFwiXFxuXFxuUHJvY2lkZSB0byBzZW5kID9cIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGNvbmZpcm0obWVzc2FnZSkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuQ29uZmlybWVkU2VuZCA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLlNlbmRUb1NlbGVjdGVkR3JvdXBzKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgUmVtYWluaW5nQ3JlZGl0ICE9ICd1bmRlZmluZWQnKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiTm8gU01TIGNyZWFkaXRcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgZWxzZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiRXJyb3IgcHJvY2Vzc2luZyByZXF1ZXN0XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5Db25maXJtZWRTZW5kID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICBzd2l0Y2ggKF9kYXRhLnN0YXR1cykge1xyXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMTpcclxuICAgICAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBfZGF0YS5tZXNzYWdlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAwOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5TZWxlY3RlZFByb3ZpZGVyLnZhbHVlID09IDEpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChfZGF0YS5lcnIuaW5kZXhPZihcIkVSUk9SXCIpID4gLTEgJiYgX2RhdGEuZXJyLmluZGV4T2YoXCJTRU5ERVJfUFJFRklYXCIpID4gLTEpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogXCJJbnZhbGlkIFNlbmRlciBQaG9uZSBOdW1iZXJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMub3BlblNtc1NldHRpbmdzKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKHRoaXMuU2VsZWN0ZWRQcm92aWRlci52YWx1ZSA9PSAyKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBcIlVuYWJsZSBUbyBTZW5kIE1lc3NhZ2VcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhkYXRhKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICAgICAgLCBlcnI9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIGVyci5fYm9keSA9PSAnc3RyaW5nJykge1xyXG4gICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBKU09OLnBhcnNlKGVyci5fYm9keSkuZXJyb3IsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiVW5hYmxlIHRvIGNvbm5lY3QgdG8gdGhlIFNlcnZpY2VcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogXCJTbXMgc2VuZCByZXNwb25jZSBjb21wbGVhdGVkIVwiLFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIClcclxuICAgIH1cclxuXHJcblxyXG4gICAgYWxsQmluZCgpIHtcclxuICAgICAgIC8vIGRlYnVnZ2VyO1xyXG5cclxuICAgICAgICB0aGlzLlNtc1Byb3ZpZGVyID0gW1xyXG4gICAgICAgICAgICB7IG5hbWU6IFwiU21zIDIgWW91XCIsIHZhbHVlOiAxIH0sXHJcbiAgICAgICAgICAgIHsgbmFtZTogXCIwMTkgU21zXCIsIHZhbHVlOiAyIH1cclxuICAgICAgICBdO1xyXG4gICAgICAgIHRoaXMuU2VsZWN0ZWRQcm92aWRlciA9IHRoaXMuU21zUHJvdmlkZXJbMF07XHJcbiAgICAgICAgLy9hbGVydCh0aGlzLl9hbWF4U2VydmljZS5HZXRHZW5lcmFsR3JvdXBUcmVlKDApKTtcclxuICAgICAgICAvL3RoaXMuYmluZEdlbmVyYWxHcm91cFRyZWUodGhpcy5fYW1heFNlcnZpY2UuR2V0R2VuZXJhbEdyb3VwVHJlZSgwKSk7XHJcblxyXG4gICAgICAgIHRoaXMuX2FtYXhTZXJ2aWNlLkdldEdlbmVyYWxHcm91cFRyZWUoKS5zdWJzY3JpYmUoXHJcblxyXG4gICAgICAgICAgICAoZGF0YSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgdmFyIHJlcyA9IGpRdWVyeS5wYXJzZUpTT04oZGF0YSk7XHJcblxyXG4gICAgICAgICAgICAgICAgalF1ZXJ5KFwiI2dyb3VwVHJlZVwiKS5rZW5kb1RyZWVWaWV3KHtcclxuICAgICAgICAgICAgICAgICAgICBsb2FkT25EZW1hbmQ6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tib3hlczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2NoZWNrQ2hpbGRyZW46IHRydWVcclxuICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgIC8vLy9jaGVjazogdGhpcy5vbkdyb3VwU2VsZWN0LFxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrOiBmdW5jdGlvbiAoZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmV4cGFuZFJvb3QgPSBlLm5vZGU7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmV4cGFuZChqUXVlcnkodGhpcy5leHBhbmRSb290KS5maW5kKFwiLmstaXRlbVwiKS5hZGRCYWNrKCkpO1xyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgZGF0YVNvdXJjZTogcmVzLkRhdGEua2VuZG9UcmVlXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIGpRdWVyeShcIiNzZW5kTGF0ZXJEYXRlXCIpLmtlbmRvRGF0ZVBpY2tlcih7XHJcbiAgICAgICAgICAgICAgICAgICAgZm9ybWF0OiBcImRkLU1NLXl5eXlcIlxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIChlcnIpID0+IHtcclxuXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICgpID0+IHtcclxuXHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgKTtcclxuICAgICAgICAvL2pRdWVyeShcIiNzZW5kTGF0ZXJEYXRlXCIpLmtlbmRvRGF0ZVBpY2tlcih7XHJcbiAgICAgICAgLy8gICAgZm9ybWF0OiBcImRkLU1NLXl5eXlcIlxyXG4gICAgICAgIC8vfSk7XHJcblxyXG5cclxuICAgICAgICAvL3RoaXMuYmluZFBob25lVHlwZUxpc3QodGhpcy5fcmVzb3VyY2VTZXJ2aWNlLkdldExvY2FsU3RvcmFnZShcIkNlbGxQaG9uZVR5cGVMaXN0XCIpKTtcclxuICAgICAgICAvL3RoaXMuc2V0U21zQ29tcGFueUxpc3QodGhpcy5fcmVzb3VyY2VTZXJ2aWNlLkdldExvY2FsU3RvcmFnZShcIlNtc0NvbXBhbnlMaXN0XCIpKTtcclxuICAgICAgICB0aGlzLl9hbWF4U2VydmljZS5HZXREYXRhRnJvbVNlcnZlcih7XHJcbiAgICAgICAgICAgIFNtc0NvbXBhbnlMaXN0OiB7XHJcbiAgICAgICAgICAgICAgICB1cWVyeTogYFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVzZXJzbXMgQVMgVXNlck5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXNzd29yZHNtcyBBUyBWYWx1ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmcm9tXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBBcHBsaWNhdGlvbkluZm9cclxuICAgICAgICAgICAgICAgICAgICBgLFxyXG4gICAgICAgICAgICAgICAgcGFyYW1ldGVyczoge31cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgUGhvbmVUeXBlTGlzdDoge1xyXG4gICAgICAgICAgICAgICAgdXFlcnk6IFwiU0VMRUNUIGlkIEFTIFZhbHVlLCBjb250ZW50SGViKycgKCcrIGNvbnRlbnRlbmcgKycpJyBBUyBMYWJlbCBGUk9NIFBob25lVHlwZXNcIixcclxuICAgICAgICAgICAgICAgIHBhcmFtZXRlcnM6IHt9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KS5zdWJzY3JpYmUoXHJcbiAgICAgICAgICAgIChkYXRhKSA9PiB7XHJcblxyXG4gICAgICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGRhdGEpO1xyXG4gICAgICAgICAgICAgICAgdmFyIHJlcyA9IGpRdWVyeS5wYXJzZUpTT04oZGF0YSk7XHJcblxyXG4gICAgICAgICAgICAgICAgdGhpcy5TbXNEYXRhID0gcmVzLkRhdGEuZGF0YS5TbXNDb21wYW55TGlzdDtcclxuICAgICAgICAgICAgICAgIHRoaXMuUGhvbmVUeXBlTGlzdERhdGEgPSByZXMuRGF0YS5kYXRhLlBob25lVHlwZUxpc3Q7XHJcbiAgICAgICAgICAgICAgICB2YXIgcGhvbmV0eXBlaWQgPSBcIlwiO1xyXG4gICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5QaG9uZVR5cGVMaXN0RGF0YSwgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHBob25ldHlwZWlkID0gdGhpcy5MYWJlbDtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIC8valF1ZXJ5KFwiI1Bob250VHlwZXNlbFwiKS5hdHRyKFwic2VsZWN0ZWR2YWxcIiwgcGhvbmV0eXBlaWQpO1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAoZXJyb3IpID0+IHsgfSxcclxuICAgICAgICAgICAgKCkgPT4geyB9XHJcbiAgICAgICAgICAgICk7XHJcblxyXG4gICAgfVxyXG4gICAgXHJcbiAgICAvL25nT25Jbml0KCkge1xyXG4gICAgLy8gICAgZGVidWdnZXI7XHJcbiAgICAvLyAgICBhbGVydCgnaGVsbG8nKTtcclxuICAgIC8vICAgIC8vbG9hZGluZ0xhbmd1YWdlIHN0YXJ0XHJcbiAgICAvLyAgICB0aGlzLl9hbWF4Q3JtU3lpbmMub24oJ2xzc2V0LicgKyBMb2NhbERpY3QubGFuZ3VhZ2VSZXNvdXJjZSwgZGF0YT0+IHRoaXMuUkVTID0gZGF0YVtcIlNDUkVFTl9TTVNcIl0pO1xyXG4gICAgLy8gICAgdGhpcy5SRVMgPSB0aGlzLl9hbWF4Q3JtU3lpbmMuZmV0Y2hMYW5ndWFnZVJlc291cmNlKFwiU0NSRUVOX1NNU1wiKTtcclxuICAgIC8vICAgIGlmICghdGhpcy5SRVMpIHtcclxuICAgIC8vICAgICAgICBpZiAoIWxvY2FsU3RvcmFnZS5nZXRJdGVtKExvY2FsRGljdC5zZWxlY3RlZExhbmd1YWdlKSkge1xyXG4gICAgLy8gICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShMb2NhbERpY3Quc2VsZWN0ZWRMYW5ndWFnZSwgY3JtQ29uZmlnLmZhbGJhY2tMYW5ndWFnZSk7XHJcbiAgICAvLyAgICAgICAgfVxyXG4gICAgLy8gICAgICAgIHRoaXMuX2FtYXhDcm1TeWluYy5sb2FkTGFuZ3VhZ2VSZXNvdXJjZShsb2NhbFN0b3JhZ2UuZ2V0SXRlbShMb2NhbERpY3Quc2VsZWN0ZWRMYW5ndWFnZSkpO1xyXG4gICAgLy8gICAgfVxyXG4gICAgLy8gICAgLy9sb2FkaW5nTGFuZ3VhZ2Ugc3RhcnRcclxuICAgIC8vICAgIHRoaXMuYWxsQmluZCgpO1xyXG4gICAgLy8gICAgYWxlcnQoJ0J5ZScpO1xyXG4gICAgLy99XHJcblxyXG5cclxuXHJcblxyXG5cclxuXHJcblxyXG5cclxuXHJcblxyXG59XHJcblxyXG5cclxuXHJcblxyXG4iXX0=
