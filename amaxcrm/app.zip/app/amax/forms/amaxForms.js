System.register(["angular2/core", 'angular2/common', "../../services/ResourceService", "angular2/router", "../../services/AmaxService", '../../jsonQ'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, common_1, ResourceService_1, router_1, AmaxService_1, jsonQ_1;
    var AmaxForms;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (ResourceService_1_1) {
                ResourceService_1 = ResourceService_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (AmaxService_1_1) {
                AmaxService_1 = AmaxService_1_1;
            },
            function (jsonQ_1_1) {
                jsonQ_1 = jsonQ_1_1;
            }],
        execute: function() {
            AmaxForms = (function () {
                function AmaxForms(_resourceService, _amaxService, _routeParams) {
                    this._resourceService = _resourceService;
                    this._amaxService = _amaxService;
                    this._routeParams = _routeParams;
                    this.ShowForm = false;
                }
                AmaxForms.prototype.saveFormData = function () {
                    var jsQ = new jsonQ_1.jsonQ("DemoTransation", "DemoHashKey");
                    for (var _i = 0, _a = this.FormObject; _i < _a.length; _i++) {
                        var frm = _a[_i];
                        jsQ.addNewInsert(frm.tableName, frm.pKey, frm.pKeyName);
                        for (var _b = 0, _c = frm.fields; _b < _c.length; _b++) {
                            var fld = _c[_b];
                            if (!fld.dummy) {
                                console.log(jQuery("form #" + frm.tableName + "_" + fld.name).val());
                                console.log("form #" + frm.tableName + "_" + fld.name);
                                jsQ.Insert(fld.name, jQuery("form #" + frm.tableName + "_" + fld.name).val());
                            }
                        }
                        jsQ.addToList();
                    }
                    console.log(JSON.stringify(jsQ.toJsonQObject()));
                    this._amaxService.ExecuteJson(jsQ.toJsonQObject()).subscribe(function (data) {
                        console.log(data);
                    }, function (error) { return console.log(error); }, function () { return console.log("Call Compleated"); });
                };
                AmaxForms.prototype.ngOnInit = function () {
                    var _this = this;
                    var frm = this._routeParams.get('frm');
                    console.log(frm);
                    this._resourceService.GetFormByName(this._routeParams.get('frm')).subscribe(function (data) {
                        _this.FormObject = data;
                        _this.ShowForm = true;
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleated");
                    });
                };
                AmaxForms = __decorate([
                    core_1.Component({
                        providers: [ResourceService_1.ResourceService, AmaxService_1.AmaxService],
                        directives: [common_1.NgSwitch, common_1.NgSwitchWhen, common_1.NgSwitchDefault],
                        template: "\n        <form *ngIf=\"ShowForm\">\n            <div class=\"row\">\n                <div class=\"col-sm-12\">\n                    <div *ngFor=\"#group of FormObject\" class=\"row\">\n                        <h1>{{group.name}}</h1>\n                        <div *ngFor=\"#field of group.fields\" class=\"col-xs-12 col-md-6 {{field.hiden ? 'hide' : ''}}\">\n                            <div class=\"row\" style=\"padding-top: 15px;\">\n                                <div class=\"col-xs-12 col-sm-5 col-md-4\"><label>{{field.caption||field.name}}</label></div>\n                                <div class=\"col-xs-12 col-sm-7 col-md-8\" [ngSwitch]=\"field.type\">\n                                    <template [ngSwitchWhen]=\"select\">\n                                        <select>\n                                            <option>Option 1</option>\n                                            <option>Option 2</option>\n                                            <option>Option 3</option>\n                                            <option>Option 4</option>\n                                            <option>Option 5</option>\n                                        </select>\n                                    </template>\n                                    <template ngSwitchDefault>\n                                        <input id=\"{{group.tableName}}_{{field.name}}\" class=\"form-control\" name=\"{{field.name}}\" value=\"{{field.default}}\" type=\"text\">\n                                    </template>\n                                </div>\n                            </div>\n                        </div>\n                    </div>\n                </div>\n                <div class=\"col-xs-12\">\n                    <button type=\"button\" (click)=\"saveFormData()\" class=\"btn btn-primary pull-right\" style=\"margin-top: 20px;\">Save</button>\n                </div>\n            </div>\n        </form>\n    "
                    }), 
                    __metadata('design:paramtypes', [ResourceService_1.ResourceService, AmaxService_1.AmaxService, router_1.RouteParams])
                ], AmaxForms);
                return AmaxForms;
            }());
            exports_1("AmaxForms", AmaxForms);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFtYXgvZm9ybXMvYW1heEZvcm1zLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1lBK0NBO2dCQUlJLG1CQUFvQixnQkFBZ0MsRUFBVSxZQUF3QixFQUFVLFlBQXdCO29CQUFwRyxxQkFBZ0IsR0FBaEIsZ0JBQWdCLENBQWdCO29CQUFVLGlCQUFZLEdBQVosWUFBWSxDQUFZO29CQUFVLGlCQUFZLEdBQVosWUFBWSxDQUFZO29CQUZ4SCxhQUFRLEdBQVMsS0FBSyxDQUFDO2dCQUd2QixDQUFDO2dCQUVELGdDQUFZLEdBQVo7b0JBQ0ksSUFBSSxHQUFHLEdBQUcsSUFBSSxhQUFLLENBQUMsZ0JBQWdCLEVBQUMsYUFBYSxDQUFDLENBQUM7b0JBRXBELEdBQUcsQ0FBQSxDQUFZLFVBQWUsRUFBZixLQUFBLElBQUksQ0FBQyxVQUFVLEVBQWYsY0FBZSxFQUFmLElBQWUsQ0FBQzt3QkFBM0IsSUFBSSxHQUFHLFNBQUE7d0JBQ1AsR0FBRyxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUN0RCxHQUFHLENBQUEsQ0FBWSxVQUFVLEVBQVYsS0FBQSxHQUFHLENBQUMsTUFBTSxFQUFWLGNBQVUsRUFBVixJQUFVLENBQUM7NEJBQXRCLElBQUksR0FBRyxTQUFBOzRCQUNQLEVBQUUsQ0FBQSxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFBLENBQUM7Z0NBQ1gsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsUUFBUSxHQUFDLEdBQUcsQ0FBQyxTQUFTLEdBQUUsR0FBRyxHQUFFLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO2dDQUNqRSxPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsR0FBQyxHQUFHLENBQUMsU0FBUyxHQUFFLEdBQUcsR0FBRSxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUM7Z0NBR25ELEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsUUFBUSxHQUFDLEdBQUcsQ0FBQyxTQUFTLEdBQUMsR0FBRyxHQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDOzRCQUM1RSxDQUFDO3lCQUNKO3dCQUNELEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztxQkFDbkI7b0JBQ0QsT0FBTyxDQUFDLEdBQUcsQ0FBRSxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUUsQ0FBQyxDQUFDLENBQUM7b0JBQ2xELElBQUksQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQzdELE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBQ2xCLENBQUMsRUFDRCxVQUFBLEtBQUssSUFBRSxPQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEVBQWxCLENBQWtCLEVBQ3pCLGNBQUksT0FBQSxPQUFPLENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDLEVBQTlCLENBQThCLENBQ3JDLENBQUM7Z0JBQ04sQ0FBQztnQkFFRCw0QkFBUSxHQUFSO29CQUFBLGlCQVlDO29CQVhHLElBQUksR0FBRyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QyxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUVqQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDNUUsS0FBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7d0JBQ3ZCLEtBQUksQ0FBQyxRQUFRLEdBQUMsSUFBSSxDQUFDO29CQUN2QixDQUFDLEVBQUMsVUFBQSxLQUFLO3dCQUNILE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBQzt3QkFDRSxPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDLENBQUE7b0JBQ2pDLENBQUMsQ0FBQyxDQUFDO2dCQUNQLENBQUM7Z0JBakZMO29CQUFDLGdCQUFTLENBQUM7d0JBQ1AsU0FBUyxFQUFFLENBQUMsaUNBQWUsRUFBQyx5QkFBVyxDQUFDO3dCQUN4QyxVQUFVLEVBQUMsQ0FBQyxpQkFBUSxFQUFFLHFCQUFZLEVBQUUsd0JBQWUsQ0FBQzt3QkFDcEQsUUFBUSxFQUFFLHc2REFnQ1Q7cUJBQ0osQ0FBQzs7NkJBQUE7Z0JBOENGLGdCQUFDO1lBQUQsQ0E3Q0EsQUE2Q0MsSUFBQTtZQTdDRCxpQ0E2Q0MsQ0FBQSIsImZpbGUiOiJhbWF4L2Zvcm1zL2FtYXhGb3Jtcy5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7Q29tcG9uZW50LCBPbkluaXR9IGZyb20gXCJhbmd1bGFyMi9jb3JlXCI7XHJcbmltcG9ydCB7TmdTd2l0Y2gsIE5nU3dpdGNoV2hlbiwgTmdTd2l0Y2hEZWZhdWx0fSBmcm9tICdhbmd1bGFyMi9jb21tb24nXHJcbmltcG9ydCB7UmVzb3VyY2VTZXJ2aWNlfSBmcm9tIFwiLi4vLi4vc2VydmljZXMvUmVzb3VyY2VTZXJ2aWNlXCI7XHJcbmltcG9ydCB7Um91dGVQYXJhbXN9IGZyb20gXCJhbmd1bGFyMi9yb3V0ZXJcIjtcclxuaW1wb3J0IHtBbWF4U2VydmljZX0gZnJvbSBcIi4uLy4uL3NlcnZpY2VzL0FtYXhTZXJ2aWNlXCI7XHJcbmltcG9ydCB7IGpzb25RIH0gZnJvbSAnLi4vLi4vanNvblEnO1xyXG5cclxuXHJcbmRlY2xhcmUgdmFyIGpRdWVyeTtcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgcHJvdmlkZXJzOiBbUmVzb3VyY2VTZXJ2aWNlLEFtYXhTZXJ2aWNlXSxcclxuICAgIGRpcmVjdGl2ZXM6W05nU3dpdGNoLCBOZ1N3aXRjaFdoZW4sIE5nU3dpdGNoRGVmYXVsdF0sXHJcbiAgICB0ZW1wbGF0ZTogYFxyXG4gICAgICAgIDxmb3JtICpuZ0lmPVwiU2hvd0Zvcm1cIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInJvd1wiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbC1zbS0xMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgKm5nRm9yPVwiI2dyb3VwIG9mIEZvcm1PYmplY3RcIiBjbGFzcz1cInJvd1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aDE+e3tncm91cC5uYW1lfX08L2gxPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2ICpuZ0Zvcj1cIiNmaWVsZCBvZiBncm91cC5maWVsZHNcIiBjbGFzcz1cImNvbC14cy0xMiBjb2wtbWQtNiB7e2ZpZWxkLmhpZGVuID8gJ2hpZGUnIDogJyd9fVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInJvd1wiIHN0eWxlPVwicGFkZGluZy10b3A6IDE1cHg7XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbC14cy0xMiBjb2wtc20tNSBjb2wtbWQtNFwiPjxsYWJlbD57e2ZpZWxkLmNhcHRpb258fGZpZWxkLm5hbWV9fTwvbGFiZWw+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbC14cy0xMiBjb2wtc20tNyBjb2wtbWQtOFwiIFtuZ1N3aXRjaF09XCJmaWVsZC50eXBlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZW1wbGF0ZSBbbmdTd2l0Y2hXaGVuXT1cInNlbGVjdFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uPk9wdGlvbiAxPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbj5PcHRpb24gMjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24+T3B0aW9uIDM8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uPk9wdGlvbiA0PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbj5PcHRpb24gNTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGVtcGxhdGU+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZW1wbGF0ZSBuZ1N3aXRjaERlZmF1bHQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgaWQ9XCJ7e2dyb3VwLnRhYmxlTmFtZX19X3t7ZmllbGQubmFtZX19XCIgY2xhc3M9XCJmb3JtLWNvbnRyb2xcIiBuYW1lPVwie3tmaWVsZC5uYW1lfX1cIiB2YWx1ZT1cInt7ZmllbGQuZGVmYXVsdH19XCIgdHlwZT1cInRleHRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZW1wbGF0ZT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbC14cy0xMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIChjbGljayk9XCJzYXZlRm9ybURhdGEoKVwiIGNsYXNzPVwiYnRuIGJ0bi1wcmltYXJ5IHB1bGwtcmlnaHRcIiBzdHlsZT1cIm1hcmdpbi10b3A6IDIwcHg7XCI+U2F2ZTwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZm9ybT5cclxuICAgIGBcclxufSlcclxuZXhwb3J0IGNsYXNzIEFtYXhGb3JtcyBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcbiAgICBGb3JtT2JqZWN0OkFycmF5PGFueT47XHJcbiAgICBTaG93Rm9ybTpib29sZWFuPWZhbHNlO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgX3Jlc291cmNlU2VydmljZTpSZXNvdXJjZVNlcnZpY2UsIHByaXZhdGUgX2FtYXhTZXJ2aWNlOkFtYXhTZXJ2aWNlLCBwcml2YXRlIF9yb3V0ZVBhcmFtczpSb3V0ZVBhcmFtcykge1xyXG4gICAgfVxyXG5cclxuICAgIHNhdmVGb3JtRGF0YSgpe1xyXG4gICAgICAgIHZhciBqc1EgPSBuZXcganNvblEoXCJEZW1vVHJhbnNhdGlvblwiLFwiRGVtb0hhc2hLZXlcIik7XHJcblxyXG4gICAgICAgIGZvcih2YXIgZnJtIG9mIHRoaXMuRm9ybU9iamVjdCl7XHJcbiAgICAgICAgICAgIGpzUS5hZGROZXdJbnNlcnQoZnJtLnRhYmxlTmFtZSxmcm0ucEtleSxmcm0ucEtleU5hbWUpO1xyXG4gICAgICAgICAgICBmb3IodmFyIGZsZCBvZiBmcm0uZmllbGRzKXtcclxuICAgICAgICAgICAgICAgIGlmKCFmbGQuZHVtbXkpe1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGpRdWVyeShcImZvcm0gI1wiK2ZybS50YWJsZU5hbWUrIFwiX1wiICtmbGQubmFtZSkudmFsKCkpO1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZm9ybSAjXCIrZnJtLnRhYmxlTmFtZSsgXCJfXCIgK2ZsZC5uYW1lKTtcclxuXHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGpzUS5JbnNlcnQoZmxkLm5hbWUsIGpRdWVyeShcImZvcm0gI1wiK2ZybS50YWJsZU5hbWUrXCJfXCIrZmxkLm5hbWUpLnZhbCgpKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBqc1EuYWRkVG9MaXN0KCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbnNvbGUubG9nKCBKU09OLnN0cmluZ2lmeShqc1EudG9Kc29uUU9iamVjdCgpKSk7XHJcbiAgICAgICAgdGhpcy5fYW1heFNlcnZpY2UuRXhlY3V0ZUpzb24oanNRLnRvSnNvblFPYmplY3QoKSkuc3Vic2NyaWJlKGRhdGE9PntcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZGF0YSk7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGVycm9yPT5jb25zb2xlLmxvZyhlcnJvciksXHJcbiAgICAgICAgICAgICgpPT5jb25zb2xlLmxvZyhcIkNhbGwgQ29tcGxlYXRlZFwiKVxyXG4gICAgICAgICk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkluaXQoKSB7XHJcbiAgICAgICAgdmFyIGZybSA9IHRoaXMuX3JvdXRlUGFyYW1zLmdldCgnZnJtJyk7XHJcbiAgICAgICAgY29uc29sZS5sb2coZnJtKTtcclxuICAgICAgICBcclxuICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuR2V0Rm9ybUJ5TmFtZSh0aGlzLl9yb3V0ZVBhcmFtcy5nZXQoJ2ZybScpKS5zdWJzY3JpYmUoZGF0YT0+e1xyXG4gICAgICAgICAgICB0aGlzLkZvcm1PYmplY3QgPSBkYXRhO1xyXG4gICAgICAgICAgICB0aGlzLlNob3dGb3JtPXRydWU7XHJcbiAgICAgICAgfSxlcnJvcj0+e1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwoKT0+e1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGVhdGVkXCIpXHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcbn0iXX0=
