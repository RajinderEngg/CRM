System.register(['angular2/common', "../../services/ResourceService", "angular2/router", "angular2/core", "../../services/CustomerService", "../../services/ChargeCreditService", '../../autocomplete/autocomplete-container', '../../autocomplete/autocomplete.component'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var common_1, ResourceService_1, router_1, core_1, CustomerService_1, ChargeCreditService_1, autocomplete_container_1, autocomplete_component_1;
    var AUTOCOMPLETE_DIRECTIVES, AmaxChargeCredit;
    return {
        setters:[
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (ResourceService_1_1) {
                ResourceService_1 = ResourceService_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (CustomerService_1_1) {
                CustomerService_1 = CustomerService_1_1;
            },
            function (ChargeCreditService_1_1) {
                ChargeCreditService_1 = ChargeCreditService_1_1;
            },
            function (autocomplete_container_1_1) {
                autocomplete_container_1 = autocomplete_container_1_1;
            },
            function (autocomplete_component_1_1) {
                autocomplete_component_1 = autocomplete_component_1_1;
            }],
        execute: function() {
            exports_1("AUTOCOMPLETE_DIRECTIVES", AUTOCOMPLETE_DIRECTIVES = [autocomplete_component_1.Autocomplete, autocomplete_container_1.AutocompleteContainer]);
            AmaxChargeCredit = (function () {
                function AmaxChargeCredit(_resourceService, _customerService, _routeParams, _ChargeCreditService) {
                    this._resourceService = _resourceService;
                    this._customerService = _customerService;
                    this._routeParams = _routeParams;
                    this._ChargeCreditService = _ChargeCreditService;
                    this.modelInput = {};
                    this.modelInputTemp = {};
                    this.RES = {};
                    this.Formtype = "CHARGECREDIT_SCREEN";
                    this.Lang = "";
                    this.CustomerId = -1;
                    this.BaseAppUrl = "";
                    this._TerminalList = [];
                    this.TerminalNumber = "";
                    this.RemPaymentsText = "";
                    this.NumOfPaymentsText = "";
                    this.Isbtndisable = "";
                    this.MsgClass = "";
                    this.ChangeDialog = "";
                    this.CHANGEDIR = "";
                    this.IsCreditCancel = false;
                    this.IsCreditNoOfPay = false;
                    this.Installments = 0;
                    this.InstallmentPay = 0;
                    this.isfindcreditCardOwnerID = true;
                    this.PrintUrl = "https://secure.cardcom.co.il/Note/ProgramNote.aspx"; /*?DealNumber=" + oDealNumber + "&DisplayData=3&Termianl=" + oTermianl + "&DefPrint=false";*/
                    this._Mnths = [];
                    this._Years = [];
                    this._ChargeTypes = [];
                    this._Currency = [];
                    this._CreditTypes = [];
                    this.RES.CHARGECREDIT_SCREEN = {};
                    this.BaseAppUrl = _resourceService.AppUrl;
                    this.modelInput.CustomerId = _routeParams.params.Id;
                    this.modelInput.oTerminalNumber = _routeParams.params.TermNo;
                    this.modelInput.oCurrency = "Nis";
                    this.modelInput.ChargeType = "0";
                    // this.OpenDiv();
                    this.modelInput.CreditType = "0";
                    //this.modelInputTemp.DealNumber = "test";
                    //this.modelInputTemp.oTerminalNumber = "test";
                    //    modelInput.oCurrency        
                }
                AmaxChargeCredit.prototype.ChangeOwnerId = function () {
                    this.isfindcreditCardOwnerID = false;
                };
                AmaxChargeCredit.prototype.CalculateConstPay = function () {
                    if (this.modelInput.oSumToBill != undefined && this.modelInput.oSumToBill != null && this.modelInput.oSumToBill != ""
                        && this.modelInput.ofirstpaymentsum != undefined && this.modelInput.ofirstpaymentsum != null && this.modelInput.ofirstpaymentsum != ""
                        && this.modelInput.oNumOfPayments != undefined && this.modelInput.oNumOfPayments != null && this.modelInput.oNumOfPayments != "") {
                        var RemAmt = parseFloat(this.modelInput.oSumToBill) - parseFloat(this.modelInput.ofirstpaymentsum);
                        if (RemAmt >= 0) {
                            if (parseInt(this.modelInput.oNumOfPayments) == 1) {
                                if (RemAmt > 0) {
                                    bootbox.alert({
                                        message: "Please give full amount in first payment or increase th no of payments",
                                        className: this.ChangeDialog,
                                        buttons: {
                                            ok: {
                                                //label: 'Ok',
                                                className: this.CHANGEDIR
                                            }
                                        }
                                    });
                                }
                                else {
                                    this.NumOfPaymentsText = this.modelInput.oNumOfPayments + " payments, first payment: " + this.modelInput.ofirstpaymentsum;
                                    this.RemPaymentsText = this.modelInput.ofirstpaymentsum + " and 0 payments of 0";
                                }
                            }
                            else if (parseInt(this.modelInput.oNumOfPayments) > 1) {
                                //debugger;
                                this.InstallmentPay = parseFloat(RemAmt / parseFloat(this.modelInput.oNumOfPayments - 1));
                                this.modelInput.oconstpatment = this.InstallmentPay;
                                this.NumOfPaymentsText = this.modelInput.oNumOfPayments + " payments, first payment: " + this.modelInput.ofirstpaymentsum;
                                this.RemPaymentsText = this.modelInput.ofirstpaymentsum + " and " + parseFloat(this.modelInput.oNumOfPayments - 1) + " payments of " +
                                    this.InstallmentPay.toFixed(2);
                                this.modelInput.oNumOfPayments = parseFloat(this.modelInput.oNumOfPayments) + 1;
                            }
                        }
                    }
                };
                AmaxChargeCredit.prototype.ChangeCreditType = function (obj) {
                    this.modelInput.CreditType = obj.Value;
                    if (obj.Value != 0) {
                        this.IsCreditNoOfPay = true;
                    }
                    else {
                        this.IsCreditNoOfPay = false;
                    }
                    this.modelInput.ofirstpaymentsum = "";
                    this.modelInput.oNumOfPayments = "";
                    this.NumOfPaymentsText = "";
                    this.RemPaymentsText;
                };
                AmaxChargeCredit.prototype.OpenDiv = function () {
                    var savetext = "";
                    this.modelInput.ChargeType = jQuery("#Chargetype").val();
                    //debugger;
                    var chrgtype = this.modelInput.ChargeType;
                    jQuery.each(this._ChargeTypes, function () {
                        if (this.Value == chrgtype) {
                            savetext = this.Text;
                            return false;
                        }
                    });
                    this.SAVE_BTN_TEXT = savetext;
                    if (this.modelInput.ChargeType != "0") {
                        this.IsCreditCancel = true;
                    }
                    else if (this.modelInput.ChargeType == "0") {
                        this.IsCreditCancel = false;
                    }
                    this.modelInput.ouserpassword = "";
                };
                AmaxChargeCredit.prototype.CheckCreditCardDet = function () {
                    var _this = this;
                    if (jQuery("input:checked").val() != undefined && jQuery("input:checked").val() != null) {
                        if (this.modelInput.UseToken != undefined && this.modelInput.UseToken != null) { }
                        else {
                            this.modelInput.UseToken = false;
                        }
                        this.modelInput.CompanySlika = "1";
                        if (this.modelInput.CreditType == "0") {
                            this.modelInput.oNumOfPayments = "1";
                        }
                        else {
                            if (this.modelInput.oNumOfPayments != undefined && this.modelInput.oNumOfPayments != null) {
                                if (this.modelInput.oNumOfPayments != "") {
                                    this.modelInput.oNumOfPayments = parseInt(this.modelInput.oNumOfPayments + 1);
                                }
                                else {
                                    this.modelInput.oNumOfPayments = "1";
                                }
                            }
                        }
                        if (this.modelInput.ChargeType == "0") {
                            this.modelInput.odealtype = "1";
                        }
                        else if (this.modelInput.ChargeType == "1") {
                            this.modelInput.odealtype = "51";
                        }
                        else if (this.modelInput.ChargeType == "2") {
                            this.modelInput.odealtype = "52";
                        }
                        if (this.modelInput.odealtype == "1") {
                            //swal({
                            //    title: "Are you sure?",
                            //    text: "Note that you requested charge the customer, will continue!",
                            //    type: "warning",
                            //    showCancelButton: true,
                            //    confirmButtonColor: "#DD6B55",
                            //    confirmButtonText: "Yes",
                            //    cancelButtonText: "No",
                            //    closeOnConfirm: false,
                            //    closeOnCancel: false
                            //},
                            //    function (isConfirm) {
                            //        if (isConfirm) {
                            //        }
                            //        else {
                            //            return false;
                            //        }
                            //    });
                            //bootbox.confirm({
                            //    message: "Note that you requested charge the customer, will continue?",
                            //    buttons: {
                            //        confirm: {
                            //            label: 'Yes',
                            //            className: 'btn-success'
                            //        },
                            //        cancel: {
                            //            label: 'No',
                            //            className: 'btn-danger'
                            //        }
                            //    },
                            //    callback: function (result) {
                            //        if (result == false) {
                            //            return false;
                            //        }
                            //        //console.log('This was logged in the callback: ' + result);
                            //    }
                            //});
                            if (confirm("Note that you requested charge the customer, will continue?") == true) { }
                            else {
                                return false;
                            }
                        }
                        var IsInsert = "";
                        this._ChargeCreditService.IsInsertTotblLastUpdate(this.modelInput.CustomerId).subscribe(function (resp) {
                            var response = jQuery.parseJSON(resp);
                            if (response.IsError == true) {
                                bootbox.alert({
                                    message: response.ErrMsg,
                                    className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                            else {
                                IsInsert = response.Data;
                                if (IsInsert.length > 0) {
                                    //swal({
                                    //    title: "Are you sure?",
                                    //    text: IsInsert,
                                    //    type: "warning",
                                    //    showCancelButton: true,
                                    //    confirmButtonColor: "#DD6B55",
                                    //    confirmButtonText: "Yes",
                                    //    cancelButtonText: "No",
                                    //    closeOnConfirm: false,
                                    //    closeOnCancel: false
                                    //},
                                    //    function (isConfirm) {
                                    //        if (isConfirm) {
                                    //            this._ChargeCreditService.InsertTotblLastUpdate(this.modelInput.CustomerId, this.modelInput.oSumToBill).subscribe(resp=> {
                                    //                var response1 = jQuery.parseJSON(resp);
                                    //                if (response1.IsError == true) {
                                    //                    swal(response1.ErrMsg);
                                    //                }
                                    //                else {
                                    //                }
                                    //            }, error=> {
                                    //                console.log(error);
                                    //            }, () => {
                                    //                console.log("CallCompleted")
                                    //            });
                                    //        }
                                    //        else {
                                    //            return false;
                                    //        }
                                    //    });
                                    if (confirm(IsInsert) == true) {
                                        _this._ChargeCreditService.InsertTotblLastUpdate(_this.modelInput.CustomerId, _this.modelInput.oSumToBill).subscribe(function (resp) {
                                            var response1 = jQuery.parseJSON(resp);
                                            if (response1.IsError == true) {
                                                bootbox.alert({
                                                    message: response1.ErrMsg,
                                                    className: _this.ChangeDialog,
                                                    buttons: {
                                                        ok: {
                                                            //label: 'Ok',
                                                            className: _this.CHANGEDIR
                                                        }
                                                    }
                                                });
                                            }
                                            else {
                                            }
                                        }, function (error) {
                                            console.log(error);
                                        }, function () {
                                            console.log("CallCompleted");
                                        });
                                    }
                                    else {
                                        return false;
                                    }
                                }
                            }
                        }, function (error) {
                            console.log(error);
                        }, function () {
                            console.log("CallCompleted");
                        });
                        if (this.isfindcreditCardOwnerID == false) {
                            //swal({
                            //    title: "Are you sure?",
                            //    text: "You want to update a customer ID card!",
                            //    type: "warning",
                            //    showCancelButton: true,
                            //    confirmButtonColor: "#DD6B55",
                            //    confirmButtonText: "Yes",
                            //    cancelButtonText: "No",
                            //    closeOnConfirm: false,
                            //    closeOnCancel: false
                            //},
                            //    function (isConfirm) {
                            //        if (isConfirm) {
                            //            this._ChargeCreditService.UpdateOwnerId(this.modelInput.CustomerId, this.modelInput.oCardOwnerId).subscribe(resp=> {
                            //                var response = jQuery.parseJSON(resp);
                            //                if (response.IsError == true) {
                            //                    swal(response.ErrMsg);
                            //                }
                            //                else {
                            //                }
                            //            }, error=> {
                            //                console.log(error);
                            //            }, () => {
                            //                console.log("CallCompleted")
                            //            });
                            //        }
                            //        else {
                            //            return false;
                            //        }
                            //    });
                            if (confirm("You want to update a customer ID card?") == true) {
                                this._ChargeCreditService.UpdateOwnerId(this.modelInput.CustomerId, this.modelInput.oCardOwnerId).subscribe(function (resp) {
                                    var response = jQuery.parseJSON(resp);
                                    if (response.IsError == true) {
                                        bootbox.alert({
                                            message: response.ErrMsg,
                                            className: _this.ChangeDialog,
                                            buttons: {
                                                ok: {
                                                    //label: 'Ok',
                                                    className: _this.CHANGEDIR
                                                }
                                            }
                                        });
                                    }
                                    else {
                                    }
                                }, function (error) {
                                    console.log(error);
                                }, function () {
                                    console.log("CallCompleted");
                                });
                            }
                            else {
                                return false;
                            }
                        }
                        var jdata = JSON.stringify(this.modelInput);
                        this._ChargeCreditService.Save(jdata).subscribe(function (resp) {
                            var response = jQuery.parseJSON(resp);
                            if (response.IsError == true) {
                                bootbox.alert({
                                    message: response.ErrMsg,
                                    className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                            else {
                                bootbox.alert({
                                    message: response.ErrMsg,
                                    className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        }
                                    }
                                });
                                // document.location = this.BaseAppUrl + "ChargeCredit/" + this.modelInput.CustomerId + "/" + this.modelInput.oTerminalNumber;
                                _this.modelInput.DealNumber = response.Data.DealNumber;
                                _this.modelInputTemp = _this.modelInput;
                                _this.modelInput = {};
                                _this.modelInput.oTerminalNumber = _this._routeParams.params.TermNo;
                                _this.modelInput.CustomerId = _this._routeParams.params.Id;
                                _this.modelInput.oCurrency = "Nis";
                                _this.modelInput.ChargeType = "0";
                                _this._ChargeTypes = [];
                                _this._ChargeCreditService.BindChargeTypeList().subscribe(function (resp) {
                                    //debugger;
                                    var response = jQuery.parseJSON(resp);
                                    if (response.IsError == true) {
                                        bootbox.alert({
                                            message: response.ErrMsg,
                                            className: _this.ChangeDialog,
                                            buttons: {
                                                ok: {
                                                    //label: 'Ok',
                                                    className: _this.CHANGEDIR
                                                }
                                            }
                                        });
                                    }
                                    else {
                                        _this._ChargeTypes = response.Data;
                                        var savetext = "";
                                        var chrgtype = _this.modelInput.ChargeType;
                                        jQuery.each(_this._ChargeTypes, function () {
                                            if (this.Value == chrgtype) {
                                                savetext = this.Text;
                                                return false;
                                            }
                                        });
                                        _this.SAVE_BTN_TEXT = savetext;
                                    }
                                }, function (error) {
                                    console.log(error);
                                }, function () {
                                    console.log("CallCompleted");
                                });
                                _this.modelInput.CreditType = "0";
                                _this._ChargeCreditService.BindTermDet(_this.modelInput.oTerminalNumber).subscribe(function (resp) {
                                    //debugger;
                                    var response = jQuery.parseJSON(resp);
                                    if (response.IsError == true) {
                                        bootbox.alert({
                                            message: response.ErrMsg,
                                            className: _this.ChangeDialog,
                                            buttons: {
                                                ok: {
                                                    //label: 'Ok',
                                                    className: _this.CHANGEDIR
                                                }
                                            }
                                        });
                                    }
                                    else {
                                        _this.modelInput.ousername = response.Data.instituteName;
                                    }
                                }, function (error) {
                                    console.log(error);
                                }, function () {
                                    console.log("CallCompleted");
                                });
                                _this._customerService.GetCompleteCustDet(_this.modelInput.CustomerId).subscribe(function (resp) {
                                    //debugger;
                                    var response = jQuery.parseJSON(resp);
                                    if (response.IsError == true) {
                                        bootbox.alert({
                                            message: response.ErrMsg,
                                            className: _this.ChangeDialog,
                                            buttons: {
                                                ok: {
                                                    //label: 'Ok',
                                                    className: _this.CHANGEDIR
                                                }
                                            }
                                        });
                                    }
                                    else {
                                        _this.modelInput.CustomerName = response.Data.fname + " " + response.Data.lname;
                                        _this.modelInput.oCardOwnerId = response.Data.CustomerCode;
                                    }
                                }, function (error) {
                                    console.log(error);
                                }, function () {
                                    console.log("CallCompleted");
                                });
                                //debugger;
                                //var PrintUrl = this.PrintUrl + "?DealNumber=" + response.Data.DealNumber +
                                //    "&DisplayData=3&Termianl=" + this.modelInput.oTerminalNumber +
                                //    "&DefPrint=false";
                                _this.PrintData(response.Data.DealNumber, _this.modelInput.oTerminalNumber);
                            }
                        }, function (error) {
                            console.log(error);
                        }, function () {
                            console.log("CallCompleted");
                        });
                    }
                    else {
                        bootbox.alert({
                            message: 'Please select credit type',
                            className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                    }
                };
                AmaxChargeCredit.prototype.ClearCardNo = function () {
                    this.modelInput.oCardNumber = "";
                };
                AmaxChargeCredit.prototype.PrintPrevData = function () {
                    //debugger;
                    if (this.modelInputTemp.DealNumber != undefined && this.modelInputTemp.DealNumber != null
                        && this.modelInputTemp.oTerminalNumber != undefined && this.modelInputTemp.oTerminalNumber != null) {
                        this.PrintData(this.modelInputTemp.DealNumber, this.modelInputTemp.oTerminalNumber);
                    }
                    else {
                        bootbox.alert({
                            message: "Please do any transection and then click on print button",
                            className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                    }
                };
                AmaxChargeCredit.prototype.CancelBtn = function () {
                    document.location = this.BaseAppUrl + "Customer/Add/" + this._routeParams.params.Id;
                };
                AmaxChargeCredit.prototype.PrintData = function (DealNumber, Terminal) {
                    var _this = this;
                    var PrintData = "";
                    this._ChargeCreditService.getPrint(DealNumber, Terminal).subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            PrintData = response.Data;
                            //var OpenWindow = window.open("");
                            var windowObject = window.open('', 'Print', 'scrollbars=yes,resizable=yes,width=1050,height=650');
                            windowObject.document.write(PrintData);
                            windowObject.document.close();
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxChargeCredit.prototype.OpenNewReceipt = function () {
                    if (this.modelInput != undefined) {
                        var emid = localStorage.getItem("employeeid");
                        document.location = this.BaseAppUrl + "ReceiptSelect/" + emid;
                    }
                };
                AmaxChargeCredit.prototype.ngOnInit = function () {
                    var _this = this;
                    if (localStorage.getItem("lang") == "") {
                        localStorage.setItem("lang", "en");
                    }
                    this.Lang = localStorage.getItem("lang");
                    this._resourceService.GetLangRes(this.Formtype, this.Lang).subscribe(function (response) {
                        //debugger;
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.RES = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._ChargeCreditService.BindTermDet(this.modelInput.oTerminalNumber).subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.modelInput.ousername = response.Data.instituteName;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._customerService.GetCompleteCustDet(this.modelInput.CustomerId).subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.modelInput.CustomerName = response.Data.fname + " " + response.Data.lname;
                            _this.modelInput.oCardOwnerId = response.Data.CustomerCode;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._ChargeCreditService.BindCurrencyList().subscribe(function (resp) {
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Currency = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._ChargeCreditService.BindCreditTypeList().subscribe(function (resp) {
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            //debugger;
                            _this._CreditTypes = response.Data;
                            var rbid = "#" + _this.modelInput.CreditType.toString();
                            jQuery(rbid).prop("checked", true);
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._ChargeCreditService.BindChargeTypeList().subscribe(function (resp) {
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._ChargeTypes = response.Data;
                            var savetext = "";
                            var chrgtype = _this.modelInput.ChargeType;
                            jQuery.each(_this._ChargeTypes, function () {
                                if (this.Value == chrgtype) {
                                    savetext = this.Text;
                                    return false;
                                }
                            });
                            _this.SAVE_BTN_TEXT = savetext;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._ChargeCreditService.BindYears().subscribe(function (resp) {
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Years = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._ChargeCreditService.BindMonths().subscribe(function (resp) {
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Mnths = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    window.setTimeout(function () { $("[name='CreditType']:first").attr("checked", true); }, 1000);
                };
                AmaxChargeCredit.$inject = ['$scope', '$location', '$anchorScroll'];
                AmaxChargeCredit = __decorate([
                    core_1.Component({
                        templateUrl: './app/amax/Charge_Credit/templates/ChargeCredit.html',
                        directives: [common_1.NgSwitch, common_1.NgSwitchWhen, common_1.NgSwitchDefault, AUTOCOMPLETE_DIRECTIVES, common_1.CORE_DIRECTIVES, common_1.FORM_DIRECTIVES],
                        providers: [CustomerService_1.CustomerService, ResourceService_1.ResourceService, ChargeCreditService_1.ChargeCreditService]
                    }), 
                    __metadata('design:paramtypes', [ResourceService_1.ResourceService, CustomerService_1.CustomerService, router_1.RouteParams, ChargeCreditService_1.ChargeCreditService])
                ], AmaxChargeCredit);
                return AmaxChargeCredit;
            }());
            exports_1("AmaxChargeCredit", AmaxChargeCredit);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFtYXgvQ2hhcmdlX0NyZWRpdC9DaGFyZ2VDcmVkaXRDYXJkLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7UUFXYSx1QkFBdUI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7WUFBdkIscUNBQUEsdUJBQXVCLEdBQUcsQ0FBQyxxQ0FBWSxFQUFFLDhDQUFxQixDQUFDLENBQUEsQ0FBQztZQVM3RTtnQkErQkksMEJBQW9CLGdCQUFpQyxFQUFVLGdCQUFpQyxFQUFVLFlBQXlCLEVBQVUsb0JBQXlDO29CQUFsSyxxQkFBZ0IsR0FBaEIsZ0JBQWdCLENBQWlCO29CQUFVLHFCQUFnQixHQUFoQixnQkFBZ0IsQ0FBaUI7b0JBQVUsaUJBQVksR0FBWixZQUFZLENBQWE7b0JBQVUseUJBQW9CLEdBQXBCLG9CQUFvQixDQUFxQjtvQkE5QnRMLGVBQVUsR0FBRyxFQUFFLENBQUM7b0JBQ2hCLG1CQUFjLEdBQUcsRUFBRSxDQUFDO29CQUNwQixRQUFHLEdBQVcsRUFBRSxDQUFDO29CQUNqQixhQUFRLEdBQVUscUJBQXFCLENBQUM7b0JBQ3hDLFNBQUksR0FBVyxFQUFFLENBQUM7b0JBQ2xCLGVBQVUsR0FBVyxDQUFDLENBQUMsQ0FBQztvQkFFeEIsZUFBVSxHQUFXLEVBQUUsQ0FBQztvQkFDeEIsa0JBQWEsR0FBRyxFQUFFLENBQUM7b0JBQ25CLG1CQUFjLEdBQVcsRUFBRSxDQUFDO29CQUM1QixvQkFBZSxHQUFXLEVBQUUsQ0FBQztvQkFDN0Isc0JBQWlCLEdBQVcsRUFBRSxDQUFDO29CQUMvQixpQkFBWSxHQUFXLEVBQUUsQ0FBQztvQkFDMUIsYUFBUSxHQUFXLEVBQUUsQ0FBQztvQkFDdEIsaUJBQVksR0FBVyxFQUFFLENBQUM7b0JBQzFCLGNBQVMsR0FBVyxFQUFFLENBQUM7b0JBR3ZCLG1CQUFjLEdBQVksS0FBSyxDQUFDO29CQUNoQyxvQkFBZSxHQUFZLEtBQUssQ0FBQztvQkFDakMsaUJBQVksR0FBSyxDQUFDLENBQUM7b0JBQ25CLG1CQUFjLEdBQVEsQ0FBQyxDQUFDO29CQUN4Qiw0QkFBdUIsR0FBWSxJQUFJLENBQUM7b0JBQ3hDLGFBQVEsR0FBVyxvREFBb0QsQ0FBQyxDQUFBLDZGQUE2RjtvQkFDckssV0FBTSxHQUFHLEVBQUUsQ0FBQztvQkFDWixXQUFNLEdBQUcsRUFBRSxDQUFDO29CQUNaLGlCQUFZLEdBQUcsRUFBRSxDQUFDO29CQUNsQixjQUFTLEdBQUcsRUFBRSxDQUFDO29CQUNmLGlCQUFZLEdBQUcsRUFBRSxDQUFDO29CQUlkLElBQUksQ0FBQyxHQUFHLENBQUMsbUJBQW1CLEdBQUcsRUFBRSxDQUFDO29CQUNsQyxJQUFJLENBQUMsVUFBVSxHQUFHLGdCQUFnQixDQUFDLE1BQU0sQ0FBQztvQkFDMUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsWUFBWSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7b0JBQ3BELElBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxHQUFHLFlBQVksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO29CQUU3RCxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUM7b0JBQ2xDLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLEdBQUcsQ0FBQztvQkFDbEMsa0JBQWtCO29CQUNqQixJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBRyxHQUFHLENBQUM7b0JBQ2pDLDBDQUEwQztvQkFDMUMsK0NBQStDO29CQUNuRCxrQ0FBa0M7Z0JBQ2xDLENBQUM7Z0JBQ0Qsd0NBQWEsR0FBYjtvQkFDSSxJQUFJLENBQUMsdUJBQXVCLEdBQUcsS0FBSyxDQUFDO2dCQUN6QyxDQUFDO2dCQUNELDRDQUFpQixHQUFqQjtvQkFDSSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLEVBQUU7MkJBQzlHLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLElBQUksRUFBRTsyQkFDbkksSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO3dCQUNuSSxJQUFJLE1BQU0sR0FBRyxVQUFVLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsR0FBRyxVQUFVLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO3dCQUNuRyxFQUFFLENBQUMsQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQzs0QkFDZCxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUNoRCxFQUFFLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQ0FDYixPQUFPLENBQUMsS0FBSyxDQUFDO3dDQUNWLE9BQU8sRUFBRSx3RUFBd0U7d0NBQ2pGLFNBQVMsRUFBRSxJQUFJLENBQUMsWUFBWTt3Q0FDNUIsT0FBTyxFQUFFOzRDQUNMLEVBQUUsRUFBRTtnREFDQSxjQUFjO2dEQUNkLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUzs2Q0FDNUI7eUNBQ0o7cUNBQ0osQ0FBQyxDQUFDO2dDQUNQLENBQUM7Z0NBQ0QsSUFBSSxDQUFDLENBQUM7b0NBQ0YsSUFBSSxDQUFDLGlCQUFpQixHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLDRCQUE0QixHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLENBQUM7b0NBQzFILElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsR0FBQyxzQkFBc0IsQ0FBQztnQ0FDbkYsQ0FBQzs0QkFDTCxDQUFDOzRCQUNELElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUNwRCxXQUFXO2dDQUNYLElBQUksQ0FBQyxjQUFjLEdBQUcsVUFBVSxDQUFDLE1BQU0sR0FBRyxVQUFVLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDMUYsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQztnQ0FFcEQsSUFBSSxDQUFDLGlCQUFpQixHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLDRCQUE0QixHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLENBQUM7Z0NBQzFILElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsR0FBRyxPQUFPLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLENBQUMsQ0FBQyxHQUFHLGVBQWU7b0NBQ2hJLElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUNuQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxVQUFVLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLENBQUM7NEJBRXBGLENBQUM7d0JBQ0wsQ0FBQztvQkFDTCxDQUFDO2dCQUNMLENBQUM7Z0JBQ0QsMkNBQWdCLEdBQWhCLFVBQWlCLEdBQUc7b0JBRWhCLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUM7b0JBQ3ZDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDakIsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUM7b0JBQ2hDLENBQUM7b0JBQ0QsSUFBSSxDQUFDLENBQUM7d0JBQ0YsSUFBSSxDQUFDLGVBQWUsR0FBRyxLQUFLLENBQUM7b0JBRWpDLENBQUM7b0JBQ0QsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsR0FBRyxFQUFFLENBQUM7b0JBQ3RDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLEVBQUUsQ0FBQztvQkFDcEMsSUFBSSxDQUFDLGlCQUFpQixHQUFHLEVBQUUsQ0FBQztvQkFDNUIsSUFBSSxDQUFDLGVBQWUsQ0FBQztnQkFDekIsQ0FBQztnQkFDRCxrQ0FBTyxHQUFQO29CQUNJLElBQUksUUFBUSxHQUFHLEVBQUUsQ0FBQztvQkFDbEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDO29CQUN6RCxXQUFXO29CQUNYLElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDO29CQUMxQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUU7d0JBRTNCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLElBQUksUUFBUSxDQUFDLENBQUMsQ0FBQzs0QkFFekIsUUFBUSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUM7NEJBQ3JCLE1BQU0sQ0FBQyxLQUFLLENBQUM7d0JBQ2pCLENBQUM7b0JBQ0wsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsSUFBSSxDQUFDLGFBQWEsR0FBRyxRQUFRLENBQUM7b0JBQzlCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLEdBQUcsQ0FBQyxDQUFDLENBQUM7d0JBQ3BDLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDO29CQUMvQixDQUFDO29CQUNELElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxHQUFHLENBQUMsQ0FBQyxDQUFDO3dCQUN6QyxJQUFJLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQztvQkFHaEMsQ0FBQztvQkFDRCxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsR0FBRyxFQUFFLENBQUM7Z0JBQ3ZDLENBQUM7Z0JBQ0QsNkNBQWtCLEdBQWxCO29CQUFBLGlCQXVYQztvQkF0WEcsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxDQUFDLEdBQUcsRUFBRSxJQUFJLFNBQVMsSUFBSSxNQUFNLENBQUMsZUFBZSxDQUFDLENBQUMsR0FBRyxFQUFFLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzt3QkFDdEYsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUFDLElBQUksQ0FBQyxDQUFDOzRCQUNyRixJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7d0JBQ3JDLENBQUM7d0JBQ0QsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEdBQUcsR0FBRyxDQUFDO3dCQUVuQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxHQUFHLENBQUMsQ0FBQyxDQUFDOzRCQUNwQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxHQUFHLENBQUM7d0JBRXpDLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7Z0NBQ3hGLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7b0NBQ3ZDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxDQUFDLENBQUMsQ0FBQztnQ0FDbEYsQ0FBQztnQ0FDRCxJQUFJLENBQUMsQ0FBQztvQ0FDRixJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxHQUFHLENBQUM7Z0NBQ3pDLENBQUM7NEJBQ0wsQ0FBQzt3QkFDTCxDQUFDO3dCQUNELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLEdBQUcsQ0FBQyxDQUFDLENBQUM7NEJBQ3BDLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxHQUFHLEdBQUcsQ0FBQzt3QkFDcEMsQ0FBQzt3QkFDRCxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksR0FBRyxDQUFDLENBQUMsQ0FBQzs0QkFDekMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDO3dCQUNyQyxDQUFDO3dCQUNELElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxHQUFHLENBQUMsQ0FBQyxDQUFDOzRCQUN6QyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7d0JBQ3JDLENBQUM7d0JBQ0QsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLElBQUksR0FBRyxDQUFDLENBQUMsQ0FBQzs0QkFDbkMsUUFBUTs0QkFDUiw2QkFBNkI7NEJBQzdCLDBFQUEwRTs0QkFDMUUsc0JBQXNCOzRCQUN0Qiw2QkFBNkI7NEJBQzdCLG9DQUFvQzs0QkFDcEMsK0JBQStCOzRCQUMvQiw2QkFBNkI7NEJBQzdCLDRCQUE0Qjs0QkFDNUIsMEJBQTBCOzRCQUMxQixJQUFJOzRCQUNKLDRCQUE0Qjs0QkFDNUIsMEJBQTBCOzRCQUMxQixXQUFXOzRCQUNYLGdCQUFnQjs0QkFDaEIsMkJBQTJCOzRCQUMzQixXQUFXOzRCQUNYLFNBQVM7NEJBRVQsbUJBQW1COzRCQUNuQiw2RUFBNkU7NEJBQzdFLGdCQUFnQjs0QkFDaEIsb0JBQW9COzRCQUNwQiwyQkFBMkI7NEJBQzNCLHNDQUFzQzs0QkFDdEMsWUFBWTs0QkFDWixtQkFBbUI7NEJBQ25CLDBCQUEwQjs0QkFDMUIscUNBQXFDOzRCQUNyQyxXQUFXOzRCQUNYLFFBQVE7NEJBQ1IsbUNBQW1DOzRCQUNuQyxnQ0FBZ0M7NEJBQ2hDLDJCQUEyQjs0QkFDM0IsV0FBVzs0QkFDWCxzRUFBc0U7NEJBQ3RFLE9BQU87NEJBQ1AsS0FBSzs0QkFHTCxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsNkRBQTZELENBQUMsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs0QkFDdkYsSUFBSSxDQUFDLENBQUM7Z0NBQ0YsTUFBTSxDQUFDLEtBQUssQ0FBQzs0QkFDakIsQ0FBQzt3QkFDTCxDQUFDO3dCQUNELElBQUksUUFBUSxHQUFHLEVBQUUsQ0FBQzt3QkFDbEIsSUFBSSxDQUFDLG9CQUFvQixDQUFDLHVCQUF1QixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTs0QkFFeEYsSUFBSSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzs0QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO2dDQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO29DQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtvQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO29DQUM1QixPQUFPLEVBQUU7d0NBQ0wsRUFBRSxFQUFFOzRDQUNBLGNBQWM7NENBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3lDQUM1QjtxQ0FDSjtpQ0FDSixDQUFDLENBQUM7NEJBQ1AsQ0FBQzs0QkFDRCxJQUFJLENBQUMsQ0FBQztnQ0FDRixRQUFRLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQztnQ0FDekIsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO29DQUV0QixRQUFRO29DQUNSLDZCQUE2QjtvQ0FDN0IscUJBQXFCO29DQUNyQixzQkFBc0I7b0NBQ3RCLDZCQUE2QjtvQ0FDN0Isb0NBQW9DO29DQUNwQywrQkFBK0I7b0NBQy9CLDZCQUE2QjtvQ0FDN0IsNEJBQTRCO29DQUM1QiwwQkFBMEI7b0NBQzFCLElBQUk7b0NBQ0osNEJBQTRCO29DQUM1QiwwQkFBMEI7b0NBQzFCLHdJQUF3STtvQ0FFeEkseURBQXlEO29DQUN6RCxrREFBa0Q7b0NBQ2xELDZDQUE2QztvQ0FDN0MsbUJBQW1CO29DQUNuQix3QkFBd0I7b0NBQ3hCLG1CQUFtQjtvQ0FDbkIsMEJBQTBCO29DQUMxQixxQ0FBcUM7b0NBQ3JDLHdCQUF3QjtvQ0FDeEIsOENBQThDO29DQUM5QyxpQkFBaUI7b0NBQ2pCLFdBQVc7b0NBQ1gsZ0JBQWdCO29DQUNoQiwyQkFBMkI7b0NBQzNCLFdBQVc7b0NBQ1gsU0FBUztvQ0FFVCxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzt3Q0FFNUIsS0FBSSxDQUFDLG9CQUFvQixDQUFDLHFCQUFxQixDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxFQUFFLEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTs0Q0FFbEgsSUFBSSxTQUFTLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzs0Q0FDdkMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO2dEQUM1QixPQUFPLENBQUMsS0FBSyxDQUFDO29EQUNWLE9BQU8sRUFBRSxTQUFTLENBQUMsTUFBTTtvREFDekIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO29EQUM1QixPQUFPLEVBQUU7d0RBQ0wsRUFBRSxFQUFFOzREQUNBLGNBQWM7NERBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3lEQUM1QjtxREFDSjtpREFDSixDQUFDLENBQUM7NENBQ1AsQ0FBQzs0Q0FDRCxJQUFJLENBQUMsQ0FBQzs0Q0FDTixDQUFDO3dDQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7NENBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQzt3Q0FDdkIsQ0FBQyxFQUFFOzRDQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7d0NBQ2hDLENBQUMsQ0FBQyxDQUFDO29DQUNQLENBQUM7b0NBQ0QsSUFBSSxDQUFDLENBQUM7d0NBQ0YsTUFBTSxDQUFDLEtBQUssQ0FBQztvQ0FDakIsQ0FBQztnQ0FDTCxDQUFDOzRCQUNMLENBQUM7d0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzs0QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO3dCQUN2QixDQUFDLEVBQUU7NEJBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTt3QkFDaEMsQ0FBQyxDQUFDLENBQUM7d0JBSUgsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLHVCQUF1QixJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUM7NEJBRXhDLFFBQVE7NEJBQ1IsNkJBQTZCOzRCQUM3QixxREFBcUQ7NEJBQ3JELHNCQUFzQjs0QkFDdEIsNkJBQTZCOzRCQUM3QixvQ0FBb0M7NEJBQ3BDLCtCQUErQjs0QkFDL0IsNkJBQTZCOzRCQUM3Qiw0QkFBNEI7NEJBQzVCLDBCQUEwQjs0QkFDMUIsSUFBSTs0QkFDSiw0QkFBNEI7NEJBQzVCLDBCQUEwQjs0QkFDMUIsa0lBQWtJOzRCQUVsSSx3REFBd0Q7NEJBQ3hELGlEQUFpRDs0QkFDakQsNENBQTRDOzRCQUM1QyxtQkFBbUI7NEJBQ25CLHdCQUF3Qjs0QkFDeEIsbUJBQW1COzRCQUNuQiwwQkFBMEI7NEJBQzFCLHFDQUFxQzs0QkFDckMsd0JBQXdCOzRCQUN4Qiw4Q0FBOEM7NEJBQzlDLGlCQUFpQjs0QkFDakIsV0FBVzs0QkFDWCxnQkFBZ0I7NEJBQ2hCLDJCQUEyQjs0QkFDM0IsV0FBVzs0QkFDWCxTQUFTOzRCQUVULEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyx3Q0FBd0MsQ0FBQyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7Z0NBQzVELElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO29DQUU1RyxJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO29DQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7d0NBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7NENBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNOzRDQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7NENBQzVCLE9BQU8sRUFBRTtnREFDTCxFQUFFLEVBQUU7b0RBQ0EsY0FBYztvREFDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7aURBQzVCOzZDQUNKO3lDQUNKLENBQUMsQ0FBQztvQ0FDUCxDQUFDO29DQUNELElBQUksQ0FBQyxDQUFDO29DQUNOLENBQUM7Z0NBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSztvQ0FDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO2dDQUN2QixDQUFDLEVBQUU7b0NBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtnQ0FDaEMsQ0FBQyxDQUFDLENBQUM7NEJBQ1AsQ0FBQzs0QkFDRCxJQUFJLENBQUMsQ0FBQztnQ0FDRixNQUFNLENBQUMsS0FBSyxDQUFDOzRCQUNqQixDQUFDO3dCQUVMLENBQUM7d0JBQ0QsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7d0JBQzVDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTs0QkFFaEQsSUFBSSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzs0QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO2dDQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO29DQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtvQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO29DQUM1QixPQUFPLEVBQUU7d0NBQ0wsRUFBRSxFQUFFOzRDQUNBLGNBQWM7NENBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3lDQUM1QjtxQ0FDSjtpQ0FDSixDQUFDLENBQUM7NEJBQ1AsQ0FBQzs0QkFDRCxJQUFJLENBQUMsQ0FBQztnQ0FDRixPQUFPLENBQUMsS0FBSyxDQUFDO29DQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtvQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO29DQUM1QixPQUFPLEVBQUU7d0NBQ0wsRUFBRSxFQUFFOzRDQUNBLGNBQWM7NENBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3lDQUM1QjtxQ0FDSjtpQ0FDSixDQUFDLENBQUM7Z0NBRUgsOEhBQThIO2dDQUM5SCxLQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQztnQ0FDdEQsS0FBSSxDQUFDLGNBQWMsR0FBRyxLQUFJLENBQUMsVUFBVSxDQUFDO2dDQUN0QyxLQUFJLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztnQ0FDckIsS0FBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLEdBQUcsS0FBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO2dDQUNsRSxLQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBRyxLQUFJLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7Z0NBQ3pELEtBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQztnQ0FDbEMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsR0FBRyxDQUFDO2dDQUNqQyxLQUFJLENBQUMsWUFBWSxHQUFHLEVBQUUsQ0FBQztnQ0FDdkIsS0FBSSxDQUFDLG9CQUFvQixDQUFDLGtCQUFrQixFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTtvQ0FDekQsV0FBVztvQ0FDWCxJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO29DQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7d0NBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7NENBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNOzRDQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7NENBQzVCLE9BQU8sRUFBRTtnREFDTCxFQUFFLEVBQUU7b0RBQ0EsY0FBYztvREFDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7aURBQzVCOzZDQUNKO3lDQUNKLENBQUMsQ0FBQztvQ0FDUCxDQUFDO29DQUNELElBQUksQ0FBQyxDQUFDO3dDQUNGLEtBQUksQ0FBQyxZQUFZLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzt3Q0FDbEMsSUFBSSxRQUFRLEdBQUcsRUFBRSxDQUFDO3dDQUNsQixJQUFJLFFBQVEsR0FBRyxLQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQzt3Q0FDMUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsWUFBWSxFQUFFOzRDQUUzQixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxJQUFJLFFBQVEsQ0FBQyxDQUFDLENBQUM7Z0RBRXpCLFFBQVEsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO2dEQUNyQixNQUFNLENBQUMsS0FBSyxDQUFDOzRDQUNqQixDQUFDO3dDQUNMLENBQUMsQ0FBQyxDQUFDO3dDQUNILEtBQUksQ0FBQyxhQUFhLEdBQUcsUUFBUSxDQUFDO29DQUVsQyxDQUFDO2dDQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7b0NBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztnQ0FDdkIsQ0FBQyxFQUFFO29DQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7Z0NBQ2hDLENBQUMsQ0FBQyxDQUFDO2dDQUNILEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLEdBQUcsQ0FBQztnQ0FDakMsS0FBSSxDQUFDLG9CQUFvQixDQUFDLFdBQVcsQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7b0NBQ2pGLFdBQVc7b0NBQ1gsSUFBSSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQztvQ0FDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO3dDQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDOzRDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTs0Q0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZOzRDQUM1QixPQUFPLEVBQUU7Z0RBQ0wsRUFBRSxFQUFFO29EQUNBLGNBQWM7b0RBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO2lEQUM1Qjs2Q0FDSjt5Q0FDSixDQUFDLENBQUM7b0NBQ1AsQ0FBQztvQ0FDRCxJQUFJLENBQUMsQ0FBQzt3Q0FDRixLQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQztvQ0FFNUQsQ0FBQztnQ0FDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO29DQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7Z0NBQ3ZCLENBQUMsRUFBRTtvQ0FDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO2dDQUNoQyxDQUFDLENBQUMsQ0FBQztnQ0FDSCxLQUFJLENBQUMsZ0JBQWdCLENBQUMsa0JBQWtCLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO29DQUMvRSxXQUFXO29DQUNYLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7b0NBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzt3Q0FDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQzs0Q0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07NENBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTs0Q0FDNUIsT0FBTyxFQUFFO2dEQUNMLEVBQUUsRUFBRTtvREFDQSxjQUFjO29EQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztpREFDNUI7NkNBQ0o7eUNBQ0osQ0FBQyxDQUFDO29DQUNQLENBQUM7b0NBQ0QsSUFBSSxDQUFDLENBQUM7d0NBQ0YsS0FBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLEdBQUcsR0FBRyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDO3dDQUMvRSxLQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQztvQ0FDOUQsQ0FBQztnQ0FDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO29DQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7Z0NBQ3ZCLENBQUMsRUFBRTtvQ0FDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO2dDQUNoQyxDQUFDLENBQUMsQ0FBQztnQ0FDSCxXQUFXO2dDQUNYLDRFQUE0RTtnQ0FDNUUsb0VBQW9FO2dDQUNwRSx3QkFBd0I7Z0NBQ3hCLEtBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsS0FBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLENBQUMsQ0FBQzs0QkFDOUUsQ0FBQzt3QkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLOzRCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7d0JBQ3ZCLENBQUMsRUFBRTs0QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO3dCQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFFUCxDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUNGLE9BQU8sQ0FBQyxLQUFLLENBQUM7NEJBQ1YsT0FBTyxFQUFFLDJCQUEyQjs0QkFDcEMsU0FBUyxFQUFFLElBQUksQ0FBQyxZQUFZOzRCQUM1QixPQUFPLEVBQUU7Z0NBQ0wsRUFBRSxFQUFFO29DQUNBLGNBQWM7b0NBQ2QsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO2lDQUM1Qjs2QkFDSjt5QkFDSixDQUFDLENBQUM7b0JBQ1AsQ0FBQztnQkFDTCxDQUFDO2dCQUNELHNDQUFXLEdBQVg7b0JBQ0ksSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEdBQUcsRUFBRSxDQUFDO2dCQUNyQyxDQUFDO2dCQUNELHdDQUFhLEdBQWI7b0JBQ0ksV0FBVztvQkFDWCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLGNBQWMsQ0FBQyxVQUFVLElBQUksSUFBSTsyQkFDbEYsSUFBSSxDQUFDLGNBQWMsQ0FBQyxlQUFlLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsZUFBZSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7d0JBQ3JHLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxlQUFlLENBQUMsQ0FBQztvQkFDeEYsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixPQUFPLENBQUMsS0FBSyxDQUFDOzRCQUNWLE9BQU8sRUFBRSwwREFBMEQ7NEJBQ25FLFNBQVMsRUFBRSxJQUFJLENBQUMsWUFBWTs0QkFDNUIsT0FBTyxFQUFFO2dDQUNMLEVBQUUsRUFBRTtvQ0FDQSxjQUFjO29DQUNkLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUztpQ0FDNUI7NkJBQ0o7eUJBQ0osQ0FBQyxDQUFDO29CQUNQLENBQUM7Z0JBQ0wsQ0FBQztnQkFDRCxvQ0FBUyxHQUFUO29CQUNJLFFBQVEsQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLFVBQVUsR0FBRyxlQUFlLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO2dCQUN4RixDQUFDO2dCQUNELG9DQUFTLEdBQVQsVUFBVSxVQUFVLEVBQUMsUUFBUTtvQkFBN0IsaUJBNkJDO29CQTVCRyxJQUFJLFNBQVMsR0FBRyxFQUFFLENBQUM7b0JBQ25CLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxRQUFRLENBQUMsVUFBVSxFQUFDLFFBQVEsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQ2xFLFdBQVc7d0JBQ1gsSUFBSSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtnQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUM1QixPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixTQUFTLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzs0QkFDMUIsbUNBQW1DOzRCQUNuQyxJQUFJLFlBQVksR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRSxPQUFPLEVBQUMsb0RBQW9ELENBQUMsQ0FBQzs0QkFDakcsWUFBWSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUM7NEJBQ3ZDLFlBQVksQ0FBQyxRQUFRLENBQUMsS0FBSyxFQUFFLENBQUM7d0JBQ2xDLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7Z0JBQ1AsQ0FBQztnQkFFRCx5Q0FBYyxHQUFkO29CQUNJLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQzt3QkFDL0IsSUFBSSxJQUFJLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQzt3QkFDOUMsUUFBUSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsVUFBVSxHQUFHLGdCQUFnQixHQUFHLElBQUksQ0FBQztvQkFDbEUsQ0FBQztnQkFDTCxDQUFDO2dCQUNELG1DQUFRLEdBQVI7b0JBQUEsaUJBeU5DO29CQXhORyxFQUFFLENBQUMsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7d0JBQ3JDLFlBQVksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxDQUFDO29CQUN2QyxDQUFDO29CQUNELElBQUksQ0FBQyxJQUFJLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFLMUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUN6RSxXQUFXO3dCQUNYLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO2dDQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQzVCLE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEtBQUksQ0FBQyxHQUFHLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzt3QkFDN0IsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFFSCxJQUFJLENBQUMsb0JBQW9CLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDakYsV0FBVzt3QkFDWCxJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO2dDQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQzVCLE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEtBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDO3dCQUU1RCxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUVILElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQy9FLFdBQVc7d0JBQ1gsSUFBSSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtnQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUM1QixPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLEtBQUssR0FBRyxHQUFHLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7NEJBQy9FLEtBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDO3dCQUM5RCxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUVILElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQ3ZELElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLFNBQVMsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO3dCQUVuQyxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUVILElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxrQkFBa0IsRUFBRSxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQ3pELElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsV0FBVzs0QkFDWCxLQUFJLENBQUMsWUFBWSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7NEJBQ2xDLElBQUksSUFBSSxHQUFHLEdBQUcsR0FBRyxLQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEVBQUUsQ0FBQzs0QkFDdkQsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7d0JBQ3ZDLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBRUgsSUFBSSxDQUFDLG9CQUFvQixDQUFDLGtCQUFrQixFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFFekQsSUFBSSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtnQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUM1QixPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsWUFBWSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7NEJBQ2xDLElBQUksUUFBUSxHQUFHLEVBQUUsQ0FBQzs0QkFDbEIsSUFBSSxRQUFRLEdBQUcsS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUM7NEJBQzFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLFlBQVksRUFBRTtnQ0FFM0IsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssSUFBSSxRQUFRLENBQUMsQ0FBQyxDQUFDO29DQUV6QixRQUFRLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQztvQ0FDckIsTUFBTSxDQUFDLEtBQUssQ0FBQztnQ0FDakIsQ0FBQzs0QkFDTCxDQUFDLENBQUMsQ0FBQzs0QkFDSCxLQUFJLENBQUMsYUFBYSxHQUFHLFFBQVEsQ0FBQzt3QkFFbEMsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFFSCxJQUFJLENBQUMsb0JBQW9CLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDaEQsSUFBSSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtnQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUM1QixPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsTUFBTSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7d0JBRWhDLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBRUgsSUFBSSxDQUFDLG9CQUFvQixDQUFDLFVBQVUsRUFBRSxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQ2pELElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLE1BQU0sR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO3dCQUVoQyxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUNILE1BQU0sQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLENBQUMsMkJBQTJCLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxDQUFDO2dCQUNqRyxDQUFDO2dCQXR3Qk0sd0JBQU8sR0FBRyxDQUFDLFFBQVEsRUFBRSxXQUFXLEVBQUUsZUFBZSxDQUFDLENBQUM7Z0JBZDlEO29CQUFDLGdCQUFTLENBQUM7d0JBRVAsV0FBVyxFQUFFLHNEQUFzRDt3QkFDbkUsVUFBVSxFQUFFLENBQUMsaUJBQVEsRUFBRSxxQkFBWSxFQUFFLHdCQUFlLEVBQUUsdUJBQXVCLEVBQUUsd0JBQWUsRUFBRSx3QkFBZSxDQUFDO3dCQUNoSCxTQUFTLEVBQUUsQ0FBQyxpQ0FBZSxFQUFFLGlDQUFlLEVBQUUseUNBQW1CLENBQUM7cUJBQ3JFLENBQUM7O29DQUFBO2dCQWd4QkYsdUJBQUM7WUFBRCxDQTl3QkEsQUE4d0JDLElBQUE7WUE5d0JELCtDQTh3QkMsQ0FBQSIsImZpbGUiOiJhbWF4L0NoYXJnZV9DcmVkaXQvQ2hhcmdlQ3JlZGl0Q2FyZC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7TmdTd2l0Y2gsIE5nU3dpdGNoV2hlbiwgTmdTd2l0Y2hEZWZhdWx0LCBDT1JFX0RJUkVDVElWRVMsIEZPUk1fRElSRUNUSVZFU30gZnJvbSAnYW5ndWxhcjIvY29tbW9uJ1xyXG5pbXBvcnQge1Jlc291cmNlU2VydmljZX0gZnJvbSBcIi4uLy4uL3NlcnZpY2VzL1Jlc291cmNlU2VydmljZVwiO1xyXG5pbXBvcnQge1JvdXRlUGFyYW1zfSBmcm9tIFwiYW5ndWxhcjIvcm91dGVyXCI7XHJcbmltcG9ydCB7Q29tcG9uZW50LCBPdXRwdXQsIElucHV0LCBFdmVudEVtaXR0ZXIsIE9uSW5pdH0gZnJvbSBcImFuZ3VsYXIyL2NvcmVcIjtcclxuaW1wb3J0IHtDdXN0b21lclNlcnZpY2V9IGZyb20gXCIuLi8uLi9zZXJ2aWNlcy9DdXN0b21lclNlcnZpY2VcIjtcclxuaW1wb3J0IHtDaGFyZ2VDcmVkaXRTZXJ2aWNlfSBmcm9tIFwiLi4vLi4vc2VydmljZXMvQ2hhcmdlQ3JlZGl0U2VydmljZVwiO1xyXG5pbXBvcnQgeyBqc29uUSB9IGZyb20gJy4uLy4uL2pzb25RJztcclxuaW1wb3J0IHtHcm91cEZpbHRlclBpcGUsIEdyb3VwUGFyZW5GaWx0ZXJQaXBlLCBLZW5kb191dGlsaXR5fSBmcm9tIFwiLi4vLi4vYW1heFV0aWxcIjtcclxuaW1wb3J0IHtBdXRvY29tcGxldGVDb250YWluZXJ9IGZyb20gJy4uLy4uL2F1dG9jb21wbGV0ZS9hdXRvY29tcGxldGUtY29udGFpbmVyJztcclxuaW1wb3J0IHtBdXRvY29tcGxldGV9IGZyb20gJy4uLy4uL2F1dG9jb21wbGV0ZS9hdXRvY29tcGxldGUuY29tcG9uZW50JztcclxuXHJcbmV4cG9ydCBjb25zdCBBVVRPQ09NUExFVEVfRElSRUNUSVZFUyA9IFtBdXRvY29tcGxldGUsIEF1dG9jb21wbGV0ZUNvbnRhaW5lcl07XHJcbmRlY2xhcmUgdmFyIGpRdWVyeTtcclxuQENvbXBvbmVudCh7XHJcblxyXG4gICAgdGVtcGxhdGVVcmw6ICcuL2FwcC9hbWF4L0NoYXJnZV9DcmVkaXQvdGVtcGxhdGVzL0NoYXJnZUNyZWRpdC5odG1sJyxcclxuICAgIGRpcmVjdGl2ZXM6IFtOZ1N3aXRjaCwgTmdTd2l0Y2hXaGVuLCBOZ1N3aXRjaERlZmF1bHQsIEFVVE9DT01QTEVURV9ESVJFQ1RJVkVTLCBDT1JFX0RJUkVDVElWRVMsIEZPUk1fRElSRUNUSVZFU10sXHJcbiAgICBwcm92aWRlcnM6IFtDdXN0b21lclNlcnZpY2UsIFJlc291cmNlU2VydmljZSwgQ2hhcmdlQ3JlZGl0U2VydmljZV1cclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBBbWF4Q2hhcmdlQ3JlZGl0IGltcGxlbWVudHMgT25Jbml0IHtcclxuICAgIG1vZGVsSW5wdXQgPSB7fTtcclxuICAgIG1vZGVsSW5wdXRUZW1wID0ge307XHJcbiAgICBSRVM6IE9iamVjdCA9IHt9O1xyXG4gICAgRm9ybXR5cGU6IHN0cmluZyA9XCJDSEFSR0VDUkVESVRfU0NSRUVOXCI7XHJcbiAgICBMYW5nOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgQ3VzdG9tZXJJZDogbnVtYmVyID0gLTE7XHJcbiAgICBzdGF0aWMgJGluamVjdCA9IFsnJHNjb3BlJywgJyRsb2NhdGlvbicsICckYW5jaG9yU2Nyb2xsJ107XHJcbiAgICBCYXNlQXBwVXJsOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgX1Rlcm1pbmFsTGlzdCA9IFtdO1xyXG4gICAgVGVybWluYWxOdW1iZXI6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBSZW1QYXltZW50c1RleHQ6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBOdW1PZlBheW1lbnRzVGV4dDogc3RyaW5nID0gXCJcIjtcclxuICAgIElzYnRuZGlzYWJsZTogc3RyaW5nID0gXCJcIjtcclxuICAgIE1zZ0NsYXNzOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgQ2hhbmdlRGlhbG9nOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgQ0hBTkdFRElSOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgU2hvd0xvYWRlcjogYm9vbGVhbjtcclxuICAgIFNBVkVfQlROX1RFWFQ6IHN0cmluZztcclxuICAgIElzQ3JlZGl0Q2FuY2VsOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBJc0NyZWRpdE5vT2ZQYXk6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIEluc3RhbGxtZW50czphbnk9MDtcclxuICAgIEluc3RhbGxtZW50UGF5OiBhbnkgPSAwO1xyXG4gICAgaXNmaW5kY3JlZGl0Q2FyZE93bmVySUQ6IGJvb2xlYW4gPSB0cnVlO1xyXG4gICAgUHJpbnRVcmw6IHN0cmluZyA9IFwiaHR0cHM6Ly9zZWN1cmUuY2FyZGNvbS5jby5pbC9Ob3RlL1Byb2dyYW1Ob3RlLmFzcHhcIjsvKj9EZWFsTnVtYmVyPVwiICsgb0RlYWxOdW1iZXIgKyBcIiZEaXNwbGF5RGF0YT0zJlRlcm1pYW5sPVwiICsgb1Rlcm1pYW5sICsgXCImRGVmUHJpbnQ9ZmFsc2VcIjsqL1xyXG4gICAgX01udGhzID0gW107XHJcbiAgICBfWWVhcnMgPSBbXTtcclxuICAgIF9DaGFyZ2VUeXBlcyA9IFtdO1xyXG4gICAgX0N1cnJlbmN5ID0gW107XHJcbiAgICBfQ3JlZGl0VHlwZXMgPSBbXTtcclxuXHJcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIF9yZXNvdXJjZVNlcnZpY2U6IFJlc291cmNlU2VydmljZSwgcHJpdmF0ZSBfY3VzdG9tZXJTZXJ2aWNlOiBDdXN0b21lclNlcnZpY2UsIHByaXZhdGUgX3JvdXRlUGFyYW1zOiBSb3V0ZVBhcmFtcywgcHJpdmF0ZSBfQ2hhcmdlQ3JlZGl0U2VydmljZTogQ2hhcmdlQ3JlZGl0U2VydmljZSkge1xyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMuUkVTLkNIQVJHRUNSRURJVF9TQ1JFRU4gPSB7fTtcclxuICAgICAgICB0aGlzLkJhc2VBcHBVcmwgPSBfcmVzb3VyY2VTZXJ2aWNlLkFwcFVybDtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCA9IF9yb3V0ZVBhcmFtcy5wYXJhbXMuSWQ7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0Lm9UZXJtaW5hbE51bWJlciA9IF9yb3V0ZVBhcmFtcy5wYXJhbXMuVGVybU5vO1xyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5vQ3VycmVuY3kgPSBcIk5pc1wiO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DaGFyZ2VUeXBlID0gXCIwXCI7XHJcbiAgICAgICAvLyB0aGlzLk9wZW5EaXYoKTtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3JlZGl0VHlwZSA9IFwiMFwiO1xyXG4gICAgICAgIC8vdGhpcy5tb2RlbElucHV0VGVtcC5EZWFsTnVtYmVyID0gXCJ0ZXN0XCI7XHJcbiAgICAgICAgLy90aGlzLm1vZGVsSW5wdXRUZW1wLm9UZXJtaW5hbE51bWJlciA9IFwidGVzdFwiO1xyXG4gICAgLy8gICAgbW9kZWxJbnB1dC5vQ3VycmVuY3kgICAgICAgIFxyXG4gICAgfVxyXG4gICAgQ2hhbmdlT3duZXJJZCgpIHtcclxuICAgICAgICB0aGlzLmlzZmluZGNyZWRpdENhcmRPd25lcklEID0gZmFsc2U7XHJcbiAgICB9XHJcbiAgICBDYWxjdWxhdGVDb25zdFBheSgpIHtcclxuICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0Lm9TdW1Ub0JpbGwgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dC5vU3VtVG9CaWxsICE9IG51bGwgJiYgdGhpcy5tb2RlbElucHV0Lm9TdW1Ub0JpbGwgIT0gXCJcIlxyXG4gICAgICAgICAgICAmJiB0aGlzLm1vZGVsSW5wdXQub2ZpcnN0cGF5bWVudHN1bSAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0Lm9maXJzdHBheW1lbnRzdW0gIT0gbnVsbCAmJiB0aGlzLm1vZGVsSW5wdXQub2ZpcnN0cGF5bWVudHN1bSAhPSBcIlwiXHJcbiAgICAgICAgICAgICYmIHRoaXMubW9kZWxJbnB1dC5vTnVtT2ZQYXltZW50cyAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0Lm9OdW1PZlBheW1lbnRzICE9IG51bGwgJiYgdGhpcy5tb2RlbElucHV0Lm9OdW1PZlBheW1lbnRzICE9IFwiXCIpIHtcclxuICAgICAgICAgICAgdmFyIFJlbUFtdCA9IHBhcnNlRmxvYXQodGhpcy5tb2RlbElucHV0Lm9TdW1Ub0JpbGwpIC0gcGFyc2VGbG9hdCh0aGlzLm1vZGVsSW5wdXQub2ZpcnN0cGF5bWVudHN1bSk7XHJcbiAgICAgICAgICAgIGlmIChSZW1BbXQgPj0gMCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHBhcnNlSW50KHRoaXMubW9kZWxJbnB1dC5vTnVtT2ZQYXltZW50cykgPT0gMSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChSZW1BbXQgPiAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogXCJQbGVhc2UgZ2l2ZSBmdWxsIGFtb3VudCBpbiBmaXJzdCBwYXltZW50IG9yIGluY3JlYXNlIHRoIG5vIG9mIHBheW1lbnRzXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5OdW1PZlBheW1lbnRzVGV4dCA9IHRoaXMubW9kZWxJbnB1dC5vTnVtT2ZQYXltZW50cyArIFwiIHBheW1lbnRzLCBmaXJzdCBwYXltZW50OiBcIiArIHRoaXMubW9kZWxJbnB1dC5vZmlyc3RwYXltZW50c3VtO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLlJlbVBheW1lbnRzVGV4dCA9IHRoaXMubW9kZWxJbnB1dC5vZmlyc3RwYXltZW50c3VtK1wiIGFuZCAwIHBheW1lbnRzIG9mIDBcIjtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIGlmIChwYXJzZUludCh0aGlzLm1vZGVsSW5wdXQub051bU9mUGF5bWVudHMpID4gMSkge1xyXG4gICAgICAgICAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5JbnN0YWxsbWVudFBheSA9IHBhcnNlRmxvYXQoUmVtQW10IC8gcGFyc2VGbG9hdCh0aGlzLm1vZGVsSW5wdXQub051bU9mUGF5bWVudHMgLSAxKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0Lm9jb25zdHBhdG1lbnQgPSB0aGlzLkluc3RhbGxtZW50UGF5O1xyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuTnVtT2ZQYXltZW50c1RleHQgPSB0aGlzLm1vZGVsSW5wdXQub051bU9mUGF5bWVudHMgKyBcIiBwYXltZW50cywgZmlyc3QgcGF5bWVudDogXCIgKyB0aGlzLm1vZGVsSW5wdXQub2ZpcnN0cGF5bWVudHN1bTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLlJlbVBheW1lbnRzVGV4dCA9IHRoaXMubW9kZWxJbnB1dC5vZmlyc3RwYXltZW50c3VtICsgXCIgYW5kIFwiICsgcGFyc2VGbG9hdCh0aGlzLm1vZGVsSW5wdXQub051bU9mUGF5bWVudHMgLSAxKSArIFwiIHBheW1lbnRzIG9mIFwiICtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5JbnN0YWxsbWVudFBheS50b0ZpeGVkKDIpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5vTnVtT2ZQYXltZW50cyA9IHBhcnNlRmxvYXQodGhpcy5tb2RlbElucHV0Lm9OdW1PZlBheW1lbnRzKSArIDE7XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBDaGFuZ2VDcmVkaXRUeXBlKG9iaikge1xyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DcmVkaXRUeXBlID0gb2JqLlZhbHVlO1xyXG4gICAgICAgIGlmIChvYmouVmFsdWUgIT0gMCkge1xyXG4gICAgICAgICAgICB0aGlzLklzQ3JlZGl0Tm9PZlBheSA9IHRydWU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLklzQ3JlZGl0Tm9PZlBheSA9IGZhbHNlO1xyXG4gICAgICAgICAgICBcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0Lm9maXJzdHBheW1lbnRzdW0gPSBcIlwiO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5vTnVtT2ZQYXltZW50cyA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5OdW1PZlBheW1lbnRzVGV4dCA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5SZW1QYXltZW50c1RleHQ7XHJcbiAgICB9XHJcbiAgICBPcGVuRGl2KCkge1xyXG4gICAgICAgIHZhciBzYXZldGV4dCA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkNoYXJnZVR5cGUgPSBqUXVlcnkoXCIjQ2hhcmdldHlwZVwiKS52YWwoKTtcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgIHZhciBjaHJndHlwZSA9IHRoaXMubW9kZWxJbnB1dC5DaGFyZ2VUeXBlO1xyXG4gICAgICAgIGpRdWVyeS5lYWNoKHRoaXMuX0NoYXJnZVR5cGVzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgXHJcbiAgICAgICAgICAgIGlmICh0aGlzLlZhbHVlID09IGNocmd0eXBlKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgc2F2ZXRleHQgPSB0aGlzLlRleHQ7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgICAgICB0aGlzLlNBVkVfQlROX1RFWFQgPSBzYXZldGV4dDtcclxuICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkNoYXJnZVR5cGUgIT0gXCIwXCIpIHtcclxuICAgICAgICAgICAgdGhpcy5Jc0NyZWRpdENhbmNlbCA9IHRydWU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2UgaWYgKHRoaXMubW9kZWxJbnB1dC5DaGFyZ2VUeXBlID09IFwiMFwiKSB7XHJcbiAgICAgICAgICAgIHRoaXMuSXNDcmVkaXRDYW5jZWwgPSBmYWxzZTsgXHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICBcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0Lm91c2VycGFzc3dvcmQgPSBcIlwiO1xyXG4gICAgfVxyXG4gICAgQ2hlY2tDcmVkaXRDYXJkRGV0KCkge1xyXG4gICAgICAgIGlmIChqUXVlcnkoXCJpbnB1dDpjaGVja2VkXCIpLnZhbCgpICE9IHVuZGVmaW5lZCAmJiBqUXVlcnkoXCJpbnB1dDpjaGVja2VkXCIpLnZhbCgpICE9IG51bGwpIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5Vc2VUb2tlbiAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0LlVzZVRva2VuICE9IG51bGwpIHsgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5Vc2VUb2tlbiA9IGZhbHNlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5Db21wYW55U2xpa2EgPSBcIjFcIjtcclxuXHJcbiAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3JlZGl0VHlwZSA9PSBcIjBcIikge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0Lm9OdW1PZlBheW1lbnRzID0gXCIxXCI7XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5vTnVtT2ZQYXltZW50cyAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0Lm9OdW1PZlBheW1lbnRzICE9IG51bGwpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0Lm9OdW1PZlBheW1lbnRzICE9IFwiXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0Lm9OdW1PZlBheW1lbnRzID0gcGFyc2VJbnQodGhpcy5tb2RlbElucHV0Lm9OdW1PZlBheW1lbnRzICsgMSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQub051bU9mUGF5bWVudHMgPSBcIjFcIjtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5DaGFyZ2VUeXBlID09IFwiMFwiKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQub2RlYWx0eXBlID0gXCIxXCI7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSBpZiAodGhpcy5tb2RlbElucHV0LkNoYXJnZVR5cGUgPT0gXCIxXCIpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5vZGVhbHR5cGUgPSBcIjUxXCI7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSBpZiAodGhpcy5tb2RlbElucHV0LkNoYXJnZVR5cGUgPT0gXCIyXCIpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5vZGVhbHR5cGUgPSBcIjUyXCI7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5vZGVhbHR5cGUgPT0gXCIxXCIpIHtcclxuICAgICAgICAgICAgICAgIC8vc3dhbCh7XHJcbiAgICAgICAgICAgICAgICAvLyAgICB0aXRsZTogXCJBcmUgeW91IHN1cmU/XCIsXHJcbiAgICAgICAgICAgICAgICAvLyAgICB0ZXh0OiBcIk5vdGUgdGhhdCB5b3UgcmVxdWVzdGVkIGNoYXJnZSB0aGUgY3VzdG9tZXIsIHdpbGwgY29udGludWUhXCIsXHJcbiAgICAgICAgICAgICAgICAvLyAgICB0eXBlOiBcIndhcm5pbmdcIixcclxuICAgICAgICAgICAgICAgIC8vICAgIHNob3dDYW5jZWxCdXR0b246IHRydWUsXHJcbiAgICAgICAgICAgICAgICAvLyAgICBjb25maXJtQnV0dG9uQ29sb3I6IFwiI0RENkI1NVwiLFxyXG4gICAgICAgICAgICAgICAgLy8gICAgY29uZmlybUJ1dHRvblRleHQ6IFwiWWVzXCIsXHJcbiAgICAgICAgICAgICAgICAvLyAgICBjYW5jZWxCdXR0b25UZXh0OiBcIk5vXCIsXHJcbiAgICAgICAgICAgICAgICAvLyAgICBjbG9zZU9uQ29uZmlybTogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICAvLyAgICBjbG9zZU9uQ2FuY2VsOiBmYWxzZVxyXG4gICAgICAgICAgICAgICAgLy99LFxyXG4gICAgICAgICAgICAgICAgLy8gICAgZnVuY3Rpb24gKGlzQ29uZmlybSkge1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgIGlmIChpc0NvbmZpcm0pIHtcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvLyAgICB9KTtcclxuXHJcbiAgICAgICAgICAgICAgICAvL2Jvb3Rib3guY29uZmlybSh7XHJcbiAgICAgICAgICAgICAgICAvLyAgICBtZXNzYWdlOiBcIk5vdGUgdGhhdCB5b3UgcmVxdWVzdGVkIGNoYXJnZSB0aGUgY3VzdG9tZXIsIHdpbGwgY29udGludWU/XCIsXHJcbiAgICAgICAgICAgICAgICAvLyAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgY29uZmlybToge1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICBsYWJlbDogJ1llcycsXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgIGNsYXNzTmFtZTogJ2J0bi1zdWNjZXNzJ1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgY2FuY2VsOiB7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgIGxhYmVsOiAnTm8nLFxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICBjbGFzc05hbWU6ICdidG4tZGFuZ2VyJ1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC8vICAgIH0sXHJcbiAgICAgICAgICAgICAgICAvLyAgICBjYWxsYmFjazogZnVuY3Rpb24gKHJlc3VsdCkge1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgIGlmIChyZXN1bHQgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAvL2NvbnNvbGUubG9nKCdUaGlzIHdhcyBsb2dnZWQgaW4gdGhlIGNhbGxiYWNrOiAnICsgcmVzdWx0KTtcclxuICAgICAgICAgICAgICAgIC8vICAgIH1cclxuICAgICAgICAgICAgICAgIC8vfSk7XHJcblxyXG5cclxuICAgICAgICAgICAgICAgIGlmIChjb25maXJtKFwiTm90ZSB0aGF0IHlvdSByZXF1ZXN0ZWQgY2hhcmdlIHRoZSBjdXN0b21lciwgd2lsbCBjb250aW51ZT9cIikgPT0gdHJ1ZSkgeyB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdmFyIElzSW5zZXJ0ID0gXCJcIjtcclxuICAgICAgICAgICAgdGhpcy5fQ2hhcmdlQ3JlZGl0U2VydmljZS5Jc0luc2VydFRvdGJsTGFzdFVwZGF0ZSh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCkuc3Vic2NyaWJlKHJlc3A9PiB7XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIHZhciByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcCk7XHJcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgSXNJbnNlcnQgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChJc0luc2VydC5sZW5ndGggPiAwKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL3N3YWwoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICB0aXRsZTogXCJBcmUgeW91IHN1cmU/XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgIHRleHQ6IElzSW5zZXJ0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICB0eXBlOiBcIndhcm5pbmdcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gICAgc2hvd0NhbmNlbEJ1dHRvbjogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gICAgY29uZmlybUJ1dHRvbkNvbG9yOiBcIiNERDZCNTVcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gICAgY29uZmlybUJ1dHRvblRleHQ6IFwiWWVzXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgIGNhbmNlbEJ1dHRvblRleHQ6IFwiTm9cIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gICAgY2xvc2VPbkNvbmZpcm06IGZhbHNlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICBjbG9zZU9uQ2FuY2VsOiBmYWxzZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL30sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgIGZ1bmN0aW9uIChpc0NvbmZpcm0pIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gICAgICAgIGlmIChpc0NvbmZpcm0pIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gICAgICAgICAgICB0aGlzLl9DaGFyZ2VDcmVkaXRTZXJ2aWNlLkluc2VydFRvdGJsTGFzdFVwZGF0ZSh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCwgdGhpcy5tb2RlbElucHV0Lm9TdW1Ub0JpbGwpLnN1YnNjcmliZShyZXNwPT4ge1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgICAgdmFyIHJlc3BvbnNlMSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZTEuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgICAgICAgICBzd2FsKHJlc3BvbnNlMS5FcnJNc2cpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gICAgICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChjb25maXJtKElzSW5zZXJ0KSA9PSB0cnVlKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fQ2hhcmdlQ3JlZGl0U2VydmljZS5JbnNlcnRUb3RibExhc3RVcGRhdGUodGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQsIHRoaXMubW9kZWxJbnB1dC5vU3VtVG9CaWxsKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHJlc3BvbnNlMSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlMS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZTEuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICAgICAgfSk7XHJcblxyXG5cclxuXHJcbiAgICAgICAgICAgIGlmICh0aGlzLmlzZmluZGNyZWRpdENhcmRPd25lcklEID09IGZhbHNlKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgLy9zd2FsKHtcclxuICAgICAgICAgICAgICAgIC8vICAgIHRpdGxlOiBcIkFyZSB5b3Ugc3VyZT9cIixcclxuICAgICAgICAgICAgICAgIC8vICAgIHRleHQ6IFwiWW91IHdhbnQgdG8gdXBkYXRlIGEgY3VzdG9tZXIgSUQgY2FyZCFcIixcclxuICAgICAgICAgICAgICAgIC8vICAgIHR5cGU6IFwid2FybmluZ1wiLFxyXG4gICAgICAgICAgICAgICAgLy8gICAgc2hvd0NhbmNlbEJ1dHRvbjogdHJ1ZSxcclxuICAgICAgICAgICAgICAgIC8vICAgIGNvbmZpcm1CdXR0b25Db2xvcjogXCIjREQ2QjU1XCIsXHJcbiAgICAgICAgICAgICAgICAvLyAgICBjb25maXJtQnV0dG9uVGV4dDogXCJZZXNcIixcclxuICAgICAgICAgICAgICAgIC8vICAgIGNhbmNlbEJ1dHRvblRleHQ6IFwiTm9cIixcclxuICAgICAgICAgICAgICAgIC8vICAgIGNsb3NlT25Db25maXJtOiBmYWxzZSxcclxuICAgICAgICAgICAgICAgIC8vICAgIGNsb3NlT25DYW5jZWw6IGZhbHNlXHJcbiAgICAgICAgICAgICAgICAvL30sXHJcbiAgICAgICAgICAgICAgICAvLyAgICBmdW5jdGlvbiAoaXNDb25maXJtKSB7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgaWYgKGlzQ29uZmlybSkge1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICB0aGlzLl9DaGFyZ2VDcmVkaXRTZXJ2aWNlLlVwZGF0ZU93bmVySWQodGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQsIHRoaXMubW9kZWxJbnB1dC5vQ2FyZE93bmVySWQpLnN1YnNjcmliZShyZXNwPT4ge1xyXG5cclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgICAgIHZhciByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcCk7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgc3dhbChyZXNwb25zZS5FcnJNc2cpO1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLy8gICAgfSk7XHJcbiAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICBpZiAoY29uZmlybShcIllvdSB3YW50IHRvIHVwZGF0ZSBhIGN1c3RvbWVyIElEIGNhcmQ/XCIpID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9DaGFyZ2VDcmVkaXRTZXJ2aWNlLlVwZGF0ZU93bmVySWQodGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQsIHRoaXMubW9kZWxJbnB1dC5vQ2FyZE93bmVySWQpLnN1YnNjcmliZShyZXNwPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICAgICAgICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdmFyIGpkYXRhID0gSlNPTi5zdHJpbmdpZnkodGhpcy5tb2RlbElucHV0KTtcclxuICAgICAgICAgICAgdGhpcy5fQ2hhcmdlQ3JlZGl0U2VydmljZS5TYXZlKGpkYXRhKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIC8vIGRvY3VtZW50LmxvY2F0aW9uID0gdGhpcy5CYXNlQXBwVXJsICsgXCJDaGFyZ2VDcmVkaXQvXCIgKyB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCArIFwiL1wiICsgdGhpcy5tb2RlbElucHV0Lm9UZXJtaW5hbE51bWJlcjtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuRGVhbE51bWJlciA9IHJlc3BvbnNlLkRhdGEuRGVhbE51bWJlcjtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXRUZW1wID0gdGhpcy5tb2RlbElucHV0O1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dCA9IHt9O1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5vVGVybWluYWxOdW1iZXIgPSB0aGlzLl9yb3V0ZVBhcmFtcy5wYXJhbXMuVGVybU5vO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkID0gdGhpcy5fcm91dGVQYXJhbXMucGFyYW1zLklkO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5vQ3VycmVuY3kgPSBcIk5pc1wiO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DaGFyZ2VUeXBlID0gXCIwXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fQ2hhcmdlVHlwZXMgPSBbXTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9DaGFyZ2VDcmVkaXRTZXJ2aWNlLkJpbmRDaGFyZ2VUeXBlTGlzdCgpLnN1YnNjcmliZShyZXNwPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3ApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9DaGFyZ2VUeXBlcyA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgc2F2ZXRleHQgPSBcIlwiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGNocmd0eXBlID0gdGhpcy5tb2RlbElucHV0LkNoYXJnZVR5cGU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLl9DaGFyZ2VUeXBlcywgZnVuY3Rpb24gKCkge1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5WYWx1ZSA9PSBjaHJndHlwZSkge1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2F2ZXRleHQgPSB0aGlzLlRleHQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuU0FWRV9CVE5fVEVYVCA9IHNhdmV0ZXh0O1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgICAgICAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3JlZGl0VHlwZSA9IFwiMFwiO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX0NoYXJnZUNyZWRpdFNlcnZpY2UuQmluZFRlcm1EZXQodGhpcy5tb2RlbElucHV0Lm9UZXJtaW5hbE51bWJlcikuc3Vic2NyaWJlKHJlc3A9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5vdXNlcm5hbWUgPSByZXNwb25zZS5EYXRhLmluc3RpdHV0ZU5hbWU7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICAgICAgICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRDb21wbGV0ZUN1c3REZXQodGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQpLnN1YnNjcmliZShyZXNwPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3ApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJOYW1lID0gcmVzcG9uc2UuRGF0YS5mbmFtZSArIFwiIFwiICsgcmVzcG9uc2UuRGF0YS5sbmFtZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5vQ2FyZE93bmVySWQgPSByZXNwb25zZS5EYXRhLkN1c3RvbWVyQ29kZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgICAgICAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vdmFyIFByaW50VXJsID0gdGhpcy5QcmludFVybCArIFwiP0RlYWxOdW1iZXI9XCIgKyByZXNwb25zZS5EYXRhLkRlYWxOdW1iZXIgK1xyXG4gICAgICAgICAgICAgICAgICAgIC8vICAgIFwiJkRpc3BsYXlEYXRhPTMmVGVybWlhbmw9XCIgKyB0aGlzLm1vZGVsSW5wdXQub1Rlcm1pbmFsTnVtYmVyICtcclxuICAgICAgICAgICAgICAgICAgICAvLyAgICBcIiZEZWZQcmludD1mYWxzZVwiO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuUHJpbnREYXRhKHJlc3BvbnNlLkRhdGEuRGVhbE51bWJlciwgdGhpcy5tb2RlbElucHV0Lm9UZXJtaW5hbE51bWJlcik7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICBtZXNzYWdlOiAnUGxlYXNlIHNlbGVjdCBjcmVkaXQgdHlwZScsXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIENsZWFyQ2FyZE5vKCkge1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5vQ2FyZE51bWJlciA9IFwiXCI7XHJcbiAgICB9XHJcbiAgICBQcmludFByZXZEYXRhKCkge1xyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dFRlbXAuRGVhbE51bWJlciAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0VGVtcC5EZWFsTnVtYmVyICE9IG51bGxcclxuICAgICAgICAgICAgJiYgdGhpcy5tb2RlbElucHV0VGVtcC5vVGVybWluYWxOdW1iZXIgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dFRlbXAub1Rlcm1pbmFsTnVtYmVyICE9IG51bGwpIHtcclxuICAgICAgICAgICAgdGhpcy5QcmludERhdGEodGhpcy5tb2RlbElucHV0VGVtcC5EZWFsTnVtYmVyLCB0aGlzLm1vZGVsSW5wdXRUZW1wLm9UZXJtaW5hbE51bWJlcik7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiUGxlYXNlIGRvIGFueSB0cmFuc2VjdGlvbiBhbmQgdGhlbiBjbGljayBvbiBwcmludCBidXR0b25cIixcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgQ2FuY2VsQnRuKCkge1xyXG4gICAgICAgIGRvY3VtZW50LmxvY2F0aW9uID0gdGhpcy5CYXNlQXBwVXJsICsgXCJDdXN0b21lci9BZGQvXCIgKyB0aGlzLl9yb3V0ZVBhcmFtcy5wYXJhbXMuSWQ7XHJcbiAgICB9XHJcbiAgICBQcmludERhdGEoRGVhbE51bWJlcixUZXJtaW5hbCkge1xyXG4gICAgICAgIHZhciBQcmludERhdGEgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMuX0NoYXJnZUNyZWRpdFNlcnZpY2UuZ2V0UHJpbnQoRGVhbE51bWJlcixUZXJtaW5hbCkuc3Vic2NyaWJlKHJlc3A9PiB7XHJcbiAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgIHZhciByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcCk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIFByaW50RGF0YSA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICAvL3ZhciBPcGVuV2luZG93ID0gd2luZG93Lm9wZW4oXCJcIik7XHJcbiAgICAgICAgICAgICAgICB2YXIgd2luZG93T2JqZWN0ID0gd2luZG93Lm9wZW4oJycsICdQcmludCcsJ3Njcm9sbGJhcnM9eWVzLHJlc2l6YWJsZT15ZXMsd2lkdGg9MTA1MCxoZWlnaHQ9NjUwJyk7XHJcbiAgICAgICAgICAgICAgICB3aW5kb3dPYmplY3QuZG9jdW1lbnQud3JpdGUoUHJpbnREYXRhKTtcclxuICAgICAgICAgICAgICAgIHdpbmRvd09iamVjdC5kb2N1bWVudC5jbG9zZSgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIE9wZW5OZXdSZWNlaXB0KCkge1xyXG4gICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQgIT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgIHZhciBlbWlkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJlbXBsb3llZWlkXCIpO1xyXG4gICAgICAgICAgICBkb2N1bWVudC5sb2NhdGlvbiA9IHRoaXMuQmFzZUFwcFVybCArIFwiUmVjZWlwdFNlbGVjdC9cIiArIGVtaWQ7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgbmdPbkluaXQoKSB7XHJcbiAgICAgICAgaWYgKGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwibGFuZ1wiKSA9PSBcIlwiKSB7XHJcbiAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwibGFuZ1wiLCBcImVuXCIpO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLkxhbmcgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImxhbmdcIik7XHJcbiAgICAgICAgXHJcbiAgICAgIFxyXG4gICAgICAgIFxyXG4gICAgICAgXHJcbiAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuR2V0TGFuZ1Jlcyh0aGlzLkZvcm10eXBlLCB0aGlzLkxhbmcpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICB0aGlzLlJFUyA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgfSk7ICAgICAgICAgIFxyXG5cclxuICAgICAgIHRoaXMuX0NoYXJnZUNyZWRpdFNlcnZpY2UuQmluZFRlcm1EZXQodGhpcy5tb2RlbElucHV0Lm9UZXJtaW5hbE51bWJlcikuc3Vic2NyaWJlKHJlc3A9PiB7XHJcbiAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICB2YXIgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3ApO1xyXG4gICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgIH1cclxuICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0Lm91c2VybmFtZSA9IHJlc3BvbnNlLkRhdGEuaW5zdGl0dXRlTmFtZTtcclxuXHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgfSk7XHJcblxyXG4gICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkdldENvbXBsZXRlQ3VzdERldCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCkuc3Vic2NyaWJlKHJlc3A9PiB7XHJcbiAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICB2YXIgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3ApO1xyXG4gICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgIH1cclxuICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyTmFtZSA9IHJlc3BvbnNlLkRhdGEuZm5hbWUgKyBcIiBcIiArIHJlc3BvbnNlLkRhdGEubG5hbWU7XHJcbiAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5vQ2FyZE93bmVySWQgPSByZXNwb25zZS5EYXRhLkN1c3RvbWVyQ29kZTtcclxuICAgICAgICAgICB9XHJcbiAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICB9KTtcclxuXHJcbiAgICAgICB0aGlzLl9DaGFyZ2VDcmVkaXRTZXJ2aWNlLkJpbmRDdXJyZW5jeUxpc3QoKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICB2YXIgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3ApO1xyXG4gICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgIH1cclxuICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgdGhpcy5fQ3VycmVuY3kgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICBcclxuICAgICAgICAgICB9XHJcbiAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICB9KTtcclxuXHJcbiAgICAgICB0aGlzLl9DaGFyZ2VDcmVkaXRTZXJ2aWNlLkJpbmRDcmVkaXRUeXBlTGlzdCgpLnN1YnNjcmliZShyZXNwPT4ge1xyXG4gICAgICAgICAgIHZhciByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcCk7XHJcbiAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICB0aGlzLl9DcmVkaXRUeXBlcyA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgIHZhciByYmlkID0gXCIjXCIgKyB0aGlzLm1vZGVsSW5wdXQuQ3JlZGl0VHlwZS50b1N0cmluZygpO1xyXG4gICAgICAgICAgICAgICBqUXVlcnkocmJpZCkucHJvcChcImNoZWNrZWRcIiwgdHJ1ZSk7XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgfSk7XHJcblxyXG4gICAgICAgdGhpcy5fQ2hhcmdlQ3JlZGl0U2VydmljZS5CaW5kQ2hhcmdlVHlwZUxpc3QoKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICBcclxuICAgICAgICAgICB2YXIgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3ApO1xyXG4gICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgIH1cclxuICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgdGhpcy5fQ2hhcmdlVHlwZXMgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICB2YXIgc2F2ZXRleHQgPSBcIlwiO1xyXG4gICAgICAgICAgICAgICB2YXIgY2hyZ3R5cGUgPSB0aGlzLm1vZGVsSW5wdXQuQ2hhcmdlVHlwZTtcclxuICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5fQ2hhcmdlVHlwZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuVmFsdWUgPT0gY2hyZ3R5cGUpIHtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgc2F2ZXRleHQgPSB0aGlzLlRleHQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgdGhpcy5TQVZFX0JUTl9URVhUID0gc2F2ZXRleHQ7XHJcbiAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgfSk7XHJcbiAgICAgICBcclxuICAgICAgIHRoaXMuX0NoYXJnZUNyZWRpdFNlcnZpY2UuQmluZFllYXJzKCkuc3Vic2NyaWJlKHJlc3A9PiB7XHJcbiAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICB9XHJcbiAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgIHRoaXMuX1llYXJzID0gcmVzcG9uc2UuRGF0YTtcclxuXHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgfSk7XHJcblxyXG4gICAgICAgdGhpcy5fQ2hhcmdlQ3JlZGl0U2VydmljZS5CaW5kTW9udGhzKCkuc3Vic2NyaWJlKHJlc3A9PiB7XHJcbiAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICB9XHJcbiAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgIHRoaXMuX01udGhzID0gcmVzcG9uc2UuRGF0YTtcclxuXHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgfSk7XHJcbiAgICAgICB3aW5kb3cuc2V0VGltZW91dChmdW5jdGlvbiAoKSB7ICQoXCJbbmFtZT0nQ3JlZGl0VHlwZSddOmZpcnN0XCIpLmF0dHIoXCJjaGVja2VkXCIsIHRydWUpOyB9LDEwMDApO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==
