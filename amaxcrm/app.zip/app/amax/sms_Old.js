System.register(["angular2/core", "../comonComponents/basicComponents/select", "../services/AmaxService", "../amaxUtil"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, select_1, AmaxService_1, amaxUtil_1;
    var AmaxSmsComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (select_1_1) {
                select_1 = select_1_1;
            },
            function (AmaxService_1_1) {
                AmaxService_1 = AmaxService_1_1;
            },
            function (amaxUtil_1_1) {
                amaxUtil_1 = amaxUtil_1_1;
            }],
        execute: function() {
            AmaxSmsComponent = (function () {
                function AmaxSmsComponent(_amaxService) {
                    this._amaxService = _amaxService;
                    this.SelectedData = { Name: "", Value: "", Company: "", UserName: "" };
                }
                AmaxSmsComponent.prototype.doNothing = function () { };
                AmaxSmsComponent.prototype.openModel = function () {
                };
                AmaxSmsComponent.prototype.ngOnInit = function () {
                    var _this = this;
                    //debugger;
                    //this.RES = jQuery.parseJSON(localStorage.getItem("langresource"));
                    this._amaxService.GetDataFromServer({
                        SmsCompanyList: {
                            uqery: "\n                        Select\n                            usersms AS UserName,\n                            companysms AS Value\n                        from\n                            ApplicationInfo\n                    ",
                            parameters: {}
                        },
                        PhoneTypeList: {
                            uqery: "SELECT id AS Value, contentHeb+' ('+ contenteng +')' AS Label FROM PhoneTypes",
                            parameters: {}
                        }
                    }).subscribe(function (data) {
                        //debugger;
                        console.log(data);
                        var res = jQuery.parseJSON(data);
                        _this.SmsData = res.Data.data.SmsCompanyList;
                        _this.PhoneTypeListData = res.Data.data.PhoneTypeList;
                    }, function (error) { }, function () { });
                    this._amaxService.GetGeneralGroupTree().subscribe(function (data) {
                        var res = jQuery.parseJSON(data);
                        jQuery("#groupTree").kendoTreeView({
                            checkboxes: {
                                checkChildren: true
                            },
                            //check: this.onGroupSelect,
                            dataSource: res.Data.kendoTree
                        });
                    }, function (err) {
                    }, function () {
                    });
                };
                AmaxSmsComponent.prototype.getSelectedGroups = function () {
                    //debugger;
                    var _CheckedGroups = [];
                    amaxUtil_1.Kendo_utility.checkedNodeIds(jQuery("#groupTree").data("kendoTreeView").dataSource.view(), _CheckedGroups);
                    return _CheckedGroups;
                };
                AmaxSmsComponent.prototype.SendToSelectedGroups = function () {
                    //debugger;
                    //username:string,company:string,message:string,groups:Array<any>,phoneTypeId:number
                    var _selectedGroups = this.getSelectedGroups();
                    var status = "ok";
                    if (_selectedGroups.length == 0)
                        status = "No groups selected";
                    else if (!this.SelectedData.UserName || !this.SelectedData.Value)
                        status = "Please select a provider";
                    else if (!this.SelectedPhoneType.Value)
                        status = "Select Phone type";
                    else if (!this.message)
                        status = "Message can't be empty";
                    if (status != "ok") {
                        alert(status);
                        return;
                    }
                    ;
                    this._amaxService.SendSms(this.SelectedData.UserName, this.SelectedData.Value, this.message, this.getSelectedGroups(), this.SelectedPhoneType.Value).subscribe(function (data) {
                        debugger;
                        console.log(data);
                        var res = jQuery.parseJSON(data);
                        alert(res.Data.err);
                    }, function (err) {
                        console.log(err);
                    }, function () {
                        console.log("Sms send responce compleated!");
                    });
                };
                AmaxSmsComponent = __decorate([
                    core_1.Component({
                        name: 'amax-sms',
                        pipes: [amaxUtil_1.GroupFilterPipe, amaxUtil_1.GroupParenFilterPipe],
                        template: "\n        <div class=\"row\">\n            <div class=\"col-xs-12\">\n\n                <div class=\"row\">\n                    <div class=\"col-xs-12 col-sm-4 col-md-6\">\n                        <label>Select Sms Provider</label>\n                        <mx-select [data]=\"SmsData\" label=\"Value\" (onData)=\"SelectedData = $event\" cssclass=\"form-control\"></mx-select>\n                    </div>\n                    <div class=\"col-xs-12 col-sm-4 col-md-6\">\n                        <label>Select Phone Type</label>\n                        <mx-select [data]=\"PhoneTypeListData\" label=\"Label\" (onData)=\"SelectedPhoneType = $event\" cssclass=\"form-control\"></mx-select>\n                    </div>\n                    <div class=\"col-xs-12 col-sm-4 col-md-3\">\n                        <label>Company</label>\n                        <input class=\"form-control\" type=\"text\" readonly value=\"{{SelectedData.Value}}\"/>\n                    </div>\n                    <div class=\"col-xs-12 col-sm-4 col-md-3\">\n                        <label>Username</label>\n                        <input class=\"form-control\" type=\"text\" readonly value=\"{{SelectedData.UserName}}\"/>\n                    </div>\n                    <div class=\"col-sm-12\">\n                        <label>Select Group</label>\n                        <div class=\"k-content\" style=\"margin: 4px auto;width: 100%; padding: 4px 10px 20px;\">\n                            <div id=\"groupTree\" style=\"overflow: visible;\"> Loading... </div>\n                        </div>\n                    </div>\n                    <div class=\"col-xs-12\">\n                        <label>Message :</label>\n                        <textarea #msg (keyup)=\"message=msg.value\" class=\"form-control\" placeholder=\"Type your messages\"></textarea>\n                        <span>{{msg.value.length||0}} of 120</span>\n                        \n                    </div>\n                </div>\n            </div>\n            <div class=\"col-xs-12\">\n                <button class=\"btn btn-primary\" (click)=\"SendToSelectedGroups()\">Send Message</button>\n            </div>\n        </div>\n    ",
                        directives: [select_1.SelectInputComponent],
                        providers: [AmaxService_1.AmaxService]
                    }), 
                    __metadata('design:paramtypes', [AmaxService_1.AmaxService])
                ], AmaxSmsComponent);
                return AmaxSmsComponent;
            }());
            exports_1("AmaxSmsComponent", AmaxSmsComponent);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFtYXgvc21zX09sZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztZQXFEQTtnQkFtQkksMEJBQXFCLFlBQXdCO29CQUF4QixpQkFBWSxHQUFaLFlBQVksQ0FBWTtvQkFDekMsSUFBSSxDQUFDLFlBQVksR0FBRyxFQUFDLElBQUksRUFBQyxFQUFFLEVBQUUsS0FBSyxFQUFDLEVBQUUsRUFBRSxPQUFPLEVBQUMsRUFBRSxFQUFFLFFBQVEsRUFBQyxFQUFFLEVBQUMsQ0FBQztnQkFDckUsQ0FBQztnQkFURCxvQ0FBUyxHQUFULGNBQVksQ0FBQztnQkFHYixvQ0FBUyxHQUFUO2dCQUVBLENBQUM7Z0JBS0QsbUNBQVEsR0FBUjtvQkFBQSxpQkFvREM7b0JBbkRHLFdBQVc7b0JBQ1gsb0VBQW9FO29CQUNwRSxJQUFJLENBQUMsWUFBWSxDQUFDLGlCQUFpQixDQUFDO3dCQUNoQyxjQUFjLEVBQUM7NEJBQ1gsS0FBSyxFQUFDLHNPQU1EOzRCQUNMLFVBQVUsRUFBQyxFQUFFO3lCQUNoQjt3QkFDRCxhQUFhLEVBQUM7NEJBQ1YsS0FBSyxFQUFDLCtFQUErRTs0QkFDckYsVUFBVSxFQUFDLEVBQUU7eUJBQ2hCO3FCQUNKLENBQUMsQ0FBQyxTQUFTLENBQ1IsVUFBQyxJQUFJO3dCQUNELFdBQVc7d0JBQ1gsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFDbEIsSUFBSSxHQUFHLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFFakMsS0FBSSxDQUFDLE9BQU8sR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUM7d0JBQzVDLEtBQUksQ0FBQyxpQkFBaUIsR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUM7b0JBQ3pELENBQUMsRUFDRCxVQUFDLEtBQUssSUFBSSxDQUFDLEVBQ1gsY0FBSyxDQUFDLENBQ1QsQ0FBQztvQkFFRixJQUFJLENBQUMsWUFBWSxDQUFDLG1CQUFtQixFQUFFLENBQUMsU0FBUyxDQUU3QyxVQUFDLElBQUk7d0JBQ0QsSUFBSSxHQUFHLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFFakMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLGFBQWEsQ0FBQzs0QkFDL0IsVUFBVSxFQUFFO2dDQUNSLGFBQWEsRUFBRSxJQUFJOzZCQUN0Qjs0QkFDRCw0QkFBNEI7NEJBQzVCLFVBQVUsRUFBRSxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVM7eUJBQ2pDLENBQUMsQ0FBQztvQkFDUCxDQUFDLEVBQ0QsVUFBQyxHQUFHO29CQUVKLENBQUMsRUFDRDtvQkFFQSxDQUFDLENBRUosQ0FBQztnQkFDTixDQUFDO2dCQUdELDRDQUFpQixHQUFqQjtvQkFDSSxXQUFXO29CQUNYLElBQUksY0FBYyxHQUFHLEVBQUUsQ0FBQztvQkFDeEIsd0JBQWEsQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLEVBQUMsY0FBYyxDQUFDLENBQUM7b0JBQzFHLE1BQU0sQ0FBQyxjQUFjLENBQUM7Z0JBQzFCLENBQUM7Z0JBRUQsK0NBQW9CLEdBQXBCO29CQUNJLFdBQVc7b0JBQ1gsb0ZBQW9GO29CQUNwRixJQUFJLGVBQWUsR0FBRyxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztvQkFDL0MsSUFBSSxNQUFNLEdBQUcsSUFBSSxDQUFDO29CQUVsQixFQUFFLENBQUEsQ0FBQyxlQUFlLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQzt3QkFBQyxNQUFNLEdBQUcsb0JBQW9CLENBQUM7b0JBQzlELElBQUksQ0FBQyxFQUFFLENBQUEsQ0FBQyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxJQUFHLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUM7d0JBQUMsTUFBTSxHQUFDLDBCQUEwQixDQUFDO29CQUNsRyxJQUFJLENBQUMsRUFBRSxDQUFBLENBQUMsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsS0FBSyxDQUFDO3dCQUFDLE1BQU0sR0FBQyxtQkFBbUIsQ0FBQztvQkFDbEUsSUFBSSxDQUFDLEVBQUUsQ0FBQSxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQzt3QkFBQyxNQUFNLEdBQUcsd0JBQXdCLENBQUM7b0JBRXpELEVBQUUsQ0FBQSxDQUFDLE1BQU0sSUFBRSxJQUFJLENBQUMsQ0FBQSxDQUFDO3dCQUNiLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQzt3QkFDZCxNQUFNLENBQUM7b0JBQ1gsQ0FBQztvQkFBQSxDQUFDO29CQUVGLElBQUksQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUNyQixJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsRUFDMUIsSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLEVBQ3ZCLElBQUksQ0FBQyxPQUFPLEVBQ1osSUFBSSxDQUFDLGlCQUFpQixFQUFFLEVBQ3hCLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxLQUFLLENBQy9CLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDWixRQUFRLENBQUM7d0JBQ0wsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQTt3QkFDckIsSUFBSSxHQUFHLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFDakMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7b0JBR3BCLENBQUMsRUFDQSxVQUFBLEdBQUc7d0JBQ0EsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQTtvQkFDcEIsQ0FBQyxFQUFDO3dCQUNFLE9BQU8sQ0FBQyxHQUFHLENBQUMsK0JBQStCLENBQUMsQ0FBQztvQkFDakQsQ0FBQyxDQUNKLENBQUE7Z0JBQ0wsQ0FBQztnQkF0S0w7b0JBQUMsZ0JBQVMsQ0FBQzt3QkFDUCxJQUFJLEVBQUMsVUFBVTt3QkFDZixLQUFLLEVBQUMsQ0FBQywwQkFBZSxFQUFFLCtCQUFvQixDQUFDO3dCQUM3QyxRQUFRLEVBQUMscXBFQXVDUjt3QkFDRCxVQUFVLEVBQUMsQ0FBQyw2QkFBb0IsQ0FBQzt3QkFDakMsU0FBUyxFQUFDLENBQUMseUJBQVcsQ0FBQztxQkFDMUIsQ0FBQzs7b0NBQUE7Z0JBMEhGLHVCQUFDO1lBQUQsQ0F6SEEsQUF5SEMsSUFBQTtZQXpIRCwrQ0F5SEMsQ0FBQSIsImZpbGUiOiJhbWF4L3Ntc19PbGQuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge0NvbXBvbmVudCwgT25Jbml0fSBmcm9tIFwiYW5ndWxhcjIvY29yZVwiO1xyXG5pbXBvcnQgIHtTZWxlY3RJbnB1dENvbXBvbmVudH0gZnJvbSBcIi4uL2NvbW9uQ29tcG9uZW50cy9iYXNpY0NvbXBvbmVudHMvc2VsZWN0XCJcclxuaW1wb3J0IHtBbWF4U2VydmljZX0gZnJvbSBcIi4uL3NlcnZpY2VzL0FtYXhTZXJ2aWNlXCI7XHJcbmltcG9ydCB7R3JvdXBGaWx0ZXJQaXBlLCBHcm91cFBhcmVuRmlsdGVyUGlwZSwgS2VuZG9fdXRpbGl0eX0gZnJvbSBcIi4uL2FtYXhVdGlsXCI7XHJcblxyXG5kZWNsYXJlIHZhciBqUXVlcnk7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIG5hbWU6J2FtYXgtc21zJyxcclxuICAgIHBpcGVzOltHcm91cEZpbHRlclBpcGUsIEdyb3VwUGFyZW5GaWx0ZXJQaXBlXSxcclxuICAgIHRlbXBsYXRlOmBcclxuICAgICAgICA8ZGl2IGNsYXNzPVwicm93XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wteHMtMTJcIj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwicm93XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbC14cy0xMiBjb2wtc20tNCBjb2wtbWQtNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWw+U2VsZWN0IFNtcyBQcm92aWRlcjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxteC1zZWxlY3QgW2RhdGFdPVwiU21zRGF0YVwiIGxhYmVsPVwiVmFsdWVcIiAob25EYXRhKT1cIlNlbGVjdGVkRGF0YSA9ICRldmVudFwiIGNzc2NsYXNzPVwiZm9ybS1jb250cm9sXCI+PC9teC1zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbC14cy0xMiBjb2wtc20tNCBjb2wtbWQtNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWw+U2VsZWN0IFBob25lIFR5cGU8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bXgtc2VsZWN0IFtkYXRhXT1cIlBob25lVHlwZUxpc3REYXRhXCIgbGFiZWw9XCJMYWJlbFwiIChvbkRhdGEpPVwiU2VsZWN0ZWRQaG9uZVR5cGUgPSAkZXZlbnRcIiBjc3NjbGFzcz1cImZvcm0tY29udHJvbFwiPjwvbXgtc2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wteHMtMTIgY29sLXNtLTQgY29sLW1kLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsPkNvbXBhbnk8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgY2xhc3M9XCJmb3JtLWNvbnRyb2xcIiB0eXBlPVwidGV4dFwiIHJlYWRvbmx5IHZhbHVlPVwie3tTZWxlY3RlZERhdGEuVmFsdWV9fVwiLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sLXhzLTEyIGNvbC1zbS00IGNvbC1tZC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbD5Vc2VybmFtZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCBjbGFzcz1cImZvcm0tY29udHJvbFwiIHR5cGU9XCJ0ZXh0XCIgcmVhZG9ubHkgdmFsdWU9XCJ7e1NlbGVjdGVkRGF0YS5Vc2VyTmFtZX19XCIvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtc20tMTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsPlNlbGVjdCBHcm91cDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJrLWNvbnRlbnRcIiBzdHlsZT1cIm1hcmdpbjogNHB4IGF1dG87d2lkdGg6IDEwMCU7IHBhZGRpbmc6IDRweCAxMHB4IDIwcHg7XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGlkPVwiZ3JvdXBUcmVlXCIgc3R5bGU9XCJvdmVyZmxvdzogdmlzaWJsZTtcIj4gTG9hZGluZy4uLiA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbC14cy0xMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWw+TWVzc2FnZSA6PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRleHRhcmVhICNtc2cgKGtleXVwKT1cIm1lc3NhZ2U9bXNnLnZhbHVlXCIgY2xhc3M9XCJmb3JtLWNvbnRyb2xcIiBwbGFjZWhvbGRlcj1cIlR5cGUgeW91ciBtZXNzYWdlc1wiPjwvdGV4dGFyZWE+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnt7bXNnLnZhbHVlLmxlbmd0aHx8MH19IG9mIDEyMDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wteHMtMTJcIj5cclxuICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3M9XCJidG4gYnRuLXByaW1hcnlcIiAoY2xpY2spPVwiU2VuZFRvU2VsZWN0ZWRHcm91cHMoKVwiPlNlbmQgTWVzc2FnZTwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgIGAsXHJcbiAgICBkaXJlY3RpdmVzOltTZWxlY3RJbnB1dENvbXBvbmVudF0sXHJcbiAgICBwcm92aWRlcnM6W0FtYXhTZXJ2aWNlXVxyXG59KVxyXG5leHBvcnQgY2xhc3MgQW1heFNtc0NvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdHtcclxuICAgIC8vUkVTOiBPYmplY3Q7XHJcbiAgICBTbXNEYXRhOkFycmF5PGFueT47XHJcbiAgICBTZWxlY3RlZERhdGE6YW55O1xyXG5cclxuICAgIFBob25lVHlwZUxpc3REYXRhOkFycmF5PGFueT47XHJcbiAgICBTZWxlY3RlZFBob25lVHlwZTphbnk7XHJcbiAgICB1c2VyTmFtZTpzdHJpbmc7XHJcbiAgICBtZXNzYWdlOnN0cmluZztcclxuXHJcblxyXG5cclxuICAgIGRvTm90aGluZygpe31cclxuXHJcblxyXG4gICAgb3Blbk1vZGVsKCl7XHJcbiAgICAgICAgXHJcbiAgICB9XHJcblxyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSAgX2FtYXhTZXJ2aWNlOkFtYXhTZXJ2aWNlKXtcclxuICAgICAgICB0aGlzLlNlbGVjdGVkRGF0YSA9IHtOYW1lOlwiXCIsIFZhbHVlOlwiXCIsIENvbXBhbnk6XCJcIiwgVXNlck5hbWU6XCJcIn07XHJcbiAgICB9XHJcbiAgICBuZ09uSW5pdCgpIHtcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgIC8vdGhpcy5SRVMgPSBqUXVlcnkucGFyc2VKU09OKGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwibGFuZ3Jlc291cmNlXCIpKTtcclxuICAgICAgICB0aGlzLl9hbWF4U2VydmljZS5HZXREYXRhRnJvbVNlcnZlcih7XHJcbiAgICAgICAgICAgIFNtc0NvbXBhbnlMaXN0OntcclxuICAgICAgICAgICAgICAgIHVxZXJ5OmBcclxuICAgICAgICAgICAgICAgICAgICAgICAgU2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1c2Vyc21zIEFTIFVzZXJOYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29tcGFueXNtcyBBUyBWYWx1ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmcm9tXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBBcHBsaWNhdGlvbkluZm9cclxuICAgICAgICAgICAgICAgICAgICBgLFxyXG4gICAgICAgICAgICAgICAgcGFyYW1ldGVyczp7fVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBQaG9uZVR5cGVMaXN0OntcclxuICAgICAgICAgICAgICAgIHVxZXJ5OlwiU0VMRUNUIGlkIEFTIFZhbHVlLCBjb250ZW50SGViKycgKCcrIGNvbnRlbnRlbmcgKycpJyBBUyBMYWJlbCBGUk9NIFBob25lVHlwZXNcIixcclxuICAgICAgICAgICAgICAgIHBhcmFtZXRlcnM6e31cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pLnN1YnNjcmliZShcclxuICAgICAgICAgICAgKGRhdGEpID0+IHtcclxuICAgICAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhkYXRhKTtcclxuICAgICAgICAgICAgICAgIHZhciByZXMgPSBqUXVlcnkucGFyc2VKU09OKGRhdGEpO1xyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICB0aGlzLlNtc0RhdGEgPSByZXMuRGF0YS5kYXRhLlNtc0NvbXBhbnlMaXN0O1xyXG4gICAgICAgICAgICAgICAgdGhpcy5QaG9uZVR5cGVMaXN0RGF0YSA9IHJlcy5EYXRhLmRhdGEuUGhvbmVUeXBlTGlzdDtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgKGVycm9yKT0+e30sXHJcbiAgICAgICAgICAgICgpPT57fVxyXG4gICAgICAgICk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5fYW1heFNlcnZpY2UuR2V0R2VuZXJhbEdyb3VwVHJlZSgpLnN1YnNjcmliZShcclxuICAgICAgICBcclxuICAgICAgICAgICAgKGRhdGEpID0+IHtcclxuICAgICAgICAgICAgICAgIHZhciByZXMgPSBqUXVlcnkucGFyc2VKU09OKGRhdGEpO1xyXG5cclxuICAgICAgICAgICAgICAgIGpRdWVyeShcIiNncm91cFRyZWVcIikua2VuZG9UcmVlVmlldyh7XHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tib3hlczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjaGVja0NoaWxkcmVuOiB0cnVlXHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAvL2NoZWNrOiB0aGlzLm9uR3JvdXBTZWxlY3QsXHJcbiAgICAgICAgICAgICAgICAgICAgZGF0YVNvdXJjZTogcmVzLkRhdGEua2VuZG9UcmVlXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgKGVycikgPT4ge1xyXG5cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgKCkgPT4ge1xyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBcclxuICAgICAgICApO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICBnZXRTZWxlY3RlZEdyb3VwcygpOiBBcnJheTxudW1iZXI+e1xyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgdmFyIF9DaGVja2VkR3JvdXBzID0gW107XHJcbiAgICAgICAgS2VuZG9fdXRpbGl0eS5jaGVja2VkTm9kZUlkcyhqUXVlcnkoXCIjZ3JvdXBUcmVlXCIpLmRhdGEoXCJrZW5kb1RyZWVWaWV3XCIpLmRhdGFTb3VyY2UudmlldygpLF9DaGVja2VkR3JvdXBzKTtcclxuICAgICAgICByZXR1cm4gX0NoZWNrZWRHcm91cHM7XHJcbiAgICB9XHJcblxyXG4gICAgU2VuZFRvU2VsZWN0ZWRHcm91cHMoKSB7XHJcbiAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAvL3VzZXJuYW1lOnN0cmluZyxjb21wYW55OnN0cmluZyxtZXNzYWdlOnN0cmluZyxncm91cHM6QXJyYXk8YW55PixwaG9uZVR5cGVJZDpudW1iZXJcclxuICAgICAgICB2YXIgX3NlbGVjdGVkR3JvdXBzID0gdGhpcy5nZXRTZWxlY3RlZEdyb3VwcygpO1xyXG4gICAgICAgIHZhciBzdGF0dXMgPSBcIm9rXCI7XHJcblxyXG4gICAgICAgIGlmKF9zZWxlY3RlZEdyb3Vwcy5sZW5ndGggPT0gMCkgc3RhdHVzID0gXCJObyBncm91cHMgc2VsZWN0ZWRcIjtcclxuICAgICAgICBlbHNlIGlmKCF0aGlzLlNlbGVjdGVkRGF0YS5Vc2VyTmFtZSB8fCF0aGlzLlNlbGVjdGVkRGF0YS5WYWx1ZSkgc3RhdHVzPVwiUGxlYXNlIHNlbGVjdCBhIHByb3ZpZGVyXCI7XHJcbiAgICAgICAgZWxzZSBpZighdGhpcy5TZWxlY3RlZFBob25lVHlwZS5WYWx1ZSkgc3RhdHVzPVwiU2VsZWN0IFBob25lIHR5cGVcIjtcclxuICAgICAgICBlbHNlIGlmKCF0aGlzLm1lc3NhZ2UpIHN0YXR1cyA9IFwiTWVzc2FnZSBjYW4ndCBiZSBlbXB0eVwiO1xyXG5cclxuICAgICAgICBpZihzdGF0dXMhPVwib2tcIil7XHJcbiAgICAgICAgICAgIGFsZXJ0KHN0YXR1cyk7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICB0aGlzLl9hbWF4U2VydmljZS5TZW5kU21zKFxyXG4gICAgICAgICAgICB0aGlzLlNlbGVjdGVkRGF0YS5Vc2VyTmFtZSxcclxuICAgICAgICAgICAgdGhpcy5TZWxlY3RlZERhdGEuVmFsdWUsXHJcbiAgICAgICAgICAgIHRoaXMubWVzc2FnZSxcclxuICAgICAgICAgICAgdGhpcy5nZXRTZWxlY3RlZEdyb3VwcygpLFxyXG4gICAgICAgICAgICB0aGlzLlNlbGVjdGVkUGhvbmVUeXBlLlZhbHVlXHJcbiAgICAgICAgKS5zdWJzY3JpYmUoZGF0YT0+IHtcclxuICAgICAgICAgICAgZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhkYXRhKVxyXG4gICAgICAgICAgICB2YXIgcmVzID0galF1ZXJ5LnBhcnNlSlNPTihkYXRhKTtcclxuICAgICAgICAgICAgYWxlcnQocmVzLkRhdGEuZXJyKTtcclxuXHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAsZXJyPT57XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnIpXHJcbiAgICAgICAgICAgIH0sKCk9PntcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiU21zIHNlbmQgcmVzcG9uY2UgY29tcGxlYXRlZCFcIik7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICApXHJcbiAgICB9XHJcbn0iXX0=
