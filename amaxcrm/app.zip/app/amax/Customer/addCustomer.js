System.register(['angular2/common', "../../services/ResourceService", "angular2/router", "angular2/core", "../../services/CustomerService", "../../amaxUtil", '../../autocomplete/autocomplete-container', '../../autocomplete/autocomplete.component', '../../comonComponents/basicComponents'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var common_1, ResourceService_1, router_1, core_1, CustomerService_1, amaxUtil_1, autocomplete_container_1, autocomplete_component_1, basicComponents_1;
    var AUTOCOMPLETE_DIRECTIVES, AmaxCustomers;
    return {
        setters:[
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (ResourceService_1_1) {
                ResourceService_1 = ResourceService_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (CustomerService_1_1) {
                CustomerService_1 = CustomerService_1_1;
            },
            function (amaxUtil_1_1) {
                amaxUtil_1 = amaxUtil_1_1;
            },
            function (autocomplete_container_1_1) {
                autocomplete_container_1 = autocomplete_container_1_1;
            },
            function (autocomplete_component_1_1) {
                autocomplete_component_1 = autocomplete_component_1_1;
            },
            function (basicComponents_1_1) {
                basicComponents_1 = basicComponents_1_1;
            }],
        execute: function() {
            exports_1("AUTOCOMPLETE_DIRECTIVES", AUTOCOMPLETE_DIRECTIVES = [autocomplete_component_1.Autocomplete, autocomplete_container_1.AutocompleteContainer]);
            AmaxCustomers = (function () {
                function AmaxCustomers(_resourceService, _customerService, _routeParams) {
                    this._resourceService = _resourceService;
                    this._customerService = _customerService;
                    this._routeParams = _routeParams;
                    this.baseUrl = "";
                    this.ImageUrl = "";
                    this.modelInput = {};
                    this.TempmodelInput = {};
                    this.custSearchData = [];
                    this.RES = {};
                    this.SelectedPhType = {};
                    this.tempstreetmsg = "";
                    this.Formtype = "CUSTOMER_MASTER";
                    this.Lang = "";
                    //modelInput.lname= "";
                    this.ShowMore = false;
                    this.IsRecordEditMode = false;
                    this.ShowMoreText = "More";
                    this.CustFileImage = "DefaultUser.jpg";
                    this.ShowLoader = false;
                    this.ShowMsg = false;
                    this.ShowGroups = true;
                    this.GroupText = "Show Groups";
                    this.Msg = "";
                    this.MsgClass = "text-primary";
                    this.Isbtndisable = "";
                    this.IsFileAsSaveBtn = "";
                    this.IsFileAsCancelBtn = "";
                    this.languageArray = [];
                    this.Address = {};
                    this.PhoneModel = {};
                    this.EmailModel = {};
                    this.IsShowAll = false;
                    this.CustList = {};
                    this.SAVE_BTN_TEXT = "";
                    this.BTN_PHADD = "";
                    this.EditPhoneData = {};
                    this.EditAddressData = {};
                    this.EditEmailData = {};
                    this.IsFileAstxtShow = false;
                    this.FILEAS_BTN_TEXT = "";
                    this.cssFileAsBtn = "";
                    this.IsCancel = false;
                    this.SearchVal = "";
                    this.EnterCount = 0;
                    this.CustIdText = "";
                    this.BaseAppUrl = "";
                    this.PhIndex = 0;
                    this.KendoRTLCSS = "";
                    this.CHANGEDIR = "";
                    this.ChangeDialog = "";
                    this.IsPopUp = true;
                    //IsFileAsSave: boolean = false;
                    //Email: string = "";
                    //CustomerEmail: Object = {};
                    //modelInput.CustomerEmails = [];
                    this._CustTypes = [];
                    this._Sources = [];
                    this._Employees = [];
                    this._Suffixes = [];
                    this._PhoneTypes = [];
                    this._AddressTypes = [];
                    this._Groups = [];
                    this._Countries = [];
                    this._States = [];
                    this._Cities = [];
                    this._CustTitles = [];
                    this.selectedCar = '';
                    this.asyncSelectedCar = '';
                    this.autocompleteLoading = false;
                    this.autocompleteNoResults = false;
                    this.autocompleteSelect = false;
                    this._previousasyncSelectedCar = '';
                    this.modelInput.BirthDate = "";
                    this.modelInput.CustomerAddresses = [];
                    this.modelInput.CustomerPhones = [];
                    this.modelInput.CustomerEmails = [];
                    this.modelInput.CustomerGroups = [];
                    this.Address.CountryCode = "";
                    this.Address.StateId = "";
                    this.modelInput.employeeid = "";
                    this.modelInput.CustomerType = "";
                    this.modelInput.CameFromCustomer = "";
                    this.modelInput.Safixid = "";
                    //this.modelInput.ImageFileName = "DefaultUser.jpg";
                    this.modelInput.Gender = "0";
                    this.PhoneModel.PhoneTypeId = "";
                    this.RES.CUSTOMER_MASTER = {};
                    this.IsShowAll = false;
                    this.SAVE_BTN_TEXT = this.RES.CUSTOMER_MASTER.APP_BTN_SAVE;
                    this.BTN_PHADD = this.RES.CUSTOMER_MASTER.APP_BTN_PHADD;
                    this.ADD_NEW_CUST_TEXT = this.RES.CUSTOMER_MASTER.APP_LBL_NEW_CUST;
                    this.modelInput.CustomerEmails = [{ Email: "", EmailName: "", Newslettere: true, publish: 1, NewsOrder: "News1", EPublishOrder: "EPub1" }];
                    this.modelInput.CustomerPhones = [{ PhoneTypeId: "", Prefix: "", Area: "", Phone: "", IsSms: 1, Comments: "", IsShowRemarks: false, phpublish: 1, SMSOrder: "SMS1", PublishOrder: "Pub1" }];
                    // debugger;
                    var empid = localStorage.getItem("employeeid");
                    var ccode = this._resourceService.getCookie(empid + "ccode");
                    if (ccode.length > 0)
                        ccode = ccode.substring(1, ccode.length);
                    this.modelInput.CustomerAddresses = [{
                            Street: "", Street2: "", CityName: "", Zip: "", CountryCode: ccode, StateId: "", AddressTypeId: "",
                            ForDelivery: true, MainAddress: true, MainOrder: "MainAddr1", DelvryOrder: "Delvry1"
                        }];
                    var custtype = this._resourceService.getCookie(empid + "cust");
                    if (custtype.length > 0) {
                        custtype = custtype.substring(1, custtype.length);
                    }
                    this.modelInput.CustomerType = custtype;
                    var emp = this._resourceService.getCookie(empid + "emp");
                    if (emp.length > 0)
                        emp = emp.substring(1, emp.length);
                    this.modelInput.employeeid = emp;
                    var source = this._resourceService.getCookie(empid + "src");
                    if (source.length > 0)
                        source = source.substring(1, source.length);
                    else {
                    }
                    this.modelInput.CameFromCustomer = source;
                    this.CSSTEXT = "mdi-content-add";
                    this.cssFileAsBtn = "mdi-content-create";
                    this.IsFileAstxtShow = false;
                    clearTimeout(this.StopTimeOut);
                    this.modelInput.CustomerId = _routeParams.params.Id;
                    this.BaseAppUrl = _resourceService.AppUrl;
                    this.baseUrl = _resourceService.baseUrl;
                    this.ImageUrl = _resourceService.ImageUrl;
                    this.TempmodelInput = this.modelInput;
                    //alert(this._resourceService.getCookie(empid + "cust"));
                    //this.ShowMoreText = "More";
                }
                AmaxCustomers.prototype.getCurrentContext = function () {
                    return this;
                };
                AmaxCustomers.prototype.dateSelectionChange = function (evt) {
                    console.log(evt);
                    this.modelInput.BirthDate = evt;
                    // alert(this.modelInput.BirthDate);
                    //this.validateLogin();
                };
                AmaxCustomers.prototype.getAsyncData = function (context) {
                    var _this = this;
                    var SrchVal = context.asyncSelectedCar;
                    // if (SrchVal != undefined && SrchVal != null && SrchVal != "") {
                    // debugger;
                    if (this._previousasyncSelectedCar == context.asyncSelectedCar) {
                        //clearTimeout(this.StopTimeOut);
                        return this._cachedResult;
                    }
                    else {
                        //alert(this._previousasyncSelectedCar + " | " + context.asyncSelectedCar);
                        if (context.asyncSelectedCar != "") {
                            this._previousasyncSelectedCar = context.asyncSelectedCar;
                            //  this.StopTimeOut = setTimeout(() => {
                            //    alert(SrchVal);
                            this._customerService.GetCompleteSearch(SrchVal).subscribe(function (response) {
                                // debugger;
                                response = jQuery.parseJSON(response);
                                if (response.IsError == true) {
                                    //alert(response.ErrMsg);
                                    bootbox.alert({ message: response.ErrMsg,
                                        className: _this.ChangeDialog,
                                        buttons: {
                                            ok: {
                                                //label: 'Ok',
                                                className: _this.CHANGEDIR
                                            }
                                        }
                                    });
                                }
                                else {
                                    context.carsExample1 = response.Data;
                                }
                            }, function (error) {
                                console.log(error);
                            }, function () {
                                console.log("CallCompleted");
                            });
                            // }, 500);
                            this._cachedResult = context.carsExample1;
                        }
                        else {
                            this._cachedResult = [];
                        }
                        return this._cachedResult;
                    }
                };
                AmaxCustomers.prototype.changeAutocompleteLoading = function (e) {
                    this.autocompleteLoading = e;
                };
                AmaxCustomers.prototype.changeAutocompleteNoResults = function (e) {
                    this.autocompleteSelect = false;
                    this.autocompleteNoResults = e;
                };
                AmaxCustomers.prototype.autocompleteOnSelect = function (e) {
                    var _this = this;
                    this.autocompleteSelect = true;
                    console.log("Selected value: " + e.item);
                    var CompData = e.item.split('|');
                    // debugger;
                    if (e.item != undefined && e.item != "" && e.item != null) {
                        //alert(CompData[0]);
                        this._customerService.GetCompleteCustDet(CompData[0].trim()).subscribe(function (response) {
                            //debugger;
                            response = jQuery.parseJSON(response);
                            if (response.IsError == true) {
                                //alert(response.ErrMsg);
                                bootbox.alert({ message: response.ErrMsg,
                                    className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                            else {
                                _this.modelInput = response.Data;
                                // alert(this.modelInput.BirthDate);
                                _this.SAVE_BTN_TEXT = _this.RES.CUSTOMER_MASTER.APP_BTN_UPDATE;
                                _this.ADD_NEW_CUST_TEXT = _this.RES.CUSTOMER_MASTER.APP_LBL_NEW_CUST;
                                _this.CSSTEXT = "mdi-content-create";
                                if (_this.modelInput.CustomerEmails.length == 0) {
                                    _this.modelInput.CustomerEmails = [{ Email: "", EmailName: _this.modelInput.FileAs, Newslettere: false }];
                                }
                                else {
                                    jQuery.each(_this.modelInput.CustomerEmails, function () {
                                        if (this.Newslettere == "1") {
                                            this.Newslettere = false;
                                        }
                                        else {
                                            this.Newslettere = true;
                                        }
                                    });
                                }
                                if (_this.modelInput.CustomerPhones.length == 0) {
                                    var phid = "";
                                    jQuery.each(_this._PhoneTypes, function () {
                                        if (this.Text == "CellPhone") {
                                            phid = this.Value;
                                            return false;
                                        }
                                    });
                                    _this.modelInput.CustomerPhones = [{ PhoneTypeId: phid, Prefix: "", Area: "", Phone: "", IsSms: 0, Comments: "", phpublish: 0 }];
                                }
                                if (_this.modelInput.CustomerAddresses.length == 0) {
                                    var empid = localStorage.getItem("employeeid");
                                    var ccode = _this._resourceService.getCookie(empid + "ccode");
                                    if (ccode.length > 0)
                                        ccode = ccode.substring(1, ccode.length);
                                    var adid = "";
                                    var comptext = "Home";
                                    if (_this.modelInput.Company != "" && _this.modelInput.Company != undefined && _this.modelInput.Company != null) {
                                        comptext = "Work";
                                    }
                                    jQuery.each(_this._AddressTypes, function () {
                                        if (this.Text == comptext) {
                                            adid = this.Value;
                                            return false;
                                        }
                                    });
                                    _this.modelInput.CustomerAddresses = [{ Street: "", Street2: "", CityName: "", Zip: "", CountryCode: ccode, StateId: "", AddressTypeId: adid, ForDelivery: false, MainAddress: false }];
                                }
                                _this.CustIdText = "( " + _this.modelInput.CustomerId + " )";
                                _this.IsFileAstxtShow = false;
                                //this.IsCancel = true;
                                //this.HideShowFileAstxt();
                                _this.CancelFileAstxt();
                                _this.IsShowAll = true;
                                //this.bindGroup();
                                //alert(this.RES);
                                _this.bindGroupTree(true);
                            }
                        }, function (error) {
                            console.log(error);
                        }, function () {
                            console.log("CallCompleted");
                        });
                    }
                };
                AmaxCustomers.prototype.OpenProfile = function () {
                    if (this.modelInput != undefined && this.modelInput.CustomerId != undefined && this.modelInput.CustomerId >= 0) {
                        var custId = this.modelInput.CustomerId;
                        if (custId != -1) {
                            document.location = this.BaseAppUrl + "Customer/Profile/" + custId;
                        }
                    }
                };
                AmaxCustomers.prototype.OpenNewReceipt = function () {
                    if (this.modelInput != undefined && this.modelInput.CustomerId != undefined && this.modelInput.CustomerId >= 0) {
                        var custId = this.modelInput.CustomerId;
                        if (custId != -1) {
                            var emid = localStorage.getItem("employeeid");
                            document.location = this.BaseAppUrl + "ReceiptSelect/" + emid + "/" + custId;
                        }
                    }
                };
                AmaxCustomers.prototype.OpenChargeCreditPage = function () {
                    var _this = this;
                    this.Isbtndisable = "disabled";
                    this._customerService.CheckIsOpenCharge().subscribe(function (response) {
                        console.log(response);
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    } } });
                        }
                        else {
                            //debugger;
                            if (response.Data != undefined && response.Data != null && response.Data.length == 1) {
                                var custId = -1;
                                if (_this.TempmodelInput != undefined && _this.TempmodelInput.CustomerId != undefined && _this.TempmodelInput.CustomerId >= 0) {
                                    custId = _this.TempmodelInput.CustomerId;
                                }
                                if (_this.modelInput != undefined && _this.modelInput.CustomerId != undefined && _this.modelInput.CustomerId >= 0) {
                                    custId = _this.modelInput.CustomerId;
                                }
                                if (custId != -1) {
                                    document.location = _this.BaseAppUrl + "ChargeCredit/" + custId + "/" + response.Data[0].Value;
                                }
                                else {
                                    bootbox.alert({
                                        message: 'Please save new or load previous customer and then click on charge credit button',
                                        className: _this.ChangeDialog,
                                        buttons: {
                                            ok: {
                                                //label: 'Ok',
                                                className: _this.CHANGEDIR
                                            }
                                        }
                                    });
                                }
                            }
                            else if (response.Data != undefined && response.Data != null && response.Data.length > 1) {
                                //debugger;
                                var custId = -1;
                                if (_this.TempmodelInput != undefined && _this.TempmodelInput.CustomerId != undefined && _this.TempmodelInput.CustomerId >= 0) {
                                    custId = _this.TempmodelInput.CustomerId;
                                }
                                if (_this.modelInput != undefined && _this.modelInput.CustomerId != undefined && _this.modelInput.CustomerId >= 0) {
                                    custId = _this.modelInput.CustomerId;
                                }
                                if (custId != -1) {
                                    document.location = _this.BaseAppUrl + "Terminals/Show/" + custId;
                                }
                                else {
                                    bootbox.alert({
                                        message: 'Please save new or load previous customer and then click on charge credit button',
                                        className: _this.ChangeDialog,
                                        buttons: {
                                            ok: {
                                                //label: 'Ok',
                                                className: _this.CHANGEDIR
                                            }
                                        }
                                    });
                                }
                            }
                            else {
                                bootbox.alert({
                                    message: _this.RES.CUSTOMER_MASTER.APP_MSG_CHARGECREDIT,
                                    className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        } }
                                });
                            }
                        }
                        _this.ShowMsg = true;
                        _this.Msg = response.ErrMsg;
                    }, function (error) { return console.log(error); }, function () { return console.log("Save Call Compleated"); });
                    this.Isbtndisable = "";
                };
                AmaxCustomers.prototype.StopTimer = function () {
                    bootbox.alert({
                        message: 'From Stop Timer' + this.StopTimeOut, className: this.ChangeDialog,
                        buttons: {
                            ok: {
                                //label: 'Ok',
                                className: this.CHANGEDIR
                            }
                        }
                    });
                    clearTimeout(this.StopTimeOut);
                };
                AmaxCustomers.prototype.SetdefaultPage = function () {
                    var _this = this;
                    document.location = this.BaseAppUrl + "Customer/Add/-1";
                    this.IsFileAstxtShow = true;
                    this.IsCancel = true;
                    var empid = localStorage.getItem("employeeid");
                    this.asyncSelectedCar = "";
                    this.modelInput = {};
                    this.CustFileImage = "DefaultUser.jpg";
                    this.modelInput.BirthDate = "";
                    this.modelInput.CustomerId = -1;
                    this.CustIdText = "";
                    this.HideShowFileAstxt();
                    var custtype = this._resourceService.getCookie(empid + "cust");
                    if (custtype.length > 0)
                        custtype = custtype.substring(1, custtype.length);
                    this.modelInput.CustomerType = custtype;
                    var emp = this._resourceService.getCookie(empid + "emp");
                    if (emp.length > 0)
                        emp = emp.substring(1, emp.length);
                    this.modelInput.employeeid = emp;
                    var source = this._resourceService.getCookie(empid + "src");
                    if (source.length > 0)
                        source = source.substring(1, source.length);
                    this.modelInput.CameFromCustomer = source;
                    this.ShowMore = false;
                    //this.ShowMoreText = "More"; 
                    this.ShowMoreText = this.RES.CUSTOMER_MASTER.APP_LNK_LBL_MORE;
                    this.SAVE_BTN_TEXT = this.RES.CUSTOMER_MASTER.APP_BTN_SAVE;
                    this.CSSTEXT = "mdi-content-add";
                    this.ADD_NEW_CUST_TEXT = this.RES.CUSTOMER_MASTER.APP_LBL_NEW_CUST;
                    this.ShowGroups = true;
                    this.showhideGroups();
                    //this.GroupText = this.RES.CUSTOMER_MASTER.APP_LBL_SHOWGROUPS;
                    var phid = "";
                    var SMS = 0;
                    var publish = 0;
                    var epublish = 0;
                    jQuery.each(this._PhoneTypes, function () {
                        if (this.Text == "CellPhone") {
                            phid = this.Value;
                            SMS = 1;
                            publish = 1;
                            epublish = 1;
                            return false;
                        }
                    });
                    this.modelInput.CustomerPhones = [{ PhoneTypeId: phid, Prefix: "", Area: "", Phone: "", IsSms: SMS, Comments: "", phpublish: publish }];
                    //debugger;
                    this.modelInput.CustomerEmails = [{ Email: "", EmailName: "", Newslettere: false, publish: epublish }];
                    var cntrycode = this._resourceService.getCookie(empid + "ccode");
                    if (cntrycode.length > 0)
                        cntrycode = cntrycode.substring(1, cntrycode.length);
                    var adid = "";
                    jQuery.each(this._AddressTypes, function () {
                        if (this.Text == "Home") {
                            adid = this.Value;
                            return false;
                        }
                    });
                    this.modelInput.CustomerAddresses = [{ Street: "", Street2: "", CityName: "", Zip: "", CountryCode: cntrycode, StateId: "", AddressTypeId: adid, ForDelivery: false, MainAddress: false }];
                    this.modelInput.CustomerGroups = [];
                    this.Address.CountryCode = "";
                    this.Address.StateId = "";
                    this.modelInput.Safixid = "";
                    this.modelInput.Gender = "0";
                    this.ShowMsg = false;
                    this.Msg = "";
                    this.IsShowAll = false;
                    this._customerService.GetGeneralGroups(this.IsShowAll).subscribe(function (data) {
                        // debugger;
                        if (_this.IsShowAll == false) {
                            jQuery("#groupTree").html("Loding...");
                            var res = jQuery.parseJSON(data).Data;
                            jQuery("#groupTree").kendoTreeView({
                                loadOnDemand: true,
                                checkboxes: {},
                                check: function (e) {
                                    this.expandRoot = e.node;
                                    this.expand(jQuery(this.expandRoot).find(".k-item").addBack());
                                },
                                //check: this.onGroupSelect,
                                dataSource: res
                            });
                        }
                        else {
                            jQuery("#groupTree1").html("Loding...");
                            var res = jQuery.parseJSON(data).Data;
                            jQuery("#groupTree1").kendoTreeView({
                                loadOnDemand: true,
                                checkboxes: {},
                                check: function (e) {
                                    this.expandRoot = e.node;
                                    this.expand(jQuery(this.expandRoot).find(".k-item").addBack());
                                },
                                dataSource: res
                            });
                        }
                    }, function (err) {
                    }, function () {
                    });
                    this.IsPopUp = true;
                };
                AmaxCustomers.prototype.CancelFileAstxt = function () {
                    this.IsFileAstxtShow = true;
                    this.IsFileAstxtShow = false;
                    this.IsCancel = true;
                    jQuery("#FileAstxt").hide();
                    jQuery("#FileAsSpn").show();
                    this.FILEAS_BTN_TEXT = this.RES.CUSTOMER_MASTER.APP_BTN_FILEAS;
                    if (this.modelInput.CustomerId != undefined && this.modelInput.CustomerId != null && parseInt(this.modelInput.CustomerId) > -1) {
                        jQuery("#FileAsSaveBtn").show();
                        this.cssFileAsBtn = "mdi-content-create";
                        jQuery("#FileAsCancelBtn").hide();
                    }
                    else {
                        jQuery("#FileAsSaveBtn").hide();
                        jQuery("#FileAsCancelBtn").hide();
                    }
                };
                AmaxCustomers.prototype.HideShowFileAstxt = function () {
                    var _this = this;
                    if (this.IsFileAstxtShow == false) {
                        this.IsFileAstxtShow = true;
                        jQuery("#FileAstxt").show();
                        jQuery("#FileAsSpn").hide();
                        this.IsCancel = false;
                        this.FILEAS_BTN_TEXT = this.RES.CUSTOMER_MASTER.APP_BTN_SAVEFILEAS;
                        // alert(this.modelInput.CustomerId);
                        if (this.modelInput.CustomerId != undefined && this.modelInput.CustomerId != null && parseInt(this.modelInput.CustomerId) > -1) {
                            jQuery("#FileAsSaveBtn").show();
                            this.cssFileAsBtn = "mdi-content-save";
                            jQuery("#FileAsCancelBtn").show();
                        }
                        else {
                            jQuery("#FileAsSaveBtn").hide();
                            jQuery("#FileAsCancelBtn").hide();
                        }
                    }
                    else {
                        this.IsFileAstxtShow = false;
                        jQuery("#FileAstxt").hide();
                        jQuery("#FileAsSpn").show();
                        this.FILEAS_BTN_TEXT = this.RES.CUSTOMER_MASTER.APP_BTN_FILEAS;
                        if (this.modelInput.CustomerId != undefined && this.modelInput.CustomerId != null && parseInt(this.modelInput.CustomerId) > -1) {
                            jQuery("#FileAsSaveBtn").show();
                            this.cssFileAsBtn = "mdi-content-create";
                            jQuery("#FileAsCancelBtn").hide();
                            if (this.modelInput.FileAs != "" && this.modelInput.FileAs != undefined && this.modelInput.FileAs != null && this.IsCancel == false) {
                                this._customerService.SaveFileAs(this.modelInput.CustomerId, this.modelInput.FileAs).subscribe(function (response) {
                                    response = jQuery.parseJSON(response);
                                    //alert('hello');
                                    if (response.IsError == true) {
                                        //alert(response.ErrMsg);
                                        bootbox.alert({
                                            message: response.ErrMsg, className: _this.ChangeDialog,
                                            buttons: {
                                                ok: {
                                                    //label: 'Ok',
                                                    className: _this.CHANGEDIR
                                                }
                                            }
                                        });
                                    }
                                    //this.IsFileAsSave = false;
                                    bootbox.alert({
                                        message: response.ErrMsg, className: _this.ChangeDialog,
                                        buttons: {
                                            ok: {
                                                //label: 'Ok',
                                                className: _this.CHANGEDIR
                                            }
                                        }
                                    });
                                    _this.IsCancel = true;
                                    //}
                                    //else {
                                    //}
                                });
                            }
                            else {
                                bootbox.alert({
                                    message: this.RES.CUSTOMER_MASTER.APP_EMPTYFILEAS, className: this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: this.CHANGEDIR
                                        }
                                    }
                                });
                                this.bindFileAs();
                                this.IsFileAstxtShow = false;
                                this.HideShowFileAstxt();
                            }
                        }
                        else {
                            jQuery("#FileAsSaveBtn").hide();
                            jQuery("#FileAsCancelBtn").hide();
                        }
                    }
                };
                AmaxCustomers.prototype.SetEmailName = function () {
                    if (this.modelInput.FileAs != undefined && this.modelInput.FileAs != null) {
                        if (this.modelInput.CustomerEmails.length > 0) {
                            this.modelInput.CustomerEmails[this.modelInput.CustomerEmails.length - 1].EmailName = this.modelInput.FileAs;
                        }
                    }
                };
                AmaxCustomers.prototype.CheckCustWithSameName = function () {
                };
                AmaxCustomers.prototype.SetDefaultCust = function () {
                    //alert();
                    //debugger;
                };
                AmaxCustomers.prototype.setdefaultAddress = function () {
                    this.bindFileAs();
                    this.CheckCustWithfnamelnamecompphsemails();
                    var adid = "";
                    var adtext = "Home";
                    if (this.modelInput.Company != "" && this.modelInput.Company != undefined) {
                        adtext = "Work";
                    }
                    jQuery.each(this._AddressTypes, function () {
                        if (this.Text == adtext) {
                            adid = this.Value;
                            return false;
                        }
                    });
                    this.modelInput.CustomerAddresses[this.modelInput.CustomerAddresses.length - 1].AddressTypeId = adid;
                };
                AmaxCustomers.prototype.bindFileAs = function () {
                    if (this.modelInput.FileAs == "" || this.modelInput.FileAs == undefined) {
                        //debugger;
                        if ((this.modelInput.Company == "" || this.modelInput.Company == undefined)) {
                            var fileastext = "";
                            if (this.modelInput.fname != "" && this.modelInput.fname != undefined && this.modelInput.lname != "" && this.modelInput.lname != undefined) {
                                fileastext = this.modelInput.lname + " " + this.modelInput.fname;
                            }
                            else if (this.modelInput.fname != "" && this.modelInput.fname != undefined && (this.modelInput.lname == "" || this.modelInput.lname == undefined)) {
                                fileastext = " " + this.modelInput.fname;
                            }
                            else if ((this.modelInput.fname == "" || this.modelInput.fname == undefined) && (this.modelInput.lname != "" && this.modelInput.lname != undefined)) {
                                fileastext = this.modelInput.lname + " ";
                            }
                            this.modelInput.FileAs = fileastext;
                        }
                        else if ((this.modelInput.lname == "" || this.modelInput.lname == undefined) && (this.modelInput.fname == "" || this.modelInput.lname == undefined)) {
                            var fileastext = "";
                            if ((this.modelInput.Company != "" && this.modelInput.Company != undefined)) {
                                fileastext = this.modelInput.Company;
                            }
                            this.modelInput.FileAs = fileastext;
                        }
                        else
                            this.modelInput.FileAs = "(" + this.modelInput.Company + ") " + this.modelInput.lname + " " + this.modelInput.fname; //+ " " & m_strSpouse
                        if (this.modelInput.CustomerEmails.length > 0) {
                            this.modelInput.CustomerEmails[this.modelInput.CustomerEmails.length - 1].EmailName = this.modelInput.FileAs;
                        }
                    }
                    this.SetEmailName();
                };
                AmaxCustomers.prototype.bindGroup = function () {
                    //alert(this.IsShowAll); this function is calling on click of checkbox
                    var isshow = false;
                    if (this.IsShowAll == true) {
                        isshow = false;
                        this.IsShowAll = false;
                    }
                    else {
                        this.IsShowAll = true;
                        isshow = true;
                    }
                    this.bindGroupTree(isshow);
                };
                AmaxCustomers.prototype.saveCustomerData = function () {
                    var _this = this;
                    //debugger;
                    this.Isbtndisable = "disabled";
                    this.ShowLoader = true;
                    this.getSelectedGroups();
                    var count = 0;
                    if (this.modelInput.CustomerAddresses != undefined && this.modelInput.CustomerAddresses != null) {
                        jQuery.each(this.modelInput.CustomerAddresses, function () {
                            if (this.MainAddress == true) {
                                count = count + 1;
                            }
                            if (count > 1) {
                                //bootbox.alert("Main Address sholud be only one");
                                this.Isbtndisable = "";
                                this.ShowLoader = false;
                                return false;
                            }
                        });
                    }
                    //alert(this.modelInput.BirthDate);
                    if (this.modelInput.BirthDate != "") {
                        if (moment(this.modelInput.BirthDate, "DD-MM-YYYY", true).isValid() == false) {
                            bootbox.alert({ message: "Birthdate is not valid" });
                            this.Isbtndisable = "";
                            this.ShowLoader = false;
                            return false;
                        }
                    }
                    this.modelInput.Title = jQuery("#Title").val();
                    if (count <= 1 || this.modelInput.CustomerAddresses == undefined || this.modelInput.CustomerAddresses == null) {
                        if (this.modelInput.CustomerPhones != undefined && this.modelInput.CustomerPhones != null) {
                            var phtemp = [];
                            jQuery('input[name^="ph"]').each(function () {
                                phtemp.push(jQuery(this).val());
                            });
                            var artemp = [];
                            jQuery('input[name^="ar"]').each(function () {
                                artemp.push(jQuery(this).val());
                            });
                            var pretemp = [];
                            jQuery('input[name^="pre"]').each(function () {
                                pretemp.push(jQuery(this).val());
                            });
                            var i = 0;
                            jQuery.each(this.modelInput.CustomerPhones, function () {
                                if (this.IsSms == true) {
                                    this.IsSms = "1";
                                }
                                else {
                                    this.IsSms = "0";
                                }
                                if (this.phpublish == true) {
                                    this.phpublish = "1";
                                }
                                else {
                                    this.phpublish = "0";
                                }
                                this.Phone = phtemp[i];
                                this.Area = artemp[i];
                                this.Prefix = pretemp[i];
                                i++;
                                //var temp = this.PhoneTypeId.split(';');
                                //this.PhoneTypeId = parseInt(temp[1]);
                                //this.PhoneType = temp[0];
                            });
                        }
                        if (this.modelInput.CustomerEmails != undefined && this.modelInput.CustomerEmails != null) {
                            jQuery.each(this.modelInput.CustomerEmails, function () {
                                if (this.publish == true) {
                                    this.publish = "1";
                                }
                                else {
                                    this.publish = "0";
                                }
                                // debugger;
                                if (this.Newslettere == true) {
                                    this.Newslettere = false;
                                }
                                else {
                                    this.Newslettere = true;
                                }
                                i++;
                            });
                        }
                        var jdata = JSON.stringify(this.modelInput);
                        console.log(jdata);
                        this._resourceService.deleteCookie("TempImageName");
                        this._customerService.AddCustomer(jdata).subscribe(function (response) {
                            console.log(response);
                            response = jQuery.parseJSON(response);
                            _this.Isbtndisable = "";
                            _this.ShowLoader = false;
                            if (response.IsError == true) {
                                //alert(response.ErrMsg);
                                _this.MsgClass = "text-danger";
                            }
                            else {
                                //alert(response.ErrMsg);
                                _this.MsgClass = "text-success";
                                var empid = localStorage.getItem("employeeid");
                                _this._resourceService.setCookie(empid + "cust", _this.modelInput.CustomerType, 10);
                                _this._resourceService.setCookie(empid + "emp", _this.modelInput.employeeid, 10);
                                _this._resourceService.setCookie(empid + "src", _this.modelInput.CameFromCustomer, 10);
                                if (_this.modelInput.CustomerAddresses.length > 0)
                                    _this._resourceService.setCookie(empid + "ccode", _this.modelInput.CustomerAddresses[_this.modelInput.CustomerAddresses.length - 1].CountryCode, 10);
                                // debugger;
                                //document.location = this.BaseAppUrl + "Customer/Add/-1";
                                //debugger;
                                _this.TempmodelInput = response.Data;
                                _this.modelInput = response.Data;
                                _this.editCustDet(_this.modelInput);
                            }
                            _this.ShowMsg = true;
                            _this.Msg = response.ErrMsg;
                        }, function (error) { return console.log(error); }, function () { return console.log("Save Call Compleated"); });
                    }
                    else {
                        bootbox.alert({
                            message: this.RES.CUSTOMER_MASTER.APP_MSG_ISMAINADD, className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                        this.Isbtndisable = "";
                        this.ShowLoader = false;
                    }
                };
                AmaxCustomers.prototype.CheckCustWithfnamelnamecompphsemails = function () {
                    var _this = this;
                    //this.modelInput.ImageFileName = this._resourceService.getCookie("TempImageName");
                    if (this.IsPopUp == true) {
                        var jdata = JSON.stringify(this.modelInput);
                        //debugger;
                        var fname = "";
                        var lname = "";
                        var company = "";
                        var phones = "";
                        var emails = "";
                        if (this.modelInput.fname == undefined)
                            fname = "";
                        else
                            fname = this.modelInput.fname;
                        if (this.modelInput.lname == undefined)
                            lname = "";
                        else
                            lname = this.modelInput.lname;
                        if (this.modelInput.Company == undefined)
                            company = "";
                        else
                            company = this.modelInput.Company;
                        jQuery('input[name^="ph"]').each(function () {
                            if (jQuery(this).val() != "" && jQuery(this).val() != undefined && jQuery(this).val() != null && jQuery(this).val().length >= 3) {
                                phones += jQuery(this).val() + "','";
                            }
                        });
                        if (phones.length > 0)
                            phones = phones.substring(0, phones.length - 3);
                        jQuery.each(this.modelInput.CustomerEmails, function () {
                            if (this.Email != "" && this.Email != undefined && this.Email != null && this.Email.length >= 3) {
                                emails += this.Email + "','";
                            }
                        });
                        if (emails.length > 0)
                            emails = emails.substring(0, emails.length - 3);
                        if ((fname != "" && fname.length >= 2 && lname != "" && lname.length >= 2)
                            || (company != "" && company.length >= 3)
                            || (phones != "")
                            || (emails != "")) {
                            this._customerService.GetCustomersSearchData(fname, lname, company, phones, emails).subscribe(function (response) {
                                //debugger;
                                response = jQuery.parseJSON(response);
                                if (response.IsError == true) {
                                    bootbox.alert({
                                        message: response.ErrMsg, className: _this.ChangeDialog,
                                        buttons: {
                                            ok: {
                                                //label: 'Ok',
                                                className: _this.CHANGEDIR
                                            }
                                        }
                                    });
                                }
                                else {
                                    _this.CustList = {};
                                    _this.CustList = response.Data;
                                    if (response.Data != null && response.Data != undefined) {
                                        _this.custSearchData = response.Data;
                                        jQuery('#CustModal').openModal();
                                    }
                                }
                            }, function (error) {
                                console.log(error);
                            }, function () {
                                console.log("CallCompleted");
                            });
                        }
                    }
                    //this.bindFileAs();
                };
                AmaxCustomers.prototype.CloseModalPop = function () {
                    this.ClosePopUp();
                    this.IsPopUp = false;
                };
                AmaxCustomers.prototype.ClosePopUp = function () {
                    jQuery("#CustModal").closeModal();
                    jQuery(".lean-overlay").css({ "display": "none" });
                };
                AmaxCustomers.prototype.CheckCustWithfnamelname = function (fname, lname, company) {
                    var _this = this;
                    var jdata = JSON.stringify(this.modelInput);
                    //debugger;
                    if (this.modelInput.fname == undefined)
                        fname = "";
                    else
                        fname = this.modelInput.fname;
                    if (this.modelInput.lname == undefined)
                        lname = "";
                    else
                        lname = this.modelInput.lname;
                    if (this.modelInput.Company == undefined)
                        company = "";
                    else
                        company = this.modelInput.Company;
                    this._customerService.CheckCustWithSameName(fname, lname, company).subscribe(function (response) {
                        //debugger;
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.CustList = {};
                            _this.CustList = response.Data;
                            if (response.Data != null && response.Data != undefined) {
                                _this.custSearchData = response.Data;
                                jQuery("#CustModal").openModal();
                            }
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //this.bindFileAs();
                };
                AmaxCustomers.prototype.CheckCustWithEmail = function () {
                    //var Email = "";
                    //if (this.EmailModel.Email != "" && this.EmailModel.Email != undefined)
                    //    Email = this.EmailModel.Email;
                    //this._customerService.CheckCustWithSameEmail(Email).subscribe(response=> {
                    //    //debugger;
                    //    response = jQuery.parseJSON(response);
                    //    if (response.IsError == true) {
                    //        alert(response.ErrMsg);
                    //    }
                    //    else {
                    //        this.CustList = {};
                    //        this.CustList = response.Data;
                    //        if (response.Data != null && response.Data != undefined) {
                    //            this.custSearchData = response.Data;
                    //            jQuery("#CustModal").modal("show");
                    //        }
                    //        //alert(this.RES);
                    //    }
                    //}, error=> {
                    //    console.log(error);
                    //}, () => {
                    //    console.log("CallCompleted")
                    //});
                };
                AmaxCustomers.prototype.CheckCustWithPhone = function () {
                    var _this = this;
                    var Phone = "";
                    if (this.PhoneModel.Phone != "" && this.PhoneModel.Phone != undefined)
                        Phone = this.PhoneModel.Phone;
                    this._customerService.CheckCustWithSamePhone(this.PhoneModel.Phone).subscribe(function (response) {
                        //debugger;
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.CustList = {};
                            _this.CustList = response.Data;
                            if (response.Data != null && response.Data != undefined) {
                                _this.custSearchData = response.Data;
                                jQuery("#CustModal").openModal();
                            }
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxCustomers.prototype.ShowRemarks = function (PhObj) {
                    jQuery.each(this.modelInput.CustomerPhones, function () {
                        if (this == PhObj) {
                            this.IsShowRemarks = true;
                        }
                    });
                };
                AmaxCustomers.prototype.showAddPopup = function () {
                    this.Address = {};
                    this.PhoneModel = {};
                    this.PhoneModel.PhoneTypeId = "";
                    this.Address.CountryCode = "";
                    this.Address.StateId = "";
                    this.Address.CityName = "";
                    this.Address.AddressTypeId = "";
                    this.EmailModel = {};
                    this.BTN_PHADD = this.RES.CUSTOMER_MASTER.APP_BTN_PHADD;
                };
                AmaxCustomers.prototype.showhideGroups = function () {
                    //debugger;
                    if (this.ShowGroups == false) {
                        this.ShowGroups = true;
                        this.GroupText = this.RES.CUSTOMER_MASTER.APP_LBL_HIDEGROUP;
                        jQuery("#GrpDiv").show(1000);
                    }
                    else {
                        this.ShowGroups = false;
                        this.GroupText = this.RES.CUSTOMER_MASTER.APP_LBL_SHOWGROUPS;
                        jQuery("#GrpDiv").hide(1000);
                    }
                };
                AmaxCustomers.prototype.CanaddAddress = function (adobj) {
                    //alert('Hello');
                    return (adobj.Street != undefined && adobj.Street != "")
                        && (adobj.Street2 != undefined && adobj.Street2 != "")
                        && (adobj.Zip != undefined && adobj.Zip != "")
                        && (adobj.CountryCode != undefined && adobj.CountryCode != "")
                        && (adobj.AddressTypeId != undefined && adobj.AddressTypeId != "");
                };
                AmaxCustomers.prototype.AddAddresses = function (adobj) {
                    var IsMainAdd = false;
                    adobj.CityName = jQuery("#City").val();
                    if (this.CanaddAddress(adobj)) {
                        var empid = localStorage.getItem("employeeid");
                        this._resourceService.setCookie(empid + "ccode", adobj.CountryCode, 10);
                        var adid = "";
                        var adtext = "Home";
                        if (this.modelInput.Company != "" && this.modelInput.Company != undefined) {
                            adtext = "Work";
                        }
                        jQuery.each(this._AddressTypes, function () {
                            if (this.Text == adtext) {
                                adid = this.Value;
                                return false;
                            }
                        });
                        var AddresObj = { Street: "", Street2: "", CityName: "", Zip: "", CountryCode: adobj.CountryCode, StateId: "", AddressTypeId: adid, ForDelivery: false, MainAddress: false, MainOrder: "MainAddr" + (this.modelInput.CustomerAddresses.length + 1).toString(), DelvryOrder: "Delvry" + (this.modelInput.CustomerAddresses.length + 1).toString() };
                        //jQuery.each(this.modelInput.CustomerAddresses, function () {
                        //    if (this.MainAddress == true && adobj.MainAddress == true && this != adobj) {
                        //        adobj.MainAddress = false;
                        //        return false;
                        //    }
                        //});
                        if (IsMainAdd == false) {
                            this.modelInput.CustomerAddresses.push(AddresObj);
                        }
                    }
                    else {
                        var msg = '';
                        if (adobj.Street == undefined || adobj.Street == "") {
                            //msg += '\nStreet is not filled'; APP_AL_MSG_STREET
                            msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_MSG_STREET;
                        }
                        if (adobj.Street2 == undefined || adobj.Street2 == "") {
                            //msg += '\nArea is not filled';
                            msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_MSG_AREA;
                        }
                        //if (adobj.CityName == undefined || adobj.CityName == "")
                        //    //msg += '\nCity is not filled'; 
                        //    msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_MSG_CITY;
                        if (adobj.Zip == undefined || adobj.Zip == "") {
                            //msg += '\nZip is not filled'; 
                            msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_MSG_ZIP;
                        }
                        if (adobj.CountryCode == undefined || adobj.CountryCode == "") {
                            //msg += '\nCountry is not selected';
                            msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_MSG_COUNTRY;
                        }
                        //if (this.Address.StateId == undefined || this.Address.StateId == "") {
                        //    msg += '\nState is not selected';
                        //}
                        if (adobj.AddressTypeId == undefined || adobj.AddressTypeId == "") {
                            //msg += '\nAddress type is not selected';
                            msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_MSG_ADTYPE;
                        }
                        bootbox.alert({
                            message: msg, className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                    }
                };
                AmaxCustomers.prototype.CanaddPhone = function (phoneObj) {
                    //debugger;
                    //alert(this.PhoneModel.PhoneTypeId + ' ' + this.PhoneModel.PhoneType + ' ' + this.PhoneModel.Prefix + ' ' + this.PhoneModel.Area + ' ' + this.PhoneModel.Phone);
                    return (phoneObj.PhoneTypeId != undefined && phoneObj.PhoneTypeId != "");
                    // && (this.PhoneModel.PhoneType != undefined&& this.PhoneModel.PhoneType != "" )
                    //&& (this.PhoneModel.Prefix != undefined&& this.PhoneModel.Prefix != ""  )
                    //&& (this.PhoneModel.Area != undefined&&this.PhoneModel.Area != ""  )
                    //&& (phoneObj.Phone != undefined && phoneObj.Phone != "");
                    //&& (this.PhoneModel.Prefix != undefined && this.PhoneModel.Prefix.length != 3);            ;
                };
                AmaxCustomers.prototype.AddPhones = function (phoneObj) {
                    if (this.CanaddPhone(phoneObj)) {
                        // debugger;
                        //if (this.IsRecordEditMode == false) {
                        var phid = "";
                        var SMS = 0;
                        var publish = 0;
                        jQuery.each(this._PhoneTypes, function () {
                            if (this.Text == "CellPhone") {
                                phid = this.Value;
                                SMS = 1;
                                publish = 1;
                                return false;
                            }
                        });
                        var PhoneObj = { PhoneTypeId: phid, PhoneType: "", Prefix: "", Area: "", Phone: "", IsSms: SMS, Comments: "", IsShowRemarks: false, phpublish: publish, SMSOrder: "SMS" + (this.modelInput.CustomerPhones.length + 1).toString(), PublishOrder: "Pub" + (this.modelInput.CustomerPhones.length + 1).toString() };
                        this.modelInput.CustomerPhones.push(PhoneObj);
                    }
                    else {
                        var msg = '';
                        if (phoneObj.PhoneTypeId == undefined || phoneObj.PhoneTypeId == "") {
                            //msg += '\nPhone type is not selected';
                            msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_REGMSG_PHTYPE;
                        }
                        //if (phoneObj.Phone == undefined || phoneObj.Phone == "") {
                        //    //msg += '\nPhone number is not filled';
                        //    msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_REGMSG_PHNO;
                        //}
                        //if (this.PhoneModel.Prefix.length!=3) {
                        //    msg += '\nPrefix must of 3 numeric digits';
                        //}
                        bootbox.alert({
                            message: msg, className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                    }
                };
                AmaxCustomers.prototype.CanaddEmail = function (EmailObj) {
                    //debugger;
                    //alert('Hello');
                    return (EmailObj.EmailName != undefined && EmailObj.EmailName != "");
                    //(EmailObj.Email != undefined && EmailObj.Email != "") &&
                };
                AmaxCustomers.prototype.AddEmails = function (EmailObj) {
                    //debugger;
                    if (this.CanaddEmail(EmailObj)) {
                        var epublish = 0;
                        jQuery.each(this._PhoneTypes, function () {
                            if (this.Text == "CellPhone") {
                                epublish = 1;
                                return false;
                            }
                        });
                        //if (this.IsRecordEditMode == false) {
                        var eObj = {};
                        eObj.Email = "";
                        eObj.EmailName = this.modelInput.FileAs;
                        eObj.Newslettere = true;
                        eObj.publish = epublish;
                        eObj.NewsOrder = "News" + (this.modelInput.CustomerEmails.length + 1).toString();
                        eObj.EPublishOrder = "EPub" + (this.modelInput.CustomerEmails.length + 1).toString();
                        this.modelInput.CustomerEmails.push(eObj);
                    }
                    else {
                        var msg = '';
                        //if (EmailObj.Email == undefined || EmailObj.Email == "")
                        //    //msg += '\nEmail is not filled';
                        //    msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_REGMSG_EMAIL;
                        if (EmailObj.EmailName == undefined || EmailObj.EmailName == "") {
                            //msg += '\nName is not filled';
                            msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_REGMSG_ENAME;
                        }
                        bootbox.alert({
                            message: msg, className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                    }
                    // this.modelInput.CustomerAddresses = this.CustomerAddresses;
                };
                AmaxCustomers.prototype.editCustDet = function (Obj) {
                    var _this = this;
                    this._customerService.GetCompleteCustDet(Obj.CustomerId).subscribe(function (response) {
                        //  debugger;
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.modelInput = response.Data;
                            _this.SAVE_BTN_TEXT = _this.RES.CUSTOMER_MASTER.APP_BTN_UPDATE;
                            //this.ADD_NEW_CUST_TEXT = this.RES.CUSTOMER_MASTER.APP_LBL_UPDATE_CUST;
                            _this.CSSTEXT = "mdi-content-add";
                            if (_this.modelInput.CustomerEmails.length == 0) {
                                _this.modelInput.CustomerEmails = [{ Email: "", EmailName: _this.modelInput.FileAs, Newslettere: false, publish: 0, NewsOrder: "News1", EPublishOrder: "EPub1" }];
                            }
                            else {
                                var count = 1;
                                jQuery.each(_this.modelInput.CustomerEmails, function () {
                                    this.NewsOrder = "News" + count;
                                    this.EPublishOrder = "EPub" + count++;
                                    if (this.Newslettere == "1") {
                                        this.Newslettere = false;
                                    }
                                    else {
                                        this.Newslettere = true;
                                    }
                                });
                            }
                            if (_this.modelInput.CustomerPhones.length == 0) {
                                var phid = "";
                                jQuery.each(_this._PhoneTypes, function () {
                                    if (this.Text == "CellPhone") {
                                        phid = this.Value;
                                        return false;
                                    }
                                });
                                _this.modelInput.CustomerPhones = [{ PhoneTypeId: phid, Prefix: "", Area: "", Phone: "", IsSms: 0, Comments: "", phpublish: 0, SMSOrder: "SMS1", PublishOrder: "Pub1" }];
                            }
                            else {
                                var count = 1;
                                jQuery.each(_this.modelInput.CustomerPhones, function () {
                                    this.SMSOrder = "SMS" + count;
                                    this.PublishOrder = "Pub" + count++;
                                });
                            }
                            if (_this.modelInput.CustomerAddresses.length == 0) {
                                var empid = localStorage.getItem("employeeid");
                                var ccode = _this._resourceService.getCookie(empid + "ccode");
                                if (ccode.length > 0)
                                    ccode = ccode.substring(1, ccode.length);
                                var adid = "";
                                var comptext = "Home";
                                if (_this.modelInput.Company != "" && _this.modelInput.Company != undefined && _this.modelInput.Company != null) {
                                    comptext = "Work";
                                }
                                jQuery.each(_this._AddressTypes, function () {
                                    if (this.Text == comptext) {
                                        adid = this.Value;
                                        return false;
                                    }
                                });
                                _this.modelInput.CustomerAddresses = [{ Street: "", Street2: "", CityName: "", Zip: "", CountryCode: ccode, StateId: "", AddressTypeId: adid, ForDelivery: false, MainAddress: false, MainOrder: "MainAddr1", DelvryOrder: "Delvry1" }];
                            }
                            else {
                                var count = 1;
                                jQuery.each(_this.modelInput.CustomerAddresses, function () {
                                    this.MainOrder = "MainAddr" + count;
                                    this.DelvryOrder = "Delvry" + count++;
                                });
                            }
                            //var treeview = jQuery("#groupTree").data("kendoTreeView");
                            //var bar = treeview.findById("Bar");
                            //jQuery.each(this.modelInput.CustomerGroups, function () {
                            //    var data = jQuery("#groupTree").data("kendoTreeView").dataSource.getByUid(this.CustomerGeneralGroupId);
                            //    if (data) {
                            //        data.set("checked", true);
                            //    }
                            //    //var GroupNode = treeview.findById(this.CustomerGeneralGroupId);
                            //    //treeview.dataItem(GroupNode).set("checked", true);
                            //});
                            _this.CustIdText = "( " + _this.modelInput.CustomerId + " )";
                            _this.IsFileAstxtShow = false;
                            _this.HideShowFileAstxt();
                            //this.modelInput.ImageFileName = "DefaultUser.jpg";
                            if (_this.modelInput.ImageFileName != undefined && _this.modelInput.ImageFileName != null && _this.modelInput.ImageFileName != "") {
                                var OrgId = "";
                                var empid = localStorage.getItem("employeeid");
                                if (empid != null && empid != undefined) {
                                    OrgId = localStorage.getItem(empid + "_OrgId");
                                }
                                _this.CustFileImage = OrgId + "//" + _this.modelInput.ImageFileName;
                            }
                            else {
                                _this.CustFileImage = "DefaultUser.jpg";
                            }
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this.ClosePopUp();
                    //////For Closing Display Popup/////////////
                    this.IsPopUp = false;
                };
                AmaxCustomers.prototype.CheckPhoneType = function (PhoneObj) {
                    var _this = this;
                    //debugger;
                    //alert(PhoneObj.PhoneTypeId + " | " + jQuery("#PhoneType").val());
                    var pretemp = [];
                    jQuery('select[name^="phtype"]').each(function () {
                        pretemp.push(jQuery(this).val());
                    });
                    var index = 0;
                    jQuery.each(this.modelInput.CustomerPhones, function () {
                        if (this == PhoneObj) {
                            return false;
                        }
                        index = index + 1;
                    });
                    if (pretemp[index] != undefined && pretemp[index] != null && pretemp[index] != "") {
                        var PhoneTypeId = pretemp[index];
                        this._customerService.GetPhoneTypeDet(PhoneTypeId).subscribe(function (data) {
                            //debugger;
                            //
                            var response = jQuery.parseJSON(data);
                            if (response.IsError == true) {
                                bootbox.alert({
                                    message: response.ErrMsg, className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                            else {
                                if (response.Data != undefined && response.Data != null && response.Data != "") {
                                    //debugger;
                                    //alert(index + " | " + this.modelInput.CustomerPhones[index].IsSms + " | " + response.Data.Text);
                                    if (response.Data.Text == "1") {
                                        _this.modelInput.CustomerPhones[index].IsSms = 1;
                                        _this.modelInput.CustomerPhones[index].phpublish = 1;
                                        _this.modelInput.CustomerEmails[_this.modelInput.CustomerEmails.length - 1].publish = 1;
                                    }
                                    else {
                                        _this.modelInput.CustomerPhones[index].phpublish = 0;
                                        _this.modelInput.CustomerPhones[index].IsSms = 0;
                                        _this.modelInput.CustomerEmails[_this.modelInput.CustomerEmails.length - 1].publish = 0;
                                    }
                                }
                            }
                            //var treeviewDataSource = jQuery("#groupTree").data("kendoTreeView").dataSource.view();
                        }, function (err) {
                        }, function () {
                        });
                    }
                };
                AmaxCustomers.prototype.editEmailDet = function (EmailObj) {
                    //debugger;
                    var index = 0;
                    this.IsRecordEditMode = true;
                    this.BTN_PHADD = this.RES.CUSTOMER_MASTER.APP_BTN_PHEDIT;
                    this.EmailModel.Email = EmailObj.Email;
                    this.EmailModel.EmailName = EmailObj.EmailName;
                    this.EmailModel.Newslettere = EmailObj.Newslettere;
                    this.EditEmailData = {};
                    this.EditEmailData = EmailObj;
                };
                AmaxCustomers.prototype.delEmailDet = function (EmailObj) {
                    //debugger;
                    if (this.modelInput.CustomerEmails.length > 1) {
                        var index = 0;
                        jQuery.each(this.modelInput.CustomerEmails, function () {
                            if (this == EmailObj) {
                                return false;
                            }
                            index = index + 1;
                        });
                        this.modelInput.CustomerEmails.splice(index, 1);
                    }
                };
                AmaxCustomers.prototype.editAddressDet = function (AddressObj) {
                    //debugger;
                    var index = 0;
                    this.IsRecordEditMode = true;
                    this.BTN_PHADD = this.RES.CUSTOMER_MASTER.APP_BTN_PHEDIT;
                    // AddressObj.CityName = jQuery("#City").val();
                    this.Address.Street = AddressObj.Street;
                    this.Address.Street2 = AddressObj.Street2;
                    this.Address.CityName = AddressObj.CityName;
                    this.Address.Zip = AddressObj.Zip;
                    this.Address.CountryCode = AddressObj.CountryCode;
                    this.Address.StateId = AddressObj.StateId;
                    this.Address.AddressTypeId = AddressObj.AddressTypeId;
                    this.Address.MainAddress = AddressObj.MainAddress;
                    this.Address.ForDelivery = AddressObj.ForDelivery;
                    this.EditAddressData = {};
                    this.EditAddressData = AddressObj;
                };
                AmaxCustomers.prototype.delAddressDet = function (AddressObj) {
                    // debugger; 
                    if (this.modelInput.CustomerAddresses > 1) {
                        var index = 0;
                        jQuery.each(this.modelInput.CustomerAddresses, function () {
                            if (this == AddressObj) {
                                return false;
                            }
                            index = index + 1;
                        });
                        this.modelInput.CustomerAddresses.splice(index, 1);
                    }
                };
                AmaxCustomers.prototype.editPhoneDet = function (PhoneObj) {
                    var index = 0;
                    this.BTN_PHADD = this.RES.CUSTOMER_MASTER.APP_BTN_PHEDIT;
                    var temp = PhoneObj.PhoneTypeId.split(';');
                    this.PhoneModel.PhoneTypeId = PhoneObj.PhoneType + ";" + PhoneObj.PhoneTypeId;
                    this.PhoneModel.PhoneType = PhoneObj.PhoneType;
                    this.PhoneModel.Prefix = PhoneObj.Prefix;
                    this.PhoneModel.Area = PhoneObj.Area;
                    this.PhoneModel.Phone = PhoneObj.Phone;
                    this.PhoneModel.IsSms = PhoneObj.IsSms;
                    this.PhoneModel.Comments = PhoneObj.Comments;
                    this.EditPhoneData = {};
                    this.EditPhoneData = PhoneObj;
                };
                AmaxCustomers.prototype.delPhoneDet = function (PhoneObj) {
                    // debugger;
                    if (this.modelInput.CustomerPhones.length > 1) {
                        var index = 0;
                        jQuery.each(this.modelInput.CustomerPhones, function () {
                            if (this == PhoneObj) {
                                return false;
                            }
                            index = index + 1;
                        });
                        this.modelInput.CustomerPhones.splice(index, 1);
                    }
                };
                AmaxCustomers.prototype.getSelectedGroups = function () {
                    this.modelInput.CustomerGroups = [];
                    var _CheckedGroups = [];
                    if (this.IsShowAll == false) {
                        amaxUtil_1.Kendo_utility.checkedNodeIds(jQuery("#groupTree").data("kendoTreeView").dataSource.view(), _CheckedGroups);
                    }
                    else {
                        amaxUtil_1.Kendo_utility.checkedNodeIds(jQuery("#groupTree1").data("kendoTreeView").dataSource.view(), _CheckedGroups);
                    }
                    for (var i = 0; i < _CheckedGroups.length; i++) {
                        var GObj = {};
                        GObj.CustomerGeneralGroupId = _CheckedGroups[i];
                        this.modelInput.CustomerGroups.push(GObj);
                    }
                };
                AmaxCustomers.prototype.More = function () {
                    // alert("call");
                    if (this.ShowMore == true) {
                        this.ShowMore = false;
                        //this.ShowMoreText = "More";
                        this.ShowMoreText = this.RES.CUSTOMER_MASTER.APP_LNK_LBL_MORE;
                    }
                    else {
                        this.ShowMore = true;
                        //this.ShowMoreText = "Less"; 
                        this.ShowMoreText = this.RES.CUSTOMER_MASTER.APP_LNK_LBL_LESS;
                    }
                    this.BindCustTitles();
                };
                AmaxCustomers.prototype.bindGroupTree = function (Isshowall) {
                    var _this = this;
                    this._customerService.GetGeneralGroups(Isshowall).subscribe(function (data) {
                        //debugger;
                        //
                        //alert(Isshowall);
                        if (Isshowall == false) {
                            jQuery("#groupTree").html("Loding...");
                            var res = jQuery.parseJSON(data).Data;
                            jQuery("#groupTree").kendoTreeView({
                                loadOnDemand: true,
                                checkboxes: {},
                                check: function (e) {
                                    this.expandRoot = e.node;
                                    this.expand(jQuery(this.expandRoot).find(".k-item").addBack());
                                },
                                //check: this.onGroupSelect,
                                dataSource: res
                            });
                            var grpids = "";
                            jQuery.each(_this.modelInput.CustomerGroups, function () {
                                grpids += this.CustomerGeneralGroupId + ";";
                            });
                            if (grpids.length > 0) {
                                amaxUtil_1.Kendo_utility.checkingNodeIds(jQuery("#groupTree").data("kendoTreeView").dataSource.view(), grpids.substring(0, grpids.length - 1));
                            }
                        }
                        else {
                            jQuery("#groupTree1").html("Loding...");
                            var res = jQuery.parseJSON(data).Data;
                            jQuery("#groupTree1").kendoTreeView({
                                loadOnDemand: true,
                                checkboxes: {},
                                check: function (e) {
                                    this.expandRoot = e.node;
                                    this.expand(jQuery(this.expandRoot).find(".k-item").addBack());
                                },
                                //check: this.onGroupSelect,
                                dataSource: res
                            });
                            var grpids = "";
                            jQuery.each(_this.modelInput.CustomerGroups, function () {
                                grpids += this.CustomerGeneralGroupId + ";";
                            });
                            if (grpids.length > 0) {
                                amaxUtil_1.Kendo_utility.checkingNodeIds(jQuery("#groupTree1").data("kendoTreeView").dataSource.view(), grpids.substring(0, grpids.length - 1));
                            }
                        }
                        //var treeviewDataSource = jQuery("#groupTree").data("kendoTreeView").dataSource.view();
                    }, function (err) {
                    }, function () {
                    });
                };
                AmaxCustomers.prototype.GetDataForSearch = function (event) {
                    //this.SearchVal = jQuery("#Searchtxt").val();
                    //alert(event.keyCode);
                    //if (this.SearchVal != undefined && this.SearchVal != "" && this.SearchVal != null && event.keyCode == 13) {
                    //alert(this.autocompleteSelect + " " + this.autocompleteNoResults);
                    //    this.EnterCount++;
                    //    if (this.EnterCount >= 2) {
                    //        this._customerService.GetCompleteSearch(this.SearchVal).subscribe(response=> {
                    //            response = jQuery.parseJSON(response);
                    //            if (response.IsError == true) {
                    //                alert(response.ErrMsg);
                    //            }
                    //            else {
                    //                this.CustList = {};
                    //                this.CustList = response.Data;
                    //                if (response.Data != null && response.Data != undefined) {
                    //                    this.custSearchData = response.Data;
                    //                    jQuery("#CustModal").modal("show");
                    //                }
                    //            }
                    //        }, error=> {
                    //            console.log(error);
                    //        }, () => {
                    //            console.log("CallCompleted")
                    //        });
                    //        this.EnterCount = 0;
                    //    }
                    //}
                    //this.SearchVal = "";
                };
                AmaxCustomers.prototype.BindCustTitles = function () {
                    var _this = this;
                    this._customerService.GetCustTitles().subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            var titletypeaheadSource = [];
                            jQuery.each(response.Data, function () {
                                var newtemp = {};
                                newtemp.id = this.Value;
                                newtemp.name = this.Text;
                                titletypeaheadSource.push(newtemp);
                            });
                            _this._CustTitles = response.Data;
                            jQuery("#Title").typeahead({
                                //data: this._Cities,
                                source: titletypeaheadSource,
                                //display: "text",
                                dataType: "JSON",
                            });
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxCustomers.prototype.FindImageFile = function (input) {
                    var _this = this;
                    //debugger;
                    this.modelInput.CustomerImageFile = input.target.files;
                    var data = new FormData();
                    var file = this.modelInput.CustomerImageFile[0];
                    data.append('file', file);
                    //  var uploaddata = {};
                    //  uploaddata.CustomerUploadedFile = data;
                    debugger;
                    var OrgId = "";
                    var empid = localStorage.getItem("employeeid");
                    if (empid != null && empid != undefined) {
                        OrgId = localStorage.getItem(empid + "_OrgId");
                    }
                    var xhr = this._customerService.UploadCustomerImage(data, OrgId);
                    xhr.onreadystatechange = function () {
                        if (xhr.readyState === 4) {
                            if (xhr.status === 200) {
                                debugger;
                                var response = xhr.responseText;
                                if (response != undefined && response != "" && response != null) {
                                    response = jQuery.parseJSON(response);
                                    if (response.IsError == true) {
                                        bootbox.alert({
                                            message: response.ErrMsg, className: _this.ChangeDialog,
                                            buttons: {
                                                ok: {
                                                    //label: 'Ok',
                                                    className: _this.CHANGEDIR
                                                }
                                            }
                                        });
                                    }
                                    else {
                                        //this.setCookie("TempImageName", response.Data, 10);
                                        _this.CustFileImage = response.Data;
                                        _this.modelInput.ImageFileName = response.Data;
                                    }
                                }
                            }
                            else {
                            }
                        }
                    };
                    //    .(response=> {
                    //    //debugger;
                    //    response = jQuery.parseJSON(response);
                    //    if (response.IsError == true) {
                    //        bootbox.alert({
                    //            message: response.ErrMsg, className: this.ChangeDialog,
                    //            buttons: {
                    //                ok: {
                    //                    //label: 'Ok',
                    //                    className: this.CHANGEDIR
                    //                }
                    //            }
                    //        });
                    //    }
                    //    else {
                    //        debugger;
                    //        var res = jQuery.parseJSON(response);
                    //        //this.modelInput.ImageFileName = response.Data;
                    //    }
                    //}, error=> {
                    //    console.log(error);
                    //}, () => {
                    //    console.log("CallCompleted")
                    //});
                    //input.srcElement.form.submit();
                    //var imagepath = jQuery("#CustImage").val().split('\\');
                    //if (imagepath.length > 0) {
                    //    this.CustFileImage = imagepath[2];
                    //    var iname = this.modelInput.CustomerId.toString() + ".jpg";
                    //    this.modelInput.ImageFileName = iname;
                    //}
                    //alert(jQuery("#CustImage").val());
                };
                AmaxCustomers.prototype.ClearImage = function () {
                    jQuery("#CustImage").val('');
                    this.modelInput.ImageFileName = "";
                    this.CustFileImage = "DefaultUser.jpg";
                    //alert(jQuery("#CustImage").val());
                };
                AmaxCustomers.prototype.ngOnInit = function () {
                    var _this = this;
                    //
                    this._resourceService.deleteCookie("TempImageName");
                    jQuery(".lean-overlay").css({ "display": "none" });
                    this.BindCustTitles();
                    // debugger;
                    //bootbox.alert("This is the default alert!");
                    if (localStorage.getItem("lang") == "") {
                        localStorage.setItem("lang", "en");
                    }
                    if (this._resourceService.getCookie("lang") == "") {
                        this._resourceService.setCookie("lang", "en", 10);
                    }
                    this.IsCancel = false;
                    this.showhideGroups();
                    this.IsFileAstxtShow = true;
                    //this.modelInput.CustomerId = -1;
                    if (this.modelInput.CustomerId >= 0) {
                        //this.IsFileAstxtShow = false;
                        this.editCustDet(this.modelInput);
                        this.SAVE_BTN_TEXT = this.RES.CUSTOMER_MASTER.APP_BTN_UPDATE;
                        //this.ADD_NEW_CUST_TEXT = this.RES.CUSTOMER_MASTER.APP_LBL_UPDATE_CUST;
                        //this.CSSTEXT = "mdi-content-add";
                        if (this.modelInput.CustomerAddresses.length == 0) {
                            var empid = localStorage.getItem("employeeid");
                            var ccode = this._resourceService.getCookie(empid + "ccode");
                            if (ccode.length > 0)
                                ccode = ccode.substring(1, ccode.length);
                            var adid = "";
                            var comptext = "Home";
                            if (this.modelInput.Company != "" && this.modelInput.Company != undefined && this.modelInput.Company != null) {
                                comptext = "Work";
                            }
                            jQuery.each(this._AddressTypes, function () {
                                if (this.Text == comptext) {
                                    adid = this.Value;
                                    return false;
                                }
                            });
                            this.modelInput.CustomerAddresses = [{ Street: "", Street2: "", CityName: "", Zip: "", CountryCode: ccode, StateId: "", AddressTypeId: adid, ForDelivery: false, MainAddress: false, MainOrder: "MainAddr1", DelvryOrder: "Delvry1" }];
                        }
                        this.CustIdText = "( " + this.modelInput.CustomerId + " )";
                        this.IsFileAstxtShow = false;
                    }
                    else {
                        this.CustFileImage = "DefaultUser.jpg";
                    }
                    this.Lang = this._resourceService.getCookie("lang");
                    if (this.Lang.length > 0) {
                        this.Lang = this.Lang.substring(1, this.Lang.length);
                    }
                    this.HideShowFileAstxt();
                    //this.RES = jQuery.parseJSON(this._customerService.GetLangRes(this.Formtype, this.Lang)).Data; //jQuery.parseJSON(localStorage.getItem("langresource"));
                    if (this.Lang == "he") {
                        this.KendoRTLCSS = "k-rtl";
                        this.CHANGEDIR = "rtlmodal";
                        this.ChangeDialog = "input_right";
                    }
                    else {
                        this.CHANGEDIR = "ltrmodal";
                        this.ChangeDialog = "input_left";
                    }
                    this._resourceService.GetLangRes(this.Formtype, this.Lang).subscribe(function (response) {
                        //debugger;
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.RES = response.Data;
                            _this.ShowMoreText = _this.RES.CUSTOMER_MASTER.APP_LNK_LBL_MORE;
                            _this.GroupText = _this.RES.CUSTOMER_MASTER.APP_LBL_SHOWGROUPS;
                            _this.SAVE_BTN_TEXT = _this.RES.CUSTOMER_MASTER.APP_BTN_SAVE;
                            _this.ADD_NEW_CUST_TEXT = _this.RES.CUSTOMER_MASTER.APP_LBL_NEW_CUST;
                            _this.FILEAS_BTN_TEXT = _this.RES.CUSTOMER_MASTER.APP_BTN_FILEAS;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //this.ShowMoreText = "More";
                    ////Cities
                    var CountryCode = this.Address.CountryCode;
                    var StateName = this.Address.StateId;
                    this._customerService.GetCities(CountryCode, StateName).subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            var typeaheadSource = [];
                            jQuery.each(response.Data, function () {
                                var newtemp = {};
                                newtemp.id = this.Value;
                                newtemp.name = this.Text;
                                typeaheadSource.push(newtemp);
                            });
                            _this._Cities = response.Data;
                            jQuery('#City').typeahead({
                                //data: this._Cities,
                                source: typeaheadSource,
                                //display: "text",
                                dataType: "JSON",
                            });
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this.languageArray = this._resourceService.GetAvailableLanguages();
                    this._customerService.GetCustomerTypes().subscribe(function (resp) {
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._CustTypes = response.Data;
                            if (_this.modelInput.CustomerType == "" || _this.modelInput.CustomerType == undefined || _this.modelInput.CustomerType == null) {
                                var CusttypeId;
                                jQuery.each(_this._CustTypes, function () {
                                    CusttypeId = this.Value;
                                    return false;
                                });
                                _this.modelInput.CustomerType = CusttypeId;
                            }
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    ////Sources
                    this._customerService.GetSources().subscribe(function (resp) {
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Sources = response.Data;
                            if (_this.modelInput.CameFromCustomer == "" || _this.modelInput.CameFromCustomer == undefined || _this.modelInput.CameFromCustomer == null) {
                                var Source;
                                jQuery.each(_this._Sources, function () {
                                    Source = this.Value;
                                    return false;
                                });
                                _this.modelInput.CameFromCustomer = Source;
                            }
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //GetEmployees
                    this._customerService.GetEmployees().subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Employees = response.Data;
                            if (_this.modelInput.employeeid == "" || _this.modelInput.employeeid == undefined || _this.modelInput.employeeid == null) {
                                var empid;
                                jQuery.each(_this._Employees, function () {
                                    empid = this.Value;
                                    return false;
                                });
                                _this.modelInput.employeeid = empid;
                            }
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //GetSuffixes
                    this._customerService.GetSuffixes().subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Suffixes = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //GetPhoneTypes
                    this._customerService.GetPhoneTypes().subscribe(function (response) {
                        // debugger;
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._PhoneTypes = response.Data;
                            var phid = "";
                            jQuery.each(_this._PhoneTypes, function () {
                                if (this.Text == "CellPhone") {
                                    phid = this.Value;
                                    return false;
                                }
                            });
                            _this.modelInput.CustomerPhones[0].PhoneTypeId = phid;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    var epublish = 0;
                    if (this.modelInput.CustomerPhones.length == 0) {
                        var phid = "";
                        jQuery.each(this._PhoneTypes, function () {
                            if (this.Text == "CellPhone") {
                                phid = this.Value;
                                epublish = 1;
                                return false;
                            }
                        });
                        this.modelInput.CustomerPhones = [{ PhoneTypeId: phid, Prefix: "", Area: "", Phone: "", IsSms: epublish, Comments: "", phpublish: epublish, SMSOrder: "SMS1", PublishOrder: "Pub1" }];
                    }
                    if (this.modelInput.CustomerEmails.length == 0) {
                        this.modelInput.CustomerEmails = [{ Email: "", EmailName: this.modelInput.FileAs, Newslettere: false, publish: epublish, NewsOrder: "News1", EPublishOrder: "EPub1" }];
                    }
                    //GetAddressTypes
                    this._customerService.GetAddressTypes().subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._AddressTypes = response.Data;
                            // debugger;
                            var adid = "";
                            jQuery.each(_this._AddressTypes, function () {
                                if (this.Text == "Home") {
                                    adid = this.Value;
                                    return false;
                                }
                            });
                            _this.modelInput.CustomerAddresses[0].AddressTypeId = adid;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //Groups
                    this._customerService.GetGroups().subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Groups = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    ////Countries
                    this._customerService.GetCountries().subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Countries = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    ////States
                    var CountryCode = this.Address.CountryCode;
                    this._customerService.GetStates(CountryCode).subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._States = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //Tree Group
                    //this.bindGroupTree(this.IsShowAll);
                    this._customerService.GetGeneralGroups(this.IsShowAll).subscribe(function (data) {
                        // debugger;
                        if (_this.IsShowAll == false) {
                            jQuery("#groupTree").html("Loding...");
                            var res = jQuery.parseJSON(data).Data;
                            jQuery("#groupTree").kendoTreeView({
                                loadOnDemand: true,
                                checkboxes: {
                                    checkChildren: true
                                },
                                //check: this.onGroupSelect,
                                dataSource: res
                            });
                            var grpids = "";
                            jQuery.each(_this.modelInput.CustomerGroups, function () {
                                grpids += this.CustomerGeneralGroupId + ";";
                            });
                            if (grpids.length > 0) {
                                amaxUtil_1.Kendo_utility.checkingNodeIds(jQuery("#groupTree").data("kendoTreeView").dataSource.view(), grpids.substring(0, grpids.length - 1));
                            }
                        }
                        else {
                            jQuery("#groupTree1").html("Loding...");
                            var res = jQuery.parseJSON(data).Data;
                            jQuery("#groupTree1").kendoTreeView({
                                loadOnDemand: true,
                                checkboxes: {
                                    checkChildren: true
                                },
                                //check: this.onGroupSelect,
                                dataSource: res
                            });
                            var grpids = "";
                            jQuery.each(_this.modelInput.CustomerGroups, function () {
                                grpids += this.CustomerGeneralGroupId + ";";
                            });
                            if (grpids.length > 0) {
                                amaxUtil_1.Kendo_utility.checkingNodeIds(jQuery("#groupTree1").data("kendoTreeView").dataSource.view(), grpids.substring(0, grpids.length - 1));
                            }
                        }
                    }, function (err) {
                    }, function () {
                    });
                    //alert(moment().format('D MMM YYYY'));       
                    // this.baseUrl + "Dropdown/BindAutoCompleteSrch"
                    var SrchData = null;
                    //alert('Hi');
                    jQuery("#EmailTable tbody tr td a[name=delEbtn]").not(":last").hide();
                    jQuery("#EmailTable tbody tr a[name=addEbtn]").not(":last").show();
                    //$('.modal').modal();
                };
                AmaxCustomers.$inject = ['$scope', '$location', '$anchorScroll'];
                AmaxCustomers = __decorate([
                    core_1.Component({
                        templateUrl: './app/amax/Customer/templates/customer.html',
                        directives: [common_1.NgSwitch, common_1.NgSwitchWhen, common_1.NgSwitchDefault, AUTOCOMPLETE_DIRECTIVES, common_1.CORE_DIRECTIVES, common_1.FORM_DIRECTIVES, basicComponents_1.AmaxDate],
                        providers: [CustomerService_1.CustomerService, ResourceService_1.ResourceService]
                    }), 
                    __metadata('design:paramtypes', [ResourceService_1.ResourceService, CustomerService_1.CustomerService, router_1.RouteParams])
                ], AmaxCustomers);
                return AmaxCustomers;
            }());
            exports_1("AmaxCustomers", AmaxCustomers);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFtYXgvQ3VzdG9tZXIvYWRkQ3VzdG9tZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7OztRQVlhLHVCQUF1Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztZQUF2QixxQ0FBQSx1QkFBdUIsR0FBRyxDQUFDLHFDQUFZLEVBQUUsOENBQXFCLENBQUMsQ0FBQSxDQUFDO1lBWTdFO2dCQXVGSSx1QkFBb0IsZ0JBQWlDLEVBQVUsZ0JBQWlDLEVBQVUsWUFBeUI7b0JBQS9HLHFCQUFnQixHQUFoQixnQkFBZ0IsQ0FBaUI7b0JBQVUscUJBQWdCLEdBQWhCLGdCQUFnQixDQUFpQjtvQkFBVSxpQkFBWSxHQUFaLFlBQVksQ0FBYTtvQkF0Rm5JLFlBQU8sR0FBVyxFQUFFLENBQUM7b0JBQ3JCLGFBQVEsR0FBVyxFQUFFLENBQUM7b0JBQ3RCLGVBQVUsR0FBRyxFQUFFLENBQUM7b0JBQ2hCLG1CQUFjLEdBQUcsRUFBRSxDQUFDO29CQUNwQixtQkFBYyxHQUFXLEVBQUUsQ0FBQztvQkFDNUIsUUFBRyxHQUFXLEVBQUUsQ0FBQztvQkFDakIsbUJBQWMsR0FBVyxFQUFFLENBQUM7b0JBQzVCLGtCQUFhLEdBQVcsRUFBRSxDQUFDO29CQUMzQixhQUFRLEdBQVUsaUJBQWlCLENBQUM7b0JBQ3BDLFNBQUksR0FBUyxFQUFFLENBQUM7b0JBQ2hCLHVCQUF1QjtvQkFDdkIsYUFBUSxHQUFZLEtBQUssQ0FBQztvQkFDMUIscUJBQWdCLEdBQVksS0FBSyxDQUFDO29CQUNsQyxpQkFBWSxHQUFXLE1BQU0sQ0FBQztvQkFDOUIsa0JBQWEsR0FBVyxpQkFBaUIsQ0FBQztvQkFDMUMsZUFBVSxHQUFZLEtBQUssQ0FBQztvQkFDNUIsWUFBTyxHQUFZLEtBQUssQ0FBQztvQkFDekIsZUFBVSxHQUFZLElBQUksQ0FBQztvQkFDM0IsY0FBUyxHQUFTLGFBQWEsQ0FBQztvQkFDaEMsUUFBRyxHQUFXLEVBQUUsQ0FBQztvQkFDakIsYUFBUSxHQUFXLGNBQWMsQ0FBQztvQkFDbEMsaUJBQVksR0FBVyxFQUFFLENBQUM7b0JBQzFCLG9CQUFlLEdBQVcsRUFBRSxDQUFDO29CQUM3QixzQkFBaUIsR0FBVyxFQUFFLENBQUM7b0JBQy9CLGtCQUFhLEdBQUcsRUFBRSxDQUFDO29CQUVuQixZQUFPLEdBQVcsRUFBRSxDQUFDO29CQUNyQixlQUFVLEdBQVcsRUFBRSxDQUFDO29CQUN4QixlQUFVLEdBQVcsRUFBRSxDQUFDO29CQUN4QixjQUFTLEdBQVksS0FBSyxDQUFDO29CQUMzQixhQUFRLEdBQVcsRUFBRSxDQUFDO29CQUN0QixrQkFBYSxHQUFXLEVBQUUsQ0FBQztvQkFFM0IsY0FBUyxHQUFXLEVBQUUsQ0FBQztvQkFDdkIsa0JBQWEsR0FBVyxFQUFFLENBQUM7b0JBQzNCLG9CQUFlLEdBQVcsRUFBRSxDQUFDO29CQUM3QixrQkFBYSxHQUFXLEVBQUUsQ0FBQztvQkFLM0Isb0JBQWUsR0FBWSxLQUFLLENBQUM7b0JBQ2pDLG9CQUFlLEdBQVcsRUFBRSxDQUFDO29CQUM3QixpQkFBWSxHQUFXLEVBQUUsQ0FBQztvQkFDMUIsYUFBUSxHQUFZLEtBQUssQ0FBQztvQkFDMUIsY0FBUyxHQUFXLEVBQUUsQ0FBQztvQkFDdkIsZUFBVSxHQUFXLENBQUMsQ0FBQztvQkFFdkIsZUFBVSxHQUFXLEVBQUUsQ0FBQztvQkFFeEIsZUFBVSxHQUFXLEVBQUUsQ0FBQztvQkFDeEIsWUFBTyxHQUFXLENBQUMsQ0FBQztvQkFDcEIsZ0JBQVcsR0FBVyxFQUFFLENBQUM7b0JBQ3pCLGNBQVMsR0FBVyxFQUFFLENBQUM7b0JBQ3ZCLGlCQUFZLEdBQVcsRUFBRSxDQUFDO29CQUMxQixZQUFPLEdBQVksSUFBSSxDQUFDO29CQUl4QixnQ0FBZ0M7b0JBRWhDLHFCQUFxQjtvQkFDckIsNkJBQTZCO29CQUM3QixpQ0FBaUM7b0JBRWpDLGVBQVUsR0FBRyxFQUFFLENBQUM7b0JBQ2hCLGFBQVEsR0FBRyxFQUFFLENBQUM7b0JBQ2QsZUFBVSxHQUFHLEVBQUUsQ0FBQztvQkFDaEIsY0FBUyxHQUFHLEVBQUUsQ0FBQztvQkFDZixnQkFBVyxHQUFHLEVBQUUsQ0FBQztvQkFDakIsa0JBQWEsR0FBRyxFQUFFLENBQUM7b0JBQ25CLFlBQU8sR0FBRyxFQUFFLENBQUM7b0JBQ2IsZUFBVSxHQUFHLEVBQUUsQ0FBQztvQkFDaEIsWUFBTyxHQUFHLEVBQUUsQ0FBQztvQkFDYixZQUFPLEdBQUcsRUFBRSxDQUFDO29CQUNiLGdCQUFXLEdBQUcsRUFBRSxDQUFDO29CQUNULGdCQUFXLEdBQVcsRUFBRSxDQUFDO29CQUN6QixxQkFBZ0IsR0FBVyxFQUFFLENBQUM7b0JBQzlCLHdCQUFtQixHQUFZLEtBQUssQ0FBQztvQkFDckMsMEJBQXFCLEdBQVksS0FBSyxDQUFDO29CQUN2Qyx1QkFBa0IsR0FBWSxLQUFLLENBQUM7b0JBK0VwQyw4QkFBeUIsR0FBUyxFQUFFLENBQUM7b0JBdkV6QyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsR0FBRyxFQUFFLENBQUM7b0JBQy9CLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLEdBQUcsRUFBRSxDQUFDO29CQUN2QyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxFQUFFLENBQUM7b0JBQ3BDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLEVBQUUsQ0FBQztvQkFDcEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDO29CQUNwQyxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsR0FBQyxFQUFFLENBQUM7b0JBQzVCLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztvQkFDMUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsRUFBRSxDQUFDO29CQUNoQyxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUM7b0JBQ2xDLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLEdBQUcsRUFBRSxDQUFDO29CQUN0QyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7b0JBQzdCLG9EQUFvRDtvQkFDcEQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsR0FBRyxDQUFDO29CQUM3QixJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsR0FBRyxFQUFFLENBQUM7b0JBQ2pDLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxHQUFHLEVBQUUsQ0FBQztvQkFDOUIsSUFBSSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUM7b0JBQ3ZCLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsWUFBWSxDQUFDO29CQUMzRCxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGFBQWEsQ0FBQztvQkFDeEQsSUFBSSxDQUFDLGlCQUFpQixHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGdCQUFnQixDQUFDO29CQUNuRSxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxDQUFDLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFLFdBQVcsRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFFLENBQUMsRUFBRSxTQUFTLEVBQUUsT0FBTyxFQUFFLGFBQWEsRUFBQyxPQUFPLEVBQUUsQ0FBQyxDQUFBO29CQUN6SSxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxDQUFDLEVBQUUsV0FBVyxFQUFFLEVBQUUsRUFBRSxNQUFNLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsQ0FBQyxFQUFFLFFBQVEsRUFBRSxFQUFFLEVBQUUsYUFBYSxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsQ0FBQyxFQUFFLFFBQVEsRUFBRSxNQUFNLEVBQUMsWUFBWSxFQUFFLE1BQU0sRUFBQyxDQUFDLENBQUE7b0JBQzFMLFlBQVk7b0JBQ1gsSUFBSSxLQUFLLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQztvQkFFL0MsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsT0FBTyxDQUFDLENBQUM7b0JBQzdELEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO3dCQUNqQixLQUFLLEdBQUcsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUU3QyxJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixHQUFHLENBQUM7NEJBQ2pDLE1BQU0sRUFBRSxFQUFFLEVBQUUsT0FBTyxFQUFFLEVBQUUsRUFBRSxRQUFRLEVBQUUsRUFBRSxFQUFFLEdBQUcsRUFBRSxFQUFFLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRSxPQUFPLEVBQUUsRUFBRSxFQUFFLGFBQWEsRUFBRSxFQUFFOzRCQUNsRyxXQUFXLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFFLFdBQVcsRUFBRSxXQUFXLEVBQUUsU0FBUzt5QkFDdkYsQ0FBQyxDQUFBO29CQUtGLElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLE1BQU0sQ0FBQyxDQUFDO29CQUMvRCxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBRXRCLFFBQVEsR0FBRyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQ3RELENBQUM7b0JBQ0QsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEdBQUcsUUFBUSxDQUFDO29CQUd4QyxJQUFJLEdBQUcsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUMsQ0FBQztvQkFDekQsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7d0JBQ2YsR0FBRyxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDdkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsR0FBRyxDQUFDO29CQUVqQyxJQUFJLE1BQU0sR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUMsQ0FBQztvQkFDNUQsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7d0JBQ2xCLE1BQU0sR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQ2hELElBQUksQ0FBQyxDQUFDO29CQUVOLENBQUM7b0JBQ0QsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsR0FBRyxNQUFNLENBQUM7b0JBQzFDLElBQUksQ0FBQyxPQUFPLEdBQUcsaUJBQWlCLENBQUM7b0JBQ2pDLElBQUksQ0FBQyxZQUFZLEdBQUcsb0JBQW9CLENBQUM7b0JBQ3pDLElBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSyxDQUFDO29CQUM3QixZQUFZLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO29CQUMvQixJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBRyxZQUFZLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztvQkFDcEQsSUFBSSxDQUFDLFVBQVUsR0FBRyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUM7b0JBQzFDLElBQUksQ0FBQyxPQUFPLEdBQUcsZ0JBQWdCLENBQUMsT0FBTyxDQUFDO29CQUN4QyxJQUFJLENBQUMsUUFBUSxHQUFHLGdCQUFnQixDQUFDLFFBQVEsQ0FBQztvQkFDMUMsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDO29CQUV0Qyx5REFBeUQ7b0JBQ3pELDZCQUE2QjtnQkFFakMsQ0FBQztnQkEzRU8seUNBQWlCLEdBQXpCO29CQUVJLE1BQU0sQ0FBQyxJQUFJLENBQUM7Z0JBQ2hCLENBQUM7Z0JBNEVELDJDQUFtQixHQUFuQixVQUFvQixHQUFHO29CQUNuQixPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUNqQixJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsR0FBRyxHQUFHLENBQUM7b0JBQ2pDLG9DQUFvQztvQkFDbkMsdUJBQXVCO2dCQUMzQixDQUFDO2dCQUVNLG9DQUFZLEdBQXBCLFVBQXFCLE9BQVk7b0JBQWpDLGlCQXNERTtvQkFwREUsSUFBSSxPQUFPLEdBQUcsT0FBTyxDQUFDLGdCQUFnQixDQUFDO29CQUV4QyxrRUFBa0U7b0JBRy9ELFlBQVk7b0JBQ2QsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLHlCQUF5QixJQUFJLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUM7d0JBQ3pELGlDQUFpQzt3QkFDakMsTUFBTSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUM7b0JBQzlCLENBQUM7b0JBQ0wsSUFBSSxDQUFDLENBQUM7d0JBQ0YsMkVBQTJFO3dCQUN2RSxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzs0QkFDakMsSUFBSSxDQUFDLHlCQUF5QixHQUFHLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQzs0QkFDNUQseUNBQXlDOzRCQUN2QyxxQkFBcUI7NEJBQ2pCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO2dDQUNoRSxZQUFZO2dDQUNYLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dDQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7b0NBQzNCLHlCQUF5QjtvQ0FDekIsT0FBTyxDQUFDLEtBQUssQ0FBQyxFQUFDLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTt3Q0FDdEMsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO3dDQUN6QixPQUFPLEVBQUU7NENBQ0wsRUFBRSxFQUFFO2dEQUNBLGNBQWM7Z0RBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTOzZDQUM1Qjt5Q0FDSjtxQ0FDSixDQUFDLENBQUM7Z0NBQ1AsQ0FBQztnQ0FDRCxJQUFJLENBQUMsQ0FBQztvQ0FDRixPQUFPLENBQUMsWUFBWSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7Z0NBR3pDLENBQUM7NEJBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSztnQ0FDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDOzRCQUN2QixDQUFDLEVBQUU7Z0NBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTs0QkFDaEMsQ0FBQyxDQUFDLENBQUM7NEJBQ1IsV0FBVzs0QkFFVixJQUFJLENBQUMsYUFBYSxHQUFHLE9BQU8sQ0FBQyxZQUFZLENBQUM7d0JBQzlDLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsSUFBSSxDQUFDLGFBQWEsR0FBRyxFQUFFLENBQUM7d0JBQzVCLENBQUM7d0JBQ0QsTUFBTSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUM7b0JBQzlCLENBQUM7Z0JBR1IsQ0FBQztnQkFFTyxpREFBeUIsR0FBakMsVUFBa0MsQ0FBVTtvQkFDeEMsSUFBSSxDQUFDLG1CQUFtQixHQUFHLENBQUMsQ0FBQztnQkFDakMsQ0FBQztnQkFFTyxtREFBMkIsR0FBbkMsVUFBb0MsQ0FBVTtvQkFDMUMsSUFBSSxDQUFDLGtCQUFrQixHQUFHLEtBQUssQ0FBQztvQkFDaEMsSUFBSSxDQUFDLHFCQUFxQixHQUFHLENBQUMsQ0FBQztnQkFDbkMsQ0FBQztnQkFDTyw0Q0FBb0IsR0FBNUIsVUFBNkIsQ0FBTTtvQkFBbkMsaUJBOEZDO29CQTdGRyxJQUFJLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDO29CQUMvQixPQUFPLENBQUMsR0FBRyxDQUFDLHFCQUFtQixDQUFDLENBQUMsSUFBTSxDQUFDLENBQUM7b0JBQ3pDLElBQUksUUFBUSxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUNsQyxZQUFZO29CQUNYLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksU0FBUyxJQUFJLENBQUMsQ0FBQyxJQUFJLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzt3QkFDeEQscUJBQXFCO3dCQUNyQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsa0JBQWtCLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTs0QkFDM0UsV0FBVzs0QkFDWCxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzs0QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO2dDQUMzQix5QkFBeUI7Z0NBQ3pCLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBQyxPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07b0NBQ25DLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtvQ0FDNUIsT0FBTyxFQUFFO3dDQUNMLEVBQUUsRUFBRTs0Q0FDQSxjQUFjOzRDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUzt5Q0FDNUI7cUNBQ0o7aUNBQ0osQ0FBQyxDQUFDOzRCQUNQLENBQUM7NEJBQ0QsSUFBSSxDQUFDLENBQUM7Z0NBQ0YsS0FBSSxDQUFDLFVBQVUsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO2dDQUNqQyxvQ0FBb0M7Z0NBQ25DLEtBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsY0FBYyxDQUFDO2dDQUM3RCxLQUFJLENBQUMsaUJBQWlCLEdBQUcsS0FBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsZ0JBQWdCLENBQUM7Z0NBQ25FLEtBQUksQ0FBQyxPQUFPLEdBQUcsb0JBQW9CLENBQUM7Z0NBQ3BDLEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO29DQUM3QyxLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxDQUFDLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsS0FBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUE7Z0NBQzNHLENBQUM7Z0NBQ0QsSUFBSSxDQUFDLENBQUM7b0NBQ0YsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRTt3Q0FDeEMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsSUFBSSxHQUFHLENBQUMsQ0FBQyxDQUFDOzRDQUUxQixJQUFJLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQzt3Q0FFN0IsQ0FBQzt3Q0FDRCxJQUFJLENBQUMsQ0FBQzs0Q0FDRixJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQzt3Q0FDNUIsQ0FBQztvQ0FDTCxDQUFDLENBQUMsQ0FBQztnQ0FDUCxDQUFDO2dDQUNELEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO29DQUM3QyxJQUFJLElBQUksR0FBRyxFQUFFLENBQUM7b0NBQ2QsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsV0FBVyxFQUFFO3dDQUMxQixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLFdBQVcsQ0FBQyxDQUFDLENBQUM7NENBRTNCLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDOzRDQUNsQixNQUFNLENBQUMsS0FBSyxDQUFDO3dDQUNqQixDQUFDO29DQUNMLENBQUMsQ0FBQyxDQUFDO29DQUVILEtBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLENBQUMsRUFBRSxXQUFXLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUUsUUFBUSxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztnQ0FHcEksQ0FBQztnQ0FDRCxFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO29DQUNoRCxJQUFJLEtBQUssR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDO29DQUUvQyxJQUFJLEtBQUssR0FBRyxLQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxPQUFPLENBQUMsQ0FBQztvQ0FDN0QsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7d0NBQ2pCLEtBQUssR0FBRyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7b0NBQzdDLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQztvQ0FDZCxJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUM7b0NBQ3RCLEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxJQUFJLEVBQUUsSUFBSSxLQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sSUFBSSxTQUFTLElBQUksS0FBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzt3Q0FDM0csUUFBUSxHQUFHLE1BQU0sQ0FBQztvQ0FDdEIsQ0FBQztvQ0FDRCxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUksQ0FBQyxhQUFhLEVBQUU7d0NBQzVCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksUUFBUSxDQUFDLENBQUMsQ0FBQzs0Q0FDeEIsSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7NENBQ2xCLE1BQU0sQ0FBQyxLQUFLLENBQUM7d0NBQ2pCLENBQUM7b0NBQ0wsQ0FBQyxDQUFDLENBQUM7b0NBRUgsS0FBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsR0FBRyxDQUFDLEVBQUUsTUFBTSxFQUFFLEVBQUUsRUFBRSxPQUFPLEVBQUUsRUFBRSxFQUFFLFFBQVEsRUFBRSxFQUFFLEVBQUUsR0FBRyxFQUFFLEVBQUUsRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLE9BQU8sRUFBRSxFQUFFLEVBQUUsYUFBYSxFQUFFLElBQUksRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDO2dDQUMzTCxDQUFDO2dDQUVELEtBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxHQUFHLEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztnQ0FDM0QsS0FBSSxDQUFDLGVBQWUsR0FBRyxLQUFLLENBQUM7Z0NBQzdCLHVCQUF1QjtnQ0FDdkIsMkJBQTJCO2dDQUMzQixLQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7Z0NBQ3ZCLEtBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDO2dDQUN0QixtQkFBbUI7Z0NBQ25CLGtCQUFrQjtnQ0FDbEIsS0FBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsQ0FBQzs0QkFDN0IsQ0FBQzt3QkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLOzRCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7d0JBQ3ZCLENBQUMsRUFBRTs0QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO3dCQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFDUCxDQUFDO2dCQUNMLENBQUM7Z0JBQ0QsbUNBQVcsR0FBWDtvQkFDSSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDN0csSUFBSSxNQUFNLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUM7d0JBQ3hDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7NEJBQ2YsUUFBUSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsVUFBVSxHQUFHLG1CQUFtQixHQUFHLE1BQU0sQ0FBQzt3QkFDdkUsQ0FBQztvQkFDTCxDQUFDO2dCQUNMLENBQUM7Z0JBQ0Qsc0NBQWMsR0FBZDtvQkFDSSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDN0csSUFBSSxNQUFNLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUM7d0JBQ3hDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7NEJBQ2YsSUFBSSxJQUFJLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQzs0QkFDOUMsUUFBUSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsVUFBVSxHQUFHLGdCQUFnQixHQUFHLElBQUksR0FBRyxHQUFHLEdBQUcsTUFBTSxDQUFDO3dCQUNqRixDQUFDO29CQUNMLENBQUM7Z0JBQ0wsQ0FBQztnQkFDRCw0Q0FBb0IsR0FBcEI7b0JBQUEsaUJBeUZDO29CQXhGRyxJQUFJLENBQUMsWUFBWSxHQUFHLFVBQVUsQ0FBQztvQkFDL0IsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGlCQUFpQixFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFDeEQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDdEIsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBR3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQ3RELE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCLEVBQUUsRUFBQyxDQUFDLENBQUM7d0JBQ2xCLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsV0FBVzs0QkFDWCxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxJQUFJLFNBQVMsSUFBSSxRQUFRLENBQUMsSUFBSSxJQUFJLElBQUksSUFBSSxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUNuRixJQUFJLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQztnQ0FDaEIsRUFBRSxDQUFDLENBQUMsS0FBSSxDQUFDLGNBQWMsSUFBSSxTQUFTLElBQUksS0FBSSxDQUFDLGNBQWMsQ0FBQyxVQUFVLElBQUksU0FBUyxJQUFJLEtBQUksQ0FBQyxjQUFjLENBQUMsVUFBVSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7b0NBQ3pILE1BQU0sR0FBRyxLQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQTtnQ0FDM0MsQ0FBQztnQ0FDRCxFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsVUFBVSxJQUFJLFNBQVMsSUFBSSxLQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxTQUFTLElBQUksS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztvQ0FDN0csTUFBTSxHQUFHLEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFBO2dDQUN2QyxDQUFDO2dDQUNELEVBQUUsQ0FBQyxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7b0NBQ2YsUUFBUSxDQUFDLFFBQVEsR0FBRyxLQUFJLENBQUMsVUFBVSxHQUFHLGVBQWUsR0FBRyxNQUFNLEdBQUcsR0FBRyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO2dDQUNsRyxDQUFDO2dDQUNELElBQUksQ0FBQyxDQUFDO29DQUVGLE9BQU8sQ0FBQyxLQUFLLENBQUM7d0NBQ1YsT0FBTyxFQUFFLGtGQUFrRjt3Q0FDM0YsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO3dDQUM1QixPQUFPLEVBQUU7NENBQ0wsRUFBRSxFQUFFO2dEQUNBLGNBQWM7Z0RBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTOzZDQUM1Qjt5Q0FFSjtxQ0FDSixDQUFDLENBQUM7Z0NBQ1AsQ0FBQzs0QkFDTCxDQUFDOzRCQUNELElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxJQUFJLFNBQVMsSUFBSSxRQUFRLENBQUMsSUFBSSxJQUFJLElBQUksSUFBSSxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUN2RixXQUFXO2dDQUNYLElBQUksTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDO2dDQUNoQixFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsY0FBYyxJQUFJLFNBQVMsSUFBSSxLQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsSUFBSSxTQUFTLElBQUksS0FBSSxDQUFDLGNBQWMsQ0FBQyxVQUFVLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztvQ0FDekgsTUFBTSxHQUFHLEtBQUksQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFBO2dDQUMzQyxDQUFDO2dDQUNELEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxVQUFVLElBQUksU0FBUyxJQUFJLEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLFNBQVMsSUFBSSxLQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO29DQUM3RyxNQUFNLEdBQUcsS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUE7Z0NBQ3ZDLENBQUM7Z0NBQ0QsRUFBRSxDQUFDLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQ0FDZixRQUFRLENBQUMsUUFBUSxHQUFHLEtBQUksQ0FBQyxVQUFVLEdBQUcsaUJBQWlCLEdBQUcsTUFBTSxDQUFDO2dDQUNyRSxDQUFDO2dDQUNELElBQUksQ0FBQyxDQUFDO29DQUNGLE9BQU8sQ0FBQyxLQUFLLENBQUM7d0NBQ1YsT0FBTyxFQUFFLGtGQUFrRjt3Q0FDM0YsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO3dDQUM1QixPQUFPLEVBQUU7NENBQ0wsRUFBRSxFQUFFO2dEQUNBLGNBQWM7Z0RBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTOzZDQUM1Qjt5Q0FDSjtxQ0FDSixDQUFDLENBQUM7Z0NBQ1AsQ0FBQzs0QkFFTCxDQUFDOzRCQUNELElBQUksQ0FBQyxDQUFDO2dDQUNGLE9BQU8sQ0FBQyxLQUFLLENBQUM7b0NBQ1YsT0FBTyxFQUFFLEtBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLG9CQUFvQjtvQ0FDdEQsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO29DQUM1QixPQUFPLEVBQUU7d0NBQ0wsRUFBRSxFQUFFOzRDQUNBLGNBQWM7NENBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3lDQUM1QixFQUFDO2lDQUNULENBQUMsQ0FBQzs0QkFDUCxDQUFDO3dCQUNMLENBQUM7d0JBQ0QsS0FBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7d0JBQ3BCLEtBQUksQ0FBQyxHQUFHLEdBQUcsUUFBUSxDQUFDLE1BQU0sQ0FBQztvQkFDL0IsQ0FBQyxFQUNHLFVBQUEsS0FBSyxJQUFHLE9BQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBbEIsQ0FBa0IsRUFDMUIsY0FBTSxPQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsc0JBQXNCLENBQUMsRUFBbkMsQ0FBbUMsQ0FDNUMsQ0FBQztvQkFDRixJQUFJLENBQUMsWUFBWSxHQUFHLEVBQUUsQ0FBQztnQkFDM0IsQ0FBQztnQkFDRCxpQ0FBUyxHQUFUO29CQUNJLE9BQU8sQ0FBQyxLQUFLLENBQUM7d0JBQ1YsT0FBTyxFQUFFLGlCQUFpQixHQUFHLElBQUksQ0FBQyxXQUFXLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxZQUFZO3dCQUMzRSxPQUFPLEVBQUU7NEJBQ0wsRUFBRSxFQUFFO2dDQUNBLGNBQWM7Z0NBQ2QsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTOzZCQUM1Qjt5QkFDSjtxQkFDSixDQUFDLENBQUM7b0JBQ0gsWUFBWSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztnQkFDbkMsQ0FBQztnQkFDRCxzQ0FBYyxHQUFkO29CQUFBLGlCQWdJQztvQkEvSEcsUUFBUSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsVUFBVSxHQUFHLGlCQUFpQixDQUFDO29CQUN4RCxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQztvQkFDNUIsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7b0JBRXJCLElBQUksS0FBSyxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUM7b0JBQy9DLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxFQUFFLENBQUM7b0JBRTNCLElBQUksQ0FBQyxVQUFVLEdBQUcsRUFBRSxDQUFDO29CQUNyQixJQUFJLENBQUMsYUFBYSxHQUFHLGlCQUFpQixDQUFDO29CQUN2QyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsR0FBRyxFQUFFLENBQUM7b0JBQy9CLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLENBQUMsQ0FBQyxDQUFDO29CQUNoQyxJQUFJLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztvQkFDckIsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7b0JBQ3pCLElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLE1BQU0sQ0FBQyxDQUFDO29CQUMvRCxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQzt3QkFDcEIsUUFBUSxHQUFHLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDdEQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEdBQUcsUUFBUSxDQUFDO29CQUN4QyxJQUFJLEdBQUcsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUMsQ0FBQztvQkFDekQsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7d0JBQ2YsR0FBRyxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDdkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsR0FBRyxDQUFDO29CQUNqQyxJQUFJLE1BQU0sR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUMsQ0FBQztvQkFDNUQsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7d0JBQ2xCLE1BQU0sR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQ2hELElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLEdBQUcsTUFBTSxDQUFDO29CQUUxQyxJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQztvQkFDdEIsOEJBQThCO29CQUM5QixJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGdCQUFnQixDQUFDO29CQUM5RCxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLFlBQVksQ0FBQztvQkFDM0QsSUFBSSxDQUFDLE9BQU8sR0FBRyxpQkFBaUIsQ0FBQztvQkFDakMsSUFBSSxDQUFDLGlCQUFpQixHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGdCQUFnQixDQUFDO29CQUNuRSxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztvQkFDdkIsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO29CQUN0QiwrREFBK0Q7b0JBSS9ELElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQztvQkFDZCxJQUFJLEdBQUcsR0FBRyxDQUFDLENBQUM7b0JBQ1osSUFBSSxPQUFPLEdBQUcsQ0FBQyxDQUFDO29CQUNoQixJQUFJLFFBQVEsR0FBRyxDQUFDLENBQUM7b0JBQ2pCLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRTt3QkFDMUIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxXQUFXLENBQUMsQ0FBQyxDQUFDOzRCQUUzQixJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQzs0QkFDbEIsR0FBRyxHQUFHLENBQUMsQ0FBQzs0QkFDUixPQUFPLEdBQUcsQ0FBQyxDQUFDOzRCQUNaLFFBQVEsR0FBRyxDQUFDLENBQUM7NEJBQ2IsTUFBTSxDQUFDLEtBQUssQ0FBQzt3QkFDakIsQ0FBQztvQkFDTCxDQUFDLENBQUMsQ0FBQztvQkFFSCxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxDQUFDLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFLFFBQVEsRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFFLE9BQU8sRUFBRSxDQUFDLENBQUE7b0JBQ3ZJLFdBQVc7b0JBRVgsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsQ0FBQyxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFBO29CQUN0RyxJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxPQUFPLENBQUMsQ0FBQztvQkFDakUsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7d0JBQ3JCLFNBQVMsR0FBRyxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBRXpELElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQztvQkFDZCxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUU7d0JBQzVCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksTUFBTSxDQUFDLENBQUMsQ0FBQzs0QkFFdEIsSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7NEJBQ2xCLE1BQU0sQ0FBQyxLQUFLLENBQUM7d0JBQ2pCLENBQUM7b0JBRUwsQ0FBQyxDQUFDLENBQUM7b0JBR0gsSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsR0FBRyxDQUFDLEVBQUUsTUFBTSxFQUFFLEVBQUUsRUFBRSxPQUFPLEVBQUUsRUFBRSxFQUFFLFFBQVEsRUFBRSxFQUFFLEVBQUUsR0FBRyxFQUFFLEVBQUUsRUFBRSxXQUFXLEVBQUUsU0FBUyxFQUFFLE9BQU8sRUFBRSxFQUFFLEVBQUUsYUFBYSxFQUFFLElBQUksRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFBO29CQUMxTCxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxFQUFFLENBQUM7b0JBQ3BDLElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxHQUFHLEVBQUUsQ0FBQztvQkFDOUIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLEdBQUcsRUFBRSxDQUFDO29CQUMxQixJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7b0JBQzdCLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxHQUFHLEdBQUcsQ0FBQztvQkFDN0IsSUFBSSxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7b0JBQ3JCLElBQUksQ0FBQyxHQUFHLEdBQUcsRUFBRSxDQUFDO29CQUNkLElBQUksQ0FBQyxTQUFTLEdBQUcsS0FBSyxDQUFDO29CQUN2QixJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFNBQVMsQ0FDNUQsVUFBQyxJQUFJO3dCQUNELFlBQVk7d0JBQ1osRUFBRSxDQUFDLENBQUMsS0FBSSxDQUFDLFNBQVMsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDOzRCQUMxQixNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDOzRCQUN2QyxJQUFJLEdBQUcsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQTs0QkFDckMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLGFBQWEsQ0FBQztnQ0FDL0IsWUFBWSxFQUFFLElBQUk7Z0NBQ2xCLFVBQVUsRUFBRSxFQUVYO2dDQUNELEtBQUssRUFBRSxVQUFVLENBQUM7b0NBQ2QsSUFBSSxDQUFDLFVBQVUsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO29DQUV6QixJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7Z0NBQ25FLENBQUM7Z0NBQ0QsNEJBQTRCO2dDQUM1QixVQUFVLEVBQUUsR0FBRzs2QkFDbEIsQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQzs0QkFDeEMsSUFBSSxHQUFHLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUE7NEJBQ3JDLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQyxhQUFhLENBQUM7Z0NBQ2hDLFlBQVksRUFBRSxJQUFJO2dDQUNsQixVQUFVLEVBQUUsRUFFWDtnQ0FDRCxLQUFLLEVBQUUsVUFBVSxDQUFDO29DQUNkLElBQUksQ0FBQyxVQUFVLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztvQ0FFekIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO2dDQUNuRSxDQUFDO2dDQUNELFVBQVUsRUFBRSxHQUFHOzZCQUNsQixDQUFDLENBQUM7d0JBQ1AsQ0FBQztvQkFDTCxDQUFDLEVBQ0QsVUFBQyxHQUFHO29CQUVKLENBQUMsRUFDRDtvQkFFQSxDQUFDLENBQ0osQ0FBQztvQkFFRixJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQztnQkFDeEIsQ0FBQztnQkFDRCx1Q0FBZSxHQUFmO29CQUNJLElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDO29CQUM1QixJQUFJLENBQUMsZUFBZSxHQUFHLEtBQUssQ0FBQztvQkFDN0IsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7b0JBQ3JCLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztvQkFDNUIsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO29CQUM1QixJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGNBQWMsQ0FBQztvQkFDL0QsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLElBQUksSUFBSSxRQUFRLENBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsR0FBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQzdILE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO3dCQUNoQyxJQUFJLENBQUMsWUFBWSxHQUFHLG9CQUFvQixDQUFDO3dCQUN6QyxNQUFNLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztvQkFDdEMsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixNQUFNLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQzt3QkFDaEMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ3RDLENBQUM7Z0JBQ0wsQ0FBQztnQkFFRCx5Q0FBaUIsR0FBakI7b0JBQUEsaUJBb0ZDO29CQWxGRyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUM7d0JBQ2hDLElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDO3dCQUM1QixNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7d0JBQzVCLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQzt3QkFDNUIsSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7d0JBQ3RCLElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsa0JBQWtCLENBQUM7d0JBQ3BFLHFDQUFxQzt3QkFDcEMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLElBQUksSUFBSSxRQUFRLENBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsR0FBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7NEJBQzdILE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDOzRCQUNoQyxJQUFJLENBQUMsWUFBWSxHQUFHLGtCQUFrQixDQUFDOzRCQUN2QyxNQUFNLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQzt3QkFDdEMsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixNQUFNLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQzs0QkFDaEMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7d0JBQ3RDLENBQUM7b0JBQ0wsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixJQUFJLENBQUMsZUFBZSxHQUFHLEtBQUssQ0FBQzt3QkFDN0IsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO3dCQUM1QixNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7d0JBQzVCLElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsY0FBYyxDQUFDO3dCQUUvRCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksSUFBSSxJQUFJLFFBQVEsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs0QkFDM0gsTUFBTSxDQUFDLGdCQUFnQixDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7NEJBQ2hDLElBQUksQ0FBQyxZQUFZLEdBQUcsb0JBQW9CLENBQUM7NEJBQ3pDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDOzRCQUVsQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsUUFBUSxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUM7Z0NBQ2xJLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO29DQUNuRyxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQztvQ0FDdEMsaUJBQWlCO29DQUNqQixFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7d0NBQzNCLHlCQUF5Qjt3Q0FDekIsT0FBTyxDQUFDLEtBQUssQ0FBQzs0Q0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7NENBQ3RELE9BQU8sRUFBRTtnREFDTCxFQUFFLEVBQUU7b0RBQ0EsY0FBYztvREFDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7aURBQzVCOzZDQUNKO3lDQUNKLENBQUMsQ0FBQztvQ0FDUCxDQUFDO29DQUNELDRCQUE0QjtvQ0FDNUIsT0FBTyxDQUFDLEtBQUssQ0FBQzt3Q0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7d0NBQ3RELE9BQU8sRUFBRTs0Q0FDTCxFQUFFLEVBQUU7Z0RBQ0EsY0FBYztnREFDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7NkNBQzVCO3lDQUNKO3FDQUNKLENBQUMsQ0FBQztvQ0FDSCxLQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQztvQ0FDckIsR0FBRztvQ0FDSCxRQUFRO29DQUVSLEdBQUc7Z0NBQ1AsQ0FBQyxDQUFDLENBQUM7NEJBQ1AsQ0FBQzs0QkFDRCxJQUFJLENBQUMsQ0FBQztnQ0FDRixPQUFPLENBQUMsS0FBSyxDQUFDO29DQUNWLE9BQU8sRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxlQUFlLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxZQUFZO29DQUMvRSxPQUFPLEVBQUU7d0NBQ0wsRUFBRSxFQUFFOzRDQUNBLGNBQWM7NENBQ2QsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO3lDQUM1QjtxQ0FDSjtpQ0FDSixDQUFDLENBQUM7Z0NBQ0gsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO2dDQUNsQixJQUFJLENBQUMsZUFBZSxHQUFHLEtBQUssQ0FBQztnQ0FDN0IsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7NEJBQzdCLENBQUM7d0JBQ0wsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixNQUFNLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQzs0QkFDaEMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7d0JBQ3RDLENBQUM7b0JBQ0wsQ0FBQztnQkFFTCxDQUFDO2dCQUNELG9DQUFZLEdBQVo7b0JBQ0ksRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7d0JBQ3hFLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDOzRCQUM1QyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDO3dCQUNqSCxDQUFDO29CQUNMLENBQUM7Z0JBQ0wsQ0FBQztnQkFDRCw2Q0FBcUIsR0FBckI7Z0JBRUEsQ0FBQztnQkFDRCxzQ0FBYyxHQUFkO29CQUNJLFVBQVU7b0JBQ1YsV0FBVztnQkFFZixDQUFDO2dCQUVELHlDQUFpQixHQUFqQjtvQkFFSSxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7b0JBQ2xCLElBQUksQ0FBQyxvQ0FBb0MsRUFBRSxDQUFDO29CQUM1QyxJQUFJLElBQUksR0FBRyxFQUFFLENBQUM7b0JBQ2QsSUFBSSxNQUFNLEdBQUcsTUFBTSxDQUFDO29CQUVwQixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQzt3QkFDeEUsTUFBTSxHQUFHLE1BQU0sQ0FBQztvQkFFcEIsQ0FBQztvQkFDRCxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUU7d0JBQzVCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksTUFBTSxDQUFDLENBQUMsQ0FBQzs0QkFDdEIsSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7NEJBQ2xCLE1BQU0sQ0FBQyxLQUFLLENBQUM7d0JBQ2pCLENBQUM7b0JBRUwsQ0FBQyxDQUFDLENBQUM7b0JBRUgsSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO2dCQUN6RyxDQUFDO2dCQUNELGtDQUFVLEdBQVY7b0JBRUksRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUM7d0JBQ3RFLFdBQVc7d0JBQ1gsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLElBQUksU0FBUyxDQUFFLENBQUMsQ0FBRCxDQUFDOzRCQUN6RSxJQUFJLFVBQVUsR0FBRyxFQUFFLENBQUM7NEJBQ3BCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUM7Z0NBQ3pJLFVBQVUsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUM7NEJBRXJFLENBQUM7NEJBQ0QsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssSUFBSSxTQUFTLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUNoSixVQUFVLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDOzRCQUM3QyxDQUFDOzRCQUNELElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssSUFBSSxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQ2xKLFVBQVUsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssR0FBRyxHQUFHLENBQUM7NEJBQzdDLENBQUM7NEJBQ0QsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsVUFBVSxDQUFDO3dCQUN4QyxDQUFDO3dCQUNELElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssSUFBSSxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7NEJBQ2xKLElBQUksVUFBVSxHQUFHLEVBQUUsQ0FBQzs0QkFDcEIsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUMxRSxVQUFVLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUM7NEJBQ3pDLENBQUM7NEJBQ0QsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsVUFBVSxDQUFDO3dCQUN4QyxDQUFDO3dCQUNELElBQUk7NEJBQ0EsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxHQUFHLElBQUksR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxxQkFBcUI7d0JBQzlJLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDOzRCQUM1QyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDO3dCQUNqSCxDQUFDO29CQUNMLENBQUM7b0JBQ0QsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO2dCQUN4QixDQUFDO2dCQUNELGlDQUFTLEdBQVQ7b0JBQ0ksc0VBQXNFO29CQUN0RSxJQUFJLE1BQU0sR0FBRyxLQUFLLENBQUM7b0JBQ25CLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzt3QkFDekIsTUFBTSxHQUFHLEtBQUssQ0FBQTt3QkFDZCxJQUFJLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQztvQkFDM0IsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQzt3QkFDdEIsTUFBTSxHQUFHLElBQUksQ0FBQztvQkFDbEIsQ0FBQztvQkFFRCxJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUMvQixDQUFDO2dCQUNELHdDQUFnQixHQUFoQjtvQkFBQSxpQkFvSkM7b0JBbkpHLFdBQVc7b0JBQ1gsSUFBSSxDQUFDLFlBQVksR0FBRyxVQUFVLENBQUM7b0JBQy9CLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO29CQUN2QixJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztvQkFFekIsSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO29CQUVkLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzt3QkFDOUYsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixFQUFFOzRCQUMzQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7Z0NBQzNCLEtBQUssR0FBRyxLQUFLLEdBQUcsQ0FBQyxDQUFDOzRCQUN0QixDQUFDOzRCQUNELEVBQUUsQ0FBQyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUNaLG1EQUFtRDtnQ0FFbkQsSUFBSSxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUM7Z0NBQ3ZCLElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO2dDQUN4QixNQUFNLENBQUMsS0FBSyxDQUFDOzRCQUNqQixDQUFDO3dCQUNMLENBQUMsQ0FBQyxDQUFDO29CQUNQLENBQUM7b0JBQ0QsbUNBQW1DO29CQUNuQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO3dCQUNsQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsWUFBWSxFQUFFLElBQUksQ0FBQyxDQUFDLE9BQU8sRUFBRSxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUM7NEJBQzNFLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBRSxPQUFPLEVBQUUsd0JBQXdCLEVBQUUsQ0FBQyxDQUFDOzRCQUVyRCxJQUFJLENBQUMsWUFBWSxHQUFHLEVBQUUsQ0FBQzs0QkFDdkIsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7NEJBQ3hCLE1BQU0sQ0FBQyxLQUFLLENBQUM7d0JBQ2pCLENBQUM7b0JBQ0wsQ0FBQztvQkFDRCxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssR0FBRyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUM7b0JBQy9DLEVBQUUsQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO3dCQUU1RyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDeEYsSUFBSSxNQUFNLEdBQUcsRUFBRSxDQUFDOzRCQUNoQixNQUFNLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0NBQzdCLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7NEJBQ3BDLENBQUMsQ0FBQyxDQUFDOzRCQUNILElBQUksTUFBTSxHQUFHLEVBQUUsQ0FBQzs0QkFDaEIsTUFBTSxDQUFDLG1CQUFtQixDQUFDLENBQUMsSUFBSSxDQUFDO2dDQUM3QixNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDOzRCQUNwQyxDQUFDLENBQUMsQ0FBQzs0QkFDSCxJQUFJLE9BQU8sR0FBRyxFQUFFLENBQUM7NEJBQ2pCLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLElBQUksQ0FBQztnQ0FDOUIsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQzs0QkFDckMsQ0FBQyxDQUFDLENBQUM7NEJBQ0gsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDOzRCQUNWLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUU7Z0NBQ3hDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQztvQ0FDckIsSUFBSSxDQUFDLEtBQUssR0FBRyxHQUFHLENBQUM7Z0NBQ3JCLENBQUM7Z0NBQ0QsSUFBSSxDQUFDLENBQUM7b0NBQ0YsSUFBSSxDQUFDLEtBQUssR0FBRyxHQUFHLENBQUM7Z0NBQ3JCLENBQUM7Z0NBQ0QsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO29DQUN6QixJQUFJLENBQUMsU0FBUyxHQUFHLEdBQUcsQ0FBQztnQ0FDekIsQ0FBQztnQ0FDRCxJQUFJLENBQUMsQ0FBQztvQ0FDRixJQUFJLENBQUMsU0FBUyxHQUFHLEdBQUcsQ0FBQztnQ0FDekIsQ0FBQztnQ0FDRCxJQUFJLENBQUMsS0FBSyxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDdkIsSUFBSSxDQUFDLElBQUksR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQ3RCLElBQUksQ0FBQyxNQUFNLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUN6QixDQUFDLEVBQUUsQ0FBQztnQ0FDSix5Q0FBeUM7Z0NBQ3pDLHVDQUF1QztnQ0FDdkMsMkJBQTJCOzRCQUMvQixDQUFDLENBQUMsQ0FBQzt3QkFFUCxDQUFDO3dCQUNELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUN4RixNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxFQUFFO2dDQUN4QyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7b0NBQ3ZCLElBQUksQ0FBQyxPQUFPLEdBQUcsR0FBRyxDQUFDO2dDQUN2QixDQUFDO2dDQUNELElBQUksQ0FBQyxDQUFDO29DQUNGLElBQUksQ0FBQyxPQUFPLEdBQUcsR0FBRyxDQUFDO2dDQUN2QixDQUFDO2dDQUNGLFlBQVk7Z0NBQ1gsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO29DQUMzQixJQUFJLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQztnQ0FDN0IsQ0FBQztnQ0FDRCxJQUFJLENBQUMsQ0FBQztvQ0FDRixJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQztnQ0FDNUIsQ0FBQztnQ0FFRCxDQUFDLEVBQUUsQ0FBQzs0QkFDUixDQUFDLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO3dCQUM1QyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFBO3dCQUNsQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxDQUFDLGVBQWUsQ0FBQyxDQUFDO3dCQUNwRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7NEJBQ3ZELE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUM7NEJBQ3RCLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDOzRCQUN0QyxLQUFJLENBQUMsWUFBWSxHQUFHLEVBQUUsQ0FBQzs0QkFDdkIsS0FBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7NEJBRXhCLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQztnQ0FDM0IseUJBQXlCO2dDQUN6QixLQUFJLENBQUMsUUFBUSxHQUFHLGFBQWEsQ0FBQzs0QkFDbEMsQ0FBQzs0QkFDRCxJQUFJLENBQUMsQ0FBQztnQ0FDRix5QkFBeUI7Z0NBRXpCLEtBQUksQ0FBQyxRQUFRLEdBQUcsY0FBYyxDQUFDO2dDQUMvQixJQUFJLEtBQUssR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDO2dDQUMvQyxLQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxNQUFNLEVBQUUsS0FBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEVBQUUsRUFBRSxDQUFDLENBQUM7Z0NBQ2xGLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLEtBQUssRUFBRSxLQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsRUFBRSxFQUFFLENBQUMsQ0FBQztnQ0FDL0UsS0FBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsS0FBSyxFQUFFLEtBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLEVBQUUsRUFBRSxDQUFDLENBQUM7Z0NBQ3JGLEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsTUFBTSxHQUFDLENBQUMsQ0FBQztvQ0FDM0MsS0FBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsT0FBTyxFQUFFLEtBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsV0FBVyxFQUFFLEVBQUUsQ0FBQyxDQUFDO2dDQUN2SixZQUFZO2dDQUNYLDBEQUEwRDtnQ0FDMUQsV0FBVztnQ0FDWCxLQUFJLENBQUMsY0FBYyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7Z0NBQ3BDLEtBQUksQ0FBQyxVQUFVLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQztnQ0FDaEMsS0FBSSxDQUFDLFdBQVcsQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7NEJBUXRDLENBQUM7NEJBQ0QsS0FBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7NEJBQ3BCLEtBQUksQ0FBQyxHQUFHLEdBQUcsUUFBUSxDQUFDLE1BQU0sQ0FBQzt3QkFDL0IsQ0FBQyxFQUNHLFVBQUEsS0FBSyxJQUFHLE9BQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBbEIsQ0FBa0IsRUFDMUIsY0FBTSxPQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsc0JBQXNCLENBQUMsRUFBbkMsQ0FBbUMsQ0FDNUMsQ0FBQztvQkFDTixDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUNGLE9BQU8sQ0FBQyxLQUFLLENBQUM7NEJBQ1YsT0FBTyxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGlCQUFpQixFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsWUFBWTs0QkFDakYsT0FBTyxFQUFFO2dDQUNMLEVBQUUsRUFBRTtvQ0FDQSxjQUFjO29DQUNkLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUztpQ0FDNUI7NkJBQ0o7eUJBQ0osQ0FBQyxDQUFDO3dCQUNILElBQUksQ0FBQyxZQUFZLEdBQUcsRUFBRSxDQUFDO3dCQUN2QixJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztvQkFDNUIsQ0FBQztnQkFDTCxDQUFDO2dCQUVELDREQUFvQyxHQUFwQztvQkFBQSxpQkE4RUM7b0JBNUVPLG1GQUFtRjtvQkFDdkYsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO3dCQUN2QixJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQzt3QkFDNUMsV0FBVzt3QkFDWCxJQUFJLEtBQUssR0FBRyxFQUFFLENBQUM7d0JBQ2YsSUFBSSxLQUFLLEdBQUcsRUFBRSxDQUFDO3dCQUNmLElBQUksT0FBTyxHQUFHLEVBQUUsQ0FBQzt3QkFDakIsSUFBSSxNQUFNLEdBQUcsRUFBRSxDQUFDO3dCQUNoQixJQUFJLE1BQU0sR0FBRyxFQUFFLENBQUM7d0JBRWhCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLFNBQVMsQ0FBQzs0QkFDbkMsS0FBSyxHQUFHLEVBQUUsQ0FBQzt3QkFDZixJQUFJOzRCQUNBLEtBQUssR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQzt3QkFFbEMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLElBQUksU0FBUyxDQUFDOzRCQUNuQyxLQUFLLEdBQUcsRUFBRSxDQUFDO3dCQUNmLElBQUk7NEJBQ0EsS0FBSyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDO3dCQUNsQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sSUFBSSxTQUFTLENBQUM7NEJBQ3JDLE9BQU8sR0FBRyxFQUFFLENBQUM7d0JBQ2pCLElBQUk7NEJBQ0EsT0FBTyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDO3dCQUV0QyxNQUFNLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxJQUFJLENBQUM7NEJBRTdCLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLEVBQUUsSUFBSSxFQUFFLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsRUFBRSxJQUFJLFNBQVMsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxFQUFFLElBQUksSUFBSSxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDOUgsTUFBTSxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxLQUFLLENBQUM7NEJBQ3pDLENBQUM7d0JBQ0wsQ0FBQyxDQUFDLENBQUM7d0JBQ0gsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7NEJBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7d0JBQ3ZFLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUU7NEJBQ3hDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxLQUFLLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxLQUFLLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQzlGLE1BQU0sSUFBSSxJQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQzs0QkFDakMsQ0FBQzt3QkFFTCxDQUFDLENBQUMsQ0FBQzt3QkFDSCxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQzs0QkFBQyxNQUFNLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQzt3QkFDdkUsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLElBQUksRUFBRSxJQUFJLEtBQUssQ0FBQyxNQUFNLElBQUksQ0FBQyxJQUFJLEtBQUssSUFBSSxFQUFFLElBQUksS0FBSyxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUM7K0JBQ25FLENBQUMsT0FBTyxJQUFJLEVBQUUsSUFBSSxPQUFPLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQzsrQkFDdEMsQ0FBQyxNQUFNLElBQUksRUFBRSxDQUFDOytCQUNkLENBQUMsTUFBTSxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQzs0QkFFcEIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLHNCQUFzQixDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxNQUFNLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO2dDQUNsRyxXQUFXO2dDQUNYLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dDQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7b0NBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7d0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO3dDQUN0RCxPQUFPLEVBQUU7NENBQ0wsRUFBRSxFQUFFO2dEQUNBLGNBQWM7Z0RBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTOzZDQUM1Qjt5Q0FDSjtxQ0FDSixDQUFDLENBQUM7Z0NBQ1AsQ0FBQztnQ0FDRCxJQUFJLENBQUMsQ0FBQztvQ0FDRixLQUFJLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQztvQ0FDbkIsS0FBSSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO29DQUM5QixFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxJQUFJLElBQUksSUFBSSxRQUFRLENBQUMsSUFBSSxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUM7d0NBQ3RELEtBQUksQ0FBQyxjQUFjLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzt3Q0FDcEMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFBO29DQUdwQyxDQUFDO2dDQUVMLENBQUM7NEJBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSztnQ0FDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDOzRCQUN2QixDQUFDLEVBQUU7Z0NBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTs0QkFDaEMsQ0FBQyxDQUFDLENBQUM7d0JBQ1AsQ0FBQztvQkFDTCxDQUFDO29CQUNELG9CQUFvQjtnQkFDeEIsQ0FBQztnQkFDRCxxQ0FBYSxHQUFiO29CQUNJLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztvQkFDbEIsSUFBSSxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7Z0JBQ3pCLENBQUM7Z0JBQ0Qsa0NBQVUsR0FBVjtvQkFDSSxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsVUFBVSxFQUFFLENBQUM7b0JBQ2xDLE1BQU0sQ0FBQyxlQUFlLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFLENBQUMsQ0FBQztnQkFDdkQsQ0FBQztnQkFFRCwrQ0FBdUIsR0FBdkIsVUFBd0IsS0FBSyxFQUFFLEtBQUssRUFBQyxPQUFPO29CQUE1QyxpQkE4Q0M7b0JBN0NHLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO29CQUM1QyxXQUFXO29CQUNYLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLFNBQVMsQ0FBQzt3QkFDbkMsS0FBSyxHQUFHLEVBQUUsQ0FBQztvQkFDZixJQUFJO3dCQUNBLEtBQUssR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQztvQkFFbEMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLElBQUksU0FBUyxDQUFDO3dCQUNuQyxLQUFLLEdBQUcsRUFBRSxDQUFDO29CQUNmLElBQUk7d0JBQ0EsS0FBSyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDO29CQUNsQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sSUFBSSxTQUFTLENBQUM7d0JBQ3JDLE9BQU8sR0FBRyxFQUFFLENBQUM7b0JBQ2pCLElBQUk7d0JBQ0EsT0FBTyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDO29CQUN0QyxJQUFJLENBQUMsZ0JBQWdCLENBQUMscUJBQXFCLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUNqRixXQUFXO3dCQUNYLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUN0RCxPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQzs0QkFDbkIsS0FBSSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDOzRCQUM5QixFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxJQUFJLElBQUksSUFBSSxRQUFRLENBQUMsSUFBSSxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUM7Z0NBQ3RELEtBQUksQ0FBQyxjQUFjLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQztnQ0FDcEMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDOzRCQUVyQyxDQUFDO3dCQUVMLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsb0JBQW9CO2dCQUN4QixDQUFDO2dCQUtELDBDQUFrQixHQUFsQjtvQkFFSSxpQkFBaUI7b0JBQ2pCLHdFQUF3RTtvQkFDeEUsb0NBQW9DO29CQUNwQyw0RUFBNEU7b0JBQzVFLGlCQUFpQjtvQkFDakIsNENBQTRDO29CQUM1QyxxQ0FBcUM7b0JBQ3JDLGlDQUFpQztvQkFDakMsT0FBTztvQkFDUCxZQUFZO29CQUNaLDZCQUE2QjtvQkFDN0Isd0NBQXdDO29CQUN4QyxvRUFBb0U7b0JBQ3BFLGtEQUFrRDtvQkFDbEQsaURBQWlEO29CQUNqRCxXQUFXO29CQUNYLDRCQUE0QjtvQkFDNUIsT0FBTztvQkFDUCxjQUFjO29CQUNkLHlCQUF5QjtvQkFDekIsWUFBWTtvQkFDWixrQ0FBa0M7b0JBQ2xDLEtBQUs7Z0JBQ1QsQ0FBQztnQkFDRCwwQ0FBa0IsR0FBbEI7b0JBQUEsaUJBZ0NDO29CQS9CRyxJQUFJLEtBQUssR0FBRyxFQUFFLENBQUM7b0JBQ2YsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLFNBQVMsQ0FBQzt3QkFDbEUsS0FBSyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDO29CQUNsQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsc0JBQXNCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUNsRixXQUFXO3dCQUNYLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUN0RCxPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQzs0QkFDbkIsS0FBSSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDOzRCQUM5QixFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxJQUFJLElBQUksSUFBSSxRQUFRLENBQUMsSUFBSSxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUM7Z0NBQ3RELEtBQUksQ0FBQyxjQUFjLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQztnQ0FDcEMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDOzRCQUNyQyxDQUFDO3dCQUVMLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7Z0JBQ1AsQ0FBQztnQkFDRCxtQ0FBVyxHQUFYLFVBQVksS0FBSztvQkFDYixNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxFQUFFO3dCQUN4QyxFQUFFLENBQUMsQ0FBQyxJQUFJLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQzs0QkFDaEIsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7d0JBQzlCLENBQUM7b0JBRUwsQ0FBQyxDQUFDLENBQUM7Z0JBQ1AsQ0FBQztnQkFDRCxvQ0FBWSxHQUFaO29CQUNJLElBQUksQ0FBQyxPQUFPLEdBQUcsRUFBRSxDQUFDO29CQUNsQixJQUFJLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztvQkFDckIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEdBQUcsRUFBRSxDQUFDO29CQUNqQyxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsR0FBRyxFQUFFLENBQUM7b0JBQzlCLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztvQkFDMUIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDO29CQUMzQixJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsR0FBRyxFQUFFLENBQUM7b0JBQ2hDLElBQUksQ0FBQyxVQUFVLEdBQUcsRUFBRSxDQUFDO29CQUNyQixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGFBQWEsQ0FBQTtnQkFHM0QsQ0FBQztnQkFDRCxzQ0FBYyxHQUFkO29CQUNJLFdBQVc7b0JBQ1gsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDO3dCQUMzQixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQzt3QkFDdkIsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxpQkFBaUIsQ0FBQzt3QkFDNUQsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFDakMsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQzt3QkFDeEIsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxrQkFBa0IsQ0FBQzt3QkFDN0QsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFDakMsQ0FBQztnQkFFTCxDQUFDO2dCQUdELHFDQUFhLEdBQWIsVUFBYyxLQUFLO29CQUNmLGlCQUFpQjtvQkFDakIsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sSUFBSSxTQUFTLElBQUksS0FBSyxDQUFDLE1BQU0sSUFBSSxFQUFFLENBQUM7MkJBQ2pELENBQUMsS0FBSyxDQUFDLE9BQU8sSUFBSSxTQUFTLElBQUksS0FBSyxDQUFDLE9BQU8sSUFBSSxFQUFFLENBQUM7MkJBRW5ELENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxTQUFTLElBQUksS0FBSyxDQUFDLEdBQUcsSUFBSSxFQUFFLENBQUM7MkJBQzNDLENBQUMsS0FBSyxDQUFDLFdBQVcsSUFBSSxTQUFTLElBQUksS0FBSyxDQUFDLFdBQVcsSUFBSSxFQUFFLENBQUU7MkJBRTVELENBQUMsS0FBSyxDQUFDLGFBQWEsSUFBSSxTQUFTLElBQUksS0FBSyxDQUFDLGFBQWEsSUFBSSxFQUFFLENBQUMsQ0FBQztnQkFDM0UsQ0FBQztnQkFDRCxvQ0FBWSxHQUFaLFVBQWEsS0FBSztvQkFFZCxJQUFJLFNBQVMsR0FBRyxLQUFLLENBQUM7b0JBQ3RCLEtBQUssQ0FBQyxRQUFRLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDO29CQUV2QyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFFNUIsSUFBSSxLQUFLLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQzt3QkFDL0MsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsT0FBTyxFQUFFLEtBQUssQ0FBQyxXQUFXLEVBQUUsRUFBRSxDQUFDLENBQUM7d0JBQ3hFLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQzt3QkFDZCxJQUFJLE1BQU0sR0FBRyxNQUFNLENBQUM7d0JBQ3BCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDOzRCQUN4RSxNQUFNLEdBQUcsTUFBTSxDQUFDO3dCQUNwQixDQUFDO3dCQUNELE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRTs0QkFDNUIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxNQUFNLENBQUMsQ0FBQyxDQUFDO2dDQUN0QixJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztnQ0FDbEIsTUFBTSxDQUFDLEtBQUssQ0FBQzs0QkFDakIsQ0FBQzt3QkFFTCxDQUFDLENBQUMsQ0FBQzt3QkFDSCxJQUFJLFNBQVMsR0FBRyxFQUFFLE1BQU0sRUFBRSxFQUFFLEVBQUUsT0FBTyxFQUFFLEVBQUUsRUFBRSxRQUFRLEVBQUUsRUFBRSxFQUFFLEdBQUcsRUFBRSxFQUFFLEVBQUUsV0FBVyxFQUFFLEtBQUssQ0FBQyxXQUFXLEVBQUUsT0FBTyxFQUFFLEVBQUUsRUFBRSxhQUFhLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRyxTQUFTLEVBQUUsVUFBVSxHQUFHLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLEdBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsV0FBVyxFQUFFLFFBQVEsR0FBRyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsTUFBTSxHQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUM7d0JBRTVVLDhEQUE4RDt3QkFDOUQsbUZBQW1GO3dCQUVuRixvQ0FBb0M7d0JBQ3BDLHVCQUF1Qjt3QkFDdkIsT0FBTzt3QkFDUCxLQUFLO3dCQUNMLEVBQUUsQ0FBQyxDQUFDLFNBQVMsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDOzRCQUNyQixJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQzt3QkFDdEQsQ0FBQztvQkFFVCxDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUNGLElBQUksR0FBRyxHQUFHLEVBQUUsQ0FBQzt3QkFDYixFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxJQUFJLFNBQVMsSUFBSSxLQUFLLENBQUMsTUFBTSxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7NEJBQ2xELG9EQUFvRDs0QkFDcEQsR0FBRyxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxpQkFBaUIsQ0FBQzt3QkFDN0QsQ0FBQzt3QkFDRCxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxJQUFJLFNBQVMsSUFBSSxLQUFLLENBQUMsT0FBTyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7NEJBQ3BELGdDQUFnQzs0QkFDaEMsR0FBRyxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxlQUFlLENBQUM7d0JBQzNELENBQUM7d0JBQ0QsMERBQTBEO3dCQUMxRCx1Q0FBdUM7d0JBQ3ZDLDZEQUE2RDt3QkFDN0QsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxTQUFTLElBQUksS0FBSyxDQUFDLEdBQUcsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDOzRCQUM1QyxnQ0FBZ0M7NEJBQ2hDLEdBQUcsSUFBSSxJQUFJLEdBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsY0FBYyxDQUFDO3dCQUN4RCxDQUFDO3dCQUNELEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxXQUFXLElBQUksU0FBUyxJQUFJLEtBQUssQ0FBQyxXQUFXLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzs0QkFDNUQscUNBQXFDOzRCQUNyQyxHQUFHLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGtCQUFrQixDQUFDO3dCQUM5RCxDQUFDO3dCQUNELHdFQUF3RTt3QkFDeEUsdUNBQXVDO3dCQUN2QyxHQUFHO3dCQUNILEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxhQUFhLElBQUksU0FBUyxJQUFJLEtBQUssQ0FBQyxhQUFhLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzs0QkFDaEUsMENBQTBDOzRCQUMxQyxHQUFHLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGlCQUFpQixDQUFDO3dCQUM3RCxDQUFDO3dCQUNELE9BQU8sQ0FBQyxLQUFLLENBQUM7NEJBQ1YsT0FBTyxFQUFFLEdBQUcsRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLFlBQVk7NEJBQzFDLE9BQU8sRUFBRTtnQ0FDTCxFQUFFLEVBQUU7b0NBQ0EsY0FBYztvQ0FDZCxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVM7aUNBQzVCOzZCQUNKO3lCQUNKLENBQUMsQ0FBQztvQkFDUCxDQUFDO2dCQUVMLENBQUM7Z0JBQ0QsbUNBQVcsR0FBWCxVQUFZLFFBQVE7b0JBQ2hCLFdBQVc7b0JBQ1gsaUtBQWlLO29CQUNqSyxNQUFNLENBQUMsQ0FBQyxRQUFRLENBQUMsV0FBVyxJQUFJLFNBQVMsSUFBSSxRQUFRLENBQUMsV0FBVyxJQUFJLEVBQUUsQ0FBQyxDQUFBO29CQUNwRSxpRkFBaUY7b0JBQ2pGLDJFQUEyRTtvQkFDM0Usc0VBQXNFO29CQUN0RSwyREFBMkQ7b0JBQzNELDhGQUE4RjtnQkFDdEcsQ0FBQztnQkFDRCxpQ0FBUyxHQUFULFVBQVUsUUFBUTtvQkFDZCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFFOUIsWUFBWTt3QkFDWCx1Q0FBdUM7d0JBQ3ZDLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQzt3QkFDZCxJQUFJLEdBQUcsR0FBRyxDQUFDLENBQUM7d0JBQ1osSUFBSSxPQUFPLEdBQUcsQ0FBQyxDQUFDO3dCQUNoQixNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUU7NEJBQzFCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksV0FBVyxDQUFDLENBQUMsQ0FBQztnQ0FFM0IsSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7Z0NBQ2xCLEdBQUcsR0FBRyxDQUFDLENBQUM7Z0NBQ1IsT0FBTyxHQUFHLENBQUMsQ0FBQztnQ0FDWixNQUFNLENBQUMsS0FBSyxDQUFDOzRCQUNqQixDQUFDO3dCQUNMLENBQUMsQ0FBQyxDQUFDO3dCQUNILElBQUksUUFBUSxHQUFHLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFLE1BQU0sRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFFLEtBQUssRUFBRSxHQUFHLEVBQUUsUUFBUSxFQUFFLEVBQUUsRUFBRSxhQUFhLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLEtBQUssR0FBRyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxZQUFZLEVBQUUsS0FBSyxHQUFHLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUM7d0JBRWpULElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFJbEQsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixJQUFJLEdBQUcsR0FBRyxFQUFFLENBQUM7d0JBQ2IsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLFdBQVcsSUFBSSxTQUFTLElBQUksUUFBUSxDQUFDLFdBQVcsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDOzRCQUNsRSx3Q0FBd0M7NEJBQ3hDLEdBQUcsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsb0JBQW9CLENBQUM7d0JBQ2hFLENBQUM7d0JBQ0QsNERBQTREO3dCQUM1RCw4Q0FBOEM7d0JBQzlDLGdFQUFnRTt3QkFDaEUsR0FBRzt3QkFDSCx5Q0FBeUM7d0JBQ3pDLGlEQUFpRDt3QkFDakQsR0FBRzt3QkFDSCxPQUFPLENBQUMsS0FBSyxDQUFDOzRCQUNWLE9BQU8sRUFBRSxHQUFHLEVBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxZQUFZOzRCQUN6QyxPQUFPLEVBQUU7Z0NBQ0wsRUFBRSxFQUFFO29DQUNBLGNBQWM7b0NBQ2QsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO2lDQUM1Qjs2QkFDSjt5QkFDSixDQUFDLENBQUM7b0JBRVAsQ0FBQztnQkFFTCxDQUFDO2dCQUNELG1DQUFXLEdBQVgsVUFBWSxRQUFRO29CQUNoQixXQUFXO29CQUNYLGlCQUFpQjtvQkFDakIsTUFBTSxDQUFDLENBQUMsUUFBUSxDQUFDLFNBQVMsSUFBSSxTQUFTLElBQUksUUFBUSxDQUFDLFNBQVMsSUFBSSxFQUFFLENBQUMsQ0FBQztvQkFDckUsMERBQTBEO2dCQUU5RCxDQUFDO2dCQUNELGlDQUFTLEdBQVQsVUFBVSxRQUFRO29CQUNkLFdBQVc7b0JBQ1gsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQzdCLElBQUksUUFBUSxHQUFHLENBQUMsQ0FBQzt3QkFDakIsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFOzRCQUMzQixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLFdBQVcsQ0FBQyxDQUFDLENBQUM7Z0NBSTNCLFFBQVEsR0FBRyxDQUFDLENBQUM7Z0NBQ1osTUFBTSxDQUFDLEtBQUssQ0FBQzs0QkFDakIsQ0FBQzt3QkFDTCxDQUFDLENBQUMsQ0FBQzt3QkFDSCx1Q0FBdUM7d0JBQ3ZDLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQzt3QkFDZCxJQUFJLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQzt3QkFDaEIsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQzt3QkFDeEMsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUM7d0JBQ3hCLElBQUksQ0FBQyxPQUFPLEdBQUcsUUFBUSxDQUFDO3dCQUN4QixJQUFJLENBQUMsU0FBUyxHQUFFLE1BQU0sR0FBRyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sR0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQzt3QkFDOUUsSUFBSSxDQUFDLGFBQWEsR0FBRSxNQUFNLEdBQUcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUM7d0JBQ2hGLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFHbEQsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixJQUFJLEdBQUcsR0FBRyxFQUFFLENBQUM7d0JBQ2IsMERBQTBEO3dCQUMxRCx1Q0FBdUM7d0JBQ3ZDLGlFQUFpRTt3QkFDakUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLFNBQVMsSUFBSSxTQUFTLElBQUksUUFBUSxDQUFDLFNBQVMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDOzRCQUM5RCxnQ0FBZ0M7NEJBQ2hDLEdBQUcsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsbUJBQW1CLENBQUM7d0JBQy9ELENBQUM7d0JBQ0QsT0FBTyxDQUFDLEtBQUssQ0FBQzs0QkFDVixPQUFPLEVBQUUsR0FBRyxFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsWUFBWTs0QkFDMUMsT0FBTyxFQUFFO2dDQUNMLEVBQUUsRUFBRTtvQ0FDQSxjQUFjO29DQUNkLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUztpQ0FDNUI7NkJBQ0o7eUJBQ0osQ0FBQyxDQUFDO29CQUVQLENBQUM7b0JBRUQsOERBQThEO2dCQUNsRSxDQUFDO2dCQUVELG1DQUFXLEdBQVgsVUFBWSxHQUFHO29CQUFmLGlCQW1JQztvQkFsSUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGtCQUFrQixDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUN6RSxhQUFhO3dCQUNYLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUN0RCxPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsVUFBVSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7NEJBQ2hDLEtBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsY0FBYyxDQUFDOzRCQUM3RCx3RUFBd0U7NEJBQ3hFLEtBQUksQ0FBQyxPQUFPLEdBQUcsaUJBQWlCLENBQUM7NEJBQ2pDLEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUM3QyxLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxDQUFDLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsS0FBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFFLFNBQVMsRUFBRSxPQUFPLEVBQUUsYUFBYSxFQUFFLE9BQU8sRUFBRSxDQUFDLENBQUE7NEJBQ25LLENBQUM7NEJBQ0QsSUFBSSxDQUFDLENBQUM7Z0NBQ0YsSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO2dDQUVkLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUU7b0NBQ3hDLElBQUksQ0FBQyxTQUFTLEdBQUcsTUFBTSxHQUFHLEtBQUssQ0FBQztvQ0FDaEMsSUFBSSxDQUFDLGFBQWEsR0FBRyxNQUFNLEdBQUcsS0FBSyxFQUFFLENBQUM7b0NBQ3RDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLElBQUksR0FBRyxDQUFDLENBQUMsQ0FBQzt3Q0FDMUIsSUFBSSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUM7b0NBQzdCLENBQUM7b0NBQ0QsSUFBSSxDQUFDLENBQUM7d0NBQ0YsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUM7b0NBQzVCLENBQUM7Z0NBQ0wsQ0FBQyxDQUFDLENBQUM7NEJBQ1AsQ0FBQzs0QkFDRCxFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDN0MsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDO2dDQUVkLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLFdBQVcsRUFBRTtvQ0FFMUIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxXQUFXLENBQUMsQ0FBQyxDQUFDO3dDQUUzQixJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQzt3Q0FDbEIsTUFBTSxDQUFDLEtBQUssQ0FBQztvQ0FDakIsQ0FBQztnQ0FDTCxDQUFDLENBQUMsQ0FBQztnQ0FFSCxLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxDQUFDLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsQ0FBQyxFQUFFLFFBQVEsRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFFLENBQUMsRUFBRSxRQUFRLEVBQUUsTUFBTSxFQUFFLFlBQVksRUFBRSxNQUFNLEVBQUUsQ0FBQyxDQUFDOzRCQUc1SyxDQUFDOzRCQUNELElBQUksQ0FBQyxDQUFDO2dDQUNGLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQztnQ0FDZCxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxFQUFFO29DQUV4QyxJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssR0FBRyxLQUFLLENBQUM7b0NBQzlCLElBQUksQ0FBQyxZQUFZLEdBQUcsS0FBSyxHQUFHLEtBQUssRUFBRSxDQUFDO2dDQUN4QyxDQUFDLENBQUMsQ0FBQzs0QkFDUCxDQUFDOzRCQUNELEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQ2hELElBQUksS0FBSyxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUM7Z0NBRS9DLElBQUksS0FBSyxHQUFHLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLE9BQU8sQ0FBQyxDQUFDO2dDQUM3RCxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztvQ0FDakIsS0FBSyxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQztnQ0FDN0MsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDO2dDQUNkLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQztnQ0FDdEIsRUFBRSxDQUFDLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLElBQUksRUFBRSxJQUFJLEtBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxJQUFJLFNBQVMsSUFBSSxLQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO29DQUMzRyxRQUFRLEdBQUcsTUFBTSxDQUFDO2dDQUN0QixDQUFDO2dDQUNELE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLGFBQWEsRUFBRTtvQ0FDNUIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxRQUFRLENBQUMsQ0FBQyxDQUFDO3dDQUV4QixJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQzt3Q0FDbEIsTUFBTSxDQUFDLEtBQUssQ0FBQztvQ0FDakIsQ0FBQztnQ0FFTCxDQUFDLENBQUMsQ0FBQztnQ0FDSCxLQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixHQUFHLENBQUMsRUFBRSxNQUFNLEVBQUUsRUFBRSxFQUFFLE9BQU8sRUFBRSxFQUFFLEVBQUUsUUFBUSxFQUFFLEVBQUUsRUFBRSxHQUFHLEVBQUUsRUFBRSxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsT0FBTyxFQUFFLEVBQUUsRUFBRSxhQUFhLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsV0FBVyxFQUFFLFdBQVcsRUFBRSxTQUFTLEVBQUUsQ0FBQyxDQUFDOzRCQUMzTyxDQUFDOzRCQUNELElBQUksQ0FBQyxDQUFDO2dDQUNGLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQztnQ0FDbEIsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixFQUFFO29DQUMzQyxJQUFJLENBQUMsU0FBUyxHQUFHLFVBQVUsR0FBRyxLQUFLLENBQUM7b0NBQ3BDLElBQUksQ0FBQyxXQUFXLEdBQUcsUUFBUSxHQUFHLEtBQUssRUFBRSxDQUFDO2dDQUMxQyxDQUFDLENBQUMsQ0FBQzs0QkFDSCxDQUFDOzRCQUNELDREQUE0RDs0QkFFNUQscUNBQXFDOzRCQUdyQywyREFBMkQ7NEJBQzNELDZHQUE2Rzs0QkFDN0csaUJBQWlCOzRCQUNqQixvQ0FBb0M7NEJBQ3BDLE9BQU87NEJBQ1AsdUVBQXVFOzRCQUN2RSwwREFBMEQ7NEJBQzFELEtBQUs7NEJBQ0wsS0FBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLEdBQUcsS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDOzRCQUMzRCxLQUFJLENBQUMsZUFBZSxHQUFHLEtBQUssQ0FBQzs0QkFDN0IsS0FBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7NEJBQ3pCLG9EQUFvRDs0QkFDcEQsRUFBRSxDQUFDLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLElBQUksU0FBUyxJQUFJLEtBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxJQUFJLElBQUksSUFBSSxLQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO2dDQUM3SCxJQUFJLEtBQUssR0FBRyxFQUFFLENBQUM7Z0NBQ2YsSUFBSSxLQUFLLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQztnQ0FDL0MsRUFBRSxDQUFDLENBQUMsS0FBSyxJQUFJLElBQUksSUFBSSxLQUFLLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQztvQ0FDdEMsS0FBSyxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsS0FBSyxHQUFHLFFBQVEsQ0FBQyxDQUFDO2dDQUNuRCxDQUFDO2dDQUNELEtBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSyxHQUFDLElBQUksR0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQzs0QkFDbEUsQ0FBQzs0QkFDRCxJQUFJLENBQUMsQ0FBQztnQ0FDRixLQUFJLENBQUMsYUFBYSxHQUFHLGlCQUFpQixDQUFDOzRCQUMzQyxDQUFDO3dCQUlMLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBRUgsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO29CQUNsQiw0Q0FBNEM7b0JBQzVDLElBQUksQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDO2dCQUV6QixDQUFDO2dCQUNELHNDQUFjLEdBQWQsVUFBZSxRQUFRO29CQUF2QixpQkErREM7b0JBOURHLFdBQVc7b0JBQ1gsbUVBQW1FO29CQUNuRSxJQUFJLE9BQU8sR0FBRyxFQUFFLENBQUM7b0JBQ2pCLE1BQU0sQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDLElBQUksQ0FBQzt3QkFDbEMsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQztvQkFDckMsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO29CQUNkLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUU7d0JBQ3hDLEVBQUUsQ0FBQyxDQUFDLElBQUksSUFBSSxRQUFRLENBQUMsQ0FBQyxDQUFDOzRCQUVuQixNQUFNLENBQUMsS0FBSyxDQUFBO3dCQUNoQixDQUFDO3dCQUNELEtBQUssR0FBRyxLQUFLLEdBQUcsQ0FBQyxDQUFDO29CQUN0QixDQUFDLENBQUMsQ0FBQztvQkFFSCxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLElBQUksU0FBUyxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsSUFBSSxJQUFJLElBQUksT0FBTyxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7d0JBQ2hGLElBQUksV0FBVyxHQUFHLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQzt3QkFDakMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMsQ0FBQyxTQUFTLENBQ3hELFVBQUMsSUFBSTs0QkFDRCxXQUFXOzRCQUNYLEVBQUU7NEJBQ0YsSUFBSSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzs0QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO2dDQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO29DQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtvQ0FDdEQsT0FBTyxFQUFFO3dDQUNMLEVBQUUsRUFBRTs0Q0FDQSxjQUFjOzRDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUzt5Q0FDNUI7cUNBQ0o7aUNBQ0osQ0FBQyxDQUFDOzRCQUNQLENBQUM7NEJBQ0QsSUFBSSxDQUFDLENBQUM7Z0NBQ0YsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksSUFBSSxTQUFTLElBQUksUUFBUSxDQUFDLElBQUksSUFBSSxJQUFJLElBQUksUUFBUSxDQUFDLElBQUksSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO29DQUU3RSxXQUFXO29DQUVYLGtHQUFrRztvQ0FDbEcsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksR0FBRyxDQUFDLENBQUMsQ0FBQzt3Q0FDNUIsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQzt3Q0FDaEQsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQzt3Q0FDcEQsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLE9BQU8sR0FBRyxDQUFDLENBQUM7b0NBQzFGLENBQUM7b0NBQ0QsSUFBSSxDQUFDLENBQUM7d0NBQ0YsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQzt3Q0FDcEQsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQzt3Q0FDaEQsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLE9BQU8sR0FBRyxDQUFDLENBQUM7b0NBQzFGLENBQUM7Z0NBRUwsQ0FBQzs0QkFFTCxDQUFDOzRCQUNELHdGQUF3Rjt3QkFDNUYsQ0FBQyxFQUNELFVBQUMsR0FBRzt3QkFFSixDQUFDLEVBQ0Q7d0JBRUEsQ0FBQyxDQUFDLENBQUM7b0JBQ1AsQ0FBQztnQkFDVCxDQUFDO2dCQUNELG9DQUFZLEdBQVosVUFBYSxRQUFRO29CQUNqQixXQUFXO29CQUNYLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQztvQkFDZCxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDO29CQUM3QixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGNBQWMsQ0FBQztvQkFJekQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLEdBQUcsUUFBUSxDQUFDLEtBQUssQ0FBQztvQkFDdkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEdBQUcsUUFBUSxDQUFDLFNBQVMsQ0FBQztvQkFDL0MsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLFdBQVcsQ0FBQztvQkFHbkQsSUFBSSxDQUFDLGFBQWEsR0FBRyxFQUFFLENBQUM7b0JBQ3hCLElBQUksQ0FBQyxhQUFhLEdBQUcsUUFBUSxDQUFDO2dCQUNsQyxDQUFDO2dCQUNELG1DQUFXLEdBQVgsVUFBWSxRQUFRO29CQUNoQixXQUFXO29CQUNYLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUU1QyxJQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7d0JBQ2QsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRTs0QkFDeEMsRUFBRSxDQUFDLENBQUMsSUFBSSxJQUFJLFFBQVEsQ0FBQyxDQUFDLENBQUM7Z0NBQ25CLE1BQU0sQ0FBQyxLQUFLLENBQUE7NEJBQ2hCLENBQUM7NEJBQ0QsS0FBSyxHQUFHLEtBQUssR0FBRyxDQUFDLENBQUM7d0JBRXRCLENBQUMsQ0FBQyxDQUFDO3dCQUNILElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUM7b0JBQ3BELENBQUM7Z0JBQ0wsQ0FBQztnQkFFRCxzQ0FBYyxHQUFkLFVBQWUsVUFBVTtvQkFDckIsV0FBVztvQkFDWCxJQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7b0JBQ2QsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQztvQkFDN0IsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxjQUFjLENBQUM7b0JBRTFELCtDQUErQztvQkFFOUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQztvQkFDeEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLEdBQUcsVUFBVSxDQUFDLE9BQU8sQ0FBQztvQkFDMUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLEdBQUcsVUFBVSxDQUFDLFFBQVEsQ0FBQztvQkFDNUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLEdBQUcsVUFBVSxDQUFDLEdBQUcsQ0FBQztvQkFDbEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEdBQUcsVUFBVSxDQUFDLFdBQVcsQ0FBQztvQkFDbEQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLEdBQUcsVUFBVSxDQUFDLE9BQU8sQ0FBQztvQkFDMUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLEdBQUcsVUFBVSxDQUFDLGFBQWEsQ0FBQztvQkFDdEQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEdBQUcsVUFBVSxDQUFDLFdBQVcsQ0FBQztvQkFDbEQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEdBQUcsVUFBVSxDQUFDLFdBQVcsQ0FBQztvQkFHbEQsSUFBSSxDQUFDLGVBQWUsR0FBRyxFQUFFLENBQUM7b0JBQzFCLElBQUksQ0FBQyxlQUFlLEdBQUcsVUFBVSxDQUFDO2dCQUN0QyxDQUFDO2dCQUVELHFDQUFhLEdBQWIsVUFBYyxVQUFVO29CQUNyQixhQUFhO29CQUNaLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDeEMsSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO3dCQUNkLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsRUFBRTs0QkFDM0MsRUFBRSxDQUFDLENBQUMsSUFBSSxJQUFJLFVBQVUsQ0FBQyxDQUFDLENBQUM7Z0NBQ3JCLE1BQU0sQ0FBQyxLQUFLLENBQUE7NEJBQ2hCLENBQUM7NEJBQ0QsS0FBSyxHQUFHLEtBQUssR0FBRyxDQUFDLENBQUM7d0JBQ3RCLENBQUMsQ0FBQyxDQUFDO3dCQUNILElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQztvQkFDdkQsQ0FBQztnQkFDTCxDQUFDO2dCQUNELG9DQUFZLEdBQVosVUFBYSxRQUFRO29CQUVqQixJQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7b0JBQ2QsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxjQUFjLENBQUE7b0JBQ3hELElBQUksSUFBSSxHQUFHLFFBQVEsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUUzQyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsR0FBRyxRQUFRLENBQUMsU0FBUyxHQUFHLEdBQUcsR0FBRyxRQUFRLENBQUMsV0FBVyxDQUFDO29CQUU5RSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsR0FBRyxRQUFRLENBQUMsU0FBUyxDQUFDO29CQUMvQyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDO29CQUN6QyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO29CQUNyQyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUMsS0FBSyxDQUFDO29CQUN2QyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUMsS0FBSyxDQUFDO29CQUN2QyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUMsUUFBUSxDQUFDO29CQUM3QyxJQUFJLENBQUMsYUFBYSxHQUFHLEVBQUUsQ0FBQztvQkFDeEIsSUFBSSxDQUFDLGFBQWEsR0FBRyxRQUFRLENBQUM7Z0JBQ2xDLENBQUM7Z0JBQ0QsbUNBQVcsR0FBWCxVQUFZLFFBQVE7b0JBQ2pCLFlBQVk7b0JBQ1gsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQzVDLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQzt3QkFDZCxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxFQUFFOzRCQUN4QyxFQUFFLENBQUMsQ0FBQyxJQUFJLElBQUksUUFBUSxDQUFDLENBQUMsQ0FBQztnQ0FDbkIsTUFBTSxDQUFDLEtBQUssQ0FBQTs0QkFDaEIsQ0FBQzs0QkFDRCxLQUFLLEdBQUcsS0FBSyxHQUFHLENBQUMsQ0FBQzt3QkFDdEIsQ0FBQyxDQUFDLENBQUM7d0JBQ0gsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQztvQkFDcEQsQ0FBQztnQkFDTCxDQUFDO2dCQUdELHlDQUFpQixHQUFqQjtvQkFDSSxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxFQUFFLENBQUM7b0JBQ3BDLElBQUksY0FBYyxHQUFHLEVBQUUsQ0FBQztvQkFDeEIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDO3dCQUMxQix3QkFBYSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsRUFBRSxjQUFjLENBQUMsQ0FBQztvQkFDL0csQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFFRix3QkFBYSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsRUFBRSxjQUFjLENBQUMsQ0FBQztvQkFDaEgsQ0FBQztvQkFDRCxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUMsQ0FBQyxHQUFDLGNBQWMsQ0FBQyxNQUFNLEVBQUMsQ0FBQyxFQUFFLEVBQUMsQ0FBQzt3QkFDeEMsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDO3dCQUNkLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ2hELElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFFOUMsQ0FBQztnQkFFTCxDQUFDO2dCQUVELDRCQUFJLEdBQUo7b0JBQ0csaUJBQWlCO29CQUNoQixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7d0JBQ3hCLElBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO3dCQUV0Qiw2QkFBNkI7d0JBQzdCLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsZ0JBQWdCLENBQUM7b0JBQ2xFLENBQUM7b0JBQ0QsSUFBSSxDQUFDLENBQUM7d0JBQ04sSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7d0JBQ3JCLDhCQUE4Qjt3QkFDOUIsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxnQkFBZ0IsQ0FBQztvQkFDOUQsQ0FBQztvQkFDRCxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7Z0JBQzFCLENBQUM7Z0JBQ0QscUNBQWEsR0FBYixVQUFjLFNBQVM7b0JBQXZCLGlCQWlFQztvQkFoRUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxDQUFDLFNBQVMsQ0FDdkQsVUFBQyxJQUFJO3dCQUNELFdBQVc7d0JBQ1gsRUFBRTt3QkFDRixtQkFBbUI7d0JBQ25CLEVBQUUsQ0FBQyxDQUFDLFNBQVMsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDOzRCQUNyQixNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDOzRCQUN2QyxJQUFJLEdBQUcsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQTs0QkFDckMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLGFBQWEsQ0FBQztnQ0FDL0IsWUFBWSxFQUFFLElBQUk7Z0NBQ2xCLFVBQVUsRUFBRSxFQUVYO2dDQUNELEtBQUssRUFBRSxVQUFVLENBQUM7b0NBQ2QsSUFBSSxDQUFDLFVBQVUsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO29DQUV6QixJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7Z0NBQ25FLENBQUM7Z0NBQ0QsNEJBQTRCO2dDQUM1QixVQUFVLEVBQUUsR0FBRzs2QkFDbEIsQ0FBQyxDQUFDOzRCQUNILElBQUksTUFBTSxHQUFHLEVBQUUsQ0FBQzs0QkFFaEIsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRTtnQ0FDeEMsTUFBTSxJQUFJLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxHQUFHLENBQUM7NEJBQ2hELENBQUMsQ0FBQyxDQUFDOzRCQUNILEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDcEIsd0JBQWEsQ0FBQyxlQUFlLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLEVBQUUsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFBOzRCQUN2SSxDQUFDO3dCQUNMLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQzs0QkFDeEMsSUFBSSxHQUFHLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUE7NEJBQ3JDLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQyxhQUFhLENBQUM7Z0NBQ2hDLFlBQVksRUFBRSxJQUFJO2dDQUNsQixVQUFVLEVBQUUsRUFFWDtnQ0FDRCxLQUFLLEVBQUUsVUFBVSxDQUFDO29DQUNkLElBQUksQ0FBQyxVQUFVLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztvQ0FFekIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO2dDQUNuRSxDQUFDO2dDQUNELDRCQUE0QjtnQ0FDNUIsVUFBVSxFQUFFLEdBQUc7NkJBQ2xCLENBQUMsQ0FBQzs0QkFDSCxJQUFJLE1BQU0sR0FBRyxFQUFFLENBQUM7NEJBQ2hCLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUU7Z0NBQ3hDLE1BQU0sSUFBSSxJQUFJLENBQUMsc0JBQXNCLEdBQUcsR0FBRyxDQUFDOzRCQUNoRCxDQUFDLENBQUMsQ0FBQzs0QkFDSCxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQ3BCLHdCQUFhLENBQUMsZUFBZSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxFQUFFLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQTs0QkFDeEksQ0FBQzt3QkFDTCxDQUFDO3dCQUNELHdGQUF3RjtvQkFDNUYsQ0FBQyxFQUNELFVBQUMsR0FBRztvQkFFSixDQUFDLEVBQ0Q7b0JBRUEsQ0FBQyxDQUNKLENBQUM7Z0JBRU4sQ0FBQztnQkFDRCx3Q0FBZ0IsR0FBaEIsVUFBaUIsS0FBVTtvQkFFdkIsOENBQThDO29CQUM5Qyx1QkFBdUI7b0JBQ3ZCLDZHQUE2RztvQkFDekcsb0VBQW9FO29CQUN4RSx3QkFBd0I7b0JBQ3hCLGlDQUFpQztvQkFDakMsd0ZBQXdGO29CQUV4RixvREFBb0Q7b0JBQ3BELDZDQUE2QztvQkFDN0MseUNBQXlDO29CQUN6QyxlQUFlO29CQUNmLG9CQUFvQjtvQkFDcEIscUNBQXFDO29CQUNyQyxnREFBZ0Q7b0JBQ2hELDRFQUE0RTtvQkFDNUUsMERBQTBEO29CQUMxRCx5REFBeUQ7b0JBRXpELG1CQUFtQjtvQkFFbkIsZUFBZTtvQkFDZixzQkFBc0I7b0JBQ3RCLGlDQUFpQztvQkFDakMsb0JBQW9CO29CQUNwQiwwQ0FBMEM7b0JBQzFDLGFBQWE7b0JBQ2IsOEJBQThCO29CQUM5QixPQUFPO29CQUVQLEdBQUc7b0JBQ0gsc0JBQXNCO2dCQUMxQixDQUFDO2dCQUVELHNDQUFjLEdBQWQ7b0JBQUEsaUJBeUNDO29CQXZDRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsYUFBYSxFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFDcEQsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQ3RELE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLElBQUksb0JBQW9CLEdBQUcsRUFBRSxDQUFDOzRCQUM5QixNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUU7Z0NBQ3ZCLElBQUksT0FBTyxHQUFHLEVBQUUsQ0FBQztnQ0FDakIsT0FBTyxDQUFDLEVBQUUsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO2dDQUN4QixPQUFPLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUM7Z0NBQ3pCLG9CQUFvQixDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQzs0QkFDdkMsQ0FBQyxDQUFDLENBQUM7NEJBQ0gsS0FBSSxDQUFDLFdBQVcsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDOzRCQUNqQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsU0FBUyxDQUFDO2dDQUN2QixxQkFBcUI7Z0NBQ3JCLE1BQU0sRUFBRSxvQkFBb0I7Z0NBQzVCLGtCQUFrQjtnQ0FDbEIsUUFBUSxFQUFFLE1BQU07NkJBSW5CLENBQUMsQ0FBQzt3QkFHUCxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO2dCQUNQLENBQUM7Z0JBQ0QscUNBQWEsR0FBYixVQUFjLEtBQUs7b0JBQW5CLGlCQXFGQztvQkFwRkcsV0FBVztvQkFDWCxJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO29CQUN2RCxJQUFJLElBQUksR0FBRyxJQUFJLFFBQVEsRUFBRSxDQUFDO29CQUMxQixJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUVoRCxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQztvQkFDNUIsd0JBQXdCO29CQUN0QiwyQ0FBMkM7b0JBQzNDLFFBQVEsQ0FBQztvQkFDVCxJQUFJLEtBQUssR0FBRyxFQUFFLENBQUM7b0JBQ2YsSUFBSSxLQUFLLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQztvQkFDL0MsRUFBRSxDQUFDLENBQUMsS0FBSyxJQUFJLElBQUksSUFBSSxLQUFLLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQzt3QkFDdEMsS0FBSyxHQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsS0FBSyxHQUFHLFFBQVEsQ0FBQyxDQUFDO29CQUNqRCxDQUFDO29CQUNELElBQUksR0FBRyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUM7b0JBRWpFLEdBQUcsQ0FBQyxrQkFBa0IsR0FBRzt3QkFDckIsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLFVBQVUsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDOzRCQUN2QixFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUM7Z0NBQ3JCLFFBQVEsQ0FBQztnQ0FDVCxJQUFJLFFBQVEsR0FBRyxHQUFHLENBQUMsWUFBWSxDQUFDO2dDQUNoQyxFQUFFLENBQUMsQ0FBQyxRQUFRLElBQUksU0FBUyxJQUFJLFFBQVEsSUFBSSxFQUFFLElBQUksUUFBUSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7b0NBQzlELFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO29DQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7d0NBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7NENBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZOzRDQUN0RCxPQUFPLEVBQUU7Z0RBQ0wsRUFBRSxFQUFFO29EQUNBLGNBQWM7b0RBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO2lEQUM1Qjs2Q0FDSjt5Q0FDSixDQUFDLENBQUM7b0NBQ1AsQ0FBQztvQ0FDRCxJQUFJLENBQUMsQ0FBQzt3Q0FDRixxREFBcUQ7d0NBRXJELEtBQUksQ0FBQyxhQUFhLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzt3Q0FDbkMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQztvQ0FHbEQsQ0FBQztnQ0FDTCxDQUFDOzRCQUVMLENBQUM7NEJBQUMsSUFBSSxDQUFDLENBQUM7NEJBRVIsQ0FBQzt3QkFDTCxDQUFDO29CQUNMLENBQUMsQ0FBQztvQkFHRixvQkFBb0I7b0JBQ3BCLGlCQUFpQjtvQkFDakIsNENBQTRDO29CQUM1QyxxQ0FBcUM7b0JBQ3JDLHlCQUF5QjtvQkFDekIscUVBQXFFO29CQUNyRSx3QkFBd0I7b0JBQ3hCLHVCQUF1QjtvQkFDdkIsb0NBQW9DO29CQUNwQywrQ0FBK0M7b0JBQy9DLG1CQUFtQjtvQkFDbkIsZUFBZTtvQkFDZixhQUFhO29CQUNiLE9BQU87b0JBQ1AsWUFBWTtvQkFDWixtQkFBbUI7b0JBQ25CLCtDQUErQztvQkFDL0MsMERBQTBEO29CQUUxRCxPQUFPO29CQUNQLGNBQWM7b0JBQ2QseUJBQXlCO29CQUN6QixZQUFZO29CQUNaLGtDQUFrQztvQkFDbEMsS0FBSztvQkFDTCxpQ0FBaUM7b0JBQ2pDLHlEQUF5RDtvQkFDekQsNkJBQTZCO29CQUM3Qix3Q0FBd0M7b0JBQ3hDLGlFQUFpRTtvQkFDakUsNENBQTRDO29CQUM1QyxHQUFHO29CQUNILG9DQUFvQztnQkFDeEMsQ0FBQztnQkFDRCxrQ0FBVSxHQUFWO29CQUNJLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUM7b0JBQzdCLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxHQUFHLEVBQUUsQ0FBQztvQkFFbkMsSUFBSSxDQUFDLGFBQWEsR0FBRyxpQkFBaUIsQ0FBQztvQkFDdkMsb0NBQW9DO2dCQUN4QyxDQUFDO2dCQUNELGdDQUFRLEdBQVI7b0JBQUEsaUJBaWZDO29CQWhmRyxFQUFFO29CQUNGLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLENBQUMsZUFBZSxDQUFDLENBQUM7b0JBQ3BELE1BQU0sQ0FBQyxlQUFlLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFLENBQUMsQ0FBQztvQkFDbkQsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO29CQUN2QixZQUFZO29CQUNYLDhDQUE4QztvQkFDOUMsRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO3dCQUNyQyxZQUFZLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQztvQkFDdkMsQ0FBQztvQkFDRCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7d0JBRWhELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLElBQUksRUFBRSxFQUFFLENBQUMsQ0FBQztvQkFDdEQsQ0FBQztvQkFDRCxJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQztvQkFDdEIsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO29CQUN0QixJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQztvQkFFNUIsa0NBQWtDO29CQUVsQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUNsQywrQkFBK0I7d0JBQy9CLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO3dCQUVsQyxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGNBQWMsQ0FBQzt3QkFDN0Qsd0VBQXdFO3dCQUN4RSxtQ0FBbUM7d0JBRW5DLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7NEJBQ2hELElBQUksS0FBSyxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUM7NEJBRS9DLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLE9BQU8sQ0FBQyxDQUFDOzRCQUM3RCxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztnQ0FDakIsS0FBSyxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQzs0QkFDN0MsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDOzRCQUNkLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQzs0QkFDdEIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO2dDQUMzRyxRQUFRLEdBQUcsTUFBTSxDQUFDOzRCQUN0QixDQUFDOzRCQUNELE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRTtnQ0FDNUIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxRQUFRLENBQUMsQ0FBQyxDQUFDO29DQUV4QixJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztvQ0FDbEIsTUFBTSxDQUFDLEtBQUssQ0FBQztnQ0FDakIsQ0FBQzs0QkFFTCxDQUFDLENBQUMsQ0FBQzs0QkFDSCxJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixHQUFHLENBQUMsRUFBRSxNQUFNLEVBQUUsRUFBRSxFQUFFLE9BQU8sRUFBRSxFQUFFLEVBQUUsUUFBUSxFQUFFLEVBQUUsRUFBRSxHQUFHLEVBQUUsRUFBRSxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsT0FBTyxFQUFFLEVBQUUsRUFBRSxhQUFhLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsV0FBVyxFQUFFLFdBQVcsRUFBRSxTQUFTLEVBQUUsQ0FBQyxDQUFDO3dCQUMzTyxDQUFDO3dCQUNELElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQTt3QkFDMUQsSUFBSSxDQUFDLGVBQWUsR0FBRyxLQUFLLENBQUM7b0JBRWpDLENBQUM7b0JBQ0QsSUFBSSxDQUFDLENBQUM7d0JBQ0YsSUFBSSxDQUFDLGFBQWEsR0FBRyxpQkFBaUIsQ0FBQztvQkFDM0MsQ0FBQztvQkFDRCxJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQ3BELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ3ZCLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQ3pELENBQUM7b0JBQ0QsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7b0JBQzFCLHlKQUF5SjtvQkFFeEosRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO3dCQUNwQixJQUFJLENBQUMsV0FBVyxHQUFHLE9BQU8sQ0FBQzt3QkFDM0IsSUFBSSxDQUFDLFNBQVMsR0FBRyxVQUFVLENBQUM7d0JBQzVCLElBQUksQ0FBQyxZQUFZLEdBQUcsYUFBYSxDQUFDO29CQUl0QyxDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUNGLElBQUksQ0FBQyxTQUFTLEdBQUcsVUFBVSxDQUFDO3dCQUM1QixJQUFJLENBQUMsWUFBWSxHQUFHLFlBQVksQ0FBQztvQkFDckMsQ0FBQztvQkFHRixJQUFJLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7d0JBQ3pFLFdBQVc7d0JBQ1gsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQ3RELE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEtBQUksQ0FBQyxHQUFHLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzs0QkFDekIsS0FBSSxDQUFDLFlBQVksR0FBRyxLQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxnQkFBZ0IsQ0FBQzs0QkFDOUQsS0FBSSxDQUFDLFNBQVMsR0FBRyxLQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxrQkFBa0IsQ0FBQzs0QkFDN0QsS0FBSSxDQUFDLGFBQWEsR0FBRyxLQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUM7NEJBQzNELEtBQUksQ0FBQyxpQkFBaUIsR0FBRyxLQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxnQkFBZ0IsQ0FBQzs0QkFDbkUsS0FBSSxDQUFDLGVBQWUsR0FBRyxLQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxjQUFjLENBQUM7d0JBRW5FLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsNkJBQTZCO29CQUU3QixVQUFVO29CQUtWLElBQUksV0FBVyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDO29CQUMzQyxJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQztvQkFDckMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxXQUFXLEVBQUUsU0FBUyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFDdEUsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQ3RELE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLElBQUksZUFBZSxHQUFHLEVBQUUsQ0FBQzs0QkFDekIsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFO2dDQUN2QixJQUFJLE9BQU8sR0FBRyxFQUFFLENBQUM7Z0NBQ2pCLE9BQU8sQ0FBQyxFQUFFLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztnQ0FDeEIsT0FBTyxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO2dDQUN6QixlQUFlLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDOzRCQUNsQyxDQUFDLENBQUMsQ0FBQzs0QkFDSCxLQUFJLENBQUMsT0FBTyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7NEJBQzdCLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUM7Z0NBQ3RCLHFCQUFxQjtnQ0FDckIsTUFBTSxFQUFFLGVBQWU7Z0NBQ3ZCLGtCQUFrQjtnQ0FDbEIsUUFBUSxFQUFFLE1BQU07NkJBSW5CLENBQUMsQ0FBQzt3QkFDUCxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQU9GLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLHFCQUFxQixFQUFFLENBQUM7b0JBQ25FLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBRW5ELElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQ3RELE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEtBQUksQ0FBQyxVQUFVLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzs0QkFDaEMsRUFBRSxDQUFDLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLElBQUksRUFBRSxJQUFJLEtBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxJQUFJLFNBQVMsSUFBSSxLQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO2dDQUMxSCxJQUFJLFVBQVUsQ0FBQztnQ0FDZixNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUksQ0FBQyxVQUFVLEVBQUU7b0NBQ3pCLFVBQVUsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO29DQUN4QixNQUFNLENBQUMsS0FBSyxDQUFDO2dDQUNqQixDQUFDLENBQUMsQ0FBQztnQ0FDSCxLQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksR0FBRyxVQUFVLENBQUM7NEJBQzlDLENBQUM7d0JBQ0wsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFHSCxXQUFXO29CQUNYLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUM3QyxJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUN0RCxPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7NEJBQzlCLEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLElBQUksRUFBRSxJQUFJLEtBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLElBQUksU0FBUyxJQUFJLEtBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQztnQ0FDdEksSUFBSSxNQUFNLENBQUM7Z0NBQ1gsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsUUFBUSxFQUFFO29DQUN2QixNQUFNLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztvQ0FDcEIsTUFBTSxDQUFDLEtBQUssQ0FBQztnQ0FDakIsQ0FBQyxDQUFDLENBQUM7Z0NBQ0gsS0FBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsR0FBRyxNQUFNLENBQUM7NEJBQzlDLENBQUM7d0JBQ0wsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFFSCxjQUFjO29CQUNkLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLEVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUNuRCxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDdEQsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLFVBQVUsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDOzRCQUNoQyxFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxFQUFFLElBQUksS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksU0FBUyxJQUFJLEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7Z0NBQ3BILElBQUksS0FBSyxDQUFDO2dDQUNWLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLFVBQVUsRUFBRTtvQ0FDekIsS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7b0NBQ25CLE1BQU0sQ0FBQyxLQUFLLENBQUM7Z0NBQ2pCLENBQUMsQ0FBQyxDQUFDO2dDQUNILEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQzs0QkFDdkMsQ0FBQzt3QkFDTCxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUNILGFBQWE7b0JBQ2IsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFdBQVcsRUFBRSxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7d0JBQ2xELFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUN0RCxPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsU0FBUyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7d0JBQ25DLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsZUFBZTtvQkFDZixJQUFJLENBQUMsZ0JBQWdCLENBQUMsYUFBYSxFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFDckQsWUFBWTt3QkFDWCxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDdEQsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLFdBQVcsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDOzRCQUNqQyxJQUFJLElBQUksR0FBRyxFQUFFLENBQUM7NEJBQ2QsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsV0FBVyxFQUFFO2dDQUMxQixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLFdBQVcsQ0FBQyxDQUFDLENBQUM7b0NBRTNCLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO29DQUNsQixNQUFNLENBQUMsS0FBSyxDQUFDO2dDQUNqQixDQUFDOzRCQUNMLENBQUMsQ0FBQyxDQUFDOzRCQUNILEtBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUM7d0JBQ3pELENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBR0gsSUFBSSxRQUFRLEdBQUcsQ0FBQyxDQUFDO29CQUNqQixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDN0MsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDO3dCQUVkLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRTs0QkFDMUIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxXQUFXLENBQUMsQ0FBQyxDQUFDO2dDQUUzQixJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztnQ0FDbEIsUUFBUSxHQUFHLENBQUMsQ0FBQztnQ0FDYixNQUFNLENBQUMsS0FBSyxDQUFDOzRCQUNqQixDQUFDO3dCQUNMLENBQUMsQ0FBQyxDQUFDO3dCQUVILElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLENBQUMsRUFBRSxXQUFXLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBRSxNQUFNLEVBQUUsWUFBWSxFQUFDLE1BQU0sRUFBRSxDQUFDLENBQUM7b0JBR3pMLENBQUM7b0JBQ0QsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQzdDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLENBQUMsRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsU0FBUyxFQUFFLE9BQU8sRUFBRSxhQUFhLEVBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQTtvQkFDekssQ0FBQztvQkFFRCxpQkFBaUI7b0JBQ2pCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxlQUFlLEVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUN0RCxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDdEQsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLGFBQWEsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDOzRCQUNwQyxZQUFZOzRCQUNYLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQzs0QkFDZCxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUksQ0FBQyxhQUFhLEVBQUU7Z0NBQzVCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksTUFBTSxDQUFDLENBQUMsQ0FBQztvQ0FFdEIsSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7b0NBQ2xCLE1BQU0sQ0FBQyxLQUFLLENBQUM7Z0NBQ2pCLENBQUM7NEJBRUwsQ0FBQyxDQUFDLENBQUM7NEJBQ0gsS0FBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO3dCQUM5RCxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUNILFFBQVE7b0JBRVIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7d0JBQ2hELFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUN0RCxPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsT0FBTyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7d0JBQ2pDLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsYUFBYTtvQkFFYixJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFDbkQsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQ3RELE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEtBQUksQ0FBQyxVQUFVLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzt3QkFDcEMsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFDSCxVQUFVO29CQUNWLElBQUksV0FBVyxHQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDO29CQUMxQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7d0JBQzNELFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUN0RCxPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsT0FBTyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7d0JBQ2pDLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBR0gsWUFBWTtvQkFFWixxQ0FBcUM7b0JBQ3JDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsU0FBUyxDQUM1RCxVQUFDLElBQUk7d0JBQ0YsWUFBWTt3QkFDWCxFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsU0FBUyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUM7NEJBQzFCLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7NEJBQ3ZDLElBQUksR0FBRyxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFBOzRCQUNyQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsYUFBYSxDQUFDO2dDQUMvQixZQUFZLEVBQUUsSUFBSTtnQ0FDbEIsVUFBVSxFQUFFO29DQUNSLGFBQWEsRUFBRSxJQUFJO2lDQUN0QjtnQ0FDRCw0QkFBNEI7Z0NBQzVCLFVBQVUsRUFBRSxHQUFHOzZCQUVsQixDQUFDLENBQUM7NEJBQ0gsSUFBSSxNQUFNLEdBQUcsRUFBRSxDQUFDOzRCQUNoQixNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxFQUFFO2dDQUN4QyxNQUFNLElBQUksSUFBSSxDQUFDLHNCQUFzQixHQUFHLEdBQUcsQ0FBQzs0QkFDaEQsQ0FBQyxDQUFDLENBQUM7NEJBQ0gsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUNwQix3QkFBYSxDQUFDLGVBQWUsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsRUFBRSxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUE7NEJBQ3ZJLENBQUM7d0JBQ0wsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixNQUFNLENBQUMsYUFBYSxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDOzRCQUN4QyxJQUFJLEdBQUcsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQTs0QkFDckMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDLGFBQWEsQ0FBQztnQ0FDaEMsWUFBWSxFQUFFLElBQUk7Z0NBQ2xCLFVBQVUsRUFBRTtvQ0FDUixhQUFhLEVBQUUsSUFBSTtpQ0FDdEI7Z0NBQ0QsNEJBQTRCO2dDQUM1QixVQUFVLEVBQUUsR0FBRzs2QkFDbEIsQ0FBQyxDQUFDOzRCQUNILElBQUksTUFBTSxHQUFHLEVBQUUsQ0FBQzs0QkFDaEIsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRTtnQ0FDeEMsTUFBTSxJQUFJLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxHQUFHLENBQUM7NEJBQ2hELENBQUMsQ0FBQyxDQUFDOzRCQUNILEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDcEIsd0JBQWEsQ0FBQyxlQUFlLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLEVBQUUsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFBOzRCQUN4SSxDQUFDO3dCQUNMLENBQUM7b0JBQ0wsQ0FBQyxFQUNELFVBQUMsR0FBRztvQkFFSixDQUFDLEVBQ0Q7b0JBRUEsQ0FBQyxDQUNKLENBQUM7b0JBSUYsOENBQThDO29CQUMvQyxpREFBaUQ7b0JBQ2hELElBQUksUUFBUSxHQUFHLElBQUksQ0FBQztvQkFFcEIsY0FBYztvQkFDZCxNQUFNLENBQUMseUNBQXlDLENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ3RFLE1BQU0sQ0FBQyxzQ0FBc0MsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztvQkFDbkUsc0JBQXNCO2dCQUUxQixDQUFDO2dCQTN6RU0scUJBQU8sR0FBRyxDQUFDLFFBQVEsRUFBRSxXQUFXLEVBQUUsZUFBZSxDQUFDLENBQUM7Z0JBekQ5RDtvQkFBQyxnQkFBUyxDQUFDO3dCQUVQLFdBQVcsRUFBRSw2Q0FBNkM7d0JBQzFELFVBQVUsRUFBRSxDQUFDLGlCQUFRLEVBQUUscUJBQVksRUFBRSx3QkFBZSxFQUFFLHVCQUF1QixFQUFFLHdCQUFlLEVBQUUsd0JBQWUsRUFBRSwwQkFBUSxDQUFDO3dCQUMxSCxTQUFTLEVBQUUsQ0FBQyxpQ0FBZSxFQUFFLGlDQUFlLENBQUM7cUJBQ2hELENBQUM7O2lDQUFBO2dCQWczRUYsb0JBQUM7WUFBRCxDQTkyRUEsQUE4MkVDLElBQUE7WUE5MkVELHlDQTgyRUMsQ0FBQSIsImZpbGUiOiJhbWF4L0N1c3RvbWVyL2FkZEN1c3RvbWVyLmpzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbmltcG9ydCB7TmdTd2l0Y2gsIE5nU3dpdGNoV2hlbiwgTmdTd2l0Y2hEZWZhdWx0LCBDT1JFX0RJUkVDVElWRVMsIEZPUk1fRElSRUNUSVZFU30gZnJvbSAnYW5ndWxhcjIvY29tbW9uJ1xyXG5pbXBvcnQge1Jlc291cmNlU2VydmljZX0gZnJvbSBcIi4uLy4uL3NlcnZpY2VzL1Jlc291cmNlU2VydmljZVwiO1xyXG5pbXBvcnQge1JvdXRlUGFyYW1zfSBmcm9tIFwiYW5ndWxhcjIvcm91dGVyXCI7XHJcbmltcG9ydCB7Q29tcG9uZW50LCBPdXRwdXQsIElucHV0LCBFdmVudEVtaXR0ZXIsIE9uSW5pdH0gZnJvbSBcImFuZ3VsYXIyL2NvcmVcIjtcclxuaW1wb3J0IHtDdXN0b21lclNlcnZpY2V9IGZyb20gXCIuLi8uLi9zZXJ2aWNlcy9DdXN0b21lclNlcnZpY2VcIjtcclxuaW1wb3J0IHsganNvblEgfSBmcm9tICcuLi8uLi9qc29uUSc7XHJcbmltcG9ydCB7R3JvdXBGaWx0ZXJQaXBlLCBHcm91cFBhcmVuRmlsdGVyUGlwZSwgS2VuZG9fdXRpbGl0eX0gZnJvbSBcIi4uLy4uL2FtYXhVdGlsXCI7XHJcbmltcG9ydCB7QXV0b2NvbXBsZXRlQ29udGFpbmVyfSBmcm9tICcuLi8uLi9hdXRvY29tcGxldGUvYXV0b2NvbXBsZXRlLWNvbnRhaW5lcic7XHJcbmltcG9ydCB7QXV0b2NvbXBsZXRlfSBmcm9tICcuLi8uLi9hdXRvY29tcGxldGUvYXV0b2NvbXBsZXRlLmNvbXBvbmVudCc7XHJcbmltcG9ydCB7IEFtYXhEYXRlIH0gZnJvbSAnLi4vLi4vY29tb25Db21wb25lbnRzL2Jhc2ljQ29tcG9uZW50cyc7XHJcblxyXG5leHBvcnQgY29uc3QgQVVUT0NPTVBMRVRFX0RJUkVDVElWRVMgPSBbQXV0b2NvbXBsZXRlLCBBdXRvY29tcGxldGVDb250YWluZXJdO1xyXG5kZWNsYXJlIHZhciBqUXVlcnk7XHJcbmRlY2xhcmUgdmFyIHN3YWw7XHJcbmRlY2xhcmUgdmFyIG1vbWVudDtcclxuXHJcbkBDb21wb25lbnQoe1xyXG5cclxuICAgIHRlbXBsYXRlVXJsOiAnLi9hcHAvYW1heC9DdXN0b21lci90ZW1wbGF0ZXMvY3VzdG9tZXIuaHRtbCcsXHJcbiAgICBkaXJlY3RpdmVzOiBbTmdTd2l0Y2gsIE5nU3dpdGNoV2hlbiwgTmdTd2l0Y2hEZWZhdWx0LCBBVVRPQ09NUExFVEVfRElSRUNUSVZFUywgQ09SRV9ESVJFQ1RJVkVTLCBGT1JNX0RJUkVDVElWRVMsIEFtYXhEYXRlXSxcclxuICAgIHByb3ZpZGVyczogW0N1c3RvbWVyU2VydmljZSwgUmVzb3VyY2VTZXJ2aWNlXVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEFtYXhDdXN0b21lcnMgaW1wbGVtZW50cyBPbkluaXQge1xyXG4gICAgYmFzZVVybDogc3RyaW5nID0gXCJcIjtcclxuICAgIEltYWdlVXJsOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgbW9kZWxJbnB1dCA9IHt9O1xyXG4gICAgVGVtcG1vZGVsSW5wdXQgPSB7fTtcclxuICAgIGN1c3RTZWFyY2hEYXRhOiBPYmplY3QgPSBbXTtcclxuICAgIFJFUzogT2JqZWN0ID0ge307XHJcbiAgICBTZWxlY3RlZFBoVHlwZTogT2JqZWN0ID0ge307XHJcbiAgICB0ZW1wc3RyZWV0bXNnOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgRm9ybXR5cGU6IHN0cmluZyA9XCJDVVNUT01FUl9NQVNURVJcIjtcclxuICAgIExhbmc6IHN0cmluZz1cIlwiO1xyXG4gICAgLy9tb2RlbElucHV0LmxuYW1lPSBcIlwiO1xyXG4gICAgU2hvd01vcmU6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIElzUmVjb3JkRWRpdE1vZGU6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIFNob3dNb3JlVGV4dDogc3RyaW5nID0gXCJNb3JlXCI7XHJcbiAgICBDdXN0RmlsZUltYWdlOiBzdHJpbmcgPSBcIkRlZmF1bHRVc2VyLmpwZ1wiO1xyXG4gICAgU2hvd0xvYWRlcjogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgU2hvd01zZzogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgU2hvd0dyb3VwczogYm9vbGVhbiA9IHRydWU7XHJcbiAgICBHcm91cFRleHQ6IHN0cmluZz1cIlNob3cgR3JvdXBzXCI7XHJcbiAgICBNc2c6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBNc2dDbGFzczogc3RyaW5nID0gXCJ0ZXh0LXByaW1hcnlcIjtcclxuICAgIElzYnRuZGlzYWJsZTogc3RyaW5nID0gXCJcIjtcclxuICAgIElzRmlsZUFzU2F2ZUJ0bjogc3RyaW5nID0gXCJcIjtcclxuICAgIElzRmlsZUFzQ2FuY2VsQnRuOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgbGFuZ3VhZ2VBcnJheSA9IFtdO1xyXG5cclxuICAgIEFkZHJlc3M6IE9iamVjdCA9IHt9O1xyXG4gICAgUGhvbmVNb2RlbDogT2JqZWN0ID0ge307XHJcbiAgICBFbWFpbE1vZGVsOiBPYmplY3QgPSB7fTtcclxuICAgIElzU2hvd0FsbDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgQ3VzdExpc3Q6IE9iamVjdCA9IHt9O1xyXG4gICAgU0FWRV9CVE5fVEVYVDogc3RyaW5nID0gXCJcIjtcclxuICAgIFxyXG4gICAgQlROX1BIQUREOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgRWRpdFBob25lRGF0YTogT2JqZWN0ID0ge307XHJcbiAgICBFZGl0QWRkcmVzc0RhdGE6IE9iamVjdCA9IHt9O1xyXG4gICAgRWRpdEVtYWlsRGF0YTogT2JqZWN0ID0ge307XHJcbiAgICBhZElkOiBzdHJpbmc7XHJcbiAgICBJc0ZpbGVBc09wZW46IGJvb2xlYW47XHJcbiAgICBBRERfTkVXX0NVU1RfVEVYVDogc3RyaW5nO1xyXG4gICAgQ1NTVEVYVDogc3RyaW5nO1xyXG4gICAgSXNGaWxlQXN0eHRTaG93OiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBGSUxFQVNfQlROX1RFWFQ6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBjc3NGaWxlQXNCdG46IHN0cmluZyA9IFwiXCI7XHJcbiAgICBJc0NhbmNlbDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgU2VhcmNoVmFsOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgRW50ZXJDb3VudDogbnVtYmVyID0gMDtcclxuICAgIFN0b3BUaW1lT3V0OiBhbnk7XHJcbiAgICBDdXN0SWRUZXh0OiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgc3RhdGljICRpbmplY3QgPSBbJyRzY29wZScsICckbG9jYXRpb24nLCAnJGFuY2hvclNjcm9sbCddO1xyXG4gICAgQmFzZUFwcFVybDogc3RyaW5nID0gXCJcIjtcclxuICAgIFBoSW5kZXg6IG51bWJlciA9IDA7XHJcbiAgICBLZW5kb1JUTENTUzogc3RyaW5nID0gXCJcIjtcclxuICAgIENIQU5HRURJUjogc3RyaW5nID0gXCJcIjtcclxuICAgIENoYW5nZURpYWxvZzogc3RyaW5nID0gXCJcIjtcclxuICAgIElzUG9wVXA6IGJvb2xlYW4gPSB0cnVlO1xyXG5cclxuICAgIFxyXG5cclxuICAgIC8vSXNGaWxlQXNTYXZlOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBcclxuICAgIC8vRW1haWw6IHN0cmluZyA9IFwiXCI7XHJcbiAgICAvL0N1c3RvbWVyRW1haWw6IE9iamVjdCA9IHt9O1xyXG4gICAgLy9tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzID0gW107XHJcbiAgICBcclxuICAgIF9DdXN0VHlwZXMgPSBbXTtcclxuICAgIF9Tb3VyY2VzID0gW107XHJcbiAgICBfRW1wbG95ZWVzID0gW107XHJcbiAgICBfU3VmZml4ZXMgPSBbXTtcclxuICAgIF9QaG9uZVR5cGVzID0gW107XHJcbiAgICBfQWRkcmVzc1R5cGVzID0gW107XHJcbiAgICBfR3JvdXBzID0gW107XHJcbiAgICBfQ291bnRyaWVzID0gW107XHJcbiAgICBfU3RhdGVzID0gW107XHJcbiAgICBfQ2l0aWVzID0gW107XHJcbiAgICBfQ3VzdFRpdGxlcyA9IFtdO1xyXG4gICAgcHJpdmF0ZSBzZWxlY3RlZENhcjogc3RyaW5nID0gJyc7XHJcbiAgICBwcml2YXRlIGFzeW5jU2VsZWN0ZWRDYXI6IHN0cmluZyA9ICcnO1xyXG4gICAgcHJpdmF0ZSBhdXRvY29tcGxldGVMb2FkaW5nOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwcml2YXRlIGF1dG9jb21wbGV0ZU5vUmVzdWx0czogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHJpdmF0ZSBhdXRvY29tcGxldGVTZWxlY3Q6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIFxyXG4gICAgcHJpdmF0ZSBnZXRDdXJyZW50Q29udGV4dCgpIHtcclxuICAgICAgICBcclxuICAgICAgICByZXR1cm4gdGhpcztcclxuICAgIH1cclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgX3Jlc291cmNlU2VydmljZTogUmVzb3VyY2VTZXJ2aWNlLCBwcml2YXRlIF9jdXN0b21lclNlcnZpY2U6IEN1c3RvbWVyU2VydmljZSwgcHJpdmF0ZSBfcm91dGVQYXJhbXM6IFJvdXRlUGFyYW1zKSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkJpcnRoRGF0ZSA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzID0gW107XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzID0gW107XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzID0gW107XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyR3JvdXBzID0gW107XHJcbiAgICAgICAgdGhpcy5BZGRyZXNzLkNvdW50cnlDb2RlPVwiXCI7XHJcbiAgICAgICAgdGhpcy5BZGRyZXNzLlN0YXRlSWQgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5lbXBsb3llZWlkID0gXCJcIjtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJUeXBlID0gXCJcIjtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ2FtZUZyb21DdXN0b21lciA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LlNhZml4aWQgPSBcIlwiO1xyXG4gICAgICAgIC8vdGhpcy5tb2RlbElucHV0LkltYWdlRmlsZU5hbWUgPSBcIkRlZmF1bHRVc2VyLmpwZ1wiO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5HZW5kZXIgPSBcIjBcIjtcclxuICAgICAgICB0aGlzLlBob25lTW9kZWwuUGhvbmVUeXBlSWQgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUiA9IHt9O1xyXG4gICAgICAgIHRoaXMuSXNTaG93QWxsID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5TQVZFX0JUTl9URVhUID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9CVE5fU0FWRTtcclxuICAgICAgICB0aGlzLkJUTl9QSEFERCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfQlROX1BIQUREO1xyXG4gICAgICAgIHRoaXMuQUREX05FV19DVVNUX1RFWFQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0xCTF9ORVdfQ1VTVDtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMgPSBbeyBFbWFpbDogXCJcIiwgRW1haWxOYW1lOiBcIlwiLCBOZXdzbGV0dGVyZTogdHJ1ZSwgcHVibGlzaDogMSwgTmV3c09yZGVyOiBcIk5ld3MxXCIsIEVQdWJsaXNoT3JkZXI6XCJFUHViMVwiIH1dXHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzID0gW3sgUGhvbmVUeXBlSWQ6IFwiXCIsIFByZWZpeDogXCJcIiwgQXJlYTogXCJcIiwgUGhvbmU6IFwiXCIsIElzU21zOiAxLCBDb21tZW50czogXCJcIiwgSXNTaG93UmVtYXJrczogZmFsc2UsIHBocHVibGlzaDogMSwgU01TT3JkZXI6IFwiU01TMVwiLFB1Ymxpc2hPcmRlcjogXCJQdWIxXCJ9XVxyXG4gICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAgdmFyIGVtcGlkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJlbXBsb3llZWlkXCIpO1xyXG4gICAgICAgIFxyXG4gICAgICAgIHZhciBjY29kZSA9IHRoaXMuX3Jlc291cmNlU2VydmljZS5nZXRDb29raWUoZW1waWQgKyBcImNjb2RlXCIpO1xyXG4gICAgICAgIGlmIChjY29kZS5sZW5ndGggPiAwKVxyXG4gICAgICAgICAgICBjY29kZSA9IGNjb2RlLnN1YnN0cmluZygxLCBjY29kZS5sZW5ndGgpO1xyXG5cclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMgPSBbe1xyXG4gICAgICAgICAgICBTdHJlZXQ6IFwiXCIsIFN0cmVldDI6IFwiXCIsIENpdHlOYW1lOiBcIlwiLCBaaXA6IFwiXCIsIENvdW50cnlDb2RlOiBjY29kZSwgU3RhdGVJZDogXCJcIiwgQWRkcmVzc1R5cGVJZDogXCJcIixcclxuICAgICAgICAgICAgRm9yRGVsaXZlcnk6IHRydWUsIE1haW5BZGRyZXNzOiB0cnVlLCBNYWluT3JkZXI6IFwiTWFpbkFkZHIxXCIsIERlbHZyeU9yZGVyOiBcIkRlbHZyeTFcIlxyXG4gICAgICAgIH1dXHJcblxyXG4gICAgICAgIFxyXG4gICAgICAgIFxyXG5cclxuICAgICAgICB2YXIgY3VzdHR5cGUgPSB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZ2V0Q29va2llKGVtcGlkICsgXCJjdXN0XCIpO1xyXG4gICAgICAgIGlmIChjdXN0dHlwZS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICBjdXN0dHlwZSA9IGN1c3R0eXBlLnN1YnN0cmluZygxLCBjdXN0dHlwZS5sZW5ndGgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJUeXBlID0gY3VzdHR5cGU7XHJcblxyXG5cclxuICAgICAgICB2YXIgZW1wID0gdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmdldENvb2tpZShlbXBpZCArIFwiZW1wXCIpO1xyXG4gICAgICAgIGlmIChlbXAubGVuZ3RoID4gMClcclxuICAgICAgICAgICAgZW1wID0gZW1wLnN1YnN0cmluZygxLCBlbXAubGVuZ3RoKTtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuZW1wbG95ZWVpZCA9IGVtcDtcclxuXHJcbiAgICAgICAgdmFyIHNvdXJjZSA9IHRoaXMuX3Jlc291cmNlU2VydmljZS5nZXRDb29raWUoZW1waWQgKyBcInNyY1wiKTtcclxuICAgICAgICBpZiAoc291cmNlLmxlbmd0aCA+IDApXHJcbiAgICAgICAgICAgIHNvdXJjZSA9IHNvdXJjZS5zdWJzdHJpbmcoMSwgc291cmNlLmxlbmd0aCk7XHJcbiAgICAgICAgZWxzZSB7XHJcblxyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ2FtZUZyb21DdXN0b21lciA9IHNvdXJjZTtcclxuICAgICAgICB0aGlzLkNTU1RFWFQgPSBcIm1kaS1jb250ZW50LWFkZFwiO1xyXG4gICAgICAgIHRoaXMuY3NzRmlsZUFzQnRuID0gXCJtZGktY29udGVudC1jcmVhdGVcIjtcclxuICAgICAgICB0aGlzLklzRmlsZUFzdHh0U2hvdyA9IGZhbHNlO1xyXG4gICAgICAgIGNsZWFyVGltZW91dCh0aGlzLlN0b3BUaW1lT3V0KTtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCA9IF9yb3V0ZVBhcmFtcy5wYXJhbXMuSWQ7XHJcbiAgICAgICAgdGhpcy5CYXNlQXBwVXJsID0gX3Jlc291cmNlU2VydmljZS5BcHBVcmw7XHJcbiAgICAgICAgdGhpcy5iYXNlVXJsID0gX3Jlc291cmNlU2VydmljZS5iYXNlVXJsO1xyXG4gICAgICAgIHRoaXMuSW1hZ2VVcmwgPSBfcmVzb3VyY2VTZXJ2aWNlLkltYWdlVXJsO1xyXG4gICAgICAgIHRoaXMuVGVtcG1vZGVsSW5wdXQgPSB0aGlzLm1vZGVsSW5wdXQ7XHJcbiAgICAgICAgXHJcbiAgICAgICAgLy9hbGVydCh0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZ2V0Q29va2llKGVtcGlkICsgXCJjdXN0XCIpKTtcclxuICAgICAgICAvL3RoaXMuU2hvd01vcmVUZXh0ID0gXCJNb3JlXCI7XHJcbiAgICAgICAgXHJcbiAgICB9XHJcbiAgICBwcml2YXRlIF9jYWNoZWRSZXN1bHQ6IGFueTtcclxuICAgIHByaXZhdGUgX3ByZXZpb3VzYXN5bmNTZWxlY3RlZENhcjogc3RyaW5nPScnO1xyXG4gICAgXHJcbiAgICBkYXRlU2VsZWN0aW9uQ2hhbmdlKGV2dCkge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGV2dCk7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkJpcnRoRGF0ZSA9IGV2dDtcclxuICAgICAgIC8vIGFsZXJ0KHRoaXMubW9kZWxJbnB1dC5CaXJ0aERhdGUpO1xyXG4gICAgICAgIC8vdGhpcy52YWxpZGF0ZUxvZ2luKCk7XHJcbiAgICB9XHJcblxyXG4gICBwcml2YXRlIGdldEFzeW5jRGF0YShjb250ZXh0OiBhbnkpOiBGdW5jdGlvbiB7XHJcbiAgICAgICAgXHJcbiAgICAgICB2YXIgU3JjaFZhbCA9IGNvbnRleHQuYXN5bmNTZWxlY3RlZENhcjtcclxuICAgICAgXHJcbiAgICAgIC8vIGlmIChTcmNoVmFsICE9IHVuZGVmaW5lZCAmJiBTcmNoVmFsICE9IG51bGwgJiYgU3JjaFZhbCAhPSBcIlwiKSB7XHJcblxyXG4gICAgICAgXHJcbiAgICAgICAgIC8vIGRlYnVnZ2VyO1xyXG4gICAgICAgaWYgKHRoaXMuX3ByZXZpb3VzYXN5bmNTZWxlY3RlZENhciA9PSBjb250ZXh0LmFzeW5jU2VsZWN0ZWRDYXIpIHtcclxuICAgICAgICAgICAgICAgLy9jbGVhclRpbWVvdXQodGhpcy5TdG9wVGltZU91dCk7XHJcbiAgICAgICAgICAgICAgIHJldHVybiB0aGlzLl9jYWNoZWRSZXN1bHQ7XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgLy9hbGVydCh0aGlzLl9wcmV2aW91c2FzeW5jU2VsZWN0ZWRDYXIgKyBcIiB8IFwiICsgY29udGV4dC5hc3luY1NlbGVjdGVkQ2FyKTtcclxuICAgICAgICAgICAgICAgaWYgKGNvbnRleHQuYXN5bmNTZWxlY3RlZENhciAhPSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICB0aGlzLl9wcmV2aW91c2FzeW5jU2VsZWN0ZWRDYXIgPSBjb250ZXh0LmFzeW5jU2VsZWN0ZWRDYXI7XHJcbiAgICAgICAgICAgICAgICAgLy8gIHRoaXMuU3RvcFRpbWVPdXQgPSBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgIC8vICAgIGFsZXJ0KFNyY2hWYWwpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRDb21wbGV0ZVNlYXJjaChTcmNoVmFsKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vYWxlcnQocmVzcG9uc2UuRXJyTXNnKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe21lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRleHQuY2Fyc0V4YW1wbGUxID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vcmV0dXJuIGNvbnRleHQuY2Fyc0V4YW1wbGUxO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgLy8gfSwgNTAwKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICB0aGlzLl9jYWNoZWRSZXN1bHQgPSBjb250ZXh0LmNhcnNFeGFtcGxlMTtcclxuICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgIHRoaXMuX2NhY2hlZFJlc3VsdCA9IFtdO1xyXG4gICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgIHJldHVybiB0aGlzLl9jYWNoZWRSZXN1bHQ7XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgICAgIFxyXG4gICAgICAgIFxyXG4gICAgfVxyXG4gICBcclxuICAgIHByaXZhdGUgY2hhbmdlQXV0b2NvbXBsZXRlTG9hZGluZyhlOiBib29sZWFuKSB7XHJcbiAgICAgICAgdGhpcy5hdXRvY29tcGxldGVMb2FkaW5nID0gZTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIGNoYW5nZUF1dG9jb21wbGV0ZU5vUmVzdWx0cyhlOiBib29sZWFuKSB7XHJcbiAgICAgICAgdGhpcy5hdXRvY29tcGxldGVTZWxlY3QgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLmF1dG9jb21wbGV0ZU5vUmVzdWx0cyA9IGU7XHJcbiAgICB9XHJcbiAgICBwcml2YXRlIGF1dG9jb21wbGV0ZU9uU2VsZWN0KGU6IGFueSkge1xyXG4gICAgICAgIHRoaXMuYXV0b2NvbXBsZXRlU2VsZWN0ID0gdHJ1ZTtcclxuICAgICAgICBjb25zb2xlLmxvZyhgU2VsZWN0ZWQgdmFsdWU6ICR7ZS5pdGVtfWApO1xyXG4gICAgICAgIHZhciBDb21wRGF0YSA9IGUuaXRlbS5zcGxpdCgnfCcpO1xyXG4gICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAgaWYgKGUuaXRlbSAhPSB1bmRlZmluZWQgJiYgZS5pdGVtICE9IFwiXCIgJiYgZS5pdGVtICE9IG51bGwpIHtcclxuICAgICAgICAgICAgLy9hbGVydChDb21wRGF0YVswXSk7XHJcbiAgICAgICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRDb21wbGV0ZUN1c3REZXQoQ29tcERhdGFbMF0udHJpbSgpKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAvL2FsZXJ0KHJlc3BvbnNlLkVyck1zZyk7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7bWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgICAgLy8gYWxlcnQodGhpcy5tb2RlbElucHV0LkJpcnRoRGF0ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5TQVZFX0JUTl9URVhUID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9CVE5fVVBEQVRFO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuQUREX05FV19DVVNUX1RFWFQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0xCTF9ORVdfQ1VTVDtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLkNTU1RFWFQgPSBcIm1kaS1jb250ZW50LWNyZWF0ZVwiO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMubGVuZ3RoID09IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzID0gW3sgRW1haWw6IFwiXCIsIEVtYWlsTmFtZTogdGhpcy5tb2RlbElucHV0LkZpbGVBcywgTmV3c2xldHRlcmU6IGZhbHNlIH1dXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLk5ld3NsZXR0ZXJlID09IFwiMVwiKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuTmV3c2xldHRlcmUgPSBmYWxzZTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLk5ld3NsZXR0ZXJlID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXMubGVuZ3RoID09IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHBoaWQgPSBcIlwiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLl9QaG9uZVR5cGVzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5UZXh0ID09IFwiQ2VsbFBob25lXCIpIHtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGhpZCA9IHRoaXMuVmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lcyA9IFt7IFBob25lVHlwZUlkOiBwaGlkLCBQcmVmaXg6IFwiXCIsIEFyZWE6IFwiXCIsIFBob25lOiBcIlwiLCBJc1NtczogMCwgQ29tbWVudHM6IFwiXCIsIHBocHVibGlzaDogMCB9XTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMubGVuZ3RoID09IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGVtcGlkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJlbXBsb3llZWlkXCIpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGNjb2RlID0gdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmdldENvb2tpZShlbXBpZCArIFwiY2NvZGVcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChjY29kZS5sZW5ndGggPiAwKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2NvZGUgPSBjY29kZS5zdWJzdHJpbmcoMSwgY2NvZGUubGVuZ3RoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGFkaWQgPSBcIlwiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgY29tcHRleHQgPSBcIkhvbWVcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5Db21wYW55ICE9IFwiXCIgJiYgdGhpcy5tb2RlbElucHV0LkNvbXBhbnkgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dC5Db21wYW55ICE9IG51bGwpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbXB0ZXh0ID0gXCJXb3JrXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5fQWRkcmVzc1R5cGVzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5UZXh0ID09IGNvbXB0ZXh0KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWRpZCA9IHRoaXMuVmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3NlcyA9IFt7IFN0cmVldDogXCJcIiwgU3RyZWV0MjogXCJcIiwgQ2l0eU5hbWU6IFwiXCIsIFppcDogXCJcIiwgQ291bnRyeUNvZGU6IGNjb2RlLCBTdGF0ZUlkOiBcIlwiLCBBZGRyZXNzVHlwZUlkOiBhZGlkLCBGb3JEZWxpdmVyeTogZmFsc2UsIE1haW5BZGRyZXNzOiBmYWxzZSB9XTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuQ3VzdElkVGV4dCA9IFwiKCBcIiArIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkICsgXCIgKVwiO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuSXNGaWxlQXN0eHRTaG93ID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgLy90aGlzLklzQ2FuY2VsID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICAvL3RoaXMuSGlkZVNob3dGaWxlQXN0eHQoKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLkNhbmNlbEZpbGVBc3R4dCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuSXNTaG93QWxsID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICAvL3RoaXMuYmluZEdyb3VwKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9hbGVydCh0aGlzLlJFUyk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5iaW5kR3JvdXBUcmVlKHRydWUpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIE9wZW5Qcm9maWxlKCkge1xyXG4gICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkICE9IHVuZGVmaW5lZCAmJiB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCA+PSAwKSB7XHJcbiAgICAgICAgICAgIHZhciBjdXN0SWQgPSB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZDtcclxuICAgICAgICAgICAgaWYgKGN1c3RJZCAhPSAtMSkge1xyXG4gICAgICAgICAgICAgICAgZG9jdW1lbnQubG9jYXRpb24gPSB0aGlzLkJhc2VBcHBVcmwgKyBcIkN1c3RvbWVyL1Byb2ZpbGUvXCIgKyBjdXN0SWQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBPcGVuTmV3UmVjZWlwdCgpIHtcclxuICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0ICE9IHVuZGVmaW5lZCAmJiB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQgPj0gMCkge1xyXG4gICAgICAgICAgICB2YXIgY3VzdElkID0gdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQ7XHJcbiAgICAgICAgICAgIGlmIChjdXN0SWQgIT0gLTEpIHtcclxuICAgICAgICAgICAgICAgIHZhciBlbWlkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJlbXBsb3llZWlkXCIpO1xyXG4gICAgICAgICAgICAgICAgZG9jdW1lbnQubG9jYXRpb24gPSB0aGlzLkJhc2VBcHBVcmwgKyBcIlJlY2VpcHRTZWxlY3QvXCIgKyBlbWlkICsgXCIvXCIgKyBjdXN0SWQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBPcGVuQ2hhcmdlQ3JlZGl0UGFnZSgpIHtcclxuICAgICAgICB0aGlzLklzYnRuZGlzYWJsZSA9IFwiZGlzYWJsZWRcIjtcclxuICAgICAgICB0aGlzLl9jdXN0b21lclNlcnZpY2UuQ2hlY2tJc09wZW5DaGFyZ2UoKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgXHJcblxyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczogeyAgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gfX0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5EYXRhICE9IHVuZGVmaW5lZCAmJiByZXNwb25zZS5EYXRhICE9IG51bGwgJiYgcmVzcG9uc2UuRGF0YS5sZW5ndGggPT0gMSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBjdXN0SWQgPSAtMTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5UZW1wbW9kZWxJbnB1dCAhPSB1bmRlZmluZWQgJiYgdGhpcy5UZW1wbW9kZWxJbnB1dC5DdXN0b21lcklkICE9IHVuZGVmaW5lZCAmJiB0aGlzLlRlbXBtb2RlbElucHV0LkN1c3RvbWVySWQgPj0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjdXN0SWQgPSB0aGlzLlRlbXBtb2RlbElucHV0LkN1c3RvbWVySWRcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dCAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkID49IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY3VzdElkID0gdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWRcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGN1c3RJZCAhPSAtMSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBkb2N1bWVudC5sb2NhdGlvbiA9IHRoaXMuQmFzZUFwcFVybCArIFwiQ2hhcmdlQ3JlZGl0L1wiICsgY3VzdElkICsgXCIvXCIgKyByZXNwb25zZS5EYXRhWzBdLlZhbHVlO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogJ1BsZWFzZSBzYXZlIG5ldyBvciBsb2FkIHByZXZpb3VzIGN1c3RvbWVyIGFuZCB0aGVuIGNsaWNrIG9uIGNoYXJnZSBjcmVkaXQgYnV0dG9uJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIGlmIChyZXNwb25zZS5EYXRhICE9IHVuZGVmaW5lZCAmJiByZXNwb25zZS5EYXRhICE9IG51bGwgJiYgcmVzcG9uc2UuRGF0YS5sZW5ndGggPiAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgY3VzdElkID0gLTE7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuVGVtcG1vZGVsSW5wdXQgIT0gdW5kZWZpbmVkICYmIHRoaXMuVGVtcG1vZGVsSW5wdXQuQ3VzdG9tZXJJZCAhPSB1bmRlZmluZWQgJiYgdGhpcy5UZW1wbW9kZWxJbnB1dC5DdXN0b21lcklkID49IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY3VzdElkID0gdGhpcy5UZW1wbW9kZWxJbnB1dC5DdXN0b21lcklkXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkICE9IHVuZGVmaW5lZCAmJiB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCA+PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGN1c3RJZCA9IHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChjdXN0SWQgIT0gLTEpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZG9jdW1lbnQubG9jYXRpb24gPSB0aGlzLkJhc2VBcHBVcmwgKyBcIlRlcm1pbmFscy9TaG93L1wiICsgY3VzdElkO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiAnUGxlYXNlIHNhdmUgbmV3IG9yIGxvYWQgcHJldmlvdXMgY3VzdG9tZXIgYW5kIHRoZW4gY2xpY2sgb24gY2hhcmdlIGNyZWRpdCBidXR0b24nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAvLyBhbGVydChyZXNwb25zZS5EYXRhLmxlbmd0aCArICcgVGVybWluYWwgU2NyZWVuIGhlbGxvJyk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9NU0dfQ0hBUkdFQ1JFRElULFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0aGlzLlNob3dNc2cgPSB0cnVlO1xyXG4gICAgICAgICAgICB0aGlzLk1zZyA9IHJlc3BvbnNlLkVyck1zZztcclxuICAgICAgICB9LFxyXG4gICAgICAgICAgICBlcnJvcj0+IGNvbnNvbGUubG9nKGVycm9yKSxcclxuICAgICAgICAgICAgKCkgPT4gY29uc29sZS5sb2coXCJTYXZlIENhbGwgQ29tcGxlYXRlZFwiKVxyXG4gICAgICAgICk7XHJcbiAgICAgICAgdGhpcy5Jc2J0bmRpc2FibGUgPSBcIlwiO1xyXG4gICAgfVxyXG4gICAgU3RvcFRpbWVyKCk6IG9ic2VydmFibGUge1xyXG4gICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICBtZXNzYWdlOiAnRnJvbSBTdG9wIFRpbWVyJyArIHRoaXMuU3RvcFRpbWVPdXQsIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgICAgICBjbGVhclRpbWVvdXQodGhpcy5TdG9wVGltZU91dCk7XHJcbiAgICB9XHJcbiAgICBTZXRkZWZhdWx0UGFnZSgpe1xyXG4gICAgICAgIGRvY3VtZW50LmxvY2F0aW9uID0gdGhpcy5CYXNlQXBwVXJsICsgXCJDdXN0b21lci9BZGQvLTFcIjtcclxuICAgICAgICB0aGlzLklzRmlsZUFzdHh0U2hvdyA9IHRydWU7XHJcbiAgICAgICAgdGhpcy5Jc0NhbmNlbCA9IHRydWU7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdmFyIGVtcGlkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJlbXBsb3llZWlkXCIpO1xyXG4gICAgICAgIHRoaXMuYXN5bmNTZWxlY3RlZENhciA9IFwiXCI7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0ID0ge307XHJcbiAgICAgICAgdGhpcy5DdXN0RmlsZUltYWdlID0gXCJEZWZhdWx0VXNlci5qcGdcIjtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQmlydGhEYXRlID0gXCJcIjtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCA9IC0xO1xyXG4gICAgICAgIHRoaXMuQ3VzdElkVGV4dCA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5IaWRlU2hvd0ZpbGVBc3R4dCgpO1xyXG4gICAgICAgIHZhciBjdXN0dHlwZSA9IHRoaXMuX3Jlc291cmNlU2VydmljZS5nZXRDb29raWUoZW1waWQgKyBcImN1c3RcIik7XHJcbiAgICAgICAgaWYgKGN1c3R0eXBlLmxlbmd0aCA+IDApXHJcbiAgICAgICAgICAgIGN1c3R0eXBlID0gY3VzdHR5cGUuc3Vic3RyaW5nKDEsIGN1c3R0eXBlLmxlbmd0aCk7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyVHlwZSA9IGN1c3R0eXBlO1xyXG4gICAgICAgIHZhciBlbXAgPSB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZ2V0Q29va2llKGVtcGlkICsgXCJlbXBcIik7XHJcbiAgICAgICAgaWYgKGVtcC5sZW5ndGggPiAwKVxyXG4gICAgICAgICAgICBlbXAgPSBlbXAuc3Vic3RyaW5nKDEsIGVtcC5sZW5ndGgpO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5lbXBsb3llZWlkID0gZW1wO1xyXG4gICAgICAgIHZhciBzb3VyY2UgPSB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZ2V0Q29va2llKGVtcGlkICsgXCJzcmNcIik7XHJcbiAgICAgICAgaWYgKHNvdXJjZS5sZW5ndGggPiAwKVxyXG4gICAgICAgICAgICBzb3VyY2UgPSBzb3VyY2Uuc3Vic3RyaW5nKDEsIHNvdXJjZS5sZW5ndGgpO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DYW1lRnJvbUN1c3RvbWVyID0gc291cmNlO1xyXG5cclxuICAgICAgICB0aGlzLlNob3dNb3JlID0gZmFsc2U7XHJcbiAgICAgICAgLy90aGlzLlNob3dNb3JlVGV4dCA9IFwiTW9yZVwiOyBcclxuICAgICAgICB0aGlzLlNob3dNb3JlVGV4dCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfTE5LX0xCTF9NT1JFO1xyXG4gICAgICAgIHRoaXMuU0FWRV9CVE5fVEVYVCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfQlROX1NBVkU7XHJcbiAgICAgICAgdGhpcy5DU1NURVhUID0gXCJtZGktY29udGVudC1hZGRcIjtcclxuICAgICAgICB0aGlzLkFERF9ORVdfQ1VTVF9URVhUID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9MQkxfTkVXX0NVU1Q7XHJcbiAgICAgICAgdGhpcy5TaG93R3JvdXBzID0gdHJ1ZTtcclxuICAgICAgICB0aGlzLnNob3doaWRlR3JvdXBzKCk7XHJcbiAgICAgICAgLy90aGlzLkdyb3VwVGV4dCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfTEJMX1NIT1dHUk9VUFM7XHJcblxyXG4gICAgICAgIFxyXG5cclxuICAgICAgICB2YXIgcGhpZCA9IFwiXCI7XHJcbiAgICAgICAgdmFyIFNNUyA9IDA7XHJcbiAgICAgICAgdmFyIHB1Ymxpc2ggPSAwO1xyXG4gICAgICAgIHZhciBlcHVibGlzaCA9IDA7XHJcbiAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5fUGhvbmVUeXBlcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5UZXh0ID09IFwiQ2VsbFBob25lXCIpIHtcclxuXHJcbiAgICAgICAgICAgICAgICBwaGlkID0gdGhpcy5WYWx1ZTtcclxuICAgICAgICAgICAgICAgIFNNUyA9IDE7XHJcbiAgICAgICAgICAgICAgICBwdWJsaXNoID0gMTtcclxuICAgICAgICAgICAgICAgIGVwdWJsaXNoID0gMTtcclxuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXMgPSBbeyBQaG9uZVR5cGVJZDogcGhpZCwgUHJlZml4OiBcIlwiLCBBcmVhOiBcIlwiLCBQaG9uZTogXCJcIiwgSXNTbXM6IFNNUywgQ29tbWVudHM6IFwiXCIsIHBocHVibGlzaDogcHVibGlzaCB9XVxyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcblxyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlscyA9IFt7IEVtYWlsOiBcIlwiLCBFbWFpbE5hbWU6IFwiXCIsIE5ld3NsZXR0ZXJlOiBmYWxzZSwgcHVibGlzaDogZXB1Ymxpc2ggfV1cclxuICAgICAgICB2YXIgY250cnljb2RlID0gdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmdldENvb2tpZShlbXBpZCArIFwiY2NvZGVcIik7XHJcbiAgICAgICAgaWYgKGNudHJ5Y29kZS5sZW5ndGggPiAwKVxyXG4gICAgICAgICAgICBjbnRyeWNvZGUgPSBjbnRyeWNvZGUuc3Vic3RyaW5nKDEsIGNudHJ5Y29kZS5sZW5ndGgpO1xyXG5cclxuICAgICAgICB2YXIgYWRpZCA9IFwiXCI7XHJcbiAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5fQWRkcmVzc1R5cGVzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLlRleHQgPT0gXCJIb21lXCIpIHtcclxuXHJcbiAgICAgICAgICAgICAgICBhZGlkID0gdGhpcy5WYWx1ZTtcclxuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICB9KTtcclxuXHJcblxyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3NlcyA9IFt7IFN0cmVldDogXCJcIiwgU3RyZWV0MjogXCJcIiwgQ2l0eU5hbWU6IFwiXCIsIFppcDogXCJcIiwgQ291bnRyeUNvZGU6IGNudHJ5Y29kZSwgU3RhdGVJZDogXCJcIiwgQWRkcmVzc1R5cGVJZDogYWRpZCwgRm9yRGVsaXZlcnk6IGZhbHNlLCBNYWluQWRkcmVzczogZmFsc2UgfV1cclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJHcm91cHMgPSBbXTtcclxuICAgICAgICB0aGlzLkFkZHJlc3MuQ291bnRyeUNvZGUgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMuQWRkcmVzcy5TdGF0ZUlkID0gXCJcIjtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuU2FmaXhpZCA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkdlbmRlciA9IFwiMFwiO1xyXG4gICAgICAgIHRoaXMuU2hvd01zZyA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMuTXNnID0gXCJcIjtcclxuICAgICAgICB0aGlzLklzU2hvd0FsbCA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRHZW5lcmFsR3JvdXBzKHRoaXMuSXNTaG93QWxsKS5zdWJzY3JpYmUoXHJcbiAgICAgICAgICAgIChkYXRhKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLklzU2hvd0FsbCA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeShcIiNncm91cFRyZWVcIikuaHRtbChcIkxvZGluZy4uLlwiKTtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgcmVzID0galF1ZXJ5LnBhcnNlSlNPTihkYXRhKS5EYXRhXHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5KFwiI2dyb3VwVHJlZVwiKS5rZW5kb1RyZWVWaWV3KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbG9hZE9uRGVtYW5kOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjaGVja2JveGVzOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gIGNoZWNrQ2hpbGRyZW46IHRydWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2s6IGZ1bmN0aW9uIChlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmV4cGFuZFJvb3QgPSBlLm5vZGU7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5leHBhbmQoalF1ZXJ5KHRoaXMuZXhwYW5kUm9vdCkuZmluZChcIi5rLWl0ZW1cIikuYWRkQmFjaygpKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9jaGVjazogdGhpcy5vbkdyb3VwU2VsZWN0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkYXRhU291cmNlOiByZXNcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeShcIiNncm91cFRyZWUxXCIpLmh0bWwoXCJMb2RpbmcuLi5cIik7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIHJlcyA9IGpRdWVyeS5wYXJzZUpTT04oZGF0YSkuRGF0YVxyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeShcIiNncm91cFRyZWUxXCIpLmtlbmRvVHJlZVZpZXcoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsb2FkT25EZW1hbmQ6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrYm94ZXM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgIC8vICAgICAgY2hlY2tDaGlsZHJlbjogdHJ1ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjaGVjazogZnVuY3Rpb24gKGUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZXhwYW5kUm9vdCA9IGUubm9kZTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmV4cGFuZChqUXVlcnkodGhpcy5leHBhbmRSb290KS5maW5kKFwiLmstaXRlbVwiKS5hZGRCYWNrKCkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkYXRhU291cmNlOiByZXNcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgKGVycikgPT4ge1xyXG5cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgKCkgPT4ge1xyXG5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICk7XHJcblxyXG4gICAgICAgIHRoaXMuSXNQb3BVcCA9IHRydWU7XHJcbiAgICB9XHJcbiAgICBDYW5jZWxGaWxlQXN0eHQoKSB7XHJcbiAgICAgICAgdGhpcy5Jc0ZpbGVBc3R4dFNob3cgPSB0cnVlO1xyXG4gICAgICAgIHRoaXMuSXNGaWxlQXN0eHRTaG93ID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5Jc0NhbmNlbCA9IHRydWU7XHJcbiAgICAgICAgalF1ZXJ5KFwiI0ZpbGVBc3R4dFwiKS5oaWRlKCk7XHJcbiAgICAgICAgalF1ZXJ5KFwiI0ZpbGVBc1NwblwiKS5zaG93KCk7XHJcbiAgICAgICAgdGhpcy5GSUxFQVNfQlROX1RFWFQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0JUTl9GSUxFQVM7XHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkICE9IHVuZGVmaW5lZCAmJiB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCAhPSBudWxsICYmIHBhcnNlSW50KCB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCkgPi0xKSB7XHJcbiAgICAgICAgICAgIGpRdWVyeShcIiNGaWxlQXNTYXZlQnRuXCIpLnNob3coKTtcclxuICAgICAgICAgICAgdGhpcy5jc3NGaWxlQXNCdG4gPSBcIm1kaS1jb250ZW50LWNyZWF0ZVwiO1xyXG4gICAgICAgICAgICBqUXVlcnkoXCIjRmlsZUFzQ2FuY2VsQnRuXCIpLmhpZGUoKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIGpRdWVyeShcIiNGaWxlQXNTYXZlQnRuXCIpLmhpZGUoKTtcclxuICAgICAgICAgICAgalF1ZXJ5KFwiI0ZpbGVBc0NhbmNlbEJ0blwiKS5oaWRlKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgXHJcbiAgICBIaWRlU2hvd0ZpbGVBc3R4dCgpOiBvYnNlcnZhYmxlIHtcclxuICAgICAgIFxyXG4gICAgICAgIGlmICh0aGlzLklzRmlsZUFzdHh0U2hvdyA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICB0aGlzLklzRmlsZUFzdHh0U2hvdyA9IHRydWU7XHJcbiAgICAgICAgICAgIGpRdWVyeShcIiNGaWxlQXN0eHRcIikuc2hvdygpO1xyXG4gICAgICAgICAgICBqUXVlcnkoXCIjRmlsZUFzU3BuXCIpLmhpZGUoKTtcclxuICAgICAgICAgICAgdGhpcy5Jc0NhbmNlbCA9IGZhbHNlO1xyXG4gICAgICAgICAgICB0aGlzLkZJTEVBU19CVE5fVEVYVCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfQlROX1NBVkVGSUxFQVM7XHJcbiAgICAgICAgICAgLy8gYWxlcnQodGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQpO1xyXG4gICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkICE9IG51bGwgJiYgcGFyc2VJbnQoIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkKSA+LTEpIHtcclxuICAgICAgICAgICAgICAgIGpRdWVyeShcIiNGaWxlQXNTYXZlQnRuXCIpLnNob3coKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuY3NzRmlsZUFzQnRuID0gXCJtZGktY29udGVudC1zYXZlXCI7XHJcbiAgICAgICAgICAgICAgICBqUXVlcnkoXCIjRmlsZUFzQ2FuY2VsQnRuXCIpLnNob3coKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGpRdWVyeShcIiNGaWxlQXNTYXZlQnRuXCIpLmhpZGUoKTtcclxuICAgICAgICAgICAgICAgIGpRdWVyeShcIiNGaWxlQXNDYW5jZWxCdG5cIikuaGlkZSgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLklzRmlsZUFzdHh0U2hvdyA9IGZhbHNlO1xyXG4gICAgICAgICAgICBqUXVlcnkoXCIjRmlsZUFzdHh0XCIpLmhpZGUoKTtcclxuICAgICAgICAgICAgalF1ZXJ5KFwiI0ZpbGVBc1NwblwiKS5zaG93KCk7XHJcbiAgICAgICAgICAgIHRoaXMuRklMRUFTX0JUTl9URVhUID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9CVE5fRklMRUFTO1xyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkICE9IHVuZGVmaW5lZCAmJiB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCAhPSBudWxsICYmIHBhcnNlSW50KHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkKT4tMSkge1xyXG4gICAgICAgICAgICAgICAgalF1ZXJ5KFwiI0ZpbGVBc1NhdmVCdG5cIikuc2hvdygpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jc3NGaWxlQXNCdG4gPSBcIm1kaS1jb250ZW50LWNyZWF0ZVwiO1xyXG4gICAgICAgICAgICAgICAgalF1ZXJ5KFwiI0ZpbGVBc0NhbmNlbEJ0blwiKS5oaWRlKCk7XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuRmlsZUFzICE9IFwiXCIgJiYgdGhpcy5tb2RlbElucHV0LkZpbGVBcyAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0LkZpbGVBcyAhPSBudWxsICYmIHRoaXMuSXNDYW5jZWwgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9jdXN0b21lclNlcnZpY2UuU2F2ZUZpbGVBcyh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCwgdGhpcy5tb2RlbElucHV0LkZpbGVBcykuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2FsZXJ0KCdoZWxsbycpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2FsZXJ0KHJlc3BvbnNlLkVyck1zZyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vdGhpcy5Jc0ZpbGVBc1NhdmUgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuSXNDYW5jZWwgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9lbHNlIHtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vfVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfRU1QVFlGSUxFQVMsIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmJpbmRGaWxlQXMoKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLklzRmlsZUFzdHh0U2hvdyA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuSGlkZVNob3dGaWxlQXN0eHQoKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGpRdWVyeShcIiNGaWxlQXNTYXZlQnRuXCIpLmhpZGUoKTtcclxuICAgICAgICAgICAgICAgIGpRdWVyeShcIiNGaWxlQXNDYW5jZWxCdG5cIikuaGlkZSgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgfVxyXG4gICAgU2V0RW1haWxOYW1lKCk6IG9ic2VydmFibGUge1xyXG4gICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuRmlsZUFzICE9IHVuZGVmaW5lZCAmJiB0aGlzLm1vZGVsSW5wdXQuRmlsZUFzICE9IG51bGwpIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlscy5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHNbdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzLmxlbmd0aCAtIDFdLkVtYWlsTmFtZSA9IHRoaXMubW9kZWxJbnB1dC5GaWxlQXM7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBDaGVja0N1c3RXaXRoU2FtZU5hbWUoKTogb2JzZXJ2YWJsZSB7XHJcblxyXG4gICAgfVxyXG4gICAgU2V0RGVmYXVsdEN1c3QoKSB7XHJcbiAgICAgICAgLy9hbGVydCgpO1xyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcblxyXG4gICAgfVxyXG5cclxuICAgIHNldGRlZmF1bHRBZGRyZXNzKCkge1xyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMuYmluZEZpbGVBcygpO1xyXG4gICAgICAgIHRoaXMuQ2hlY2tDdXN0V2l0aGZuYW1lbG5hbWVjb21wcGhzZW1haWxzKCk7XHJcbiAgICAgICAgdmFyIGFkaWQgPSBcIlwiO1xyXG4gICAgICAgIHZhciBhZHRleHQgPSBcIkhvbWVcIjtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5Db21wYW55ICE9IFwiXCIgJiYgdGhpcy5tb2RlbElucHV0LkNvbXBhbnkgIT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgIGFkdGV4dCA9IFwiV29ya1wiO1xyXG4gICAgICAgICAgICBcclxuICAgICAgICB9XHJcbiAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5fQWRkcmVzc1R5cGVzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLlRleHQgPT0gYWR0ZXh0KSB7XHJcbiAgICAgICAgICAgICAgICBhZGlkID0gdGhpcy5WYWx1ZTtcclxuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICB9KTtcclxuICAgICAgICBcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXNbdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzLmxlbmd0aCAtIDFdLkFkZHJlc3NUeXBlSWQgPSBhZGlkO1xyXG4gICAgfVxyXG4gICAgYmluZEZpbGVBcygpOiBvYnNlcnZhYmxlIHtcclxuICAgICAgICBcclxuICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkZpbGVBcyA9PSBcIlwiIHx8IHRoaXMubW9kZWxJbnB1dC5GaWxlQXMgPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgIGlmICgodGhpcy5tb2RlbElucHV0LkNvbXBhbnkgPT0gXCJcIiB8fCB0aGlzLm1vZGVsSW5wdXQuQ29tcGFueSA9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgIHZhciBmaWxlYXN0ZXh0ID0gXCJcIjtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuZm5hbWUgIT0gXCJcIiAmJiB0aGlzLm1vZGVsSW5wdXQuZm5hbWUgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dC5sbmFtZSAhPSBcIlwiICYmIHRoaXMubW9kZWxJbnB1dC5sbmFtZSAhPSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgICAgICBmaWxlYXN0ZXh0ID0gdGhpcy5tb2RlbElucHV0LmxuYW1lICsgXCIgXCIgKyB0aGlzLm1vZGVsSW5wdXQuZm5hbWU7XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIGlmICh0aGlzLm1vZGVsSW5wdXQuZm5hbWUgIT0gXCJcIiAmJiB0aGlzLm1vZGVsSW5wdXQuZm5hbWUgIT0gdW5kZWZpbmVkICYmICh0aGlzLm1vZGVsSW5wdXQubG5hbWUgPT0gXCJcIiB8fCB0aGlzLm1vZGVsSW5wdXQubG5hbWUgPT0gdW5kZWZpbmVkKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGZpbGVhc3RleHQgPSBcIiBcIiArIHRoaXMubW9kZWxJbnB1dC5mbmFtZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKCh0aGlzLm1vZGVsSW5wdXQuZm5hbWUgPT0gXCJcIiB8fCB0aGlzLm1vZGVsSW5wdXQuZm5hbWUgPT0gdW5kZWZpbmVkKSAmJiAodGhpcy5tb2RlbElucHV0LmxuYW1lICE9IFwiXCIgJiYgdGhpcy5tb2RlbElucHV0LmxuYW1lICE9IHVuZGVmaW5lZCkpIHtcclxuICAgICAgICAgICAgICAgICAgICBmaWxlYXN0ZXh0ID0gdGhpcy5tb2RlbElucHV0LmxuYW1lICsgXCIgXCI7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuRmlsZUFzID0gZmlsZWFzdGV4dDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIGlmICgodGhpcy5tb2RlbElucHV0LmxuYW1lID09IFwiXCIgfHwgdGhpcy5tb2RlbElucHV0LmxuYW1lID09IHVuZGVmaW5lZCkgJiYgKHRoaXMubW9kZWxJbnB1dC5mbmFtZSA9PSBcIlwiIHx8IHRoaXMubW9kZWxJbnB1dC5sbmFtZSA9PSB1bmRlZmluZWQpKSB7XHJcbiAgICAgICAgICAgICAgICB2YXIgZmlsZWFzdGV4dCA9IFwiXCI7XHJcbiAgICAgICAgICAgICAgICBpZiAoKHRoaXMubW9kZWxJbnB1dC5Db21wYW55ICE9IFwiXCIgJiYgdGhpcy5tb2RlbElucHV0LkNvbXBhbnkgIT0gdW5kZWZpbmVkKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGZpbGVhc3RleHQgPSB0aGlzLm1vZGVsSW5wdXQuQ29tcGFueTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5GaWxlQXMgPSBmaWxlYXN0ZXh0O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2VcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5GaWxlQXMgPSBcIihcIiArIHRoaXMubW9kZWxJbnB1dC5Db21wYW55ICsgXCIpIFwiICsgdGhpcy5tb2RlbElucHV0LmxuYW1lICsgXCIgXCIgKyB0aGlzLm1vZGVsSW5wdXQuZm5hbWU7IC8vKyBcIiBcIiAmIG1fc3RyU3BvdXNlXHJcbiAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzW3RoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlscy5sZW5ndGggLSAxXS5FbWFpbE5hbWUgPSB0aGlzLm1vZGVsSW5wdXQuRmlsZUFzO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuU2V0RW1haWxOYW1lKCk7XHJcbiAgICB9XHJcbiAgICBiaW5kR3JvdXAoKTogdm9pZCB7XHJcbiAgICAgICAgLy9hbGVydCh0aGlzLklzU2hvd0FsbCk7IHRoaXMgZnVuY3Rpb24gaXMgY2FsbGluZyBvbiBjbGljayBvZiBjaGVja2JveFxyXG4gICAgICAgIHZhciBpc3Nob3cgPSBmYWxzZTtcclxuICAgICAgICBpZiAodGhpcy5Jc1Nob3dBbGwgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICBpc3Nob3cgPSBmYWxzZVxyXG4gICAgICAgICAgICB0aGlzLklzU2hvd0FsbCA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5Jc1Nob3dBbGwgPSB0cnVlO1xyXG4gICAgICAgICAgICBpc3Nob3cgPSB0cnVlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGhpcy5iaW5kR3JvdXBUcmVlKGlzc2hvdyk7XHJcbiAgICB9ZGlcclxuICAgIHNhdmVDdXN0b21lckRhdGEoKTogdm9pZCB7XHJcbiAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICB0aGlzLklzYnRuZGlzYWJsZSA9IFwiZGlzYWJsZWRcIjtcclxuICAgICAgICB0aGlzLlNob3dMb2FkZXIgPSB0cnVlO1xyXG4gICAgICAgIHRoaXMuZ2V0U2VsZWN0ZWRHcm91cHMoKTtcclxuICAgICAgIFxyXG4gICAgICAgIHZhciBjb3VudCA9IDA7XHJcbiAgICAgICAgXHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3NlcyAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzICE9IG51bGwpIHtcclxuICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5NYWluQWRkcmVzcyA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY291bnQgPSBjb3VudCArIDE7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBpZiAoY291bnQgPiAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9ib290Ym94LmFsZXJ0KFwiTWFpbiBBZGRyZXNzIHNob2x1ZCBiZSBvbmx5IG9uZVwiKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5Jc2J0bmRpc2FibGUgPSBcIlwiO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuU2hvd0xvYWRlciA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vYWxlcnQodGhpcy5tb2RlbElucHV0LkJpcnRoRGF0ZSk7XHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5CaXJ0aERhdGUgIT0gXCJcIikge1xyXG4gICAgICAgICAgICBpZiAobW9tZW50KHRoaXMubW9kZWxJbnB1dC5CaXJ0aERhdGUsIFwiREQtTU0tWVlZWVwiLCB0cnVlKS5pc1ZhbGlkKCkgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoeyBtZXNzYWdlOiBcIkJpcnRoZGF0ZSBpcyBub3QgdmFsaWRcIiB9KTtcclxuXHJcbiAgICAgICAgICAgICAgICB0aGlzLklzYnRuZGlzYWJsZSA9IFwiXCI7XHJcbiAgICAgICAgICAgICAgICB0aGlzLlNob3dMb2FkZXIgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuVGl0bGUgPSBqUXVlcnkoXCIjVGl0bGVcIikudmFsKCk7XHJcbiAgICAgICAgaWYgKGNvdW50IDw9IDEgfHwgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzID09IHVuZGVmaW5lZCB8fCB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMgPT0gbnVsbCkge1xyXG5cclxuICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lcyAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzICE9IG51bGwpIHtcclxuICAgICAgICAgICAgICAgIHZhciBwaHRlbXAgPSBbXTtcclxuICAgICAgICAgICAgICAgIGpRdWVyeSgnaW5wdXRbbmFtZV49XCJwaFwiXScpLmVhY2goZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHBodGVtcC5wdXNoKGpRdWVyeSh0aGlzKS52YWwoKSk7XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIHZhciBhcnRlbXAgPSBbXTtcclxuICAgICAgICAgICAgICAgIGpRdWVyeSgnaW5wdXRbbmFtZV49XCJhclwiXScpLmVhY2goZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGFydGVtcC5wdXNoKGpRdWVyeSh0aGlzKS52YWwoKSk7XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIHZhciBwcmV0ZW1wID0gW107XHJcbiAgICAgICAgICAgICAgICBqUXVlcnkoJ2lucHV0W25hbWVePVwicHJlXCJdJykuZWFjaChmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcHJldGVtcC5wdXNoKGpRdWVyeSh0aGlzKS52YWwoKSk7XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIHZhciBpID0gMDtcclxuICAgICAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLklzU21zID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5Jc1NtcyA9IFwiMVwiO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5Jc1NtcyA9IFwiMFwiO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5waHB1Ymxpc2ggPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnBocHVibGlzaCA9IFwiMVwiO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5waHB1Ymxpc2ggPSBcIjBcIjtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5QaG9uZSA9IHBodGVtcFtpXTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLkFyZWEgPSBhcnRlbXBbaV07XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5QcmVmaXggPSBwcmV0ZW1wW2ldO1xyXG4gICAgICAgICAgICAgICAgICAgIGkrKztcclxuICAgICAgICAgICAgICAgICAgICAvL3ZhciB0ZW1wID0gdGhpcy5QaG9uZVR5cGVJZC5zcGxpdCgnOycpO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vdGhpcy5QaG9uZVR5cGVJZCA9IHBhcnNlSW50KHRlbXBbMV0pO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vdGhpcy5QaG9uZVR5cGUgPSB0ZW1wWzBdO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlscyAhPSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5wdWJsaXNoID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5wdWJsaXNoID0gXCIxXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnB1Ymxpc2ggPSBcIjBcIjtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5OZXdzbGV0dGVyZSA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuTmV3c2xldHRlcmUgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuTmV3c2xldHRlcmUgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICBpKys7XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB2YXIgamRhdGEgPSBKU09OLnN0cmluZ2lmeSh0aGlzLm1vZGVsSW5wdXQpO1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhqZGF0YSlcclxuICAgICAgICAgICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmRlbGV0ZUNvb2tpZShcIlRlbXBJbWFnZU5hbWVcIik7XHJcbiAgICAgICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5BZGRDdXN0b21lcihqZGF0YSkuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2cocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuSXNidG5kaXNhYmxlID0gXCJcIjtcclxuICAgICAgICAgICAgICAgIHRoaXMuU2hvd0xvYWRlciA9IGZhbHNlO1xyXG5cclxuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAvL2FsZXJ0KHJlc3BvbnNlLkVyck1zZyk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5Nc2dDbGFzcyA9IFwidGV4dC1kYW5nZXJcIjtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIC8vYWxlcnQocmVzcG9uc2UuRXJyTXNnKTtcclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLk1zZ0NsYXNzID0gXCJ0ZXh0LXN1Y2Nlc3NcIjtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgZW1waWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImVtcGxveWVlaWRcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLnNldENvb2tpZShlbXBpZCArIFwiY3VzdFwiLCB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJUeXBlLCAxMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLnNldENvb2tpZShlbXBpZCArIFwiZW1wXCIsIHRoaXMubW9kZWxJbnB1dC5lbXBsb3llZWlkLCAxMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLnNldENvb2tpZShlbXBpZCArIFwic3JjXCIsIHRoaXMubW9kZWxJbnB1dC5DYW1lRnJvbUN1c3RvbWVyLCAxMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3Nlcy5sZW5ndGg+MClcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLnNldENvb2tpZShlbXBpZCArIFwiY2NvZGVcIiwgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzW3RoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3Nlcy5sZW5ndGggLSAxXS5Db3VudHJ5Q29kZSwgMTApO1xyXG4gICAgICAgICAgICAgICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9kb2N1bWVudC5sb2NhdGlvbiA9IHRoaXMuQmFzZUFwcFVybCArIFwiQ3VzdG9tZXIvQWRkLy0xXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLlRlbXBtb2RlbElucHV0ID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZWRpdEN1c3REZXQodGhpcy5tb2RlbElucHV0KTtcclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAvL3RoaXMuSXNQb3BVcCA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgLy90aGlzLlNldGRlZmF1bHRQYWdlKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gUmVzZXQgZm9ybSB2YWx1ZXNcclxuICAgICAgICAgICAgICAgICAgICAvL3RoaXMuX0N1c3RUeXBlcyA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB0aGlzLlNob3dNc2cgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5Nc2cgPSByZXNwb25zZS5FcnJNc2c7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICBlcnJvcj0+IGNvbnNvbGUubG9nKGVycm9yKSxcclxuICAgICAgICAgICAgICAgICgpID0+IGNvbnNvbGUubG9nKFwiU2F2ZSBDYWxsIENvbXBsZWF0ZWRcIilcclxuICAgICAgICAgICAgKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgbWVzc2FnZTogdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9NU0dfSVNNQUlOQURELCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB0aGlzLklzYnRuZGlzYWJsZSA9IFwiXCI7XHJcbiAgICAgICAgICAgIHRoaXMuU2hvd0xvYWRlciA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBDaGVja0N1c3RXaXRoZm5hbWVsbmFtZWNvbXBwaHNlbWFpbHMoKTogb2JzZXJ2YWJsZSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgICAgIC8vdGhpcy5tb2RlbElucHV0LkltYWdlRmlsZU5hbWUgPSB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZ2V0Q29va2llKFwiVGVtcEltYWdlTmFtZVwiKTtcclxuICAgICAgICBpZiAodGhpcy5Jc1BvcFVwID09IHRydWUpIHtcclxuICAgICAgICAgICAgdmFyIGpkYXRhID0gSlNPTi5zdHJpbmdpZnkodGhpcy5tb2RlbElucHV0KTtcclxuICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgdmFyIGZuYW1lID0gXCJcIjtcclxuICAgICAgICAgICAgdmFyIGxuYW1lID0gXCJcIjtcclxuICAgICAgICAgICAgdmFyIGNvbXBhbnkgPSBcIlwiO1xyXG4gICAgICAgICAgICB2YXIgcGhvbmVzID0gXCJcIjtcclxuICAgICAgICAgICAgdmFyIGVtYWlscyA9IFwiXCI7XHJcblxyXG4gICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LmZuYW1lID09IHVuZGVmaW5lZClcclxuICAgICAgICAgICAgICAgIGZuYW1lID0gXCJcIjtcclxuICAgICAgICAgICAgZWxzZVxyXG4gICAgICAgICAgICAgICAgZm5hbWUgPSB0aGlzLm1vZGVsSW5wdXQuZm5hbWU7XHJcblxyXG4gICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LmxuYW1lID09IHVuZGVmaW5lZClcclxuICAgICAgICAgICAgICAgIGxuYW1lID0gXCJcIjtcclxuICAgICAgICAgICAgZWxzZVxyXG4gICAgICAgICAgICAgICAgbG5hbWUgPSB0aGlzLm1vZGVsSW5wdXQubG5hbWU7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ29tcGFueSA9PSB1bmRlZmluZWQpXHJcbiAgICAgICAgICAgICAgICBjb21wYW55ID0gXCJcIjtcclxuICAgICAgICAgICAgZWxzZVxyXG4gICAgICAgICAgICAgICAgY29tcGFueSA9IHRoaXMubW9kZWxJbnB1dC5Db21wYW55O1xyXG5cclxuICAgICAgICAgICAgalF1ZXJ5KCdpbnB1dFtuYW1lXj1cInBoXCJdJykuZWFjaChmdW5jdGlvbiAoKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKGpRdWVyeSh0aGlzKS52YWwoKSAhPSBcIlwiICYmIGpRdWVyeSh0aGlzKS52YWwoKSAhPSB1bmRlZmluZWQgJiYgalF1ZXJ5KHRoaXMpLnZhbCgpICE9IG51bGwgJiYgalF1ZXJ5KHRoaXMpLnZhbCgpLmxlbmd0aCA+PSAzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcGhvbmVzICs9IGpRdWVyeSh0aGlzKS52YWwoKSArIFwiJywnXCI7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICBpZiAocGhvbmVzLmxlbmd0aCA+IDApIHBob25lcyA9IHBob25lcy5zdWJzdHJpbmcoMCwgcGhvbmVzLmxlbmd0aCAtIDMpO1xyXG4gICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLkVtYWlsICE9IFwiXCIgJiYgdGhpcy5FbWFpbCAhPSB1bmRlZmluZWQgJiYgdGhpcy5FbWFpbCAhPSBudWxsICYmIHRoaXMuRW1haWwubGVuZ3RoID49IDMpIHtcclxuICAgICAgICAgICAgICAgICAgICBlbWFpbHMgKz0gdGhpcy5FbWFpbCArIFwiJywnXCI7XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgaWYgKGVtYWlscy5sZW5ndGggPiAwKSBlbWFpbHMgPSBlbWFpbHMuc3Vic3RyaW5nKDAsIGVtYWlscy5sZW5ndGggLSAzKTtcclxuICAgICAgICAgICAgaWYgKChmbmFtZSAhPSBcIlwiICYmIGZuYW1lLmxlbmd0aCA+PSAyICYmIGxuYW1lICE9IFwiXCIgJiYgbG5hbWUubGVuZ3RoID49IDIpXHJcbiAgICAgICAgICAgICAgICB8fCAoY29tcGFueSAhPSBcIlwiICYmIGNvbXBhbnkubGVuZ3RoID49IDMpXHJcbiAgICAgICAgICAgICAgICB8fCAocGhvbmVzICE9IFwiXCIpXHJcbiAgICAgICAgICAgICAgICB8fCAoZW1haWxzICE9IFwiXCIpKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkdldEN1c3RvbWVyc1NlYXJjaERhdGEoZm5hbWUsIGxuYW1lLCBjb21wYW55LCBwaG9uZXMsIGVtYWlscykuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5DdXN0TGlzdCA9IHt9O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLkN1c3RMaXN0ID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLkRhdGEgIT0gbnVsbCAmJiByZXNwb25zZS5EYXRhICE9IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jdXN0U2VhcmNoRGF0YSA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBqUXVlcnkoJyNDdXN0TW9kYWwnKS5vcGVuTW9kYWwoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9qUXVlcnkoJyNDdXN0TW9kYWwnKS5tb2RhbCgnb3BlbicpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9qUXVlcnkoXCIjQ3VzdE1vZGFsXCIpLnNob3coMTAwMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9hbGVydCh0aGlzLlJFUyk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgICAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgLy90aGlzLmJpbmRGaWxlQXMoKTtcclxuICAgIH1cclxuICAgIENsb3NlTW9kYWxQb3AoKSB7XHJcbiAgICAgICAgdGhpcy5DbG9zZVBvcFVwKCk7XHJcbiAgICAgICAgdGhpcy5Jc1BvcFVwID0gZmFsc2U7XHJcbiAgICB9XHJcbiAgICBDbG9zZVBvcFVwKCkge1xyXG4gICAgICAgIGpRdWVyeShcIiNDdXN0TW9kYWxcIikuY2xvc2VNb2RhbCgpO1xyXG4gICAgICAgIGpRdWVyeShcIi5sZWFuLW92ZXJsYXlcIikuY3NzKHsgXCJkaXNwbGF5XCI6IFwibm9uZVwiIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIENoZWNrQ3VzdFdpdGhmbmFtZWxuYW1lKGZuYW1lLCBsbmFtZSxjb21wYW55KTogb2JzZXJ2YWJsZSB7XHJcbiAgICAgICAgdmFyIGpkYXRhID0gSlNPTi5zdHJpbmdpZnkodGhpcy5tb2RlbElucHV0KTtcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuZm5hbWUgPT0gdW5kZWZpbmVkKVxyXG4gICAgICAgICAgICBmbmFtZSA9IFwiXCI7XHJcbiAgICAgICAgZWxzZVxyXG4gICAgICAgICAgICBmbmFtZSA9IHRoaXMubW9kZWxJbnB1dC5mbmFtZTtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5sbmFtZSA9PSB1bmRlZmluZWQpXHJcbiAgICAgICAgICAgIGxuYW1lID0gXCJcIjtcclxuICAgICAgICBlbHNlXHJcbiAgICAgICAgICAgIGxuYW1lID0gdGhpcy5tb2RlbElucHV0LmxuYW1lO1xyXG4gICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ29tcGFueSA9PSB1bmRlZmluZWQpXHJcbiAgICAgICAgICAgIGNvbXBhbnkgPSBcIlwiO1xyXG4gICAgICAgIGVsc2VcclxuICAgICAgICAgICAgY29tcGFueSA9IHRoaXMubW9kZWxJbnB1dC5Db21wYW55O1xyXG4gICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5DaGVja0N1c3RXaXRoU2FtZU5hbWUoZm5hbWUsIGxuYW1lLCBjb21wYW55KS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZywgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLkN1c3RMaXN0ID0ge307XHJcbiAgICAgICAgICAgICAgICB0aGlzLkN1c3RMaXN0ID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5EYXRhICE9IG51bGwgJiYgcmVzcG9uc2UuRGF0YSAhPSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmN1c3RTZWFyY2hEYXRhID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkoXCIjQ3VzdE1vZGFsXCIpLm9wZW5Nb2RhbCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIC8valF1ZXJ5KFwiI0N1c3RNb2RhbFwiKS5zaG93KDEwMDApO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLy9hbGVydCh0aGlzLlJFUyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgLy90aGlzLmJpbmRGaWxlQXMoKTtcclxuICAgIH1cclxuXHJcblxyXG5cclxuXHJcbiAgICBDaGVja0N1c3RXaXRoRW1haWwoKTogb2JzZXJ2YWJsZSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgLy92YXIgRW1haWwgPSBcIlwiO1xyXG4gICAgICAgIC8vaWYgKHRoaXMuRW1haWxNb2RlbC5FbWFpbCAhPSBcIlwiICYmIHRoaXMuRW1haWxNb2RlbC5FbWFpbCAhPSB1bmRlZmluZWQpXHJcbiAgICAgICAgLy8gICAgRW1haWwgPSB0aGlzLkVtYWlsTW9kZWwuRW1haWw7XHJcbiAgICAgICAgLy90aGlzLl9jdXN0b21lclNlcnZpY2UuQ2hlY2tDdXN0V2l0aFNhbWVFbWFpbChFbWFpbCkuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgIC8vICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgLy8gICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAvLyAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgLy8gICAgICAgIGFsZXJ0KHJlc3BvbnNlLkVyck1zZyk7XHJcbiAgICAgICAgLy8gICAgfVxyXG4gICAgICAgIC8vICAgIGVsc2Uge1xyXG4gICAgICAgIC8vICAgICAgICB0aGlzLkN1c3RMaXN0ID0ge307XHJcbiAgICAgICAgLy8gICAgICAgIHRoaXMuQ3VzdExpc3QgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgIC8vICAgICAgICBpZiAocmVzcG9uc2UuRGF0YSAhPSBudWxsICYmIHJlc3BvbnNlLkRhdGEgIT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgLy8gICAgICAgICAgICB0aGlzLmN1c3RTZWFyY2hEYXRhID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAvLyAgICAgICAgICAgIGpRdWVyeShcIiNDdXN0TW9kYWxcIikubW9kYWwoXCJzaG93XCIpO1xyXG4gICAgICAgIC8vICAgICAgICB9XHJcbiAgICAgICAgLy8gICAgICAgIC8vYWxlcnQodGhpcy5SRVMpO1xyXG4gICAgICAgIC8vICAgIH1cclxuICAgICAgICAvL30sIGVycm9yPT4ge1xyXG4gICAgICAgIC8vICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICAvL30sICgpID0+IHtcclxuICAgICAgICAvLyAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICAvL30pO1xyXG4gICAgfVxyXG4gICAgQ2hlY2tDdXN0V2l0aFBob25lKCk6IG9ic2VydmFibGUge1xyXG4gICAgICAgIHZhciBQaG9uZSA9IFwiXCI7XHJcbiAgICAgICAgaWYgKHRoaXMuUGhvbmVNb2RlbC5QaG9uZSAhPSBcIlwiICYmIHRoaXMuUGhvbmVNb2RlbC5QaG9uZSAhPSB1bmRlZmluZWQpXHJcbiAgICAgICAgICAgIFBob25lID0gdGhpcy5QaG9uZU1vZGVsLlBob25lO1xyXG4gICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5DaGVja0N1c3RXaXRoU2FtZVBob25lKHRoaXMuUGhvbmVNb2RlbC5QaG9uZSkuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5DdXN0TGlzdCA9IHt9O1xyXG4gICAgICAgICAgICAgICAgdGhpcy5DdXN0TGlzdCA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuRGF0YSAhPSBudWxsICYmIHJlc3BvbnNlLkRhdGEgIT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jdXN0U2VhcmNoRGF0YSA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5KFwiI0N1c3RNb2RhbFwiKS5vcGVuTW9kYWwoKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC8vYWxlcnQodGhpcy5SRVMpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG4gICAgU2hvd1JlbWFya3MoUGhPYmopOiBPYnNlcnZhYmxlIHtcclxuICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMgPT0gUGhPYmopIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuSXNTaG93UmVtYXJrcyA9IHRydWU7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcbiAgICBzaG93QWRkUG9wdXAoKTogb2JzZXJ2YWJsZSB7XHJcbiAgICAgICAgdGhpcy5BZGRyZXNzID0ge307XHJcbiAgICAgICAgdGhpcy5QaG9uZU1vZGVsID0ge307XHJcbiAgICAgICAgdGhpcy5QaG9uZU1vZGVsLlBob25lVHlwZUlkID0gXCJcIjtcclxuICAgICAgICB0aGlzLkFkZHJlc3MuQ291bnRyeUNvZGUgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMuQWRkcmVzcy5TdGF0ZUlkID0gXCJcIjtcclxuICAgICAgICB0aGlzLkFkZHJlc3MuQ2l0eU5hbWUgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMuQWRkcmVzcy5BZGRyZXNzVHlwZUlkID0gXCJcIjtcclxuICAgICAgICB0aGlzLkVtYWlsTW9kZWwgPSB7fTtcclxuICAgICAgICB0aGlzLkJUTl9QSEFERCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfQlROX1BIQUREXHJcbiAgICAgICAgXHJcblxyXG4gICAgfVxyXG4gICAgc2hvd2hpZGVHcm91cHMoKTogb2JzZXJ2YWJsZSB7XHJcbiAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICBpZiAodGhpcy5TaG93R3JvdXBzID09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuU2hvd0dyb3VwcyA9IHRydWU7XHJcbiAgICAgICAgICAgIHRoaXMuR3JvdXBUZXh0ID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9MQkxfSElERUdST1VQO1xyXG4gICAgICAgICAgICBqUXVlcnkoXCIjR3JwRGl2XCIpLnNob3coMTAwMCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLlNob3dHcm91cHMgPSBmYWxzZTtcclxuICAgICAgICAgICAgdGhpcy5Hcm91cFRleHQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0xCTF9TSE9XR1JPVVBTO1xyXG4gICAgICAgICAgICBqUXVlcnkoXCIjR3JwRGl2XCIpLmhpZGUoMTAwMCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgIH1cclxuXHJcblxyXG4gICAgQ2FuYWRkQWRkcmVzcyhhZG9iaik6IGJvb2xlYW4ge1xyXG4gICAgICAgIC8vYWxlcnQoJ0hlbGxvJyk7XHJcbiAgICAgICAgcmV0dXJuIChhZG9iai5TdHJlZXQgIT0gdW5kZWZpbmVkICYmIGFkb2JqLlN0cmVldCAhPSBcIlwiKVxyXG4gICAgICAgICAgICAmJiAoYWRvYmouU3RyZWV0MiAhPSB1bmRlZmluZWQgJiYgYWRvYmouU3RyZWV0MiAhPSBcIlwiKVxyXG4gICAgICAgICAgICAvLyYmIChhZG9iai5DaXR5TmFtZSAhPSB1bmRlZmluZWQgJiYgYWRvYmouQ2l0eU5hbWUgIT0gXCJcIilcclxuICAgICAgICAgICAgJiYgKGFkb2JqLlppcCAhPSB1bmRlZmluZWQgJiYgYWRvYmouWmlwICE9IFwiXCIpIFxyXG4gICAgICAgICAgICAmJiAoYWRvYmouQ291bnRyeUNvZGUgIT0gdW5kZWZpbmVkICYmIGFkb2JqLkNvdW50cnlDb2RlICE9IFwiXCIgKVxyXG4gICAgICAgICAgICAvLyYmICh0aGlzLkFkZHJlc3MuU3RhdGVJZCAhPSB1bmRlZmluZWQgJiYgdGhpcy5BZGRyZXNzLlN0YXRlSWQgIT0gXCJcIilcclxuICAgICAgICAgICAgJiYgKGFkb2JqLkFkZHJlc3NUeXBlSWQgIT0gdW5kZWZpbmVkICYmIGFkb2JqLkFkZHJlc3NUeXBlSWQgIT0gXCJcIik7XHJcbiAgICB9XHJcbiAgICBBZGRBZGRyZXNzZXMoYWRvYmopOiBvYnNlcnZhYmxlIHtcclxuICAgICAgICBcclxuICAgICAgICB2YXIgSXNNYWluQWRkID0gZmFsc2U7XHJcbiAgICAgICAgYWRvYmouQ2l0eU5hbWUgPSBqUXVlcnkoXCIjQ2l0eVwiKS52YWwoKTtcclxuICAgICAgICBcclxuICAgICAgICBpZiAodGhpcy5DYW5hZGRBZGRyZXNzKGFkb2JqKSkge1xyXG5cclxuICAgICAgICAgICAgdmFyIGVtcGlkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJlbXBsb3llZWlkXCIpO1xyXG4gICAgICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2Uuc2V0Q29va2llKGVtcGlkICsgXCJjY29kZVwiLCBhZG9iai5Db3VudHJ5Q29kZSwgMTApO1xyXG4gICAgICAgICAgICB2YXIgYWRpZCA9IFwiXCI7XHJcbiAgICAgICAgICAgIHZhciBhZHRleHQgPSBcIkhvbWVcIjtcclxuICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5Db21wYW55ICE9IFwiXCIgJiYgdGhpcy5tb2RlbElucHV0LkNvbXBhbnkgIT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgICAgICBhZHRleHQgPSBcIldvcmtcIjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLl9BZGRyZXNzVHlwZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLlRleHQgPT0gYWR0ZXh0KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYWRpZCA9IHRoaXMuVmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIHZhciBBZGRyZXNPYmogPSB7IFN0cmVldDogXCJcIiwgU3RyZWV0MjogXCJcIiwgQ2l0eU5hbWU6IFwiXCIsIFppcDogXCJcIiwgQ291bnRyeUNvZGU6IGFkb2JqLkNvdW50cnlDb2RlLCBTdGF0ZUlkOiBcIlwiLCBBZGRyZXNzVHlwZUlkOiBhZGlkLCBGb3JEZWxpdmVyeTogZmFsc2UsIE1haW5BZGRyZXNzOiBmYWxzZSwsIE1haW5PcmRlcjogXCJNYWluQWRkclwiICsgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3Nlcy5sZW5ndGgrMSkudG9TdHJpbmcoKSwgRGVsdnJ5T3JkZXI6IFwiRGVsdnJ5XCIgKyAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzLmxlbmd0aCsxKS50b1N0cmluZygpIH07XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIC8valF1ZXJ5LmVhY2godGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAvLyAgICBpZiAodGhpcy5NYWluQWRkcmVzcyA9PSB0cnVlICYmIGFkb2JqLk1haW5BZGRyZXNzID09IHRydWUgJiYgdGhpcyAhPSBhZG9iaikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICBhZG9iai5NYWluQWRkcmVzcyA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgIC8vICAgIH1cclxuICAgICAgICAgICAgICAgIC8vfSk7XHJcbiAgICAgICAgICAgICAgICBpZiAoSXNNYWluQWRkID09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzLnB1c2goQWRkcmVzT2JqKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICB2YXIgbXNnID0gJyc7XHJcbiAgICAgICAgICAgIGlmIChhZG9iai5TdHJlZXQgPT0gdW5kZWZpbmVkIHx8IGFkb2JqLlN0cmVldCA9PSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICAvL21zZyArPSAnXFxuU3RyZWV0IGlzIG5vdCBmaWxsZWQnOyBBUFBfQUxfTVNHX1NUUkVFVFxyXG4gICAgICAgICAgICAgICAgbXNnICs9ICdcXG4nICsgdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9BTF9NU0dfU1RSRUVUO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChhZG9iai5TdHJlZXQyID09IHVuZGVmaW5lZCB8fCBhZG9iai5TdHJlZXQyID09IFwiXCIpIHtcclxuICAgICAgICAgICAgICAgIC8vbXNnICs9ICdcXG5BcmVhIGlzIG5vdCBmaWxsZWQnO1xyXG4gICAgICAgICAgICAgICAgbXNnICs9ICdcXG4nICsgdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9BTF9NU0dfQVJFQTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAvL2lmIChhZG9iai5DaXR5TmFtZSA9PSB1bmRlZmluZWQgfHwgYWRvYmouQ2l0eU5hbWUgPT0gXCJcIilcclxuICAgICAgICAgICAgLy8gICAgLy9tc2cgKz0gJ1xcbkNpdHkgaXMgbm90IGZpbGxlZCc7IFxyXG4gICAgICAgICAgICAvLyAgICBtc2cgKz0gJ1xcbicgKyB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0FMX01TR19DSVRZO1xyXG4gICAgICAgICAgICBpZiAoYWRvYmouWmlwID09IHVuZGVmaW5lZCB8fCBhZG9iai5aaXAgPT0gXCJcIikge1xyXG4gICAgICAgICAgICAgICAgLy9tc2cgKz0gJ1xcblppcCBpcyBub3QgZmlsbGVkJzsgXHJcbiAgICAgICAgICAgICAgICBtc2cgKz0gJ1xcbicrdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9BTF9NU0dfWklQO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChhZG9iai5Db3VudHJ5Q29kZSA9PSB1bmRlZmluZWQgfHwgYWRvYmouQ291bnRyeUNvZGUgPT0gXCJcIikge1xyXG4gICAgICAgICAgICAgICAgLy9tc2cgKz0gJ1xcbkNvdW50cnkgaXMgbm90IHNlbGVjdGVkJztcclxuICAgICAgICAgICAgICAgIG1zZyArPSAnXFxuJyArIHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfQUxfTVNHX0NPVU5UUlk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgLy9pZiAodGhpcy5BZGRyZXNzLlN0YXRlSWQgPT0gdW5kZWZpbmVkIHx8IHRoaXMuQWRkcmVzcy5TdGF0ZUlkID09IFwiXCIpIHtcclxuICAgICAgICAgICAgLy8gICAgbXNnICs9ICdcXG5TdGF0ZSBpcyBub3Qgc2VsZWN0ZWQnO1xyXG4gICAgICAgICAgICAvL31cclxuICAgICAgICAgICAgaWYgKGFkb2JqLkFkZHJlc3NUeXBlSWQgPT0gdW5kZWZpbmVkIHx8IGFkb2JqLkFkZHJlc3NUeXBlSWQgPT0gXCJcIikge1xyXG4gICAgICAgICAgICAgICAgLy9tc2cgKz0gJ1xcbkFkZHJlc3MgdHlwZSBpcyBub3Qgc2VsZWN0ZWQnO1xyXG4gICAgICAgICAgICAgICAgbXNnICs9ICdcXG4nICsgdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9BTF9NU0dfQURUWVBFO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgbWVzc2FnZTogbXNnLCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICB9XHJcbiAgICBDYW5hZGRQaG9uZShwaG9uZU9iaik6IGJvb2xlYW4ge1xyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgLy9hbGVydCh0aGlzLlBob25lTW9kZWwuUGhvbmVUeXBlSWQgKyAnICcgKyB0aGlzLlBob25lTW9kZWwuUGhvbmVUeXBlICsgJyAnICsgdGhpcy5QaG9uZU1vZGVsLlByZWZpeCArICcgJyArIHRoaXMuUGhvbmVNb2RlbC5BcmVhICsgJyAnICsgdGhpcy5QaG9uZU1vZGVsLlBob25lKTtcclxuICAgICAgICByZXR1cm4gKHBob25lT2JqLlBob25lVHlwZUlkICE9IHVuZGVmaW5lZCAmJiBwaG9uZU9iai5QaG9uZVR5cGVJZCAhPSBcIlwiKVxyXG4gICAgICAgICAgICAvLyAmJiAodGhpcy5QaG9uZU1vZGVsLlBob25lVHlwZSAhPSB1bmRlZmluZWQmJiB0aGlzLlBob25lTW9kZWwuUGhvbmVUeXBlICE9IFwiXCIgKVxyXG4gICAgICAgICAgICAvLyYmICh0aGlzLlBob25lTW9kZWwuUHJlZml4ICE9IHVuZGVmaW5lZCYmIHRoaXMuUGhvbmVNb2RlbC5QcmVmaXggIT0gXCJcIiAgKVxyXG4gICAgICAgICAgICAvLyYmICh0aGlzLlBob25lTW9kZWwuQXJlYSAhPSB1bmRlZmluZWQmJnRoaXMuUGhvbmVNb2RlbC5BcmVhICE9IFwiXCIgIClcclxuICAgICAgICAgICAgLy8mJiAocGhvbmVPYmouUGhvbmUgIT0gdW5kZWZpbmVkICYmIHBob25lT2JqLlBob25lICE9IFwiXCIpO1xyXG4gICAgICAgICAgICAvLyYmICh0aGlzLlBob25lTW9kZWwuUHJlZml4ICE9IHVuZGVmaW5lZCAmJiB0aGlzLlBob25lTW9kZWwuUHJlZml4Lmxlbmd0aCAhPSAzKTsgICAgICAgICAgICA7XHJcbiAgICB9XHJcbiAgICBBZGRQaG9uZXMocGhvbmVPYmopOiBvYnNlcnZhYmxlIHtcclxuICAgICAgICBpZiAodGhpcy5DYW5hZGRQaG9uZShwaG9uZU9iaikpIHtcclxuXHJcbiAgICAgICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAgICAgIC8vaWYgKHRoaXMuSXNSZWNvcmRFZGl0TW9kZSA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICB2YXIgcGhpZCA9IFwiXCI7XHJcbiAgICAgICAgICAgIHZhciBTTVMgPSAwO1xyXG4gICAgICAgICAgICB2YXIgcHVibGlzaCA9IDA7XHJcbiAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMuX1Bob25lVHlwZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLlRleHQgPT0gXCJDZWxsUGhvbmVcIikge1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBwaGlkID0gdGhpcy5WYWx1ZTtcclxuICAgICAgICAgICAgICAgICAgICBTTVMgPSAxO1xyXG4gICAgICAgICAgICAgICAgICAgIHB1Ymxpc2ggPSAxO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIHZhciBQaG9uZU9iaiA9IHsgUGhvbmVUeXBlSWQ6IHBoaWQsIFBob25lVHlwZTogXCJcIiwgUHJlZml4OiBcIlwiLCBBcmVhOiBcIlwiLCBQaG9uZTogXCJcIiwgSXNTbXM6IFNNUywgQ29tbWVudHM6IFwiXCIsIElzU2hvd1JlbWFya3M6IGZhbHNlLCBwaHB1Ymxpc2g6IHB1Ymxpc2gsIFNNU09yZGVyOiBcIlNNU1wiICsgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lcy5sZW5ndGggKyAxKS50b1N0cmluZygpLCBQdWJsaXNoT3JkZXI6IFwiUHViXCIgKyAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzLmxlbmd0aCArIDEpLnRvU3RyaW5nKCkgfTtcclxuICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lcy5wdXNoKFBob25lT2JqKTtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAvL3RoaXMuQ2hlY2tDdXN0V2l0aGZuYW1lbG5hbWVjb21wcGhzZW1haWxzKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICB2YXIgbXNnID0gJyc7XHJcbiAgICAgICAgICAgIGlmIChwaG9uZU9iai5QaG9uZVR5cGVJZCA9PSB1bmRlZmluZWQgfHwgcGhvbmVPYmouUGhvbmVUeXBlSWQgPT0gXCJcIikge1xyXG4gICAgICAgICAgICAgICAgLy9tc2cgKz0gJ1xcblBob25lIHR5cGUgaXMgbm90IHNlbGVjdGVkJztcclxuICAgICAgICAgICAgICAgIG1zZyArPSAnXFxuJyArIHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfQUxfUkVHTVNHX1BIVFlQRTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAvL2lmIChwaG9uZU9iai5QaG9uZSA9PSB1bmRlZmluZWQgfHwgcGhvbmVPYmouUGhvbmUgPT0gXCJcIikge1xyXG4gICAgICAgICAgICAvLyAgICAvL21zZyArPSAnXFxuUGhvbmUgbnVtYmVyIGlzIG5vdCBmaWxsZWQnO1xyXG4gICAgICAgICAgICAvLyAgICBtc2cgKz0gJ1xcbicgKyB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0FMX1JFR01TR19QSE5PO1xyXG4gICAgICAgICAgICAvL31cclxuICAgICAgICAgICAgLy9pZiAodGhpcy5QaG9uZU1vZGVsLlByZWZpeC5sZW5ndGghPTMpIHtcclxuICAgICAgICAgICAgLy8gICAgbXNnICs9ICdcXG5QcmVmaXggbXVzdCBvZiAzIG51bWVyaWMgZGlnaXRzJztcclxuICAgICAgICAgICAgLy99XHJcbiAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgbWVzc2FnZTogbXNnLGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgIH1cclxuICAgIENhbmFkZEVtYWlsKEVtYWlsT2JqKTogYm9vbGVhbiB7XHJcbiAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAvL2FsZXJ0KCdIZWxsbycpO1xyXG4gICAgICAgIHJldHVybiAoRW1haWxPYmouRW1haWxOYW1lICE9IHVuZGVmaW5lZCAmJiBFbWFpbE9iai5FbWFpbE5hbWUgIT0gXCJcIik7XHJcbiAgICAgICAgLy8oRW1haWxPYmouRW1haWwgIT0gdW5kZWZpbmVkICYmIEVtYWlsT2JqLkVtYWlsICE9IFwiXCIpICYmXHJcbiAgICAgICAgICAgICBcclxuICAgIH1cclxuICAgIEFkZEVtYWlscyhFbWFpbE9iaik6IG9ic2VydmFibGUge1xyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgaWYgKHRoaXMuQ2FuYWRkRW1haWwoRW1haWxPYmopKSB7XHJcbiAgICAgICAgICAgIHZhciBlcHVibGlzaCA9IDA7XHJcbiAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMuX1Bob25lVHlwZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgaWYgKHRoaXMuVGV4dCA9PSBcIkNlbGxQaG9uZVwiKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgZXB1Ymxpc2ggPSAxO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIC8vaWYgKHRoaXMuSXNSZWNvcmRFZGl0TW9kZSA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICB2YXIgZU9iaiA9IHt9O1xyXG4gICAgICAgICAgICBlT2JqLkVtYWlsID0gXCJcIjtcclxuICAgICAgICAgICAgZU9iai5FbWFpbE5hbWUgPSB0aGlzLm1vZGVsSW5wdXQuRmlsZUFzO1xyXG4gICAgICAgICAgICBlT2JqLk5ld3NsZXR0ZXJlID0gdHJ1ZTtcclxuICAgICAgICAgICAgZU9iai5wdWJsaXNoID0gZXB1Ymxpc2g7XHJcbiAgICAgICAgICAgIGVPYmouTmV3c09yZGVyPSBcIk5ld3NcIiArICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMubGVuZ3RoKzEpLnRvU3RyaW5nKCk7XHJcbiAgICAgICAgICAgIGVPYmouRVB1Ymxpc2hPcmRlcj0gXCJFUHViXCIgKyAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzLmxlbmd0aCArIDEpLnRvU3RyaW5nKCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMucHVzaChlT2JqKTtcclxuICAgICAgICAgICAgICAgIC8vdGhpcy5DaGVja0N1c3RXaXRoZm5hbWVsbmFtZWNvbXBwaHNlbWFpbHMoKTtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICB2YXIgbXNnID0gJyc7XHJcbiAgICAgICAgICAgIC8vaWYgKEVtYWlsT2JqLkVtYWlsID09IHVuZGVmaW5lZCB8fCBFbWFpbE9iai5FbWFpbCA9PSBcIlwiKVxyXG4gICAgICAgICAgICAvLyAgICAvL21zZyArPSAnXFxuRW1haWwgaXMgbm90IGZpbGxlZCc7XHJcbiAgICAgICAgICAgIC8vICAgIG1zZyArPSAnXFxuJyArIHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfQUxfUkVHTVNHX0VNQUlMO1xyXG4gICAgICAgICAgICBpZiAoRW1haWxPYmouRW1haWxOYW1lID09IHVuZGVmaW5lZCB8fCBFbWFpbE9iai5FbWFpbE5hbWUgPT0gXCJcIikge1xyXG4gICAgICAgICAgICAgICAgLy9tc2cgKz0gJ1xcbk5hbWUgaXMgbm90IGZpbGxlZCc7XHJcbiAgICAgICAgICAgICAgICBtc2cgKz0gJ1xcbicgKyB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0FMX1JFR01TR19FTkFNRTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgIG1lc3NhZ2U6IG1zZywgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgICAgIC8vIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3NlcyA9IHRoaXMuQ3VzdG9tZXJBZGRyZXNzZXM7XHJcbiAgICB9XHJcbiAgICBcclxuICAgIGVkaXRDdXN0RGV0KE9iaikge1xyXG4gICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRDb21wbGV0ZUN1c3REZXQoT2JqLkN1c3RvbWVySWQpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgIC8vICBkZWJ1Z2dlcjtcclxuICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dCA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICB0aGlzLlNBVkVfQlROX1RFWFQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0JUTl9VUERBVEU7XHJcbiAgICAgICAgICAgICAgICAvL3RoaXMuQUREX05FV19DVVNUX1RFWFQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0xCTF9VUERBVEVfQ1VTVDtcclxuICAgICAgICAgICAgICAgIHRoaXMuQ1NTVEVYVCA9IFwibWRpLWNvbnRlbnQtYWRkXCI7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzLmxlbmd0aCA9PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzID0gW3sgRW1haWw6IFwiXCIsIEVtYWlsTmFtZTogdGhpcy5tb2RlbElucHV0LkZpbGVBcywgTmV3c2xldHRlcmU6IGZhbHNlLCBwdWJsaXNoOiAwLCBOZXdzT3JkZXI6IFwiTmV3czFcIiwgRVB1Ymxpc2hPcmRlcjogXCJFUHViMVwiIH1dXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgY291bnQgPSAxO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5OZXdzT3JkZXIgPSBcIk5ld3NcIiArIGNvdW50O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLkVQdWJsaXNoT3JkZXIgPSBcIkVQdWJcIiArIGNvdW50Kys7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLk5ld3NsZXR0ZXJlID09IFwiMVwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLk5ld3NsZXR0ZXJlID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLk5ld3NsZXR0ZXJlID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lcy5sZW5ndGggPT0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBwaGlkID0gXCJcIjtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5fUGhvbmVUeXBlcywgZnVuY3Rpb24gKCkge1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuVGV4dCA9PSBcIkNlbGxQaG9uZVwiKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGhpZCA9IHRoaXMuVmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzID0gW3sgUGhvbmVUeXBlSWQ6IHBoaWQsIFByZWZpeDogXCJcIiwgQXJlYTogXCJcIiwgUGhvbmU6IFwiXCIsIElzU21zOiAwLCBDb21tZW50czogXCJcIiwgcGhwdWJsaXNoOiAwLCBTTVNPcmRlcjogXCJTTVMxXCIsIFB1Ymxpc2hPcmRlcjogXCJQdWIxXCIgfV07XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgY291bnQgPSAxO1xyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lcywgZnVuY3Rpb24gKCkge1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5TTVNPcmRlciA9IFwiU01TXCIgKyBjb3VudDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5QdWJsaXNoT3JkZXIgPSBcIlB1YlwiICsgY291bnQrKztcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMubGVuZ3RoID09IDApIHtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgZW1waWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImVtcGxveWVlaWRcIik7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHZhciBjY29kZSA9IHRoaXMuX3Jlc291cmNlU2VydmljZS5nZXRDb29raWUoZW1waWQgKyBcImNjb2RlXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChjY29kZS5sZW5ndGggPiAwKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjY29kZSA9IGNjb2RlLnN1YnN0cmluZygxLCBjY29kZS5sZW5ndGgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBhZGlkID0gXCJcIjtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgY29tcHRleHQgPSBcIkhvbWVcIjtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkNvbXBhbnkgIT0gXCJcIiAmJiB0aGlzLm1vZGVsSW5wdXQuQ29tcGFueSAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0LkNvbXBhbnkgIT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb21wdGV4dCA9IFwiV29ya1wiO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLl9BZGRyZXNzVHlwZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuVGV4dCA9PSBjb21wdGV4dCkge1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFkaWQgPSB0aGlzLlZhbHVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3NlcyA9IFt7IFN0cmVldDogXCJcIiwgU3RyZWV0MjogXCJcIiwgQ2l0eU5hbWU6IFwiXCIsIFppcDogXCJcIiwgQ291bnRyeUNvZGU6IGNjb2RlLCBTdGF0ZUlkOiBcIlwiLCBBZGRyZXNzVHlwZUlkOiBhZGlkLCBGb3JEZWxpdmVyeTogZmFsc2UsIE1haW5BZGRyZXNzOiBmYWxzZSwgTWFpbk9yZGVyOiBcIk1haW5BZGRyMVwiLCBEZWx2cnlPcmRlcjogXCJEZWx2cnkxXCIgfV07XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgY291bnQgPSAxO1xyXG4gICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5NYWluT3JkZXIgPSBcIk1haW5BZGRyXCIgKyBjb3VudDtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLkRlbHZyeU9yZGVyID0gXCJEZWx2cnlcIiArIGNvdW50Kys7XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC8vdmFyIHRyZWV2aWV3ID0galF1ZXJ5KFwiI2dyb3VwVHJlZVwiKS5kYXRhKFwia2VuZG9UcmVlVmlld1wiKTtcclxuXHJcbiAgICAgICAgICAgICAgICAvL3ZhciBiYXIgPSB0cmVldmlldy5maW5kQnlJZChcIkJhclwiKTtcclxuXHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIC8valF1ZXJ5LmVhY2godGhpcy5tb2RlbElucHV0LkN1c3RvbWVyR3JvdXBzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAvLyAgICB2YXIgZGF0YSA9IGpRdWVyeShcIiNncm91cFRyZWVcIikuZGF0YShcImtlbmRvVHJlZVZpZXdcIikuZGF0YVNvdXJjZS5nZXRCeVVpZCh0aGlzLkN1c3RvbWVyR2VuZXJhbEdyb3VwSWQpO1xyXG4gICAgICAgICAgICAgICAgLy8gICAgaWYgKGRhdGEpIHtcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICBkYXRhLnNldChcImNoZWNrZWRcIiwgdHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICAvLyAgICB9XHJcbiAgICAgICAgICAgICAgICAvLyAgICAvL3ZhciBHcm91cE5vZGUgPSB0cmVldmlldy5maW5kQnlJZCh0aGlzLkN1c3RvbWVyR2VuZXJhbEdyb3VwSWQpO1xyXG4gICAgICAgICAgICAgICAgLy8gICAgLy90cmVldmlldy5kYXRhSXRlbShHcm91cE5vZGUpLnNldChcImNoZWNrZWRcIiwgdHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICAvL30pO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5DdXN0SWRUZXh0ID0gXCIoIFwiICsgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQgKyBcIiApXCI7XHJcbiAgICAgICAgICAgICAgICB0aGlzLklzRmlsZUFzdHh0U2hvdyA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5IaWRlU2hvd0ZpbGVBc3R4dCgpO1xyXG4gICAgICAgICAgICAgICAgLy90aGlzLm1vZGVsSW5wdXQuSW1hZ2VGaWxlTmFtZSA9IFwiRGVmYXVsdFVzZXIuanBnXCI7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkltYWdlRmlsZU5hbWUgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dC5JbWFnZUZpbGVOYW1lICE9IG51bGwgJiYgdGhpcy5tb2RlbElucHV0LkltYWdlRmlsZU5hbWUgIT0gXCJcIikge1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBPcmdJZCA9IFwiXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIGVtcGlkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJlbXBsb3llZWlkXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChlbXBpZCAhPSBudWxsICYmIGVtcGlkICE9IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBPcmdJZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKGVtcGlkICsgXCJfT3JnSWRcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuQ3VzdEZpbGVJbWFnZSA9IE9yZ0lkK1wiLy9cIit0aGlzLm1vZGVsSW5wdXQuSW1hZ2VGaWxlTmFtZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuQ3VzdEZpbGVJbWFnZSA9IFwiRGVmYXVsdFVzZXIuanBnXCI7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgLy9hbGVydCh0aGlzLlJFUyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHRoaXMuQ2xvc2VQb3BVcCgpO1xyXG4gICAgICAgIC8vLy8vL0ZvciBDbG9zaW5nIERpc3BsYXkgUG9wdXAvLy8vLy8vLy8vLy8vXHJcbiAgICAgICAgdGhpcy5Jc1BvcFVwID0gZmFsc2U7XHJcblxyXG4gICAgfVxyXG4gICAgQ2hlY2tQaG9uZVR5cGUoUGhvbmVPYmopIHtcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgIC8vYWxlcnQoUGhvbmVPYmouUGhvbmVUeXBlSWQgKyBcIiB8IFwiICsgalF1ZXJ5KFwiI1Bob25lVHlwZVwiKS52YWwoKSk7XHJcbiAgICAgICAgdmFyIHByZXRlbXAgPSBbXTtcclxuICAgICAgICBqUXVlcnkoJ3NlbGVjdFtuYW1lXj1cInBodHlwZVwiXScpLmVhY2goZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICBwcmV0ZW1wLnB1c2goalF1ZXJ5KHRoaXMpLnZhbCgpKTtcclxuICAgICAgICB9KTtcclxuICAgICAgICB2YXIgaW5kZXggPSAwO1xyXG4gICAgICAgIGpRdWVyeS5lYWNoKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICBpZiAodGhpcyA9PSBQaG9uZU9iaikge1xyXG5cclxuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGluZGV4ID0gaW5kZXggKyAxO1xyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBpZiAocHJldGVtcFtpbmRleF0gIT0gdW5kZWZpbmVkICYmIHByZXRlbXBbaW5kZXhdICE9IG51bGwgJiYgcHJldGVtcFtpbmRleF0gIT0gXCJcIikge1xyXG4gICAgICAgICAgICB2YXIgUGhvbmVUeXBlSWQgPSBwcmV0ZW1wW2luZGV4XTtcclxuICAgICAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkdldFBob25lVHlwZURldChQaG9uZVR5cGVJZCkuc3Vic2NyaWJlKFxyXG4gICAgICAgICAgICAgICAgKGRhdGEpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vXHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihkYXRhKTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLkRhdGEgIT0gdW5kZWZpbmVkICYmIHJlc3BvbnNlLkRhdGEgIT0gbnVsbCAmJiByZXNwb25zZS5EYXRhICE9IFwiXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9hbGVydChpbmRleCArIFwiIHwgXCIgKyB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXNbaW5kZXhdLklzU21zICsgXCIgfCBcIiArIHJlc3BvbnNlLkRhdGEuVGV4dCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuRGF0YS5UZXh0ID09IFwiMVwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzW2luZGV4XS5Jc1NtcyA9IDE7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzW2luZGV4XS5waHB1Ymxpc2ggPSAxO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlsc1t0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMubGVuZ3RoIC0gMV0ucHVibGlzaCA9IDE7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXNbaW5kZXhdLnBocHVibGlzaCA9IDA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzW2luZGV4XS5Jc1NtcyA9IDA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzW3RoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlscy5sZW5ndGggLSAxXS5wdWJsaXNoID0gMDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9hbGVydCh0aGlzLlJFUyk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8vdmFyIHRyZWV2aWV3RGF0YVNvdXJjZSA9IGpRdWVyeShcIiNncm91cFRyZWVcIikuZGF0YShcImtlbmRvVHJlZVZpZXdcIikuZGF0YVNvdXJjZS52aWV3KCk7XHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgKGVycikgPT4ge1xyXG5cclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAoKSA9PiB7XHJcblxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgIH1cclxuICAgIGVkaXRFbWFpbERldChFbWFpbE9iaik6IG9ic2VydmFibGUge1xyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgdmFyIGluZGV4ID0gMDtcclxuICAgICAgICB0aGlzLklzUmVjb3JkRWRpdE1vZGUgPSB0cnVlO1xyXG4gICAgICAgIHRoaXMuQlROX1BIQUREID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9CVE5fUEhFRElUO1xyXG4gICAgICAgIFxyXG5cclxuICAgICAgICBcclxuICAgICAgICB0aGlzLkVtYWlsTW9kZWwuRW1haWwgPSBFbWFpbE9iai5FbWFpbDtcclxuICAgICAgICB0aGlzLkVtYWlsTW9kZWwuRW1haWxOYW1lID0gRW1haWxPYmouRW1haWxOYW1lO1xyXG4gICAgICAgIHRoaXMuRW1haWxNb2RlbC5OZXdzbGV0dGVyZSA9IEVtYWlsT2JqLk5ld3NsZXR0ZXJlO1xyXG5cclxuXHJcbiAgICAgICAgdGhpcy5FZGl0RW1haWxEYXRhID0ge307XHJcbiAgICAgICAgdGhpcy5FZGl0RW1haWxEYXRhID0gRW1haWxPYmo7XHJcbiAgICB9XHJcbiAgICBkZWxFbWFpbERldChFbWFpbE9iaik6IG9ic2VydmFibGUge1xyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlscy5sZW5ndGggPiAxKSB7XHJcblxyXG4gICAgICAgICAgICB2YXIgaW5kZXggPSAwO1xyXG4gICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzID09IEVtYWlsT2JqKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBpbmRleCA9IGluZGV4ICsgMTtcclxuXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMuc3BsaWNlKGluZGV4LCAxKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgZWRpdEFkZHJlc3NEZXQoQWRkcmVzc09iaik6IG9ic2VydmFibGUge1xyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgdmFyIGluZGV4ID0gMDtcclxuICAgICAgICB0aGlzLklzUmVjb3JkRWRpdE1vZGUgPSB0cnVlO1xyXG4gICAgICAgIHRoaXMuQlROX1BIQUREID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9CVE5fUEhFRElUO1xyXG4gICAgICAgIFxyXG4gICAgICAgLy8gQWRkcmVzc09iai5DaXR5TmFtZSA9IGpRdWVyeShcIiNDaXR5XCIpLnZhbCgpO1xyXG5cclxuICAgICAgICB0aGlzLkFkZHJlc3MuU3RyZWV0ID0gQWRkcmVzc09iai5TdHJlZXQ7XHJcbiAgICAgICAgdGhpcy5BZGRyZXNzLlN0cmVldDIgPSBBZGRyZXNzT2JqLlN0cmVldDI7XHJcbiAgICAgICAgdGhpcy5BZGRyZXNzLkNpdHlOYW1lID0gQWRkcmVzc09iai5DaXR5TmFtZTtcclxuICAgICAgICB0aGlzLkFkZHJlc3MuWmlwID0gQWRkcmVzc09iai5aaXA7XHJcbiAgICAgICAgdGhpcy5BZGRyZXNzLkNvdW50cnlDb2RlID0gQWRkcmVzc09iai5Db3VudHJ5Q29kZTtcclxuICAgICAgICB0aGlzLkFkZHJlc3MuU3RhdGVJZCA9IEFkZHJlc3NPYmouU3RhdGVJZDtcclxuICAgICAgICB0aGlzLkFkZHJlc3MuQWRkcmVzc1R5cGVJZCA9IEFkZHJlc3NPYmouQWRkcmVzc1R5cGVJZDtcclxuICAgICAgICB0aGlzLkFkZHJlc3MuTWFpbkFkZHJlc3MgPSBBZGRyZXNzT2JqLk1haW5BZGRyZXNzO1xyXG4gICAgICAgIHRoaXMuQWRkcmVzcy5Gb3JEZWxpdmVyeSA9IEFkZHJlc3NPYmouRm9yRGVsaXZlcnk7XHJcblxyXG5cclxuICAgICAgICB0aGlzLkVkaXRBZGRyZXNzRGF0YSA9IHt9O1xyXG4gICAgICAgIHRoaXMuRWRpdEFkZHJlc3NEYXRhID0gQWRkcmVzc09iajtcclxuICAgIH1cclxuXHJcbiAgICBkZWxBZGRyZXNzRGV0KEFkZHJlc3NPYmopOiBvYnNlcnZhYmxlIHtcclxuICAgICAgIC8vIGRlYnVnZ2VyOyBcclxuICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzID4gMSkge1xyXG4gICAgICAgICAgICB2YXIgaW5kZXggPSAwO1xyXG4gICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzID09IEFkZHJlc3NPYmopIHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGluZGV4ID0gaW5kZXggKyAxO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzLnNwbGljZShpbmRleCwgMSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgZWRpdFBob25lRGV0KFBob25lT2JqKTogb2JzZXJ2YWJsZSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdmFyIGluZGV4ID0gMDtcclxuICAgICAgICB0aGlzLkJUTl9QSEFERCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfQlROX1BIRURJVFxyXG4gICAgICAgIHZhciB0ZW1wID0gUGhvbmVPYmouUGhvbmVUeXBlSWQuc3BsaXQoJzsnKTtcclxuICAgICAgICBcclxuICAgICAgICB0aGlzLlBob25lTW9kZWwuUGhvbmVUeXBlSWQgPSBQaG9uZU9iai5QaG9uZVR5cGUgKyBcIjtcIiArIFBob25lT2JqLlBob25lVHlwZUlkO1xyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMuUGhvbmVNb2RlbC5QaG9uZVR5cGUgPSBQaG9uZU9iai5QaG9uZVR5cGU7XHJcbiAgICAgICAgdGhpcy5QaG9uZU1vZGVsLlByZWZpeCA9IFBob25lT2JqLlByZWZpeDtcclxuICAgICAgICB0aGlzLlBob25lTW9kZWwuQXJlYSA9IFBob25lT2JqLkFyZWE7XHJcbiAgICAgICAgdGhpcy5QaG9uZU1vZGVsLlBob25lID0gUGhvbmVPYmouUGhvbmU7XHJcbiAgICAgICAgdGhpcy5QaG9uZU1vZGVsLklzU21zID0gUGhvbmVPYmouSXNTbXM7XHJcbiAgICAgICAgdGhpcy5QaG9uZU1vZGVsLkNvbW1lbnRzID0gUGhvbmVPYmouQ29tbWVudHM7XHJcbiAgICAgICAgdGhpcy5FZGl0UGhvbmVEYXRhID0ge307XHJcbiAgICAgICAgdGhpcy5FZGl0UGhvbmVEYXRhID0gUGhvbmVPYmo7XHJcbiAgICB9XHJcbiAgICBkZWxQaG9uZURldChQaG9uZU9iaik6IG9ic2VydmFibGUge1xyXG4gICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lcy5sZW5ndGggPiAxKSB7XHJcbiAgICAgICAgICAgIHZhciBpbmRleCA9IDA7XHJcbiAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMgPT0gUGhvbmVPYmopIHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGluZGV4ID0gaW5kZXggKyAxO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzLnNwbGljZShpbmRleCwgMSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuXHJcbiAgICBnZXRTZWxlY3RlZEdyb3VwcygpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJHcm91cHMgPSBbXTtcclxuICAgICAgICB2YXIgX0NoZWNrZWRHcm91cHMgPSBbXTtcclxuICAgICAgICBpZiAodGhpcy5Jc1Nob3dBbGwgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgS2VuZG9fdXRpbGl0eS5jaGVja2VkTm9kZUlkcyhqUXVlcnkoXCIjZ3JvdXBUcmVlXCIpLmRhdGEoXCJrZW5kb1RyZWVWaWV3XCIpLmRhdGFTb3VyY2UudmlldygpLCBfQ2hlY2tlZEdyb3Vwcyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgIFxyXG4gICAgICAgICAgICBLZW5kb191dGlsaXR5LmNoZWNrZWROb2RlSWRzKGpRdWVyeShcIiNncm91cFRyZWUxXCIpLmRhdGEoXCJrZW5kb1RyZWVWaWV3XCIpLmRhdGFTb3VyY2UudmlldygpLCBfQ2hlY2tlZEdyb3Vwcyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGZvciAodmFyIGkgPSAwO2k8X0NoZWNrZWRHcm91cHMubGVuZ3RoO2krKyl7XHJcbiAgICAgICAgICAgIHZhciBHT2JqID0ge307XHJcbiAgICAgICAgICAgIEdPYmouQ3VzdG9tZXJHZW5lcmFsR3JvdXBJZCA9IF9DaGVja2VkR3JvdXBzW2ldO1xyXG4gICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJHcm91cHMucHVzaChHT2JqKTtcclxuICAgICBcclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICB9XHJcblxyXG4gICAgTW9yZSgpOiBvYnNlcnZhYmxlIHtcclxuICAgICAgIC8vIGFsZXJ0KFwiY2FsbFwiKTtcclxuICAgICAgICBpZiAodGhpcy5TaG93TW9yZSA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuU2hvd01vcmUgPSBmYWxzZTtcclxuXHJcbiAgICAgICAgICAgIC8vdGhpcy5TaG93TW9yZVRleHQgPSBcIk1vcmVcIjtcclxuICAgICAgICAgICAgdGhpcy5TaG93TW9yZVRleHQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0xOS19MQkxfTU9SRTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgdGhpcy5TaG93TW9yZSA9IHRydWU7XHJcbiAgICAgICAgLy90aGlzLlNob3dNb3JlVGV4dCA9IFwiTGVzc1wiOyBcclxuICAgICAgICB0aGlzLlNob3dNb3JlVGV4dCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfTE5LX0xCTF9MRVNTO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLkJpbmRDdXN0VGl0bGVzKCk7XHJcbiAgICB9XHJcbiAgICBiaW5kR3JvdXBUcmVlKElzc2hvd2FsbCk6IG9ic2VydmFibGUge1xyXG4gICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRHZW5lcmFsR3JvdXBzKElzc2hvd2FsbCkuc3Vic2NyaWJlKFxyXG4gICAgICAgICAgICAoZGF0YSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgIC8vXHJcbiAgICAgICAgICAgICAgICAvL2FsZXJ0KElzc2hvd2FsbCk7XHJcbiAgICAgICAgICAgICAgICBpZiAoSXNzaG93YWxsID09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5KFwiI2dyb3VwVHJlZVwiKS5odG1sKFwiTG9kaW5nLi4uXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciByZXMgPSBqUXVlcnkucGFyc2VKU09OKGRhdGEpLkRhdGFcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkoXCIjZ3JvdXBUcmVlXCIpLmtlbmRvVHJlZVZpZXcoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsb2FkT25EZW1hbmQ6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrYm94ZXM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvLyAgY2hlY2tDaGlsZHJlbjogdHJ1ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjaGVjazogZnVuY3Rpb24gKGUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZXhwYW5kUm9vdCA9IGUubm9kZTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmV4cGFuZChqUXVlcnkodGhpcy5leHBhbmRSb290KS5maW5kKFwiLmstaXRlbVwiKS5hZGRCYWNrKCkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2NoZWNrOiB0aGlzLm9uR3JvdXBTZWxlY3QsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhdGFTb3VyY2U6IHJlc1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBncnBpZHMgPSBcIlwiO1xyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckdyb3VwcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBncnBpZHMgKz0gdGhpcy5DdXN0b21lckdlbmVyYWxHcm91cElkICsgXCI7XCI7XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGdycGlkcy5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEtlbmRvX3V0aWxpdHkuY2hlY2tpbmdOb2RlSWRzKGpRdWVyeShcIiNncm91cFRyZWVcIikuZGF0YShcImtlbmRvVHJlZVZpZXdcIikuZGF0YVNvdXJjZS52aWV3KCksIGdycGlkcy5zdWJzdHJpbmcoMCwgZ3JwaWRzLmxlbmd0aCAtIDEpKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeShcIiNncm91cFRyZWUxXCIpLmh0bWwoXCJMb2RpbmcuLi5cIik7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIHJlcyA9IGpRdWVyeS5wYXJzZUpTT04oZGF0YSkuRGF0YVxyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeShcIiNncm91cFRyZWUxXCIpLmtlbmRvVHJlZVZpZXcoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsb2FkT25EZW1hbmQ6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrYm94ZXM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vY2hlY2tDaGlsZHJlbjogdHJ1ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjaGVjazogZnVuY3Rpb24gKGUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZXhwYW5kUm9vdCA9IGUubm9kZTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmV4cGFuZChqUXVlcnkodGhpcy5leHBhbmRSb290KS5maW5kKFwiLmstaXRlbVwiKS5hZGRCYWNrKCkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2NoZWNrOiB0aGlzLm9uR3JvdXBTZWxlY3QsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhdGFTb3VyY2U6IHJlc1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBncnBpZHMgPSBcIlwiO1xyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckdyb3VwcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBncnBpZHMgKz0gdGhpcy5DdXN0b21lckdlbmVyYWxHcm91cElkICsgXCI7XCI7XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGdycGlkcy5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEtlbmRvX3V0aWxpdHkuY2hlY2tpbmdOb2RlSWRzKGpRdWVyeShcIiNncm91cFRyZWUxXCIpLmRhdGEoXCJrZW5kb1RyZWVWaWV3XCIpLmRhdGFTb3VyY2UudmlldygpLCBncnBpZHMuc3Vic3RyaW5nKDAsIGdycGlkcy5sZW5ndGggLSAxKSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvL3ZhciB0cmVldmlld0RhdGFTb3VyY2UgPSBqUXVlcnkoXCIjZ3JvdXBUcmVlXCIpLmRhdGEoXCJrZW5kb1RyZWVWaWV3XCIpLmRhdGFTb3VyY2UudmlldygpO1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAoZXJyKSA9PiB7XHJcblxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAoKSA9PiB7XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgKTtcclxuICAgICAgICBcclxuICAgIH1cclxuICAgIEdldERhdGFGb3JTZWFyY2goZXZlbnQ6IGFueSk6IG9ic2VydmFibGUge1xyXG4gICAgICAgIFxyXG4gICAgICAgIC8vdGhpcy5TZWFyY2hWYWwgPSBqUXVlcnkoXCIjU2VhcmNodHh0XCIpLnZhbCgpO1xyXG4gICAgICAgIC8vYWxlcnQoZXZlbnQua2V5Q29kZSk7XHJcbiAgICAgICAgLy9pZiAodGhpcy5TZWFyY2hWYWwgIT0gdW5kZWZpbmVkICYmIHRoaXMuU2VhcmNoVmFsICE9IFwiXCIgJiYgdGhpcy5TZWFyY2hWYWwgIT0gbnVsbCAmJiBldmVudC5rZXlDb2RlID09IDEzKSB7XHJcbiAgICAgICAgICAgIC8vYWxlcnQodGhpcy5hdXRvY29tcGxldGVTZWxlY3QgKyBcIiBcIiArIHRoaXMuYXV0b2NvbXBsZXRlTm9SZXN1bHRzKTtcclxuICAgICAgICAvLyAgICB0aGlzLkVudGVyQ291bnQrKztcclxuICAgICAgICAvLyAgICBpZiAodGhpcy5FbnRlckNvdW50ID49IDIpIHtcclxuICAgICAgICAvLyAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkdldENvbXBsZXRlU2VhcmNoKHRoaXMuU2VhcmNoVmFsKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAvLyAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgLy8gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgYWxlcnQocmVzcG9uc2UuRXJyTXNnKTtcclxuICAgICAgICAvLyAgICAgICAgICAgIH1cclxuICAgICAgICAvLyAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgIC8vICAgICAgICAgICAgICAgIHRoaXMuQ3VzdExpc3QgPSB7fTtcclxuICAgICAgICAvLyAgICAgICAgICAgICAgICB0aGlzLkN1c3RMaXN0ID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAvLyAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuRGF0YSAhPSBudWxsICYmIHJlc3BvbnNlLkRhdGEgIT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgIHRoaXMuY3VzdFNlYXJjaERhdGEgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICBqUXVlcnkoXCIjQ3VzdE1vZGFsXCIpLm1vZGFsKFwic2hvd1wiKTtcclxuXHJcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyAgICAgICAgICAgIH1cclxuICAgICAgICAvLyAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgLy8gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgLy8gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAvLyAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIC8vICAgICAgICB9KTtcclxuICAgICAgICAvLyAgICAgICAgdGhpcy5FbnRlckNvdW50ID0gMDtcclxuICAgICAgICAvLyAgICB9XHJcbiAgICAgICAgICAgICAgIFxyXG4gICAgICAgIC8vfVxyXG4gICAgICAgIC8vdGhpcy5TZWFyY2hWYWwgPSBcIlwiO1xyXG4gICAgfVxyXG5cclxuICAgIEJpbmRDdXN0VGl0bGVzKCkge1xyXG5cclxuICAgICAgICB0aGlzLl9jdXN0b21lclNlcnZpY2UuR2V0Q3VzdFRpdGxlcygpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHZhciB0aXRsZXR5cGVhaGVhZFNvdXJjZSA9IFtdO1xyXG4gICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2gocmVzcG9uc2UuRGF0YSwgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBuZXd0ZW1wID0ge307XHJcbiAgICAgICAgICAgICAgICAgICAgbmV3dGVtcC5pZCA9IHRoaXMuVmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgbmV3dGVtcC5uYW1lID0gdGhpcy5UZXh0O1xyXG4gICAgICAgICAgICAgICAgICAgIHRpdGxldHlwZWFoZWFkU291cmNlLnB1c2gobmV3dGVtcCk7XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX0N1c3RUaXRsZXMgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgalF1ZXJ5KFwiI1RpdGxlXCIpLnR5cGVhaGVhZCh7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9kYXRhOiB0aGlzLl9DaXRpZXMsXHJcbiAgICAgICAgICAgICAgICAgICAgc291cmNlOiB0aXRsZXR5cGVhaGVhZFNvdXJjZSxcclxuICAgICAgICAgICAgICAgICAgICAvL2Rpc3BsYXk6IFwidGV4dFwiLFxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGFUeXBlOiBcIkpTT05cIixcclxuICAgICAgICAgICAgICAgICAgICAvL2hpbnQ6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgLy9oaWdobGlnaHQ6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgLy9taW5MZW5ndGg6IDEsXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuICAgIEZpbmRJbWFnZUZpbGUoaW5wdXQpIHtcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckltYWdlRmlsZSA9IGlucHV0LnRhcmdldC5maWxlcztcclxuICAgICAgICB2YXIgZGF0YSA9IG5ldyBGb3JtRGF0YSgpO1xyXG4gICAgICAgIHZhciBmaWxlID0gdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySW1hZ2VGaWxlWzBdO1xyXG4gICAgICAgIFxyXG4gICAgICAgIGRhdGEuYXBwZW5kKCdmaWxlJywgZmlsZSk7XHJcbiAgICAgIC8vICB2YXIgdXBsb2FkZGF0YSA9IHt9O1xyXG4gICAgICAgIC8vICB1cGxvYWRkYXRhLkN1c3RvbWVyVXBsb2FkZWRGaWxlID0gZGF0YTtcclxuICAgICAgICBkZWJ1Z2dlcjtcclxuICAgICAgICB2YXIgT3JnSWQgPSBcIlwiO1xyXG4gICAgICAgIHZhciBlbXBpZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiZW1wbG95ZWVpZFwiKTtcclxuICAgICAgICBpZiAoZW1waWQgIT0gbnVsbCAmJiBlbXBpZCAhPSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgT3JnSWQ9bG9jYWxTdG9yYWdlLmdldEl0ZW0oZW1waWQgKyBcIl9PcmdJZFwiKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdmFyIHhociA9IHRoaXMuX2N1c3RvbWVyU2VydmljZS5VcGxvYWRDdXN0b21lckltYWdlKGRhdGEsIE9yZ0lkKTtcclxuXHJcbiAgICAgICAgeGhyLm9ucmVhZHlzdGF0ZWNoYW5nZSA9ICgpID0+IHtcbiAgICAgICAgICAgIGlmICh4aHIucmVhZHlTdGF0ZSA9PT0gNCkge1xuICAgICAgICAgICAgICAgIGlmICh4aHIuc3RhdHVzID09PSAyMDApIHtcbiAgICAgICAgICAgICAgICAgICAgZGVidWdnZXI7XG4gICAgICAgICAgICAgICAgICAgIHZhciByZXNwb25zZSA9IHhoci5yZXNwb25zZVRleHQ7XG4gICAgICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZSAhPSB1bmRlZmluZWQgJiYgcmVzcG9uc2UgIT0gXCJcIiAmJiByZXNwb25zZSAhPSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZywgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL3RoaXMuc2V0Q29va2llKFwiVGVtcEltYWdlTmFtZVwiLCByZXNwb25zZS5EYXRhLCAxMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuQ3VzdEZpbGVJbWFnZSA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuSW1hZ2VGaWxlTmFtZSA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL3RoaXMubW9kZWxJbnB1dC5JbWFnZUZpbGVOYW1lID0gcmVzcG9uc2UuRGF0YTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9O1xyXG5cclxuICAgICAgICBcclxuICAgICAgICAvLyAgICAuKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgIC8vICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgLy8gICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAvLyAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgLy8gICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgIC8vICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgIC8vICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgIC8vICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAvLyAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgLy8gICAgICAgICAgICB9XHJcbiAgICAgICAgLy8gICAgICAgIH0pO1xyXG4gICAgICAgIC8vICAgIH1cclxuICAgICAgICAvLyAgICBlbHNlIHtcclxuICAgICAgICAvLyAgICAgICAgZGVidWdnZXI7XHJcbiAgICAgICAgLy8gICAgICAgIHZhciByZXMgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAvLyAgICAgICAgLy90aGlzLm1vZGVsSW5wdXQuSW1hZ2VGaWxlTmFtZSA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAvLyAgICB9XHJcbiAgICAgICAgLy99LCBlcnJvcj0+IHtcclxuICAgICAgICAvLyAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgLy99LCAoKSA9PiB7XHJcbiAgICAgICAgLy8gICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgLy99KTtcclxuICAgICAgICAvL2lucHV0LnNyY0VsZW1lbnQuZm9ybS5zdWJtaXQoKTtcclxuICAgICAgICAvL3ZhciBpbWFnZXBhdGggPSBqUXVlcnkoXCIjQ3VzdEltYWdlXCIpLnZhbCgpLnNwbGl0KCdcXFxcJyk7XHJcbiAgICAgICAgLy9pZiAoaW1hZ2VwYXRoLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAvLyAgICB0aGlzLkN1c3RGaWxlSW1hZ2UgPSBpbWFnZXBhdGhbMl07XHJcbiAgICAgICAgLy8gICAgdmFyIGluYW1lID0gdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQudG9TdHJpbmcoKSArIFwiLmpwZ1wiO1xyXG4gICAgICAgIC8vICAgIHRoaXMubW9kZWxJbnB1dC5JbWFnZUZpbGVOYW1lID0gaW5hbWU7XHJcbiAgICAgICAgLy99XHJcbiAgICAgICAgLy9hbGVydChqUXVlcnkoXCIjQ3VzdEltYWdlXCIpLnZhbCgpKTtcclxuICAgIH1cclxuICAgIENsZWFySW1hZ2UoKSB7XHJcbiAgICAgICAgalF1ZXJ5KFwiI0N1c3RJbWFnZVwiKS52YWwoJycpO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5JbWFnZUZpbGVOYW1lID0gXCJcIjtcclxuICAgICAgICBcclxuICAgICAgICB0aGlzLkN1c3RGaWxlSW1hZ2UgPSBcIkRlZmF1bHRVc2VyLmpwZ1wiO1xyXG4gICAgICAgIC8vYWxlcnQoalF1ZXJ5KFwiI0N1c3RJbWFnZVwiKS52YWwoKSk7XHJcbiAgICB9XHJcbiAgICBuZ09uSW5pdCgpIHtcclxuICAgICAgICAvL1xyXG4gICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5kZWxldGVDb29raWUoXCJUZW1wSW1hZ2VOYW1lXCIpO1xyXG4gICAgICAgIGpRdWVyeShcIi5sZWFuLW92ZXJsYXlcIikuY3NzKHsgXCJkaXNwbGF5XCI6IFwibm9uZVwiIH0pO1xyXG4gICAgICAgIHRoaXMuQmluZEN1c3RUaXRsZXMoKTtcclxuICAgICAgIC8vIGRlYnVnZ2VyO1xyXG4gICAgICAgIC8vYm9vdGJveC5hbGVydChcIlRoaXMgaXMgdGhlIGRlZmF1bHQgYWxlcnQhXCIpO1xyXG4gICAgICAgIGlmIChsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImxhbmdcIikgPT0gXCJcIikge1xyXG4gICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImxhbmdcIiwgXCJlblwiKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHRoaXMuX3Jlc291cmNlU2VydmljZS5nZXRDb29raWUoXCJsYW5nXCIpID09IFwiXCIpIHtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5zZXRDb29raWUoXCJsYW5nXCIsIFwiZW5cIiwgMTApO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLklzQ2FuY2VsID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5zaG93aGlkZUdyb3VwcygpO1xyXG4gICAgICAgIHRoaXMuSXNGaWxlQXN0eHRTaG93ID0gdHJ1ZTtcclxuICAgICAgICBcclxuICAgICAgICAvL3RoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkID0gLTE7XHJcbiAgICAgICAgXHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkID49IDApIHtcclxuICAgICAgICAgICAgLy90aGlzLklzRmlsZUFzdHh0U2hvdyA9IGZhbHNlO1xyXG4gICAgICAgICAgICB0aGlzLmVkaXRDdXN0RGV0KHRoaXMubW9kZWxJbnB1dCk7XHJcblxyXG4gICAgICAgICAgICB0aGlzLlNBVkVfQlROX1RFWFQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0JUTl9VUERBVEU7XHJcbiAgICAgICAgICAgIC8vdGhpcy5BRERfTkVXX0NVU1RfVEVYVCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfTEJMX1VQREFURV9DVVNUO1xyXG4gICAgICAgICAgICAvL3RoaXMuQ1NTVEVYVCA9IFwibWRpLWNvbnRlbnQtYWRkXCI7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzLmxlbmd0aCA9PSAwKSB7XHJcbiAgICAgICAgICAgICAgICB2YXIgZW1waWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImVtcGxveWVlaWRcIik7XHJcblxyXG4gICAgICAgICAgICAgICAgdmFyIGNjb2RlID0gdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmdldENvb2tpZShlbXBpZCArIFwiY2NvZGVcIik7XHJcbiAgICAgICAgICAgICAgICBpZiAoY2NvZGUubGVuZ3RoID4gMClcclxuICAgICAgICAgICAgICAgICAgICBjY29kZSA9IGNjb2RlLnN1YnN0cmluZygxLCBjY29kZS5sZW5ndGgpO1xyXG4gICAgICAgICAgICAgICAgdmFyIGFkaWQgPSBcIlwiO1xyXG4gICAgICAgICAgICAgICAgdmFyIGNvbXB0ZXh0ID0gXCJIb21lXCI7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkNvbXBhbnkgIT0gXCJcIiAmJiB0aGlzLm1vZGVsSW5wdXQuQ29tcGFueSAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0LkNvbXBhbnkgIT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbXB0ZXh0ID0gXCJXb3JrXCI7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLl9BZGRyZXNzVHlwZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5UZXh0ID09IGNvbXB0ZXh0KSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhZGlkID0gdGhpcy5WYWx1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3NlcyA9IFt7IFN0cmVldDogXCJcIiwgU3RyZWV0MjogXCJcIiwgQ2l0eU5hbWU6IFwiXCIsIFppcDogXCJcIiwgQ291bnRyeUNvZGU6IGNjb2RlLCBTdGF0ZUlkOiBcIlwiLCBBZGRyZXNzVHlwZUlkOiBhZGlkLCBGb3JEZWxpdmVyeTogZmFsc2UsIE1haW5BZGRyZXNzOiBmYWxzZSwgTWFpbk9yZGVyOiBcIk1haW5BZGRyMVwiLCBEZWx2cnlPcmRlcjogXCJEZWx2cnkxXCIgfV07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdGhpcy5DdXN0SWRUZXh0ID0gXCIoIFwiICsgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQgKyBcIiApXCJcclxuICAgICAgICAgICAgdGhpcy5Jc0ZpbGVBc3R4dFNob3cgPSBmYWxzZTtcclxuICAgICAgICAgICAgLy90aGlzLkhpZGVTaG93RmlsZUFzdHh0KCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLkN1c3RGaWxlSW1hZ2UgPSBcIkRlZmF1bHRVc2VyLmpwZ1wiO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLkxhbmcgPSB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZ2V0Q29va2llKFwibGFuZ1wiKTtcclxuICAgICAgICBpZiAodGhpcy5MYW5nLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgdGhpcy5MYW5nID0gdGhpcy5MYW5nLnN1YnN0cmluZygxLCB0aGlzLkxhbmcubGVuZ3RoKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5IaWRlU2hvd0ZpbGVBc3R4dCgpO1xyXG4gICAgICAgLy90aGlzLlJFUyA9IGpRdWVyeS5wYXJzZUpTT04odGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkdldExhbmdSZXModGhpcy5Gb3JtdHlwZSwgdGhpcy5MYW5nKSkuRGF0YTsgLy9qUXVlcnkucGFyc2VKU09OKGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwibGFuZ3Jlc291cmNlXCIpKTtcclxuICAgICAgICBcclxuICAgICAgICBpZiAodGhpcy5MYW5nID09IFwiaGVcIikge1xyXG4gICAgICAgICAgICB0aGlzLktlbmRvUlRMQ1NTID0gXCJrLXJ0bFwiO1xyXG4gICAgICAgICAgICB0aGlzLkNIQU5HRURJUiA9IFwicnRsbW9kYWxcIjtcclxuICAgICAgICAgICAgdGhpcy5DaGFuZ2VEaWFsb2cgPSBcImlucHV0X3JpZ2h0XCI7XHJcbiAgICAgICAgICAgIC8valF1ZXJ5KFwiLmJvb3Rib3gtY2xvc2UtYnV0dG9uXCIpLmNzcyhcImZsb2F0XCIsIFwibGVmdCFpbXBvcnRhbnRcIik7XHJcbiAgICAgICAgICAgIC8valF1ZXJ5KFwiLm1vZGFsLWZvb3RlciBidXR0b246YmVmb3JlXCIpLmNzcyhcImZsb2F0XCIsIFwibGVmdCFpbXBvcnRhbnRcIik7XHJcbiAgICAgICAgICAgIC8valF1ZXJ5KFwiLm1vZGFsLWZvb3RlciBidXR0b246YWZ0ZXJcIikuY3NzKFwiZmxvYXRcIiwgXCJsZWZ0IWltcG9ydGFudFwiKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuQ0hBTkdFRElSID0gXCJsdHJtb2RhbFwiO1xyXG4gICAgICAgICAgICB0aGlzLkNoYW5nZURpYWxvZyA9IFwiaW5wdXRfbGVmdFwiO1xyXG4gICAgICAgIH1cclxuXHJcblxyXG4gICAgICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLkdldExhbmdSZXModGhpcy5Gb3JtdHlwZSwgdGhpcy5MYW5nKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICB0aGlzLlJFUyA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgIHRoaXMuU2hvd01vcmVUZXh0ID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9MTktfTEJMX01PUkU7XHJcbiAgICAgICAgICAgICAgIHRoaXMuR3JvdXBUZXh0ID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9MQkxfU0hPV0dST1VQUztcclxuICAgICAgICAgICAgICAgdGhpcy5TQVZFX0JUTl9URVhUID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9CVE5fU0FWRTtcclxuICAgICAgICAgICAgICAgdGhpcy5BRERfTkVXX0NVU1RfVEVYVCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfTEJMX05FV19DVVNUO1xyXG4gICAgICAgICAgICAgICB0aGlzLkZJTEVBU19CVE5fVEVYVCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfQlROX0ZJTEVBUztcclxuICAgICAgICAgICAgICAgLy9hbGVydCh0aGlzLlJFUyk7XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgfSk7XHJcbiAgICAgICAvL3RoaXMuU2hvd01vcmVUZXh0ID0gXCJNb3JlXCI7XHJcbiAgICAgICBcclxuICAgICAgIC8vLy9DaXRpZXNcclxuICAgICAgIFxyXG5cclxuXHJcblxyXG4gICAgICAgdmFyIENvdW50cnlDb2RlID0gdGhpcy5BZGRyZXNzLkNvdW50cnlDb2RlO1xyXG4gICAgICAgdmFyIFN0YXRlTmFtZSA9IHRoaXMuQWRkcmVzcy5TdGF0ZUlkO1xyXG4gICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkdldENpdGllcyhDb3VudHJ5Q29kZSwgU3RhdGVOYW1lKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgIH1cclxuICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgdmFyIHR5cGVhaGVhZFNvdXJjZSA9IFtdO1xyXG4gICAgICAgICAgICAgICBqUXVlcnkuZWFjaChyZXNwb25zZS5EYXRhLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICB2YXIgbmV3dGVtcCA9IHt9O1xyXG4gICAgICAgICAgICAgICAgICAgbmV3dGVtcC5pZCA9IHRoaXMuVmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICBuZXd0ZW1wLm5hbWUgPSB0aGlzLlRleHQ7XHJcbiAgICAgICAgICAgICAgICAgICB0eXBlYWhlYWRTb3VyY2UucHVzaChuZXd0ZW1wKTtcclxuICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgIHRoaXMuX0NpdGllcyA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgIGpRdWVyeSgnI0NpdHknKS50eXBlYWhlYWQoe1xyXG4gICAgICAgICAgICAgICAgICAgLy9kYXRhOiB0aGlzLl9DaXRpZXMsXHJcbiAgICAgICAgICAgICAgICAgICBzb3VyY2U6IHR5cGVhaGVhZFNvdXJjZSxcclxuICAgICAgICAgICAgICAgICAgIC8vZGlzcGxheTogXCJ0ZXh0XCIsXHJcbiAgICAgICAgICAgICAgICAgICBkYXRhVHlwZTogXCJKU09OXCIsXHJcbiAgICAgICAgICAgICAgICAgICAvL2hpbnQ6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAvL2hpZ2hsaWdodDogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgIC8vbWluTGVuZ3RoOiAxLFxyXG4gICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICB9XHJcbiAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICB9KTtcclxuXHJcbiAgICAgICBcclxuICAgICAgIFxyXG4gICAgICAgICAgXHJcblxyXG5cclxuICAgICAgICB0aGlzLmxhbmd1YWdlQXJyYXkgPSB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuR2V0QXZhaWxhYmxlTGFuZ3VhZ2VzKCk7XHJcbiAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkdldEN1c3RvbWVyVHlwZXMoKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIHZhciByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcCk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZywgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9DdXN0VHlwZXMgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclR5cGUgPT0gXCJcIiB8fCB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJUeXBlID09IHVuZGVmaW5lZCB8fCB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJUeXBlID09IG51bGwpIHtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgQ3VzdHR5cGVJZDtcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLl9DdXN0VHlwZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgQ3VzdHR5cGVJZCA9IHRoaXMuVmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJUeXBlID0gQ3VzdHR5cGVJZDtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgXHJcbiAgICAgICAgLy8vL1NvdXJjZXNcclxuICAgICAgICB0aGlzLl9jdXN0b21lclNlcnZpY2UuR2V0U291cmNlcygpLnN1YnNjcmliZShyZXNwPT4ge1xyXG4gICAgICAgICAgICB2YXIgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3ApO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fU291cmNlcyA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkNhbWVGcm9tQ3VzdG9tZXIgPT0gXCJcIiB8fCB0aGlzLm1vZGVsSW5wdXQuQ2FtZUZyb21DdXN0b21lciA9PSB1bmRlZmluZWQgfHwgdGhpcy5tb2RlbElucHV0LkNhbWVGcm9tQ3VzdG9tZXIgPT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBTb3VyY2U7XHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5fU291cmNlcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBTb3VyY2UgPSB0aGlzLlZhbHVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkNhbWVGcm9tQ3VzdG9tZXIgPSBTb3VyY2U7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIC8vR2V0RW1wbG95ZWVzXHJcbiAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkdldEVtcGxveWVlcygpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX0VtcGxveWVlcyA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LmVtcGxveWVlaWQgPT0gXCJcIiB8fCB0aGlzLm1vZGVsSW5wdXQuZW1wbG95ZWVpZCA9PSB1bmRlZmluZWQgfHwgdGhpcy5tb2RlbElucHV0LmVtcGxveWVlaWQgPT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBlbXBpZDtcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLl9FbXBsb3llZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZW1waWQgPSB0aGlzLlZhbHVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LmVtcGxveWVlaWQgPSBlbXBpZDtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuICAgICAgICAvL0dldFN1ZmZpeGVzXHJcbiAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkdldFN1ZmZpeGVzKCkuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fU3VmZml4ZXMgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIC8vR2V0UGhvbmVUeXBlc1xyXG4gICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRQaG9uZVR5cGVzKCkuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgIC8vIGRlYnVnZ2VyO1xyXG4gICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fUGhvbmVUeXBlcyA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICB2YXIgcGhpZCA9IFwiXCI7XHJcbiAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLl9QaG9uZVR5cGVzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuVGV4dCA9PSBcIkNlbGxQaG9uZVwiKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwaGlkID0gdGhpcy5WYWx1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzWzBdLlBob25lVHlwZUlkID0gcGhpZDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuXHJcblxyXG4gICAgICAgIHZhciBlcHVibGlzaCA9IDA7XHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lcy5sZW5ndGggPT0gMCkge1xyXG4gICAgICAgICAgICB2YXIgcGhpZCA9IFwiXCI7XHJcblxyXG4gICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLl9QaG9uZVR5cGVzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5UZXh0ID09IFwiQ2VsbFBob25lXCIpIHtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgcGhpZCA9IHRoaXMuVmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgZXB1Ymxpc2ggPSAxO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXMgPSBbeyBQaG9uZVR5cGVJZDogcGhpZCwgUHJlZml4OiBcIlwiLCBBcmVhOiBcIlwiLCBQaG9uZTogXCJcIiwgSXNTbXM6IGVwdWJsaXNoLCBDb21tZW50czogXCJcIiwgcGhwdWJsaXNoOiBlcHVibGlzaCwgU01TT3JkZXI6IFwiU01TMVwiLCBQdWJsaXNoT3JkZXI6XCJQdWIxXCIgfV07XHJcbiAgICAgICAgICAgIC8vIGRlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMubGVuZ3RoID09IDApIHtcclxuICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzID0gW3sgRW1haWw6IFwiXCIsIEVtYWlsTmFtZTogdGhpcy5tb2RlbElucHV0LkZpbGVBcywgTmV3c2xldHRlcmU6IGZhbHNlLCBwdWJsaXNoOiBlcHVibGlzaCwgTmV3c09yZGVyOiBcIk5ld3MxXCIsIEVQdWJsaXNoT3JkZXI6XCJFUHViMVwiIH1dXHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvL0dldEFkZHJlc3NUeXBlc1xyXG4gICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRBZGRyZXNzVHlwZXMoKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZywgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9BZGRyZXNzVHlwZXMgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgIHZhciBhZGlkID0gXCJcIjtcclxuICAgICAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMuX0FkZHJlc3NUeXBlcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLlRleHQgPT0gXCJIb21lXCIpIHtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFkaWQgPSB0aGlzLlZhbHVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzWzBdLkFkZHJlc3NUeXBlSWQgPSBhZGlkO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIC8vR3JvdXBzXHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkdldEdyb3VwcygpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX0dyb3VwcyA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgLy8vL0NvdW50cmllc1xyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRDb3VudHJpZXMoKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZywgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9Db3VudHJpZXMgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIC8vLy9TdGF0ZXNcclxuICAgICAgICB2YXIgQ291bnRyeUNvZGU9IHRoaXMuQWRkcmVzcy5Db3VudHJ5Q29kZTtcclxuICAgICAgICB0aGlzLl9jdXN0b21lclNlcnZpY2UuR2V0U3RhdGVzKENvdW50cnlDb2RlKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZywgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9TdGF0ZXMgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIFxyXG4gICAgICAgIFxyXG4gICAgICAgIC8vVHJlZSBHcm91cFxyXG5cclxuICAgICAgICAvL3RoaXMuYmluZEdyb3VwVHJlZSh0aGlzLklzU2hvd0FsbCk7XHJcbiAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkdldEdlbmVyYWxHcm91cHModGhpcy5Jc1Nob3dBbGwpLnN1YnNjcmliZShcclxuICAgICAgICAgICAgKGRhdGEpID0+IHtcclxuICAgICAgICAgICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5Jc1Nob3dBbGwgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkoXCIjZ3JvdXBUcmVlXCIpLmh0bWwoXCJMb2RpbmcuLi5cIik7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIHJlcyA9IGpRdWVyeS5wYXJzZUpTT04oZGF0YSkuRGF0YVxyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeShcIiNncm91cFRyZWVcIikua2VuZG9UcmVlVmlldyh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRPbkRlbWFuZDogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tib3hlczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tDaGlsZHJlbjogdHJ1ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2NoZWNrOiB0aGlzLm9uR3JvdXBTZWxlY3QsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhdGFTb3VyY2U6IHJlc1xyXG5cclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgZ3JwaWRzID0gXCJcIjtcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJHcm91cHMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZ3JwaWRzICs9IHRoaXMuQ3VzdG9tZXJHZW5lcmFsR3JvdXBJZCArIFwiO1wiO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChncnBpZHMubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBLZW5kb191dGlsaXR5LmNoZWNraW5nTm9kZUlkcyhqUXVlcnkoXCIjZ3JvdXBUcmVlXCIpLmRhdGEoXCJrZW5kb1RyZWVWaWV3XCIpLmRhdGFTb3VyY2UudmlldygpLCBncnBpZHMuc3Vic3RyaW5nKDAsIGdycGlkcy5sZW5ndGggLSAxKSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkoXCIjZ3JvdXBUcmVlMVwiKS5odG1sKFwiTG9kaW5nLi4uXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciByZXMgPSBqUXVlcnkucGFyc2VKU09OKGRhdGEpLkRhdGFcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkoXCIjZ3JvdXBUcmVlMVwiKS5rZW5kb1RyZWVWaWV3KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbG9hZE9uRGVtYW5kOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjaGVja2JveGVzOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja0NoaWxkcmVuOiB0cnVlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vY2hlY2s6IHRoaXMub25Hcm91cFNlbGVjdCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGF0YVNvdXJjZTogcmVzXHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIGdycGlkcyA9IFwiXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5tb2RlbElucHV0LkN1c3RvbWVyR3JvdXBzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGdycGlkcyArPSB0aGlzLkN1c3RvbWVyR2VuZXJhbEdyb3VwSWQgKyBcIjtcIjtcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoZ3JwaWRzLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgS2VuZG9fdXRpbGl0eS5jaGVja2luZ05vZGVJZHMoalF1ZXJ5KFwiI2dyb3VwVHJlZTFcIikuZGF0YShcImtlbmRvVHJlZVZpZXdcIikuZGF0YVNvdXJjZS52aWV3KCksIGdycGlkcy5zdWJzdHJpbmcoMCwgZ3JwaWRzLmxlbmd0aCAtIDEpKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgKGVycikgPT4ge1xyXG5cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgKCkgPT4ge1xyXG5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICk7XHJcbiAgICAgICAgXHJcblxyXG5cclxuICAgICAgICAvL2FsZXJ0KG1vbWVudCgpLmZvcm1hdCgnRCBNTU0gWVlZWScpKTsgICAgICAgXHJcbiAgICAgICAvLyB0aGlzLmJhc2VVcmwgKyBcIkRyb3Bkb3duL0JpbmRBdXRvQ29tcGxldGVTcmNoXCJcclxuICAgICAgICB2YXIgU3JjaERhdGEgPSBudWxsO1xyXG4gICAgICAgICAgIFxyXG4gICAgICAgIC8vYWxlcnQoJ0hpJyk7XHJcbiAgICAgICAgalF1ZXJ5KFwiI0VtYWlsVGFibGUgdGJvZHkgdHIgdGQgYVtuYW1lPWRlbEVidG5dXCIpLm5vdChcIjpsYXN0XCIpLmhpZGUoKTtcclxuICAgICAgICBqUXVlcnkoXCIjRW1haWxUYWJsZSB0Ym9keSB0ciBhW25hbWU9YWRkRWJ0bl1cIikubm90KFwiOmxhc3RcIikuc2hvdygpO1xyXG4gICAgICAgIC8vJCgnLm1vZGFsJykubW9kYWwoKTtcclxuICAgICAgICBcclxuICAgIH1cclxufVxyXG4iXX0=
