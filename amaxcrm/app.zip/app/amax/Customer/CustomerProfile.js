System.register(['angular2/common', "../../services/ResourceService", "angular2/router", "angular2/core", "../../services/CustomerService", "../../services/RecieptService", '../../comonComponents/basicComponents'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var common_1, ResourceService_1, router_1, core_1, CustomerService_1, RecieptService_1, basicComponents_1;
    var AmaxCustomerProfiles;
    return {
        setters:[
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (ResourceService_1_1) {
                ResourceService_1 = ResourceService_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (CustomerService_1_1) {
                CustomerService_1 = CustomerService_1_1;
            },
            function (RecieptService_1_1) {
                RecieptService_1 = RecieptService_1_1;
            },
            function (basicComponents_1_1) {
                basicComponents_1 = basicComponents_1_1;
            }],
        execute: function() {
            AmaxCustomerProfiles = (function () {
                function AmaxCustomerProfiles(_resourceService, _customerService, _routeParams, _RecieptService) {
                    this._resourceService = _resourceService;
                    this._customerService = _customerService;
                    this._routeParams = _routeParams;
                    this._RecieptService = _RecieptService;
                    this.modelInput = {};
                    this.RES = {};
                    this.BaseUrl = "";
                    this.ImageUrl = "";
                    this.Receipts = [];
                    this.Formtype = "CUSTOMER_PROFILE";
                    this.Lang = "";
                    this.ChangeDialog = "";
                    this.CHANGEDIR = "";
                    this.CustFileName = "";
                    this.IsEmailRowsShow = false;
                    this.IsPhonesRowsShow = false;
                    this.IsAddressRowsShow = false;
                    this.IsGroupRowsShow = false;
                    this.modelInput = {};
                    this.RES.CUSTOMER_PROFILE = {};
                    this.modelInput.CustomerAddresses = [];
                    this.modelInput.CustomerPhones = [];
                    this.modelInput.CustomerEmails = [];
                    this.modelInput.CustomerGroups = [];
                    this.modelInput.Receipts = [];
                    this.modelInput.CustomerId = _routeParams.params.Id;
                    this.BaseUrl = _resourceService.AppUrl;
                    this.ImageUrl = _resourceService.ImageUrl;
                    this.CustFileName = "DefaultUser.jpg";
                }
                AmaxCustomerProfiles.prototype.SetdefaultPage = function () {
                    this.modelInput = {};
                };
                AmaxCustomerProfiles.prototype.ShowHideEmailRows = function () {
                    if (this.IsEmailRowsShow == false) {
                        var count = 0;
                        jQuery.each(this.modelInput.CustomerEmails, function () {
                            if (count == 0) {
                                this.CSSStlye = "display:block";
                            }
                            else {
                                this.CSSStlye = "display:none";
                            }
                            count++;
                        });
                        this.IsEmailRowsShow = true;
                    }
                    else {
                        jQuery.each(this.modelInput.CustomerEmails, function () {
                            this.CSSStlye = "display:block";
                        });
                        this.IsEmailRowsShow = false;
                    }
                };
                AmaxCustomerProfiles.prototype.ShowHidePhonesRows = function () {
                    if (this.IsPhonesRowsShow == false) {
                        var count = 0;
                        jQuery.each(this.modelInput.CustomerPhones, function () {
                            if (count == 0) {
                                this.CSSStlye = "display:block";
                            }
                            else {
                                this.CSSStlye = "display:none";
                            }
                            count++;
                        });
                        this.IsPhonesRowsShow = true;
                    }
                    else {
                        jQuery.each(this.modelInput.CustomerPhones, function () {
                            this.CSSStlye = "display:block";
                        });
                        this.IsPhonesRowsShow = false;
                    }
                };
                AmaxCustomerProfiles.prototype.ShowHideaddressesRows = function () {
                    if (this.IsAddressRowsShow == false) {
                        var count = 0;
                        jQuery.each(this.modelInput.CustomerAddresses, function () {
                            if (count == 0) {
                                this.CSSStlye = "display:block";
                            }
                            else {
                                this.CSSStlye = "display:none";
                            }
                            count++;
                        });
                        this.IsAddressRowsShow = true;
                    }
                    else {
                        jQuery.each(this.modelInput.CustomerAddresses, function () {
                            this.CSSStlye = "display:block";
                        });
                        this.IsAddressRowsShow = false;
                    }
                };
                AmaxCustomerProfiles.prototype.ShowHideGroupsRows = function () {
                    if (this.IsGroupRowsShow == false) {
                        var count = 0;
                        jQuery.each(this.modelInput.CustomerGroups, function () {
                            if (count == 0) {
                                this.CSSStlye = "display:block";
                            }
                            else {
                                this.CSSStlye = "display:none";
                            }
                            count++;
                        });
                        this.IsGroupRowsShow = true;
                    }
                    else {
                        jQuery.each(this.modelInput.CustomerGroups, function () {
                            this.CSSStlye = "display:block";
                        });
                        this.IsGroupRowsShow = false;
                    }
                };
                AmaxCustomerProfiles.prototype.CustomerDetail = function (CustomerId) {
                    var _this = this;
                    // debugger;
                    this._customerService.GetCompleteCustDet(CustomerId).subscribe(function (response) {
                        //debugger;
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.modelInput = response.Data;
                            _this.modelInput.Receipts = [];
                            if (_this.modelInput.ImageFileName != null && _this.modelInput.ImageFileName != "") {
                                var OrgId = "";
                                var empid = localStorage.getItem("employeeid");
                                if (empid != null && empid != undefined) {
                                    OrgId = localStorage.getItem(empid + "_OrgId");
                                }
                                _this.CustFileName = OrgId + "//" + _this.modelInput.ImageFileName;
                            }
                            debugger;
                            _this.IsEmailRowsShow = false;
                            _this.ShowHideEmailRows();
                            _this.IsPhonesRowsShow = false;
                            _this.ShowHidePhonesRows();
                            _this.IsAddressRowsShow = false;
                            _this.ShowHideaddressesRows();
                            _this.IsGroupRowsShow = false;
                            _this.ShowHideGroupsRows();
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxCustomerProfiles.prototype.ngOnInit = function () {
                    var _this = this;
                    this.CustFileName = "DefaultUser.jpg";
                    jQuery(".lean-overlay").css({ "display": "none" });
                    this.modelInput.CustomerId = this._routeParams.params.Id;
                    if (localStorage.getItem("lang") == "") {
                        localStorage.setItem("lang", "en");
                    }
                    if (this._resourceService.getCookie("lang") == "") {
                        this._resourceService.setCookie("lang", "en", 10);
                    }
                    this.Lang = this._resourceService.getCookie("lang");
                    if (this.Lang.length > 0) {
                        this.Lang = this.Lang.substring(1, this.Lang.length);
                    }
                    if (this.Lang == "he") {
                        this.CHANGEDIR = "rtlmodal";
                        this.ChangeDialog = "input_right";
                    }
                    else {
                        this.CHANGEDIR = "ltrmodal";
                        this.ChangeDialog = "input_left";
                    }
                    // debugger;
                    this._resourceService.GetLangRes(this.Formtype, this.Lang).subscribe(function (response) {
                        //debugger;
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.RES = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    if (this.modelInput.CustomerId != undefined && this.modelInput.CustomerId != null && this.modelInput.CustomerId != "") {
                        this.CustomerDetail(this.modelInput.CustomerId);
                        this._RecieptService.GetReceiptByCustomerId(this.modelInput.CustomerId).subscribe(function (response) {
                            // debugger;
                            response = jQuery.parseJSON(response);
                            if (response.IsError == true) {
                                bootbox.alert({
                                    message: response.ErrMsg, className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                            else {
                                _this.Receipts = response.Data;
                            }
                        }, function (error) {
                            console.log(error);
                        }, function () {
                            console.log("CallCompleted");
                        });
                    }
                    else {
                        bootbox.alert({
                            message: "Customer not found", className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                    }
                };
                AmaxCustomerProfiles = __decorate([
                    core_1.Component({
                        templateUrl: './app/amax/Customer/templates/CustomerProfile.html',
                        directives: [common_1.NgSwitch, common_1.NgSwitchWhen, common_1.NgSwitchDefault, common_1.CORE_DIRECTIVES, common_1.FORM_DIRECTIVES, basicComponents_1.AmaxDate],
                        providers: [CustomerService_1.CustomerService, ResourceService_1.ResourceService, RecieptService_1.RecieptService]
                    }), 
                    __metadata('design:paramtypes', [ResourceService_1.ResourceService, CustomerService_1.CustomerService, router_1.RouteParams, RecieptService_1.RecieptService])
                ], AmaxCustomerProfiles);
                return AmaxCustomerProfiles;
            }());
            exports_1("AmaxCustomerProfiles", AmaxCustomerProfiles);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFtYXgvQ3VzdG9tZXIvQ3VzdG9tZXJQcm9maWxlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1lBdUJBO2dCQWVJLDhCQUFvQixnQkFBaUMsRUFBVSxnQkFBaUMsRUFBVSxZQUF5QixFQUFVLGVBQStCO29CQUF4SixxQkFBZ0IsR0FBaEIsZ0JBQWdCLENBQWlCO29CQUFVLHFCQUFnQixHQUFoQixnQkFBZ0IsQ0FBaUI7b0JBQVUsaUJBQVksR0FBWixZQUFZLENBQWE7b0JBQVUsb0JBQWUsR0FBZixlQUFlLENBQWdCO29CQWQ1SyxlQUFVLEdBQUcsRUFBRSxDQUFDO29CQUNoQixRQUFHLEdBQVcsRUFBRSxDQUFDO29CQUNqQixZQUFPLEdBQVcsRUFBRSxDQUFDO29CQUNyQixhQUFRLEdBQVcsRUFBRSxDQUFDO29CQUN0QixhQUFRLEdBQUcsRUFBRSxDQUFDO29CQUNkLGFBQVEsR0FBVSxrQkFBa0IsQ0FBQztvQkFDckMsU0FBSSxHQUFTLEVBQUUsQ0FBQztvQkFDaEIsaUJBQVksR0FBVyxFQUFFLENBQUM7b0JBQzFCLGNBQVMsR0FBVyxFQUFFLENBQUM7b0JBQ3ZCLGlCQUFZLEdBQVcsRUFBRSxDQUFDO29CQUMxQixvQkFBZSxHQUFTLEtBQUssQ0FBQztvQkFDOUIscUJBQWdCLEdBQVcsS0FBSyxDQUFDO29CQUNqQyxzQkFBaUIsR0FBWSxLQUFLLENBQUM7b0JBQ25DLG9CQUFlLEdBQVksS0FBSyxDQUFDO29CQUc3QixJQUFJLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztvQkFDckIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsR0FBRyxFQUFFLENBQUM7b0JBQy9CLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLEdBQUcsRUFBRSxDQUFDO29CQUN2QyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxFQUFFLENBQUM7b0JBQ3BDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLEVBQUUsQ0FBQztvQkFDcEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDO29CQUNwQyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUM7b0JBQzlCLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLFlBQVksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO29CQUNwRCxJQUFJLENBQUMsT0FBTyxHQUFHLGdCQUFnQixDQUFDLE1BQU0sQ0FBQztvQkFDdkMsSUFBSSxDQUFDLFFBQVEsR0FBRyxnQkFBZ0IsQ0FBQyxRQUFRLENBQUM7b0JBQzFDLElBQUksQ0FBQyxZQUFZLEdBQUcsaUJBQWlCLENBQUM7Z0JBQzFDLENBQUM7Z0JBRUQsNkNBQWMsR0FBZDtvQkFHSSxJQUFJLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztnQkFHekIsQ0FBQztnQkFDRCxnREFBaUIsR0FBakI7b0JBQ0ksRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDO3dCQUNoQyxJQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7d0JBQ2QsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRTs0QkFDeEMsRUFBRSxDQUFDLENBQUMsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBRWIsSUFBSSxDQUFDLFFBQVEsR0FBRyxlQUFlLENBQUM7NEJBRXBDLENBQUM7NEJBQ0QsSUFBSSxDQUFDLENBQUM7Z0NBQ0YsSUFBSSxDQUFDLFFBQVEsR0FBRyxjQUFjLENBQUM7NEJBQ25DLENBQUM7NEJBQ0QsS0FBSyxFQUFFLENBQUM7d0JBQ1osQ0FBQyxDQUFDLENBQUM7d0JBQ0gsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUM7b0JBQ2hDLENBQUM7b0JBQ0QsSUFBSSxDQUFDLENBQUM7d0JBQ0YsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRTs0QkFDcEMsSUFBSSxDQUFDLFFBQVEsR0FBRyxlQUFlLENBQUM7d0JBQ3hDLENBQUMsQ0FBQyxDQUFDO3dCQUNILElBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSyxDQUFDO29CQUNqQyxDQUFDO2dCQUNMLENBQUM7Z0JBQ0QsaURBQWtCLEdBQWxCO29CQUNJLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDO3dCQUNqQyxJQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7d0JBQ2QsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRTs0QkFDeEMsRUFBRSxDQUFDLENBQUMsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBRWIsSUFBSSxDQUFDLFFBQVEsR0FBRyxlQUFlLENBQUM7NEJBRXBDLENBQUM7NEJBQ0QsSUFBSSxDQUFDLENBQUM7Z0NBQ0YsSUFBSSxDQUFDLFFBQVEsR0FBRyxjQUFjLENBQUM7NEJBQ25DLENBQUM7NEJBQ0QsS0FBSyxFQUFFLENBQUM7d0JBQ1osQ0FBQyxDQUFDLENBQUM7d0JBQ0gsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQztvQkFDakMsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxFQUFFOzRCQUN4QyxJQUFJLENBQUMsUUFBUSxHQUFHLGVBQWUsQ0FBQzt3QkFDcEMsQ0FBQyxDQUFDLENBQUM7d0JBQ0gsSUFBSSxDQUFDLGdCQUFnQixHQUFHLEtBQUssQ0FBQztvQkFDbEMsQ0FBQztnQkFDTCxDQUFDO2dCQUNELG9EQUFxQixHQUFyQjtvQkFDSSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQzt3QkFDbEMsSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO3dCQUNkLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsRUFBRTs0QkFDM0MsRUFBRSxDQUFDLENBQUMsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBRWIsSUFBSSxDQUFDLFFBQVEsR0FBRyxlQUFlLENBQUM7NEJBRXBDLENBQUM7NEJBQ0QsSUFBSSxDQUFDLENBQUM7Z0NBQ0YsSUFBSSxDQUFDLFFBQVEsR0FBRyxjQUFjLENBQUM7NEJBQ25DLENBQUM7NEJBQ0QsS0FBSyxFQUFFLENBQUM7d0JBQ1osQ0FBQyxDQUFDLENBQUM7d0JBQ0gsSUFBSSxDQUFDLGlCQUFpQixHQUFHLElBQUksQ0FBQztvQkFDbEMsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLEVBQUU7NEJBQzNDLElBQUksQ0FBQyxRQUFRLEdBQUcsZUFBZSxDQUFDO3dCQUNwQyxDQUFDLENBQUMsQ0FBQzt3QkFDSCxJQUFJLENBQUMsaUJBQWlCLEdBQUcsS0FBSyxDQUFDO29CQUNuQyxDQUFDO2dCQUNMLENBQUM7Z0JBQ0QsaURBQWtCLEdBQWxCO29CQUNJLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQzt3QkFDaEMsSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO3dCQUNkLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUU7NEJBQ3hDLEVBQUUsQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUViLElBQUksQ0FBQyxRQUFRLEdBQUcsZUFBZSxDQUFDOzRCQUVwQyxDQUFDOzRCQUNELElBQUksQ0FBQyxDQUFDO2dDQUNGLElBQUksQ0FBQyxRQUFRLEdBQUcsY0FBYyxDQUFDOzRCQUNuQyxDQUFDOzRCQUNELEtBQUssRUFBRSxDQUFDO3dCQUNaLENBQUMsQ0FBQyxDQUFDO3dCQUNILElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDO29CQUNoQyxDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUNGLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUU7NEJBQ3hDLElBQUksQ0FBQyxRQUFRLEdBQUcsZUFBZSxDQUFDO3dCQUNwQyxDQUFDLENBQUMsQ0FBQzt3QkFDSCxJQUFJLENBQUMsZUFBZSxHQUFHLEtBQUssQ0FBQztvQkFDakMsQ0FBQztnQkFDTCxDQUFDO2dCQUNELDZDQUFjLEdBQWQsVUFBZSxVQUFVO29CQUF6QixpQkE2Q0M7b0JBNUNFLFlBQVk7b0JBQ1gsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGtCQUFrQixDQUFDLFVBQVUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7d0JBQ2xFLFdBQVc7d0JBQ1osUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQ3RELE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEtBQUksQ0FBQyxVQUFVLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzs0QkFDaEMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDOzRCQUM5QixFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsSUFBSSxJQUFJLElBQUksS0FBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQztnQ0FDL0UsSUFBSSxLQUFLLEdBQUcsRUFBRSxDQUFDO2dDQUNmLElBQUksS0FBSyxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUM7Z0NBQy9DLEVBQUUsQ0FBQyxDQUFDLEtBQUssSUFBSSxJQUFJLElBQUksS0FBSyxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUM7b0NBQ3RDLEtBQUssR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUMsQ0FBQztnQ0FDbkQsQ0FBQztnQ0FDRCxLQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssR0FBQyxJQUFJLEdBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUM7NEJBQ2pFLENBQUM7NEJBQ0QsUUFBUSxDQUFDOzRCQUVULEtBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSyxDQUFDOzRCQUM3QixLQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQzs0QkFDekIsS0FBSSxDQUFDLGdCQUFnQixHQUFHLEtBQUssQ0FBQzs0QkFDOUIsS0FBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7NEJBQzFCLEtBQUksQ0FBQyxpQkFBaUIsR0FBRyxLQUFLLENBQUM7NEJBQy9CLEtBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDOzRCQUM3QixLQUFJLENBQUMsZUFBZSxHQUFHLEtBQUssQ0FBQzs0QkFDN0IsS0FBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7d0JBRzlCLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7Z0JBQ1AsQ0FBQztnQkFFRCx1Q0FBUSxHQUFSO29CQUFBLGlCQStGQztvQkE1RkcsSUFBSSxDQUFDLFlBQVksR0FBRyxpQkFBaUIsQ0FBQztvQkFDdEMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLFNBQVMsRUFBRSxNQUFNLEVBQUUsQ0FBQyxDQUFDO29CQUNuRCxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7b0JBQ3pELEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzt3QkFDckMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUM7b0JBQ3ZDLENBQUM7b0JBQ0QsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO3dCQUVoRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsRUFBRSxDQUFDLENBQUM7b0JBRXRELENBQUM7b0JBRUQsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUNwRCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUN2QixJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUN6RCxDQUFDO29CQUlELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzt3QkFFcEIsSUFBSSxDQUFDLFNBQVMsR0FBRyxVQUFVLENBQUM7d0JBQzVCLElBQUksQ0FBQyxZQUFZLEdBQUcsYUFBYSxDQUFDO29CQUN0QyxDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUNGLElBQUksQ0FBQyxTQUFTLEdBQUcsVUFBVSxDQUFDO3dCQUM1QixJQUFJLENBQUMsWUFBWSxHQUFHLFlBQVksQ0FBQztvQkFDckMsQ0FBQztvQkFFRixZQUFZO29CQUNaLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFDekUsV0FBVzt3QkFDWCxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDdEQsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLEdBQUcsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO3dCQUM3QixDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUNILEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzt3QkFDcEgsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxDQUFDO3dCQUdoRCxJQUFJLENBQUMsZUFBZSxDQUFDLHNCQUFzQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTs0QkFDdEYsWUFBWTs0QkFDWixRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzs0QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO2dDQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO29DQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtvQ0FDdEQsT0FBTyxFQUFFO3dDQUNMLEVBQUUsRUFBRTs0Q0FDQSxjQUFjOzRDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUzt5Q0FDNUI7cUNBQ0o7aUNBQ0osQ0FBQyxDQUFDOzRCQUNQLENBQUM7NEJBQ0QsSUFBSSxDQUFDLENBQUM7Z0NBQ0YsS0FBSSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDOzRCQUdsQyxDQUFDO3dCQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7NEJBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQzt3QkFDdkIsQ0FBQyxFQUFFOzRCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7d0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUNQLENBQUM7b0JBQ0QsSUFBSSxDQUFDLENBQUM7d0JBQ0YsT0FBTyxDQUFDLEtBQUssQ0FBQzs0QkFDVixPQUFPLEVBQUUsb0JBQW9CLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxZQUFZOzRCQUMzRCxPQUFPLEVBQUU7Z0NBQ0wsRUFBRSxFQUFFO29DQUNBLGNBQWM7b0NBQ2QsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO2lDQUM1Qjs2QkFDSjt5QkFDSixDQUFDLENBQUM7b0JBQ1AsQ0FBQztnQkFDSixDQUFDO2dCQXRSTDtvQkFBQyxnQkFBUyxDQUFDO3dCQUVQLFdBQVcsRUFBRSxvREFBb0Q7d0JBQ2pFLFVBQVUsRUFBRSxDQUFDLGlCQUFRLEVBQUUscUJBQVksRUFBRSx3QkFBZSxFQUFFLHdCQUFlLEVBQUUsd0JBQWUsRUFBRSwwQkFBUSxDQUFDO3dCQUNqRyxTQUFTLEVBQUUsQ0FBQyxpQ0FBZSxFQUFFLGlDQUFlLEVBQUUsK0JBQWMsQ0FBQztxQkFDaEUsQ0FBQzs7d0NBQUE7Z0JBa1JGLDJCQUFDO1lBQUQsQ0FoUkEsQUFnUkMsSUFBQTtZQWhSRCx1REFnUkMsQ0FBQSIsImZpbGUiOiJhbWF4L0N1c3RvbWVyL0N1c3RvbWVyUHJvZmlsZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7TmdTd2l0Y2gsIE5nU3dpdGNoV2hlbiwgTmdTd2l0Y2hEZWZhdWx0LCBDT1JFX0RJUkVDVElWRVMsIEZPUk1fRElSRUNUSVZFU30gZnJvbSAnYW5ndWxhcjIvY29tbW9uJ1xyXG5pbXBvcnQge1Jlc291cmNlU2VydmljZX0gZnJvbSBcIi4uLy4uL3NlcnZpY2VzL1Jlc291cmNlU2VydmljZVwiO1xyXG5pbXBvcnQge1JvdXRlUGFyYW1zfSBmcm9tIFwiYW5ndWxhcjIvcm91dGVyXCI7XHJcbmltcG9ydCB7Q29tcG9uZW50LCBPdXRwdXQsIElucHV0LCBFdmVudEVtaXR0ZXIsIE9uSW5pdH0gZnJvbSBcImFuZ3VsYXIyL2NvcmVcIjtcclxuaW1wb3J0IHtDdXN0b21lclNlcnZpY2V9IGZyb20gXCIuLi8uLi9zZXJ2aWNlcy9DdXN0b21lclNlcnZpY2VcIjtcclxuaW1wb3J0IHtSZWNpZXB0U2VydmljZX0gZnJvbSBcIi4uLy4uL3NlcnZpY2VzL1JlY2llcHRTZXJ2aWNlXCI7XHJcbmltcG9ydCB7IGpzb25RIH0gZnJvbSAnLi4vLi4vanNvblEnO1xyXG5pbXBvcnQge0dyb3VwRmlsdGVyUGlwZSwgR3JvdXBQYXJlbkZpbHRlclBpcGUsIEtlbmRvX3V0aWxpdHl9IGZyb20gXCIuLi8uLi9hbWF4VXRpbFwiO1xyXG5cclxuaW1wb3J0IHsgQW1heERhdGUgfSBmcm9tICcuLi8uLi9jb21vbkNvbXBvbmVudHMvYmFzaWNDb21wb25lbnRzJztcclxuXHJcblxyXG5kZWNsYXJlIHZhciBqUXVlcnk7XHJcbmRlY2xhcmUgdmFyIHN3YWw7XHJcbmRlY2xhcmUgdmFyIG1vbWVudDtcclxuXHJcbkBDb21wb25lbnQoe1xyXG5cclxuICAgIHRlbXBsYXRlVXJsOiAnLi9hcHAvYW1heC9DdXN0b21lci90ZW1wbGF0ZXMvQ3VzdG9tZXJQcm9maWxlLmh0bWwnLFxyXG4gICAgZGlyZWN0aXZlczogW05nU3dpdGNoLCBOZ1N3aXRjaFdoZW4sIE5nU3dpdGNoRGVmYXVsdCwgQ09SRV9ESVJFQ1RJVkVTLCBGT1JNX0RJUkVDVElWRVMsIEFtYXhEYXRlXSxcclxuICAgIHByb3ZpZGVyczogW0N1c3RvbWVyU2VydmljZSwgUmVzb3VyY2VTZXJ2aWNlLCBSZWNpZXB0U2VydmljZV1cclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBBbWF4Q3VzdG9tZXJQcm9maWxlcyBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcbiAgICBtb2RlbElucHV0ID0ge307XHJcbiAgICBSRVM6IE9iamVjdCA9IHt9O1xyXG4gICAgQmFzZVVybDogc3RyaW5nID0gXCJcIjtcclxuICAgIEltYWdlVXJsOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgUmVjZWlwdHMgPSBbXTtcclxuICAgIEZvcm10eXBlOiBzdHJpbmcgPVwiQ1VTVE9NRVJfUFJPRklMRVwiO1xyXG4gICAgTGFuZzogc3RyaW5nPVwiXCI7XHJcbiAgICBDaGFuZ2VEaWFsb2c6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBDSEFOR0VESVI6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBDdXN0RmlsZU5hbWU6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBJc0VtYWlsUm93c1Nob3c6Ym9vbGVhbj1mYWxzZTtcclxuICAgIElzUGhvbmVzUm93c1Nob3c6IGJvb2xlYW4gPWZhbHNlO1xyXG4gICAgSXNBZGRyZXNzUm93c1Nob3c6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIElzR3JvdXBSb3dzU2hvdzogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBfcmVzb3VyY2VTZXJ2aWNlOiBSZXNvdXJjZVNlcnZpY2UsIHByaXZhdGUgX2N1c3RvbWVyU2VydmljZTogQ3VzdG9tZXJTZXJ2aWNlLCBwcml2YXRlIF9yb3V0ZVBhcmFtczogUm91dGVQYXJhbXMsIHByaXZhdGUgX1JlY2llcHRTZXJ2aWNlOiBSZWNpZXB0U2VydmljZSkge1xyXG4gICAgXHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0ID0ge307XHJcbiAgICAgICAgdGhpcy5SRVMuQ1VTVE9NRVJfUFJPRklMRSA9IHt9O1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3NlcyA9IFtdO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lcyA9IFtdO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlscyA9IFtdO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckdyb3VwcyA9IFtdO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0cyA9IFtdO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkID0gX3JvdXRlUGFyYW1zLnBhcmFtcy5JZDtcclxuICAgICAgICB0aGlzLkJhc2VVcmwgPSBfcmVzb3VyY2VTZXJ2aWNlLkFwcFVybDtcclxuICAgICAgICB0aGlzLkltYWdlVXJsID0gX3Jlc291cmNlU2VydmljZS5JbWFnZVVybDsgICBcclxuICAgICAgICB0aGlzLkN1c3RGaWxlTmFtZSA9IFwiRGVmYXVsdFVzZXIuanBnXCI7ICAgXHJcbiAgICB9XHJcbiAgICBcclxuICAgIFNldGRlZmF1bHRQYWdlKCl7XHJcbiAgICAgICAgXHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0ID0ge307XHJcbiAgICAgICAgXHJcbiAgICAgICAgXHJcbiAgICB9XHJcbiAgICBTaG93SGlkZUVtYWlsUm93cygpIHtcclxuICAgICAgICBpZiAodGhpcy5Jc0VtYWlsUm93c1Nob3cgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgdmFyIGNvdW50ID0gMDtcclxuICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoY291bnQgPT0gMCkge1xyXG5cclxuICAgICAgICAgICAgICAgICAgICB0aGlzLkNTU1N0bHllID0gXCJkaXNwbGF5OmJsb2NrXCI7XHJcblxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5DU1NTdGx5ZSA9IFwiZGlzcGxheTpub25lXCI7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBjb3VudCsrO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgdGhpcy5Jc0VtYWlsUm93c1Nob3cgPSB0cnVlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5DU1NTdGx5ZSA9IFwiZGlzcGxheTpibG9ja1wiOyAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIHRoaXMuSXNFbWFpbFJvd3NTaG93ID0gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgU2hvd0hpZGVQaG9uZXNSb3dzKCkge1xyXG4gICAgICAgIGlmICh0aGlzLklzUGhvbmVzUm93c1Nob3cgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgdmFyIGNvdW50ID0gMDtcclxuICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoY291bnQgPT0gMCkge1xyXG5cclxuICAgICAgICAgICAgICAgICAgICB0aGlzLkNTU1N0bHllID0gXCJkaXNwbGF5OmJsb2NrXCI7XHJcblxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5DU1NTdGx5ZSA9IFwiZGlzcGxheTpub25lXCI7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBjb3VudCsrO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgdGhpcy5Jc1Bob25lc1Jvd3NTaG93ID0gdHJ1ZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5DU1NTdGx5ZSA9IFwiZGlzcGxheTpibG9ja1wiO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgdGhpcy5Jc1Bob25lc1Jvd3NTaG93ID0gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgU2hvd0hpZGVhZGRyZXNzZXNSb3dzKCkge1xyXG4gICAgICAgIGlmICh0aGlzLklzQWRkcmVzc1Jvd3NTaG93ID09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgIHZhciBjb3VudCA9IDA7XHJcbiAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3NlcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKGNvdW50ID09IDApIHtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5DU1NTdGx5ZSA9IFwiZGlzcGxheTpibG9ja1wiO1xyXG5cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuQ1NTU3RseWUgPSBcImRpc3BsYXk6bm9uZVwiO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgY291bnQrKztcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIHRoaXMuSXNBZGRyZXNzUm93c1Nob3cgPSB0cnVlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLkNTU1N0bHllID0gXCJkaXNwbGF5OmJsb2NrXCI7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB0aGlzLklzQWRkcmVzc1Jvd3NTaG93ID0gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgU2hvd0hpZGVHcm91cHNSb3dzKCkge1xyXG4gICAgICAgIGlmICh0aGlzLklzR3JvdXBSb3dzU2hvdyA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICB2YXIgY291bnQgPSAwO1xyXG4gICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJHcm91cHMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgIGlmIChjb3VudCA9PSAwKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuQ1NTU3RseWUgPSBcImRpc3BsYXk6YmxvY2tcIjtcclxuXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLkNTU1N0bHllID0gXCJkaXNwbGF5Om5vbmVcIjtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGNvdW50Kys7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB0aGlzLklzR3JvdXBSb3dzU2hvdyA9IHRydWU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJHcm91cHMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuQ1NTU3RseWUgPSBcImRpc3BsYXk6YmxvY2tcIjtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIHRoaXMuSXNHcm91cFJvd3NTaG93ID0gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgQ3VzdG9tZXJEZXRhaWwoQ3VzdG9tZXJJZCkge1xyXG4gICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkdldENvbXBsZXRlQ3VzdERldChDdXN0b21lcklkKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0ID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0cyA9IFtdO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5JbWFnZUZpbGVOYW1lICE9IG51bGwgJiYgdGhpcy5tb2RlbElucHV0LkltYWdlRmlsZU5hbWUgIT0gXCJcIikge1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBPcmdJZCA9IFwiXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIGVtcGlkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJlbXBsb3llZWlkXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChlbXBpZCAhPSBudWxsICYmIGVtcGlkICE9IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBPcmdJZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKGVtcGlkICsgXCJfT3JnSWRcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuQ3VzdEZpbGVOYW1lID0gT3JnSWQrXCIvL1wiK3RoaXMubW9kZWxJbnB1dC5JbWFnZUZpbGVOYW1lO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZGVidWdnZXI7XHJcblxyXG4gICAgICAgICAgICAgICAgdGhpcy5Jc0VtYWlsUm93c1Nob3cgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIHRoaXMuU2hvd0hpZGVFbWFpbFJvd3MoKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuSXNQaG9uZXNSb3dzU2hvdyA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5TaG93SGlkZVBob25lc1Jvd3MoKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuSXNBZGRyZXNzUm93c1Nob3cgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIHRoaXMuU2hvd0hpZGVhZGRyZXNzZXNSb3dzKCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLklzR3JvdXBSb3dzU2hvdyA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5TaG93SGlkZUdyb3Vwc1Jvd3MoKTtcclxuICAgICAgICAgICAgICAgIC8valF1ZXJ5KFwiI0VtYWlsVGFibGVcIikuY2hpbGRyZW4oJ3Rib2R5JykuaGlkZSgpO1xyXG4gICAgICAgICAgICAgICAgLy9qUXVlcnkoXCIjRW1haWxUYWJsZVwiKS5jaGlsZHJlbigndGJvZHknKS5jaGlsZHJlbigndHI6Zmlyc3QtY2hpbGQnKS5oaWRlKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcbiAgICBcclxuICAgIG5nT25Jbml0KCkge1xyXG5cclxuICAgXHJcbiAgICAgICAgdGhpcy5DdXN0RmlsZU5hbWUgPSBcIkRlZmF1bHRVc2VyLmpwZ1wiOyBcclxuICAgICAgICBqUXVlcnkoXCIubGVhbi1vdmVybGF5XCIpLmNzcyh7IFwiZGlzcGxheVwiOiBcIm5vbmVcIiB9KTtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCA9IHRoaXMuX3JvdXRlUGFyYW1zLnBhcmFtcy5JZDtcclxuICAgICAgICBpZiAobG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJsYW5nXCIpID09IFwiXCIpIHtcclxuICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJsYW5nXCIsIFwiZW5cIik7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICh0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZ2V0Q29va2llKFwibGFuZ1wiKSA9PSBcIlwiKSB7XHJcblxyXG4gICAgICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2Uuc2V0Q29va2llKFwibGFuZ1wiLCBcImVuXCIsIDEwKTtcclxuXHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMuTGFuZyA9IHRoaXMuX3Jlc291cmNlU2VydmljZS5nZXRDb29raWUoXCJsYW5nXCIpO1xyXG4gICAgICAgIGlmICh0aGlzLkxhbmcubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICB0aGlzLkxhbmcgPSB0aGlzLkxhbmcuc3Vic3RyaW5nKDEsIHRoaXMuTGFuZy5sZW5ndGgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgICAgICBcclxuICAgICAgICBcclxuICAgICAgICBpZiAodGhpcy5MYW5nID09IFwiaGVcIikge1xyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgdGhpcy5DSEFOR0VESVIgPSBcInJ0bG1vZGFsXCI7XHJcbiAgICAgICAgICAgIHRoaXMuQ2hhbmdlRGlhbG9nID0gXCJpbnB1dF9yaWdodFwiO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5DSEFOR0VESVIgPSBcImx0cm1vZGFsXCI7XHJcbiAgICAgICAgICAgIHRoaXMuQ2hhbmdlRGlhbG9nID0gXCJpbnB1dF9sZWZ0XCI7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgIC8vIGRlYnVnZ2VyO1xyXG4gICAgICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLkdldExhbmdSZXModGhpcy5Gb3JtdHlwZSwgdGhpcy5MYW5nKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICB0aGlzLlJFUyA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgfSk7XHJcbiAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkICE9IG51bGwgJiYgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQgIT0gXCJcIikge1xyXG4gICAgICAgICAgIHRoaXMuQ3VzdG9tZXJEZXRhaWwodGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQpO1xyXG5cclxuXHJcbiAgICAgICAgICAgdGhpcy5fUmVjaWVwdFNlcnZpY2UuR2V0UmVjZWlwdEJ5Q3VzdG9tZXJJZCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCkuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgIHRoaXMuUmVjZWlwdHMgPSByZXNwb25zZS5EYXRhO1xyXG5cclxuXHJcbiAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgICAgfSk7XHJcbiAgICAgICB9XHJcbiAgICAgICBlbHNlIHtcclxuICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgbWVzc2FnZTogXCJDdXN0b21lciBub3QgZm91bmRcIiwgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgIH0pO1xyXG4gICAgICAgfVxyXG4gICAgfVxyXG59XHJcbiJdfQ==
