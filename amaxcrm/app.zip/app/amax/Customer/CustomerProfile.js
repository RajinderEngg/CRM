System.register(['angular2/common', "../../services/ResourceService", "angular2/router", "angular2/core", "../../services/CustomerService", "../../amaxUtil", '../../autocomplete/autocomplete-container', '../../autocomplete/autocomplete.component', '../../comonComponents/basicComponents'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var common_1, ResourceService_1, router_1, core_1, CustomerService_1, amaxUtil_1, autocomplete_container_1, autocomplete_component_1, basicComponents_1;
    var AUTOCOMPLETE_DIRECTIVES, AmaxCustomers;
    return {
        setters:[
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (ResourceService_1_1) {
                ResourceService_1 = ResourceService_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (CustomerService_1_1) {
                CustomerService_1 = CustomerService_1_1;
            },
            function (amaxUtil_1_1) {
                amaxUtil_1 = amaxUtil_1_1;
            },
            function (autocomplete_container_1_1) {
                autocomplete_container_1 = autocomplete_container_1_1;
            },
            function (autocomplete_component_1_1) {
                autocomplete_component_1 = autocomplete_component_1_1;
            },
            function (basicComponents_1_1) {
                basicComponents_1 = basicComponents_1_1;
            }],
        execute: function() {
            exports_1("AUTOCOMPLETE_DIRECTIVES", AUTOCOMPLETE_DIRECTIVES = [autocomplete_component_1.Autocomplete, autocomplete_container_1.AutocompleteContainer]);
            AmaxCustomers = (function () {
                function AmaxCustomers(_resourceService, _customerService, _routeParams) {
                    this._resourceService = _resourceService;
                    this._customerService = _customerService;
                    this._routeParams = _routeParams;
                    this.modelInput = {};
                    this.TempmodelInput = {};
                    this.custSearchData = [];
                    this.RES = {};
                    this.SelectedPhType = {};
                    this.tempstreetmsg = "";
                    this.Formtype = "CUSTOMER_MASTER";
                    this.Lang = "";
                    //modelInput.lname= "";
                    this.ShowMore = false;
                    this.IsRecordEditMode = false;
                    this.ShowMoreText = "More";
                    this.ShowLoader = false;
                    this.ShowMsg = false;
                    this.ShowGroups = true;
                    this.GroupText = "Show Groups";
                    this.Msg = "";
                    this.MsgClass = "text-primary";
                    this.Isbtndisable = "";
                    this.IsFileAsSaveBtn = "";
                    this.IsFileAsCancelBtn = "";
                    this.languageArray = [];
                    this.Address = {};
                    this.PhoneModel = {};
                    this.EmailModel = {};
                    this.IsShowAll = false;
                    this.CustList = {};
                    this.SAVE_BTN_TEXT = "";
                    this.BTN_PHADD = "";
                    this.EditPhoneData = {};
                    this.EditAddressData = {};
                    this.EditEmailData = {};
                    this.IsFileAstxtShow = false;
                    this.FILEAS_BTN_TEXT = "";
                    this.cssFileAsBtn = "";
                    this.IsCancel = false;
                    this.SearchVal = "";
                    this.EnterCount = 0;
                    this.CustIdText = "";
                    this.BaseAppUrl = "";
                    this.PhIndex = 0;
                    this.KendoRTLCSS = "";
                    this.CHANGEDIR = "";
                    this.ChangeDialog = "";
                    this.IsPopUp = true;
                    //IsFileAsSave: boolean = false;
                    //Email: string = "";
                    //CustomerEmail: Object = {};
                    //modelInput.CustomerEmails = [];
                    this._CustTypes = [];
                    this._Sources = [];
                    this._Employees = [];
                    this._Suffixes = [];
                    this._PhoneTypes = [];
                    this._AddressTypes = [];
                    this._Groups = [];
                    this._Countries = [];
                    this._States = [];
                    this._Cities = [];
                    this._CustTitles = [];
                    this.selectedCar = '';
                    this.asyncSelectedCar = '';
                    this.autocompleteLoading = false;
                    this.autocompleteNoResults = false;
                    this.autocompleteSelect = false;
                    this._previousasyncSelectedCar = '';
                    this.modelInput.BirthDate = "";
                    this.modelInput.CustomerAddresses = [];
                    this.modelInput.CustomerPhones = [];
                    this.modelInput.CustomerEmails = [];
                    this.modelInput.CustomerGroups = [];
                    this.Address.CountryCode = "";
                    this.Address.StateId = "";
                    this.modelInput.employeeid = "";
                    this.modelInput.CustomerType = "";
                    this.modelInput.CameFromCustomer = "";
                    this.modelInput.Safixid = "";
                    this.modelInput.Gender = "0";
                    this.PhoneModel.PhoneTypeId = "";
                    this.RES.CUSTOMER_MASTER = {};
                    this.IsShowAll = false;
                    this.SAVE_BTN_TEXT = this.RES.CUSTOMER_MASTER.APP_BTN_SAVE;
                    this.BTN_PHADD = this.RES.CUSTOMER_MASTER.APP_BTN_PHADD;
                    this.ADD_NEW_CUST_TEXT = this.RES.CUSTOMER_MASTER.APP_LBL_NEW_CUST;
                    this.modelInput.CustomerEmails = [{ Email: "", EmailName: "", Newslettere: true, publish: 1, NewsOrder: "News1", EPublishOrder: "EPub1" }];
                    this.modelInput.CustomerPhones = [{ PhoneTypeId: "", Prefix: "", Area: "", Phone: "", IsSms: 1, Comments: "", IsShowRemarks: false, phpublish: 1, SMSOrder: "SMS1", PublishOrder: "Pub1" }];
                    // debugger;
                    var empid = localStorage.getItem("employeeid");
                    var ccode = this._resourceService.getCookie(empid + "ccode");
                    if (ccode.length > 0)
                        ccode = ccode.substring(1, ccode.length);
                    this.modelInput.CustomerAddresses = [{
                            Street: "", Street2: "", CityName: "", Zip: "", CountryCode: ccode, StateId: "", AddressTypeId: "",
                            ForDelivery: true, MainAddress: true, MainOrder: "MainAddr1", DelvryOrder: "Delvry1"
                        }];
                    var custtype = this._resourceService.getCookie(empid + "cust");
                    if (custtype.length > 0) {
                        custtype = custtype.substring(1, custtype.length);
                    }
                    this.modelInput.CustomerType = custtype;
                    var emp = this._resourceService.getCookie(empid + "emp");
                    if (emp.length > 0)
                        emp = emp.substring(1, emp.length);
                    this.modelInput.employeeid = emp;
                    var source = this._resourceService.getCookie(empid + "src");
                    if (source.length > 0)
                        source = source.substring(1, source.length);
                    else {
                    }
                    this.modelInput.CameFromCustomer = source;
                    this.CSSTEXT = "mdi-content-add";
                    this.cssFileAsBtn = "mdi-content-create";
                    this.IsFileAstxtShow = false;
                    clearTimeout(this.StopTimeOut);
                    this.modelInput.CustomerId = _routeParams.params.Id;
                    this.BaseAppUrl = _resourceService.AppUrl;
                    this.TempmodelInput = this.modelInput;
                    //alert(this._resourceService.getCookie(empid + "cust"));
                    //this.ShowMoreText = "More";
                }
                AmaxCustomers.prototype.getCurrentContext = function () {
                    return this;
                };
                AmaxCustomers.prototype.dateSelectionChange = function (evt) {
                    console.log(evt);
                    this.modelInput.BirthDate = evt;
                    // alert(this.modelInput.BirthDate);
                    //this.validateLogin();
                };
                AmaxCustomers.prototype.getAsyncData = function (context) {
                    var _this = this;
                    var SrchVal = context.asyncSelectedCar;
                    // if (SrchVal != undefined && SrchVal != null && SrchVal != "") {
                    // debugger;
                    if (this._previousasyncSelectedCar == context.asyncSelectedCar) {
                        //clearTimeout(this.StopTimeOut);
                        return this._cachedResult;
                    }
                    else {
                        //alert(this._previousasyncSelectedCar + " | " + context.asyncSelectedCar);
                        if (context.asyncSelectedCar != "") {
                            this._previousasyncSelectedCar = context.asyncSelectedCar;
                            //  this.StopTimeOut = setTimeout(() => {
                            //    alert(SrchVal);
                            this._customerService.GetCompleteSearch(SrchVal).subscribe(function (response) {
                                // debugger;
                                response = jQuery.parseJSON(response);
                                if (response.IsError == true) {
                                    //alert(response.ErrMsg);
                                    bootbox.alert({ message: response.ErrMsg,
                                        className: _this.ChangeDialog,
                                        buttons: {
                                            ok: {
                                                //label: 'Ok',
                                                className: _this.CHANGEDIR
                                            }
                                        }
                                    });
                                }
                                else {
                                    context.carsExample1 = response.Data;
                                }
                            }, function (error) {
                                console.log(error);
                            }, function () {
                                console.log("CallCompleted");
                            });
                            // }, 500);
                            this._cachedResult = context.carsExample1;
                        }
                        else {
                            this._cachedResult = [];
                        }
                        return this._cachedResult;
                    }
                };
                AmaxCustomers.prototype.changeAutocompleteLoading = function (e) {
                    this.autocompleteLoading = e;
                };
                AmaxCustomers.prototype.changeAutocompleteNoResults = function (e) {
                    this.autocompleteSelect = false;
                    this.autocompleteNoResults = e;
                };
                AmaxCustomers.prototype.autocompleteOnSelect = function (e) {
                    var _this = this;
                    this.autocompleteSelect = true;
                    console.log("Selected value: " + e.item);
                    var CompData = e.item.split('|');
                    // debugger;
                    if (e.item != undefined && e.item != "" && e.item != null) {
                        //alert(CompData[0]);
                        this._customerService.GetCompleteCustDet(CompData[0].trim()).subscribe(function (response) {
                            //debugger;
                            response = jQuery.parseJSON(response);
                            if (response.IsError == true) {
                                //alert(response.ErrMsg);
                                bootbox.alert({ message: response.ErrMsg,
                                    className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                            else {
                                _this.modelInput = response.Data;
                                // alert(this.modelInput.BirthDate);
                                _this.SAVE_BTN_TEXT = _this.RES.CUSTOMER_MASTER.APP_BTN_UPDATE;
                                _this.ADD_NEW_CUST_TEXT = _this.RES.CUSTOMER_MASTER.APP_LBL_NEW_CUST;
                                _this.CSSTEXT = "mdi-content-create";
                                if (_this.modelInput.CustomerEmails.length == 0) {
                                    _this.modelInput.CustomerEmails = [{ Email: "", EmailName: _this.modelInput.FileAs, Newslettere: false }];
                                }
                                else {
                                    jQuery.each(_this.modelInput.CustomerEmails, function () {
                                        if (this.Newslettere == "1") {
                                            this.Newslettere = false;
                                        }
                                        else {
                                            this.Newslettere = true;
                                        }
                                    });
                                }
                                if (_this.modelInput.CustomerPhones.length == 0) {
                                    var phid = "";
                                    jQuery.each(_this._PhoneTypes, function () {
                                        if (this.Text == "CellPhone") {
                                            phid = this.Value;
                                            return false;
                                        }
                                    });
                                    _this.modelInput.CustomerPhones = [{ PhoneTypeId: phid, Prefix: "", Area: "", Phone: "", IsSms: 0, Comments: "", phpublish: 0 }];
                                }
                                if (_this.modelInput.CustomerAddresses.length == 0) {
                                    var empid = localStorage.getItem("employeeid");
                                    var ccode = _this._resourceService.getCookie(empid + "ccode");
                                    if (ccode.length > 0)
                                        ccode = ccode.substring(1, ccode.length);
                                    var adid = "";
                                    var comptext = "Home";
                                    if (_this.modelInput.Company != "" && _this.modelInput.Company != undefined && _this.modelInput.Company != null) {
                                        comptext = "Work";
                                    }
                                    jQuery.each(_this._AddressTypes, function () {
                                        if (this.Text == comptext) {
                                            adid = this.Value;
                                            return false;
                                        }
                                    });
                                    _this.modelInput.CustomerAddresses = [{ Street: "", Street2: "", CityName: "", Zip: "", CountryCode: ccode, StateId: "", AddressTypeId: adid, ForDelivery: false, MainAddress: false }];
                                }
                                _this.CustIdText = "( " + _this.modelInput.CustomerId + " )";
                                _this.IsFileAstxtShow = false;
                                //this.IsCancel = true;
                                //this.HideShowFileAstxt();
                                _this.CancelFileAstxt();
                                _this.IsShowAll = true;
                                //this.bindGroup();
                                //alert(this.RES);
                                _this.bindGroupTree(true);
                            }
                        }, function (error) {
                            console.log(error);
                        }, function () {
                            console.log("CallCompleted");
                        });
                    }
                };
                AmaxCustomers.prototype.OpenNewReceipt = function () {
                    if (this.modelInput != undefined && this.modelInput.CustomerId != undefined && this.modelInput.CustomerId >= 0) {
                        var custId = this.modelInput.CustomerId;
                        if (custId != -1) {
                            var emid = localStorage.getItem("employeeid");
                            document.location = this.BaseAppUrl + "ReceiptSelect/" + emid + "/" + custId;
                        }
                    }
                };
                AmaxCustomers.prototype.OpenChargeCreditPage = function () {
                    var _this = this;
                    this.Isbtndisable = "disabled";
                    this._customerService.CheckIsOpenCharge().subscribe(function (response) {
                        console.log(response);
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    } } });
                        }
                        else {
                            //debugger;
                            if (response.Data != undefined && response.Data != null && response.Data.length == 1) {
                                var custId = -1;
                                if (_this.TempmodelInput != undefined && _this.TempmodelInput.CustomerId != undefined && _this.TempmodelInput.CustomerId >= 0) {
                                    custId = _this.TempmodelInput.CustomerId;
                                }
                                if (_this.modelInput != undefined && _this.modelInput.CustomerId != undefined && _this.modelInput.CustomerId >= 0) {
                                    custId = _this.modelInput.CustomerId;
                                }
                                if (custId != -1) {
                                    document.location = _this.BaseAppUrl + "ChargeCredit/" + custId + "/" + response.Data[0].Value;
                                }
                                else {
                                    bootbox.alert({
                                        message: 'Please save new or load previous customer and then click on charge credit button',
                                        className: _this.ChangeDialog,
                                        buttons: {
                                            ok: {
                                                //label: 'Ok',
                                                className: _this.CHANGEDIR
                                            }
                                        }
                                    });
                                }
                            }
                            else if (response.Data != undefined && response.Data != null && response.Data.length > 1) {
                                //debugger;
                                var custId = -1;
                                if (_this.TempmodelInput != undefined && _this.TempmodelInput.CustomerId != undefined && _this.TempmodelInput.CustomerId >= 0) {
                                    custId = _this.TempmodelInput.CustomerId;
                                }
                                if (_this.modelInput != undefined && _this.modelInput.CustomerId != undefined && _this.modelInput.CustomerId >= 0) {
                                    custId = _this.modelInput.CustomerId;
                                }
                                if (custId != -1) {
                                    document.location = _this.BaseAppUrl + "Terminals/Show/" + custId;
                                }
                                else {
                                    bootbox.alert({
                                        message: 'Please save new or load previous customer and then click on charge credit button',
                                        className: _this.ChangeDialog,
                                        buttons: {
                                            ok: {
                                                //label: 'Ok',
                                                className: _this.CHANGEDIR
                                            }
                                        }
                                    });
                                }
                            }
                            else {
                                bootbox.alert({
                                    message: _this.RES.CUSTOMER_MASTER.APP_MSG_CHARGECREDIT,
                                    className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        } }
                                });
                            }
                        }
                        _this.ShowMsg = true;
                        _this.Msg = response.ErrMsg;
                    }, function (error) { return console.log(error); }, function () { return console.log("Save Call Compleated"); });
                    this.Isbtndisable = "";
                };
                AmaxCustomers.prototype.StopTimer = function () {
                    bootbox.alert({
                        message: 'From Stop Timer' + this.StopTimeOut, className: this.ChangeDialog,
                        buttons: {
                            ok: {
                                //label: 'Ok',
                                className: this.CHANGEDIR
                            }
                        }
                    });
                    clearTimeout(this.StopTimeOut);
                };
                AmaxCustomers.prototype.SetdefaultPage = function () {
                    var _this = this;
                    document.location = this.BaseAppUrl + "Customer/Add/-1";
                    this.IsFileAstxtShow = true;
                    this.IsCancel = true;
                    var empid = localStorage.getItem("employeeid");
                    this.asyncSelectedCar = "";
                    this.modelInput = {};
                    this.modelInput.BirthDate = "";
                    this.modelInput.CustomerId = -1;
                    this.CustIdText = "";
                    this.HideShowFileAstxt();
                    var custtype = this._resourceService.getCookie(empid + "cust");
                    if (custtype.length > 0)
                        custtype = custtype.substring(1, custtype.length);
                    this.modelInput.CustomerType = custtype;
                    var emp = this._resourceService.getCookie(empid + "emp");
                    if (emp.length > 0)
                        emp = emp.substring(1, emp.length);
                    this.modelInput.employeeid = emp;
                    var source = this._resourceService.getCookie(empid + "src");
                    if (source.length > 0)
                        source = source.substring(1, source.length);
                    this.modelInput.CameFromCustomer = source;
                    this.ShowMore = false;
                    //this.ShowMoreText = "More"; 
                    this.ShowMoreText = this.RES.CUSTOMER_MASTER.APP_LNK_LBL_MORE;
                    this.SAVE_BTN_TEXT = this.RES.CUSTOMER_MASTER.APP_BTN_SAVE;
                    this.CSSTEXT = "mdi-content-add";
                    this.ADD_NEW_CUST_TEXT = this.RES.CUSTOMER_MASTER.APP_LBL_NEW_CUST;
                    this.ShowGroups = true;
                    this.showhideGroups();
                    //this.GroupText = this.RES.CUSTOMER_MASTER.APP_LBL_SHOWGROUPS;
                    var phid = "";
                    var SMS = 0;
                    var publish = 0;
                    var epublish = 0;
                    jQuery.each(this._PhoneTypes, function () {
                        if (this.Text == "CellPhone") {
                            phid = this.Value;
                            SMS = 1;
                            publish = 1;
                            epublish = 1;
                            return false;
                        }
                    });
                    this.modelInput.CustomerPhones = [{ PhoneTypeId: phid, Prefix: "", Area: "", Phone: "", IsSms: SMS, Comments: "", phpublish: publish }];
                    //debugger;
                    this.modelInput.CustomerEmails = [{ Email: "", EmailName: "", Newslettere: false, publish: epublish }];
                    var cntrycode = this._resourceService.getCookie(empid + "ccode");
                    if (cntrycode.length > 0)
                        cntrycode = cntrycode.substring(1, cntrycode.length);
                    var adid = "";
                    jQuery.each(this._AddressTypes, function () {
                        if (this.Text == "Home") {
                            adid = this.Value;
                            return false;
                        }
                    });
                    this.modelInput.CustomerAddresses = [{ Street: "", Street2: "", CityName: "", Zip: "", CountryCode: cntrycode, StateId: "", AddressTypeId: adid, ForDelivery: false, MainAddress: false }];
                    this.modelInput.CustomerGroups = [];
                    this.Address.CountryCode = "";
                    this.Address.StateId = "";
                    this.modelInput.Safixid = "";
                    this.modelInput.Gender = "0";
                    this.ShowMsg = false;
                    this.Msg = "";
                    this.IsShowAll = false;
                    this._customerService.GetGeneralGroups(this.IsShowAll).subscribe(function (data) {
                        // debugger;
                        if (_this.IsShowAll == false) {
                            jQuery("#groupTree").html("Loding...");
                            var res = jQuery.parseJSON(data).Data;
                            jQuery("#groupTree").kendoTreeView({
                                loadOnDemand: true,
                                checkboxes: {
                                    checkChildren: true
                                },
                                //check: this.onGroupSelect,
                                dataSource: res
                            });
                        }
                        else {
                            jQuery("#groupTree1").html("Loding...");
                            var res = jQuery.parseJSON(data).Data;
                            jQuery("#groupTree1").kendoTreeView({
                                loadOnDemand: true,
                                checkboxes: {
                                    checkChildren: true
                                },
                                //check: this.onGroupSelect,
                                dataSource: res
                            });
                        }
                    }, function (err) {
                    }, function () {
                    });
                    this.IsPopUp = true;
                };
                AmaxCustomers.prototype.CancelFileAstxt = function () {
                    this.IsFileAstxtShow = true;
                    this.IsFileAstxtShow = false;
                    this.IsCancel = true;
                    jQuery("#FileAstxt").hide();
                    jQuery("#FileAsSpn").show();
                    this.FILEAS_BTN_TEXT = this.RES.CUSTOMER_MASTER.APP_BTN_FILEAS;
                    if (this.modelInput.CustomerId != undefined && this.modelInput.CustomerId != null && parseInt(this.modelInput.CustomerId) > -1) {
                        jQuery("#FileAsSaveBtn").show();
                        this.cssFileAsBtn = "mdi-content-create";
                        jQuery("#FileAsCancelBtn").hide();
                    }
                    else {
                        jQuery("#FileAsSaveBtn").hide();
                        jQuery("#FileAsCancelBtn").hide();
                    }
                };
                AmaxCustomers.prototype.HideShowFileAstxt = function () {
                    var _this = this;
                    if (this.IsFileAstxtShow == false) {
                        this.IsFileAstxtShow = true;
                        jQuery("#FileAstxt").show();
                        jQuery("#FileAsSpn").hide();
                        this.IsCancel = false;
                        this.FILEAS_BTN_TEXT = this.RES.CUSTOMER_MASTER.APP_BTN_SAVEFILEAS;
                        // alert(this.modelInput.CustomerId);
                        if (this.modelInput.CustomerId != undefined && this.modelInput.CustomerId != null && parseInt(this.modelInput.CustomerId) > -1) {
                            jQuery("#FileAsSaveBtn").show();
                            this.cssFileAsBtn = "mdi-content-save";
                            jQuery("#FileAsCancelBtn").show();
                        }
                        else {
                            jQuery("#FileAsSaveBtn").hide();
                            jQuery("#FileAsCancelBtn").hide();
                        }
                    }
                    else {
                        this.IsFileAstxtShow = false;
                        jQuery("#FileAstxt").hide();
                        jQuery("#FileAsSpn").show();
                        this.FILEAS_BTN_TEXT = this.RES.CUSTOMER_MASTER.APP_BTN_FILEAS;
                        if (this.modelInput.CustomerId != undefined && this.modelInput.CustomerId != null && parseInt(this.modelInput.CustomerId) > -1) {
                            jQuery("#FileAsSaveBtn").show();
                            this.cssFileAsBtn = "mdi-content-create";
                            jQuery("#FileAsCancelBtn").hide();
                            if (this.modelInput.FileAs != "" && this.modelInput.FileAs != undefined && this.modelInput.FileAs != null && this.IsCancel == false) {
                                this._customerService.SaveFileAs(this.modelInput.CustomerId, this.modelInput.FileAs).subscribe(function (response) {
                                    response = jQuery.parseJSON(response);
                                    //alert('hello');
                                    if (response.IsError == true) {
                                        //alert(response.ErrMsg);
                                        bootbox.alert({
                                            message: response.ErrMsg, className: _this.ChangeDialog,
                                            buttons: {
                                                ok: {
                                                    //label: 'Ok',
                                                    className: _this.CHANGEDIR
                                                }
                                            }
                                        });
                                    }
                                    //this.IsFileAsSave = false;
                                    bootbox.alert({
                                        message: response.ErrMsg, className: _this.ChangeDialog,
                                        buttons: {
                                            ok: {
                                                //label: 'Ok',
                                                className: _this.CHANGEDIR
                                            }
                                        }
                                    });
                                    _this.IsCancel = true;
                                    //}
                                    //else {
                                    //}
                                });
                            }
                            else {
                                bootbox.alert({
                                    message: this.RES.CUSTOMER_MASTER.APP_EMPTYFILEAS, className: this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: this.CHANGEDIR
                                        }
                                    }
                                });
                                this.bindFileAs();
                                this.IsFileAstxtShow = false;
                                this.HideShowFileAstxt();
                            }
                        }
                        else {
                            jQuery("#FileAsSaveBtn").hide();
                            jQuery("#FileAsCancelBtn").hide();
                        }
                    }
                };
                AmaxCustomers.prototype.SetEmailName = function () {
                    if (this.modelInput.FileAs != undefined && this.modelInput.FileAs != null) {
                        if (this.modelInput.CustomerEmails.length > 0) {
                            this.modelInput.CustomerEmails[this.modelInput.CustomerEmails.length - 1].EmailName = this.modelInput.FileAs;
                        }
                    }
                };
                AmaxCustomers.prototype.CheckCustWithSameName = function () {
                };
                AmaxCustomers.prototype.SetDefaultCust = function () {
                    //alert();
                    //debugger;
                };
                AmaxCustomers.prototype.setdefaultAddress = function () {
                    this.bindFileAs();
                    this.CheckCustWithfnamelnamecompphsemails();
                    var adid = "";
                    var adtext = "Home";
                    if (this.modelInput.Company != "" && this.modelInput.Company != undefined) {
                        adtext = "Work";
                    }
                    jQuery.each(this._AddressTypes, function () {
                        if (this.Text == adtext) {
                            adid = this.Value;
                            return false;
                        }
                    });
                    this.modelInput.CustomerAddresses[this.modelInput.CustomerAddresses.length - 1].AddressTypeId = adid;
                };
                AmaxCustomers.prototype.bindFileAs = function () {
                    if (this.modelInput.FileAs == "" || this.modelInput.FileAs == undefined) {
                        //debugger;
                        if ((this.modelInput.Company == "" || this.modelInput.Company == undefined)) {
                            var fileastext = "";
                            if (this.modelInput.fname != "" && this.modelInput.fname != undefined && this.modelInput.lname != "" && this.modelInput.lname != undefined) {
                                fileastext = this.modelInput.lname + " " + this.modelInput.fname;
                            }
                            else if (this.modelInput.fname != "" && this.modelInput.fname != undefined && (this.modelInput.lname == "" || this.modelInput.lname == undefined)) {
                                fileastext = " " + this.modelInput.fname;
                            }
                            else if ((this.modelInput.fname == "" || this.modelInput.fname == undefined) && (this.modelInput.lname != "" && this.modelInput.lname != undefined)) {
                                fileastext = this.modelInput.lname + " ";
                            }
                            this.modelInput.FileAs = fileastext;
                        }
                        else if ((this.modelInput.lname == "" || this.modelInput.lname == undefined) && (this.modelInput.fname == "" || this.modelInput.lname == undefined)) {
                            var fileastext = "";
                            if ((this.modelInput.Company != "" && this.modelInput.Company != undefined)) {
                                fileastext = this.modelInput.Company;
                            }
                            this.modelInput.FileAs = fileastext;
                        }
                        else
                            this.modelInput.FileAs = "(" + this.modelInput.Company + ") " + this.modelInput.lname + " " + this.modelInput.fname; //+ " " & m_strSpouse
                        if (this.modelInput.CustomerEmails.length > 0) {
                            this.modelInput.CustomerEmails[this.modelInput.CustomerEmails.length - 1].EmailName = this.modelInput.FileAs;
                        }
                    }
                    this.SetEmailName();
                };
                AmaxCustomers.prototype.bindGroup = function () {
                    //alert(this.IsShowAll); this function is calling on click of checkbox
                    var isshow = false;
                    if (this.IsShowAll == true) {
                        isshow = false;
                        this.IsShowAll = false;
                    }
                    else {
                        this.IsShowAll = true;
                        isshow = true;
                    }
                    this.bindGroupTree(isshow);
                };
                AmaxCustomers.prototype.saveCustomerData = function () {
                    var _this = this;
                    //debugger;
                    this.Isbtndisable = "disabled";
                    this.ShowLoader = true;
                    this.getSelectedGroups();
                    var count = 0;
                    if (this.modelInput.CustomerAddresses != undefined && this.modelInput.CustomerAddresses != null) {
                        jQuery.each(this.modelInput.CustomerAddresses, function () {
                            if (this.MainAddress == true) {
                                count = count + 1;
                            }
                            if (count > 1) {
                                //bootbox.alert("Main Address sholud be only one");
                                this.Isbtndisable = "";
                                this.ShowLoader = false;
                                return false;
                            }
                        });
                    }
                    //alert(this.modelInput.BirthDate);
                    if (this.modelInput.BirthDate != "") {
                        if (moment(this.modelInput.BirthDate, "DD-MM-YYYY", true).isValid() == false) {
                            bootbox.alert({ message: "Birthdate is not valid" });
                            this.Isbtndisable = "";
                            this.ShowLoader = false;
                            return false;
                        }
                    }
                    this.modelInput.Title = jQuery("#Title").val();
                    if (count <= 1 || this.modelInput.CustomerAddresses == undefined || this.modelInput.CustomerAddresses == null) {
                        if (this.modelInput.CustomerPhones != undefined && this.modelInput.CustomerPhones != null) {
                            var phtemp = [];
                            jQuery('input[name^="ph"]').each(function () {
                                phtemp.push(jQuery(this).val());
                            });
                            var artemp = [];
                            jQuery('input[name^="ar"]').each(function () {
                                artemp.push(jQuery(this).val());
                            });
                            var pretemp = [];
                            jQuery('input[name^="pre"]').each(function () {
                                pretemp.push(jQuery(this).val());
                            });
                            var i = 0;
                            jQuery.each(this.modelInput.CustomerPhones, function () {
                                if (this.IsSms == true) {
                                    this.IsSms = "1";
                                }
                                else {
                                    this.IsSms = "0";
                                }
                                if (this.phpublish == true) {
                                    this.phpublish = "1";
                                }
                                else {
                                    this.phpublish = "0";
                                }
                                this.Phone = phtemp[i];
                                this.Area = artemp[i];
                                this.Prefix = pretemp[i];
                                i++;
                                //var temp = this.PhoneTypeId.split(';');
                                //this.PhoneTypeId = parseInt(temp[1]);
                                //this.PhoneType = temp[0];
                            });
                        }
                        if (this.modelInput.CustomerEmails != undefined && this.modelInput.CustomerEmails != null) {
                            jQuery.each(this.modelInput.CustomerEmails, function () {
                                if (this.publish == true) {
                                    this.publish = "1";
                                }
                                else {
                                    this.publish = "0";
                                }
                                // debugger;
                                if (this.Newslettere == true) {
                                    this.Newslettere = false;
                                }
                                else {
                                    this.Newslettere = true;
                                }
                                i++;
                            });
                        }
                        var jdata = JSON.stringify(this.modelInput);
                        console.log(jdata);
                        this._customerService.AddCustomer(jdata).subscribe(function (response) {
                            console.log(response);
                            response = jQuery.parseJSON(response);
                            _this.Isbtndisable = "";
                            _this.ShowLoader = false;
                            if (response.IsError == true) {
                                //alert(response.ErrMsg);
                                _this.MsgClass = "text-danger";
                            }
                            else {
                                //alert(response.ErrMsg);
                                _this.MsgClass = "text-success";
                                var empid = localStorage.getItem("employeeid");
                                _this._resourceService.setCookie(empid + "cust", _this.modelInput.CustomerType, 10);
                                _this._resourceService.setCookie(empid + "emp", _this.modelInput.employeeid, 10);
                                _this._resourceService.setCookie(empid + "src", _this.modelInput.CameFromCustomer, 10);
                                if (_this.modelInput.CustomerAddresses.length > 0)
                                    _this._resourceService.setCookie(empid + "ccode", _this.modelInput.CustomerAddresses[_this.modelInput.CustomerAddresses.length - 1].CountryCode, 10);
                                // debugger;
                                //document.location = this.BaseAppUrl + "Customer/Add/-1";
                                //debugger;
                                _this.TempmodelInput = response.Data;
                                _this.modelInput = response.Data;
                                _this.editCustDet(_this.modelInput);
                            }
                            _this.ShowMsg = true;
                            _this.Msg = response.ErrMsg;
                        }, function (error) { return console.log(error); }, function () { return console.log("Save Call Compleated"); });
                    }
                    else {
                        bootbox.alert({
                            message: this.RES.CUSTOMER_MASTER.APP_MSG_ISMAINADD, className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                        this.Isbtndisable = "";
                        this.ShowLoader = false;
                    }
                };
                AmaxCustomers.prototype.CheckCustWithfnamelnamecompphsemails = function () {
                    var _this = this;
                    if (this.IsPopUp == true) {
                        var jdata = JSON.stringify(this.modelInput);
                        //debugger;
                        var fname = "";
                        var lname = "";
                        var company = "";
                        var phones = "";
                        var emails = "";
                        if (this.modelInput.fname == undefined)
                            fname = "";
                        else
                            fname = this.modelInput.fname;
                        if (this.modelInput.lname == undefined)
                            lname = "";
                        else
                            lname = this.modelInput.lname;
                        if (this.modelInput.Company == undefined)
                            company = "";
                        else
                            company = this.modelInput.Company;
                        jQuery('input[name^="ph"]').each(function () {
                            if (jQuery(this).val() != "" && jQuery(this).val() != undefined && jQuery(this).val() != null && jQuery(this).val().length >= 3) {
                                phones += jQuery(this).val() + "','";
                            }
                        });
                        if (phones.length > 0)
                            phones = phones.substring(0, phones.length - 3);
                        jQuery.each(this.modelInput.CustomerEmails, function () {
                            if (this.Email != "" && this.Email != undefined && this.Email != null && this.Email.length >= 3) {
                                emails += this.Email + "','";
                            }
                        });
                        if (emails.length > 0)
                            emails = emails.substring(0, emails.length - 3);
                        if ((fname != "" && fname.length >= 2 && lname != "" && lname.length >= 2)
                            || (company != "" && company.length >= 3)
                            || (phones != "")
                            || (emails != "")) {
                            this._customerService.GetCustomersSearchData(fname, lname, company, phones, emails).subscribe(function (response) {
                                //debugger;
                                response = jQuery.parseJSON(response);
                                if (response.IsError == true) {
                                    bootbox.alert({
                                        message: response.ErrMsg, className: _this.ChangeDialog,
                                        buttons: {
                                            ok: {
                                                //label: 'Ok',
                                                className: _this.CHANGEDIR
                                            }
                                        }
                                    });
                                }
                                else {
                                    _this.CustList = {};
                                    _this.CustList = response.Data;
                                    if (response.Data != null && response.Data != undefined) {
                                        _this.custSearchData = response.Data;
                                        jQuery('#CustModal').openModal();
                                    }
                                }
                            }, function (error) {
                                console.log(error);
                            }, function () {
                                console.log("CallCompleted");
                            });
                        }
                    }
                    //this.bindFileAs();
                };
                AmaxCustomers.prototype.CloseModalPop = function () {
                    this.ClosePopUp();
                    this.IsPopUp = false;
                };
                AmaxCustomers.prototype.ClosePopUp = function () {
                    jQuery("#CustModal").closeModal();
                    jQuery(".lean-overlay").css({ "display": "none" });
                };
                AmaxCustomers.prototype.CheckCustWithfnamelname = function (fname, lname, company) {
                    var _this = this;
                    var jdata = JSON.stringify(this.modelInput);
                    //debugger;
                    if (this.modelInput.fname == undefined)
                        fname = "";
                    else
                        fname = this.modelInput.fname;
                    if (this.modelInput.lname == undefined)
                        lname = "";
                    else
                        lname = this.modelInput.lname;
                    if (this.modelInput.Company == undefined)
                        company = "";
                    else
                        company = this.modelInput.Company;
                    this._customerService.CheckCustWithSameName(fname, lname, company).subscribe(function (response) {
                        //debugger;
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.CustList = {};
                            _this.CustList = response.Data;
                            if (response.Data != null && response.Data != undefined) {
                                _this.custSearchData = response.Data;
                                jQuery("#CustModal").openModal();
                            }
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //this.bindFileAs();
                };
                AmaxCustomers.prototype.CheckCustWithEmail = function () {
                    //var Email = "";
                    //if (this.EmailModel.Email != "" && this.EmailModel.Email != undefined)
                    //    Email = this.EmailModel.Email;
                    //this._customerService.CheckCustWithSameEmail(Email).subscribe(response=> {
                    //    //debugger;
                    //    response = jQuery.parseJSON(response);
                    //    if (response.IsError == true) {
                    //        alert(response.ErrMsg);
                    //    }
                    //    else {
                    //        this.CustList = {};
                    //        this.CustList = response.Data;
                    //        if (response.Data != null && response.Data != undefined) {
                    //            this.custSearchData = response.Data;
                    //            jQuery("#CustModal").modal("show");
                    //        }
                    //        //alert(this.RES);
                    //    }
                    //}, error=> {
                    //    console.log(error);
                    //}, () => {
                    //    console.log("CallCompleted")
                    //});
                };
                AmaxCustomers.prototype.CheckCustWithPhone = function () {
                    var _this = this;
                    var Phone = "";
                    if (this.PhoneModel.Phone != "" && this.PhoneModel.Phone != undefined)
                        Phone = this.PhoneModel.Phone;
                    this._customerService.CheckCustWithSamePhone(this.PhoneModel.Phone).subscribe(function (response) {
                        //debugger;
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.CustList = {};
                            _this.CustList = response.Data;
                            if (response.Data != null && response.Data != undefined) {
                                _this.custSearchData = response.Data;
                                jQuery("#CustModal").openModal();
                            }
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxCustomers.prototype.ShowRemarks = function (PhObj) {
                    jQuery.each(this.modelInput.CustomerPhones, function () {
                        if (this == PhObj) {
                            this.IsShowRemarks = true;
                        }
                    });
                };
                AmaxCustomers.prototype.showAddPopup = function () {
                    this.Address = {};
                    this.PhoneModel = {};
                    this.PhoneModel.PhoneTypeId = "";
                    this.Address.CountryCode = "";
                    this.Address.StateId = "";
                    this.Address.CityName = "";
                    this.Address.AddressTypeId = "";
                    this.EmailModel = {};
                    this.BTN_PHADD = this.RES.CUSTOMER_MASTER.APP_BTN_PHADD;
                };
                AmaxCustomers.prototype.showhideGroups = function () {
                    //debugger;
                    if (this.ShowGroups == false) {
                        this.ShowGroups = true;
                        this.GroupText = this.RES.CUSTOMER_MASTER.APP_LBL_HIDEGROUP;
                        jQuery("#GrpDiv").show(1000);
                    }
                    else {
                        this.ShowGroups = false;
                        this.GroupText = this.RES.CUSTOMER_MASTER.APP_LBL_SHOWGROUPS;
                        jQuery("#GrpDiv").hide(1000);
                    }
                };
                AmaxCustomers.prototype.CanaddAddress = function (adobj) {
                    //alert('Hello');
                    return (adobj.Street != undefined && adobj.Street != "")
                        && (adobj.Street2 != undefined && adobj.Street2 != "")
                        && (adobj.Zip != undefined && adobj.Zip != "")
                        && (adobj.CountryCode != undefined && adobj.CountryCode != "")
                        && (adobj.AddressTypeId != undefined && adobj.AddressTypeId != "");
                };
                AmaxCustomers.prototype.AddAddresses = function (adobj) {
                    var IsMainAdd = false;
                    adobj.CityName = jQuery("#City").val();
                    if (this.CanaddAddress(adobj)) {
                        var empid = localStorage.getItem("employeeid");
                        this._resourceService.setCookie(empid + "ccode", adobj.CountryCode, 10);
                        var adid = "";
                        var adtext = "Home";
                        if (this.modelInput.Company != "" && this.modelInput.Company != undefined) {
                            adtext = "Work";
                        }
                        jQuery.each(this._AddressTypes, function () {
                            if (this.Text == adtext) {
                                adid = this.Value;
                                return false;
                            }
                        });
                        var AddresObj = { Street: "", Street2: "", CityName: "", Zip: "", CountryCode: adobj.CountryCode, StateId: "", AddressTypeId: adid, ForDelivery: false, MainAddress: false, MainOrder: "MainAddr" + (this.modelInput.CustomerAddresses.length + 1).toString(), DelvryOrder: "Delvry" + (this.modelInput.CustomerAddresses.length + 1).toString() };
                        //jQuery.each(this.modelInput.CustomerAddresses, function () {
                        //    if (this.MainAddress == true && adobj.MainAddress == true && this != adobj) {
                        //        adobj.MainAddress = false;
                        //        return false;
                        //    }
                        //});
                        if (IsMainAdd == false) {
                            this.modelInput.CustomerAddresses.push(AddresObj);
                        }
                    }
                    else {
                        var msg = '';
                        if (adobj.Street == undefined || adobj.Street == "") {
                            //msg += '\nStreet is not filled'; APP_AL_MSG_STREET
                            msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_MSG_STREET;
                        }
                        if (adobj.Street2 == undefined || adobj.Street2 == "") {
                            //msg += '\nArea is not filled';
                            msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_MSG_AREA;
                        }
                        //if (adobj.CityName == undefined || adobj.CityName == "")
                        //    //msg += '\nCity is not filled'; 
                        //    msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_MSG_CITY;
                        if (adobj.Zip == undefined || adobj.Zip == "") {
                            //msg += '\nZip is not filled'; 
                            msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_MSG_ZIP;
                        }
                        if (adobj.CountryCode == undefined || adobj.CountryCode == "") {
                            //msg += '\nCountry is not selected';
                            msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_MSG_COUNTRY;
                        }
                        //if (this.Address.StateId == undefined || this.Address.StateId == "") {
                        //    msg += '\nState is not selected';
                        //}
                        if (adobj.AddressTypeId == undefined || adobj.AddressTypeId == "") {
                            //msg += '\nAddress type is not selected';
                            msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_MSG_ADTYPE;
                        }
                        bootbox.alert({
                            message: msg, className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                    }
                };
                AmaxCustomers.prototype.CanaddPhone = function (phoneObj) {
                    //debugger;
                    //alert(this.PhoneModel.PhoneTypeId + ' ' + this.PhoneModel.PhoneType + ' ' + this.PhoneModel.Prefix + ' ' + this.PhoneModel.Area + ' ' + this.PhoneModel.Phone);
                    return (phoneObj.PhoneTypeId != undefined && phoneObj.PhoneTypeId != "");
                    // && (this.PhoneModel.PhoneType != undefined&& this.PhoneModel.PhoneType != "" )
                    //&& (this.PhoneModel.Prefix != undefined&& this.PhoneModel.Prefix != ""  )
                    //&& (this.PhoneModel.Area != undefined&&this.PhoneModel.Area != ""  )
                    //&& (phoneObj.Phone != undefined && phoneObj.Phone != "");
                    //&& (this.PhoneModel.Prefix != undefined && this.PhoneModel.Prefix.length != 3);            ;
                };
                AmaxCustomers.prototype.AddPhones = function (phoneObj) {
                    if (this.CanaddPhone(phoneObj)) {
                        // debugger;
                        //if (this.IsRecordEditMode == false) {
                        var phid = "";
                        var SMS = 0;
                        var publish = 0;
                        jQuery.each(this._PhoneTypes, function () {
                            if (this.Text == "CellPhone") {
                                phid = this.Value;
                                SMS = 1;
                                publish = 1;
                                return false;
                            }
                        });
                        var PhoneObj = { PhoneTypeId: phid, PhoneType: "", Prefix: "", Area: "", Phone: "", IsSms: SMS, Comments: "", IsShowRemarks: false, phpublish: publish, SMSOrder: "SMS" + (this.modelInput.CustomerPhones.length + 1).toString(), PublishOrder: "Pub" + (this.modelInput.CustomerPhones.length + 1).toString() };
                        this.modelInput.CustomerPhones.push(PhoneObj);
                    }
                    else {
                        var msg = '';
                        if (phoneObj.PhoneTypeId == undefined || phoneObj.PhoneTypeId == "") {
                            //msg += '\nPhone type is not selected';
                            msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_REGMSG_PHTYPE;
                        }
                        //if (phoneObj.Phone == undefined || phoneObj.Phone == "") {
                        //    //msg += '\nPhone number is not filled';
                        //    msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_REGMSG_PHNO;
                        //}
                        //if (this.PhoneModel.Prefix.length!=3) {
                        //    msg += '\nPrefix must of 3 numeric digits';
                        //}
                        bootbox.alert({
                            message: msg, className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                    }
                };
                AmaxCustomers.prototype.CanaddEmail = function (EmailObj) {
                    //debugger;
                    //alert('Hello');
                    return (EmailObj.EmailName != undefined && EmailObj.EmailName != "");
                    //(EmailObj.Email != undefined && EmailObj.Email != "") &&
                };
                AmaxCustomers.prototype.AddEmails = function (EmailObj) {
                    //debugger;
                    if (this.CanaddEmail(EmailObj)) {
                        var epublish = 0;
                        jQuery.each(this._PhoneTypes, function () {
                            if (this.Text == "CellPhone") {
                                epublish = 1;
                                return false;
                            }
                        });
                        //if (this.IsRecordEditMode == false) {
                        var eObj = {};
                        eObj.Email = "";
                        eObj.EmailName = this.modelInput.FileAs;
                        eObj.Newslettere = true;
                        eObj.publish = epublish;
                        eObj.NewsOrder = "News" + (this.modelInput.CustomerEmails.length + 1).toString();
                        eObj.EPublishOrder = "EPub" + (this.modelInput.CustomerEmails.length + 1).toString();
                        this.modelInput.CustomerEmails.push(eObj);
                    }
                    else {
                        var msg = '';
                        //if (EmailObj.Email == undefined || EmailObj.Email == "")
                        //    //msg += '\nEmail is not filled';
                        //    msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_REGMSG_EMAIL;
                        if (EmailObj.EmailName == undefined || EmailObj.EmailName == "") {
                            //msg += '\nName is not filled';
                            msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_REGMSG_ENAME;
                        }
                        bootbox.alert({
                            message: msg, className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                    }
                    // this.modelInput.CustomerAddresses = this.CustomerAddresses;
                };
                AmaxCustomers.prototype.editCustDet = function (Obj) {
                    var _this = this;
                    this._customerService.GetCompleteCustDet(Obj.CustomerId).subscribe(function (response) {
                        //  debugger;
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.modelInput = response.Data;
                            _this.SAVE_BTN_TEXT = _this.RES.CUSTOMER_MASTER.APP_BTN_UPDATE;
                            //this.ADD_NEW_CUST_TEXT = this.RES.CUSTOMER_MASTER.APP_LBL_UPDATE_CUST;
                            _this.CSSTEXT = "mdi-content-add";
                            if (_this.modelInput.CustomerEmails.length == 0) {
                                _this.modelInput.CustomerEmails = [{ Email: "", EmailName: _this.modelInput.FileAs, Newslettere: false, publish: 0, NewsOrder: "News1", EPublishOrder: "EPub1" }];
                            }
                            else {
                                var count = 1;
                                jQuery.each(_this.modelInput.CustomerEmails, function () {
                                    this.NewsOrder = "News" + count;
                                    this.EPublishOrder = "EPub" + count++;
                                    if (this.Newslettere == "1") {
                                        this.Newslettere = false;
                                    }
                                    else {
                                        this.Newslettere = true;
                                    }
                                });
                            }
                            if (_this.modelInput.CustomerPhones.length == 0) {
                                var phid = "";
                                jQuery.each(_this._PhoneTypes, function () {
                                    if (this.Text == "CellPhone") {
                                        phid = this.Value;
                                        return false;
                                    }
                                });
                                _this.modelInput.CustomerPhones = [{ PhoneTypeId: phid, Prefix: "", Area: "", Phone: "", IsSms: 0, Comments: "", phpublish: 0, SMSOrder: "SMS1", PublishOrder: "Pub1" }];
                            }
                            else {
                                var count = 1;
                                jQuery.each(_this.modelInput.CustomerPhones, function () {
                                    this.SMSOrder = "SMS" + count;
                                    this.PublishOrder = "Pub" + count++;
                                });
                            }
                            if (_this.modelInput.CustomerAddresses.length == 0) {
                                var empid = localStorage.getItem("employeeid");
                                var ccode = _this._resourceService.getCookie(empid + "ccode");
                                if (ccode.length > 0)
                                    ccode = ccode.substring(1, ccode.length);
                                var adid = "";
                                var comptext = "Home";
                                if (_this.modelInput.Company != "" && _this.modelInput.Company != undefined && _this.modelInput.Company != null) {
                                    comptext = "Work";
                                }
                                jQuery.each(_this._AddressTypes, function () {
                                    if (this.Text == comptext) {
                                        adid = this.Value;
                                        return false;
                                    }
                                });
                                _this.modelInput.CustomerAddresses = [{ Street: "", Street2: "", CityName: "", Zip: "", CountryCode: ccode, StateId: "", AddressTypeId: adid, ForDelivery: false, MainAddress: false, MainOrder: "MainAddr1", DelvryOrder: "Delvry1" }];
                            }
                            else {
                                var count = 1;
                                jQuery.each(_this.modelInput.CustomerAddresses, function () {
                                    this.MainOrder = "MainAddr" + count;
                                    this.DelvryOrder = "Delvry" + count++;
                                });
                            }
                            //var treeview = jQuery("#groupTree").data("kendoTreeView");
                            //var bar = treeview.findById("Bar");
                            //jQuery.each(this.modelInput.CustomerGroups, function () {
                            //    var data = jQuery("#groupTree").data("kendoTreeView").dataSource.getByUid(this.CustomerGeneralGroupId);
                            //    if (data) {
                            //        data.set("checked", true);
                            //    }
                            //    //var GroupNode = treeview.findById(this.CustomerGeneralGroupId);
                            //    //treeview.dataItem(GroupNode).set("checked", true);
                            //});
                            _this.CustIdText = "( " + _this.modelInput.CustomerId + " )";
                            _this.IsFileAstxtShow = false;
                            _this.HideShowFileAstxt();
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this.ClosePopUp();
                    //////For Closing Display Popup/////////////
                    this.IsPopUp = false;
                };
                AmaxCustomers.prototype.CheckPhoneType = function (PhoneObj) {
                    var _this = this;
                    //debugger;
                    //alert(PhoneObj.PhoneTypeId + " | " + jQuery("#PhoneType").val());
                    var pretemp = [];
                    jQuery('select[name^="phtype"]').each(function () {
                        pretemp.push(jQuery(this).val());
                    });
                    var index = 0;
                    jQuery.each(this.modelInput.CustomerPhones, function () {
                        if (this == PhoneObj) {
                            return false;
                        }
                        index = index + 1;
                    });
                    if (pretemp[index] != undefined && pretemp[index] != null && pretemp[index] != "") {
                        var PhoneTypeId = pretemp[index];
                        this._customerService.GetPhoneTypeDet(PhoneTypeId).subscribe(function (data) {
                            //debugger;
                            //
                            var response = jQuery.parseJSON(data);
                            if (response.IsError == true) {
                                bootbox.alert({
                                    message: response.ErrMsg, className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                            else {
                                if (response.Data != undefined && response.Data != null && response.Data != "") {
                                    //debugger;
                                    //alert(index + " | " + this.modelInput.CustomerPhones[index].IsSms + " | " + response.Data.Text);
                                    if (response.Data.Text == "1") {
                                        _this.modelInput.CustomerPhones[index].IsSms = 1;
                                        _this.modelInput.CustomerPhones[index].phpublish = 1;
                                        _this.modelInput.CustomerEmails[_this.modelInput.CustomerEmails.length - 1].publish = 1;
                                    }
                                    else {
                                        _this.modelInput.CustomerPhones[index].phpublish = 0;
                                        _this.modelInput.CustomerPhones[index].IsSms = 0;
                                        _this.modelInput.CustomerEmails[_this.modelInput.CustomerEmails.length - 1].publish = 0;
                                    }
                                }
                            }
                            //var treeviewDataSource = jQuery("#groupTree").data("kendoTreeView").dataSource.view();
                        }, function (err) {
                        }, function () {
                        });
                    }
                };
                AmaxCustomers.prototype.editEmailDet = function (EmailObj) {
                    //debugger;
                    var index = 0;
                    this.IsRecordEditMode = true;
                    this.BTN_PHADD = this.RES.CUSTOMER_MASTER.APP_BTN_PHEDIT;
                    this.EmailModel.Email = EmailObj.Email;
                    this.EmailModel.EmailName = EmailObj.EmailName;
                    this.EmailModel.Newslettere = EmailObj.Newslettere;
                    this.EditEmailData = {};
                    this.EditEmailData = EmailObj;
                };
                AmaxCustomers.prototype.delEmailDet = function (EmailObj) {
                    //debugger;
                    if (this.modelInput.CustomerEmails.length > 1) {
                        var index = 0;
                        jQuery.each(this.modelInput.CustomerEmails, function () {
                            if (this == EmailObj) {
                                return false;
                            }
                            index = index + 1;
                        });
                        this.modelInput.CustomerEmails.splice(index, 1);
                    }
                };
                AmaxCustomers.prototype.editAddressDet = function (AddressObj) {
                    //debugger;
                    var index = 0;
                    this.IsRecordEditMode = true;
                    this.BTN_PHADD = this.RES.CUSTOMER_MASTER.APP_BTN_PHEDIT;
                    // AddressObj.CityName = jQuery("#City").val();
                    this.Address.Street = AddressObj.Street;
                    this.Address.Street2 = AddressObj.Street2;
                    this.Address.CityName = AddressObj.CityName;
                    this.Address.Zip = AddressObj.Zip;
                    this.Address.CountryCode = AddressObj.CountryCode;
                    this.Address.StateId = AddressObj.StateId;
                    this.Address.AddressTypeId = AddressObj.AddressTypeId;
                    this.Address.MainAddress = AddressObj.MainAddress;
                    this.Address.ForDelivery = AddressObj.ForDelivery;
                    this.EditAddressData = {};
                    this.EditAddressData = AddressObj;
                };
                AmaxCustomers.prototype.delAddressDet = function (AddressObj) {
                    // debugger; 
                    if (this.modelInput.CustomerAddresses > 1) {
                        var index = 0;
                        jQuery.each(this.modelInput.CustomerAddresses, function () {
                            if (this == AddressObj) {
                                return false;
                            }
                            index = index + 1;
                        });
                        this.modelInput.CustomerAddresses.splice(index, 1);
                    }
                };
                AmaxCustomers.prototype.editPhoneDet = function (PhoneObj) {
                    var index = 0;
                    this.BTN_PHADD = this.RES.CUSTOMER_MASTER.APP_BTN_PHEDIT;
                    var temp = PhoneObj.PhoneTypeId.split(';');
                    this.PhoneModel.PhoneTypeId = PhoneObj.PhoneType + ";" + PhoneObj.PhoneTypeId;
                    this.PhoneModel.PhoneType = PhoneObj.PhoneType;
                    this.PhoneModel.Prefix = PhoneObj.Prefix;
                    this.PhoneModel.Area = PhoneObj.Area;
                    this.PhoneModel.Phone = PhoneObj.Phone;
                    this.PhoneModel.IsSms = PhoneObj.IsSms;
                    this.PhoneModel.Comments = PhoneObj.Comments;
                    this.EditPhoneData = {};
                    this.EditPhoneData = PhoneObj;
                };
                AmaxCustomers.prototype.delPhoneDet = function (PhoneObj) {
                    // debugger;
                    if (this.modelInput.CustomerPhones.length > 1) {
                        var index = 0;
                        jQuery.each(this.modelInput.CustomerPhones, function () {
                            if (this == PhoneObj) {
                                return false;
                            }
                            index = index + 1;
                        });
                        this.modelInput.CustomerPhones.splice(index, 1);
                    }
                };
                AmaxCustomers.prototype.getSelectedGroups = function () {
                    this.modelInput.CustomerGroups = [];
                    var _CheckedGroups = [];
                    if (this.IsShowAll == false) {
                        amaxUtil_1.Kendo_utility.checkedNodeIds(jQuery("#groupTree").data("kendoTreeView").dataSource.view(), _CheckedGroups);
                    }
                    else {
                        amaxUtil_1.Kendo_utility.checkedNodeIds(jQuery("#groupTree1").data("kendoTreeView").dataSource.view(), _CheckedGroups);
                    }
                    for (var i = 0; i < _CheckedGroups.length; i++) {
                        var GObj = {};
                        GObj.CustomerGeneralGroupId = _CheckedGroups[i];
                        this.modelInput.CustomerGroups.push(GObj);
                    }
                };
                AmaxCustomers.prototype.More = function () {
                    // alert("call");
                    if (this.ShowMore == true) {
                        this.ShowMore = false;
                        //this.ShowMoreText = "More";
                        this.ShowMoreText = this.RES.CUSTOMER_MASTER.APP_LNK_LBL_MORE;
                    }
                    else {
                        this.ShowMore = true;
                        //this.ShowMoreText = "Less"; 
                        this.ShowMoreText = this.RES.CUSTOMER_MASTER.APP_LNK_LBL_LESS;
                    }
                    this.BindCustTitles();
                };
                AmaxCustomers.prototype.bindGroupTree = function (Isshowall) {
                    var _this = this;
                    this._customerService.GetGeneralGroups(Isshowall).subscribe(function (data) {
                        //debugger;
                        //
                        //alert(Isshowall);
                        if (Isshowall == false) {
                            jQuery("#groupTree").html("Loding...");
                            var res = jQuery.parseJSON(data).Data;
                            jQuery("#groupTree").kendoTreeView({
                                loadOnDemand: true,
                                checkboxes: {
                                    checkChildren: true
                                },
                                //check: this.onGroupSelect,
                                dataSource: res
                            });
                            var grpids = "";
                            jQuery.each(_this.modelInput.CustomerGroups, function () {
                                grpids += this.CustomerGeneralGroupId + ";";
                            });
                            if (grpids.length > 0) {
                                amaxUtil_1.Kendo_utility.checkingNodeIds(jQuery("#groupTree").data("kendoTreeView").dataSource.view(), grpids.substring(0, grpids.length - 1));
                            }
                        }
                        else {
                            jQuery("#groupTree1").html("Loding...");
                            var res = jQuery.parseJSON(data).Data;
                            jQuery("#groupTree1").kendoTreeView({
                                loadOnDemand: true,
                                checkboxes: {
                                    checkChildren: true
                                },
                                //check: this.onGroupSelect,
                                dataSource: res
                            });
                            var grpids = "";
                            jQuery.each(_this.modelInput.CustomerGroups, function () {
                                grpids += this.CustomerGeneralGroupId + ";";
                            });
                            if (grpids.length > 0) {
                                amaxUtil_1.Kendo_utility.checkingNodeIds(jQuery("#groupTree1").data("kendoTreeView").dataSource.view(), grpids.substring(0, grpids.length - 1));
                            }
                        }
                        //var treeviewDataSource = jQuery("#groupTree").data("kendoTreeView").dataSource.view();
                    }, function (err) {
                    }, function () {
                    });
                };
                AmaxCustomers.prototype.GetDataForSearch = function (event) {
                    //this.SearchVal = jQuery("#Searchtxt").val();
                    //alert(event.keyCode);
                    //if (this.SearchVal != undefined && this.SearchVal != "" && this.SearchVal != null && event.keyCode == 13) {
                    //alert(this.autocompleteSelect + " " + this.autocompleteNoResults);
                    //    this.EnterCount++;
                    //    if (this.EnterCount >= 2) {
                    //        this._customerService.GetCompleteSearch(this.SearchVal).subscribe(response=> {
                    //            response = jQuery.parseJSON(response);
                    //            if (response.IsError == true) {
                    //                alert(response.ErrMsg);
                    //            }
                    //            else {
                    //                this.CustList = {};
                    //                this.CustList = response.Data;
                    //                if (response.Data != null && response.Data != undefined) {
                    //                    this.custSearchData = response.Data;
                    //                    jQuery("#CustModal").modal("show");
                    //                }
                    //            }
                    //        }, error=> {
                    //            console.log(error);
                    //        }, () => {
                    //            console.log("CallCompleted")
                    //        });
                    //        this.EnterCount = 0;
                    //    }
                    //}
                    //this.SearchVal = "";
                };
                AmaxCustomers.prototype.BindCustTitles = function () {
                    var _this = this;
                    this._customerService.GetCustTitles().subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            var titletypeaheadSource = [];
                            jQuery.each(response.Data, function () {
                                var newtemp = {};
                                newtemp.id = this.Value;
                                newtemp.name = this.Text;
                                titletypeaheadSource.push(newtemp);
                            });
                            _this._CustTitles = response.Data;
                            jQuery("#Title").typeahead({
                                //data: this._Cities,
                                source: titletypeaheadSource,
                                //display: "text",
                                dataType: "JSON",
                            });
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxCustomers.prototype.ngOnInit = function () {
                    var _this = this;
                    jQuery(".lean-overlay").css({ "display": "none" });
                    this.BindCustTitles();
                    // debugger;
                    //bootbox.alert("This is the default alert!");
                    if (localStorage.getItem("lang") == "") {
                        localStorage.setItem("lang", "en");
                    }
                    if (this._resourceService.getCookie("lang") == "") {
                        this._resourceService.setCookie("lang", "en", 10);
                    }
                    this.IsCancel = false;
                    this.showhideGroups();
                    this.IsFileAstxtShow = true;
                    //this.modelInput.CustomerId = -1;
                    if (this.modelInput.CustomerId >= 0) {
                        //this.IsFileAstxtShow = false;
                        this.editCustDet(this.modelInput);
                        this.SAVE_BTN_TEXT = this.RES.CUSTOMER_MASTER.APP_BTN_UPDATE;
                        //this.ADD_NEW_CUST_TEXT = this.RES.CUSTOMER_MASTER.APP_LBL_UPDATE_CUST;
                        //this.CSSTEXT = "mdi-content-add";
                        if (this.modelInput.CustomerAddresses.length == 0) {
                            var empid = localStorage.getItem("employeeid");
                            var ccode = this._resourceService.getCookie(empid + "ccode");
                            if (ccode.length > 0)
                                ccode = ccode.substring(1, ccode.length);
                            var adid = "";
                            var comptext = "Home";
                            if (this.modelInput.Company != "" && this.modelInput.Company != undefined && this.modelInput.Company != null) {
                                comptext = "Work";
                            }
                            jQuery.each(this._AddressTypes, function () {
                                if (this.Text == comptext) {
                                    adid = this.Value;
                                    return false;
                                }
                            });
                            this.modelInput.CustomerAddresses = [{ Street: "", Street2: "", CityName: "", Zip: "", CountryCode: ccode, StateId: "", AddressTypeId: adid, ForDelivery: false, MainAddress: false, MainOrder: "MainAddr1", DelvryOrder: "Delvry1" }];
                        }
                        this.CustIdText = "( " + this.modelInput.CustomerId + " )";
                        this.IsFileAstxtShow = false;
                    }
                    this.Lang = this._resourceService.getCookie("lang");
                    if (this.Lang.length > 0) {
                        this.Lang = this.Lang.substring(1, this.Lang.length);
                    }
                    this.HideShowFileAstxt();
                    //this.RES = jQuery.parseJSON(this._customerService.GetLangRes(this.Formtype, this.Lang)).Data; //jQuery.parseJSON(localStorage.getItem("langresource"));
                    if (this.Lang == "he") {
                        this.KendoRTLCSS = "k-rtl";
                        this.CHANGEDIR = "rtlmodal";
                        this.ChangeDialog = "input_right";
                    }
                    else {
                        this.CHANGEDIR = "ltrmodal";
                        this.ChangeDialog = "input_left";
                    }
                    this._resourceService.GetLangRes(this.Formtype, this.Lang).subscribe(function (response) {
                        //debugger;
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.RES = response.Data;
                            _this.ShowMoreText = _this.RES.CUSTOMER_MASTER.APP_LNK_LBL_MORE;
                            _this.GroupText = _this.RES.CUSTOMER_MASTER.APP_LBL_SHOWGROUPS;
                            _this.SAVE_BTN_TEXT = _this.RES.CUSTOMER_MASTER.APP_BTN_SAVE;
                            _this.ADD_NEW_CUST_TEXT = _this.RES.CUSTOMER_MASTER.APP_LBL_NEW_CUST;
                            _this.FILEAS_BTN_TEXT = _this.RES.CUSTOMER_MASTER.APP_BTN_FILEAS;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //this.ShowMoreText = "More";
                    ////Cities
                    var CountryCode = this.Address.CountryCode;
                    var StateName = this.Address.StateId;
                    this._customerService.GetCities(CountryCode, StateName).subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            var typeaheadSource = [];
                            jQuery.each(response.Data, function () {
                                var newtemp = {};
                                newtemp.id = this.Value;
                                newtemp.name = this.Text;
                                typeaheadSource.push(newtemp);
                            });
                            _this._Cities = response.Data;
                            jQuery('#City').typeahead({
                                //data: this._Cities,
                                source: typeaheadSource,
                                //display: "text",
                                dataType: "JSON",
                            });
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this.languageArray = this._resourceService.GetAvailableLanguages();
                    this._customerService.GetCustomerTypes().subscribe(function (resp) {
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._CustTypes = response.Data;
                            if (_this.modelInput.CustomerType == "" || _this.modelInput.CustomerType == undefined || _this.modelInput.CustomerType == null) {
                                var CusttypeId;
                                jQuery.each(_this._CustTypes, function () {
                                    CusttypeId = this.Value;
                                    return false;
                                });
                                _this.modelInput.CustomerType = CusttypeId;
                            }
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    ////Sources
                    this._customerService.GetSources().subscribe(function (resp) {
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Sources = response.Data;
                            if (_this.modelInput.CameFromCustomer == "" || _this.modelInput.CameFromCustomer == undefined || _this.modelInput.CameFromCustomer == null) {
                                var Source;
                                jQuery.each(_this._Sources, function () {
                                    Source = this.Value;
                                    return false;
                                });
                                _this.modelInput.CameFromCustomer = Source;
                            }
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //GetEmployees
                    this._customerService.GetEmployees().subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Employees = response.Data;
                            if (_this.modelInput.employeeid == "" || _this.modelInput.employeeid == undefined || _this.modelInput.employeeid == null) {
                                var empid;
                                jQuery.each(_this._Employees, function () {
                                    empid = this.Value;
                                    return false;
                                });
                                _this.modelInput.employeeid = empid;
                            }
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //GetSuffixes
                    this._customerService.GetSuffixes().subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Suffixes = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //GetPhoneTypes
                    this._customerService.GetPhoneTypes().subscribe(function (response) {
                        // debugger;
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._PhoneTypes = response.Data;
                            var phid = "";
                            jQuery.each(_this._PhoneTypes, function () {
                                if (this.Text == "CellPhone") {
                                    phid = this.Value;
                                    return false;
                                }
                            });
                            _this.modelInput.CustomerPhones[0].PhoneTypeId = phid;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    var epublish = 0;
                    if (this.modelInput.CustomerPhones.length == 0) {
                        var phid = "";
                        jQuery.each(this._PhoneTypes, function () {
                            if (this.Text == "CellPhone") {
                                phid = this.Value;
                                epublish = 1;
                                return false;
                            }
                        });
                        this.modelInput.CustomerPhones = [{ PhoneTypeId: phid, Prefix: "", Area: "", Phone: "", IsSms: epublish, Comments: "", phpublish: epublish, SMSOrder: "SMS1", PublishOrder: "Pub1" }];
                    }
                    if (this.modelInput.CustomerEmails.length == 0) {
                        this.modelInput.CustomerEmails = [{ Email: "", EmailName: this.modelInput.FileAs, Newslettere: false, publish: epublish, NewsOrder: "News1", EPublishOrder: "EPub1" }];
                    }
                    //GetAddressTypes
                    this._customerService.GetAddressTypes().subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._AddressTypes = response.Data;
                            // debugger;
                            var adid = "";
                            jQuery.each(_this._AddressTypes, function () {
                                if (this.Text == "Home") {
                                    adid = this.Value;
                                    return false;
                                }
                            });
                            _this.modelInput.CustomerAddresses[0].AddressTypeId = adid;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //Groups
                    this._customerService.GetGroups().subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Groups = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    ////Countries
                    this._customerService.GetCountries().subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Countries = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    ////States
                    var CountryCode = this.Address.CountryCode;
                    this._customerService.GetStates(CountryCode).subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._States = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //Tree Group
                    //this.bindGroupTree(this.IsShowAll);
                    this._customerService.GetGeneralGroups(this.IsShowAll).subscribe(function (data) {
                        // debugger;
                        if (_this.IsShowAll == false) {
                            jQuery("#groupTree").html("Loding...");
                            var res = jQuery.parseJSON(data).Data;
                            jQuery("#groupTree").kendoTreeView({
                                loadOnDemand: true,
                                checkboxes: {
                                    checkChildren: true
                                },
                                //check: this.onGroupSelect,
                                dataSource: res
                            });
                            var grpids = "";
                            jQuery.each(_this.modelInput.CustomerGroups, function () {
                                grpids += this.CustomerGeneralGroupId + ";";
                            });
                            if (grpids.length > 0) {
                                amaxUtil_1.Kendo_utility.checkingNodeIds(jQuery("#groupTree").data("kendoTreeView").dataSource.view(), grpids.substring(0, grpids.length - 1));
                            }
                        }
                        else {
                            jQuery("#groupTree1").html("Loding...");
                            var res = jQuery.parseJSON(data).Data;
                            jQuery("#groupTree1").kendoTreeView({
                                loadOnDemand: true,
                                checkboxes: {
                                    checkChildren: true
                                },
                                //check: this.onGroupSelect,
                                dataSource: res
                            });
                            var grpids = "";
                            jQuery.each(_this.modelInput.CustomerGroups, function () {
                                grpids += this.CustomerGeneralGroupId + ";";
                            });
                            if (grpids.length > 0) {
                                amaxUtil_1.Kendo_utility.checkingNodeIds(jQuery("#groupTree1").data("kendoTreeView").dataSource.view(), grpids.substring(0, grpids.length - 1));
                            }
                        }
                    }, function (err) {
                    }, function () {
                    });
                    //alert(moment().format('D MMM YYYY'));       
                    // this.baseUrl + "Dropdown/BindAutoCompleteSrch"
                    var SrchData = null;
                    //alert('Hi');
                    jQuery("#EmailTable tbody tr td a[name=delEbtn]").not(":last").hide();
                    jQuery("#EmailTable tbody tr a[name=addEbtn]").not(":last").show();
                    //$('.modal').modal();
                };
                AmaxCustomers.$inject = ['$scope', '$location', '$anchorScroll'];
                AmaxCustomers = __decorate([
                    core_1.Component({
                        templateUrl: './app/amax/Customer/templates/customer.html',
                        directives: [common_1.NgSwitch, common_1.NgSwitchWhen, common_1.NgSwitchDefault, AUTOCOMPLETE_DIRECTIVES, common_1.CORE_DIRECTIVES, common_1.FORM_DIRECTIVES, basicComponents_1.AmaxDate],
                        providers: [CustomerService_1.CustomerService, ResourceService_1.ResourceService]
                    }), 
                    __metadata('design:paramtypes', [ResourceService_1.ResourceService, CustomerService_1.CustomerService, router_1.RouteParams])
                ], AmaxCustomers);
                return AmaxCustomers;
            }());
            exports_1("AmaxCustomers", AmaxCustomers);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFtYXgvQ3VzdG9tZXIvQ3VzdG9tZXJQcm9maWxlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7UUFXYSx1QkFBdUI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7WUFBdkIscUNBQUEsdUJBQXVCLEdBQUcsQ0FBQyxxQ0FBWSxFQUFFLDhDQUFxQixDQUFDLENBQUEsQ0FBQztZQVk3RTtnQkFxRkksdUJBQW9CLGdCQUFpQyxFQUFVLGdCQUFpQyxFQUFVLFlBQXlCO29CQUEvRyxxQkFBZ0IsR0FBaEIsZ0JBQWdCLENBQWlCO29CQUFVLHFCQUFnQixHQUFoQixnQkFBZ0IsQ0FBaUI7b0JBQVUsaUJBQVksR0FBWixZQUFZLENBQWE7b0JBcEZuSSxlQUFVLEdBQUcsRUFBRSxDQUFDO29CQUNoQixtQkFBYyxHQUFHLEVBQUUsQ0FBQztvQkFDcEIsbUJBQWMsR0FBVyxFQUFFLENBQUM7b0JBQzVCLFFBQUcsR0FBVyxFQUFFLENBQUM7b0JBQ2pCLG1CQUFjLEdBQVcsRUFBRSxDQUFDO29CQUM1QixrQkFBYSxHQUFXLEVBQUUsQ0FBQztvQkFDM0IsYUFBUSxHQUFVLGlCQUFpQixDQUFDO29CQUNwQyxTQUFJLEdBQVMsRUFBRSxDQUFDO29CQUNoQix1QkFBdUI7b0JBQ3ZCLGFBQVEsR0FBWSxLQUFLLENBQUM7b0JBQzFCLHFCQUFnQixHQUFZLEtBQUssQ0FBQztvQkFDbEMsaUJBQVksR0FBVyxNQUFNLENBQUM7b0JBRTlCLGVBQVUsR0FBWSxLQUFLLENBQUM7b0JBQzVCLFlBQU8sR0FBWSxLQUFLLENBQUM7b0JBQ3pCLGVBQVUsR0FBWSxJQUFJLENBQUM7b0JBQzNCLGNBQVMsR0FBUyxhQUFhLENBQUM7b0JBQ2hDLFFBQUcsR0FBVyxFQUFFLENBQUM7b0JBQ2pCLGFBQVEsR0FBVyxjQUFjLENBQUM7b0JBQ2xDLGlCQUFZLEdBQVcsRUFBRSxDQUFDO29CQUMxQixvQkFBZSxHQUFXLEVBQUUsQ0FBQztvQkFDN0Isc0JBQWlCLEdBQVcsRUFBRSxDQUFDO29CQUMvQixrQkFBYSxHQUFHLEVBQUUsQ0FBQztvQkFFbkIsWUFBTyxHQUFXLEVBQUUsQ0FBQztvQkFDckIsZUFBVSxHQUFXLEVBQUUsQ0FBQztvQkFDeEIsZUFBVSxHQUFXLEVBQUUsQ0FBQztvQkFDeEIsY0FBUyxHQUFZLEtBQUssQ0FBQztvQkFDM0IsYUFBUSxHQUFXLEVBQUUsQ0FBQztvQkFDdEIsa0JBQWEsR0FBVyxFQUFFLENBQUM7b0JBRTNCLGNBQVMsR0FBVyxFQUFFLENBQUM7b0JBQ3ZCLGtCQUFhLEdBQVcsRUFBRSxDQUFDO29CQUMzQixvQkFBZSxHQUFXLEVBQUUsQ0FBQztvQkFDN0Isa0JBQWEsR0FBVyxFQUFFLENBQUM7b0JBSzNCLG9CQUFlLEdBQVksS0FBSyxDQUFDO29CQUNqQyxvQkFBZSxHQUFXLEVBQUUsQ0FBQztvQkFDN0IsaUJBQVksR0FBVyxFQUFFLENBQUM7b0JBQzFCLGFBQVEsR0FBWSxLQUFLLENBQUM7b0JBQzFCLGNBQVMsR0FBVyxFQUFFLENBQUM7b0JBQ3ZCLGVBQVUsR0FBVyxDQUFDLENBQUM7b0JBRXZCLGVBQVUsR0FBVyxFQUFFLENBQUM7b0JBRXhCLGVBQVUsR0FBVyxFQUFFLENBQUM7b0JBQ3hCLFlBQU8sR0FBVyxDQUFDLENBQUM7b0JBQ3BCLGdCQUFXLEdBQVcsRUFBRSxDQUFDO29CQUN6QixjQUFTLEdBQVcsRUFBRSxDQUFDO29CQUN2QixpQkFBWSxHQUFXLEVBQUUsQ0FBQztvQkFDMUIsWUFBTyxHQUFZLElBQUksQ0FBQztvQkFJeEIsZ0NBQWdDO29CQUVoQyxxQkFBcUI7b0JBQ3JCLDZCQUE2QjtvQkFDN0IsaUNBQWlDO29CQUVqQyxlQUFVLEdBQUcsRUFBRSxDQUFDO29CQUNoQixhQUFRLEdBQUcsRUFBRSxDQUFDO29CQUNkLGVBQVUsR0FBRyxFQUFFLENBQUM7b0JBQ2hCLGNBQVMsR0FBRyxFQUFFLENBQUM7b0JBQ2YsZ0JBQVcsR0FBRyxFQUFFLENBQUM7b0JBQ2pCLGtCQUFhLEdBQUcsRUFBRSxDQUFDO29CQUNuQixZQUFPLEdBQUcsRUFBRSxDQUFDO29CQUNiLGVBQVUsR0FBRyxFQUFFLENBQUM7b0JBQ2hCLFlBQU8sR0FBRyxFQUFFLENBQUM7b0JBQ2IsWUFBTyxHQUFHLEVBQUUsQ0FBQztvQkFDYixnQkFBVyxHQUFHLEVBQUUsQ0FBQztvQkFDVCxnQkFBVyxHQUFXLEVBQUUsQ0FBQztvQkFDekIscUJBQWdCLEdBQVcsRUFBRSxDQUFDO29CQUM5Qix3QkFBbUIsR0FBWSxLQUFLLENBQUM7b0JBQ3JDLDBCQUFxQixHQUFZLEtBQUssQ0FBQztvQkFDdkMsdUJBQWtCLEdBQVksS0FBSyxDQUFDO29CQTRFcEMsOEJBQXlCLEdBQVMsRUFBRSxDQUFDO29CQXBFekMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEdBQUcsRUFBRSxDQUFDO29CQUMvQixJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixHQUFHLEVBQUUsQ0FBQztvQkFDdkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDO29CQUNwQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxFQUFFLENBQUM7b0JBQ3BDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLEVBQUUsQ0FBQztvQkFDcEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEdBQUMsRUFBRSxDQUFDO29CQUM1QixJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7b0JBQzFCLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztvQkFDaEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEdBQUcsRUFBRSxDQUFDO29CQUNsQyxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixHQUFHLEVBQUUsQ0FBQztvQkFDdEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEdBQUcsRUFBRSxDQUFDO29CQUM3QixJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxHQUFHLENBQUM7b0JBQzdCLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxHQUFHLEVBQUUsQ0FBQztvQkFDakMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLEdBQUcsRUFBRSxDQUFDO29CQUM5QixJQUFJLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQztvQkFDdkIsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUM7b0JBQzNELElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsYUFBYSxDQUFDO29CQUN4RCxJQUFJLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsZ0JBQWdCLENBQUM7b0JBQ25FLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLENBQUMsRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFFLFNBQVMsRUFBRSxFQUFFLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFFLFNBQVMsRUFBRSxPQUFPLEVBQUUsYUFBYSxFQUFDLE9BQU8sRUFBRSxDQUFDLENBQUE7b0JBQ3pJLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLENBQUMsRUFBRSxXQUFXLEVBQUUsRUFBRSxFQUFFLE1BQU0sRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUUsUUFBUSxFQUFFLEVBQUUsRUFBRSxhQUFhLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxDQUFDLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBQyxZQUFZLEVBQUUsTUFBTSxFQUFDLENBQUMsQ0FBQTtvQkFDMUwsWUFBWTtvQkFDWCxJQUFJLEtBQUssR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDO29CQUUvQyxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxPQUFPLENBQUMsQ0FBQztvQkFDN0QsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7d0JBQ2pCLEtBQUssR0FBRyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBRTdDLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLEdBQUcsQ0FBQzs0QkFDakMsTUFBTSxFQUFFLEVBQUUsRUFBRSxPQUFPLEVBQUUsRUFBRSxFQUFFLFFBQVEsRUFBRSxFQUFFLEVBQUUsR0FBRyxFQUFFLEVBQUUsRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLE9BQU8sRUFBRSxFQUFFLEVBQUUsYUFBYSxFQUFFLEVBQUU7NEJBQ2xHLFdBQVcsRUFBRSxJQUFJLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUUsV0FBVyxFQUFFLFdBQVcsRUFBRSxTQUFTO3lCQUN2RixDQUFDLENBQUE7b0JBS0YsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsTUFBTSxDQUFDLENBQUM7b0JBQy9ELEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFFdEIsUUFBUSxHQUFHLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDdEQsQ0FBQztvQkFDRCxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksR0FBRyxRQUFRLENBQUM7b0JBR3hDLElBQUksR0FBRyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQyxDQUFDO29CQUN6RCxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQzt3QkFDZixHQUFHLEdBQUcsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUN2QyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBRyxHQUFHLENBQUM7b0JBRWpDLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQyxDQUFDO29CQUM1RCxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQzt3QkFDbEIsTUFBTSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDaEQsSUFBSSxDQUFDLENBQUM7b0JBRU4sQ0FBQztvQkFDRCxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixHQUFHLE1BQU0sQ0FBQztvQkFDMUMsSUFBSSxDQUFDLE9BQU8sR0FBRyxpQkFBaUIsQ0FBQztvQkFDakMsSUFBSSxDQUFDLFlBQVksR0FBRyxvQkFBb0IsQ0FBQztvQkFDekMsSUFBSSxDQUFDLGVBQWUsR0FBRyxLQUFLLENBQUM7b0JBQzdCLFlBQVksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7b0JBQy9CLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLFlBQVksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO29CQUNwRCxJQUFJLENBQUMsVUFBVSxHQUFHLGdCQUFnQixDQUFDLE1BQU0sQ0FBQztvQkFDMUMsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDO29CQUV0Qyx5REFBeUQ7b0JBQ3pELDZCQUE2QjtnQkFFakMsQ0FBQztnQkF4RU8seUNBQWlCLEdBQXpCO29CQUVJLE1BQU0sQ0FBQyxJQUFJLENBQUM7Z0JBQ2hCLENBQUM7Z0JBeUVELDJDQUFtQixHQUFuQixVQUFvQixHQUFHO29CQUNuQixPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUNqQixJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsR0FBRyxHQUFHLENBQUM7b0JBQ2pDLG9DQUFvQztvQkFDbkMsdUJBQXVCO2dCQUMzQixDQUFDO2dCQUVNLG9DQUFZLEdBQXBCLFVBQXFCLE9BQVk7b0JBQWpDLGlCQXNERTtvQkFwREUsSUFBSSxPQUFPLEdBQUcsT0FBTyxDQUFDLGdCQUFnQixDQUFDO29CQUV4QyxrRUFBa0U7b0JBRy9ELFlBQVk7b0JBQ2QsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLHlCQUF5QixJQUFJLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUM7d0JBQ3pELGlDQUFpQzt3QkFDakMsTUFBTSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUM7b0JBQzlCLENBQUM7b0JBQ0wsSUFBSSxDQUFDLENBQUM7d0JBQ0YsMkVBQTJFO3dCQUN2RSxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzs0QkFDakMsSUFBSSxDQUFDLHlCQUF5QixHQUFHLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQzs0QkFDNUQseUNBQXlDOzRCQUN2QyxxQkFBcUI7NEJBQ2pCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO2dDQUNoRSxZQUFZO2dDQUNYLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dDQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7b0NBQzNCLHlCQUF5QjtvQ0FDekIsT0FBTyxDQUFDLEtBQUssQ0FBQyxFQUFDLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTt3Q0FDdEMsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO3dDQUN6QixPQUFPLEVBQUU7NENBQ0wsRUFBRSxFQUFFO2dEQUNBLGNBQWM7Z0RBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTOzZDQUM1Qjt5Q0FDSjtxQ0FDSixDQUFDLENBQUM7Z0NBQ1AsQ0FBQztnQ0FDRCxJQUFJLENBQUMsQ0FBQztvQ0FDRixPQUFPLENBQUMsWUFBWSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7Z0NBR3pDLENBQUM7NEJBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSztnQ0FDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDOzRCQUN2QixDQUFDLEVBQUU7Z0NBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTs0QkFDaEMsQ0FBQyxDQUFDLENBQUM7NEJBQ1IsV0FBVzs0QkFFVixJQUFJLENBQUMsYUFBYSxHQUFHLE9BQU8sQ0FBQyxZQUFZLENBQUM7d0JBQzlDLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsSUFBSSxDQUFDLGFBQWEsR0FBRyxFQUFFLENBQUM7d0JBQzVCLENBQUM7d0JBQ0QsTUFBTSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUM7b0JBQzlCLENBQUM7Z0JBR1IsQ0FBQztnQkFFTyxpREFBeUIsR0FBakMsVUFBa0MsQ0FBVTtvQkFDeEMsSUFBSSxDQUFDLG1CQUFtQixHQUFHLENBQUMsQ0FBQztnQkFDakMsQ0FBQztnQkFFTyxtREFBMkIsR0FBbkMsVUFBb0MsQ0FBVTtvQkFDMUMsSUFBSSxDQUFDLGtCQUFrQixHQUFHLEtBQUssQ0FBQztvQkFDaEMsSUFBSSxDQUFDLHFCQUFxQixHQUFHLENBQUMsQ0FBQztnQkFDbkMsQ0FBQztnQkFDTyw0Q0FBb0IsR0FBNUIsVUFBNkIsQ0FBTTtvQkFBbkMsaUJBOEZDO29CQTdGRyxJQUFJLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDO29CQUMvQixPQUFPLENBQUMsR0FBRyxDQUFDLHFCQUFtQixDQUFDLENBQUMsSUFBTSxDQUFDLENBQUM7b0JBQ3pDLElBQUksUUFBUSxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUNsQyxZQUFZO29CQUNYLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksU0FBUyxJQUFJLENBQUMsQ0FBQyxJQUFJLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzt3QkFDeEQscUJBQXFCO3dCQUNyQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsa0JBQWtCLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTs0QkFDM0UsV0FBVzs0QkFDWCxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzs0QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO2dDQUMzQix5QkFBeUI7Z0NBQ3pCLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBQyxPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07b0NBQ25DLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtvQ0FDNUIsT0FBTyxFQUFFO3dDQUNMLEVBQUUsRUFBRTs0Q0FDQSxjQUFjOzRDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUzt5Q0FDNUI7cUNBQ0o7aUNBQ0osQ0FBQyxDQUFDOzRCQUNQLENBQUM7NEJBQ0QsSUFBSSxDQUFDLENBQUM7Z0NBQ0YsS0FBSSxDQUFDLFVBQVUsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO2dDQUNqQyxvQ0FBb0M7Z0NBQ25DLEtBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsY0FBYyxDQUFDO2dDQUM3RCxLQUFJLENBQUMsaUJBQWlCLEdBQUcsS0FBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsZ0JBQWdCLENBQUM7Z0NBQ25FLEtBQUksQ0FBQyxPQUFPLEdBQUcsb0JBQW9CLENBQUM7Z0NBQ3BDLEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO29DQUM3QyxLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxDQUFDLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsS0FBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUE7Z0NBQzNHLENBQUM7Z0NBQ0QsSUFBSSxDQUFDLENBQUM7b0NBQ0YsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRTt3Q0FDeEMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsSUFBSSxHQUFHLENBQUMsQ0FBQyxDQUFDOzRDQUUxQixJQUFJLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQzt3Q0FFN0IsQ0FBQzt3Q0FDRCxJQUFJLENBQUMsQ0FBQzs0Q0FDRixJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQzt3Q0FDNUIsQ0FBQztvQ0FDTCxDQUFDLENBQUMsQ0FBQztnQ0FDUCxDQUFDO2dDQUNELEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO29DQUM3QyxJQUFJLElBQUksR0FBRyxFQUFFLENBQUM7b0NBQ2QsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsV0FBVyxFQUFFO3dDQUMxQixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLFdBQVcsQ0FBQyxDQUFDLENBQUM7NENBRTNCLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDOzRDQUNsQixNQUFNLENBQUMsS0FBSyxDQUFDO3dDQUNqQixDQUFDO29DQUNMLENBQUMsQ0FBQyxDQUFDO29DQUVILEtBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLENBQUMsRUFBRSxXQUFXLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUUsUUFBUSxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztnQ0FHcEksQ0FBQztnQ0FDRCxFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO29DQUNoRCxJQUFJLEtBQUssR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDO29DQUUvQyxJQUFJLEtBQUssR0FBRyxLQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxPQUFPLENBQUMsQ0FBQztvQ0FDN0QsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7d0NBQ2pCLEtBQUssR0FBRyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7b0NBQzdDLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQztvQ0FDZCxJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUM7b0NBQ3RCLEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxJQUFJLEVBQUUsSUFBSSxLQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sSUFBSSxTQUFTLElBQUksS0FBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzt3Q0FDM0csUUFBUSxHQUFHLE1BQU0sQ0FBQztvQ0FDdEIsQ0FBQztvQ0FDRCxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUksQ0FBQyxhQUFhLEVBQUU7d0NBQzVCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksUUFBUSxDQUFDLENBQUMsQ0FBQzs0Q0FDeEIsSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7NENBQ2xCLE1BQU0sQ0FBQyxLQUFLLENBQUM7d0NBQ2pCLENBQUM7b0NBQ0wsQ0FBQyxDQUFDLENBQUM7b0NBRUgsS0FBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsR0FBRyxDQUFDLEVBQUUsTUFBTSxFQUFFLEVBQUUsRUFBRSxPQUFPLEVBQUUsRUFBRSxFQUFFLFFBQVEsRUFBRSxFQUFFLEVBQUUsR0FBRyxFQUFFLEVBQUUsRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLE9BQU8sRUFBRSxFQUFFLEVBQUUsYUFBYSxFQUFFLElBQUksRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDO2dDQUMzTCxDQUFDO2dDQUVELEtBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxHQUFHLEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztnQ0FDM0QsS0FBSSxDQUFDLGVBQWUsR0FBRyxLQUFLLENBQUM7Z0NBQzdCLHVCQUF1QjtnQ0FDdkIsMkJBQTJCO2dDQUMzQixLQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7Z0NBQ3ZCLEtBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDO2dDQUN0QixtQkFBbUI7Z0NBQ25CLGtCQUFrQjtnQ0FDbEIsS0FBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsQ0FBQzs0QkFDN0IsQ0FBQzt3QkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLOzRCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7d0JBQ3ZCLENBQUMsRUFBRTs0QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO3dCQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFDUCxDQUFDO2dCQUNMLENBQUM7Z0JBQ0Qsc0NBQWMsR0FBZDtvQkFDSSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDN0csSUFBSSxNQUFNLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUM7d0JBQ3hDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7NEJBQ2YsSUFBSSxJQUFJLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQzs0QkFDOUMsUUFBUSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsVUFBVSxHQUFHLGdCQUFnQixHQUFHLElBQUksR0FBRyxHQUFHLEdBQUcsTUFBTSxDQUFDO3dCQUNqRixDQUFDO29CQUNMLENBQUM7Z0JBQ0wsQ0FBQztnQkFDRCw0Q0FBb0IsR0FBcEI7b0JBQUEsaUJBeUZDO29CQXhGRyxJQUFJLENBQUMsWUFBWSxHQUFHLFVBQVUsQ0FBQztvQkFDL0IsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGlCQUFpQixFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFDeEQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDdEIsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBR3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQ3RELE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCLEVBQUUsRUFBQyxDQUFDLENBQUM7d0JBQ2xCLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsV0FBVzs0QkFDWCxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxJQUFJLFNBQVMsSUFBSSxRQUFRLENBQUMsSUFBSSxJQUFJLElBQUksSUFBSSxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUNuRixJQUFJLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQztnQ0FDaEIsRUFBRSxDQUFDLENBQUMsS0FBSSxDQUFDLGNBQWMsSUFBSSxTQUFTLElBQUksS0FBSSxDQUFDLGNBQWMsQ0FBQyxVQUFVLElBQUksU0FBUyxJQUFJLEtBQUksQ0FBQyxjQUFjLENBQUMsVUFBVSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7b0NBQ3pILE1BQU0sR0FBRyxLQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQTtnQ0FDM0MsQ0FBQztnQ0FDRCxFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsVUFBVSxJQUFJLFNBQVMsSUFBSSxLQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxTQUFTLElBQUksS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztvQ0FDN0csTUFBTSxHQUFHLEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFBO2dDQUN2QyxDQUFDO2dDQUNELEVBQUUsQ0FBQyxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7b0NBQ2YsUUFBUSxDQUFDLFFBQVEsR0FBRyxLQUFJLENBQUMsVUFBVSxHQUFHLGVBQWUsR0FBRyxNQUFNLEdBQUcsR0FBRyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO2dDQUNsRyxDQUFDO2dDQUNELElBQUksQ0FBQyxDQUFDO29DQUVGLE9BQU8sQ0FBQyxLQUFLLENBQUM7d0NBQ1YsT0FBTyxFQUFFLGtGQUFrRjt3Q0FDM0YsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO3dDQUM1QixPQUFPLEVBQUU7NENBQ0wsRUFBRSxFQUFFO2dEQUNBLGNBQWM7Z0RBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTOzZDQUM1Qjt5Q0FFSjtxQ0FDSixDQUFDLENBQUM7Z0NBQ1AsQ0FBQzs0QkFDTCxDQUFDOzRCQUNELElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxJQUFJLFNBQVMsSUFBSSxRQUFRLENBQUMsSUFBSSxJQUFJLElBQUksSUFBSSxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUN2RixXQUFXO2dDQUNYLElBQUksTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDO2dDQUNoQixFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsY0FBYyxJQUFJLFNBQVMsSUFBSSxLQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsSUFBSSxTQUFTLElBQUksS0FBSSxDQUFDLGNBQWMsQ0FBQyxVQUFVLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztvQ0FDekgsTUFBTSxHQUFHLEtBQUksQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFBO2dDQUMzQyxDQUFDO2dDQUNELEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxVQUFVLElBQUksU0FBUyxJQUFJLEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLFNBQVMsSUFBSSxLQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO29DQUM3RyxNQUFNLEdBQUcsS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUE7Z0NBQ3ZDLENBQUM7Z0NBQ0QsRUFBRSxDQUFDLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQ0FDZixRQUFRLENBQUMsUUFBUSxHQUFHLEtBQUksQ0FBQyxVQUFVLEdBQUcsaUJBQWlCLEdBQUcsTUFBTSxDQUFDO2dDQUNyRSxDQUFDO2dDQUNELElBQUksQ0FBQyxDQUFDO29DQUNGLE9BQU8sQ0FBQyxLQUFLLENBQUM7d0NBQ1YsT0FBTyxFQUFFLGtGQUFrRjt3Q0FDM0YsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO3dDQUM1QixPQUFPLEVBQUU7NENBQ0wsRUFBRSxFQUFFO2dEQUNBLGNBQWM7Z0RBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTOzZDQUM1Qjt5Q0FDSjtxQ0FDSixDQUFDLENBQUM7Z0NBQ1AsQ0FBQzs0QkFFTCxDQUFDOzRCQUNELElBQUksQ0FBQyxDQUFDO2dDQUNGLE9BQU8sQ0FBQyxLQUFLLENBQUM7b0NBQ1YsT0FBTyxFQUFFLEtBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLG9CQUFvQjtvQ0FDdEQsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO29DQUM1QixPQUFPLEVBQUU7d0NBQ0wsRUFBRSxFQUFFOzRDQUNBLGNBQWM7NENBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3lDQUM1QixFQUFDO2lDQUNULENBQUMsQ0FBQzs0QkFDUCxDQUFDO3dCQUNMLENBQUM7d0JBQ0QsS0FBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7d0JBQ3BCLEtBQUksQ0FBQyxHQUFHLEdBQUcsUUFBUSxDQUFDLE1BQU0sQ0FBQztvQkFDL0IsQ0FBQyxFQUNHLFVBQUEsS0FBSyxJQUFHLE9BQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBbEIsQ0FBa0IsRUFDMUIsY0FBTSxPQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsc0JBQXNCLENBQUMsRUFBbkMsQ0FBbUMsQ0FDNUMsQ0FBQztvQkFDRixJQUFJLENBQUMsWUFBWSxHQUFHLEVBQUUsQ0FBQztnQkFDM0IsQ0FBQztnQkFDRCxpQ0FBUyxHQUFUO29CQUNJLE9BQU8sQ0FBQyxLQUFLLENBQUM7d0JBQ1YsT0FBTyxFQUFFLGlCQUFpQixHQUFHLElBQUksQ0FBQyxXQUFXLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxZQUFZO3dCQUMzRSxPQUFPLEVBQUU7NEJBQ0wsRUFBRSxFQUFFO2dDQUNBLGNBQWM7Z0NBQ2QsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTOzZCQUM1Qjt5QkFDSjtxQkFDSixDQUFDLENBQUM7b0JBQ0gsWUFBWSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztnQkFDbkMsQ0FBQztnQkFDRCxzQ0FBYyxHQUFkO29CQUFBLGlCQXNIQztvQkFySEcsUUFBUSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsVUFBVSxHQUFHLGlCQUFpQixDQUFDO29CQUN4RCxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQztvQkFDNUIsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7b0JBRXJCLElBQUksS0FBSyxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUM7b0JBQy9DLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxFQUFFLENBQUM7b0JBRTNCLElBQUksQ0FBQyxVQUFVLEdBQUcsRUFBRSxDQUFDO29CQUNyQixJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsR0FBRyxFQUFFLENBQUM7b0JBQy9CLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLENBQUMsQ0FBQyxDQUFDO29CQUNoQyxJQUFJLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztvQkFDckIsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7b0JBQ3pCLElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLE1BQU0sQ0FBQyxDQUFDO29CQUMvRCxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQzt3QkFDcEIsUUFBUSxHQUFHLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDdEQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEdBQUcsUUFBUSxDQUFDO29CQUN4QyxJQUFJLEdBQUcsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUMsQ0FBQztvQkFDekQsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7d0JBQ2YsR0FBRyxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDdkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsR0FBRyxDQUFDO29CQUNqQyxJQUFJLE1BQU0sR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUMsQ0FBQztvQkFDNUQsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7d0JBQ2xCLE1BQU0sR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQ2hELElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLEdBQUcsTUFBTSxDQUFDO29CQUUxQyxJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQztvQkFDdEIsOEJBQThCO29CQUM5QixJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGdCQUFnQixDQUFDO29CQUM5RCxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLFlBQVksQ0FBQztvQkFDM0QsSUFBSSxDQUFDLE9BQU8sR0FBRyxpQkFBaUIsQ0FBQztvQkFDakMsSUFBSSxDQUFDLGlCQUFpQixHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGdCQUFnQixDQUFDO29CQUNuRSxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztvQkFDdkIsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO29CQUN0QiwrREFBK0Q7b0JBSS9ELElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQztvQkFDZCxJQUFJLEdBQUcsR0FBRyxDQUFDLENBQUM7b0JBQ1osSUFBSSxPQUFPLEdBQUcsQ0FBQyxDQUFDO29CQUNoQixJQUFJLFFBQVEsR0FBRyxDQUFDLENBQUM7b0JBQ2pCLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRTt3QkFDMUIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxXQUFXLENBQUMsQ0FBQyxDQUFDOzRCQUUzQixJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQzs0QkFDbEIsR0FBRyxHQUFHLENBQUMsQ0FBQzs0QkFDUixPQUFPLEdBQUcsQ0FBQyxDQUFDOzRCQUNaLFFBQVEsR0FBRyxDQUFDLENBQUM7NEJBQ2IsTUFBTSxDQUFDLEtBQUssQ0FBQzt3QkFDakIsQ0FBQztvQkFDTCxDQUFDLENBQUMsQ0FBQztvQkFFSCxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxDQUFDLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFLFFBQVEsRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFFLE9BQU8sRUFBRSxDQUFDLENBQUE7b0JBQ3ZJLFdBQVc7b0JBRVgsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsQ0FBQyxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFBO29CQUN0RyxJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxPQUFPLENBQUMsQ0FBQztvQkFDakUsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7d0JBQ3JCLFNBQVMsR0FBRyxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBRXpELElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQztvQkFDZCxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUU7d0JBQzVCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksTUFBTSxDQUFDLENBQUMsQ0FBQzs0QkFFdEIsSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7NEJBQ2xCLE1BQU0sQ0FBQyxLQUFLLENBQUM7d0JBQ2pCLENBQUM7b0JBRUwsQ0FBQyxDQUFDLENBQUM7b0JBR0gsSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsR0FBRyxDQUFDLEVBQUUsTUFBTSxFQUFFLEVBQUUsRUFBRSxPQUFPLEVBQUUsRUFBRSxFQUFFLFFBQVEsRUFBRSxFQUFFLEVBQUUsR0FBRyxFQUFFLEVBQUUsRUFBRSxXQUFXLEVBQUUsU0FBUyxFQUFFLE9BQU8sRUFBRSxFQUFFLEVBQUUsYUFBYSxFQUFFLElBQUksRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFBO29CQUMxTCxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxFQUFFLENBQUM7b0JBQ3BDLElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxHQUFHLEVBQUUsQ0FBQztvQkFDOUIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLEdBQUcsRUFBRSxDQUFDO29CQUMxQixJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7b0JBQzdCLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxHQUFHLEdBQUcsQ0FBQztvQkFDN0IsSUFBSSxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7b0JBQ3JCLElBQUksQ0FBQyxHQUFHLEdBQUcsRUFBRSxDQUFDO29CQUNkLElBQUksQ0FBQyxTQUFTLEdBQUcsS0FBSyxDQUFDO29CQUN2QixJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFNBQVMsQ0FDNUQsVUFBQyxJQUFJO3dCQUNELFlBQVk7d0JBQ1osRUFBRSxDQUFDLENBQUMsS0FBSSxDQUFDLFNBQVMsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDOzRCQUMxQixNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDOzRCQUN2QyxJQUFJLEdBQUcsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQTs0QkFDckMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLGFBQWEsQ0FBQztnQ0FDL0IsWUFBWSxFQUFFLElBQUk7Z0NBQ2xCLFVBQVUsRUFBRTtvQ0FDUixhQUFhLEVBQUUsSUFBSTtpQ0FDdEI7Z0NBQ0QsNEJBQTRCO2dDQUM1QixVQUFVLEVBQUUsR0FBRzs2QkFDbEIsQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQzs0QkFDeEMsSUFBSSxHQUFHLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUE7NEJBQ3JDLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQyxhQUFhLENBQUM7Z0NBQ2hDLFlBQVksRUFBRSxJQUFJO2dDQUNsQixVQUFVLEVBQUU7b0NBQ1IsYUFBYSxFQUFFLElBQUk7aUNBQ3RCO2dDQUNELDRCQUE0QjtnQ0FDNUIsVUFBVSxFQUFFLEdBQUc7NkJBQ2xCLENBQUMsQ0FBQzt3QkFDUCxDQUFDO29CQUNMLENBQUMsRUFDRCxVQUFDLEdBQUc7b0JBRUosQ0FBQyxFQUNEO29CQUVBLENBQUMsQ0FDSixDQUFDO29CQUVGLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO2dCQUN4QixDQUFDO2dCQUNELHVDQUFlLEdBQWY7b0JBQ0ksSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUM7b0JBQzVCLElBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSyxDQUFDO29CQUM3QixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQztvQkFDckIsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO29CQUM1QixNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQzVCLElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsY0FBYyxDQUFDO29CQUMvRCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksSUFBSSxJQUFJLFFBQVEsQ0FBRSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxHQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDN0gsTUFBTSxDQUFDLGdCQUFnQixDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7d0JBQ2hDLElBQUksQ0FBQyxZQUFZLEdBQUcsb0JBQW9CLENBQUM7d0JBQ3pDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO29CQUN0QyxDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUNGLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO3dCQUNoQyxNQUFNLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztvQkFDdEMsQ0FBQztnQkFDTCxDQUFDO2dCQUVELHlDQUFpQixHQUFqQjtvQkFBQSxpQkFvRkM7b0JBbEZHLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQzt3QkFDaEMsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUM7d0JBQzVCLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQzt3QkFDNUIsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO3dCQUM1QixJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQzt3QkFDdEIsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxrQkFBa0IsQ0FBQzt3QkFDcEUscUNBQXFDO3dCQUNwQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksSUFBSSxJQUFJLFFBQVEsQ0FBRSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxHQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs0QkFDN0gsTUFBTSxDQUFDLGdCQUFnQixDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7NEJBQ2hDLElBQUksQ0FBQyxZQUFZLEdBQUcsa0JBQWtCLENBQUM7NEJBQ3ZDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO3dCQUN0QyxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDOzRCQUNoQyxNQUFNLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQzt3QkFDdEMsQ0FBQztvQkFDTCxDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUNGLElBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSyxDQUFDO3dCQUM3QixNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7d0JBQzVCLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQzt3QkFDNUIsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxjQUFjLENBQUM7d0JBRS9ELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxJQUFJLElBQUksUUFBUSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOzRCQUMzSCxNQUFNLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQzs0QkFDaEMsSUFBSSxDQUFDLFlBQVksR0FBRyxvQkFBb0IsQ0FBQzs0QkFDekMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7NEJBRWxDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxRQUFRLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQztnQ0FDbEksSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7b0NBQ25HLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO29DQUN0QyxpQkFBaUI7b0NBQ2pCLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzt3Q0FDM0IseUJBQXlCO3dDQUN6QixPQUFPLENBQUMsS0FBSyxDQUFDOzRDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTs0Q0FDdEQsT0FBTyxFQUFFO2dEQUNMLEVBQUUsRUFBRTtvREFDQSxjQUFjO29EQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztpREFDNUI7NkNBQ0o7eUNBQ0osQ0FBQyxDQUFDO29DQUNQLENBQUM7b0NBQ0QsNEJBQTRCO29DQUM1QixPQUFPLENBQUMsS0FBSyxDQUFDO3dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTt3Q0FDdEQsT0FBTyxFQUFFOzRDQUNMLEVBQUUsRUFBRTtnREFDQSxjQUFjO2dEQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUzs2Q0FDNUI7eUNBQ0o7cUNBQ0osQ0FBQyxDQUFDO29DQUNILEtBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO29DQUNyQixHQUFHO29DQUNILFFBQVE7b0NBRVIsR0FBRztnQ0FDUCxDQUFDLENBQUMsQ0FBQzs0QkFDUCxDQUFDOzRCQUNELElBQUksQ0FBQyxDQUFDO2dDQUNGLE9BQU8sQ0FBQyxLQUFLLENBQUM7b0NBQ1YsT0FBTyxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGVBQWUsRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLFlBQVk7b0NBQy9FLE9BQU8sRUFBRTt3Q0FDTCxFQUFFLEVBQUU7NENBQ0EsY0FBYzs0Q0FDZCxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVM7eUNBQzVCO3FDQUNKO2lDQUNKLENBQUMsQ0FBQztnQ0FDSCxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7Z0NBQ2xCLElBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSyxDQUFDO2dDQUM3QixJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQzs0QkFDN0IsQ0FBQzt3QkFDTCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDOzRCQUNoQyxNQUFNLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQzt3QkFDdEMsQ0FBQztvQkFDTCxDQUFDO2dCQUVMLENBQUM7Z0JBQ0Qsb0NBQVksR0FBWjtvQkFDSSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzt3QkFDeEUsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7NEJBQzVDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUM7d0JBQ2pILENBQUM7b0JBQ0wsQ0FBQztnQkFDTCxDQUFDO2dCQUNELDZDQUFxQixHQUFyQjtnQkFFQSxDQUFDO2dCQUNELHNDQUFjLEdBQWQ7b0JBQ0ksVUFBVTtvQkFDVixXQUFXO2dCQUVmLENBQUM7Z0JBRUQseUNBQWlCLEdBQWpCO29CQUVJLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztvQkFDbEIsSUFBSSxDQUFDLG9DQUFvQyxFQUFFLENBQUM7b0JBQzVDLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQztvQkFDZCxJQUFJLE1BQU0sR0FBRyxNQUFNLENBQUM7b0JBRXBCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDO3dCQUN4RSxNQUFNLEdBQUcsTUFBTSxDQUFDO29CQUVwQixDQUFDO29CQUNELE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRTt3QkFDNUIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxNQUFNLENBQUMsQ0FBQyxDQUFDOzRCQUN0QixJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQzs0QkFDbEIsTUFBTSxDQUFDLEtBQUssQ0FBQzt3QkFDakIsQ0FBQztvQkFFTCxDQUFDLENBQUMsQ0FBQztvQkFFSCxJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7Z0JBQ3pHLENBQUM7Z0JBQ0Qsa0NBQVUsR0FBVjtvQkFFSSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQzt3QkFDdEUsV0FBVzt3QkFDWCxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sSUFBSSxTQUFTLENBQUUsQ0FBQyxDQUFELENBQUM7NEJBQ3pFLElBQUksVUFBVSxHQUFHLEVBQUUsQ0FBQzs0QkFDcEIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQztnQ0FDekksVUFBVSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQzs0QkFFckUsQ0FBQzs0QkFDRCxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLFNBQVMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQ2hKLFVBQVUsR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUM7NEJBQzdDLENBQUM7NEJBQ0QsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDbEosVUFBVSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxHQUFHLEdBQUcsQ0FBQzs0QkFDN0MsQ0FBQzs0QkFDRCxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxVQUFVLENBQUM7d0JBQ3hDLENBQUM7d0JBQ0QsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs0QkFDbEosSUFBSSxVQUFVLEdBQUcsRUFBRSxDQUFDOzRCQUNwQixFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQzFFLFVBQVUsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQzs0QkFDekMsQ0FBQzs0QkFDRCxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxVQUFVLENBQUM7d0JBQ3hDLENBQUM7d0JBQ0QsSUFBSTs0QkFDQSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEdBQUcsSUFBSSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLHFCQUFxQjt3QkFDOUksRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7NEJBQzVDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUM7d0JBQ2pILENBQUM7b0JBQ0wsQ0FBQztvQkFDRCxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7Z0JBQ3hCLENBQUM7Z0JBQ0QsaUNBQVMsR0FBVDtvQkFDSSxzRUFBc0U7b0JBQ3RFLElBQUksTUFBTSxHQUFHLEtBQUssQ0FBQztvQkFDbkIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO3dCQUN6QixNQUFNLEdBQUcsS0FBSyxDQUFBO3dCQUNkLElBQUksQ0FBQyxTQUFTLEdBQUcsS0FBSyxDQUFDO29CQUMzQixDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUNGLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDO3dCQUN0QixNQUFNLEdBQUcsSUFBSSxDQUFDO29CQUNsQixDQUFDO29CQUVELElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBQy9CLENBQUM7Z0JBQ0Qsd0NBQWdCLEdBQWhCO29CQUFBLGlCQWlKQztvQkFoSkcsV0FBVztvQkFDWCxJQUFJLENBQUMsWUFBWSxHQUFHLFVBQVUsQ0FBQztvQkFDL0IsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7b0JBQ3ZCLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO29CQUV6QixJQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7b0JBQ2QsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO3dCQUM5RixNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLEVBQUU7NEJBQzNDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQztnQ0FDM0IsS0FBSyxHQUFHLEtBQUssR0FBRyxDQUFDLENBQUM7NEJBQ3RCLENBQUM7NEJBQ0QsRUFBRSxDQUFDLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQ1osbURBQW1EO2dDQUVuRCxJQUFJLENBQUMsWUFBWSxHQUFHLEVBQUUsQ0FBQztnQ0FDdkIsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7Z0NBQ3hCLE1BQU0sQ0FBQyxLQUFLLENBQUM7NEJBQ2pCLENBQUM7d0JBQ0wsQ0FBQyxDQUFDLENBQUM7b0JBQ1AsQ0FBQztvQkFDRCxtQ0FBbUM7b0JBQ25DLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7d0JBQ2xDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSxZQUFZLEVBQUUsSUFBSSxDQUFDLENBQUMsT0FBTyxFQUFFLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQzs0QkFDM0UsT0FBTyxDQUFDLEtBQUssQ0FBQyxFQUFFLE9BQU8sRUFBRSx3QkFBd0IsRUFBRSxDQUFDLENBQUM7NEJBRXJELElBQUksQ0FBQyxZQUFZLEdBQUcsRUFBRSxDQUFDOzRCQUN2QixJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQzs0QkFDeEIsTUFBTSxDQUFDLEtBQUssQ0FBQzt3QkFDakIsQ0FBQztvQkFDTCxDQUFDO29CQUNELElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxHQUFHLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQztvQkFDL0MsRUFBRSxDQUFDLENBQUMsS0FBSyxJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7d0JBRTVHLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUN4RixJQUFJLE1BQU0sR0FBRyxFQUFFLENBQUM7NEJBQ2hCLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLElBQUksQ0FBQztnQ0FDN0IsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQzs0QkFDcEMsQ0FBQyxDQUFDLENBQUM7NEJBQ0gsSUFBSSxNQUFNLEdBQUcsRUFBRSxDQUFDOzRCQUNoQixNQUFNLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0NBQzdCLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7NEJBQ3BDLENBQUMsQ0FBQyxDQUFDOzRCQUNILElBQUksT0FBTyxHQUFHLEVBQUUsQ0FBQzs0QkFDakIsTUFBTSxDQUFDLG9CQUFvQixDQUFDLENBQUMsSUFBSSxDQUFDO2dDQUM5QixPQUFPLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDOzRCQUNyQyxDQUFDLENBQUMsQ0FBQzs0QkFDSCxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7NEJBQ1YsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRTtnQ0FDeEMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO29DQUNyQixJQUFJLENBQUMsS0FBSyxHQUFHLEdBQUcsQ0FBQztnQ0FDckIsQ0FBQztnQ0FDRCxJQUFJLENBQUMsQ0FBQztvQ0FDRixJQUFJLENBQUMsS0FBSyxHQUFHLEdBQUcsQ0FBQztnQ0FDckIsQ0FBQztnQ0FDRCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7b0NBQ3pCLElBQUksQ0FBQyxTQUFTLEdBQUcsR0FBRyxDQUFDO2dDQUN6QixDQUFDO2dDQUNELElBQUksQ0FBQyxDQUFDO29DQUNGLElBQUksQ0FBQyxTQUFTLEdBQUcsR0FBRyxDQUFDO2dDQUN6QixDQUFDO2dDQUNELElBQUksQ0FBQyxLQUFLLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUN2QixJQUFJLENBQUMsSUFBSSxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDdEIsSUFBSSxDQUFDLE1BQU0sR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQ3pCLENBQUMsRUFBRSxDQUFDO2dDQUNKLHlDQUF5QztnQ0FDekMsdUNBQXVDO2dDQUN2QywyQkFBMkI7NEJBQy9CLENBQUMsQ0FBQyxDQUFDO3dCQUVQLENBQUM7d0JBQ0QsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQ3hGLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUU7Z0NBQ3hDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQztvQ0FDdkIsSUFBSSxDQUFDLE9BQU8sR0FBRyxHQUFHLENBQUM7Z0NBQ3ZCLENBQUM7Z0NBQ0QsSUFBSSxDQUFDLENBQUM7b0NBQ0YsSUFBSSxDQUFDLE9BQU8sR0FBRyxHQUFHLENBQUM7Z0NBQ3ZCLENBQUM7Z0NBQ0YsWUFBWTtnQ0FDWCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7b0NBQzNCLElBQUksQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDO2dDQUM3QixDQUFDO2dDQUNELElBQUksQ0FBQyxDQUFDO29DQUNGLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDO2dDQUM1QixDQUFDO2dDQUVELENBQUMsRUFBRSxDQUFDOzRCQUNSLENBQUMsQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7d0JBQzVDLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUE7d0JBQ2xCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTs0QkFDdkQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQzs0QkFDdEIsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7NEJBQ3RDLEtBQUksQ0FBQyxZQUFZLEdBQUcsRUFBRSxDQUFDOzRCQUN2QixLQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQzs0QkFFeEIsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO2dDQUMzQix5QkFBeUI7Z0NBQ3pCLEtBQUksQ0FBQyxRQUFRLEdBQUcsYUFBYSxDQUFDOzRCQUNsQyxDQUFDOzRCQUNELElBQUksQ0FBQyxDQUFDO2dDQUNGLHlCQUF5QjtnQ0FFekIsS0FBSSxDQUFDLFFBQVEsR0FBRyxjQUFjLENBQUM7Z0NBQy9CLElBQUksS0FBSyxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUM7Z0NBQy9DLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLE1BQU0sRUFBRSxLQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksRUFBRSxFQUFFLENBQUMsQ0FBQztnQ0FDbEYsS0FBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsS0FBSyxFQUFFLEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxFQUFFLEVBQUUsQ0FBQyxDQUFDO2dDQUMvRSxLQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxLQUFLLEVBQUUsS0FBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsRUFBRSxFQUFFLENBQUMsQ0FBQztnQ0FDckYsRUFBRSxDQUFDLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLEdBQUMsQ0FBQyxDQUFDO29DQUMzQyxLQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxPQUFPLEVBQUUsS0FBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxXQUFXLEVBQUUsRUFBRSxDQUFDLENBQUM7Z0NBQ3ZKLFlBQVk7Z0NBQ1gsMERBQTBEO2dDQUMxRCxXQUFXO2dDQUNYLEtBQUksQ0FBQyxjQUFjLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQztnQ0FDcEMsS0FBSSxDQUFDLFVBQVUsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO2dDQUNoQyxLQUFJLENBQUMsV0FBVyxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQzs0QkFPdEMsQ0FBQzs0QkFDRCxLQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQzs0QkFDcEIsS0FBSSxDQUFDLEdBQUcsR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDO3dCQUMvQixDQUFDLEVBQ0csVUFBQSxLQUFLLElBQUcsT0FBQSxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxFQUFsQixDQUFrQixFQUMxQixjQUFNLE9BQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQkFBc0IsQ0FBQyxFQUFuQyxDQUFtQyxDQUM1QyxDQUFDO29CQUNOLENBQUM7b0JBQ0QsSUFBSSxDQUFDLENBQUM7d0JBQ0YsT0FBTyxDQUFDLEtBQUssQ0FBQzs0QkFDVixPQUFPLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsaUJBQWlCLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxZQUFZOzRCQUNqRixPQUFPLEVBQUU7Z0NBQ0wsRUFBRSxFQUFFO29DQUNBLGNBQWM7b0NBQ2QsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO2lDQUM1Qjs2QkFDSjt5QkFDSixDQUFDLENBQUM7d0JBQ0gsSUFBSSxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUM7d0JBQ3ZCLElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO29CQUM1QixDQUFDO2dCQUNMLENBQUM7Z0JBRUQsNERBQW9DLEdBQXBDO29CQUFBLGlCQTRFQztvQkEzRUcsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO3dCQUN2QixJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQzt3QkFDNUMsV0FBVzt3QkFDWCxJQUFJLEtBQUssR0FBRyxFQUFFLENBQUM7d0JBQ2YsSUFBSSxLQUFLLEdBQUcsRUFBRSxDQUFDO3dCQUNmLElBQUksT0FBTyxHQUFHLEVBQUUsQ0FBQzt3QkFDakIsSUFBSSxNQUFNLEdBQUcsRUFBRSxDQUFDO3dCQUNoQixJQUFJLE1BQU0sR0FBRyxFQUFFLENBQUM7d0JBRWhCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLFNBQVMsQ0FBQzs0QkFDbkMsS0FBSyxHQUFHLEVBQUUsQ0FBQzt3QkFDZixJQUFJOzRCQUNBLEtBQUssR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQzt3QkFFbEMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLElBQUksU0FBUyxDQUFDOzRCQUNuQyxLQUFLLEdBQUcsRUFBRSxDQUFDO3dCQUNmLElBQUk7NEJBQ0EsS0FBSyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDO3dCQUNsQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sSUFBSSxTQUFTLENBQUM7NEJBQ3JDLE9BQU8sR0FBRyxFQUFFLENBQUM7d0JBQ2pCLElBQUk7NEJBQ0EsT0FBTyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDO3dCQUV0QyxNQUFNLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxJQUFJLENBQUM7NEJBRTdCLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLEVBQUUsSUFBSSxFQUFFLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsRUFBRSxJQUFJLFNBQVMsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxFQUFFLElBQUksSUFBSSxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDOUgsTUFBTSxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxLQUFLLENBQUM7NEJBQ3pDLENBQUM7d0JBQ0wsQ0FBQyxDQUFDLENBQUM7d0JBQ0gsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7NEJBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7d0JBQ3ZFLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUU7NEJBQ3hDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxLQUFLLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxLQUFLLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQzlGLE1BQU0sSUFBSSxJQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQzs0QkFDakMsQ0FBQzt3QkFFTCxDQUFDLENBQUMsQ0FBQzt3QkFDSCxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQzs0QkFBQyxNQUFNLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQzt3QkFDdkUsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLElBQUksRUFBRSxJQUFJLEtBQUssQ0FBQyxNQUFNLElBQUksQ0FBQyxJQUFJLEtBQUssSUFBSSxFQUFFLElBQUksS0FBSyxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUM7K0JBQ25FLENBQUMsT0FBTyxJQUFJLEVBQUUsSUFBSSxPQUFPLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQzsrQkFDdEMsQ0FBQyxNQUFNLElBQUksRUFBRSxDQUFDOytCQUNkLENBQUMsTUFBTSxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQzs0QkFFcEIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLHNCQUFzQixDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxNQUFNLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO2dDQUNsRyxXQUFXO2dDQUNYLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dDQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7b0NBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7d0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO3dDQUN0RCxPQUFPLEVBQUU7NENBQ0wsRUFBRSxFQUFFO2dEQUNBLGNBQWM7Z0RBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTOzZDQUM1Qjt5Q0FDSjtxQ0FDSixDQUFDLENBQUM7Z0NBQ1AsQ0FBQztnQ0FDRCxJQUFJLENBQUMsQ0FBQztvQ0FDRixLQUFJLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQztvQ0FDbkIsS0FBSSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO29DQUM5QixFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxJQUFJLElBQUksSUFBSSxRQUFRLENBQUMsSUFBSSxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUM7d0NBQ3RELEtBQUksQ0FBQyxjQUFjLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzt3Q0FDcEMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFBO29DQUdwQyxDQUFDO2dDQUVMLENBQUM7NEJBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSztnQ0FDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDOzRCQUN2QixDQUFDLEVBQUU7Z0NBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTs0QkFDaEMsQ0FBQyxDQUFDLENBQUM7d0JBQ1AsQ0FBQztvQkFDTCxDQUFDO29CQUNELG9CQUFvQjtnQkFDeEIsQ0FBQztnQkFDRCxxQ0FBYSxHQUFiO29CQUNJLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztvQkFDbEIsSUFBSSxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7Z0JBQ3pCLENBQUM7Z0JBQ0Qsa0NBQVUsR0FBVjtvQkFDSSxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsVUFBVSxFQUFFLENBQUM7b0JBQ2xDLE1BQU0sQ0FBQyxlQUFlLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFLENBQUMsQ0FBQztnQkFDdkQsQ0FBQztnQkFFRCwrQ0FBdUIsR0FBdkIsVUFBd0IsS0FBSyxFQUFFLEtBQUssRUFBQyxPQUFPO29CQUE1QyxpQkE4Q0M7b0JBN0NHLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO29CQUM1QyxXQUFXO29CQUNYLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLFNBQVMsQ0FBQzt3QkFDbkMsS0FBSyxHQUFHLEVBQUUsQ0FBQztvQkFDZixJQUFJO3dCQUNBLEtBQUssR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQztvQkFFbEMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLElBQUksU0FBUyxDQUFDO3dCQUNuQyxLQUFLLEdBQUcsRUFBRSxDQUFDO29CQUNmLElBQUk7d0JBQ0EsS0FBSyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDO29CQUNsQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sSUFBSSxTQUFTLENBQUM7d0JBQ3JDLE9BQU8sR0FBRyxFQUFFLENBQUM7b0JBQ2pCLElBQUk7d0JBQ0EsT0FBTyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDO29CQUN0QyxJQUFJLENBQUMsZ0JBQWdCLENBQUMscUJBQXFCLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUNqRixXQUFXO3dCQUNYLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUN0RCxPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQzs0QkFDbkIsS0FBSSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDOzRCQUM5QixFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxJQUFJLElBQUksSUFBSSxRQUFRLENBQUMsSUFBSSxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUM7Z0NBQ3RELEtBQUksQ0FBQyxjQUFjLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQztnQ0FDcEMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDOzRCQUVyQyxDQUFDO3dCQUVMLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsb0JBQW9CO2dCQUN4QixDQUFDO2dCQUtELDBDQUFrQixHQUFsQjtvQkFFSSxpQkFBaUI7b0JBQ2pCLHdFQUF3RTtvQkFDeEUsb0NBQW9DO29CQUNwQyw0RUFBNEU7b0JBQzVFLGlCQUFpQjtvQkFDakIsNENBQTRDO29CQUM1QyxxQ0FBcUM7b0JBQ3JDLGlDQUFpQztvQkFDakMsT0FBTztvQkFDUCxZQUFZO29CQUNaLDZCQUE2QjtvQkFDN0Isd0NBQXdDO29CQUN4QyxvRUFBb0U7b0JBQ3BFLGtEQUFrRDtvQkFDbEQsaURBQWlEO29CQUNqRCxXQUFXO29CQUNYLDRCQUE0QjtvQkFDNUIsT0FBTztvQkFDUCxjQUFjO29CQUNkLHlCQUF5QjtvQkFDekIsWUFBWTtvQkFDWixrQ0FBa0M7b0JBQ2xDLEtBQUs7Z0JBQ1QsQ0FBQztnQkFDRCwwQ0FBa0IsR0FBbEI7b0JBQUEsaUJBZ0NDO29CQS9CRyxJQUFJLEtBQUssR0FBRyxFQUFFLENBQUM7b0JBQ2YsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLFNBQVMsQ0FBQzt3QkFDbEUsS0FBSyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDO29CQUNsQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsc0JBQXNCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUNsRixXQUFXO3dCQUNYLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUN0RCxPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQzs0QkFDbkIsS0FBSSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDOzRCQUM5QixFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxJQUFJLElBQUksSUFBSSxRQUFRLENBQUMsSUFBSSxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUM7Z0NBQ3RELEtBQUksQ0FBQyxjQUFjLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQztnQ0FDcEMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDOzRCQUNyQyxDQUFDO3dCQUVMLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7Z0JBQ1AsQ0FBQztnQkFDRCxtQ0FBVyxHQUFYLFVBQVksS0FBSztvQkFDYixNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxFQUFFO3dCQUN4QyxFQUFFLENBQUMsQ0FBQyxJQUFJLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQzs0QkFDaEIsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7d0JBQzlCLENBQUM7b0JBRUwsQ0FBQyxDQUFDLENBQUM7Z0JBQ1AsQ0FBQztnQkFDRCxvQ0FBWSxHQUFaO29CQUNJLElBQUksQ0FBQyxPQUFPLEdBQUcsRUFBRSxDQUFDO29CQUNsQixJQUFJLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztvQkFDckIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEdBQUcsRUFBRSxDQUFDO29CQUNqQyxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsR0FBRyxFQUFFLENBQUM7b0JBQzlCLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztvQkFDMUIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDO29CQUMzQixJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsR0FBRyxFQUFFLENBQUM7b0JBQ2hDLElBQUksQ0FBQyxVQUFVLEdBQUcsRUFBRSxDQUFDO29CQUNyQixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGFBQWEsQ0FBQTtnQkFHM0QsQ0FBQztnQkFDRCxzQ0FBYyxHQUFkO29CQUNJLFdBQVc7b0JBQ1gsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDO3dCQUMzQixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQzt3QkFDdkIsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxpQkFBaUIsQ0FBQzt3QkFDNUQsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFDakMsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQzt3QkFDeEIsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxrQkFBa0IsQ0FBQzt3QkFDN0QsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFDakMsQ0FBQztnQkFFTCxDQUFDO2dCQUdELHFDQUFhLEdBQWIsVUFBYyxLQUFLO29CQUNmLGlCQUFpQjtvQkFDakIsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sSUFBSSxTQUFTLElBQUksS0FBSyxDQUFDLE1BQU0sSUFBSSxFQUFFLENBQUM7MkJBQ2pELENBQUMsS0FBSyxDQUFDLE9BQU8sSUFBSSxTQUFTLElBQUksS0FBSyxDQUFDLE9BQU8sSUFBSSxFQUFFLENBQUM7MkJBRW5ELENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxTQUFTLElBQUksS0FBSyxDQUFDLEdBQUcsSUFBSSxFQUFFLENBQUM7MkJBQzNDLENBQUMsS0FBSyxDQUFDLFdBQVcsSUFBSSxTQUFTLElBQUksS0FBSyxDQUFDLFdBQVcsSUFBSSxFQUFFLENBQUU7MkJBRTVELENBQUMsS0FBSyxDQUFDLGFBQWEsSUFBSSxTQUFTLElBQUksS0FBSyxDQUFDLGFBQWEsSUFBSSxFQUFFLENBQUMsQ0FBQztnQkFDM0UsQ0FBQztnQkFDRCxvQ0FBWSxHQUFaLFVBQWEsS0FBSztvQkFFZCxJQUFJLFNBQVMsR0FBRyxLQUFLLENBQUM7b0JBQ3RCLEtBQUssQ0FBQyxRQUFRLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDO29CQUV2QyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFFNUIsSUFBSSxLQUFLLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQzt3QkFDL0MsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsT0FBTyxFQUFFLEtBQUssQ0FBQyxXQUFXLEVBQUUsRUFBRSxDQUFDLENBQUM7d0JBQ3hFLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQzt3QkFDZCxJQUFJLE1BQU0sR0FBRyxNQUFNLENBQUM7d0JBQ3BCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDOzRCQUN4RSxNQUFNLEdBQUcsTUFBTSxDQUFDO3dCQUNwQixDQUFDO3dCQUNELE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRTs0QkFDNUIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxNQUFNLENBQUMsQ0FBQyxDQUFDO2dDQUN0QixJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztnQ0FDbEIsTUFBTSxDQUFDLEtBQUssQ0FBQzs0QkFDakIsQ0FBQzt3QkFFTCxDQUFDLENBQUMsQ0FBQzt3QkFDSCxJQUFJLFNBQVMsR0FBRyxFQUFFLE1BQU0sRUFBRSxFQUFFLEVBQUUsT0FBTyxFQUFFLEVBQUUsRUFBRSxRQUFRLEVBQUUsRUFBRSxFQUFFLEdBQUcsRUFBRSxFQUFFLEVBQUUsV0FBVyxFQUFFLEtBQUssQ0FBQyxXQUFXLEVBQUUsT0FBTyxFQUFFLEVBQUUsRUFBRSxhQUFhLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRyxTQUFTLEVBQUUsVUFBVSxHQUFHLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLEdBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsV0FBVyxFQUFFLFFBQVEsR0FBRyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsTUFBTSxHQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUM7d0JBRTVVLDhEQUE4RDt3QkFDOUQsbUZBQW1GO3dCQUVuRixvQ0FBb0M7d0JBQ3BDLHVCQUF1Qjt3QkFDdkIsT0FBTzt3QkFDUCxLQUFLO3dCQUNMLEVBQUUsQ0FBQyxDQUFDLFNBQVMsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDOzRCQUNyQixJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQzt3QkFDdEQsQ0FBQztvQkFFVCxDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUNGLElBQUksR0FBRyxHQUFHLEVBQUUsQ0FBQzt3QkFDYixFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxJQUFJLFNBQVMsSUFBSSxLQUFLLENBQUMsTUFBTSxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7NEJBQ2xELG9EQUFvRDs0QkFDcEQsR0FBRyxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxpQkFBaUIsQ0FBQzt3QkFDN0QsQ0FBQzt3QkFDRCxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxJQUFJLFNBQVMsSUFBSSxLQUFLLENBQUMsT0FBTyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7NEJBQ3BELGdDQUFnQzs0QkFDaEMsR0FBRyxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxlQUFlLENBQUM7d0JBQzNELENBQUM7d0JBQ0QsMERBQTBEO3dCQUMxRCx1Q0FBdUM7d0JBQ3ZDLDZEQUE2RDt3QkFDN0QsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxTQUFTLElBQUksS0FBSyxDQUFDLEdBQUcsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDOzRCQUM1QyxnQ0FBZ0M7NEJBQ2hDLEdBQUcsSUFBSSxJQUFJLEdBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsY0FBYyxDQUFDO3dCQUN4RCxDQUFDO3dCQUNELEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxXQUFXLElBQUksU0FBUyxJQUFJLEtBQUssQ0FBQyxXQUFXLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzs0QkFDNUQscUNBQXFDOzRCQUNyQyxHQUFHLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGtCQUFrQixDQUFDO3dCQUM5RCxDQUFDO3dCQUNELHdFQUF3RTt3QkFDeEUsdUNBQXVDO3dCQUN2QyxHQUFHO3dCQUNILEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxhQUFhLElBQUksU0FBUyxJQUFJLEtBQUssQ0FBQyxhQUFhLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzs0QkFDaEUsMENBQTBDOzRCQUMxQyxHQUFHLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGlCQUFpQixDQUFDO3dCQUM3RCxDQUFDO3dCQUNELE9BQU8sQ0FBQyxLQUFLLENBQUM7NEJBQ1YsT0FBTyxFQUFFLEdBQUcsRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLFlBQVk7NEJBQzFDLE9BQU8sRUFBRTtnQ0FDTCxFQUFFLEVBQUU7b0NBQ0EsY0FBYztvQ0FDZCxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVM7aUNBQzVCOzZCQUNKO3lCQUNKLENBQUMsQ0FBQztvQkFDUCxDQUFDO2dCQUVMLENBQUM7Z0JBQ0QsbUNBQVcsR0FBWCxVQUFZLFFBQVE7b0JBQ2hCLFdBQVc7b0JBQ1gsaUtBQWlLO29CQUNqSyxNQUFNLENBQUMsQ0FBQyxRQUFRLENBQUMsV0FBVyxJQUFJLFNBQVMsSUFBSSxRQUFRLENBQUMsV0FBVyxJQUFJLEVBQUUsQ0FBQyxDQUFBO29CQUNwRSxpRkFBaUY7b0JBQ2pGLDJFQUEyRTtvQkFDM0Usc0VBQXNFO29CQUN0RSwyREFBMkQ7b0JBQzNELDhGQUE4RjtnQkFDdEcsQ0FBQztnQkFDRCxpQ0FBUyxHQUFULFVBQVUsUUFBUTtvQkFDZCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFFOUIsWUFBWTt3QkFDWCx1Q0FBdUM7d0JBQ3ZDLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQzt3QkFDZCxJQUFJLEdBQUcsR0FBRyxDQUFDLENBQUM7d0JBQ1osSUFBSSxPQUFPLEdBQUcsQ0FBQyxDQUFDO3dCQUNoQixNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUU7NEJBQzFCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksV0FBVyxDQUFDLENBQUMsQ0FBQztnQ0FFM0IsSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7Z0NBQ2xCLEdBQUcsR0FBRyxDQUFDLENBQUM7Z0NBQ1IsT0FBTyxHQUFHLENBQUMsQ0FBQztnQ0FDWixNQUFNLENBQUMsS0FBSyxDQUFDOzRCQUNqQixDQUFDO3dCQUNMLENBQUMsQ0FBQyxDQUFDO3dCQUNILElBQUksUUFBUSxHQUFHLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFLE1BQU0sRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFFLEtBQUssRUFBRSxHQUFHLEVBQUUsUUFBUSxFQUFFLEVBQUUsRUFBRSxhQUFhLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLEtBQUssR0FBRyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxZQUFZLEVBQUUsS0FBSyxHQUFHLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUM7d0JBRWpULElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFJbEQsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixJQUFJLEdBQUcsR0FBRyxFQUFFLENBQUM7d0JBQ2IsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLFdBQVcsSUFBSSxTQUFTLElBQUksUUFBUSxDQUFDLFdBQVcsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDOzRCQUNsRSx3Q0FBd0M7NEJBQ3hDLEdBQUcsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsb0JBQW9CLENBQUM7d0JBQ2hFLENBQUM7d0JBQ0QsNERBQTREO3dCQUM1RCw4Q0FBOEM7d0JBQzlDLGdFQUFnRTt3QkFDaEUsR0FBRzt3QkFDSCx5Q0FBeUM7d0JBQ3pDLGlEQUFpRDt3QkFDakQsR0FBRzt3QkFDSCxPQUFPLENBQUMsS0FBSyxDQUFDOzRCQUNWLE9BQU8sRUFBRSxHQUFHLEVBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxZQUFZOzRCQUN6QyxPQUFPLEVBQUU7Z0NBQ0wsRUFBRSxFQUFFO29DQUNBLGNBQWM7b0NBQ2QsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO2lDQUM1Qjs2QkFDSjt5QkFDSixDQUFDLENBQUM7b0JBRVAsQ0FBQztnQkFFTCxDQUFDO2dCQUNELG1DQUFXLEdBQVgsVUFBWSxRQUFRO29CQUNoQixXQUFXO29CQUNYLGlCQUFpQjtvQkFDakIsTUFBTSxDQUFDLENBQUMsUUFBUSxDQUFDLFNBQVMsSUFBSSxTQUFTLElBQUksUUFBUSxDQUFDLFNBQVMsSUFBSSxFQUFFLENBQUMsQ0FBQztvQkFDckUsMERBQTBEO2dCQUU5RCxDQUFDO2dCQUNELGlDQUFTLEdBQVQsVUFBVSxRQUFRO29CQUNkLFdBQVc7b0JBQ1gsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQzdCLElBQUksUUFBUSxHQUFHLENBQUMsQ0FBQzt3QkFDakIsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFOzRCQUMzQixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLFdBQVcsQ0FBQyxDQUFDLENBQUM7Z0NBSTNCLFFBQVEsR0FBRyxDQUFDLENBQUM7Z0NBQ1osTUFBTSxDQUFDLEtBQUssQ0FBQzs0QkFDakIsQ0FBQzt3QkFDTCxDQUFDLENBQUMsQ0FBQzt3QkFDSCx1Q0FBdUM7d0JBQ3ZDLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQzt3QkFDZCxJQUFJLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQzt3QkFDaEIsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQzt3QkFDeEMsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUM7d0JBQ3hCLElBQUksQ0FBQyxPQUFPLEdBQUcsUUFBUSxDQUFDO3dCQUN4QixJQUFJLENBQUMsU0FBUyxHQUFFLE1BQU0sR0FBRyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sR0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQzt3QkFDOUUsSUFBSSxDQUFDLGFBQWEsR0FBRSxNQUFNLEdBQUcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUM7d0JBQ2hGLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFHbEQsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixJQUFJLEdBQUcsR0FBRyxFQUFFLENBQUM7d0JBQ2IsMERBQTBEO3dCQUMxRCx1Q0FBdUM7d0JBQ3ZDLGlFQUFpRTt3QkFDakUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLFNBQVMsSUFBSSxTQUFTLElBQUksUUFBUSxDQUFDLFNBQVMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDOzRCQUM5RCxnQ0FBZ0M7NEJBQ2hDLEdBQUcsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsbUJBQW1CLENBQUM7d0JBQy9ELENBQUM7d0JBQ0QsT0FBTyxDQUFDLEtBQUssQ0FBQzs0QkFDVixPQUFPLEVBQUUsR0FBRyxFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsWUFBWTs0QkFDMUMsT0FBTyxFQUFFO2dDQUNMLEVBQUUsRUFBRTtvQ0FDQSxjQUFjO29DQUNkLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUztpQ0FDNUI7NkJBQ0o7eUJBQ0osQ0FBQyxDQUFDO29CQUVQLENBQUM7b0JBRUQsOERBQThEO2dCQUNsRSxDQUFDO2dCQUVELG1DQUFXLEdBQVgsVUFBWSxHQUFHO29CQUFmLGlCQXNIQztvQkFySEcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGtCQUFrQixDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUN6RSxhQUFhO3dCQUNYLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUN0RCxPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsVUFBVSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7NEJBQ2hDLEtBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsY0FBYyxDQUFDOzRCQUM3RCx3RUFBd0U7NEJBQ3hFLEtBQUksQ0FBQyxPQUFPLEdBQUcsaUJBQWlCLENBQUM7NEJBQ2pDLEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUM3QyxLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxDQUFDLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsS0FBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFFLFNBQVMsRUFBRSxPQUFPLEVBQUUsYUFBYSxFQUFFLE9BQU8sRUFBRSxDQUFDLENBQUE7NEJBQ25LLENBQUM7NEJBQ0QsSUFBSSxDQUFDLENBQUM7Z0NBQ0YsSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO2dDQUVkLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUU7b0NBQ3hDLElBQUksQ0FBQyxTQUFTLEdBQUcsTUFBTSxHQUFHLEtBQUssQ0FBQztvQ0FDaEMsSUFBSSxDQUFDLGFBQWEsR0FBRyxNQUFNLEdBQUcsS0FBSyxFQUFFLENBQUM7b0NBQ3RDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLElBQUksR0FBRyxDQUFDLENBQUMsQ0FBQzt3Q0FDMUIsSUFBSSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUM7b0NBQzdCLENBQUM7b0NBQ0QsSUFBSSxDQUFDLENBQUM7d0NBQ0YsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUM7b0NBQzVCLENBQUM7Z0NBQ0wsQ0FBQyxDQUFDLENBQUM7NEJBQ1AsQ0FBQzs0QkFDRCxFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDN0MsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDO2dDQUVkLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLFdBQVcsRUFBRTtvQ0FFMUIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxXQUFXLENBQUMsQ0FBQyxDQUFDO3dDQUUzQixJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQzt3Q0FDbEIsTUFBTSxDQUFDLEtBQUssQ0FBQztvQ0FDakIsQ0FBQztnQ0FDTCxDQUFDLENBQUMsQ0FBQztnQ0FFSCxLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxDQUFDLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsQ0FBQyxFQUFFLFFBQVEsRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFFLENBQUMsRUFBRSxRQUFRLEVBQUUsTUFBTSxFQUFFLFlBQVksRUFBRSxNQUFNLEVBQUUsQ0FBQyxDQUFDOzRCQUc1SyxDQUFDOzRCQUNELElBQUksQ0FBQyxDQUFDO2dDQUNGLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQztnQ0FDZCxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxFQUFFO29DQUV4QyxJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssR0FBRyxLQUFLLENBQUM7b0NBQzlCLElBQUksQ0FBQyxZQUFZLEdBQUcsS0FBSyxHQUFHLEtBQUssRUFBRSxDQUFDO2dDQUN4QyxDQUFDLENBQUMsQ0FBQzs0QkFDUCxDQUFDOzRCQUNELEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQ2hELElBQUksS0FBSyxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUM7Z0NBRS9DLElBQUksS0FBSyxHQUFHLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLE9BQU8sQ0FBQyxDQUFDO2dDQUM3RCxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztvQ0FDakIsS0FBSyxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQztnQ0FDN0MsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDO2dDQUNkLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQztnQ0FDdEIsRUFBRSxDQUFDLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLElBQUksRUFBRSxJQUFJLEtBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxJQUFJLFNBQVMsSUFBSSxLQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO29DQUMzRyxRQUFRLEdBQUcsTUFBTSxDQUFDO2dDQUN0QixDQUFDO2dDQUNELE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLGFBQWEsRUFBRTtvQ0FDNUIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxRQUFRLENBQUMsQ0FBQyxDQUFDO3dDQUV4QixJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQzt3Q0FDbEIsTUFBTSxDQUFDLEtBQUssQ0FBQztvQ0FDakIsQ0FBQztnQ0FFTCxDQUFDLENBQUMsQ0FBQztnQ0FDSCxLQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixHQUFHLENBQUMsRUFBRSxNQUFNLEVBQUUsRUFBRSxFQUFFLE9BQU8sRUFBRSxFQUFFLEVBQUUsUUFBUSxFQUFFLEVBQUUsRUFBRSxHQUFHLEVBQUUsRUFBRSxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsT0FBTyxFQUFFLEVBQUUsRUFBRSxhQUFhLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsV0FBVyxFQUFFLFdBQVcsRUFBRSxTQUFTLEVBQUUsQ0FBQyxDQUFDOzRCQUMzTyxDQUFDOzRCQUNELElBQUksQ0FBQyxDQUFDO2dDQUNGLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQztnQ0FDbEIsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixFQUFFO29DQUMzQyxJQUFJLENBQUMsU0FBUyxHQUFHLFVBQVUsR0FBRyxLQUFLLENBQUM7b0NBQ3BDLElBQUksQ0FBQyxXQUFXLEdBQUcsUUFBUSxHQUFHLEtBQUssRUFBRSxDQUFDO2dDQUMxQyxDQUFDLENBQUMsQ0FBQzs0QkFDSCxDQUFDOzRCQUNELDREQUE0RDs0QkFFNUQscUNBQXFDOzRCQUdyQywyREFBMkQ7NEJBQzNELDZHQUE2Rzs0QkFDN0csaUJBQWlCOzRCQUNqQixvQ0FBb0M7NEJBQ3BDLE9BQU87NEJBQ1AsdUVBQXVFOzRCQUN2RSwwREFBMEQ7NEJBQzFELEtBQUs7NEJBQ0wsS0FBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLEdBQUcsS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDOzRCQUMzRCxLQUFJLENBQUMsZUFBZSxHQUFHLEtBQUssQ0FBQzs0QkFDN0IsS0FBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7d0JBRzdCLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBRUgsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO29CQUNsQiw0Q0FBNEM7b0JBQzVDLElBQUksQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDO2dCQUV6QixDQUFDO2dCQUNELHNDQUFjLEdBQWQsVUFBZSxRQUFRO29CQUF2QixpQkErREM7b0JBOURHLFdBQVc7b0JBQ1gsbUVBQW1FO29CQUNuRSxJQUFJLE9BQU8sR0FBRyxFQUFFLENBQUM7b0JBQ2pCLE1BQU0sQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDLElBQUksQ0FBQzt3QkFDbEMsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQztvQkFDckMsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO29CQUNkLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUU7d0JBQ3hDLEVBQUUsQ0FBQyxDQUFDLElBQUksSUFBSSxRQUFRLENBQUMsQ0FBQyxDQUFDOzRCQUVuQixNQUFNLENBQUMsS0FBSyxDQUFBO3dCQUNoQixDQUFDO3dCQUNELEtBQUssR0FBRyxLQUFLLEdBQUcsQ0FBQyxDQUFDO29CQUN0QixDQUFDLENBQUMsQ0FBQztvQkFFSCxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLElBQUksU0FBUyxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsSUFBSSxJQUFJLElBQUksT0FBTyxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7d0JBQ2hGLElBQUksV0FBVyxHQUFHLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQzt3QkFDakMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMsQ0FBQyxTQUFTLENBQ3hELFVBQUMsSUFBSTs0QkFDRCxXQUFXOzRCQUNYLEVBQUU7NEJBQ0YsSUFBSSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzs0QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO2dDQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO29DQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtvQ0FDdEQsT0FBTyxFQUFFO3dDQUNMLEVBQUUsRUFBRTs0Q0FDQSxjQUFjOzRDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUzt5Q0FDNUI7cUNBQ0o7aUNBQ0osQ0FBQyxDQUFDOzRCQUNQLENBQUM7NEJBQ0QsSUFBSSxDQUFDLENBQUM7Z0NBQ0YsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksSUFBSSxTQUFTLElBQUksUUFBUSxDQUFDLElBQUksSUFBSSxJQUFJLElBQUksUUFBUSxDQUFDLElBQUksSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO29DQUU3RSxXQUFXO29DQUVYLGtHQUFrRztvQ0FDbEcsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksR0FBRyxDQUFDLENBQUMsQ0FBQzt3Q0FDNUIsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQzt3Q0FDaEQsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQzt3Q0FDcEQsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLE9BQU8sR0FBRyxDQUFDLENBQUM7b0NBQzFGLENBQUM7b0NBQ0QsSUFBSSxDQUFDLENBQUM7d0NBQ0YsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQzt3Q0FDcEQsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQzt3Q0FDaEQsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLE9BQU8sR0FBRyxDQUFDLENBQUM7b0NBQzFGLENBQUM7Z0NBRUwsQ0FBQzs0QkFFTCxDQUFDOzRCQUNELHdGQUF3Rjt3QkFDNUYsQ0FBQyxFQUNELFVBQUMsR0FBRzt3QkFFSixDQUFDLEVBQ0Q7d0JBRUEsQ0FBQyxDQUFDLENBQUM7b0JBQ1AsQ0FBQztnQkFDVCxDQUFDO2dCQUNELG9DQUFZLEdBQVosVUFBYSxRQUFRO29CQUNqQixXQUFXO29CQUNYLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQztvQkFDZCxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDO29CQUM3QixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGNBQWMsQ0FBQztvQkFJekQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLEdBQUcsUUFBUSxDQUFDLEtBQUssQ0FBQztvQkFDdkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEdBQUcsUUFBUSxDQUFDLFNBQVMsQ0FBQztvQkFDL0MsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLFdBQVcsQ0FBQztvQkFHbkQsSUFBSSxDQUFDLGFBQWEsR0FBRyxFQUFFLENBQUM7b0JBQ3hCLElBQUksQ0FBQyxhQUFhLEdBQUcsUUFBUSxDQUFDO2dCQUNsQyxDQUFDO2dCQUNELG1DQUFXLEdBQVgsVUFBWSxRQUFRO29CQUNoQixXQUFXO29CQUNYLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUU1QyxJQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7d0JBQ2QsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRTs0QkFDeEMsRUFBRSxDQUFDLENBQUMsSUFBSSxJQUFJLFFBQVEsQ0FBQyxDQUFDLENBQUM7Z0NBQ25CLE1BQU0sQ0FBQyxLQUFLLENBQUE7NEJBQ2hCLENBQUM7NEJBQ0QsS0FBSyxHQUFHLEtBQUssR0FBRyxDQUFDLENBQUM7d0JBRXRCLENBQUMsQ0FBQyxDQUFDO3dCQUNILElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUM7b0JBQ3BELENBQUM7Z0JBQ0wsQ0FBQztnQkFFRCxzQ0FBYyxHQUFkLFVBQWUsVUFBVTtvQkFDckIsV0FBVztvQkFDWCxJQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7b0JBQ2QsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQztvQkFDN0IsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxjQUFjLENBQUM7b0JBRTFELCtDQUErQztvQkFFOUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQztvQkFDeEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLEdBQUcsVUFBVSxDQUFDLE9BQU8sQ0FBQztvQkFDMUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLEdBQUcsVUFBVSxDQUFDLFFBQVEsQ0FBQztvQkFDNUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLEdBQUcsVUFBVSxDQUFDLEdBQUcsQ0FBQztvQkFDbEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEdBQUcsVUFBVSxDQUFDLFdBQVcsQ0FBQztvQkFDbEQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLEdBQUcsVUFBVSxDQUFDLE9BQU8sQ0FBQztvQkFDMUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLEdBQUcsVUFBVSxDQUFDLGFBQWEsQ0FBQztvQkFDdEQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEdBQUcsVUFBVSxDQUFDLFdBQVcsQ0FBQztvQkFDbEQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEdBQUcsVUFBVSxDQUFDLFdBQVcsQ0FBQztvQkFHbEQsSUFBSSxDQUFDLGVBQWUsR0FBRyxFQUFFLENBQUM7b0JBQzFCLElBQUksQ0FBQyxlQUFlLEdBQUcsVUFBVSxDQUFDO2dCQUN0QyxDQUFDO2dCQUVELHFDQUFhLEdBQWIsVUFBYyxVQUFVO29CQUNyQixhQUFhO29CQUNaLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDeEMsSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO3dCQUNkLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsRUFBRTs0QkFDM0MsRUFBRSxDQUFDLENBQUMsSUFBSSxJQUFJLFVBQVUsQ0FBQyxDQUFDLENBQUM7Z0NBQ3JCLE1BQU0sQ0FBQyxLQUFLLENBQUE7NEJBQ2hCLENBQUM7NEJBQ0QsS0FBSyxHQUFHLEtBQUssR0FBRyxDQUFDLENBQUM7d0JBQ3RCLENBQUMsQ0FBQyxDQUFDO3dCQUNILElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQztvQkFDdkQsQ0FBQztnQkFDTCxDQUFDO2dCQUNELG9DQUFZLEdBQVosVUFBYSxRQUFRO29CQUVqQixJQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7b0JBQ2QsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxjQUFjLENBQUE7b0JBQ3hELElBQUksSUFBSSxHQUFHLFFBQVEsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUUzQyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsR0FBRyxRQUFRLENBQUMsU0FBUyxHQUFHLEdBQUcsR0FBRyxRQUFRLENBQUMsV0FBVyxDQUFDO29CQUU5RSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsR0FBRyxRQUFRLENBQUMsU0FBUyxDQUFDO29CQUMvQyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDO29CQUN6QyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO29CQUNyQyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUMsS0FBSyxDQUFDO29CQUN2QyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUMsS0FBSyxDQUFDO29CQUN2QyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUMsUUFBUSxDQUFDO29CQUM3QyxJQUFJLENBQUMsYUFBYSxHQUFHLEVBQUUsQ0FBQztvQkFDeEIsSUFBSSxDQUFDLGFBQWEsR0FBRyxRQUFRLENBQUM7Z0JBQ2xDLENBQUM7Z0JBQ0QsbUNBQVcsR0FBWCxVQUFZLFFBQVE7b0JBQ2pCLFlBQVk7b0JBQ1gsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQzVDLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQzt3QkFDZCxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxFQUFFOzRCQUN4QyxFQUFFLENBQUMsQ0FBQyxJQUFJLElBQUksUUFBUSxDQUFDLENBQUMsQ0FBQztnQ0FDbkIsTUFBTSxDQUFDLEtBQUssQ0FBQTs0QkFDaEIsQ0FBQzs0QkFDRCxLQUFLLEdBQUcsS0FBSyxHQUFHLENBQUMsQ0FBQzt3QkFDdEIsQ0FBQyxDQUFDLENBQUM7d0JBQ0gsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQztvQkFDcEQsQ0FBQztnQkFDTCxDQUFDO2dCQUdELHlDQUFpQixHQUFqQjtvQkFDSSxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxFQUFFLENBQUM7b0JBQ3BDLElBQUksY0FBYyxHQUFHLEVBQUUsQ0FBQztvQkFDeEIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDO3dCQUMxQix3QkFBYSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsRUFBRSxjQUFjLENBQUMsQ0FBQztvQkFDL0csQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFFRix3QkFBYSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsRUFBRSxjQUFjLENBQUMsQ0FBQztvQkFDaEgsQ0FBQztvQkFDRCxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUMsQ0FBQyxHQUFDLGNBQWMsQ0FBQyxNQUFNLEVBQUMsQ0FBQyxFQUFFLEVBQUMsQ0FBQzt3QkFDeEMsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDO3dCQUNkLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ2hELElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFFOUMsQ0FBQztnQkFFTCxDQUFDO2dCQUVELDRCQUFJLEdBQUo7b0JBQ0csaUJBQWlCO29CQUNoQixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7d0JBQ3hCLElBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO3dCQUV0Qiw2QkFBNkI7d0JBQzdCLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsZ0JBQWdCLENBQUM7b0JBQ2xFLENBQUM7b0JBQ0QsSUFBSSxDQUFDLENBQUM7d0JBQ04sSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7d0JBQ3JCLDhCQUE4Qjt3QkFDOUIsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxnQkFBZ0IsQ0FBQztvQkFDOUQsQ0FBQztvQkFDRCxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7Z0JBQzFCLENBQUM7Z0JBQ0QscUNBQWEsR0FBYixVQUFjLFNBQVM7b0JBQXZCLGlCQXVEQztvQkF0REcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxDQUFDLFNBQVMsQ0FDdkQsVUFBQyxJQUFJO3dCQUNELFdBQVc7d0JBQ1gsRUFBRTt3QkFDRixtQkFBbUI7d0JBQ25CLEVBQUUsQ0FBQyxDQUFDLFNBQVMsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDOzRCQUNyQixNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDOzRCQUN2QyxJQUFJLEdBQUcsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQTs0QkFDckMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLGFBQWEsQ0FBQztnQ0FDL0IsWUFBWSxFQUFFLElBQUk7Z0NBQ2xCLFVBQVUsRUFBRTtvQ0FDUixhQUFhLEVBQUUsSUFBSTtpQ0FDdEI7Z0NBQ0QsNEJBQTRCO2dDQUM1QixVQUFVLEVBQUUsR0FBRzs2QkFDbEIsQ0FBQyxDQUFDOzRCQUNILElBQUksTUFBTSxHQUFHLEVBQUUsQ0FBQzs0QkFFaEIsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRTtnQ0FDeEMsTUFBTSxJQUFJLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxHQUFHLENBQUM7NEJBQ2hELENBQUMsQ0FBQyxDQUFDOzRCQUNILEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDcEIsd0JBQWEsQ0FBQyxlQUFlLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLEVBQUUsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFBOzRCQUN2SSxDQUFDO3dCQUNMLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQzs0QkFDeEMsSUFBSSxHQUFHLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUE7NEJBQ3JDLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQyxhQUFhLENBQUM7Z0NBQ2hDLFlBQVksRUFBRSxJQUFJO2dDQUNsQixVQUFVLEVBQUU7b0NBQ1IsYUFBYSxFQUFFLElBQUk7aUNBQ3RCO2dDQUNELDRCQUE0QjtnQ0FDNUIsVUFBVSxFQUFFLEdBQUc7NkJBQ2xCLENBQUMsQ0FBQzs0QkFDSCxJQUFJLE1BQU0sR0FBRyxFQUFFLENBQUM7NEJBQ2hCLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUU7Z0NBQ3hDLE1BQU0sSUFBSSxJQUFJLENBQUMsc0JBQXNCLEdBQUcsR0FBRyxDQUFDOzRCQUNoRCxDQUFDLENBQUMsQ0FBQzs0QkFDSCxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQ3BCLHdCQUFhLENBQUMsZUFBZSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxFQUFFLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQTs0QkFDeEksQ0FBQzt3QkFDTCxDQUFDO3dCQUNELHdGQUF3RjtvQkFDNUYsQ0FBQyxFQUNELFVBQUMsR0FBRztvQkFFSixDQUFDLEVBQ0Q7b0JBRUEsQ0FBQyxDQUNKLENBQUM7Z0JBRU4sQ0FBQztnQkFDRCx3Q0FBZ0IsR0FBaEIsVUFBaUIsS0FBVTtvQkFFdkIsOENBQThDO29CQUM5Qyx1QkFBdUI7b0JBQ3ZCLDZHQUE2RztvQkFDekcsb0VBQW9FO29CQUN4RSx3QkFBd0I7b0JBQ3hCLGlDQUFpQztvQkFDakMsd0ZBQXdGO29CQUV4RixvREFBb0Q7b0JBQ3BELDZDQUE2QztvQkFDN0MseUNBQXlDO29CQUN6QyxlQUFlO29CQUNmLG9CQUFvQjtvQkFDcEIscUNBQXFDO29CQUNyQyxnREFBZ0Q7b0JBQ2hELDRFQUE0RTtvQkFDNUUsMERBQTBEO29CQUMxRCx5REFBeUQ7b0JBRXpELG1CQUFtQjtvQkFFbkIsZUFBZTtvQkFDZixzQkFBc0I7b0JBQ3RCLGlDQUFpQztvQkFDakMsb0JBQW9CO29CQUNwQiwwQ0FBMEM7b0JBQzFDLGFBQWE7b0JBQ2IsOEJBQThCO29CQUM5QixPQUFPO29CQUVQLEdBQUc7b0JBQ0gsc0JBQXNCO2dCQUMxQixDQUFDO2dCQUVELHNDQUFjLEdBQWQ7b0JBQUEsaUJBeUNDO29CQXZDRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsYUFBYSxFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFDcEQsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQ3RELE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLElBQUksb0JBQW9CLEdBQUcsRUFBRSxDQUFDOzRCQUM5QixNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUU7Z0NBQ3ZCLElBQUksT0FBTyxHQUFHLEVBQUUsQ0FBQztnQ0FDakIsT0FBTyxDQUFDLEVBQUUsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO2dDQUN4QixPQUFPLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUM7Z0NBQ3pCLG9CQUFvQixDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQzs0QkFDdkMsQ0FBQyxDQUFDLENBQUM7NEJBQ0gsS0FBSSxDQUFDLFdBQVcsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDOzRCQUNqQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsU0FBUyxDQUFDO2dDQUN2QixxQkFBcUI7Z0NBQ3JCLE1BQU0sRUFBRSxvQkFBb0I7Z0NBQzVCLGtCQUFrQjtnQ0FDbEIsUUFBUSxFQUFFLE1BQU07NkJBSW5CLENBQUMsQ0FBQzt3QkFHUCxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO2dCQUNQLENBQUM7Z0JBQ0QsZ0NBQVEsR0FBUjtvQkFBQSxpQkE0ZUM7b0JBM2VHLE1BQU0sQ0FBQyxlQUFlLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFLENBQUMsQ0FBQztvQkFDbkQsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO29CQUN2QixZQUFZO29CQUNYLDhDQUE4QztvQkFDOUMsRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO3dCQUNyQyxZQUFZLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQztvQkFDdkMsQ0FBQztvQkFDRCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7d0JBRWhELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLElBQUksRUFBRSxFQUFFLENBQUMsQ0FBQztvQkFDdEQsQ0FBQztvQkFDRCxJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQztvQkFDdEIsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO29CQUN0QixJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQztvQkFFNUIsa0NBQWtDO29CQUVsQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUNsQywrQkFBK0I7d0JBQy9CLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO3dCQUVsQyxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGNBQWMsQ0FBQzt3QkFDN0Qsd0VBQXdFO3dCQUN4RSxtQ0FBbUM7d0JBRW5DLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7NEJBQ2hELElBQUksS0FBSyxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUM7NEJBRS9DLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLE9BQU8sQ0FBQyxDQUFDOzRCQUM3RCxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztnQ0FDakIsS0FBSyxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQzs0QkFDN0MsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDOzRCQUNkLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQzs0QkFDdEIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO2dDQUMzRyxRQUFRLEdBQUcsTUFBTSxDQUFDOzRCQUN0QixDQUFDOzRCQUNELE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRTtnQ0FDNUIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxRQUFRLENBQUMsQ0FBQyxDQUFDO29DQUV4QixJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztvQ0FDbEIsTUFBTSxDQUFDLEtBQUssQ0FBQztnQ0FDakIsQ0FBQzs0QkFFTCxDQUFDLENBQUMsQ0FBQzs0QkFDSCxJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixHQUFHLENBQUMsRUFBRSxNQUFNLEVBQUUsRUFBRSxFQUFFLE9BQU8sRUFBRSxFQUFFLEVBQUUsUUFBUSxFQUFFLEVBQUUsRUFBRSxHQUFHLEVBQUUsRUFBRSxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsT0FBTyxFQUFFLEVBQUUsRUFBRSxhQUFhLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsV0FBVyxFQUFFLFdBQVcsRUFBRSxTQUFTLEVBQUUsQ0FBQyxDQUFDO3dCQUMzTyxDQUFDO3dCQUNELElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQTt3QkFDMUQsSUFBSSxDQUFDLGVBQWUsR0FBRyxLQUFLLENBQUM7b0JBRWpDLENBQUM7b0JBQ0QsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUNwRCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUN2QixJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUN6RCxDQUFDO29CQUNELElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO29CQUMxQix5SkFBeUo7b0JBRXhKLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzt3QkFDcEIsSUFBSSxDQUFDLFdBQVcsR0FBRyxPQUFPLENBQUM7d0JBQzNCLElBQUksQ0FBQyxTQUFTLEdBQUcsVUFBVSxDQUFDO3dCQUM1QixJQUFJLENBQUMsWUFBWSxHQUFHLGFBQWEsQ0FBQztvQkFJdEMsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixJQUFJLENBQUMsU0FBUyxHQUFHLFVBQVUsQ0FBQzt3QkFDNUIsSUFBSSxDQUFDLFlBQVksR0FBRyxZQUFZLENBQUM7b0JBQ3JDLENBQUM7b0JBR0YsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUN6RSxXQUFXO3dCQUNYLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUN0RCxPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsR0FBRyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7NEJBQ3pCLEtBQUksQ0FBQyxZQUFZLEdBQUcsS0FBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsZ0JBQWdCLENBQUM7NEJBQzlELEtBQUksQ0FBQyxTQUFTLEdBQUcsS0FBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsa0JBQWtCLENBQUM7NEJBQzdELEtBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsWUFBWSxDQUFDOzRCQUMzRCxLQUFJLENBQUMsaUJBQWlCLEdBQUcsS0FBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsZ0JBQWdCLENBQUM7NEJBQ25FLEtBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsY0FBYyxDQUFDO3dCQUVuRSxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUNILDZCQUE2QjtvQkFFN0IsVUFBVTtvQkFLVixJQUFJLFdBQVcsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQztvQkFDM0MsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUM7b0JBQ3JDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsV0FBVyxFQUFFLFNBQVMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7d0JBQ3RFLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUN0RCxPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixJQUFJLGVBQWUsR0FBRyxFQUFFLENBQUM7NEJBQ3pCLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRTtnQ0FDdkIsSUFBSSxPQUFPLEdBQUcsRUFBRSxDQUFDO2dDQUNqQixPQUFPLENBQUMsRUFBRSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7Z0NBQ3hCLE9BQU8sQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQztnQ0FDekIsZUFBZSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQzs0QkFDbEMsQ0FBQyxDQUFDLENBQUM7NEJBQ0gsS0FBSSxDQUFDLE9BQU8sR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDOzRCQUM3QixNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDO2dDQUN0QixxQkFBcUI7Z0NBQ3JCLE1BQU0sRUFBRSxlQUFlO2dDQUN2QixrQkFBa0I7Z0NBQ2xCLFFBQVEsRUFBRSxNQUFNOzZCQUluQixDQUFDLENBQUM7d0JBQ1AsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFPRixJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO29CQUNuRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUVuRCxJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUN0RCxPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsVUFBVSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7NEJBQ2hDLEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxJQUFJLEVBQUUsSUFBSSxLQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksSUFBSSxTQUFTLElBQUksS0FBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQztnQ0FDMUgsSUFBSSxVQUFVLENBQUM7Z0NBQ2YsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsVUFBVSxFQUFFO29DQUN6QixVQUFVLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztvQ0FDeEIsTUFBTSxDQUFDLEtBQUssQ0FBQztnQ0FDakIsQ0FBQyxDQUFDLENBQUM7Z0NBQ0gsS0FBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEdBQUcsVUFBVSxDQUFDOzRCQUM5QyxDQUFDO3dCQUNMLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBR0gsV0FBVztvQkFDWCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDN0MsSUFBSSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDdEQsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDOzRCQUM5QixFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixJQUFJLEVBQUUsSUFBSSxLQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixJQUFJLFNBQVMsSUFBSSxLQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7Z0NBQ3RJLElBQUksTUFBTSxDQUFDO2dDQUNYLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLFFBQVEsRUFBRTtvQ0FDdkIsTUFBTSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7b0NBQ3BCLE1BQU0sQ0FBQyxLQUFLLENBQUM7Z0NBQ2pCLENBQUMsQ0FBQyxDQUFDO2dDQUNILEtBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLEdBQUcsTUFBTSxDQUFDOzRCQUM5QyxDQUFDO3dCQUNMLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBRUgsY0FBYztvQkFDZCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFDbkQsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQ3RELE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEtBQUksQ0FBQyxVQUFVLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzs0QkFDaEMsRUFBRSxDQUFDLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksRUFBRSxJQUFJLEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLFNBQVMsSUFBSSxLQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO2dDQUNwSCxJQUFJLEtBQUssQ0FBQztnQ0FDVixNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUksQ0FBQyxVQUFVLEVBQUU7b0NBQ3pCLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO29DQUNuQixNQUFNLENBQUMsS0FBSyxDQUFDO2dDQUNqQixDQUFDLENBQUMsQ0FBQztnQ0FDSCxLQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7NEJBQ3ZDLENBQUM7d0JBQ0wsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFDSCxhQUFhO29CQUNiLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUNsRCxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDdEQsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLFNBQVMsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO3dCQUNuQyxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUNILGVBQWU7b0JBQ2YsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGFBQWEsRUFBRSxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7d0JBQ3JELFlBQVk7d0JBQ1gsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQ3RELE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEtBQUksQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzs0QkFDakMsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDOzRCQUNkLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLFdBQVcsRUFBRTtnQ0FDMUIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxXQUFXLENBQUMsQ0FBQyxDQUFDO29DQUUzQixJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztvQ0FDbEIsTUFBTSxDQUFDLEtBQUssQ0FBQztnQ0FDakIsQ0FBQzs0QkFDTCxDQUFDLENBQUMsQ0FBQzs0QkFDSCxLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDO3dCQUN6RCxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUdILElBQUksUUFBUSxHQUFHLENBQUMsQ0FBQztvQkFDakIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQzdDLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQzt3QkFFZCxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUU7NEJBQzFCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksV0FBVyxDQUFDLENBQUMsQ0FBQztnQ0FFM0IsSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7Z0NBQ2xCLFFBQVEsR0FBRyxDQUFDLENBQUM7Z0NBQ2IsTUFBTSxDQUFDLEtBQUssQ0FBQzs0QkFDakIsQ0FBQzt3QkFDTCxDQUFDLENBQUMsQ0FBQzt3QkFFSCxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxDQUFDLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUUsTUFBTSxFQUFFLFlBQVksRUFBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDO29CQUd6TCxDQUFDO29CQUNELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUM3QyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxDQUFDLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLFNBQVMsRUFBRSxPQUFPLEVBQUUsYUFBYSxFQUFDLE9BQU8sRUFBRSxDQUFDLENBQUE7b0JBQ3pLLENBQUM7b0JBRUQsaUJBQWlCO29CQUNqQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsZUFBZSxFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFDdEQsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQ3RELE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEtBQUksQ0FBQyxhQUFhLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzs0QkFDcEMsWUFBWTs0QkFDWCxJQUFJLElBQUksR0FBRyxFQUFFLENBQUM7NEJBQ2QsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsYUFBYSxFQUFFO2dDQUM1QixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLE1BQU0sQ0FBQyxDQUFDLENBQUM7b0NBRXRCLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO29DQUNsQixNQUFNLENBQUMsS0FBSyxDQUFDO2dDQUNqQixDQUFDOzRCQUVMLENBQUMsQ0FBQyxDQUFDOzRCQUNILEtBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQzt3QkFDOUQsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFDSCxRQUFRO29CQUVSLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUNoRCxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDdEQsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLE9BQU8sR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO3dCQUNqQyxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUNILGFBQWE7b0JBRWIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksRUFBRSxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7d0JBQ25ELFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUN0RCxPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsVUFBVSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7d0JBQ3BDLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsVUFBVTtvQkFDVixJQUFJLFdBQVcsR0FBRSxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQztvQkFDMUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUMzRCxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDdEQsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLE9BQU8sR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO3dCQUNqQyxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUdILFlBQVk7b0JBRVoscUNBQXFDO29CQUNyQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFNBQVMsQ0FDNUQsVUFBQyxJQUFJO3dCQUNGLFlBQVk7d0JBQ1gsRUFBRSxDQUFDLENBQUMsS0FBSSxDQUFDLFNBQVMsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDOzRCQUMxQixNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDOzRCQUN2QyxJQUFJLEdBQUcsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQTs0QkFDckMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLGFBQWEsQ0FBQztnQ0FDL0IsWUFBWSxFQUFFLElBQUk7Z0NBQ2xCLFVBQVUsRUFBRTtvQ0FDUixhQUFhLEVBQUUsSUFBSTtpQ0FDdEI7Z0NBQ0QsNEJBQTRCO2dDQUM1QixVQUFVLEVBQUUsR0FBRzs2QkFFbEIsQ0FBQyxDQUFDOzRCQUNILElBQUksTUFBTSxHQUFHLEVBQUUsQ0FBQzs0QkFDaEIsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRTtnQ0FDeEMsTUFBTSxJQUFJLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxHQUFHLENBQUM7NEJBQ2hELENBQUMsQ0FBQyxDQUFDOzRCQUNILEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDcEIsd0JBQWEsQ0FBQyxlQUFlLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLEVBQUUsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFBOzRCQUN2SSxDQUFDO3dCQUNMLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQzs0QkFDeEMsSUFBSSxHQUFHLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUE7NEJBQ3JDLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQyxhQUFhLENBQUM7Z0NBQ2hDLFlBQVksRUFBRSxJQUFJO2dDQUNsQixVQUFVLEVBQUU7b0NBQ1IsYUFBYSxFQUFFLElBQUk7aUNBQ3RCO2dDQUNELDRCQUE0QjtnQ0FDNUIsVUFBVSxFQUFFLEdBQUc7NkJBQ2xCLENBQUMsQ0FBQzs0QkFDSCxJQUFJLE1BQU0sR0FBRyxFQUFFLENBQUM7NEJBQ2hCLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUU7Z0NBQ3hDLE1BQU0sSUFBSSxJQUFJLENBQUMsc0JBQXNCLEdBQUcsR0FBRyxDQUFDOzRCQUNoRCxDQUFDLENBQUMsQ0FBQzs0QkFDSCxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQ3BCLHdCQUFhLENBQUMsZUFBZSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxFQUFFLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQTs0QkFDeEksQ0FBQzt3QkFDTCxDQUFDO29CQUNMLENBQUMsRUFDRCxVQUFDLEdBQUc7b0JBRUosQ0FBQyxFQUNEO29CQUVBLENBQUMsQ0FDSixDQUFDO29CQUlGLDhDQUE4QztvQkFDL0MsaURBQWlEO29CQUNoRCxJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUM7b0JBRXBCLGNBQWM7b0JBQ2QsTUFBTSxDQUFDLHlDQUF5QyxDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO29CQUN0RSxNQUFNLENBQUMsc0NBQXNDLENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ25FLHNCQUFzQjtnQkFFMUIsQ0FBQztnQkF4cUVNLHFCQUFPLEdBQUcsQ0FBQyxRQUFRLEVBQUUsV0FBVyxFQUFFLGVBQWUsQ0FBQyxDQUFDO2dCQXZEOUQ7b0JBQUMsZ0JBQVMsQ0FBQzt3QkFFUCxXQUFXLEVBQUUsNkNBQTZDO3dCQUMxRCxVQUFVLEVBQUUsQ0FBQyxpQkFBUSxFQUFFLHFCQUFZLEVBQUUsd0JBQWUsRUFBRSx1QkFBdUIsRUFBRSx3QkFBZSxFQUFFLHdCQUFlLEVBQUUsMEJBQVEsQ0FBQzt3QkFDMUgsU0FBUyxFQUFFLENBQUMsaUNBQWUsRUFBRSxpQ0FBZSxDQUFDO3FCQUNoRCxDQUFDOztpQ0FBQTtnQkEydEVGLG9CQUFDO1lBQUQsQ0F6dEVBLEFBeXRFQyxJQUFBO1lBenRFRCx5Q0F5dEVDLENBQUEiLCJmaWxlIjoiYW1heC9DdXN0b21lci9DdXN0b21lclByb2ZpbGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge05nU3dpdGNoLCBOZ1N3aXRjaFdoZW4sIE5nU3dpdGNoRGVmYXVsdCwgQ09SRV9ESVJFQ1RJVkVTLCBGT1JNX0RJUkVDVElWRVN9IGZyb20gJ2FuZ3VsYXIyL2NvbW1vbidcclxuaW1wb3J0IHtSZXNvdXJjZVNlcnZpY2V9IGZyb20gXCIuLi8uLi9zZXJ2aWNlcy9SZXNvdXJjZVNlcnZpY2VcIjtcclxuaW1wb3J0IHtSb3V0ZVBhcmFtc30gZnJvbSBcImFuZ3VsYXIyL3JvdXRlclwiO1xyXG5pbXBvcnQge0NvbXBvbmVudCwgT3V0cHV0LCBJbnB1dCwgRXZlbnRFbWl0dGVyLCBPbkluaXR9IGZyb20gXCJhbmd1bGFyMi9jb3JlXCI7XHJcbmltcG9ydCB7Q3VzdG9tZXJTZXJ2aWNlfSBmcm9tIFwiLi4vLi4vc2VydmljZXMvQ3VzdG9tZXJTZXJ2aWNlXCI7XHJcbmltcG9ydCB7IGpzb25RIH0gZnJvbSAnLi4vLi4vanNvblEnO1xyXG5pbXBvcnQge0dyb3VwRmlsdGVyUGlwZSwgR3JvdXBQYXJlbkZpbHRlclBpcGUsIEtlbmRvX3V0aWxpdHl9IGZyb20gXCIuLi8uLi9hbWF4VXRpbFwiO1xyXG5pbXBvcnQge0F1dG9jb21wbGV0ZUNvbnRhaW5lcn0gZnJvbSAnLi4vLi4vYXV0b2NvbXBsZXRlL2F1dG9jb21wbGV0ZS1jb250YWluZXInO1xyXG5pbXBvcnQge0F1dG9jb21wbGV0ZX0gZnJvbSAnLi4vLi4vYXV0b2NvbXBsZXRlL2F1dG9jb21wbGV0ZS5jb21wb25lbnQnO1xyXG5pbXBvcnQgeyBBbWF4RGF0ZSB9IGZyb20gJy4uLy4uL2NvbW9uQ29tcG9uZW50cy9iYXNpY0NvbXBvbmVudHMnO1xyXG5cclxuZXhwb3J0IGNvbnN0IEFVVE9DT01QTEVURV9ESVJFQ1RJVkVTID0gW0F1dG9jb21wbGV0ZSwgQXV0b2NvbXBsZXRlQ29udGFpbmVyXTtcclxuZGVjbGFyZSB2YXIgalF1ZXJ5O1xyXG5kZWNsYXJlIHZhciBzd2FsO1xyXG5kZWNsYXJlIHZhciBtb21lbnQ7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuXHJcbiAgICB0ZW1wbGF0ZVVybDogJy4vYXBwL2FtYXgvQ3VzdG9tZXIvdGVtcGxhdGVzL2N1c3RvbWVyLmh0bWwnLFxyXG4gICAgZGlyZWN0aXZlczogW05nU3dpdGNoLCBOZ1N3aXRjaFdoZW4sIE5nU3dpdGNoRGVmYXVsdCwgQVVUT0NPTVBMRVRFX0RJUkVDVElWRVMsIENPUkVfRElSRUNUSVZFUywgRk9STV9ESVJFQ1RJVkVTLCBBbWF4RGF0ZV0sXHJcbiAgICBwcm92aWRlcnM6IFtDdXN0b21lclNlcnZpY2UsIFJlc291cmNlU2VydmljZV1cclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBBbWF4Q3VzdG9tZXJzIGltcGxlbWVudHMgT25Jbml0IHtcclxuICAgIG1vZGVsSW5wdXQgPSB7fTtcclxuICAgIFRlbXBtb2RlbElucHV0ID0ge307XHJcbiAgICBjdXN0U2VhcmNoRGF0YTogT2JqZWN0ID0gW107XHJcbiAgICBSRVM6IE9iamVjdCA9IHt9O1xyXG4gICAgU2VsZWN0ZWRQaFR5cGU6IE9iamVjdCA9IHt9O1xyXG4gICAgdGVtcHN0cmVldG1zZzogc3RyaW5nID0gXCJcIjtcclxuICAgIEZvcm10eXBlOiBzdHJpbmcgPVwiQ1VTVE9NRVJfTUFTVEVSXCI7XHJcbiAgICBMYW5nOiBzdHJpbmc9XCJcIjtcclxuICAgIC8vbW9kZWxJbnB1dC5sbmFtZT0gXCJcIjtcclxuICAgIFNob3dNb3JlOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBJc1JlY29yZEVkaXRNb2RlOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBTaG93TW9yZVRleHQ6IHN0cmluZyA9IFwiTW9yZVwiO1xyXG5cclxuICAgIFNob3dMb2FkZXI6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIFNob3dNc2c6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIFNob3dHcm91cHM6IGJvb2xlYW4gPSB0cnVlO1xyXG4gICAgR3JvdXBUZXh0OiBzdHJpbmc9XCJTaG93IEdyb3Vwc1wiO1xyXG4gICAgTXNnOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgTXNnQ2xhc3M6IHN0cmluZyA9IFwidGV4dC1wcmltYXJ5XCI7XHJcbiAgICBJc2J0bmRpc2FibGU6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBJc0ZpbGVBc1NhdmVCdG46IHN0cmluZyA9IFwiXCI7XHJcbiAgICBJc0ZpbGVBc0NhbmNlbEJ0bjogc3RyaW5nID0gXCJcIjtcclxuICAgIGxhbmd1YWdlQXJyYXkgPSBbXTtcclxuXHJcbiAgICBBZGRyZXNzOiBPYmplY3QgPSB7fTtcclxuICAgIFBob25lTW9kZWw6IE9iamVjdCA9IHt9O1xyXG4gICAgRW1haWxNb2RlbDogT2JqZWN0ID0ge307XHJcbiAgICBJc1Nob3dBbGw6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIEN1c3RMaXN0OiBPYmplY3QgPSB7fTtcclxuICAgIFNBVkVfQlROX1RFWFQ6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBcclxuICAgIEJUTl9QSEFERDogc3RyaW5nID0gXCJcIjtcclxuICAgIEVkaXRQaG9uZURhdGE6IE9iamVjdCA9IHt9O1xyXG4gICAgRWRpdEFkZHJlc3NEYXRhOiBPYmplY3QgPSB7fTtcclxuICAgIEVkaXRFbWFpbERhdGE6IE9iamVjdCA9IHt9O1xyXG4gICAgYWRJZDogc3RyaW5nO1xyXG4gICAgSXNGaWxlQXNPcGVuOiBib29sZWFuO1xyXG4gICAgQUREX05FV19DVVNUX1RFWFQ6IHN0cmluZztcclxuICAgIENTU1RFWFQ6IHN0cmluZztcclxuICAgIElzRmlsZUFzdHh0U2hvdzogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgRklMRUFTX0JUTl9URVhUOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgY3NzRmlsZUFzQnRuOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgSXNDYW5jZWw6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIFNlYXJjaFZhbDogc3RyaW5nID0gXCJcIjtcclxuICAgIEVudGVyQ291bnQ6IG51bWJlciA9IDA7XHJcbiAgICBTdG9wVGltZU91dDogYW55O1xyXG4gICAgQ3VzdElkVGV4dDogc3RyaW5nID0gXCJcIjtcclxuICAgIHN0YXRpYyAkaW5qZWN0ID0gWyckc2NvcGUnLCAnJGxvY2F0aW9uJywgJyRhbmNob3JTY3JvbGwnXTtcclxuICAgIEJhc2VBcHBVcmw6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBQaEluZGV4OiBudW1iZXIgPSAwO1xyXG4gICAgS2VuZG9SVExDU1M6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBDSEFOR0VESVI6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBDaGFuZ2VEaWFsb2c6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBJc1BvcFVwOiBib29sZWFuID0gdHJ1ZTtcclxuXHJcbiAgICBcclxuXHJcbiAgICAvL0lzRmlsZUFzU2F2ZTogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgXHJcbiAgICAvL0VtYWlsOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgLy9DdXN0b21lckVtYWlsOiBPYmplY3QgPSB7fTtcclxuICAgIC8vbW9kZWxJbnB1dC5DdXN0b21lckVtYWlscyA9IFtdO1xyXG4gICAgXHJcbiAgICBfQ3VzdFR5cGVzID0gW107XHJcbiAgICBfU291cmNlcyA9IFtdO1xyXG4gICAgX0VtcGxveWVlcyA9IFtdO1xyXG4gICAgX1N1ZmZpeGVzID0gW107XHJcbiAgICBfUGhvbmVUeXBlcyA9IFtdO1xyXG4gICAgX0FkZHJlc3NUeXBlcyA9IFtdO1xyXG4gICAgX0dyb3VwcyA9IFtdO1xyXG4gICAgX0NvdW50cmllcyA9IFtdO1xyXG4gICAgX1N0YXRlcyA9IFtdO1xyXG4gICAgX0NpdGllcyA9IFtdO1xyXG4gICAgX0N1c3RUaXRsZXMgPSBbXTtcclxuICAgIHByaXZhdGUgc2VsZWN0ZWRDYXI6IHN0cmluZyA9ICcnO1xyXG4gICAgcHJpdmF0ZSBhc3luY1NlbGVjdGVkQ2FyOiBzdHJpbmcgPSAnJztcclxuICAgIHByaXZhdGUgYXV0b2NvbXBsZXRlTG9hZGluZzogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHJpdmF0ZSBhdXRvY29tcGxldGVOb1Jlc3VsdHM6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHByaXZhdGUgYXV0b2NvbXBsZXRlU2VsZWN0OiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBcclxuICAgIHByaXZhdGUgZ2V0Q3VycmVudENvbnRleHQoKSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgcmV0dXJuIHRoaXM7XHJcbiAgICB9XHJcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIF9yZXNvdXJjZVNlcnZpY2U6IFJlc291cmNlU2VydmljZSwgcHJpdmF0ZSBfY3VzdG9tZXJTZXJ2aWNlOiBDdXN0b21lclNlcnZpY2UsIHByaXZhdGUgX3JvdXRlUGFyYW1zOiBSb3V0ZVBhcmFtcykge1xyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5CaXJ0aERhdGUgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3NlcyA9IFtdO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lcyA9IFtdO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlscyA9IFtdO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckdyb3VwcyA9IFtdO1xyXG4gICAgICAgIHRoaXMuQWRkcmVzcy5Db3VudHJ5Q29kZT1cIlwiO1xyXG4gICAgICAgIHRoaXMuQWRkcmVzcy5TdGF0ZUlkID0gXCJcIjtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuZW1wbG95ZWVpZCA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyVHlwZSA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkNhbWVGcm9tQ3VzdG9tZXIgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5TYWZpeGlkID0gXCJcIjtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuR2VuZGVyID0gXCIwXCI7XHJcbiAgICAgICAgdGhpcy5QaG9uZU1vZGVsLlBob25lVHlwZUlkID0gXCJcIjtcclxuICAgICAgICB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIgPSB7fTtcclxuICAgICAgICB0aGlzLklzU2hvd0FsbCA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMuU0FWRV9CVE5fVEVYVCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfQlROX1NBVkU7XHJcbiAgICAgICAgdGhpcy5CVE5fUEhBREQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0JUTl9QSEFERDtcclxuICAgICAgICB0aGlzLkFERF9ORVdfQ1VTVF9URVhUID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9MQkxfTkVXX0NVU1Q7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzID0gW3sgRW1haWw6IFwiXCIsIEVtYWlsTmFtZTogXCJcIiwgTmV3c2xldHRlcmU6IHRydWUsIHB1Ymxpc2g6IDEsIE5ld3NPcmRlcjogXCJOZXdzMVwiLCBFUHVibGlzaE9yZGVyOlwiRVB1YjFcIiB9XVxyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lcyA9IFt7IFBob25lVHlwZUlkOiBcIlwiLCBQcmVmaXg6IFwiXCIsIEFyZWE6IFwiXCIsIFBob25lOiBcIlwiLCBJc1NtczogMSwgQ29tbWVudHM6IFwiXCIsIElzU2hvd1JlbWFya3M6IGZhbHNlLCBwaHB1Ymxpc2g6IDEsIFNNU09yZGVyOiBcIlNNUzFcIixQdWJsaXNoT3JkZXI6IFwiUHViMVwifV1cclxuICAgICAgIC8vIGRlYnVnZ2VyO1xyXG4gICAgICAgIHZhciBlbXBpZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiZW1wbG95ZWVpZFwiKTtcclxuICAgICAgICBcclxuICAgICAgICB2YXIgY2NvZGUgPSB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZ2V0Q29va2llKGVtcGlkICsgXCJjY29kZVwiKTtcclxuICAgICAgICBpZiAoY2NvZGUubGVuZ3RoID4gMClcclxuICAgICAgICAgICAgY2NvZGUgPSBjY29kZS5zdWJzdHJpbmcoMSwgY2NvZGUubGVuZ3RoKTtcclxuXHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzID0gW3tcclxuICAgICAgICAgICAgU3RyZWV0OiBcIlwiLCBTdHJlZXQyOiBcIlwiLCBDaXR5TmFtZTogXCJcIiwgWmlwOiBcIlwiLCBDb3VudHJ5Q29kZTogY2NvZGUsIFN0YXRlSWQ6IFwiXCIsIEFkZHJlc3NUeXBlSWQ6IFwiXCIsXHJcbiAgICAgICAgICAgIEZvckRlbGl2ZXJ5OiB0cnVlLCBNYWluQWRkcmVzczogdHJ1ZSwgTWFpbk9yZGVyOiBcIk1haW5BZGRyMVwiLCBEZWx2cnlPcmRlcjogXCJEZWx2cnkxXCJcclxuICAgICAgICB9XVxyXG5cclxuICAgICAgICBcclxuICAgICAgICBcclxuXHJcbiAgICAgICAgdmFyIGN1c3R0eXBlID0gdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmdldENvb2tpZShlbXBpZCArIFwiY3VzdFwiKTtcclxuICAgICAgICBpZiAoY3VzdHR5cGUubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgY3VzdHR5cGUgPSBjdXN0dHlwZS5zdWJzdHJpbmcoMSwgY3VzdHR5cGUubGVuZ3RoKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyVHlwZSA9IGN1c3R0eXBlO1xyXG5cclxuXHJcbiAgICAgICAgdmFyIGVtcCA9IHRoaXMuX3Jlc291cmNlU2VydmljZS5nZXRDb29raWUoZW1waWQgKyBcImVtcFwiKTtcclxuICAgICAgICBpZiAoZW1wLmxlbmd0aCA+IDApXHJcbiAgICAgICAgICAgIGVtcCA9IGVtcC5zdWJzdHJpbmcoMSwgZW1wLmxlbmd0aCk7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LmVtcGxveWVlaWQgPSBlbXA7XHJcblxyXG4gICAgICAgIHZhciBzb3VyY2UgPSB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZ2V0Q29va2llKGVtcGlkICsgXCJzcmNcIik7XHJcbiAgICAgICAgaWYgKHNvdXJjZS5sZW5ndGggPiAwKVxyXG4gICAgICAgICAgICBzb3VyY2UgPSBzb3VyY2Uuc3Vic3RyaW5nKDEsIHNvdXJjZS5sZW5ndGgpO1xyXG4gICAgICAgIGVsc2Uge1xyXG5cclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkNhbWVGcm9tQ3VzdG9tZXIgPSBzb3VyY2U7XHJcbiAgICAgICAgdGhpcy5DU1NURVhUID0gXCJtZGktY29udGVudC1hZGRcIjtcclxuICAgICAgICB0aGlzLmNzc0ZpbGVBc0J0biA9IFwibWRpLWNvbnRlbnQtY3JlYXRlXCI7XHJcbiAgICAgICAgdGhpcy5Jc0ZpbGVBc3R4dFNob3cgPSBmYWxzZTtcclxuICAgICAgICBjbGVhclRpbWVvdXQodGhpcy5TdG9wVGltZU91dCk7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQgPSBfcm91dGVQYXJhbXMucGFyYW1zLklkO1xyXG4gICAgICAgIHRoaXMuQmFzZUFwcFVybCA9IF9yZXNvdXJjZVNlcnZpY2UuQXBwVXJsO1xyXG4gICAgICAgIHRoaXMuVGVtcG1vZGVsSW5wdXQgPSB0aGlzLm1vZGVsSW5wdXQ7XHJcbiAgICAgICAgXHJcbiAgICAgICAgLy9hbGVydCh0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZ2V0Q29va2llKGVtcGlkICsgXCJjdXN0XCIpKTtcclxuICAgICAgICAvL3RoaXMuU2hvd01vcmVUZXh0ID0gXCJNb3JlXCI7XHJcbiAgICAgICAgXHJcbiAgICB9XHJcbiAgICBwcml2YXRlIF9jYWNoZWRSZXN1bHQ6IGFueTtcclxuICAgIHByaXZhdGUgX3ByZXZpb3VzYXN5bmNTZWxlY3RlZENhcjogc3RyaW5nPScnO1xyXG4gICAgXHJcbiAgICBkYXRlU2VsZWN0aW9uQ2hhbmdlKGV2dCkge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGV2dCk7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkJpcnRoRGF0ZSA9IGV2dDtcclxuICAgICAgIC8vIGFsZXJ0KHRoaXMubW9kZWxJbnB1dC5CaXJ0aERhdGUpO1xyXG4gICAgICAgIC8vdGhpcy52YWxpZGF0ZUxvZ2luKCk7XHJcbiAgICB9XHJcblxyXG4gICBwcml2YXRlIGdldEFzeW5jRGF0YShjb250ZXh0OiBhbnkpOiBGdW5jdGlvbiB7XHJcbiAgICAgICAgXHJcbiAgICAgICB2YXIgU3JjaFZhbCA9IGNvbnRleHQuYXN5bmNTZWxlY3RlZENhcjtcclxuICAgICAgXHJcbiAgICAgIC8vIGlmIChTcmNoVmFsICE9IHVuZGVmaW5lZCAmJiBTcmNoVmFsICE9IG51bGwgJiYgU3JjaFZhbCAhPSBcIlwiKSB7XHJcblxyXG4gICAgICAgXHJcbiAgICAgICAgIC8vIGRlYnVnZ2VyO1xyXG4gICAgICAgaWYgKHRoaXMuX3ByZXZpb3VzYXN5bmNTZWxlY3RlZENhciA9PSBjb250ZXh0LmFzeW5jU2VsZWN0ZWRDYXIpIHtcclxuICAgICAgICAgICAgICAgLy9jbGVhclRpbWVvdXQodGhpcy5TdG9wVGltZU91dCk7XHJcbiAgICAgICAgICAgICAgIHJldHVybiB0aGlzLl9jYWNoZWRSZXN1bHQ7XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgLy9hbGVydCh0aGlzLl9wcmV2aW91c2FzeW5jU2VsZWN0ZWRDYXIgKyBcIiB8IFwiICsgY29udGV4dC5hc3luY1NlbGVjdGVkQ2FyKTtcclxuICAgICAgICAgICAgICAgaWYgKGNvbnRleHQuYXN5bmNTZWxlY3RlZENhciAhPSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICB0aGlzLl9wcmV2aW91c2FzeW5jU2VsZWN0ZWRDYXIgPSBjb250ZXh0LmFzeW5jU2VsZWN0ZWRDYXI7XHJcbiAgICAgICAgICAgICAgICAgLy8gIHRoaXMuU3RvcFRpbWVPdXQgPSBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgIC8vICAgIGFsZXJ0KFNyY2hWYWwpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRDb21wbGV0ZVNlYXJjaChTcmNoVmFsKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vYWxlcnQocmVzcG9uc2UuRXJyTXNnKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe21lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRleHQuY2Fyc0V4YW1wbGUxID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vcmV0dXJuIGNvbnRleHQuY2Fyc0V4YW1wbGUxO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgLy8gfSwgNTAwKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICB0aGlzLl9jYWNoZWRSZXN1bHQgPSBjb250ZXh0LmNhcnNFeGFtcGxlMTtcclxuICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgIHRoaXMuX2NhY2hlZFJlc3VsdCA9IFtdO1xyXG4gICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgIHJldHVybiB0aGlzLl9jYWNoZWRSZXN1bHQ7XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgICAgIFxyXG4gICAgICAgIFxyXG4gICAgfVxyXG4gICBcclxuICAgIHByaXZhdGUgY2hhbmdlQXV0b2NvbXBsZXRlTG9hZGluZyhlOiBib29sZWFuKSB7XHJcbiAgICAgICAgdGhpcy5hdXRvY29tcGxldGVMb2FkaW5nID0gZTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIGNoYW5nZUF1dG9jb21wbGV0ZU5vUmVzdWx0cyhlOiBib29sZWFuKSB7XHJcbiAgICAgICAgdGhpcy5hdXRvY29tcGxldGVTZWxlY3QgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLmF1dG9jb21wbGV0ZU5vUmVzdWx0cyA9IGU7XHJcbiAgICB9XHJcbiAgICBwcml2YXRlIGF1dG9jb21wbGV0ZU9uU2VsZWN0KGU6IGFueSkge1xyXG4gICAgICAgIHRoaXMuYXV0b2NvbXBsZXRlU2VsZWN0ID0gdHJ1ZTtcclxuICAgICAgICBjb25zb2xlLmxvZyhgU2VsZWN0ZWQgdmFsdWU6ICR7ZS5pdGVtfWApO1xyXG4gICAgICAgIHZhciBDb21wRGF0YSA9IGUuaXRlbS5zcGxpdCgnfCcpO1xyXG4gICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAgaWYgKGUuaXRlbSAhPSB1bmRlZmluZWQgJiYgZS5pdGVtICE9IFwiXCIgJiYgZS5pdGVtICE9IG51bGwpIHtcclxuICAgICAgICAgICAgLy9hbGVydChDb21wRGF0YVswXSk7XHJcbiAgICAgICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRDb21wbGV0ZUN1c3REZXQoQ29tcERhdGFbMF0udHJpbSgpKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAvL2FsZXJ0KHJlc3BvbnNlLkVyck1zZyk7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7bWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgICAgLy8gYWxlcnQodGhpcy5tb2RlbElucHV0LkJpcnRoRGF0ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5TQVZFX0JUTl9URVhUID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9CVE5fVVBEQVRFO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuQUREX05FV19DVVNUX1RFWFQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0xCTF9ORVdfQ1VTVDtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLkNTU1RFWFQgPSBcIm1kaS1jb250ZW50LWNyZWF0ZVwiO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMubGVuZ3RoID09IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzID0gW3sgRW1haWw6IFwiXCIsIEVtYWlsTmFtZTogdGhpcy5tb2RlbElucHV0LkZpbGVBcywgTmV3c2xldHRlcmU6IGZhbHNlIH1dXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLk5ld3NsZXR0ZXJlID09IFwiMVwiKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuTmV3c2xldHRlcmUgPSBmYWxzZTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLk5ld3NsZXR0ZXJlID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXMubGVuZ3RoID09IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHBoaWQgPSBcIlwiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLl9QaG9uZVR5cGVzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5UZXh0ID09IFwiQ2VsbFBob25lXCIpIHtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGhpZCA9IHRoaXMuVmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lcyA9IFt7IFBob25lVHlwZUlkOiBwaGlkLCBQcmVmaXg6IFwiXCIsIEFyZWE6IFwiXCIsIFBob25lOiBcIlwiLCBJc1NtczogMCwgQ29tbWVudHM6IFwiXCIsIHBocHVibGlzaDogMCB9XTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMubGVuZ3RoID09IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGVtcGlkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJlbXBsb3llZWlkXCIpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGNjb2RlID0gdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmdldENvb2tpZShlbXBpZCArIFwiY2NvZGVcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChjY29kZS5sZW5ndGggPiAwKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2NvZGUgPSBjY29kZS5zdWJzdHJpbmcoMSwgY2NvZGUubGVuZ3RoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGFkaWQgPSBcIlwiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgY29tcHRleHQgPSBcIkhvbWVcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5Db21wYW55ICE9IFwiXCIgJiYgdGhpcy5tb2RlbElucHV0LkNvbXBhbnkgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dC5Db21wYW55ICE9IG51bGwpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbXB0ZXh0ID0gXCJXb3JrXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5fQWRkcmVzc1R5cGVzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5UZXh0ID09IGNvbXB0ZXh0KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWRpZCA9IHRoaXMuVmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3NlcyA9IFt7IFN0cmVldDogXCJcIiwgU3RyZWV0MjogXCJcIiwgQ2l0eU5hbWU6IFwiXCIsIFppcDogXCJcIiwgQ291bnRyeUNvZGU6IGNjb2RlLCBTdGF0ZUlkOiBcIlwiLCBBZGRyZXNzVHlwZUlkOiBhZGlkLCBGb3JEZWxpdmVyeTogZmFsc2UsIE1haW5BZGRyZXNzOiBmYWxzZSB9XTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuQ3VzdElkVGV4dCA9IFwiKCBcIiArIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkICsgXCIgKVwiO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuSXNGaWxlQXN0eHRTaG93ID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgLy90aGlzLklzQ2FuY2VsID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICAvL3RoaXMuSGlkZVNob3dGaWxlQXN0eHQoKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLkNhbmNlbEZpbGVBc3R4dCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuSXNTaG93QWxsID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICAvL3RoaXMuYmluZEdyb3VwKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9hbGVydCh0aGlzLlJFUyk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5iaW5kR3JvdXBUcmVlKHRydWUpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIE9wZW5OZXdSZWNlaXB0KCkge1xyXG4gICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkICE9IHVuZGVmaW5lZCAmJiB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCA+PSAwKSB7XHJcbiAgICAgICAgICAgIHZhciBjdXN0SWQgPSB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZDtcclxuICAgICAgICAgICAgaWYgKGN1c3RJZCAhPSAtMSkge1xyXG4gICAgICAgICAgICAgICAgdmFyIGVtaWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImVtcGxveWVlaWRcIik7XHJcbiAgICAgICAgICAgICAgICBkb2N1bWVudC5sb2NhdGlvbiA9IHRoaXMuQmFzZUFwcFVybCArIFwiUmVjZWlwdFNlbGVjdC9cIiArIGVtaWQgKyBcIi9cIiArIGN1c3RJZDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIE9wZW5DaGFyZ2VDcmVkaXRQYWdlKCkge1xyXG4gICAgICAgIHRoaXMuSXNidG5kaXNhYmxlID0gXCJkaXNhYmxlZFwiO1xyXG4gICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5DaGVja0lzT3BlbkNoYXJnZSgpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2cocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICBcclxuXHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZywgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7ICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSB9fSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLkRhdGEgIT0gdW5kZWZpbmVkICYmIHJlc3BvbnNlLkRhdGEgIT0gbnVsbCAmJiByZXNwb25zZS5EYXRhLmxlbmd0aCA9PSAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIGN1c3RJZCA9IC0xO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLlRlbXBtb2RlbElucHV0ICE9IHVuZGVmaW5lZCAmJiB0aGlzLlRlbXBtb2RlbElucHV0LkN1c3RvbWVySWQgIT0gdW5kZWZpbmVkICYmIHRoaXMuVGVtcG1vZGVsSW5wdXQuQ3VzdG9tZXJJZCA+PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGN1c3RJZCA9IHRoaXMuVGVtcG1vZGVsSW5wdXQuQ3VzdG9tZXJJZFxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0ICE9IHVuZGVmaW5lZCAmJiB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQgPj0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjdXN0SWQgPSB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZFxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAoY3VzdElkICE9IC0xKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRvY3VtZW50LmxvY2F0aW9uID0gdGhpcy5CYXNlQXBwVXJsICsgXCJDaGFyZ2VDcmVkaXQvXCIgKyBjdXN0SWQgKyBcIi9cIiArIHJlc3BvbnNlLkRhdGFbMF0uVmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiAnUGxlYXNlIHNhdmUgbmV3IG9yIGxvYWQgcHJldmlvdXMgY3VzdG9tZXIgYW5kIHRoZW4gY2xpY2sgb24gY2hhcmdlIGNyZWRpdCBidXR0b24nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKHJlc3BvbnNlLkRhdGEgIT0gdW5kZWZpbmVkICYmIHJlc3BvbnNlLkRhdGEgIT0gbnVsbCAmJiByZXNwb25zZS5EYXRhLmxlbmd0aCA+IDEpIHtcclxuICAgICAgICAgICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBjdXN0SWQgPSAtMTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5UZW1wbW9kZWxJbnB1dCAhPSB1bmRlZmluZWQgJiYgdGhpcy5UZW1wbW9kZWxJbnB1dC5DdXN0b21lcklkICE9IHVuZGVmaW5lZCAmJiB0aGlzLlRlbXBtb2RlbElucHV0LkN1c3RvbWVySWQgPj0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjdXN0SWQgPSB0aGlzLlRlbXBtb2RlbElucHV0LkN1c3RvbWVySWRcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dCAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkID49IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY3VzdElkID0gdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWRcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGN1c3RJZCAhPSAtMSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBkb2N1bWVudC5sb2NhdGlvbiA9IHRoaXMuQmFzZUFwcFVybCArIFwiVGVybWluYWxzL1Nob3cvXCIgKyBjdXN0SWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6ICdQbGVhc2Ugc2F2ZSBuZXcgb3IgbG9hZCBwcmV2aW91cyBjdXN0b21lciBhbmQgdGhlbiBjbGljayBvbiBjaGFyZ2UgY3JlZGl0IGJ1dHRvbicsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgIC8vIGFsZXJ0KHJlc3BvbnNlLkRhdGEubGVuZ3RoICsgJyBUZXJtaW5hbCBTY3JlZW4gaGVsbG8nKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX01TR19DSEFSR0VDUkVESVQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRoaXMuU2hvd01zZyA9IHRydWU7XHJcbiAgICAgICAgICAgIHRoaXMuTXNnID0gcmVzcG9uc2UuRXJyTXNnO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgICAgIGVycm9yPT4gY29uc29sZS5sb2coZXJyb3IpLFxyXG4gICAgICAgICAgICAoKSA9PiBjb25zb2xlLmxvZyhcIlNhdmUgQ2FsbCBDb21wbGVhdGVkXCIpXHJcbiAgICAgICAgKTtcclxuICAgICAgICB0aGlzLklzYnRuZGlzYWJsZSA9IFwiXCI7XHJcbiAgICB9XHJcbiAgICBTdG9wVGltZXIoKTogb2JzZXJ2YWJsZSB7XHJcbiAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgIG1lc3NhZ2U6ICdGcm9tIFN0b3AgVGltZXInICsgdGhpcy5TdG9wVGltZU91dCwgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGNsZWFyVGltZW91dCh0aGlzLlN0b3BUaW1lT3V0KTtcclxuICAgIH1cclxuICAgIFNldGRlZmF1bHRQYWdlKCl7XHJcbiAgICAgICAgZG9jdW1lbnQubG9jYXRpb24gPSB0aGlzLkJhc2VBcHBVcmwgKyBcIkN1c3RvbWVyL0FkZC8tMVwiO1xyXG4gICAgICAgIHRoaXMuSXNGaWxlQXN0eHRTaG93ID0gdHJ1ZTtcclxuICAgICAgICB0aGlzLklzQ2FuY2VsID0gdHJ1ZTtcclxuICAgICAgICBcclxuICAgICAgICB2YXIgZW1waWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImVtcGxveWVlaWRcIik7XHJcbiAgICAgICAgdGhpcy5hc3luY1NlbGVjdGVkQ2FyID0gXCJcIjtcclxuICAgICAgICBcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQgPSB7fTtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQmlydGhEYXRlID0gXCJcIjtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCA9IC0xO1xyXG4gICAgICAgIHRoaXMuQ3VzdElkVGV4dCA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5IaWRlU2hvd0ZpbGVBc3R4dCgpO1xyXG4gICAgICAgIHZhciBjdXN0dHlwZSA9IHRoaXMuX3Jlc291cmNlU2VydmljZS5nZXRDb29raWUoZW1waWQgKyBcImN1c3RcIik7XHJcbiAgICAgICAgaWYgKGN1c3R0eXBlLmxlbmd0aCA+IDApXHJcbiAgICAgICAgICAgIGN1c3R0eXBlID0gY3VzdHR5cGUuc3Vic3RyaW5nKDEsIGN1c3R0eXBlLmxlbmd0aCk7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyVHlwZSA9IGN1c3R0eXBlO1xyXG4gICAgICAgIHZhciBlbXAgPSB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZ2V0Q29va2llKGVtcGlkICsgXCJlbXBcIik7XHJcbiAgICAgICAgaWYgKGVtcC5sZW5ndGggPiAwKVxyXG4gICAgICAgICAgICBlbXAgPSBlbXAuc3Vic3RyaW5nKDEsIGVtcC5sZW5ndGgpO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5lbXBsb3llZWlkID0gZW1wO1xyXG4gICAgICAgIHZhciBzb3VyY2UgPSB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZ2V0Q29va2llKGVtcGlkICsgXCJzcmNcIik7XHJcbiAgICAgICAgaWYgKHNvdXJjZS5sZW5ndGggPiAwKVxyXG4gICAgICAgICAgICBzb3VyY2UgPSBzb3VyY2Uuc3Vic3RyaW5nKDEsIHNvdXJjZS5sZW5ndGgpO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DYW1lRnJvbUN1c3RvbWVyID0gc291cmNlO1xyXG5cclxuICAgICAgICB0aGlzLlNob3dNb3JlID0gZmFsc2U7XHJcbiAgICAgICAgLy90aGlzLlNob3dNb3JlVGV4dCA9IFwiTW9yZVwiOyBcclxuICAgICAgICB0aGlzLlNob3dNb3JlVGV4dCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfTE5LX0xCTF9NT1JFO1xyXG4gICAgICAgIHRoaXMuU0FWRV9CVE5fVEVYVCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfQlROX1NBVkU7XHJcbiAgICAgICAgdGhpcy5DU1NURVhUID0gXCJtZGktY29udGVudC1hZGRcIjtcclxuICAgICAgICB0aGlzLkFERF9ORVdfQ1VTVF9URVhUID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9MQkxfTkVXX0NVU1Q7XHJcbiAgICAgICAgdGhpcy5TaG93R3JvdXBzID0gdHJ1ZTtcclxuICAgICAgICB0aGlzLnNob3doaWRlR3JvdXBzKCk7XHJcbiAgICAgICAgLy90aGlzLkdyb3VwVGV4dCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfTEJMX1NIT1dHUk9VUFM7XHJcblxyXG4gICAgICAgIFxyXG5cclxuICAgICAgICB2YXIgcGhpZCA9IFwiXCI7XHJcbiAgICAgICAgdmFyIFNNUyA9IDA7XHJcbiAgICAgICAgdmFyIHB1Ymxpc2ggPSAwO1xyXG4gICAgICAgIHZhciBlcHVibGlzaCA9IDA7XHJcbiAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5fUGhvbmVUeXBlcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5UZXh0ID09IFwiQ2VsbFBob25lXCIpIHtcclxuXHJcbiAgICAgICAgICAgICAgICBwaGlkID0gdGhpcy5WYWx1ZTtcclxuICAgICAgICAgICAgICAgIFNNUyA9IDE7XHJcbiAgICAgICAgICAgICAgICBwdWJsaXNoID0gMTtcclxuICAgICAgICAgICAgICAgIGVwdWJsaXNoID0gMTtcclxuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXMgPSBbeyBQaG9uZVR5cGVJZDogcGhpZCwgUHJlZml4OiBcIlwiLCBBcmVhOiBcIlwiLCBQaG9uZTogXCJcIiwgSXNTbXM6IFNNUywgQ29tbWVudHM6IFwiXCIsIHBocHVibGlzaDogcHVibGlzaCB9XVxyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcblxyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlscyA9IFt7IEVtYWlsOiBcIlwiLCBFbWFpbE5hbWU6IFwiXCIsIE5ld3NsZXR0ZXJlOiBmYWxzZSwgcHVibGlzaDogZXB1Ymxpc2ggfV1cclxuICAgICAgICB2YXIgY250cnljb2RlID0gdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmdldENvb2tpZShlbXBpZCArIFwiY2NvZGVcIik7XHJcbiAgICAgICAgaWYgKGNudHJ5Y29kZS5sZW5ndGggPiAwKVxyXG4gICAgICAgICAgICBjbnRyeWNvZGUgPSBjbnRyeWNvZGUuc3Vic3RyaW5nKDEsIGNudHJ5Y29kZS5sZW5ndGgpO1xyXG5cclxuICAgICAgICB2YXIgYWRpZCA9IFwiXCI7XHJcbiAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5fQWRkcmVzc1R5cGVzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLlRleHQgPT0gXCJIb21lXCIpIHtcclxuXHJcbiAgICAgICAgICAgICAgICBhZGlkID0gdGhpcy5WYWx1ZTtcclxuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICB9KTtcclxuXHJcblxyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3NlcyA9IFt7IFN0cmVldDogXCJcIiwgU3RyZWV0MjogXCJcIiwgQ2l0eU5hbWU6IFwiXCIsIFppcDogXCJcIiwgQ291bnRyeUNvZGU6IGNudHJ5Y29kZSwgU3RhdGVJZDogXCJcIiwgQWRkcmVzc1R5cGVJZDogYWRpZCwgRm9yRGVsaXZlcnk6IGZhbHNlLCBNYWluQWRkcmVzczogZmFsc2UgfV1cclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJHcm91cHMgPSBbXTtcclxuICAgICAgICB0aGlzLkFkZHJlc3MuQ291bnRyeUNvZGUgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMuQWRkcmVzcy5TdGF0ZUlkID0gXCJcIjtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuU2FmaXhpZCA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkdlbmRlciA9IFwiMFwiO1xyXG4gICAgICAgIHRoaXMuU2hvd01zZyA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMuTXNnID0gXCJcIjtcclxuICAgICAgICB0aGlzLklzU2hvd0FsbCA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRHZW5lcmFsR3JvdXBzKHRoaXMuSXNTaG93QWxsKS5zdWJzY3JpYmUoXHJcbiAgICAgICAgICAgIChkYXRhKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLklzU2hvd0FsbCA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeShcIiNncm91cFRyZWVcIikuaHRtbChcIkxvZGluZy4uLlwiKTtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgcmVzID0galF1ZXJ5LnBhcnNlSlNPTihkYXRhKS5EYXRhXHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5KFwiI2dyb3VwVHJlZVwiKS5rZW5kb1RyZWVWaWV3KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbG9hZE9uRGVtYW5kOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjaGVja2JveGVzOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja0NoaWxkcmVuOiB0cnVlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vY2hlY2s6IHRoaXMub25Hcm91cFNlbGVjdCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGF0YVNvdXJjZTogcmVzXHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkoXCIjZ3JvdXBUcmVlMVwiKS5odG1sKFwiTG9kaW5nLi4uXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciByZXMgPSBqUXVlcnkucGFyc2VKU09OKGRhdGEpLkRhdGFcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkoXCIjZ3JvdXBUcmVlMVwiKS5rZW5kb1RyZWVWaWV3KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbG9hZE9uRGVtYW5kOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjaGVja2JveGVzOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja0NoaWxkcmVuOiB0cnVlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vY2hlY2s6IHRoaXMub25Hcm91cFNlbGVjdCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGF0YVNvdXJjZTogcmVzXHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIChlcnIpID0+IHtcclxuXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICgpID0+IHtcclxuXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICApO1xyXG5cclxuICAgICAgICB0aGlzLklzUG9wVXAgPSB0cnVlO1xyXG4gICAgfVxyXG4gICAgQ2FuY2VsRmlsZUFzdHh0KCkge1xyXG4gICAgICAgIHRoaXMuSXNGaWxlQXN0eHRTaG93ID0gdHJ1ZTtcclxuICAgICAgICB0aGlzLklzRmlsZUFzdHh0U2hvdyA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMuSXNDYW5jZWwgPSB0cnVlO1xyXG4gICAgICAgIGpRdWVyeShcIiNGaWxlQXN0eHRcIikuaGlkZSgpO1xyXG4gICAgICAgIGpRdWVyeShcIiNGaWxlQXNTcG5cIikuc2hvdygpO1xyXG4gICAgICAgIHRoaXMuRklMRUFTX0JUTl9URVhUID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9CVE5fRklMRUFTO1xyXG4gICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQgIT0gbnVsbCAmJiBwYXJzZUludCggdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQpID4tMSkge1xyXG4gICAgICAgICAgICBqUXVlcnkoXCIjRmlsZUFzU2F2ZUJ0blwiKS5zaG93KCk7XHJcbiAgICAgICAgICAgIHRoaXMuY3NzRmlsZUFzQnRuID0gXCJtZGktY29udGVudC1jcmVhdGVcIjtcclxuICAgICAgICAgICAgalF1ZXJ5KFwiI0ZpbGVBc0NhbmNlbEJ0blwiKS5oaWRlKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBqUXVlcnkoXCIjRmlsZUFzU2F2ZUJ0blwiKS5oaWRlKCk7XHJcbiAgICAgICAgICAgIGpRdWVyeShcIiNGaWxlQXNDYW5jZWxCdG5cIikuaGlkZSgpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIFxyXG4gICAgSGlkZVNob3dGaWxlQXN0eHQoKTogb2JzZXJ2YWJsZSB7XHJcbiAgICAgICBcclxuICAgICAgICBpZiAodGhpcy5Jc0ZpbGVBc3R4dFNob3cgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgdGhpcy5Jc0ZpbGVBc3R4dFNob3cgPSB0cnVlO1xyXG4gICAgICAgICAgICBqUXVlcnkoXCIjRmlsZUFzdHh0XCIpLnNob3coKTtcclxuICAgICAgICAgICAgalF1ZXJ5KFwiI0ZpbGVBc1NwblwiKS5oaWRlKCk7XHJcbiAgICAgICAgICAgIHRoaXMuSXNDYW5jZWwgPSBmYWxzZTtcclxuICAgICAgICAgICAgdGhpcy5GSUxFQVNfQlROX1RFWFQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0JUTl9TQVZFRklMRUFTO1xyXG4gICAgICAgICAgIC8vIGFsZXJ0KHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkKTtcclxuICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkICE9IHVuZGVmaW5lZCAmJiB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCAhPSBudWxsICYmIHBhcnNlSW50KCB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCkgPi0xKSB7XHJcbiAgICAgICAgICAgICAgICBqUXVlcnkoXCIjRmlsZUFzU2F2ZUJ0blwiKS5zaG93KCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNzc0ZpbGVBc0J0biA9IFwibWRpLWNvbnRlbnQtc2F2ZVwiO1xyXG4gICAgICAgICAgICAgICAgalF1ZXJ5KFwiI0ZpbGVBc0NhbmNlbEJ0blwiKS5zaG93KCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBqUXVlcnkoXCIjRmlsZUFzU2F2ZUJ0blwiKS5oaWRlKCk7XHJcbiAgICAgICAgICAgICAgICBqUXVlcnkoXCIjRmlsZUFzQ2FuY2VsQnRuXCIpLmhpZGUoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5Jc0ZpbGVBc3R4dFNob3cgPSBmYWxzZTtcclxuICAgICAgICAgICAgalF1ZXJ5KFwiI0ZpbGVBc3R4dFwiKS5oaWRlKCk7XHJcbiAgICAgICAgICAgIGpRdWVyeShcIiNGaWxlQXNTcG5cIikuc2hvdygpO1xyXG4gICAgICAgICAgICB0aGlzLkZJTEVBU19CVE5fVEVYVCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfQlROX0ZJTEVBUztcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQgIT0gbnVsbCAmJiBwYXJzZUludCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCk+LTEpIHtcclxuICAgICAgICAgICAgICAgIGpRdWVyeShcIiNGaWxlQXNTYXZlQnRuXCIpLnNob3coKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuY3NzRmlsZUFzQnRuID0gXCJtZGktY29udGVudC1jcmVhdGVcIjtcclxuICAgICAgICAgICAgICAgIGpRdWVyeShcIiNGaWxlQXNDYW5jZWxCdG5cIikuaGlkZSgpO1xyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkZpbGVBcyAhPSBcIlwiICYmIHRoaXMubW9kZWxJbnB1dC5GaWxlQXMgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dC5GaWxlQXMgIT0gbnVsbCAmJiB0aGlzLklzQ2FuY2VsID09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLlNhdmVGaWxlQXModGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQsIHRoaXMubW9kZWxJbnB1dC5GaWxlQXMpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9hbGVydCgnaGVsbG8nKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9hbGVydChyZXNwb25zZS5FcnJNc2cpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL3RoaXMuSXNGaWxlQXNTYXZlID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLklzQ2FuY2VsID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vZWxzZSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL31cclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0VNUFRZRklMRUFTLCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5iaW5kRmlsZUFzKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5Jc0ZpbGVBc3R4dFNob3cgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLkhpZGVTaG93RmlsZUFzdHh0KCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBqUXVlcnkoXCIjRmlsZUFzU2F2ZUJ0blwiKS5oaWRlKCk7XHJcbiAgICAgICAgICAgICAgICBqUXVlcnkoXCIjRmlsZUFzQ2FuY2VsQnRuXCIpLmhpZGUoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgIH1cclxuICAgIFNldEVtYWlsTmFtZSgpOiBvYnNlcnZhYmxlIHtcclxuICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkZpbGVBcyAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0LkZpbGVBcyAhPSBudWxsKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzW3RoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlscy5sZW5ndGggLSAxXS5FbWFpbE5hbWUgPSB0aGlzLm1vZGVsSW5wdXQuRmlsZUFzO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgQ2hlY2tDdXN0V2l0aFNhbWVOYW1lKCk6IG9ic2VydmFibGUge1xyXG5cclxuICAgIH1cclxuICAgIFNldERlZmF1bHRDdXN0KCkge1xyXG4gICAgICAgIC8vYWxlcnQoKTtcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG5cclxuICAgIH1cclxuXHJcbiAgICBzZXRkZWZhdWx0QWRkcmVzcygpIHtcclxuICAgICAgICBcclxuICAgICAgICB0aGlzLmJpbmRGaWxlQXMoKTtcclxuICAgICAgICB0aGlzLkNoZWNrQ3VzdFdpdGhmbmFtZWxuYW1lY29tcHBoc2VtYWlscygpO1xyXG4gICAgICAgIHZhciBhZGlkID0gXCJcIjtcclxuICAgICAgICB2YXIgYWR0ZXh0ID0gXCJIb21lXCI7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ29tcGFueSAhPSBcIlwiICYmIHRoaXMubW9kZWxJbnB1dC5Db21wYW55ICE9IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICBhZHRleHQgPSBcIldvcmtcIjtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGpRdWVyeS5lYWNoKHRoaXMuX0FkZHJlc3NUeXBlcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5UZXh0ID09IGFkdGV4dCkge1xyXG4gICAgICAgICAgICAgICAgYWRpZCA9IHRoaXMuVmFsdWU7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzW3RoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3Nlcy5sZW5ndGggLSAxXS5BZGRyZXNzVHlwZUlkID0gYWRpZDtcclxuICAgIH1cclxuICAgIGJpbmRGaWxlQXMoKTogb2JzZXJ2YWJsZSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5GaWxlQXMgPT0gXCJcIiB8fCB0aGlzLm1vZGVsSW5wdXQuRmlsZUFzID09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICBpZiAoKHRoaXMubW9kZWxJbnB1dC5Db21wYW55ID09IFwiXCIgfHwgdGhpcy5tb2RlbElucHV0LkNvbXBhbnkgPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgICAgICB2YXIgZmlsZWFzdGV4dCA9IFwiXCI7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LmZuYW1lICE9IFwiXCIgJiYgdGhpcy5tb2RlbElucHV0LmZuYW1lICE9IHVuZGVmaW5lZCAmJiB0aGlzLm1vZGVsSW5wdXQubG5hbWUgIT0gXCJcIiAmJiB0aGlzLm1vZGVsSW5wdXQubG5hbWUgIT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZmlsZWFzdGV4dCA9IHRoaXMubW9kZWxJbnB1dC5sbmFtZSArIFwiIFwiICsgdGhpcy5tb2RlbElucHV0LmZuYW1lO1xyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSBpZiAodGhpcy5tb2RlbElucHV0LmZuYW1lICE9IFwiXCIgJiYgdGhpcy5tb2RlbElucHV0LmZuYW1lICE9IHVuZGVmaW5lZCAmJiAodGhpcy5tb2RlbElucHV0LmxuYW1lID09IFwiXCIgfHwgdGhpcy5tb2RlbElucHV0LmxuYW1lID09IHVuZGVmaW5lZCkpIHtcclxuICAgICAgICAgICAgICAgICAgICBmaWxlYXN0ZXh0ID0gXCIgXCIgKyB0aGlzLm1vZGVsSW5wdXQuZm5hbWU7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIGlmICgodGhpcy5tb2RlbElucHV0LmZuYW1lID09IFwiXCIgfHwgdGhpcy5tb2RlbElucHV0LmZuYW1lID09IHVuZGVmaW5lZCkgJiYgKHRoaXMubW9kZWxJbnB1dC5sbmFtZSAhPSBcIlwiICYmIHRoaXMubW9kZWxJbnB1dC5sbmFtZSAhPSB1bmRlZmluZWQpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZmlsZWFzdGV4dCA9IHRoaXMubW9kZWxJbnB1dC5sbmFtZSArIFwiIFwiO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkZpbGVBcyA9IGZpbGVhc3RleHQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSBpZiAoKHRoaXMubW9kZWxJbnB1dC5sbmFtZSA9PSBcIlwiIHx8IHRoaXMubW9kZWxJbnB1dC5sbmFtZSA9PSB1bmRlZmluZWQpICYmICh0aGlzLm1vZGVsSW5wdXQuZm5hbWUgPT0gXCJcIiB8fCB0aGlzLm1vZGVsSW5wdXQubG5hbWUgPT0gdW5kZWZpbmVkKSkge1xyXG4gICAgICAgICAgICAgICAgdmFyIGZpbGVhc3RleHQgPSBcIlwiO1xyXG4gICAgICAgICAgICAgICAgaWYgKCh0aGlzLm1vZGVsSW5wdXQuQ29tcGFueSAhPSBcIlwiICYmIHRoaXMubW9kZWxJbnB1dC5Db21wYW55ICE9IHVuZGVmaW5lZCkpIHtcclxuICAgICAgICAgICAgICAgICAgICBmaWxlYXN0ZXh0ID0gdGhpcy5tb2RlbElucHV0LkNvbXBhbnk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuRmlsZUFzID0gZmlsZWFzdGV4dDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlXHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuRmlsZUFzID0gXCIoXCIgKyB0aGlzLm1vZGVsSW5wdXQuQ29tcGFueSArIFwiKSBcIiArIHRoaXMubW9kZWxJbnB1dC5sbmFtZSArIFwiIFwiICsgdGhpcy5tb2RlbElucHV0LmZuYW1lOyAvLysgXCIgXCIgJiBtX3N0clNwb3VzZVxyXG4gICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlsc1t0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMubGVuZ3RoIC0gMV0uRW1haWxOYW1lID0gdGhpcy5tb2RlbElucHV0LkZpbGVBcztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLlNldEVtYWlsTmFtZSgpO1xyXG4gICAgfVxyXG4gICAgYmluZEdyb3VwKCk6IHZvaWQge1xyXG4gICAgICAgIC8vYWxlcnQodGhpcy5Jc1Nob3dBbGwpOyB0aGlzIGZ1bmN0aW9uIGlzIGNhbGxpbmcgb24gY2xpY2sgb2YgY2hlY2tib3hcclxuICAgICAgICB2YXIgaXNzaG93ID0gZmFsc2U7XHJcbiAgICAgICAgaWYgKHRoaXMuSXNTaG93QWxsID09IHRydWUpIHtcclxuICAgICAgICAgICAgaXNzaG93ID0gZmFsc2VcclxuICAgICAgICAgICAgdGhpcy5Jc1Nob3dBbGwgPSBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuSXNTaG93QWxsID0gdHJ1ZTtcclxuICAgICAgICAgICAgaXNzaG93ID0gdHJ1ZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMuYmluZEdyb3VwVHJlZShpc3Nob3cpO1xyXG4gICAgfVxyXG4gICAgc2F2ZUN1c3RvbWVyRGF0YSgpOiB2b2lkIHtcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgIHRoaXMuSXNidG5kaXNhYmxlID0gXCJkaXNhYmxlZFwiO1xyXG4gICAgICAgIHRoaXMuU2hvd0xvYWRlciA9IHRydWU7XHJcbiAgICAgICAgdGhpcy5nZXRTZWxlY3RlZEdyb3VwcygpO1xyXG4gICAgICAgXHJcbiAgICAgICAgdmFyIGNvdW50ID0gMDtcclxuICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzICE9IHVuZGVmaW5lZCAmJiB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMgIT0gbnVsbCkge1xyXG4gICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLk1haW5BZGRyZXNzID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICBjb3VudCA9IGNvdW50ICsgMTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGlmIChjb3VudCA+IDEpIHtcclxuICAgICAgICAgICAgICAgICAgICAvL2Jvb3Rib3guYWxlcnQoXCJNYWluIEFkZHJlc3Mgc2hvbHVkIGJlIG9ubHkgb25lXCIpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICB0aGlzLklzYnRuZGlzYWJsZSA9IFwiXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5TaG93TG9hZGVyID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgLy9hbGVydCh0aGlzLm1vZGVsSW5wdXQuQmlydGhEYXRlKTtcclxuICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkJpcnRoRGF0ZSAhPSBcIlwiKSB7XHJcbiAgICAgICAgICAgIGlmIChtb21lbnQodGhpcy5tb2RlbElucHV0LkJpcnRoRGF0ZSwgXCJERC1NTS1ZWVlZXCIsIHRydWUpLmlzVmFsaWQoKSA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7IG1lc3NhZ2U6IFwiQmlydGhkYXRlIGlzIG5vdCB2YWxpZFwiIH0pO1xyXG5cclxuICAgICAgICAgICAgICAgIHRoaXMuSXNidG5kaXNhYmxlID0gXCJcIjtcclxuICAgICAgICAgICAgICAgIHRoaXMuU2hvd0xvYWRlciA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5UaXRsZSA9IGpRdWVyeShcIiNUaXRsZVwiKS52YWwoKTtcclxuICAgICAgICBpZiAoY291bnQgPD0gMSB8fCB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMgPT0gdW5kZWZpbmVkIHx8IHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3NlcyA9PSBudWxsKSB7XHJcblxyXG4gICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzICE9IHVuZGVmaW5lZCAmJiB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXMgIT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgdmFyIHBodGVtcCA9IFtdO1xyXG4gICAgICAgICAgICAgICAgalF1ZXJ5KCdpbnB1dFtuYW1lXj1cInBoXCJdJykuZWFjaChmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcGh0ZW1wLnB1c2goalF1ZXJ5KHRoaXMpLnZhbCgpKTtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgdmFyIGFydGVtcCA9IFtdO1xyXG4gICAgICAgICAgICAgICAgalF1ZXJ5KCdpbnB1dFtuYW1lXj1cImFyXCJdJykuZWFjaChmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYXJ0ZW1wLnB1c2goalF1ZXJ5KHRoaXMpLnZhbCgpKTtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgdmFyIHByZXRlbXAgPSBbXTtcclxuICAgICAgICAgICAgICAgIGpRdWVyeSgnaW5wdXRbbmFtZV49XCJwcmVcIl0nKS5lYWNoKGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgICAgICBwcmV0ZW1wLnB1c2goalF1ZXJ5KHRoaXMpLnZhbCgpKTtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgdmFyIGkgPSAwO1xyXG4gICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuSXNTbXMgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLklzU21zID0gXCIxXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLklzU21zID0gXCIwXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLnBocHVibGlzaCA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucGhwdWJsaXNoID0gXCIxXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnBocHVibGlzaCA9IFwiMFwiO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB0aGlzLlBob25lID0gcGh0ZW1wW2ldO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuQXJlYSA9IGFydGVtcFtpXTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLlByZWZpeCA9IHByZXRlbXBbaV07XHJcbiAgICAgICAgICAgICAgICAgICAgaSsrO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vdmFyIHRlbXAgPSB0aGlzLlBob25lVHlwZUlkLnNwbGl0KCc7Jyk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy90aGlzLlBob25lVHlwZUlkID0gcGFyc2VJbnQodGVtcFsxXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy90aGlzLlBob25lVHlwZSA9IHRlbXBbMF07XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlscyAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzICE9IG51bGwpIHtcclxuICAgICAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlscywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLnB1Ymxpc2ggPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnB1Ymxpc2ggPSBcIjFcIjtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucHVibGlzaCA9IFwiMFwiO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgIC8vIGRlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLk5ld3NsZXR0ZXJlID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5OZXdzbGV0dGVyZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5OZXdzbGV0dGVyZSA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIGkrKztcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHZhciBqZGF0YSA9IEpTT04uc3RyaW5naWZ5KHRoaXMubW9kZWxJbnB1dCk7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGpkYXRhKVxyXG4gICAgICAgICAgICB0aGlzLl9jdXN0b21lclNlcnZpY2UuQWRkQ3VzdG9tZXIoamRhdGEpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLklzYnRuZGlzYWJsZSA9IFwiXCI7XHJcbiAgICAgICAgICAgICAgICB0aGlzLlNob3dMb2FkZXIgPSBmYWxzZTtcclxuXHJcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9hbGVydChyZXNwb25zZS5FcnJNc2cpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuTXNnQ2xhc3MgPSBcInRleHQtZGFuZ2VyXCI7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAvL2FsZXJ0KHJlc3BvbnNlLkVyck1zZyk7XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5Nc2dDbGFzcyA9IFwidGV4dC1zdWNjZXNzXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIGVtcGlkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJlbXBsb3llZWlkXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5zZXRDb29raWUoZW1waWQgKyBcImN1c3RcIiwgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyVHlwZSwgMTApO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5zZXRDb29raWUoZW1waWQgKyBcImVtcFwiLCB0aGlzLm1vZGVsSW5wdXQuZW1wbG95ZWVpZCwgMTApO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5zZXRDb29raWUoZW1waWQgKyBcInNyY1wiLCB0aGlzLm1vZGVsSW5wdXQuQ2FtZUZyb21DdXN0b21lciwgMTApO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMubGVuZ3RoPjApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5zZXRDb29raWUoZW1waWQgKyBcImNjb2RlXCIsIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3Nlc1t0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMubGVuZ3RoIC0gMV0uQ291bnRyeUNvZGUsIDEwKTtcclxuICAgICAgICAgICAgICAgICAgIC8vIGRlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vZG9jdW1lbnQubG9jYXRpb24gPSB0aGlzLkJhc2VBcHBVcmwgKyBcIkN1c3RvbWVyL0FkZC8tMVwiO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5UZW1wbW9kZWxJbnB1dCA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0ID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmVkaXRDdXN0RGV0KHRoaXMubW9kZWxJbnB1dCk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy90aGlzLklzUG9wVXAgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vdGhpcy5TZXRkZWZhdWx0UGFnZSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIFJlc2V0IGZvcm0gdmFsdWVzXHJcbiAgICAgICAgICAgICAgICAgICAgLy90aGlzLl9DdXN0VHlwZXMgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgdGhpcy5TaG93TXNnID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIHRoaXMuTXNnID0gcmVzcG9uc2UuRXJyTXNnO1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgZXJyb3I9PiBjb25zb2xlLmxvZyhlcnJvciksXHJcbiAgICAgICAgICAgICAgICAoKSA9PiBjb25zb2xlLmxvZyhcIlNhdmUgQ2FsbCBDb21wbGVhdGVkXCIpXHJcbiAgICAgICAgICAgICk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfTVNHX0lTTUFJTkFERCwgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgdGhpcy5Jc2J0bmRpc2FibGUgPSBcIlwiO1xyXG4gICAgICAgICAgICB0aGlzLlNob3dMb2FkZXIgPSBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgQ2hlY2tDdXN0V2l0aGZuYW1lbG5hbWVjb21wcGhzZW1haWxzKCk6IG9ic2VydmFibGUge1xyXG4gICAgICAgIGlmICh0aGlzLklzUG9wVXAgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICB2YXIgamRhdGEgPSBKU09OLnN0cmluZ2lmeSh0aGlzLm1vZGVsSW5wdXQpO1xyXG4gICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICB2YXIgZm5hbWUgPSBcIlwiO1xyXG4gICAgICAgICAgICB2YXIgbG5hbWUgPSBcIlwiO1xyXG4gICAgICAgICAgICB2YXIgY29tcGFueSA9IFwiXCI7XHJcbiAgICAgICAgICAgIHZhciBwaG9uZXMgPSBcIlwiO1xyXG4gICAgICAgICAgICB2YXIgZW1haWxzID0gXCJcIjtcclxuXHJcbiAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuZm5hbWUgPT0gdW5kZWZpbmVkKVxyXG4gICAgICAgICAgICAgICAgZm5hbWUgPSBcIlwiO1xyXG4gICAgICAgICAgICBlbHNlXHJcbiAgICAgICAgICAgICAgICBmbmFtZSA9IHRoaXMubW9kZWxJbnB1dC5mbmFtZTtcclxuXHJcbiAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQubG5hbWUgPT0gdW5kZWZpbmVkKVxyXG4gICAgICAgICAgICAgICAgbG5hbWUgPSBcIlwiO1xyXG4gICAgICAgICAgICBlbHNlXHJcbiAgICAgICAgICAgICAgICBsbmFtZSA9IHRoaXMubW9kZWxJbnB1dC5sbmFtZTtcclxuICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5Db21wYW55ID09IHVuZGVmaW5lZClcclxuICAgICAgICAgICAgICAgIGNvbXBhbnkgPSBcIlwiO1xyXG4gICAgICAgICAgICBlbHNlXHJcbiAgICAgICAgICAgICAgICBjb21wYW55ID0gdGhpcy5tb2RlbElucHV0LkNvbXBhbnk7XHJcblxyXG4gICAgICAgICAgICBqUXVlcnkoJ2lucHV0W25hbWVePVwicGhcIl0nKS5lYWNoKGZ1bmN0aW9uICgpIHtcclxuXHJcbiAgICAgICAgICAgICAgICBpZiAoalF1ZXJ5KHRoaXMpLnZhbCgpICE9IFwiXCIgJiYgalF1ZXJ5KHRoaXMpLnZhbCgpICE9IHVuZGVmaW5lZCAmJiBqUXVlcnkodGhpcykudmFsKCkgIT0gbnVsbCAmJiBqUXVlcnkodGhpcykudmFsKCkubGVuZ3RoID49IDMpIHtcclxuICAgICAgICAgICAgICAgICAgICBwaG9uZXMgKz0galF1ZXJ5KHRoaXMpLnZhbCgpICsgXCInLCdcIjtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIGlmIChwaG9uZXMubGVuZ3RoID4gMCkgcGhvbmVzID0gcGhvbmVzLnN1YnN0cmluZygwLCBwaG9uZXMubGVuZ3RoIC0gMyk7XHJcbiAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlscywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuRW1haWwgIT0gXCJcIiAmJiB0aGlzLkVtYWlsICE9IHVuZGVmaW5lZCAmJiB0aGlzLkVtYWlsICE9IG51bGwgJiYgdGhpcy5FbWFpbC5sZW5ndGggPj0gMykge1xyXG4gICAgICAgICAgICAgICAgICAgIGVtYWlscyArPSB0aGlzLkVtYWlsICsgXCInLCdcIjtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICBpZiAoZW1haWxzLmxlbmd0aCA+IDApIGVtYWlscyA9IGVtYWlscy5zdWJzdHJpbmcoMCwgZW1haWxzLmxlbmd0aCAtIDMpO1xyXG4gICAgICAgICAgICBpZiAoKGZuYW1lICE9IFwiXCIgJiYgZm5hbWUubGVuZ3RoID49IDIgJiYgbG5hbWUgIT0gXCJcIiAmJiBsbmFtZS5sZW5ndGggPj0gMilcclxuICAgICAgICAgICAgICAgIHx8IChjb21wYW55ICE9IFwiXCIgJiYgY29tcGFueS5sZW5ndGggPj0gMylcclxuICAgICAgICAgICAgICAgIHx8IChwaG9uZXMgIT0gXCJcIilcclxuICAgICAgICAgICAgICAgIHx8IChlbWFpbHMgIT0gXCJcIikpIHtcclxuXHJcbiAgICAgICAgICAgICAgICB0aGlzLl9jdXN0b21lclNlcnZpY2UuR2V0Q3VzdG9tZXJzU2VhcmNoRGF0YShmbmFtZSwgbG5hbWUsIGNvbXBhbnksIHBob25lcywgZW1haWxzKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLkN1c3RMaXN0ID0ge307XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuQ3VzdExpc3QgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuRGF0YSAhPSBudWxsICYmIHJlc3BvbnNlLkRhdGEgIT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmN1c3RTZWFyY2hEYXRhID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGpRdWVyeSgnI0N1c3RNb2RhbCcpLm9wZW5Nb2RhbCgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2pRdWVyeSgnI0N1c3RNb2RhbCcpLm1vZGFsKCdvcGVuJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2pRdWVyeShcIiNDdXN0TW9kYWxcIikuc2hvdygxMDAwKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2FsZXJ0KHRoaXMuUkVTKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICAvL3RoaXMuYmluZEZpbGVBcygpO1xyXG4gICAgfVxyXG4gICAgQ2xvc2VNb2RhbFBvcCgpIHtcclxuICAgICAgICB0aGlzLkNsb3NlUG9wVXAoKTtcclxuICAgICAgICB0aGlzLklzUG9wVXAgPSBmYWxzZTtcclxuICAgIH1cclxuICAgIENsb3NlUG9wVXAoKSB7XHJcbiAgICAgICAgalF1ZXJ5KFwiI0N1c3RNb2RhbFwiKS5jbG9zZU1vZGFsKCk7XHJcbiAgICAgICAgalF1ZXJ5KFwiLmxlYW4tb3ZlcmxheVwiKS5jc3MoeyBcImRpc3BsYXlcIjogXCJub25lXCIgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgQ2hlY2tDdXN0V2l0aGZuYW1lbG5hbWUoZm5hbWUsIGxuYW1lLGNvbXBhbnkpOiBvYnNlcnZhYmxlIHtcclxuICAgICAgICB2YXIgamRhdGEgPSBKU09OLnN0cmluZ2lmeSh0aGlzLm1vZGVsSW5wdXQpO1xyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5mbmFtZSA9PSB1bmRlZmluZWQpXHJcbiAgICAgICAgICAgIGZuYW1lID0gXCJcIjtcclxuICAgICAgICBlbHNlXHJcbiAgICAgICAgICAgIGZuYW1lID0gdGhpcy5tb2RlbElucHV0LmZuYW1lO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LmxuYW1lID09IHVuZGVmaW5lZClcclxuICAgICAgICAgICAgbG5hbWUgPSBcIlwiO1xyXG4gICAgICAgIGVsc2VcclxuICAgICAgICAgICAgbG5hbWUgPSB0aGlzLm1vZGVsSW5wdXQubG5hbWU7XHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5Db21wYW55ID09IHVuZGVmaW5lZClcclxuICAgICAgICAgICAgY29tcGFueSA9IFwiXCI7XHJcbiAgICAgICAgZWxzZVxyXG4gICAgICAgICAgICBjb21wYW55ID0gdGhpcy5tb2RlbElucHV0LkNvbXBhbnk7XHJcbiAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkNoZWNrQ3VzdFdpdGhTYW1lTmFtZShmbmFtZSwgbG5hbWUsIGNvbXBhbnkpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuQ3VzdExpc3QgPSB7fTtcclxuICAgICAgICAgICAgICAgIHRoaXMuQ3VzdExpc3QgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLkRhdGEgIT0gbnVsbCAmJiByZXNwb25zZS5EYXRhICE9IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY3VzdFNlYXJjaERhdGEgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeShcIiNDdXN0TW9kYWxcIikub3Blbk1vZGFsKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9qUXVlcnkoXCIjQ3VzdE1vZGFsXCIpLnNob3coMTAwMCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvL2FsZXJ0KHRoaXMuUkVTKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuICAgICAgICAvL3RoaXMuYmluZEZpbGVBcygpO1xyXG4gICAgfVxyXG5cclxuXHJcblxyXG5cclxuICAgIENoZWNrQ3VzdFdpdGhFbWFpbCgpOiBvYnNlcnZhYmxlIHtcclxuICAgICAgICBcclxuICAgICAgICAvL3ZhciBFbWFpbCA9IFwiXCI7XHJcbiAgICAgICAgLy9pZiAodGhpcy5FbWFpbE1vZGVsLkVtYWlsICE9IFwiXCIgJiYgdGhpcy5FbWFpbE1vZGVsLkVtYWlsICE9IHVuZGVmaW5lZClcclxuICAgICAgICAvLyAgICBFbWFpbCA9IHRoaXMuRW1haWxNb2RlbC5FbWFpbDtcclxuICAgICAgICAvL3RoaXMuX2N1c3RvbWVyU2VydmljZS5DaGVja0N1c3RXaXRoU2FtZUVtYWlsKEVtYWlsKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgLy8gICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAvLyAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgIC8vICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAvLyAgICAgICAgYWxlcnQocmVzcG9uc2UuRXJyTXNnKTtcclxuICAgICAgICAvLyAgICB9XHJcbiAgICAgICAgLy8gICAgZWxzZSB7XHJcbiAgICAgICAgLy8gICAgICAgIHRoaXMuQ3VzdExpc3QgPSB7fTtcclxuICAgICAgICAvLyAgICAgICAgdGhpcy5DdXN0TGlzdCA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgLy8gICAgICAgIGlmIChyZXNwb25zZS5EYXRhICE9IG51bGwgJiYgcmVzcG9uc2UuRGF0YSAhPSB1bmRlZmluZWQpIHtcclxuICAgICAgICAvLyAgICAgICAgICAgIHRoaXMuY3VzdFNlYXJjaERhdGEgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgIC8vICAgICAgICAgICAgalF1ZXJ5KFwiI0N1c3RNb2RhbFwiKS5tb2RhbChcInNob3dcIik7XHJcbiAgICAgICAgLy8gICAgICAgIH1cclxuICAgICAgICAvLyAgICAgICAgLy9hbGVydCh0aGlzLlJFUyk7XHJcbiAgICAgICAgLy8gICAgfVxyXG4gICAgICAgIC8vfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgLy8gICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIC8vfSwgKCkgPT4ge1xyXG4gICAgICAgIC8vICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIC8vfSk7XHJcbiAgICB9XHJcbiAgICBDaGVja0N1c3RXaXRoUGhvbmUoKTogb2JzZXJ2YWJsZSB7XHJcbiAgICAgICAgdmFyIFBob25lID0gXCJcIjtcclxuICAgICAgICBpZiAodGhpcy5QaG9uZU1vZGVsLlBob25lICE9IFwiXCIgJiYgdGhpcy5QaG9uZU1vZGVsLlBob25lICE9IHVuZGVmaW5lZClcclxuICAgICAgICAgICAgUGhvbmUgPSB0aGlzLlBob25lTW9kZWwuUGhvbmU7XHJcbiAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkNoZWNrQ3VzdFdpdGhTYW1lUGhvbmUodGhpcy5QaG9uZU1vZGVsLlBob25lKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZywgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLkN1c3RMaXN0ID0ge307XHJcbiAgICAgICAgICAgICAgICB0aGlzLkN1c3RMaXN0ID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5EYXRhICE9IG51bGwgJiYgcmVzcG9uc2UuRGF0YSAhPSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmN1c3RTZWFyY2hEYXRhID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkoXCIjQ3VzdE1vZGFsXCIpLm9wZW5Nb2RhbCgpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLy9hbGVydCh0aGlzLlJFUyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcbiAgICBTaG93UmVtYXJrcyhQaE9iaik6IE9ic2VydmFibGUge1xyXG4gICAgICAgIGpRdWVyeS5lYWNoKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICBpZiAodGhpcyA9PSBQaE9iaikge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5Jc1Nob3dSZW1hcmtzID0gdHJ1ZTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICB9KTtcclxuICAgIH1cclxuICAgIHNob3dBZGRQb3B1cCgpOiBvYnNlcnZhYmxlIHtcclxuICAgICAgICB0aGlzLkFkZHJlc3MgPSB7fTtcclxuICAgICAgICB0aGlzLlBob25lTW9kZWwgPSB7fTtcclxuICAgICAgICB0aGlzLlBob25lTW9kZWwuUGhvbmVUeXBlSWQgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMuQWRkcmVzcy5Db3VudHJ5Q29kZSA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5BZGRyZXNzLlN0YXRlSWQgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMuQWRkcmVzcy5DaXR5TmFtZSA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5BZGRyZXNzLkFkZHJlc3NUeXBlSWQgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMuRW1haWxNb2RlbCA9IHt9O1xyXG4gICAgICAgIHRoaXMuQlROX1BIQUREID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9CVE5fUEhBRERcclxuICAgICAgICBcclxuXHJcbiAgICB9XHJcbiAgICBzaG93aGlkZUdyb3VwcygpOiBvYnNlcnZhYmxlIHtcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgIGlmICh0aGlzLlNob3dHcm91cHMgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgdGhpcy5TaG93R3JvdXBzID0gdHJ1ZTtcclxuICAgICAgICAgICAgdGhpcy5Hcm91cFRleHQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0xCTF9ISURFR1JPVVA7XHJcbiAgICAgICAgICAgIGpRdWVyeShcIiNHcnBEaXZcIikuc2hvdygxMDAwKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuU2hvd0dyb3VwcyA9IGZhbHNlO1xyXG4gICAgICAgICAgICB0aGlzLkdyb3VwVGV4dCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfTEJMX1NIT1dHUk9VUFM7XHJcbiAgICAgICAgICAgIGpRdWVyeShcIiNHcnBEaXZcIikuaGlkZSgxMDAwKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgfVxyXG5cclxuXHJcbiAgICBDYW5hZGRBZGRyZXNzKGFkb2JqKTogYm9vbGVhbiB7XHJcbiAgICAgICAgLy9hbGVydCgnSGVsbG8nKTtcclxuICAgICAgICByZXR1cm4gKGFkb2JqLlN0cmVldCAhPSB1bmRlZmluZWQgJiYgYWRvYmouU3RyZWV0ICE9IFwiXCIpXHJcbiAgICAgICAgICAgICYmIChhZG9iai5TdHJlZXQyICE9IHVuZGVmaW5lZCAmJiBhZG9iai5TdHJlZXQyICE9IFwiXCIpXHJcbiAgICAgICAgICAgIC8vJiYgKGFkb2JqLkNpdHlOYW1lICE9IHVuZGVmaW5lZCAmJiBhZG9iai5DaXR5TmFtZSAhPSBcIlwiKVxyXG4gICAgICAgICAgICAmJiAoYWRvYmouWmlwICE9IHVuZGVmaW5lZCAmJiBhZG9iai5aaXAgIT0gXCJcIikgXHJcbiAgICAgICAgICAgICYmIChhZG9iai5Db3VudHJ5Q29kZSAhPSB1bmRlZmluZWQgJiYgYWRvYmouQ291bnRyeUNvZGUgIT0gXCJcIiApXHJcbiAgICAgICAgICAgIC8vJiYgKHRoaXMuQWRkcmVzcy5TdGF0ZUlkICE9IHVuZGVmaW5lZCAmJiB0aGlzLkFkZHJlc3MuU3RhdGVJZCAhPSBcIlwiKVxyXG4gICAgICAgICAgICAmJiAoYWRvYmouQWRkcmVzc1R5cGVJZCAhPSB1bmRlZmluZWQgJiYgYWRvYmouQWRkcmVzc1R5cGVJZCAhPSBcIlwiKTtcclxuICAgIH1cclxuICAgIEFkZEFkZHJlc3NlcyhhZG9iaik6IG9ic2VydmFibGUge1xyXG4gICAgICAgIFxyXG4gICAgICAgIHZhciBJc01haW5BZGQgPSBmYWxzZTtcclxuICAgICAgICBhZG9iai5DaXR5TmFtZSA9IGpRdWVyeShcIiNDaXR5XCIpLnZhbCgpO1xyXG4gICAgICAgIFxyXG4gICAgICAgIGlmICh0aGlzLkNhbmFkZEFkZHJlc3MoYWRvYmopKSB7XHJcblxyXG4gICAgICAgICAgICB2YXIgZW1waWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImVtcGxveWVlaWRcIik7XHJcbiAgICAgICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5zZXRDb29raWUoZW1waWQgKyBcImNjb2RlXCIsIGFkb2JqLkNvdW50cnlDb2RlLCAxMCk7XHJcbiAgICAgICAgICAgIHZhciBhZGlkID0gXCJcIjtcclxuICAgICAgICAgICAgdmFyIGFkdGV4dCA9IFwiSG9tZVwiO1xyXG4gICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkNvbXBhbnkgIT0gXCJcIiAmJiB0aGlzLm1vZGVsSW5wdXQuQ29tcGFueSAhPSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgIGFkdGV4dCA9IFwiV29ya1wiO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMuX0FkZHJlc3NUeXBlcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuVGV4dCA9PSBhZHRleHQpIHtcclxuICAgICAgICAgICAgICAgICAgICBhZGlkID0gdGhpcy5WYWx1ZTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgdmFyIEFkZHJlc09iaiA9IHsgU3RyZWV0OiBcIlwiLCBTdHJlZXQyOiBcIlwiLCBDaXR5TmFtZTogXCJcIiwgWmlwOiBcIlwiLCBDb3VudHJ5Q29kZTogYWRvYmouQ291bnRyeUNvZGUsIFN0YXRlSWQ6IFwiXCIsIEFkZHJlc3NUeXBlSWQ6IGFkaWQsIEZvckRlbGl2ZXJ5OiBmYWxzZSwgTWFpbkFkZHJlc3M6IGZhbHNlLCwgTWFpbk9yZGVyOiBcIk1haW5BZGRyXCIgKyAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzLmxlbmd0aCsxKS50b1N0cmluZygpLCBEZWx2cnlPcmRlcjogXCJEZWx2cnlcIiArICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMubGVuZ3RoKzEpLnRvU3RyaW5nKCkgfTtcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgLy9qUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgIC8vICAgIGlmICh0aGlzLk1haW5BZGRyZXNzID09IHRydWUgJiYgYWRvYmouTWFpbkFkZHJlc3MgPT0gdHJ1ZSAmJiB0aGlzICE9IGFkb2JqKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgIGFkb2JqLk1haW5BZGRyZXNzID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgLy8gICAgfVxyXG4gICAgICAgICAgICAgICAgLy99KTtcclxuICAgICAgICAgICAgICAgIGlmIChJc01haW5BZGQgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMucHVzaChBZGRyZXNPYmopO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHZhciBtc2cgPSAnJztcclxuICAgICAgICAgICAgaWYgKGFkb2JqLlN0cmVldCA9PSB1bmRlZmluZWQgfHwgYWRvYmouU3RyZWV0ID09IFwiXCIpIHtcclxuICAgICAgICAgICAgICAgIC8vbXNnICs9ICdcXG5TdHJlZXQgaXMgbm90IGZpbGxlZCc7IEFQUF9BTF9NU0dfU1RSRUVUXHJcbiAgICAgICAgICAgICAgICBtc2cgKz0gJ1xcbicgKyB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0FMX01TR19TVFJFRVQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKGFkb2JqLlN0cmVldDIgPT0gdW5kZWZpbmVkIHx8IGFkb2JqLlN0cmVldDIgPT0gXCJcIikge1xyXG4gICAgICAgICAgICAgICAgLy9tc2cgKz0gJ1xcbkFyZWEgaXMgbm90IGZpbGxlZCc7XHJcbiAgICAgICAgICAgICAgICBtc2cgKz0gJ1xcbicgKyB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0FMX01TR19BUkVBO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8vaWYgKGFkb2JqLkNpdHlOYW1lID09IHVuZGVmaW5lZCB8fCBhZG9iai5DaXR5TmFtZSA9PSBcIlwiKVxyXG4gICAgICAgICAgICAvLyAgICAvL21zZyArPSAnXFxuQ2l0eSBpcyBub3QgZmlsbGVkJzsgXHJcbiAgICAgICAgICAgIC8vICAgIG1zZyArPSAnXFxuJyArIHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfQUxfTVNHX0NJVFk7XHJcbiAgICAgICAgICAgIGlmIChhZG9iai5aaXAgPT0gdW5kZWZpbmVkIHx8IGFkb2JqLlppcCA9PSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICAvL21zZyArPSAnXFxuWmlwIGlzIG5vdCBmaWxsZWQnOyBcclxuICAgICAgICAgICAgICAgIG1zZyArPSAnXFxuJyt0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0FMX01TR19aSVA7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKGFkb2JqLkNvdW50cnlDb2RlID09IHVuZGVmaW5lZCB8fCBhZG9iai5Db3VudHJ5Q29kZSA9PSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICAvL21zZyArPSAnXFxuQ291bnRyeSBpcyBub3Qgc2VsZWN0ZWQnO1xyXG4gICAgICAgICAgICAgICAgbXNnICs9ICdcXG4nICsgdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9BTF9NU0dfQ09VTlRSWTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAvL2lmICh0aGlzLkFkZHJlc3MuU3RhdGVJZCA9PSB1bmRlZmluZWQgfHwgdGhpcy5BZGRyZXNzLlN0YXRlSWQgPT0gXCJcIikge1xyXG4gICAgICAgICAgICAvLyAgICBtc2cgKz0gJ1xcblN0YXRlIGlzIG5vdCBzZWxlY3RlZCc7XHJcbiAgICAgICAgICAgIC8vfVxyXG4gICAgICAgICAgICBpZiAoYWRvYmouQWRkcmVzc1R5cGVJZCA9PSB1bmRlZmluZWQgfHwgYWRvYmouQWRkcmVzc1R5cGVJZCA9PSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICAvL21zZyArPSAnXFxuQWRkcmVzcyB0eXBlIGlzIG5vdCBzZWxlY3RlZCc7XHJcbiAgICAgICAgICAgICAgICBtc2cgKz0gJ1xcbicgKyB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0FMX01TR19BRFRZUEU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICBtZXNzYWdlOiBtc2csIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgIH1cclxuICAgIENhbmFkZFBob25lKHBob25lT2JqKTogYm9vbGVhbiB7XHJcbiAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAvL2FsZXJ0KHRoaXMuUGhvbmVNb2RlbC5QaG9uZVR5cGVJZCArICcgJyArIHRoaXMuUGhvbmVNb2RlbC5QaG9uZVR5cGUgKyAnICcgKyB0aGlzLlBob25lTW9kZWwuUHJlZml4ICsgJyAnICsgdGhpcy5QaG9uZU1vZGVsLkFyZWEgKyAnICcgKyB0aGlzLlBob25lTW9kZWwuUGhvbmUpO1xyXG4gICAgICAgIHJldHVybiAocGhvbmVPYmouUGhvbmVUeXBlSWQgIT0gdW5kZWZpbmVkICYmIHBob25lT2JqLlBob25lVHlwZUlkICE9IFwiXCIpXHJcbiAgICAgICAgICAgIC8vICYmICh0aGlzLlBob25lTW9kZWwuUGhvbmVUeXBlICE9IHVuZGVmaW5lZCYmIHRoaXMuUGhvbmVNb2RlbC5QaG9uZVR5cGUgIT0gXCJcIiApXHJcbiAgICAgICAgICAgIC8vJiYgKHRoaXMuUGhvbmVNb2RlbC5QcmVmaXggIT0gdW5kZWZpbmVkJiYgdGhpcy5QaG9uZU1vZGVsLlByZWZpeCAhPSBcIlwiICApXHJcbiAgICAgICAgICAgIC8vJiYgKHRoaXMuUGhvbmVNb2RlbC5BcmVhICE9IHVuZGVmaW5lZCYmdGhpcy5QaG9uZU1vZGVsLkFyZWEgIT0gXCJcIiAgKVxyXG4gICAgICAgICAgICAvLyYmIChwaG9uZU9iai5QaG9uZSAhPSB1bmRlZmluZWQgJiYgcGhvbmVPYmouUGhvbmUgIT0gXCJcIik7XHJcbiAgICAgICAgICAgIC8vJiYgKHRoaXMuUGhvbmVNb2RlbC5QcmVmaXggIT0gdW5kZWZpbmVkICYmIHRoaXMuUGhvbmVNb2RlbC5QcmVmaXgubGVuZ3RoICE9IDMpOyAgICAgICAgICAgIDtcclxuICAgIH1cclxuICAgIEFkZFBob25lcyhwaG9uZU9iaik6IG9ic2VydmFibGUge1xyXG4gICAgICAgIGlmICh0aGlzLkNhbmFkZFBob25lKHBob25lT2JqKSkge1xyXG5cclxuICAgICAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICAgICAgLy9pZiAodGhpcy5Jc1JlY29yZEVkaXRNb2RlID09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgIHZhciBwaGlkID0gXCJcIjtcclxuICAgICAgICAgICAgdmFyIFNNUyA9IDA7XHJcbiAgICAgICAgICAgIHZhciBwdWJsaXNoID0gMDtcclxuICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5fUGhvbmVUeXBlcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuVGV4dCA9PSBcIkNlbGxQaG9uZVwiKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHBoaWQgPSB0aGlzLlZhbHVlO1xyXG4gICAgICAgICAgICAgICAgICAgIFNNUyA9IDE7XHJcbiAgICAgICAgICAgICAgICAgICAgcHVibGlzaCA9IDE7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgdmFyIFBob25lT2JqID0geyBQaG9uZVR5cGVJZDogcGhpZCwgUGhvbmVUeXBlOiBcIlwiLCBQcmVmaXg6IFwiXCIsIEFyZWE6IFwiXCIsIFBob25lOiBcIlwiLCBJc1NtczogU01TLCBDb21tZW50czogXCJcIiwgSXNTaG93UmVtYXJrczogZmFsc2UsIHBocHVibGlzaDogcHVibGlzaCwgU01TT3JkZXI6IFwiU01TXCIgKyAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzLmxlbmd0aCArIDEpLnRvU3RyaW5nKCksIFB1Ymxpc2hPcmRlcjogXCJQdWJcIiArICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXMubGVuZ3RoICsgMSkudG9TdHJpbmcoKSB9O1xyXG4gICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzLnB1c2goUGhvbmVPYmopO1xyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIC8vdGhpcy5DaGVja0N1c3RXaXRoZm5hbWVsbmFtZWNvbXBwaHNlbWFpbHMoKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHZhciBtc2cgPSAnJztcclxuICAgICAgICAgICAgaWYgKHBob25lT2JqLlBob25lVHlwZUlkID09IHVuZGVmaW5lZCB8fCBwaG9uZU9iai5QaG9uZVR5cGVJZCA9PSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICAvL21zZyArPSAnXFxuUGhvbmUgdHlwZSBpcyBub3Qgc2VsZWN0ZWQnO1xyXG4gICAgICAgICAgICAgICAgbXNnICs9ICdcXG4nICsgdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9BTF9SRUdNU0dfUEhUWVBFO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8vaWYgKHBob25lT2JqLlBob25lID09IHVuZGVmaW5lZCB8fCBwaG9uZU9iai5QaG9uZSA9PSBcIlwiKSB7XHJcbiAgICAgICAgICAgIC8vICAgIC8vbXNnICs9ICdcXG5QaG9uZSBudW1iZXIgaXMgbm90IGZpbGxlZCc7XHJcbiAgICAgICAgICAgIC8vICAgIG1zZyArPSAnXFxuJyArIHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfQUxfUkVHTVNHX1BITk87XHJcbiAgICAgICAgICAgIC8vfVxyXG4gICAgICAgICAgICAvL2lmICh0aGlzLlBob25lTW9kZWwuUHJlZml4Lmxlbmd0aCE9Mykge1xyXG4gICAgICAgICAgICAvLyAgICBtc2cgKz0gJ1xcblByZWZpeCBtdXN0IG9mIDMgbnVtZXJpYyBkaWdpdHMnO1xyXG4gICAgICAgICAgICAvL31cclxuICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICBtZXNzYWdlOiBtc2csY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgfVxyXG4gICAgQ2FuYWRkRW1haWwoRW1haWxPYmopOiBib29sZWFuIHtcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgIC8vYWxlcnQoJ0hlbGxvJyk7XHJcbiAgICAgICAgcmV0dXJuIChFbWFpbE9iai5FbWFpbE5hbWUgIT0gdW5kZWZpbmVkICYmIEVtYWlsT2JqLkVtYWlsTmFtZSAhPSBcIlwiKTtcclxuICAgICAgICAvLyhFbWFpbE9iai5FbWFpbCAhPSB1bmRlZmluZWQgJiYgRW1haWxPYmouRW1haWwgIT0gXCJcIikgJiZcclxuICAgICAgICAgICAgIFxyXG4gICAgfVxyXG4gICAgQWRkRW1haWxzKEVtYWlsT2JqKTogb2JzZXJ2YWJsZSB7XHJcbiAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICBpZiAodGhpcy5DYW5hZGRFbWFpbChFbWFpbE9iaikpIHtcclxuICAgICAgICAgICAgdmFyIGVwdWJsaXNoID0gMDtcclxuICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5fUGhvbmVUeXBlcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICBpZiAodGhpcy5UZXh0ID09IFwiQ2VsbFBob25lXCIpIHtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICBlcHVibGlzaCA9IDE7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgLy9pZiAodGhpcy5Jc1JlY29yZEVkaXRNb2RlID09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgIHZhciBlT2JqID0ge307XHJcbiAgICAgICAgICAgIGVPYmouRW1haWwgPSBcIlwiO1xyXG4gICAgICAgICAgICBlT2JqLkVtYWlsTmFtZSA9IHRoaXMubW9kZWxJbnB1dC5GaWxlQXM7XHJcbiAgICAgICAgICAgIGVPYmouTmV3c2xldHRlcmUgPSB0cnVlO1xyXG4gICAgICAgICAgICBlT2JqLnB1Ymxpc2ggPSBlcHVibGlzaDtcclxuICAgICAgICAgICAgZU9iai5OZXdzT3JkZXI9IFwiTmV3c1wiICsgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlscy5sZW5ndGgrMSkudG9TdHJpbmcoKTtcclxuICAgICAgICAgICAgZU9iai5FUHVibGlzaE9yZGVyPSBcIkVQdWJcIiArICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMubGVuZ3RoICsgMSkudG9TdHJpbmcoKTtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlscy5wdXNoKGVPYmopO1xyXG4gICAgICAgICAgICAgICAgLy90aGlzLkNoZWNrQ3VzdFdpdGhmbmFtZWxuYW1lY29tcHBoc2VtYWlscygpO1xyXG4gICAgICAgICAgICBcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHZhciBtc2cgPSAnJztcclxuICAgICAgICAgICAgLy9pZiAoRW1haWxPYmouRW1haWwgPT0gdW5kZWZpbmVkIHx8IEVtYWlsT2JqLkVtYWlsID09IFwiXCIpXHJcbiAgICAgICAgICAgIC8vICAgIC8vbXNnICs9ICdcXG5FbWFpbCBpcyBub3QgZmlsbGVkJztcclxuICAgICAgICAgICAgLy8gICAgbXNnICs9ICdcXG4nICsgdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9BTF9SRUdNU0dfRU1BSUw7XHJcbiAgICAgICAgICAgIGlmIChFbWFpbE9iai5FbWFpbE5hbWUgPT0gdW5kZWZpbmVkIHx8IEVtYWlsT2JqLkVtYWlsTmFtZSA9PSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICAvL21zZyArPSAnXFxuTmFtZSBpcyBub3QgZmlsbGVkJztcclxuICAgICAgICAgICAgICAgIG1zZyArPSAnXFxuJyArIHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfQUxfUkVHTVNHX0VOQU1FO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgbWVzc2FnZTogbXNnLCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICAgICAgLy8gdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzID0gdGhpcy5DdXN0b21lckFkZHJlc3NlcztcclxuICAgIH1cclxuICAgIFxyXG4gICAgZWRpdEN1c3REZXQoT2JqKSB7XHJcbiAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkdldENvbXBsZXRlQ3VzdERldChPYmouQ3VzdG9tZXJJZCkuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgLy8gIGRlYnVnZ2VyO1xyXG4gICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0ID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgIHRoaXMuU0FWRV9CVE5fVEVYVCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfQlROX1VQREFURTtcclxuICAgICAgICAgICAgICAgIC8vdGhpcy5BRERfTkVXX0NVU1RfVEVYVCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfTEJMX1VQREFURV9DVVNUO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5DU1NURVhUID0gXCJtZGktY29udGVudC1hZGRcIjtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMubGVuZ3RoID09IDApIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMgPSBbeyBFbWFpbDogXCJcIiwgRW1haWxOYW1lOiB0aGlzLm1vZGVsSW5wdXQuRmlsZUFzLCBOZXdzbGV0dGVyZTogZmFsc2UsIHB1Ymxpc2g6IDAsIE5ld3NPcmRlcjogXCJOZXdzMVwiLCBFUHVibGlzaE9yZGVyOiBcIkVQdWIxXCIgfV1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBjb3VudCA9IDE7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlscywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLk5ld3NPcmRlciA9IFwiTmV3c1wiICsgY291bnQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuRVB1Ymxpc2hPcmRlciA9IFwiRVB1YlwiICsgY291bnQrKztcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuTmV3c2xldHRlcmUgPT0gXCIxXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuTmV3c2xldHRlcmUgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuTmV3c2xldHRlcmUgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzLmxlbmd0aCA9PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIHBoaWQgPSBcIlwiO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLl9QaG9uZVR5cGVzLCBmdW5jdGlvbiAoKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5UZXh0ID09IFwiQ2VsbFBob25lXCIpIHtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwaGlkID0gdGhpcy5WYWx1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXMgPSBbeyBQaG9uZVR5cGVJZDogcGhpZCwgUHJlZml4OiBcIlwiLCBBcmVhOiBcIlwiLCBQaG9uZTogXCJcIiwgSXNTbXM6IDAsIENvbW1lbnRzOiBcIlwiLCBwaHB1Ymxpc2g6IDAsIFNNU09yZGVyOiBcIlNNUzFcIiwgUHVibGlzaE9yZGVyOiBcIlB1YjFcIiB9XTtcclxuICAgICAgICAgICAgICAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBjb3VudCA9IDE7XHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzLCBmdW5jdGlvbiAoKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLlNNU09yZGVyID0gXCJTTVNcIiArIGNvdW50O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLlB1Ymxpc2hPcmRlciA9IFwiUHViXCIgKyBjb3VudCsrO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3Nlcy5sZW5ndGggPT0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBlbXBpZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiZW1wbG95ZWVpZFwiKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIGNjb2RlID0gdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmdldENvb2tpZShlbXBpZCArIFwiY2NvZGVcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGNjb2RlLmxlbmd0aCA+IDApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNjb2RlID0gY2NvZGUuc3Vic3RyaW5nKDEsIGNjb2RlLmxlbmd0aCk7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIGFkaWQgPSBcIlwiO1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBjb21wdGV4dCA9IFwiSG9tZVwiO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ29tcGFueSAhPSBcIlwiICYmIHRoaXMubW9kZWxJbnB1dC5Db21wYW55ICE9IHVuZGVmaW5lZCAmJiB0aGlzLm1vZGVsSW5wdXQuQ29tcGFueSAhPSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbXB0ZXh0ID0gXCJXb3JrXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMuX0FkZHJlc3NUeXBlcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5UZXh0ID09IGNvbXB0ZXh0KSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYWRpZCA9IHRoaXMuVmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzID0gW3sgU3RyZWV0OiBcIlwiLCBTdHJlZXQyOiBcIlwiLCBDaXR5TmFtZTogXCJcIiwgWmlwOiBcIlwiLCBDb3VudHJ5Q29kZTogY2NvZGUsIFN0YXRlSWQ6IFwiXCIsIEFkZHJlc3NUeXBlSWQ6IGFkaWQsIEZvckRlbGl2ZXJ5OiBmYWxzZSwgTWFpbkFkZHJlc3M6IGZhbHNlLCBNYWluT3JkZXI6IFwiTWFpbkFkZHIxXCIsIERlbHZyeU9yZGVyOiBcIkRlbHZyeTFcIiB9XTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBjb3VudCA9IDE7XHJcbiAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLk1haW5PcmRlciA9IFwiTWFpbkFkZHJcIiArIGNvdW50O1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuRGVsdnJ5T3JkZXIgPSBcIkRlbHZyeVwiICsgY291bnQrKztcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLy92YXIgdHJlZXZpZXcgPSBqUXVlcnkoXCIjZ3JvdXBUcmVlXCIpLmRhdGEoXCJrZW5kb1RyZWVWaWV3XCIpO1xyXG5cclxuICAgICAgICAgICAgICAgIC8vdmFyIGJhciA9IHRyZWV2aWV3LmZpbmRCeUlkKFwiQmFyXCIpO1xyXG5cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgLy9qUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJHcm91cHMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgIC8vICAgIHZhciBkYXRhID0galF1ZXJ5KFwiI2dyb3VwVHJlZVwiKS5kYXRhKFwia2VuZG9UcmVlVmlld1wiKS5kYXRhU291cmNlLmdldEJ5VWlkKHRoaXMuQ3VzdG9tZXJHZW5lcmFsR3JvdXBJZCk7XHJcbiAgICAgICAgICAgICAgICAvLyAgICBpZiAoZGF0YSkge1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgIGRhdGEuc2V0KFwiY2hlY2tlZFwiLCB0cnVlKTtcclxuICAgICAgICAgICAgICAgIC8vICAgIH1cclxuICAgICAgICAgICAgICAgIC8vICAgIC8vdmFyIEdyb3VwTm9kZSA9IHRyZWV2aWV3LmZpbmRCeUlkKHRoaXMuQ3VzdG9tZXJHZW5lcmFsR3JvdXBJZCk7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAvL3RyZWV2aWV3LmRhdGFJdGVtKEdyb3VwTm9kZSkuc2V0KFwiY2hlY2tlZFwiLCB0cnVlKTtcclxuICAgICAgICAgICAgICAgIC8vfSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLkN1c3RJZFRleHQgPSBcIiggXCIgKyB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCArIFwiIClcIjtcclxuICAgICAgICAgICAgICAgIHRoaXMuSXNGaWxlQXN0eHRTaG93ID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB0aGlzLkhpZGVTaG93RmlsZUFzdHh0KCk7XHJcblxyXG4gICAgICAgICAgICAgICAgLy9hbGVydCh0aGlzLlJFUyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHRoaXMuQ2xvc2VQb3BVcCgpO1xyXG4gICAgICAgIC8vLy8vL0ZvciBDbG9zaW5nIERpc3BsYXkgUG9wdXAvLy8vLy8vLy8vLy8vXHJcbiAgICAgICAgdGhpcy5Jc1BvcFVwID0gZmFsc2U7XHJcblxyXG4gICAgfVxyXG4gICAgQ2hlY2tQaG9uZVR5cGUoUGhvbmVPYmopIHtcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgIC8vYWxlcnQoUGhvbmVPYmouUGhvbmVUeXBlSWQgKyBcIiB8IFwiICsgalF1ZXJ5KFwiI1Bob25lVHlwZVwiKS52YWwoKSk7XHJcbiAgICAgICAgdmFyIHByZXRlbXAgPSBbXTtcclxuICAgICAgICBqUXVlcnkoJ3NlbGVjdFtuYW1lXj1cInBodHlwZVwiXScpLmVhY2goZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICBwcmV0ZW1wLnB1c2goalF1ZXJ5KHRoaXMpLnZhbCgpKTtcclxuICAgICAgICB9KTtcclxuICAgICAgICB2YXIgaW5kZXggPSAwO1xyXG4gICAgICAgIGpRdWVyeS5lYWNoKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICBpZiAodGhpcyA9PSBQaG9uZU9iaikge1xyXG5cclxuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGluZGV4ID0gaW5kZXggKyAxO1xyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBpZiAocHJldGVtcFtpbmRleF0gIT0gdW5kZWZpbmVkICYmIHByZXRlbXBbaW5kZXhdICE9IG51bGwgJiYgcHJldGVtcFtpbmRleF0gIT0gXCJcIikge1xyXG4gICAgICAgICAgICB2YXIgUGhvbmVUeXBlSWQgPSBwcmV0ZW1wW2luZGV4XTtcclxuICAgICAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkdldFBob25lVHlwZURldChQaG9uZVR5cGVJZCkuc3Vic2NyaWJlKFxyXG4gICAgICAgICAgICAgICAgKGRhdGEpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vXHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihkYXRhKTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLkRhdGEgIT0gdW5kZWZpbmVkICYmIHJlc3BvbnNlLkRhdGEgIT0gbnVsbCAmJiByZXNwb25zZS5EYXRhICE9IFwiXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9hbGVydChpbmRleCArIFwiIHwgXCIgKyB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXNbaW5kZXhdLklzU21zICsgXCIgfCBcIiArIHJlc3BvbnNlLkRhdGEuVGV4dCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuRGF0YS5UZXh0ID09IFwiMVwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzW2luZGV4XS5Jc1NtcyA9IDE7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzW2luZGV4XS5waHB1Ymxpc2ggPSAxO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlsc1t0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMubGVuZ3RoIC0gMV0ucHVibGlzaCA9IDE7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXNbaW5kZXhdLnBocHVibGlzaCA9IDA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzW2luZGV4XS5Jc1NtcyA9IDA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzW3RoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlscy5sZW5ndGggLSAxXS5wdWJsaXNoID0gMDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9hbGVydCh0aGlzLlJFUyk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8vdmFyIHRyZWV2aWV3RGF0YVNvdXJjZSA9IGpRdWVyeShcIiNncm91cFRyZWVcIikuZGF0YShcImtlbmRvVHJlZVZpZXdcIikuZGF0YVNvdXJjZS52aWV3KCk7XHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgKGVycikgPT4ge1xyXG5cclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAoKSA9PiB7XHJcblxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgIH1cclxuICAgIGVkaXRFbWFpbERldChFbWFpbE9iaik6IG9ic2VydmFibGUge1xyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgdmFyIGluZGV4ID0gMDtcclxuICAgICAgICB0aGlzLklzUmVjb3JkRWRpdE1vZGUgPSB0cnVlO1xyXG4gICAgICAgIHRoaXMuQlROX1BIQUREID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9CVE5fUEhFRElUO1xyXG4gICAgICAgIFxyXG5cclxuICAgICAgICBcclxuICAgICAgICB0aGlzLkVtYWlsTW9kZWwuRW1haWwgPSBFbWFpbE9iai5FbWFpbDtcclxuICAgICAgICB0aGlzLkVtYWlsTW9kZWwuRW1haWxOYW1lID0gRW1haWxPYmouRW1haWxOYW1lO1xyXG4gICAgICAgIHRoaXMuRW1haWxNb2RlbC5OZXdzbGV0dGVyZSA9IEVtYWlsT2JqLk5ld3NsZXR0ZXJlO1xyXG5cclxuXHJcbiAgICAgICAgdGhpcy5FZGl0RW1haWxEYXRhID0ge307XHJcbiAgICAgICAgdGhpcy5FZGl0RW1haWxEYXRhID0gRW1haWxPYmo7XHJcbiAgICB9XHJcbiAgICBkZWxFbWFpbERldChFbWFpbE9iaik6IG9ic2VydmFibGUge1xyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlscy5sZW5ndGggPiAxKSB7XHJcblxyXG4gICAgICAgICAgICB2YXIgaW5kZXggPSAwO1xyXG4gICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzID09IEVtYWlsT2JqKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBpbmRleCA9IGluZGV4ICsgMTtcclxuXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMuc3BsaWNlKGluZGV4LCAxKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgZWRpdEFkZHJlc3NEZXQoQWRkcmVzc09iaik6IG9ic2VydmFibGUge1xyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgdmFyIGluZGV4ID0gMDtcclxuICAgICAgICB0aGlzLklzUmVjb3JkRWRpdE1vZGUgPSB0cnVlO1xyXG4gICAgICAgIHRoaXMuQlROX1BIQUREID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9CVE5fUEhFRElUO1xyXG4gICAgICAgIFxyXG4gICAgICAgLy8gQWRkcmVzc09iai5DaXR5TmFtZSA9IGpRdWVyeShcIiNDaXR5XCIpLnZhbCgpO1xyXG5cclxuICAgICAgICB0aGlzLkFkZHJlc3MuU3RyZWV0ID0gQWRkcmVzc09iai5TdHJlZXQ7XHJcbiAgICAgICAgdGhpcy5BZGRyZXNzLlN0cmVldDIgPSBBZGRyZXNzT2JqLlN0cmVldDI7XHJcbiAgICAgICAgdGhpcy5BZGRyZXNzLkNpdHlOYW1lID0gQWRkcmVzc09iai5DaXR5TmFtZTtcclxuICAgICAgICB0aGlzLkFkZHJlc3MuWmlwID0gQWRkcmVzc09iai5aaXA7XHJcbiAgICAgICAgdGhpcy5BZGRyZXNzLkNvdW50cnlDb2RlID0gQWRkcmVzc09iai5Db3VudHJ5Q29kZTtcclxuICAgICAgICB0aGlzLkFkZHJlc3MuU3RhdGVJZCA9IEFkZHJlc3NPYmouU3RhdGVJZDtcclxuICAgICAgICB0aGlzLkFkZHJlc3MuQWRkcmVzc1R5cGVJZCA9IEFkZHJlc3NPYmouQWRkcmVzc1R5cGVJZDtcclxuICAgICAgICB0aGlzLkFkZHJlc3MuTWFpbkFkZHJlc3MgPSBBZGRyZXNzT2JqLk1haW5BZGRyZXNzO1xyXG4gICAgICAgIHRoaXMuQWRkcmVzcy5Gb3JEZWxpdmVyeSA9IEFkZHJlc3NPYmouRm9yRGVsaXZlcnk7XHJcblxyXG5cclxuICAgICAgICB0aGlzLkVkaXRBZGRyZXNzRGF0YSA9IHt9O1xyXG4gICAgICAgIHRoaXMuRWRpdEFkZHJlc3NEYXRhID0gQWRkcmVzc09iajtcclxuICAgIH1cclxuXHJcbiAgICBkZWxBZGRyZXNzRGV0KEFkZHJlc3NPYmopOiBvYnNlcnZhYmxlIHtcclxuICAgICAgIC8vIGRlYnVnZ2VyOyBcclxuICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzID4gMSkge1xyXG4gICAgICAgICAgICB2YXIgaW5kZXggPSAwO1xyXG4gICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzID09IEFkZHJlc3NPYmopIHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGluZGV4ID0gaW5kZXggKyAxO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzLnNwbGljZShpbmRleCwgMSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgZWRpdFBob25lRGV0KFBob25lT2JqKTogb2JzZXJ2YWJsZSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdmFyIGluZGV4ID0gMDtcclxuICAgICAgICB0aGlzLkJUTl9QSEFERCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfQlROX1BIRURJVFxyXG4gICAgICAgIHZhciB0ZW1wID0gUGhvbmVPYmouUGhvbmVUeXBlSWQuc3BsaXQoJzsnKTtcclxuICAgICAgICBcclxuICAgICAgICB0aGlzLlBob25lTW9kZWwuUGhvbmVUeXBlSWQgPSBQaG9uZU9iai5QaG9uZVR5cGUgKyBcIjtcIiArIFBob25lT2JqLlBob25lVHlwZUlkO1xyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMuUGhvbmVNb2RlbC5QaG9uZVR5cGUgPSBQaG9uZU9iai5QaG9uZVR5cGU7XHJcbiAgICAgICAgdGhpcy5QaG9uZU1vZGVsLlByZWZpeCA9IFBob25lT2JqLlByZWZpeDtcclxuICAgICAgICB0aGlzLlBob25lTW9kZWwuQXJlYSA9IFBob25lT2JqLkFyZWE7XHJcbiAgICAgICAgdGhpcy5QaG9uZU1vZGVsLlBob25lID0gUGhvbmVPYmouUGhvbmU7XHJcbiAgICAgICAgdGhpcy5QaG9uZU1vZGVsLklzU21zID0gUGhvbmVPYmouSXNTbXM7XHJcbiAgICAgICAgdGhpcy5QaG9uZU1vZGVsLkNvbW1lbnRzID0gUGhvbmVPYmouQ29tbWVudHM7XHJcbiAgICAgICAgdGhpcy5FZGl0UGhvbmVEYXRhID0ge307XHJcbiAgICAgICAgdGhpcy5FZGl0UGhvbmVEYXRhID0gUGhvbmVPYmo7XHJcbiAgICB9XHJcbiAgICBkZWxQaG9uZURldChQaG9uZU9iaik6IG9ic2VydmFibGUge1xyXG4gICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lcy5sZW5ndGggPiAxKSB7XHJcbiAgICAgICAgICAgIHZhciBpbmRleCA9IDA7XHJcbiAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMgPT0gUGhvbmVPYmopIHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGluZGV4ID0gaW5kZXggKyAxO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzLnNwbGljZShpbmRleCwgMSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuXHJcbiAgICBnZXRTZWxlY3RlZEdyb3VwcygpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJHcm91cHMgPSBbXTtcclxuICAgICAgICB2YXIgX0NoZWNrZWRHcm91cHMgPSBbXTtcclxuICAgICAgICBpZiAodGhpcy5Jc1Nob3dBbGwgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgS2VuZG9fdXRpbGl0eS5jaGVja2VkTm9kZUlkcyhqUXVlcnkoXCIjZ3JvdXBUcmVlXCIpLmRhdGEoXCJrZW5kb1RyZWVWaWV3XCIpLmRhdGFTb3VyY2UudmlldygpLCBfQ2hlY2tlZEdyb3Vwcyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgIFxyXG4gICAgICAgICAgICBLZW5kb191dGlsaXR5LmNoZWNrZWROb2RlSWRzKGpRdWVyeShcIiNncm91cFRyZWUxXCIpLmRhdGEoXCJrZW5kb1RyZWVWaWV3XCIpLmRhdGFTb3VyY2UudmlldygpLCBfQ2hlY2tlZEdyb3Vwcyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGZvciAodmFyIGkgPSAwO2k8X0NoZWNrZWRHcm91cHMubGVuZ3RoO2krKyl7XHJcbiAgICAgICAgICAgIHZhciBHT2JqID0ge307XHJcbiAgICAgICAgICAgIEdPYmouQ3VzdG9tZXJHZW5lcmFsR3JvdXBJZCA9IF9DaGVja2VkR3JvdXBzW2ldO1xyXG4gICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJHcm91cHMucHVzaChHT2JqKTtcclxuICAgICBcclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICB9XHJcblxyXG4gICAgTW9yZSgpOiBvYnNlcnZhYmxlIHtcclxuICAgICAgIC8vIGFsZXJ0KFwiY2FsbFwiKTtcclxuICAgICAgICBpZiAodGhpcy5TaG93TW9yZSA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuU2hvd01vcmUgPSBmYWxzZTtcclxuXHJcbiAgICAgICAgICAgIC8vdGhpcy5TaG93TW9yZVRleHQgPSBcIk1vcmVcIjtcclxuICAgICAgICAgICAgdGhpcy5TaG93TW9yZVRleHQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0xOS19MQkxfTU9SRTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgdGhpcy5TaG93TW9yZSA9IHRydWU7XHJcbiAgICAgICAgLy90aGlzLlNob3dNb3JlVGV4dCA9IFwiTGVzc1wiOyBcclxuICAgICAgICB0aGlzLlNob3dNb3JlVGV4dCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfTE5LX0xCTF9MRVNTO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLkJpbmRDdXN0VGl0bGVzKCk7XHJcbiAgICB9XHJcbiAgICBiaW5kR3JvdXBUcmVlKElzc2hvd2FsbCk6IG9ic2VydmFibGUge1xyXG4gICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRHZW5lcmFsR3JvdXBzKElzc2hvd2FsbCkuc3Vic2NyaWJlKFxyXG4gICAgICAgICAgICAoZGF0YSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgIC8vXHJcbiAgICAgICAgICAgICAgICAvL2FsZXJ0KElzc2hvd2FsbCk7XHJcbiAgICAgICAgICAgICAgICBpZiAoSXNzaG93YWxsID09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5KFwiI2dyb3VwVHJlZVwiKS5odG1sKFwiTG9kaW5nLi4uXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciByZXMgPSBqUXVlcnkucGFyc2VKU09OKGRhdGEpLkRhdGFcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkoXCIjZ3JvdXBUcmVlXCIpLmtlbmRvVHJlZVZpZXcoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsb2FkT25EZW1hbmQ6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrYm94ZXM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrQ2hpbGRyZW46IHRydWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9jaGVjazogdGhpcy5vbkdyb3VwU2VsZWN0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkYXRhU291cmNlOiByZXNcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgZ3JwaWRzID0gXCJcIjtcclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJHcm91cHMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZ3JwaWRzICs9IHRoaXMuQ3VzdG9tZXJHZW5lcmFsR3JvdXBJZCArIFwiO1wiO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChncnBpZHMubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBLZW5kb191dGlsaXR5LmNoZWNraW5nTm9kZUlkcyhqUXVlcnkoXCIjZ3JvdXBUcmVlXCIpLmRhdGEoXCJrZW5kb1RyZWVWaWV3XCIpLmRhdGFTb3VyY2UudmlldygpLCBncnBpZHMuc3Vic3RyaW5nKDAsIGdycGlkcy5sZW5ndGggLSAxKSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkoXCIjZ3JvdXBUcmVlMVwiKS5odG1sKFwiTG9kaW5nLi4uXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciByZXMgPSBqUXVlcnkucGFyc2VKU09OKGRhdGEpLkRhdGFcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkoXCIjZ3JvdXBUcmVlMVwiKS5rZW5kb1RyZWVWaWV3KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbG9hZE9uRGVtYW5kOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjaGVja2JveGVzOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja0NoaWxkcmVuOiB0cnVlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vY2hlY2s6IHRoaXMub25Hcm91cFNlbGVjdCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGF0YVNvdXJjZTogcmVzXHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIGdycGlkcyA9IFwiXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5tb2RlbElucHV0LkN1c3RvbWVyR3JvdXBzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGdycGlkcyArPSB0aGlzLkN1c3RvbWVyR2VuZXJhbEdyb3VwSWQgKyBcIjtcIjtcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoZ3JwaWRzLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgS2VuZG9fdXRpbGl0eS5jaGVja2luZ05vZGVJZHMoalF1ZXJ5KFwiI2dyb3VwVHJlZTFcIikuZGF0YShcImtlbmRvVHJlZVZpZXdcIikuZGF0YVNvdXJjZS52aWV3KCksIGdycGlkcy5zdWJzdHJpbmcoMCwgZ3JwaWRzLmxlbmd0aCAtIDEpKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC8vdmFyIHRyZWV2aWV3RGF0YVNvdXJjZSA9IGpRdWVyeShcIiNncm91cFRyZWVcIikuZGF0YShcImtlbmRvVHJlZVZpZXdcIikuZGF0YVNvdXJjZS52aWV3KCk7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIChlcnIpID0+IHtcclxuXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICgpID0+IHtcclxuXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICApO1xyXG4gICAgICAgIFxyXG4gICAgfVxyXG4gICAgR2V0RGF0YUZvclNlYXJjaChldmVudDogYW55KTogb2JzZXJ2YWJsZSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgLy90aGlzLlNlYXJjaFZhbCA9IGpRdWVyeShcIiNTZWFyY2h0eHRcIikudmFsKCk7XHJcbiAgICAgICAgLy9hbGVydChldmVudC5rZXlDb2RlKTtcclxuICAgICAgICAvL2lmICh0aGlzLlNlYXJjaFZhbCAhPSB1bmRlZmluZWQgJiYgdGhpcy5TZWFyY2hWYWwgIT0gXCJcIiAmJiB0aGlzLlNlYXJjaFZhbCAhPSBudWxsICYmIGV2ZW50LmtleUNvZGUgPT0gMTMpIHtcclxuICAgICAgICAgICAgLy9hbGVydCh0aGlzLmF1dG9jb21wbGV0ZVNlbGVjdCArIFwiIFwiICsgdGhpcy5hdXRvY29tcGxldGVOb1Jlc3VsdHMpO1xyXG4gICAgICAgIC8vICAgIHRoaXMuRW50ZXJDb3VudCsrO1xyXG4gICAgICAgIC8vICAgIGlmICh0aGlzLkVudGVyQ291bnQgPj0gMikge1xyXG4gICAgICAgIC8vICAgICAgICB0aGlzLl9jdXN0b21lclNlcnZpY2UuR2V0Q29tcGxldGVTZWFyY2godGhpcy5TZWFyY2hWYWwpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgIC8vICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAvLyAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAvLyAgICAgICAgICAgICAgICBhbGVydChyZXNwb25zZS5FcnJNc2cpO1xyXG4gICAgICAgIC8vICAgICAgICAgICAgfVxyXG4gICAgICAgIC8vICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgdGhpcy5DdXN0TGlzdCA9IHt9O1xyXG4gICAgICAgIC8vICAgICAgICAgICAgICAgIHRoaXMuQ3VzdExpc3QgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgIC8vICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5EYXRhICE9IG51bGwgJiYgcmVzcG9uc2UuRGF0YSAhPSB1bmRlZmluZWQpIHtcclxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgdGhpcy5jdXN0U2VhcmNoRGF0YSA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgIGpRdWVyeShcIiNDdXN0TW9kYWxcIikubW9kYWwoXCJzaG93XCIpO1xyXG5cclxuICAgICAgICAvLyAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vICAgICAgICAgICAgfVxyXG4gICAgICAgIC8vICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAvLyAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICAvLyAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgIC8vICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgLy8gICAgICAgIH0pO1xyXG4gICAgICAgIC8vICAgICAgICB0aGlzLkVudGVyQ291bnQgPSAwO1xyXG4gICAgICAgIC8vICAgIH1cclxuICAgICAgICAgICAgICAgXHJcbiAgICAgICAgLy99XHJcbiAgICAgICAgLy90aGlzLlNlYXJjaFZhbCA9IFwiXCI7XHJcbiAgICB9XHJcblxyXG4gICAgQmluZEN1c3RUaXRsZXMoKSB7XHJcblxyXG4gICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRDdXN0VGl0bGVzKCkuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdmFyIHRpdGxldHlwZWFoZWFkU291cmNlID0gW107XHJcbiAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaChyZXNwb25zZS5EYXRhLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIG5ld3RlbXAgPSB7fTtcclxuICAgICAgICAgICAgICAgICAgICBuZXd0ZW1wLmlkID0gdGhpcy5WYWx1ZTtcclxuICAgICAgICAgICAgICAgICAgICBuZXd0ZW1wLm5hbWUgPSB0aGlzLlRleHQ7XHJcbiAgICAgICAgICAgICAgICAgICAgdGl0bGV0eXBlYWhlYWRTb3VyY2UucHVzaChuZXd0ZW1wKTtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fQ3VzdFRpdGxlcyA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICBqUXVlcnkoXCIjVGl0bGVcIikudHlwZWFoZWFkKHtcclxuICAgICAgICAgICAgICAgICAgICAvL2RhdGE6IHRoaXMuX0NpdGllcyxcclxuICAgICAgICAgICAgICAgICAgICBzb3VyY2U6IHRpdGxldHlwZWFoZWFkU291cmNlLFxyXG4gICAgICAgICAgICAgICAgICAgIC8vZGlzcGxheTogXCJ0ZXh0XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgZGF0YVR5cGU6IFwiSlNPTlwiLFxyXG4gICAgICAgICAgICAgICAgICAgIC8vaGludDogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICAvL2hpZ2hsaWdodDogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICAvL21pbkxlbmd0aDogMSxcclxuICAgICAgICAgICAgICAgIH0pO1xyXG5cclxuXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcbiAgICBuZ09uSW5pdCgpIHtcclxuICAgICAgICBqUXVlcnkoXCIubGVhbi1vdmVybGF5XCIpLmNzcyh7IFwiZGlzcGxheVwiOiBcIm5vbmVcIiB9KTtcclxuICAgICAgICB0aGlzLkJpbmRDdXN0VGl0bGVzKCk7XHJcbiAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICAvL2Jvb3Rib3guYWxlcnQoXCJUaGlzIGlzIHRoZSBkZWZhdWx0IGFsZXJ0IVwiKTtcclxuICAgICAgICBpZiAobG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJsYW5nXCIpID09IFwiXCIpIHtcclxuICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJsYW5nXCIsIFwiZW5cIik7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICh0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZ2V0Q29va2llKFwibGFuZ1wiKSA9PSBcIlwiKSB7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2Uuc2V0Q29va2llKFwibGFuZ1wiLCBcImVuXCIsIDEwKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5Jc0NhbmNlbCA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMuc2hvd2hpZGVHcm91cHMoKTtcclxuICAgICAgICB0aGlzLklzRmlsZUFzdHh0U2hvdyA9IHRydWU7XHJcbiAgICAgICAgXHJcbiAgICAgICAgLy90aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCA9IC0xO1xyXG4gICAgICAgIFxyXG4gICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCA+PSAwKSB7XHJcbiAgICAgICAgICAgIC8vdGhpcy5Jc0ZpbGVBc3R4dFNob3cgPSBmYWxzZTtcclxuICAgICAgICAgICAgdGhpcy5lZGl0Q3VzdERldCh0aGlzLm1vZGVsSW5wdXQpO1xyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgdGhpcy5TQVZFX0JUTl9URVhUID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9CVE5fVVBEQVRFO1xyXG4gICAgICAgICAgICAvL3RoaXMuQUREX05FV19DVVNUX1RFWFQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0xCTF9VUERBVEVfQ1VTVDtcclxuICAgICAgICAgICAgLy90aGlzLkNTU1RFWFQgPSBcIm1kaS1jb250ZW50LWFkZFwiO1xyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3Nlcy5sZW5ndGggPT0gMCkge1xyXG4gICAgICAgICAgICAgICAgdmFyIGVtcGlkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJlbXBsb3llZWlkXCIpO1xyXG5cclxuICAgICAgICAgICAgICAgIHZhciBjY29kZSA9IHRoaXMuX3Jlc291cmNlU2VydmljZS5nZXRDb29raWUoZW1waWQgKyBcImNjb2RlXCIpO1xyXG4gICAgICAgICAgICAgICAgaWYgKGNjb2RlLmxlbmd0aCA+IDApXHJcbiAgICAgICAgICAgICAgICAgICAgY2NvZGUgPSBjY29kZS5zdWJzdHJpbmcoMSwgY2NvZGUubGVuZ3RoKTtcclxuICAgICAgICAgICAgICAgIHZhciBhZGlkID0gXCJcIjtcclxuICAgICAgICAgICAgICAgIHZhciBjb21wdGV4dCA9IFwiSG9tZVwiO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5Db21wYW55ICE9IFwiXCIgJiYgdGhpcy5tb2RlbElucHV0LkNvbXBhbnkgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dC5Db21wYW55ICE9IG51bGwpIHtcclxuICAgICAgICAgICAgICAgICAgICBjb21wdGV4dCA9IFwiV29ya1wiO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5fQWRkcmVzc1R5cGVzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuVGV4dCA9PSBjb21wdGV4dCkge1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgYWRpZCA9IHRoaXMuVmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMgPSBbeyBTdHJlZXQ6IFwiXCIsIFN0cmVldDI6IFwiXCIsIENpdHlOYW1lOiBcIlwiLCBaaXA6IFwiXCIsIENvdW50cnlDb2RlOiBjY29kZSwgU3RhdGVJZDogXCJcIiwgQWRkcmVzc1R5cGVJZDogYWRpZCwgRm9yRGVsaXZlcnk6IGZhbHNlLCBNYWluQWRkcmVzczogZmFsc2UsIE1haW5PcmRlcjogXCJNYWluQWRkcjFcIiwgRGVsdnJ5T3JkZXI6IFwiRGVsdnJ5MVwiIH1dO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRoaXMuQ3VzdElkVGV4dCA9IFwiKCBcIiArIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkICsgXCIgKVwiXHJcbiAgICAgICAgICAgIHRoaXMuSXNGaWxlQXN0eHRTaG93ID0gZmFsc2U7XHJcbiAgICAgICAgICAgIC8vdGhpcy5IaWRlU2hvd0ZpbGVBc3R4dCgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLkxhbmcgPSB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZ2V0Q29va2llKFwibGFuZ1wiKTtcclxuICAgICAgICBpZiAodGhpcy5MYW5nLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgdGhpcy5MYW5nID0gdGhpcy5MYW5nLnN1YnN0cmluZygxLCB0aGlzLkxhbmcubGVuZ3RoKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5IaWRlU2hvd0ZpbGVBc3R4dCgpO1xyXG4gICAgICAgLy90aGlzLlJFUyA9IGpRdWVyeS5wYXJzZUpTT04odGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkdldExhbmdSZXModGhpcy5Gb3JtdHlwZSwgdGhpcy5MYW5nKSkuRGF0YTsgLy9qUXVlcnkucGFyc2VKU09OKGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwibGFuZ3Jlc291cmNlXCIpKTtcclxuICAgICAgICBcclxuICAgICAgICBpZiAodGhpcy5MYW5nID09IFwiaGVcIikge1xyXG4gICAgICAgICAgICB0aGlzLktlbmRvUlRMQ1NTID0gXCJrLXJ0bFwiO1xyXG4gICAgICAgICAgICB0aGlzLkNIQU5HRURJUiA9IFwicnRsbW9kYWxcIjtcclxuICAgICAgICAgICAgdGhpcy5DaGFuZ2VEaWFsb2cgPSBcImlucHV0X3JpZ2h0XCI7XHJcbiAgICAgICAgICAgIC8valF1ZXJ5KFwiLmJvb3Rib3gtY2xvc2UtYnV0dG9uXCIpLmNzcyhcImZsb2F0XCIsIFwibGVmdCFpbXBvcnRhbnRcIik7XHJcbiAgICAgICAgICAgIC8valF1ZXJ5KFwiLm1vZGFsLWZvb3RlciBidXR0b246YmVmb3JlXCIpLmNzcyhcImZsb2F0XCIsIFwibGVmdCFpbXBvcnRhbnRcIik7XHJcbiAgICAgICAgICAgIC8valF1ZXJ5KFwiLm1vZGFsLWZvb3RlciBidXR0b246YWZ0ZXJcIikuY3NzKFwiZmxvYXRcIiwgXCJsZWZ0IWltcG9ydGFudFwiKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuQ0hBTkdFRElSID0gXCJsdHJtb2RhbFwiO1xyXG4gICAgICAgICAgICB0aGlzLkNoYW5nZURpYWxvZyA9IFwiaW5wdXRfbGVmdFwiO1xyXG4gICAgICAgIH1cclxuXHJcblxyXG4gICAgICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLkdldExhbmdSZXModGhpcy5Gb3JtdHlwZSwgdGhpcy5MYW5nKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICB0aGlzLlJFUyA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgIHRoaXMuU2hvd01vcmVUZXh0ID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9MTktfTEJMX01PUkU7XHJcbiAgICAgICAgICAgICAgIHRoaXMuR3JvdXBUZXh0ID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9MQkxfU0hPV0dST1VQUztcclxuICAgICAgICAgICAgICAgdGhpcy5TQVZFX0JUTl9URVhUID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9CVE5fU0FWRTtcclxuICAgICAgICAgICAgICAgdGhpcy5BRERfTkVXX0NVU1RfVEVYVCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfTEJMX05FV19DVVNUO1xyXG4gICAgICAgICAgICAgICB0aGlzLkZJTEVBU19CVE5fVEVYVCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfQlROX0ZJTEVBUztcclxuICAgICAgICAgICAgICAgLy9hbGVydCh0aGlzLlJFUyk7XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgfSk7XHJcbiAgICAgICAvL3RoaXMuU2hvd01vcmVUZXh0ID0gXCJNb3JlXCI7XHJcbiAgICAgICBcclxuICAgICAgIC8vLy9DaXRpZXNcclxuICAgICAgIFxyXG5cclxuXHJcblxyXG4gICAgICAgdmFyIENvdW50cnlDb2RlID0gdGhpcy5BZGRyZXNzLkNvdW50cnlDb2RlO1xyXG4gICAgICAgdmFyIFN0YXRlTmFtZSA9IHRoaXMuQWRkcmVzcy5TdGF0ZUlkO1xyXG4gICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkdldENpdGllcyhDb3VudHJ5Q29kZSwgU3RhdGVOYW1lKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgIH1cclxuICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgdmFyIHR5cGVhaGVhZFNvdXJjZSA9IFtdO1xyXG4gICAgICAgICAgICAgICBqUXVlcnkuZWFjaChyZXNwb25zZS5EYXRhLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICB2YXIgbmV3dGVtcCA9IHt9O1xyXG4gICAgICAgICAgICAgICAgICAgbmV3dGVtcC5pZCA9IHRoaXMuVmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICBuZXd0ZW1wLm5hbWUgPSB0aGlzLlRleHQ7XHJcbiAgICAgICAgICAgICAgICAgICB0eXBlYWhlYWRTb3VyY2UucHVzaChuZXd0ZW1wKTtcclxuICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgIHRoaXMuX0NpdGllcyA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgIGpRdWVyeSgnI0NpdHknKS50eXBlYWhlYWQoe1xyXG4gICAgICAgICAgICAgICAgICAgLy9kYXRhOiB0aGlzLl9DaXRpZXMsXHJcbiAgICAgICAgICAgICAgICAgICBzb3VyY2U6IHR5cGVhaGVhZFNvdXJjZSxcclxuICAgICAgICAgICAgICAgICAgIC8vZGlzcGxheTogXCJ0ZXh0XCIsXHJcbiAgICAgICAgICAgICAgICAgICBkYXRhVHlwZTogXCJKU09OXCIsXHJcbiAgICAgICAgICAgICAgICAgICAvL2hpbnQ6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAvL2hpZ2hsaWdodDogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgIC8vbWluTGVuZ3RoOiAxLFxyXG4gICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICB9XHJcbiAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICB9KTtcclxuXHJcbiAgICAgICBcclxuICAgICAgIFxyXG4gICAgICAgICAgXHJcblxyXG5cclxuICAgICAgICB0aGlzLmxhbmd1YWdlQXJyYXkgPSB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuR2V0QXZhaWxhYmxlTGFuZ3VhZ2VzKCk7XHJcbiAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkdldEN1c3RvbWVyVHlwZXMoKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIHZhciByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcCk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZywgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9DdXN0VHlwZXMgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclR5cGUgPT0gXCJcIiB8fCB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJUeXBlID09IHVuZGVmaW5lZCB8fCB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJUeXBlID09IG51bGwpIHtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgQ3VzdHR5cGVJZDtcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLl9DdXN0VHlwZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgQ3VzdHR5cGVJZCA9IHRoaXMuVmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJUeXBlID0gQ3VzdHR5cGVJZDtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgXHJcbiAgICAgICAgLy8vL1NvdXJjZXNcclxuICAgICAgICB0aGlzLl9jdXN0b21lclNlcnZpY2UuR2V0U291cmNlcygpLnN1YnNjcmliZShyZXNwPT4ge1xyXG4gICAgICAgICAgICB2YXIgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3ApO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fU291cmNlcyA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkNhbWVGcm9tQ3VzdG9tZXIgPT0gXCJcIiB8fCB0aGlzLm1vZGVsSW5wdXQuQ2FtZUZyb21DdXN0b21lciA9PSB1bmRlZmluZWQgfHwgdGhpcy5tb2RlbElucHV0LkNhbWVGcm9tQ3VzdG9tZXIgPT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBTb3VyY2U7XHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5fU291cmNlcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBTb3VyY2UgPSB0aGlzLlZhbHVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkNhbWVGcm9tQ3VzdG9tZXIgPSBTb3VyY2U7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIC8vR2V0RW1wbG95ZWVzXHJcbiAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkdldEVtcGxveWVlcygpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX0VtcGxveWVlcyA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LmVtcGxveWVlaWQgPT0gXCJcIiB8fCB0aGlzLm1vZGVsSW5wdXQuZW1wbG95ZWVpZCA9PSB1bmRlZmluZWQgfHwgdGhpcy5tb2RlbElucHV0LmVtcGxveWVlaWQgPT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBlbXBpZDtcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLl9FbXBsb3llZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZW1waWQgPSB0aGlzLlZhbHVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LmVtcGxveWVlaWQgPSBlbXBpZDtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuICAgICAgICAvL0dldFN1ZmZpeGVzXHJcbiAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkdldFN1ZmZpeGVzKCkuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fU3VmZml4ZXMgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIC8vR2V0UGhvbmVUeXBlc1xyXG4gICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRQaG9uZVR5cGVzKCkuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgIC8vIGRlYnVnZ2VyO1xyXG4gICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fUGhvbmVUeXBlcyA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICB2YXIgcGhpZCA9IFwiXCI7XHJcbiAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLl9QaG9uZVR5cGVzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuVGV4dCA9PSBcIkNlbGxQaG9uZVwiKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwaGlkID0gdGhpcy5WYWx1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzWzBdLlBob25lVHlwZUlkID0gcGhpZDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuXHJcblxyXG4gICAgICAgIHZhciBlcHVibGlzaCA9IDA7XHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lcy5sZW5ndGggPT0gMCkge1xyXG4gICAgICAgICAgICB2YXIgcGhpZCA9IFwiXCI7XHJcblxyXG4gICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLl9QaG9uZVR5cGVzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5UZXh0ID09IFwiQ2VsbFBob25lXCIpIHtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgcGhpZCA9IHRoaXMuVmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgZXB1Ymxpc2ggPSAxO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXMgPSBbeyBQaG9uZVR5cGVJZDogcGhpZCwgUHJlZml4OiBcIlwiLCBBcmVhOiBcIlwiLCBQaG9uZTogXCJcIiwgSXNTbXM6IGVwdWJsaXNoLCBDb21tZW50czogXCJcIiwgcGhwdWJsaXNoOiBlcHVibGlzaCwgU01TT3JkZXI6IFwiU01TMVwiLCBQdWJsaXNoT3JkZXI6XCJQdWIxXCIgfV07XHJcbiAgICAgICAgICAgIC8vIGRlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMubGVuZ3RoID09IDApIHtcclxuICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzID0gW3sgRW1haWw6IFwiXCIsIEVtYWlsTmFtZTogdGhpcy5tb2RlbElucHV0LkZpbGVBcywgTmV3c2xldHRlcmU6IGZhbHNlLCBwdWJsaXNoOiBlcHVibGlzaCwgTmV3c09yZGVyOiBcIk5ld3MxXCIsIEVQdWJsaXNoT3JkZXI6XCJFUHViMVwiIH1dXHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvL0dldEFkZHJlc3NUeXBlc1xyXG4gICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRBZGRyZXNzVHlwZXMoKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZywgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9BZGRyZXNzVHlwZXMgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgIHZhciBhZGlkID0gXCJcIjtcclxuICAgICAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMuX0FkZHJlc3NUeXBlcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLlRleHQgPT0gXCJIb21lXCIpIHtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFkaWQgPSB0aGlzLlZhbHVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzWzBdLkFkZHJlc3NUeXBlSWQgPSBhZGlkO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIC8vR3JvdXBzXHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkdldEdyb3VwcygpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX0dyb3VwcyA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgLy8vL0NvdW50cmllc1xyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRDb3VudHJpZXMoKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZywgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9Db3VudHJpZXMgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIC8vLy9TdGF0ZXNcclxuICAgICAgICB2YXIgQ291bnRyeUNvZGU9IHRoaXMuQWRkcmVzcy5Db3VudHJ5Q29kZTtcclxuICAgICAgICB0aGlzLl9jdXN0b21lclNlcnZpY2UuR2V0U3RhdGVzKENvdW50cnlDb2RlKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZywgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9TdGF0ZXMgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIFxyXG4gICAgICAgIFxyXG4gICAgICAgIC8vVHJlZSBHcm91cFxyXG5cclxuICAgICAgICAvL3RoaXMuYmluZEdyb3VwVHJlZSh0aGlzLklzU2hvd0FsbCk7XHJcbiAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkdldEdlbmVyYWxHcm91cHModGhpcy5Jc1Nob3dBbGwpLnN1YnNjcmliZShcclxuICAgICAgICAgICAgKGRhdGEpID0+IHtcclxuICAgICAgICAgICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5Jc1Nob3dBbGwgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkoXCIjZ3JvdXBUcmVlXCIpLmh0bWwoXCJMb2RpbmcuLi5cIik7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIHJlcyA9IGpRdWVyeS5wYXJzZUpTT04oZGF0YSkuRGF0YVxyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeShcIiNncm91cFRyZWVcIikua2VuZG9UcmVlVmlldyh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRPbkRlbWFuZDogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tib3hlczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tDaGlsZHJlbjogdHJ1ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2NoZWNrOiB0aGlzLm9uR3JvdXBTZWxlY3QsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhdGFTb3VyY2U6IHJlc1xyXG5cclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgZ3JwaWRzID0gXCJcIjtcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJHcm91cHMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZ3JwaWRzICs9IHRoaXMuQ3VzdG9tZXJHZW5lcmFsR3JvdXBJZCArIFwiO1wiO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChncnBpZHMubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBLZW5kb191dGlsaXR5LmNoZWNraW5nTm9kZUlkcyhqUXVlcnkoXCIjZ3JvdXBUcmVlXCIpLmRhdGEoXCJrZW5kb1RyZWVWaWV3XCIpLmRhdGFTb3VyY2UudmlldygpLCBncnBpZHMuc3Vic3RyaW5nKDAsIGdycGlkcy5sZW5ndGggLSAxKSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkoXCIjZ3JvdXBUcmVlMVwiKS5odG1sKFwiTG9kaW5nLi4uXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciByZXMgPSBqUXVlcnkucGFyc2VKU09OKGRhdGEpLkRhdGFcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkoXCIjZ3JvdXBUcmVlMVwiKS5rZW5kb1RyZWVWaWV3KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbG9hZE9uRGVtYW5kOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjaGVja2JveGVzOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja0NoaWxkcmVuOiB0cnVlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vY2hlY2s6IHRoaXMub25Hcm91cFNlbGVjdCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGF0YVNvdXJjZTogcmVzXHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIGdycGlkcyA9IFwiXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5tb2RlbElucHV0LkN1c3RvbWVyR3JvdXBzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGdycGlkcyArPSB0aGlzLkN1c3RvbWVyR2VuZXJhbEdyb3VwSWQgKyBcIjtcIjtcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoZ3JwaWRzLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgS2VuZG9fdXRpbGl0eS5jaGVja2luZ05vZGVJZHMoalF1ZXJ5KFwiI2dyb3VwVHJlZTFcIikuZGF0YShcImtlbmRvVHJlZVZpZXdcIikuZGF0YVNvdXJjZS52aWV3KCksIGdycGlkcy5zdWJzdHJpbmcoMCwgZ3JwaWRzLmxlbmd0aCAtIDEpKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgKGVycikgPT4ge1xyXG5cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgKCkgPT4ge1xyXG5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICk7XHJcbiAgICAgICAgXHJcblxyXG5cclxuICAgICAgICAvL2FsZXJ0KG1vbWVudCgpLmZvcm1hdCgnRCBNTU0gWVlZWScpKTsgICAgICAgXHJcbiAgICAgICAvLyB0aGlzLmJhc2VVcmwgKyBcIkRyb3Bkb3duL0JpbmRBdXRvQ29tcGxldGVTcmNoXCJcclxuICAgICAgICB2YXIgU3JjaERhdGEgPSBudWxsO1xyXG4gICAgICAgICAgIFxyXG4gICAgICAgIC8vYWxlcnQoJ0hpJyk7XHJcbiAgICAgICAgalF1ZXJ5KFwiI0VtYWlsVGFibGUgdGJvZHkgdHIgdGQgYVtuYW1lPWRlbEVidG5dXCIpLm5vdChcIjpsYXN0XCIpLmhpZGUoKTtcclxuICAgICAgICBqUXVlcnkoXCIjRW1haWxUYWJsZSB0Ym9keSB0ciBhW25hbWU9YWRkRWJ0bl1cIikubm90KFwiOmxhc3RcIikuc2hvdygpO1xyXG4gICAgICAgIC8vJCgnLm1vZGFsJykubW9kYWwoKTtcclxuICAgICAgICBcclxuICAgIH1cclxufVxyXG4iXX0=
