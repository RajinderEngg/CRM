System.register(['angular2/common', "../../services/ResourceService", "angular2/router", "angular2/core", "../../services/CustomerService", '../../autocomplete/autocomplete-container', '../../autocomplete/autocomplete.component', '../../comonComponents/basicComponents'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var common_1, ResourceService_1, router_1, core_1, CustomerService_1, autocomplete_container_1, autocomplete_component_1, basicComponents_1;
    var AUTOCOMPLETE_DIRECTIVES, AmaxSearchCustomers;
    return {
        setters:[
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (ResourceService_1_1) {
                ResourceService_1 = ResourceService_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (CustomerService_1_1) {
                CustomerService_1 = CustomerService_1_1;
            },
            function (autocomplete_container_1_1) {
                autocomplete_container_1 = autocomplete_container_1_1;
            },
            function (autocomplete_component_1_1) {
                autocomplete_component_1 = autocomplete_component_1_1;
            },
            function (basicComponents_1_1) {
                basicComponents_1 = basicComponents_1_1;
            }],
        execute: function() {
            exports_1("AUTOCOMPLETE_DIRECTIVES", AUTOCOMPLETE_DIRECTIVES = [autocomplete_component_1.Autocomplete, autocomplete_container_1.AutocompleteContainer]);
            AmaxSearchCustomers = (function () {
                function AmaxSearchCustomers(_resourceService, _customerService, _routeParams) {
                    this._resourceService = _resourceService;
                    this._customerService = _customerService;
                    this._routeParams = _routeParams;
                    this.modelInput = {};
                    this.custSearchData = [];
                    this.CHANGEDIR = "";
                    this.RES = {};
                    this.Lang = "";
                    this.ChangeDialog = "";
                    this.ForPopUp = 0;
                    this.BaseAppUrl = "";
                    this.Formtype = "CUSTOMER_SEARCH";
                    this.Isbtndisable = "";
                    this.ShowLoader = false;
                    this.FromPage = "";
                    this.SearchContent = "";
                    this.EditIconCss = "";
                    this.IsExtended = false;
                    this.Extended = false;
                    this.IsRowFound = false;
                    this.IsDirect = false;
                    this.ForBack = "";
                    this.selectedCar = '';
                    this.asyncSelectedCar = '';
                    this.autocompleteLoading = false;
                    this.autocompleteNoResults = false;
                    this.autocompleteSelect = false;
                    this._previousasyncSelectedCar = '';
                    this.RES.CUSTOMER_SEARCH = {};
                    this.modelInput = {};
                    this.modelInput.IsExtended = false;
                    this.modelInput.Extended = false;
                    this.modelInput.custSearchData = [];
                    this.ForPopUp = _routeParams.params.ForPopup;
                    this.FromPage = _routeParams.params.FromPage;
                    if (this.FromPage == "ReceiptCreate") {
                        this.EditIconCss = "mdi-notification-sync";
                        this.IsDirect = true;
                        this.ForBack = _routeParams.params.ForBack;
                    }
                    else {
                        this.EditIconCss = "mdi-content-create";
                        this.IsDirect = false;
                    }
                    //if (this.ForPopUp == 1) {
                    //    jQuery('mx-navbar').css({ "display": "none" });
                    //    jQuery('footer').css({ "display": "none" });
                    //    jQuery('mx-breadcrumb').css({ "display": "none" });
                    //}
                    this.HideForPopUp(this.ForPopUp);
                    this.BaseAppUrl = _resourceService.AppUrl;
                }
                AmaxSearchCustomers.prototype.getCurrentContext = function () {
                    return this;
                };
                AmaxSearchCustomers.prototype.getAsyncData = function (context) {
                    var _this = this;
                    var SrchVal = context.asyncSelectedCar;
                    // if (SrchVal != undefined && SrchVal != null && SrchVal != "") {
                    // debugger;
                    if (this._previousasyncSelectedCar == context.asyncSelectedCar) {
                        //clearTimeout(this.StopTimeOut);
                        return this._cachedResult;
                    }
                    else {
                        //alert(this._previousasyncSelectedCar + " | " + context.asyncSelectedCar);
                        if (context.asyncSelectedCar != "") {
                            this._previousasyncSelectedCar = context.asyncSelectedCar;
                            //  this.StopTimeOut = setTimeout(() => {
                            //    alert(SrchVal);
                            this._customerService.GetCompleteSearch(SrchVal).subscribe(function (response) {
                                // debugger;
                                response = jQuery.parseJSON(response);
                                if (response.IsError == true) {
                                    //alert(response.ErrMsg);
                                    bootbox.alert({
                                        message: response.ErrMsg,
                                        className: _this.ChangeDialog,
                                        buttons: {
                                            ok: {
                                                //label: 'Ok',
                                                className: _this.CHANGEDIR
                                            }
                                        }
                                    });
                                }
                                else {
                                    context.carsExample1 = response.Data;
                                }
                            }, function (error) {
                                console.log(error);
                            }, function () {
                                console.log("CallCompleted");
                            });
                            // }, 500);
                            this._cachedResult = context.carsExample1;
                        }
                        else {
                            this._cachedResult = [];
                        }
                        return this._cachedResult;
                    }
                };
                AmaxSearchCustomers.prototype.changeAutocompleteLoading = function (e) {
                    this.autocompleteLoading = e;
                };
                AmaxSearchCustomers.prototype.changeAutocompleteNoResults = function (e) {
                    this.autocompleteSelect = false;
                    this.autocompleteNoResults = e;
                };
                AmaxSearchCustomers.prototype.autocompleteOnSelect = function (e) {
                    this.autocompleteSelect = true;
                    console.log("Selected value: " + e.item);
                    var CompData = e.item.split('|');
                    //debugger;
                    if (e.item != undefined && e.item != "" && e.item != null) {
                        //alert(CompData[0]);
                        if (this.FromPage == "ReceiptCreate") {
                            var ReceiptId = localStorage.getItem("TempReceiptId");
                            document.location = this.BaseAppUrl + "ReceiptCreate/" + CompData[0].trim() + "/" + ReceiptId;
                            if (this.modelInput != undefined && this.modelInput != null) {
                                var jdata = JSON.stringify(this.modelInput);
                                if (this.FromPage == "ReceiptCreate") {
                                    var EmpId = localStorage.getItem("employeeid");
                                    var OrgId = localStorage.getItem(EmpId + "_OrgId");
                                    this._resourceService.setCookie(EmpId + "_" + OrgId + "_Search_Cache", jdata, 10);
                                    this._resourceService.setCookie(EmpId + "_" + OrgId + "_Search_auto_Cache", this.asyncSelectedCar, 10);
                                }
                            }
                        }
                        else {
                            if (this.modelInput != undefined && this.modelInput != null) {
                                var jdata = JSON.stringify(this.modelInput);
                                var EmpId = localStorage.getItem("employeeid");
                                var OrgId = localStorage.getItem(EmpId + "_OrgId");
                                this._resourceService.setCookie(EmpId + "_" + OrgId + "_Search_Cache", jdata, 10);
                                this._resourceService.setCookie(EmpId + "_" + OrgId + "_Search_auto_Cache", this.asyncSelectedCar, 10);
                            }
                            document.location = this.BaseAppUrl + "Customer/Add/" + CompData[0].trim();
                        }
                    }
                };
                AmaxSearchCustomers.prototype.HideForPopUp = function (ForPopUp) {
                    if (ForPopUp == 1) {
                        jQuery('mx-navbar').css({ "display": "none" });
                        jQuery('footer').css({ "display": "none" });
                        jQuery('mx-breadcrumb').css({ "display": "none" });
                    }
                };
                AmaxSearchCustomers.prototype.ChangeExtendedAttr = function () {
                    this.modelInput = {};
                    this.modelInput.custSearchData = [];
                    this.modelInput.SearchContent = "";
                    this.asyncSelectedCar = "";
                    this.modelInput.IsRowFound = false;
                    this.modelInput.IsExtended = jQuery("#Extended_").prop("checked");
                };
                AmaxSearchCustomers.prototype.OpenCustomerCard = function (CustObj) {
                    if (this.FromPage == "ReceiptCreate") {
                        var ReceiptId = localStorage.getItem("TempReceiptId");
                        parent.window.open(this.BaseAppUrl + "ReceiptCreate/" + CustObj.CustomerId + "/" + ReceiptId, "_self");
                    }
                    else {
                        parent.window.location.replace(this.BaseAppUrl + "Customer/Add/" + CustObj.CustomerId);
                    }
                };
                AmaxSearchCustomers.prototype.SearchCustomer = function () {
                    var _this = this;
                    //  debugger;
                    this.Isbtndisable = "disabled";
                    this.ShowLoader = true;
                    this._customerService.GetCompleteQuickSearch(this.modelInput.SearchContent).subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            //alert(response.ErrMsg);
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            debugger;
                            _this.modelInput.custSearchData = response.Data;
                            if (_this.modelInput.custSearchData.length == 0) {
                                _this.modelInput.IsRowFound = false;
                            }
                            else {
                                _this.modelInput.IsRowFound = true;
                            }
                            var EmpId = localStorage.getItem("employeeid");
                            var OrgId = localStorage.getItem(EmpId + "_OrgId");
                            if (_this.modelInput != undefined && _this.modelInput != null) {
                                var jdata = JSON.stringify(_this.modelInput);
                                //if (this.FromPage == "ReceiptCreate") {
                                _this._resourceService.setCookie(EmpId + "_" + OrgId + "_Search_Cache", jdata, 10);
                                _this._resourceService.setCookie(EmpId + "_" + OrgId + "_Search_auto_Cache", _this.asyncSelectedCar, 10);
                            }
                        }
                    });
                    this.Isbtndisable = "";
                    this.ShowLoader = false;
                };
                AmaxSearchCustomers.prototype.BackPage = function () {
                    if (this.FromPage == "ReceiptCreate") {
                        //debugger;
                        var ReceiptId = localStorage.getItem("TempReceiptId");
                        parent.window.open(this.BaseAppUrl + "ReceiptCreate/" + this.ForBack + "/" + ReceiptId, "_self");
                    }
                };
                AmaxSearchCustomers.prototype.SetdefaultPage = function () {
                    this.modelInput = {};
                    this.modelInput.SearchContent = "";
                    this.modelInput.custSearchData = [];
                };
                AmaxSearchCustomers.prototype.ngOnInit = function () {
                    var _this = this;
                    this.Lang = this._resourceService.getCookie("lang");
                    if (this.Lang.length > 0) {
                        this.Lang = this.Lang.substring(1, this.Lang.length);
                    }
                    if (this.Lang == "he") {
                        this.CHANGEDIR = "rtlmodal";
                        this.ChangeDialog = "input_right";
                    }
                    else {
                        this.CHANGEDIR = "ltrmodal";
                        this.ChangeDialog = "input_left";
                    }
                    debugger;
                    var EmpId = localStorage.getItem("employeeid");
                    var OrgId = localStorage.getItem(EmpId + "_OrgId");
                    var jdata = this._resourceService.getCookie(EmpId + "_" + OrgId + "_Search_Cache");
                    if (jdata != undefined && jdata != undefined && jdata != "") {
                        jdata = jdata.substring(1, jdata.length);
                        this.modelInput = jQuery.parseJSON(jdata);
                    }
                    var asyn = this._resourceService.getCookie(EmpId + "_" + OrgId + "_Search_auto_Cache");
                    if (asyn != undefined && asyn != undefined && asyn != "") {
                        asyn = asyn.substring(1, asyn.length);
                        this.asyncSelectedCar = asyn;
                    }
                    this._resourceService.GetLangRes(this.Formtype, this.Lang).subscribe(function (response) {
                        //debugger;
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.RES = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxSearchCustomers.$inject = ['$scope', '$location', '$anchorScroll'];
                AmaxSearchCustomers = __decorate([
                    core_1.Component({
                        templateUrl: './app/amax/Customer/templates/CustomerSearch.html',
                        directives: [common_1.NgSwitch, common_1.NgSwitchWhen, common_1.NgSwitchDefault, AUTOCOMPLETE_DIRECTIVES, common_1.CORE_DIRECTIVES, common_1.FORM_DIRECTIVES, basicComponents_1.AmaxDate],
                        providers: [CustomerService_1.CustomerService, ResourceService_1.ResourceService]
                    }), 
                    __metadata('design:paramtypes', [ResourceService_1.ResourceService, CustomerService_1.CustomerService, router_1.RouteParams])
                ], AmaxSearchCustomers);
                return AmaxSearchCustomers;
            }());
            exports_1("AmaxSearchCustomers", AmaxSearchCustomers);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFtYXgvQ3VzdG9tZXIvU2VhcmNoQ3VzdG9tZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7OztRQVlhLHVCQUF1Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztZQUF2QixxQ0FBQSx1QkFBdUIsR0FBRyxDQUFDLHFDQUFZLEVBQUUsOENBQXFCLENBQUMsQ0FBQSxDQUFDO1lBVzdFO2dCQStCSSw2QkFBb0IsZ0JBQWlDLEVBQVUsZ0JBQWlDLEVBQVUsWUFBeUI7b0JBQS9HLHFCQUFnQixHQUFoQixnQkFBZ0IsQ0FBaUI7b0JBQVUscUJBQWdCLEdBQWhCLGdCQUFnQixDQUFpQjtvQkFBVSxpQkFBWSxHQUFaLFlBQVksQ0FBYTtvQkE5Qm5JLGVBQVUsR0FBRyxFQUFFLENBQUM7b0JBQ2hCLG1CQUFjLEdBQVcsRUFBRSxDQUFDO29CQUM1QixjQUFTLEdBQVcsRUFBRSxDQUFDO29CQUN2QixRQUFHLEdBQVcsRUFBRSxDQUFDO29CQUNqQixTQUFJLEdBQVcsRUFBRSxDQUFDO29CQUNsQixpQkFBWSxHQUFXLEVBQUUsQ0FBQztvQkFDMUIsYUFBUSxHQUFXLENBQUMsQ0FBQztvQkFFckIsZUFBVSxHQUFXLEVBQUUsQ0FBQztvQkFDeEIsYUFBUSxHQUFXLGlCQUFpQixDQUFDO29CQUNyQyxpQkFBWSxHQUFXLEVBQUUsQ0FBQztvQkFDMUIsZUFBVSxHQUFZLEtBQUssQ0FBQztvQkFDNUIsYUFBUSxHQUFXLEVBQUUsQ0FBQztvQkFDdEIsa0JBQWEsR0FBVyxFQUFFLENBQUM7b0JBQzNCLGdCQUFXLEdBQVcsRUFBRSxDQUFDO29CQUN6QixlQUFVLEdBQVksS0FBSyxDQUFDO29CQUM1QixhQUFRLEdBQVksS0FBSyxDQUFDO29CQUMxQixlQUFVLEdBQVksS0FBSyxDQUFDO29CQUM1QixhQUFRLEdBQVksS0FBSyxDQUFDO29CQUMxQixZQUFPLEdBQVcsRUFBRSxDQUFDO29CQUNiLGdCQUFXLEdBQVcsRUFBRSxDQUFDO29CQUN6QixxQkFBZ0IsR0FBVyxFQUFFLENBQUM7b0JBQzlCLHdCQUFtQixHQUFZLEtBQUssQ0FBQztvQkFDckMsMEJBQXFCLEdBQVksS0FBSyxDQUFDO29CQUN2Qyx1QkFBa0IsR0FBWSxLQUFLLENBQUM7b0JBd0NwQyw4QkFBeUIsR0FBVyxFQUFFLENBQUM7b0JBaEMzQyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsR0FBRyxFQUFFLENBQUM7b0JBQzlCLElBQUksQ0FBQyxVQUFVLEdBQUcsRUFBRSxDQUFDO29CQUVyQixJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7b0JBQ25DLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQztvQkFDakMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDO29CQUNwQyxJQUFJLENBQUMsUUFBUSxHQUFHLFlBQVksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDO29CQUM3QyxJQUFJLENBQUMsUUFBUSxHQUFHLFlBQVksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDO29CQUc3QyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxJQUFJLGVBQWUsQ0FBQyxDQUFDLENBQUM7d0JBQ25DLElBQUksQ0FBQyxXQUFXLEdBQUcsdUJBQXVCLENBQUM7d0JBQzNDLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO3dCQUNyQixJQUFJLENBQUMsT0FBTyxHQUFHLFlBQVksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDO29CQUMvQyxDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUNGLElBQUksQ0FBQyxXQUFXLEdBQUcsb0JBQW9CLENBQUM7d0JBQ3hDLElBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO29CQUMxQixDQUFDO29CQUVELDJCQUEyQjtvQkFFM0IscURBQXFEO29CQUNyRCxrREFBa0Q7b0JBQ2xELHlEQUF5RDtvQkFDekQsR0FBRztvQkFDSCxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFDakMsSUFBSSxDQUFDLFVBQVUsR0FBRyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUM7Z0JBRTlDLENBQUM7Z0JBbkNPLCtDQUFpQixHQUF6QjtvQkFFSSxNQUFNLENBQUMsSUFBSSxDQUFDO2dCQUNoQixDQUFDO2dCQXFDTywwQ0FBWSxHQUFwQixVQUFxQixPQUFZO29CQUFqQyxpQkF1REM7b0JBckRHLElBQUksT0FBTyxHQUFHLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQztvQkFFdkMsa0VBQWtFO29CQUdsRSxZQUFZO29CQUNaLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyx5QkFBeUIsSUFBSSxPQUFPLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDO3dCQUM3RCxpQ0FBaUM7d0JBQ2pDLE1BQU0sQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDO29CQUM5QixDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUNGLDJFQUEyRTt3QkFDM0UsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLGdCQUFnQixJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7NEJBQ2pDLElBQUksQ0FBQyx5QkFBeUIsR0FBRyxPQUFPLENBQUMsZ0JBQWdCLENBQUM7NEJBQzFELHlDQUF5Qzs0QkFDekMscUJBQXFCOzRCQUNyQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsaUJBQWlCLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTtnQ0FDL0QsWUFBWTtnQ0FDWixRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQztnQ0FDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO29DQUMzQix5QkFBeUI7b0NBQ3pCLE9BQU8sQ0FBQyxLQUFLLENBQUM7d0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO3dDQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7d0NBQzVCLE9BQU8sRUFBRTs0Q0FDTCxFQUFFLEVBQUU7Z0RBQ0EsY0FBYztnREFDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7NkNBQzVCO3lDQUNKO3FDQUNKLENBQUMsQ0FBQztnQ0FDUCxDQUFDO2dDQUNELElBQUksQ0FBQyxDQUFDO29DQUNGLE9BQU8sQ0FBQyxZQUFZLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQztnQ0FHekMsQ0FBQzs0QkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO2dDQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7NEJBQ3ZCLENBQUMsRUFBRTtnQ0FDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBOzRCQUNoQyxDQUFDLENBQUMsQ0FBQzs0QkFDSCxXQUFXOzRCQUVYLElBQUksQ0FBQyxhQUFhLEdBQUcsT0FBTyxDQUFDLFlBQVksQ0FBQzt3QkFDOUMsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixJQUFJLENBQUMsYUFBYSxHQUFHLEVBQUUsQ0FBQzt3QkFDNUIsQ0FBQzt3QkFDRCxNQUFNLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQztvQkFDOUIsQ0FBQztnQkFHTCxDQUFDO2dCQUVPLHVEQUF5QixHQUFqQyxVQUFrQyxDQUFVO29CQUN4QyxJQUFJLENBQUMsbUJBQW1CLEdBQUcsQ0FBQyxDQUFDO2dCQUNqQyxDQUFDO2dCQUVPLHlEQUEyQixHQUFuQyxVQUFvQyxDQUFVO29CQUMxQyxJQUFJLENBQUMsa0JBQWtCLEdBQUcsS0FBSyxDQUFDO29CQUNoQyxJQUFJLENBQUMscUJBQXFCLEdBQUcsQ0FBQyxDQUFDO2dCQUNuQyxDQUFDO2dCQUNPLGtEQUFvQixHQUE1QixVQUE2QixDQUFNO29CQUMvQixJQUFJLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDO29CQUMvQixPQUFPLENBQUMsR0FBRyxDQUFDLHFCQUFtQixDQUFDLENBQUMsSUFBTSxDQUFDLENBQUM7b0JBQ3pDLElBQUksUUFBUSxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUNqQyxXQUFXO29CQUNYLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksU0FBUyxJQUFJLENBQUMsQ0FBQyxJQUFJLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzt3QkFDeEQscUJBQXFCO3dCQUdyQixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxJQUFJLGVBQWUsQ0FBQyxDQUFDLENBQUM7NEJBQ25DLElBQUksU0FBUyxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUM7NEJBRXRELFFBQVEsQ0FBQyxRQUFRLEdBQUMsSUFBSSxDQUFDLFVBQVUsR0FBRyxnQkFBZ0IsR0FBRyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLEdBQUcsR0FBRyxHQUFHLFNBQVMsQ0FBQzs0QkFDNUYsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLFVBQVUsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO2dDQUMxRCxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztnQ0FDNUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsSUFBSSxlQUFlLENBQUMsQ0FBQyxDQUFDO29DQUNuQyxJQUFJLEtBQUssR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDO29DQUMvQyxJQUFJLEtBQUssR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUMsQ0FBQztvQ0FDbkQsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxHQUFDLEtBQUssR0FBRyxlQUFlLEVBQUUsS0FBSyxFQUFFLEVBQUUsQ0FBQyxDQUFDO29DQUNoRixJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxHQUFHLEdBQUMsS0FBSyxHQUFDLG9CQUFvQixFQUFFLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxFQUFFLENBQUMsQ0FBQztnQ0FDdkcsQ0FBQzs0QkFDTCxDQUFDO3dCQUNMLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBR0YsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLFVBQVUsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO2dDQUMxRCxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztnQ0FDNUMsSUFBSSxLQUFLLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQztnQ0FDL0MsSUFBSSxLQUFLLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEdBQUcsUUFBUSxDQUFDLENBQUM7Z0NBQ25ELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLEdBQUcsR0FBRyxLQUFLLEdBQUcsZUFBZSxFQUFFLEtBQUssRUFBRSxFQUFFLENBQUMsQ0FBQztnQ0FDbEYsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxHQUFHLEtBQUssR0FBQyxvQkFBb0IsRUFBRSxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsRUFBRSxDQUFDLENBQUM7NEJBRXpHLENBQUM7NEJBQ0QsUUFBUSxDQUFDLFFBQVEsR0FBQyxJQUFJLENBQUMsVUFBVSxHQUFHLGVBQWUsR0FBRyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7d0JBQzdFLENBQUM7b0JBQ0wsQ0FBQztnQkFDTCxDQUFDO2dCQUdELDBDQUFZLEdBQVosVUFBYSxRQUFRO29CQUNqQixFQUFFLENBQUMsQ0FBQyxRQUFRLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFFaEIsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLFNBQVMsRUFBRSxNQUFNLEVBQUUsQ0FBQyxDQUFDO3dCQUMvQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsU0FBUyxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUM7d0JBQzVDLE1BQU0sQ0FBQyxlQUFlLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFLENBQUMsQ0FBQztvQkFDdkQsQ0FBQztnQkFDTCxDQUFDO2dCQUNELGdEQUFrQixHQUFsQjtvQkFDSSxJQUFJLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztvQkFDckIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDO29CQUVwQyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsR0FBRyxFQUFFLENBQUM7b0JBQ25DLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxFQUFFLENBQUM7b0JBQzNCLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztvQkFDbkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztnQkFFdEUsQ0FBQztnQkFDRCw4Q0FBZ0IsR0FBaEIsVUFBaUIsT0FBTztvQkFFcEIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsSUFBSSxlQUFlLENBQUMsQ0FBQyxDQUFDO3dCQUNuQyxJQUFJLFNBQVMsR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDO3dCQUN0RCxNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxHQUFHLGdCQUFnQixHQUFHLE9BQU8sQ0FBQyxVQUFVLEdBQUcsR0FBRyxHQUFHLFNBQVMsRUFBQyxPQUFPLENBQUMsQ0FBQztvQkFFMUcsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixNQUFNLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFVBQVUsR0FBRyxlQUFlLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO29CQUMzRixDQUFDO2dCQUVMLENBQUM7Z0JBQ0QsNENBQWMsR0FBZDtvQkFBQSxpQkFrREM7b0JBakRDLGFBQWE7b0JBQ1gsSUFBSSxDQUFDLFlBQVksR0FBRyxVQUFVLENBQUM7b0JBQy9CLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO29CQUN2QixJQUFJLENBQUMsZ0JBQWdCLENBQUMsc0JBQXNCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUUxRixRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQix5QkFBeUI7NEJBQ3pCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO2dDQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQzVCLE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLFFBQVEsQ0FBQzs0QkFDVCxLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDOzRCQUMvQyxFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDN0MsS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDOzRCQUN2QyxDQUFDOzRCQUNELElBQUksQ0FBQyxDQUFDO2dDQUNGLEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQzs0QkFDdEMsQ0FBQzs0QkFDRCxJQUFJLEtBQUssR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDOzRCQUMvQyxJQUFJLEtBQUssR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUMsQ0FBQzs0QkFDbkQsRUFBRSxDQUFDLENBQUMsS0FBSSxDQUFDLFVBQVUsSUFBSSxTQUFTLElBQUksS0FBSSxDQUFDLFVBQVUsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO2dDQUMxRCxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztnQ0FDNUMseUNBQXlDO2dDQUV6QyxLQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxHQUFHLEdBQUcsS0FBSyxHQUFHLGVBQWUsRUFBRSxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUM7Z0NBQ2xGLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLEdBQUcsR0FBRyxLQUFLLEdBQUMsb0JBQW9CLEVBQUUsS0FBSSxDQUFDLGdCQUFnQixFQUFFLEVBQUUsQ0FBQyxDQUFDOzRCQUV6RyxDQUFDO3dCQUNMLENBQUM7b0JBQ0wsQ0FBQyxDQU1BLENBQUM7b0JBRUYsSUFBSSxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUM7b0JBQ3ZCLElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO2dCQUM1QixDQUFDO2dCQUNELHNDQUFRLEdBQVI7b0JBQ0ksRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsSUFBSSxlQUFlLENBQUMsQ0FBQyxDQUFDO3dCQUNuQyxXQUFXO3dCQUNYLElBQUksU0FBUyxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUM7d0JBQ3RELE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLEdBQUcsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLE9BQU8sR0FBRyxHQUFHLEdBQUcsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDO29CQUNyRyxDQUFDO2dCQUNMLENBQUM7Z0JBQ0QsNENBQWMsR0FBZDtvQkFFSSxJQUFJLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztvQkFDckIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEdBQUcsRUFBRSxDQUFDO29CQUNuQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxFQUFFLENBQUM7Z0JBQ3hDLENBQUM7Z0JBRUQsc0NBQVEsR0FBUjtvQkFBQSxpQkF1REM7b0JBckRHLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDcEQsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDdkIsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDekQsQ0FBQztvQkFFRCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7d0JBQ3BCLElBQUksQ0FBQyxTQUFTLEdBQUcsVUFBVSxDQUFDO3dCQUM1QixJQUFJLENBQUMsWUFBWSxHQUFHLGFBQWEsQ0FBQztvQkFDdEMsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixJQUFJLENBQUMsU0FBUyxHQUFHLFVBQVUsQ0FBQzt3QkFDNUIsSUFBSSxDQUFDLFlBQVksR0FBRyxZQUFZLENBQUM7b0JBQ3JDLENBQUM7b0JBQ0QsUUFBUSxDQUFDO29CQUNULElBQUksS0FBSyxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUM7b0JBQy9DLElBQUksS0FBSyxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsS0FBSyxHQUFHLFFBQVEsQ0FBQyxDQUFDO29CQUNuRCxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxHQUFHLEdBQUcsS0FBSyxHQUFDLGVBQWUsQ0FBQyxDQUFDO29CQUNqRixFQUFFLENBQUMsQ0FBQyxLQUFLLElBQUksU0FBUyxJQUFJLEtBQUssSUFBSSxTQUFTLElBQUksS0FBSyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7d0JBQzFELEtBQUssR0FBRyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7d0JBQ3pDLElBQUksQ0FBQyxVQUFVLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDOUMsQ0FBQztvQkFFRCxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxHQUFHLEdBQUcsS0FBSyxHQUFDLG9CQUFvQixDQUFDLENBQUM7b0JBQ3JGLEVBQUUsQ0FBQyxDQUFDLElBQUksSUFBSSxTQUFTLElBQUksSUFBSSxJQUFJLFNBQVMsSUFBSSxJQUFJLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzt3QkFDdkQsSUFBSSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQzt3QkFDdEMsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQztvQkFDakMsQ0FBQztvQkFFRixJQUFJLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7d0JBQ3pFLFdBQVc7d0JBQ1gsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQ3RELE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEtBQUksQ0FBQyxHQUFHLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzt3QkFFN0IsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztnQkFHTixDQUFDO2dCQTFUTSwyQkFBTyxHQUFHLENBQUMsUUFBUSxFQUFFLFdBQVcsRUFBRSxlQUFlLENBQUMsQ0FBQztnQkFmOUQ7b0JBQUMsZ0JBQVMsQ0FBQzt3QkFFUCxXQUFXLEVBQUUsbURBQW1EO3dCQUNoRSxVQUFVLEVBQUUsQ0FBQyxpQkFBUSxFQUFFLHFCQUFZLEVBQUUsd0JBQWUsRUFBRSx1QkFBdUIsRUFBRSx3QkFBZSxFQUFFLHdCQUFlLEVBQUUsMEJBQVEsQ0FBQzt3QkFDMUgsU0FBUyxFQUFFLENBQUMsaUNBQWUsRUFBRSxpQ0FBZSxDQUFDO3FCQUNoRCxDQUFDOzt1Q0FBQTtnQkFxVUYsMEJBQUM7WUFBRCxDQW5VQSxBQW1VQyxJQUFBO1lBblVELHFEQW1VQyxDQUFBIiwiZmlsZSI6ImFtYXgvQ3VzdG9tZXIvU2VhcmNoQ3VzdG9tZXIuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBib290c3RyYXAgfSBmcm9tICdhbmd1bGFyMi9wbGF0Zm9ybS9icm93c2VyJzsgICAvLy8vLy8vLy8vLy8vLy9Vc2VkIGZvciBSZWR1eC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vICBcclxuaW1wb3J0IHtOZ1N3aXRjaCwgTmdTd2l0Y2hXaGVuLCBOZ1N3aXRjaERlZmF1bHQsIENPUkVfRElSRUNUSVZFUywgRk9STV9ESVJFQ1RJVkVTfSBmcm9tICdhbmd1bGFyMi9jb21tb24nXHJcbmltcG9ydCB7UmVzb3VyY2VTZXJ2aWNlfSBmcm9tIFwiLi4vLi4vc2VydmljZXMvUmVzb3VyY2VTZXJ2aWNlXCI7XHJcbmltcG9ydCB7Um91dGVQYXJhbXMsIFJPVVRFUl9QUk9WSURFUlMsIEFQUF9CQVNFX0hSRUZ9IGZyb20gXCJhbmd1bGFyMi9yb3V0ZXJcIjsgICAvLy8vLy8vLy8vLy8vLy8vLy8vL1JPVVRFUl9QUk9WSURFUlMsIEFQUF9CQVNFX0hSRUYgVXNlZCBGb3IgUmVkdXgvLy8vXHJcbmltcG9ydCB7Q29tcG9uZW50LCBPdXRwdXQsIElucHV0LCBFdmVudEVtaXR0ZXIsIE9uSW5pdCwgZW5hYmxlUHJvZE1vZGUsIHByb3ZpZGV9IGZyb20gXCJhbmd1bGFyMi9jb3JlXCI7Ly8vLy9lbmFibGVQcm9kTW9kZSxwcm92aWRlIGlzIHVzZWQgZm9yIFJlZHV4XHJcbmltcG9ydCB7Q3VzdG9tZXJTZXJ2aWNlfSBmcm9tIFwiLi4vLi4vc2VydmljZXMvQ3VzdG9tZXJTZXJ2aWNlXCI7XHJcbmltcG9ydCB7IGpzb25RIH0gZnJvbSAnLi4vLi4vanNvblEnO1xyXG5pbXBvcnQge0dyb3VwRmlsdGVyUGlwZSwgR3JvdXBQYXJlbkZpbHRlclBpcGUsIEtlbmRvX3V0aWxpdHl9IGZyb20gXCIuLi8uLi9hbWF4VXRpbFwiO1xyXG5pbXBvcnQge0F1dG9jb21wbGV0ZUNvbnRhaW5lcn0gZnJvbSAnLi4vLi4vYXV0b2NvbXBsZXRlL2F1dG9jb21wbGV0ZS1jb250YWluZXInO1xyXG5pbXBvcnQge0F1dG9jb21wbGV0ZX0gZnJvbSAnLi4vLi4vYXV0b2NvbXBsZXRlL2F1dG9jb21wbGV0ZS5jb21wb25lbnQnO1xyXG5pbXBvcnQgeyBBbWF4RGF0ZSB9IGZyb20gJy4uLy4uL2NvbW9uQ29tcG9uZW50cy9iYXNpY0NvbXBvbmVudHMnO1xyXG5cclxuZXhwb3J0IGNvbnN0IEFVVE9DT01QTEVURV9ESVJFQ1RJVkVTID0gW0F1dG9jb21wbGV0ZSwgQXV0b2NvbXBsZXRlQ29udGFpbmVyXTtcclxuZGVjbGFyZSB2YXIgalF1ZXJ5O1xyXG5kZWNsYXJlIHZhciBzd2FsO1xyXG5kZWNsYXJlIHZhciBtb21lbnQ7XHJcbkBDb21wb25lbnQoe1xyXG5cclxuICAgIHRlbXBsYXRlVXJsOiAnLi9hcHAvYW1heC9DdXN0b21lci90ZW1wbGF0ZXMvQ3VzdG9tZXJTZWFyY2guaHRtbCcsXHJcbiAgICBkaXJlY3RpdmVzOiBbTmdTd2l0Y2gsIE5nU3dpdGNoV2hlbiwgTmdTd2l0Y2hEZWZhdWx0LCBBVVRPQ09NUExFVEVfRElSRUNUSVZFUywgQ09SRV9ESVJFQ1RJVkVTLCBGT1JNX0RJUkVDVElWRVMsIEFtYXhEYXRlXSxcclxuICAgIHByb3ZpZGVyczogW0N1c3RvbWVyU2VydmljZSwgUmVzb3VyY2VTZXJ2aWNlXVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEFtYXhTZWFyY2hDdXN0b21lcnMgaW1wbGVtZW50cyBPbkluaXQge1xyXG4gICAgbW9kZWxJbnB1dCA9IHt9O1xyXG4gICAgY3VzdFNlYXJjaERhdGE6IE9iamVjdCA9IFtdO1xyXG4gICAgQ0hBTkdFRElSOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgUkVTOiBPYmplY3QgPSB7fTtcclxuICAgIExhbmc6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBDaGFuZ2VEaWFsb2c6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBGb3JQb3BVcDogbnVtYmVyID0gMDtcclxuICAgIHN0YXRpYyAkaW5qZWN0ID0gWyckc2NvcGUnLCAnJGxvY2F0aW9uJywgJyRhbmNob3JTY3JvbGwnXTtcclxuICAgIEJhc2VBcHBVcmw6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBGb3JtdHlwZTogc3RyaW5nID0gXCJDVVNUT01FUl9TRUFSQ0hcIjtcclxuICAgIElzYnRuZGlzYWJsZTogc3RyaW5nID0gXCJcIjtcclxuICAgIFNob3dMb2FkZXI6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIEZyb21QYWdlOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgU2VhcmNoQ29udGVudDogc3RyaW5nID0gXCJcIjtcclxuICAgIEVkaXRJY29uQ3NzOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgSXNFeHRlbmRlZDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgRXh0ZW5kZWQ6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIElzUm93Rm91bmQ6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIElzRGlyZWN0OiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBGb3JCYWNrOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgcHJpdmF0ZSBzZWxlY3RlZENhcjogc3RyaW5nID0gJyc7XHJcbiAgICBwcml2YXRlIGFzeW5jU2VsZWN0ZWRDYXI6IHN0cmluZyA9ICcnO1xyXG4gICAgcHJpdmF0ZSBhdXRvY29tcGxldGVMb2FkaW5nOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwcml2YXRlIGF1dG9jb21wbGV0ZU5vUmVzdWx0czogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHJpdmF0ZSBhdXRvY29tcGxldGVTZWxlY3Q6IGJvb2xlYW4gPSBmYWxzZTtcclxuXHJcbiAgICBwcml2YXRlIGdldEN1cnJlbnRDb250ZXh0KCkge1xyXG5cclxuICAgICAgICByZXR1cm4gdGhpcztcclxuICAgIH1cclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgX3Jlc291cmNlU2VydmljZTogUmVzb3VyY2VTZXJ2aWNlLCBwcml2YXRlIF9jdXN0b21lclNlcnZpY2U6IEN1c3RvbWVyU2VydmljZSwgcHJpdmF0ZSBfcm91dGVQYXJhbXM6IFJvdXRlUGFyYW1zKSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5SRVMuQ1VTVE9NRVJfU0VBUkNIID0ge307XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0ID0ge307XHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LklzRXh0ZW5kZWQgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuRXh0ZW5kZWQgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuY3VzdFNlYXJjaERhdGEgPSBbXTtcclxuICAgICAgICB0aGlzLkZvclBvcFVwID0gX3JvdXRlUGFyYW1zLnBhcmFtcy5Gb3JQb3B1cDtcclxuICAgICAgICB0aGlzLkZyb21QYWdlID0gX3JvdXRlUGFyYW1zLnBhcmFtcy5Gcm9tUGFnZTtcclxuICAgICAgICBcclxuICAgICAgICBcclxuICAgICAgICBpZiAodGhpcy5Gcm9tUGFnZSA9PSBcIlJlY2VpcHRDcmVhdGVcIikge1xyXG4gICAgICAgICAgICB0aGlzLkVkaXRJY29uQ3NzID0gXCJtZGktbm90aWZpY2F0aW9uLXN5bmNcIjtcclxuICAgICAgICAgICAgdGhpcy5Jc0RpcmVjdCA9IHRydWU7XHJcbiAgICAgICAgICAgIHRoaXMuRm9yQmFjayA9IF9yb3V0ZVBhcmFtcy5wYXJhbXMuRm9yQmFjaztcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuRWRpdEljb25Dc3MgPSBcIm1kaS1jb250ZW50LWNyZWF0ZVwiO1xyXG4gICAgICAgICAgICB0aGlzLklzRGlyZWN0ID0gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgICAgIC8vaWYgKHRoaXMuRm9yUG9wVXAgPT0gMSkge1xyXG4gICAgICAgICAgICBcclxuICAgICAgICAvLyAgICBqUXVlcnkoJ214LW5hdmJhcicpLmNzcyh7IFwiZGlzcGxheVwiOiBcIm5vbmVcIiB9KTtcclxuICAgICAgICAvLyAgICBqUXVlcnkoJ2Zvb3RlcicpLmNzcyh7IFwiZGlzcGxheVwiOiBcIm5vbmVcIiB9KTtcclxuICAgICAgICAvLyAgICBqUXVlcnkoJ214LWJyZWFkY3J1bWInKS5jc3MoeyBcImRpc3BsYXlcIjogXCJub25lXCIgfSk7XHJcbiAgICAgICAgLy99XHJcbiAgICAgICAgdGhpcy5IaWRlRm9yUG9wVXAodGhpcy5Gb3JQb3BVcCk7XHJcbiAgICAgICAgdGhpcy5CYXNlQXBwVXJsID0gX3Jlc291cmNlU2VydmljZS5BcHBVcmw7XHJcbiAgICAgICAgXHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2FjaGVkUmVzdWx0OiBhbnk7XHJcbiAgICBwcml2YXRlIF9wcmV2aW91c2FzeW5jU2VsZWN0ZWRDYXI6IHN0cmluZyA9ICcnO1xyXG5cclxuICAgIHByaXZhdGUgZ2V0QXN5bmNEYXRhKGNvbnRleHQ6IGFueSk6IEZ1bmN0aW9uIHtcclxuXHJcbiAgICAgICAgdmFyIFNyY2hWYWwgPSBjb250ZXh0LmFzeW5jU2VsZWN0ZWRDYXI7XHJcbiAgICAgIFxyXG4gICAgICAgIC8vIGlmIChTcmNoVmFsICE9IHVuZGVmaW5lZCAmJiBTcmNoVmFsICE9IG51bGwgJiYgU3JjaFZhbCAhPSBcIlwiKSB7XHJcblxyXG4gICAgICAgXHJcbiAgICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAgaWYgKHRoaXMuX3ByZXZpb3VzYXN5bmNTZWxlY3RlZENhciA9PSBjb250ZXh0LmFzeW5jU2VsZWN0ZWRDYXIpIHtcclxuICAgICAgICAgICAgLy9jbGVhclRpbWVvdXQodGhpcy5TdG9wVGltZU91dCk7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9jYWNoZWRSZXN1bHQ7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAvL2FsZXJ0KHRoaXMuX3ByZXZpb3VzYXN5bmNTZWxlY3RlZENhciArIFwiIHwgXCIgKyBjb250ZXh0LmFzeW5jU2VsZWN0ZWRDYXIpO1xyXG4gICAgICAgICAgICBpZiAoY29udGV4dC5hc3luY1NlbGVjdGVkQ2FyICE9IFwiXCIpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3ByZXZpb3VzYXN5bmNTZWxlY3RlZENhciA9IGNvbnRleHQuYXN5bmNTZWxlY3RlZENhcjtcclxuICAgICAgICAgICAgICAgIC8vICB0aGlzLlN0b3BUaW1lT3V0ID0gc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAvLyAgICBhbGVydChTcmNoVmFsKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRDb21wbGV0ZVNlYXJjaChTcmNoVmFsKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vYWxlcnQocmVzcG9uc2UuRXJyTXNnKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29udGV4dC5jYXJzRXhhbXBsZTEgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL3JldHVybiBjb250ZXh0LmNhcnNFeGFtcGxlMTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgICAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAvLyB9LCA1MDApO1xyXG5cclxuICAgICAgICAgICAgICAgIHRoaXMuX2NhY2hlZFJlc3VsdCA9IGNvbnRleHQuY2Fyc0V4YW1wbGUxO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fY2FjaGVkUmVzdWx0ID0gW107XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2NhY2hlZFJlc3VsdDtcclxuICAgICAgICB9XHJcblxyXG5cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIGNoYW5nZUF1dG9jb21wbGV0ZUxvYWRpbmcoZTogYm9vbGVhbikge1xyXG4gICAgICAgIHRoaXMuYXV0b2NvbXBsZXRlTG9hZGluZyA9IGU7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBjaGFuZ2VBdXRvY29tcGxldGVOb1Jlc3VsdHMoZTogYm9vbGVhbikge1xyXG4gICAgICAgIHRoaXMuYXV0b2NvbXBsZXRlU2VsZWN0ID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5hdXRvY29tcGxldGVOb1Jlc3VsdHMgPSBlO1xyXG4gICAgfVxyXG4gICAgcHJpdmF0ZSBhdXRvY29tcGxldGVPblNlbGVjdChlOiBhbnkpIHtcclxuICAgICAgICB0aGlzLmF1dG9jb21wbGV0ZVNlbGVjdCA9IHRydWU7XHJcbiAgICAgICAgY29uc29sZS5sb2coYFNlbGVjdGVkIHZhbHVlOiAke2UuaXRlbX1gKTtcclxuICAgICAgICB2YXIgQ29tcERhdGEgPSBlLml0ZW0uc3BsaXQoJ3wnKTtcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgIGlmIChlLml0ZW0gIT0gdW5kZWZpbmVkICYmIGUuaXRlbSAhPSBcIlwiICYmIGUuaXRlbSAhPSBudWxsKSB7XHJcbiAgICAgICAgICAgIC8vYWxlcnQoQ29tcERhdGFbMF0pO1xyXG5cclxuXHJcbiAgICAgICAgICAgIGlmICh0aGlzLkZyb21QYWdlID09IFwiUmVjZWlwdENyZWF0ZVwiKSB7XHJcbiAgICAgICAgICAgICAgICB2YXIgUmVjZWlwdElkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJUZW1wUmVjZWlwdElkXCIpO1xyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICBkb2N1bWVudC5sb2NhdGlvbj10aGlzLkJhc2VBcHBVcmwgKyBcIlJlY2VpcHRDcmVhdGUvXCIgKyBDb21wRGF0YVswXS50cmltKCkgKyBcIi9cIiArIFJlY2VpcHRJZDtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dCAhPSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIGpkYXRhID0gSlNPTi5zdHJpbmdpZnkodGhpcy5tb2RlbElucHV0KTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5Gcm9tUGFnZSA9PSBcIlJlY2VpcHRDcmVhdGVcIikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgRW1wSWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImVtcGxveWVlaWRcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBPcmdJZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKEVtcElkICsgXCJfT3JnSWRcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5zZXRDb29raWUoRW1wSWQgKyBcIl9cIitPcmdJZCArIFwiX1NlYXJjaF9DYWNoZVwiLCBqZGF0YSwgMTApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2Uuc2V0Q29va2llKEVtcElkICsgXCJfXCIrT3JnSWQrXCJfU2VhcmNoX2F1dG9fQ2FjaGVcIiwgdGhpcy5hc3luY1NlbGVjdGVkQ2FyLCAxMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG5cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dCAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0ICE9IG51bGwpIHtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgamRhdGEgPSBKU09OLnN0cmluZ2lmeSh0aGlzLm1vZGVsSW5wdXQpO1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBFbXBJZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiZW1wbG95ZWVpZFwiKTtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgT3JnSWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShFbXBJZCArIFwiX09yZ0lkXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5zZXRDb29raWUoRW1wSWQgKyBcIl9cIiArIE9yZ0lkICsgXCJfU2VhcmNoX0NhY2hlXCIsIGpkYXRhLCAxMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLnNldENvb2tpZShFbXBJZCArIFwiX1wiICsgT3JnSWQrXCJfU2VhcmNoX2F1dG9fQ2FjaGVcIiwgdGhpcy5hc3luY1NlbGVjdGVkQ2FyLCAxMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBkb2N1bWVudC5sb2NhdGlvbj10aGlzLkJhc2VBcHBVcmwgKyBcIkN1c3RvbWVyL0FkZC9cIiArIENvbXBEYXRhWzBdLnRyaW0oKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcblxyXG4gICAgSGlkZUZvclBvcFVwKEZvclBvcFVwKSB7XHJcbiAgICAgICAgaWYgKEZvclBvcFVwID09IDEpIHtcclxuXHJcbiAgICAgICAgICAgIGpRdWVyeSgnbXgtbmF2YmFyJykuY3NzKHsgXCJkaXNwbGF5XCI6IFwibm9uZVwiIH0pO1xyXG4gICAgICAgICAgICBqUXVlcnkoJ2Zvb3RlcicpLmNzcyh7IFwiZGlzcGxheVwiOiBcIm5vbmVcIiB9KTtcclxuICAgICAgICAgICAgalF1ZXJ5KCdteC1icmVhZGNydW1iJykuY3NzKHsgXCJkaXNwbGF5XCI6IFwibm9uZVwiIH0pO1xyXG4gICAgICAgIH1cclxuICAgIH0gXHJcbiAgICBDaGFuZ2VFeHRlbmRlZEF0dHIoKSB7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0ID0ge307XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LmN1c3RTZWFyY2hEYXRhID0gW107XHJcbiAgICAgICBcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuU2VhcmNoQ29udGVudCA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5hc3luY1NlbGVjdGVkQ2FyID0gXCJcIjtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuSXNSb3dGb3VuZCA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5Jc0V4dGVuZGVkID0galF1ZXJ5KFwiI0V4dGVuZGVkX1wiKS5wcm9wKFwiY2hlY2tlZFwiKTtcclxuICAgICAgIFxyXG4gICAgfVxyXG4gICAgT3BlbkN1c3RvbWVyQ2FyZChDdXN0T2JqKSB7XHJcbiAgICAgIFxyXG4gICAgICAgIGlmICh0aGlzLkZyb21QYWdlID09IFwiUmVjZWlwdENyZWF0ZVwiKSB7XHJcbiAgICAgICAgICAgIHZhciBSZWNlaXB0SWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcIlRlbXBSZWNlaXB0SWRcIik7XHJcbiAgICAgICAgICAgIHBhcmVudC53aW5kb3cub3Blbih0aGlzLkJhc2VBcHBVcmwgKyBcIlJlY2VpcHRDcmVhdGUvXCIgKyBDdXN0T2JqLkN1c3RvbWVySWQgKyBcIi9cIiArIFJlY2VpcHRJZCxcIl9zZWxmXCIpO1xyXG4gICAgICAgICAgICBcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHBhcmVudC53aW5kb3cubG9jYXRpb24ucmVwbGFjZSh0aGlzLkJhc2VBcHBVcmwgKyBcIkN1c3RvbWVyL0FkZC9cIiArIEN1c3RPYmouQ3VzdG9tZXJJZCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgIH1cclxuICAgIFNlYXJjaEN1c3RvbWVyKCkge1xyXG4gICAgICAvLyAgZGVidWdnZXI7XHJcbiAgICAgICAgdGhpcy5Jc2J0bmRpc2FibGUgPSBcImRpc2FibGVkXCI7XHJcbiAgICAgICAgdGhpcy5TaG93TG9hZGVyID0gdHJ1ZTtcclxuICAgICAgICB0aGlzLl9jdXN0b21lclNlcnZpY2UuR2V0Q29tcGxldGVRdWlja1NlYXJjaCh0aGlzLm1vZGVsSW5wdXQuU2VhcmNoQ29udGVudCkuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgLy9hbGVydChyZXNwb25zZS5FcnJNc2cpO1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuY3VzdFNlYXJjaERhdGEgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5jdXN0U2VhcmNoRGF0YS5sZW5ndGggPT0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5Jc1Jvd0ZvdW5kID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuSXNSb3dGb3VuZCA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB2YXIgRW1wSWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImVtcGxveWVlaWRcIik7XHJcbiAgICAgICAgICAgICAgICB2YXIgT3JnSWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShFbXBJZCArIFwiX09yZ0lkXCIpO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dCAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0ICE9IG51bGwpIHtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgamRhdGEgPSBKU09OLnN0cmluZ2lmeSh0aGlzLm1vZGVsSW5wdXQpO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vaWYgKHRoaXMuRnJvbVBhZ2UgPT0gXCJSZWNlaXB0Q3JlYXRlXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2Uuc2V0Q29va2llKEVtcElkICsgXCJfXCIgKyBPcmdJZCArIFwiX1NlYXJjaF9DYWNoZVwiLCBqZGF0YSwgMTApO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5zZXRDb29raWUoRW1wSWQgKyBcIl9cIiArIE9yZ0lkK1wiX1NlYXJjaF9hdXRvX0NhY2hlXCIsIHRoaXMuYXN5bmNTZWxlY3RlZENhciwgMTApO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vICAgICwgZXJyb3I9PiB7XHJcbiAgICAgICAgLy8gICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIC8vfSwgKCkgPT4ge1xyXG4gICAgICAgIC8vICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIC8vICAgIH1cclxuICAgICAgICApO1xyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMuSXNidG5kaXNhYmxlID0gXCJcIjtcclxuICAgICAgICB0aGlzLlNob3dMb2FkZXIgPSBmYWxzZTtcclxuICAgIH1cclxuICAgIEJhY2tQYWdlKCkge1xyXG4gICAgICAgIGlmICh0aGlzLkZyb21QYWdlID09IFwiUmVjZWlwdENyZWF0ZVwiKSB7XHJcbiAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgIHZhciBSZWNlaXB0SWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcIlRlbXBSZWNlaXB0SWRcIik7XHJcbiAgICAgICAgICAgIHBhcmVudC53aW5kb3cub3Blbih0aGlzLkJhc2VBcHBVcmwgKyBcIlJlY2VpcHRDcmVhdGUvXCIgKyB0aGlzLkZvckJhY2sgKyBcIi9cIiArIFJlY2VpcHRJZCwgXCJfc2VsZlwiKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBTZXRkZWZhdWx0UGFnZSgpe1xyXG4gICAgICBcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQgPSB7fTtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuU2VhcmNoQ29udGVudCA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LmN1c3RTZWFyY2hEYXRhID0gW107XHJcbiAgICB9XHJcbiAgICBcclxuICAgIG5nT25Jbml0KCkge1xyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMuTGFuZyA9IHRoaXMuX3Jlc291cmNlU2VydmljZS5nZXRDb29raWUoXCJsYW5nXCIpO1xyXG4gICAgICAgIGlmICh0aGlzLkxhbmcubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICB0aGlzLkxhbmcgPSB0aGlzLkxhbmcuc3Vic3RyaW5nKDEsIHRoaXMuTGFuZy5sZW5ndGgpO1xyXG4gICAgICAgIH1cclxuICAgICAgIFxyXG4gICAgICAgIGlmICh0aGlzLkxhbmcgPT0gXCJoZVwiKSB7XHJcbiAgICAgICAgICAgIHRoaXMuQ0hBTkdFRElSID0gXCJydGxtb2RhbFwiO1xyXG4gICAgICAgICAgICB0aGlzLkNoYW5nZURpYWxvZyA9IFwiaW5wdXRfcmlnaHRcIjtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuQ0hBTkdFRElSID0gXCJsdHJtb2RhbFwiO1xyXG4gICAgICAgICAgICB0aGlzLkNoYW5nZURpYWxvZyA9IFwiaW5wdXRfbGVmdFwiO1xyXG4gICAgICAgIH1cclxuICAgICAgICBkZWJ1Z2dlcjtcclxuICAgICAgICB2YXIgRW1wSWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImVtcGxveWVlaWRcIik7XHJcbiAgICAgICAgdmFyIE9yZ0lkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oRW1wSWQgKyBcIl9PcmdJZFwiKTtcclxuICAgICAgICB2YXIgamRhdGEgPSB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZ2V0Q29va2llKEVtcElkICsgXCJfXCIgKyBPcmdJZCtcIl9TZWFyY2hfQ2FjaGVcIik7XHJcbiAgICAgICAgaWYgKGpkYXRhICE9IHVuZGVmaW5lZCAmJiBqZGF0YSAhPSB1bmRlZmluZWQgJiYgamRhdGEgIT0gXCJcIikge1xyXG4gICAgICAgICAgICBqZGF0YSA9IGpkYXRhLnN1YnN0cmluZygxLCBqZGF0YS5sZW5ndGgpO1xyXG4gICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQgPSBqUXVlcnkucGFyc2VKU09OKGpkYXRhKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHZhciBhc3luID0gdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmdldENvb2tpZShFbXBJZCArIFwiX1wiICsgT3JnSWQrXCJfU2VhcmNoX2F1dG9fQ2FjaGVcIik7XHJcbiAgICAgICAgaWYgKGFzeW4gIT0gdW5kZWZpbmVkICYmIGFzeW4gIT0gdW5kZWZpbmVkICYmIGFzeW4gIT0gXCJcIikge1xyXG4gICAgICAgICAgICBhc3luID0gYXN5bi5zdWJzdHJpbmcoMSwgYXN5bi5sZW5ndGgpO1xyXG4gICAgICAgICAgICB0aGlzLmFzeW5jU2VsZWN0ZWRDYXIgPSBhc3luO1xyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5HZXRMYW5nUmVzKHRoaXMuRm9ybXR5cGUsIHRoaXMuTGFuZykuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgIH1cclxuICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgdGhpcy5SRVMgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAvL2FsZXJ0KHRoaXMuUkVTKTtcclxuICAgICAgICAgICB9XHJcbiAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICB9KTtcclxuICAgICAgIFxyXG4gICAgICAgIFxyXG4gICAgfVxyXG59XHJcbiJdfQ==
