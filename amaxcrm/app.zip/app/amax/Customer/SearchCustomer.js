System.register(['angular2/common', "../../services/ResourceService", "angular2/router", "angular2/core", "../../services/CustomerService", '../../autocomplete/autocomplete-container', '../../autocomplete/autocomplete.component', '../../comonComponents/basicComponents'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var common_1, ResourceService_1, router_1, core_1, CustomerService_1, autocomplete_container_1, autocomplete_component_1, basicComponents_1;
    var AUTOCOMPLETE_DIRECTIVES, AmaxSearchCustomers;
    return {
        setters:[
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (ResourceService_1_1) {
                ResourceService_1 = ResourceService_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (CustomerService_1_1) {
                CustomerService_1 = CustomerService_1_1;
            },
            function (autocomplete_container_1_1) {
                autocomplete_container_1 = autocomplete_container_1_1;
            },
            function (autocomplete_component_1_1) {
                autocomplete_component_1 = autocomplete_component_1_1;
            },
            function (basicComponents_1_1) {
                basicComponents_1 = basicComponents_1_1;
            }],
        execute: function() {
            exports_1("AUTOCOMPLETE_DIRECTIVES", AUTOCOMPLETE_DIRECTIVES = [autocomplete_component_1.Autocomplete, autocomplete_container_1.AutocompleteContainer]);
            AmaxSearchCustomers = (function () {
                function AmaxSearchCustomers(_resourceService, _customerService, _routeParams) {
                    this._resourceService = _resourceService;
                    this._customerService = _customerService;
                    this._routeParams = _routeParams;
                    this.modelInput = {};
                    this.custSearchData = [];
                    this.CHANGEDIR = "";
                    this.RES = {};
                    this.Lang = "";
                    this.ChangeDialog = "";
                    this.ForPopUp = 0;
                    this.BaseAppUrl = "";
                    this.Formtype = "CUSTOMER_SEARCH";
                    this.Isbtndisable = "";
                    this.ShowLoader = false;
                    this.FromPage = "";
                    this.SearchContent = "";
                    this.EditIconCss = "";
                    this.IsExtended = false;
                    this.Extended = false;
                    this.IsRowFound = false;
                    this.IsDirect = false;
                    this.ForBack = "";
                    this.selectedCar = '';
                    this.asyncSelectedCar = '';
                    this.autocompleteLoading = false;
                    this.autocompleteNoResults = false;
                    this.autocompleteSelect = false;
                    this._previousasyncSelectedCar = '';
                    this.RES.CUSTOMER_SEARCH = {};
                    this.modelInput = {};
                    this.modelInput.IsExtended = false;
                    this.modelInput.Extended = false;
                    this.modelInput.custSearchData = [];
                    this.ForPopUp = _routeParams.params.ForPopup;
                    this.FromPage = _routeParams.params.FromPage;
                    if (this.FromPage == "ReceiptCreate") {
                        this.EditIconCss = "mdi-notification-sync";
                        this.IsDirect = true;
                        this.ForBack = _routeParams.params.ForBack;
                    }
                    else {
                        this.EditIconCss = "mdi-content-create";
                        this.IsDirect = false;
                    }
                    //if (this.ForPopUp == 1) {
                    //    jQuery('mx-navbar').css({ "display": "none" });
                    //    jQuery('footer').css({ "display": "none" });
                    //    jQuery('mx-breadcrumb').css({ "display": "none" });
                    //}
                    this.HideForPopUp(this.ForPopUp);
                    this.BaseAppUrl = _resourceService.AppUrl;
                }
                AmaxSearchCustomers.prototype.getCurrentContext = function () {
                    return this;
                };
                AmaxSearchCustomers.prototype.getAsyncData = function (context) {
                    var _this = this;
                    var SrchVal = context.asyncSelectedCar;
                    // if (SrchVal != undefined && SrchVal != null && SrchVal != "") {
                    // debugger;
                    if (this._previousasyncSelectedCar == context.asyncSelectedCar) {
                        //clearTimeout(this.StopTimeOut);
                        return this._cachedResult;
                    }
                    else {
                        //alert(this._previousasyncSelectedCar + " | " + context.asyncSelectedCar);
                        if (context.asyncSelectedCar != "") {
                            this._previousasyncSelectedCar = context.asyncSelectedCar;
                            //  this.StopTimeOut = setTimeout(() => {
                            //    alert(SrchVal);
                            this._customerService.GetCompleteSearch(SrchVal).subscribe(function (response) {
                                // debugger;
                                response = jQuery.parseJSON(response);
                                if (response.IsError == true) {
                                    //alert(response.ErrMsg);
                                    bootbox.alert({
                                        message: response.ErrMsg,
                                        className: _this.ChangeDialog,
                                        buttons: {
                                            ok: {
                                                //label: 'Ok',
                                                className: _this.CHANGEDIR
                                            }
                                        }
                                    });
                                }
                                else {
                                    context.carsExample1 = response.Data;
                                }
                            }, function (error) {
                                console.log(error);
                            }, function () {
                                console.log("CallCompleted");
                            });
                            // }, 500);
                            this._cachedResult = context.carsExample1;
                        }
                        else {
                            this._cachedResult = [];
                        }
                        return this._cachedResult;
                    }
                };
                AmaxSearchCustomers.prototype.changeAutocompleteLoading = function (e) {
                    this.autocompleteLoading = e;
                };
                AmaxSearchCustomers.prototype.changeAutocompleteNoResults = function (e) {
                    this.autocompleteSelect = false;
                    this.autocompleteNoResults = e;
                };
                AmaxSearchCustomers.prototype.autocompleteOnSelect = function (e) {
                    this.autocompleteSelect = true;
                    console.log("Selected value: " + e.item);
                    var CompData = e.item.split('|');
                    //debugger;
                    if (e.item != undefined && e.item != "" && e.item != null) {
                        //alert(CompData[0]);
                        if (this.FromPage == "ReceiptCreate") {
                            var ReceiptId = localStorage.getItem("TempReceiptId");
                            document.location = this.BaseAppUrl + "ReceiptCreate/" + CompData[0].trim() + "/" + ReceiptId;
                            if (this.modelInput != undefined && this.modelInput != null) {
                                var jdata = JSON.stringify(this.modelInput);
                                if (this.FromPage == "ReceiptCreate") {
                                    this._resourceService.setCookie("_Search_Cache", jdata, 10);
                                    this._resourceService.setCookie("_Search_auto_Cache", this.asyncSelectedCar, 10);
                                }
                            }
                        }
                        else {
                            if (this.modelInput != undefined && this.modelInput != null) {
                                var jdata = JSON.stringify(this.modelInput);
                                this._resourceService.setCookie("_Search_Cache", jdata, 10);
                                this._resourceService.setCookie("_Search_auto_Cache", this.asyncSelectedCar, 10);
                            }
                            document.location = this.BaseAppUrl + "Customer/Add/" + CompData[0].trim();
                        }
                    }
                };
                AmaxSearchCustomers.prototype.HideForPopUp = function (ForPopUp) {
                    if (ForPopUp == 1) {
                        jQuery('mx-navbar').css({ "display": "none" });
                        jQuery('footer').css({ "display": "none" });
                        jQuery('mx-breadcrumb').css({ "display": "none" });
                    }
                };
                AmaxSearchCustomers.prototype.ChangeExtendedAttr = function () {
                    this.modelInput = {};
                    this.modelInput.custSearchData = [];
                    this.modelInput.SearchContent = "";
                    this.asyncSelectedCar = "";
                    this.modelInput.IsRowFound = false;
                    this.modelInput.IsExtended = jQuery("#Extended_").prop("checked");
                };
                AmaxSearchCustomers.prototype.OpenCustomerCard = function (CustObj) {
                    if (this.FromPage == "ReceiptCreate") {
                        var ReceiptId = localStorage.getItem("TempReceiptId");
                        parent.window.open(this.BaseAppUrl + "ReceiptCreate/" + CustObj.CustomerId + "/" + ReceiptId, "_self");
                    }
                    else {
                        parent.window.location.replace(this.BaseAppUrl + "Customer/Add/" + CustObj.CustomerId);
                    }
                };
                AmaxSearchCustomers.prototype.SearchCustomer = function () {
                    var _this = this;
                    //  debugger;
                    this.Isbtndisable = "disabled";
                    this.ShowLoader = true;
                    this._customerService.GetCompleteQuickSearch(this.modelInput.SearchContent).subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            //alert(response.ErrMsg);
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.modelInput.custSearchData = response.Data;
                            if (_this.modelInput.custSearchData.length == 0) {
                                _this.modelInput.IsRowFound = false;
                            }
                            else {
                                _this.modelInput.IsRowFound = true;
                            }
                            if (_this.modelInput != undefined && _this.modelInput != null) {
                                var jdata = JSON.stringify(_this.modelInput);
                                //if (this.FromPage == "ReceiptCreate") {
                                _this._resourceService.setCookie("_Search_Cache", jdata, 10);
                                _this._resourceService.setCookie("_Search_auto_Cache", _this.asyncSelectedCar, 10);
                            }
                        }
                    });
                    this.Isbtndisable = "";
                    this.ShowLoader = false;
                };
                AmaxSearchCustomers.prototype.BackPage = function () {
                    if (this.FromPage == "ReceiptCreate") {
                        //debugger;
                        var ReceiptId = localStorage.getItem("TempReceiptId");
                        parent.window.open(this.BaseAppUrl + "ReceiptCreate/" + this.ForBack + "/" + ReceiptId, "_self");
                    }
                };
                AmaxSearchCustomers.prototype.SetdefaultPage = function () {
                    this.modelInput = {};
                    this.modelInput.SearchContent = "";
                    this.modelInput.custSearchData = [];
                };
                AmaxSearchCustomers.prototype.ngOnInit = function () {
                    var _this = this;
                    this.Lang = this._resourceService.getCookie("lang");
                    if (this.Lang.length > 0) {
                        this.Lang = this.Lang.substring(1, this.Lang.length);
                    }
                    if (this.Lang == "he") {
                        this.CHANGEDIR = "rtlmodal";
                        this.ChangeDialog = "input_right";
                    }
                    else {
                        this.CHANGEDIR = "ltrmodal";
                        this.ChangeDialog = "input_left";
                    }
                    // debugger;
                    var jdata = this._resourceService.getCookie("_Search_Cache");
                    if (jdata != undefined && jdata != undefined && jdata != "") {
                        jdata = jdata.substring(1, jdata.length);
                        this.modelInput = jQuery.parseJSON(jdata);
                    }
                    var asyn = this._resourceService.getCookie("_Search_auto_Cache");
                    if (asyn != undefined && asyn != undefined && asyn != "") {
                        asyn = asyn.substring(1, asyn.length);
                        this.asyncSelectedCar = asyn;
                    }
                    this._resourceService.GetLangRes(this.Formtype, this.Lang).subscribe(function (response) {
                        //debugger;
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.RES = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxSearchCustomers.$inject = ['$scope', '$location', '$anchorScroll'];
                AmaxSearchCustomers = __decorate([
                    core_1.Component({
                        templateUrl: './app/amax/Customer/templates/CustomerSearch.html',
                        directives: [common_1.NgSwitch, common_1.NgSwitchWhen, common_1.NgSwitchDefault, AUTOCOMPLETE_DIRECTIVES, common_1.CORE_DIRECTIVES, common_1.FORM_DIRECTIVES, basicComponents_1.AmaxDate],
                        providers: [CustomerService_1.CustomerService, ResourceService_1.ResourceService]
                    }), 
                    __metadata('design:paramtypes', [ResourceService_1.ResourceService, CustomerService_1.CustomerService, router_1.RouteParams])
                ], AmaxSearchCustomers);
                return AmaxSearchCustomers;
            }());
            exports_1("AmaxSearchCustomers", AmaxSearchCustomers);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFtYXgvQ3VzdG9tZXIvU2VhcmNoQ3VzdG9tZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7OztRQVlhLHVCQUF1Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztZQUF2QixxQ0FBQSx1QkFBdUIsR0FBRyxDQUFDLHFDQUFZLEVBQUUsOENBQXFCLENBQUMsQ0FBQSxDQUFDO1lBVzdFO2dCQStCSSw2QkFBb0IsZ0JBQWlDLEVBQVUsZ0JBQWlDLEVBQVUsWUFBeUI7b0JBQS9HLHFCQUFnQixHQUFoQixnQkFBZ0IsQ0FBaUI7b0JBQVUscUJBQWdCLEdBQWhCLGdCQUFnQixDQUFpQjtvQkFBVSxpQkFBWSxHQUFaLFlBQVksQ0FBYTtvQkE5Qm5JLGVBQVUsR0FBRyxFQUFFLENBQUM7b0JBQ2hCLG1CQUFjLEdBQVcsRUFBRSxDQUFDO29CQUM1QixjQUFTLEdBQVcsRUFBRSxDQUFDO29CQUN2QixRQUFHLEdBQVcsRUFBRSxDQUFDO29CQUNqQixTQUFJLEdBQVcsRUFBRSxDQUFDO29CQUNsQixpQkFBWSxHQUFXLEVBQUUsQ0FBQztvQkFDMUIsYUFBUSxHQUFXLENBQUMsQ0FBQztvQkFFckIsZUFBVSxHQUFXLEVBQUUsQ0FBQztvQkFDeEIsYUFBUSxHQUFXLGlCQUFpQixDQUFDO29CQUNyQyxpQkFBWSxHQUFXLEVBQUUsQ0FBQztvQkFDMUIsZUFBVSxHQUFZLEtBQUssQ0FBQztvQkFDNUIsYUFBUSxHQUFXLEVBQUUsQ0FBQztvQkFDdEIsa0JBQWEsR0FBVyxFQUFFLENBQUM7b0JBQzNCLGdCQUFXLEdBQVcsRUFBRSxDQUFDO29CQUN6QixlQUFVLEdBQVksS0FBSyxDQUFDO29CQUM1QixhQUFRLEdBQVksS0FBSyxDQUFDO29CQUMxQixlQUFVLEdBQVksS0FBSyxDQUFDO29CQUM1QixhQUFRLEdBQVksS0FBSyxDQUFDO29CQUMxQixZQUFPLEdBQVcsRUFBRSxDQUFDO29CQUNiLGdCQUFXLEdBQVcsRUFBRSxDQUFDO29CQUN6QixxQkFBZ0IsR0FBVyxFQUFFLENBQUM7b0JBQzlCLHdCQUFtQixHQUFZLEtBQUssQ0FBQztvQkFDckMsMEJBQXFCLEdBQVksS0FBSyxDQUFDO29CQUN2Qyx1QkFBa0IsR0FBWSxLQUFLLENBQUM7b0JBd0NwQyw4QkFBeUIsR0FBVyxFQUFFLENBQUM7b0JBaEMzQyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsR0FBRyxFQUFFLENBQUM7b0JBQzlCLElBQUksQ0FBQyxVQUFVLEdBQUcsRUFBRSxDQUFDO29CQUVyQixJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7b0JBQ25DLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQztvQkFDakMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDO29CQUNwQyxJQUFJLENBQUMsUUFBUSxHQUFHLFlBQVksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDO29CQUM3QyxJQUFJLENBQUMsUUFBUSxHQUFHLFlBQVksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDO29CQUc3QyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxJQUFJLGVBQWUsQ0FBQyxDQUFDLENBQUM7d0JBQ25DLElBQUksQ0FBQyxXQUFXLEdBQUcsdUJBQXVCLENBQUM7d0JBQzNDLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO3dCQUNyQixJQUFJLENBQUMsT0FBTyxHQUFHLFlBQVksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDO29CQUMvQyxDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUNGLElBQUksQ0FBQyxXQUFXLEdBQUcsb0JBQW9CLENBQUM7d0JBQ3hDLElBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO29CQUMxQixDQUFDO29CQUVELDJCQUEyQjtvQkFFM0IscURBQXFEO29CQUNyRCxrREFBa0Q7b0JBQ2xELHlEQUF5RDtvQkFDekQsR0FBRztvQkFDSCxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFDakMsSUFBSSxDQUFDLFVBQVUsR0FBRyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUM7Z0JBRTlDLENBQUM7Z0JBbkNPLCtDQUFpQixHQUF6QjtvQkFFSSxNQUFNLENBQUMsSUFBSSxDQUFDO2dCQUNoQixDQUFDO2dCQXFDTywwQ0FBWSxHQUFwQixVQUFxQixPQUFZO29CQUFqQyxpQkF1REM7b0JBckRHLElBQUksT0FBTyxHQUFHLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQztvQkFFdkMsa0VBQWtFO29CQUdsRSxZQUFZO29CQUNaLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyx5QkFBeUIsSUFBSSxPQUFPLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDO3dCQUM3RCxpQ0FBaUM7d0JBQ2pDLE1BQU0sQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDO29CQUM5QixDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUNGLDJFQUEyRTt3QkFDM0UsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLGdCQUFnQixJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7NEJBQ2pDLElBQUksQ0FBQyx5QkFBeUIsR0FBRyxPQUFPLENBQUMsZ0JBQWdCLENBQUM7NEJBQzFELHlDQUF5Qzs0QkFDekMscUJBQXFCOzRCQUNyQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsaUJBQWlCLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTtnQ0FDL0QsWUFBWTtnQ0FDWixRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQztnQ0FDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO29DQUMzQix5QkFBeUI7b0NBQ3pCLE9BQU8sQ0FBQyxLQUFLLENBQUM7d0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO3dDQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7d0NBQzVCLE9BQU8sRUFBRTs0Q0FDTCxFQUFFLEVBQUU7Z0RBQ0EsY0FBYztnREFDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7NkNBQzVCO3lDQUNKO3FDQUNKLENBQUMsQ0FBQztnQ0FDUCxDQUFDO2dDQUNELElBQUksQ0FBQyxDQUFDO29DQUNGLE9BQU8sQ0FBQyxZQUFZLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQztnQ0FHekMsQ0FBQzs0QkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO2dDQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7NEJBQ3ZCLENBQUMsRUFBRTtnQ0FDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBOzRCQUNoQyxDQUFDLENBQUMsQ0FBQzs0QkFDSCxXQUFXOzRCQUVYLElBQUksQ0FBQyxhQUFhLEdBQUcsT0FBTyxDQUFDLFlBQVksQ0FBQzt3QkFDOUMsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixJQUFJLENBQUMsYUFBYSxHQUFHLEVBQUUsQ0FBQzt3QkFDNUIsQ0FBQzt3QkFDRCxNQUFNLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQztvQkFDOUIsQ0FBQztnQkFHTCxDQUFDO2dCQUVPLHVEQUF5QixHQUFqQyxVQUFrQyxDQUFVO29CQUN4QyxJQUFJLENBQUMsbUJBQW1CLEdBQUcsQ0FBQyxDQUFDO2dCQUNqQyxDQUFDO2dCQUVPLHlEQUEyQixHQUFuQyxVQUFvQyxDQUFVO29CQUMxQyxJQUFJLENBQUMsa0JBQWtCLEdBQUcsS0FBSyxDQUFDO29CQUNoQyxJQUFJLENBQUMscUJBQXFCLEdBQUcsQ0FBQyxDQUFDO2dCQUNuQyxDQUFDO2dCQUNPLGtEQUFvQixHQUE1QixVQUE2QixDQUFNO29CQUMvQixJQUFJLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDO29CQUMvQixPQUFPLENBQUMsR0FBRyxDQUFDLHFCQUFtQixDQUFDLENBQUMsSUFBTSxDQUFDLENBQUM7b0JBQ3pDLElBQUksUUFBUSxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUNqQyxXQUFXO29CQUNYLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksU0FBUyxJQUFJLENBQUMsQ0FBQyxJQUFJLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzt3QkFDeEQscUJBQXFCO3dCQUdyQixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxJQUFJLGVBQWUsQ0FBQyxDQUFDLENBQUM7NEJBQ25DLElBQUksU0FBUyxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUM7NEJBRXRELFFBQVEsQ0FBQyxRQUFRLEdBQUMsSUFBSSxDQUFDLFVBQVUsR0FBRyxnQkFBZ0IsR0FBRyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLEdBQUcsR0FBRyxHQUFHLFNBQVMsQ0FBQzs0QkFDNUYsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLFVBQVUsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO2dDQUMxRCxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztnQ0FDNUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsSUFBSSxlQUFlLENBQUMsQ0FBQyxDQUFDO29DQUNuQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLGVBQWUsRUFBRSxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUM7b0NBQzVELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsb0JBQW9CLEVBQUUsSUFBSSxDQUFDLGdCQUFnQixFQUFFLEVBQUUsQ0FBQyxDQUFDO2dDQUNyRixDQUFDOzRCQUNMLENBQUM7d0JBQ0wsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFHRixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7Z0NBQzFELElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO2dDQUV4QyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLGVBQWUsRUFBRSxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUM7Z0NBQzVELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsb0JBQW9CLEVBQUUsSUFBSSxDQUFDLGdCQUFnQixFQUFFLEVBQUUsQ0FBQyxDQUFDOzRCQUV6RixDQUFDOzRCQUNELFFBQVEsQ0FBQyxRQUFRLEdBQUMsSUFBSSxDQUFDLFVBQVUsR0FBRyxlQUFlLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO3dCQUM3RSxDQUFDO29CQUNMLENBQUM7Z0JBQ0wsQ0FBQztnQkFHRCwwQ0FBWSxHQUFaLFVBQWEsUUFBUTtvQkFDakIsRUFBRSxDQUFDLENBQUMsUUFBUSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBRWhCLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFLENBQUMsQ0FBQzt3QkFDL0MsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLFNBQVMsRUFBRSxNQUFNLEVBQUUsQ0FBQyxDQUFDO3dCQUM1QyxNQUFNLENBQUMsZUFBZSxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsU0FBUyxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUM7b0JBQ3ZELENBQUM7Z0JBQ0wsQ0FBQztnQkFDRCxnREFBa0IsR0FBbEI7b0JBQ0ksSUFBSSxDQUFDLFVBQVUsR0FBRyxFQUFFLENBQUM7b0JBQ3JCLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLEVBQUUsQ0FBQztvQkFFcEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEdBQUcsRUFBRSxDQUFDO29CQUNuQyxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsRUFBRSxDQUFDO29CQUMzQixJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7b0JBQ25DLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7Z0JBRXRFLENBQUM7Z0JBQ0QsOENBQWdCLEdBQWhCLFVBQWlCLE9BQU87b0JBRXBCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLElBQUksZUFBZSxDQUFDLENBQUMsQ0FBQzt3QkFDbkMsSUFBSSxTQUFTLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQzt3QkFDdEQsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsR0FBRyxnQkFBZ0IsR0FBRyxPQUFPLENBQUMsVUFBVSxHQUFHLEdBQUcsR0FBRyxTQUFTLEVBQUMsT0FBTyxDQUFDLENBQUM7b0JBRTFHLENBQUM7b0JBQ0QsSUFBSSxDQUFDLENBQUM7d0JBQ0YsTUFBTSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxVQUFVLEdBQUcsZUFBZSxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztvQkFDM0YsQ0FBQztnQkFFTCxDQUFDO2dCQUNELDRDQUFjLEdBQWQ7b0JBQUEsaUJBOENDO29CQTdDQyxhQUFhO29CQUNYLElBQUksQ0FBQyxZQUFZLEdBQUcsVUFBVSxDQUFDO29CQUMvQixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztvQkFDdkIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLHNCQUFzQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFFMUYsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IseUJBQXlCOzRCQUN6QixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtnQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUM1QixPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDOzRCQUMvQyxFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDN0MsS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDOzRCQUN2QyxDQUFDOzRCQUNELElBQUksQ0FBQyxDQUFDO2dDQUNGLEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQzs0QkFDdEMsQ0FBQzs0QkFDRCxFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsVUFBVSxJQUFJLFNBQVMsSUFBSSxLQUFJLENBQUMsVUFBVSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7Z0NBQzFELElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO2dDQUM1Qyx5Q0FBeUM7Z0NBQ3JDLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsZUFBZSxFQUFFLEtBQUssRUFBRSxFQUFFLENBQUMsQ0FBQztnQ0FDNUQsS0FBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxvQkFBb0IsRUFBRSxLQUFJLENBQUMsZ0JBQWdCLEVBQUUsRUFBRSxDQUFDLENBQUM7NEJBRXpGLENBQUM7d0JBQ0wsQ0FBQztvQkFDTCxDQUFDLENBTUEsQ0FBQztvQkFFRixJQUFJLENBQUMsWUFBWSxHQUFHLEVBQUUsQ0FBQztvQkFDdkIsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7Z0JBQzVCLENBQUM7Z0JBQ0Qsc0NBQVEsR0FBUjtvQkFDSSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxJQUFJLGVBQWUsQ0FBQyxDQUFDLENBQUM7d0JBQ25DLFdBQVc7d0JBQ1gsSUFBSSxTQUFTLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQzt3QkFDdEQsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsR0FBRyxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsT0FBTyxHQUFHLEdBQUcsR0FBRyxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUM7b0JBQ3JHLENBQUM7Z0JBQ0wsQ0FBQztnQkFDRCw0Q0FBYyxHQUFkO29CQUVJLElBQUksQ0FBQyxVQUFVLEdBQUcsRUFBRSxDQUFDO29CQUNyQixJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsR0FBRyxFQUFFLENBQUM7b0JBQ25DLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLEVBQUUsQ0FBQztnQkFDeEMsQ0FBQztnQkFFRCxzQ0FBUSxHQUFSO29CQUFBLGlCQXFEQztvQkFuREcsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUNwRCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUN2QixJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUN6RCxDQUFDO29CQUVELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzt3QkFDcEIsSUFBSSxDQUFDLFNBQVMsR0FBRyxVQUFVLENBQUM7d0JBQzVCLElBQUksQ0FBQyxZQUFZLEdBQUcsYUFBYSxDQUFDO29CQUN0QyxDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUNGLElBQUksQ0FBQyxTQUFTLEdBQUcsVUFBVSxDQUFDO3dCQUM1QixJQUFJLENBQUMsWUFBWSxHQUFHLFlBQVksQ0FBQztvQkFDckMsQ0FBQztvQkFDRixZQUFZO29CQUVYLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLENBQUM7b0JBQzdELEVBQUUsQ0FBQyxDQUFDLEtBQUssSUFBSSxTQUFTLElBQUksS0FBSyxJQUFJLFNBQVMsSUFBSSxLQUFLLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzt3QkFDMUQsS0FBSyxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQzt3QkFDekMsSUFBSSxDQUFDLFVBQVUsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUM5QyxDQUFDO29CQUNELElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsb0JBQW9CLENBQUMsQ0FBQztvQkFDakUsRUFBRSxDQUFDLENBQUMsSUFBSSxJQUFJLFNBQVMsSUFBSSxJQUFJLElBQUksU0FBUyxJQUFJLElBQUksSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO3dCQUN2RCxJQUFJLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO3dCQUN0QyxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDO29CQUNqQyxDQUFDO29CQUVGLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFDekUsV0FBVzt3QkFDWCxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDdEQsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLEdBQUcsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO3dCQUU3QixDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO2dCQUdOLENBQUM7Z0JBalRNLDJCQUFPLEdBQUcsQ0FBQyxRQUFRLEVBQUUsV0FBVyxFQUFFLGVBQWUsQ0FBQyxDQUFDO2dCQWY5RDtvQkFBQyxnQkFBUyxDQUFDO3dCQUVQLFdBQVcsRUFBRSxtREFBbUQ7d0JBQ2hFLFVBQVUsRUFBRSxDQUFDLGlCQUFRLEVBQUUscUJBQVksRUFBRSx3QkFBZSxFQUFFLHVCQUF1QixFQUFFLHdCQUFlLEVBQUUsd0JBQWUsRUFBRSwwQkFBUSxDQUFDO3dCQUMxSCxTQUFTLEVBQUUsQ0FBQyxpQ0FBZSxFQUFFLGlDQUFlLENBQUM7cUJBQ2hELENBQUM7O3VDQUFBO2dCQTRURiwwQkFBQztZQUFELENBMVRBLEFBMFRDLElBQUE7WUExVEQscURBMFRDLENBQUEiLCJmaWxlIjoiYW1heC9DdXN0b21lci9TZWFyY2hDdXN0b21lci5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGJvb3RzdHJhcCB9IGZyb20gJ2FuZ3VsYXIyL3BsYXRmb3JtL2Jyb3dzZXInOyAgIC8vLy8vLy8vLy8vLy8vL1VzZWQgZm9yIFJlZHV4Ly8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8gIFxyXG5pbXBvcnQge05nU3dpdGNoLCBOZ1N3aXRjaFdoZW4sIE5nU3dpdGNoRGVmYXVsdCwgQ09SRV9ESVJFQ1RJVkVTLCBGT1JNX0RJUkVDVElWRVN9IGZyb20gJ2FuZ3VsYXIyL2NvbW1vbidcclxuaW1wb3J0IHtSZXNvdXJjZVNlcnZpY2V9IGZyb20gXCIuLi8uLi9zZXJ2aWNlcy9SZXNvdXJjZVNlcnZpY2VcIjtcclxuaW1wb3J0IHtSb3V0ZVBhcmFtcywgUk9VVEVSX1BST1ZJREVSUywgQVBQX0JBU0VfSFJFRn0gZnJvbSBcImFuZ3VsYXIyL3JvdXRlclwiOyAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vUk9VVEVSX1BST1ZJREVSUywgQVBQX0JBU0VfSFJFRiBVc2VkIEZvciBSZWR1eC8vLy9cclxuaW1wb3J0IHtDb21wb25lbnQsIE91dHB1dCwgSW5wdXQsIEV2ZW50RW1pdHRlciwgT25Jbml0LCBlbmFibGVQcm9kTW9kZSwgcHJvdmlkZX0gZnJvbSBcImFuZ3VsYXIyL2NvcmVcIjsvLy8vL2VuYWJsZVByb2RNb2RlLHByb3ZpZGUgaXMgdXNlZCBmb3IgUmVkdXhcclxuaW1wb3J0IHtDdXN0b21lclNlcnZpY2V9IGZyb20gXCIuLi8uLi9zZXJ2aWNlcy9DdXN0b21lclNlcnZpY2VcIjtcclxuaW1wb3J0IHsganNvblEgfSBmcm9tICcuLi8uLi9qc29uUSc7XHJcbmltcG9ydCB7R3JvdXBGaWx0ZXJQaXBlLCBHcm91cFBhcmVuRmlsdGVyUGlwZSwgS2VuZG9fdXRpbGl0eX0gZnJvbSBcIi4uLy4uL2FtYXhVdGlsXCI7XHJcbmltcG9ydCB7QXV0b2NvbXBsZXRlQ29udGFpbmVyfSBmcm9tICcuLi8uLi9hdXRvY29tcGxldGUvYXV0b2NvbXBsZXRlLWNvbnRhaW5lcic7XHJcbmltcG9ydCB7QXV0b2NvbXBsZXRlfSBmcm9tICcuLi8uLi9hdXRvY29tcGxldGUvYXV0b2NvbXBsZXRlLmNvbXBvbmVudCc7XHJcbmltcG9ydCB7IEFtYXhEYXRlIH0gZnJvbSAnLi4vLi4vY29tb25Db21wb25lbnRzL2Jhc2ljQ29tcG9uZW50cyc7XHJcblxyXG5leHBvcnQgY29uc3QgQVVUT0NPTVBMRVRFX0RJUkVDVElWRVMgPSBbQXV0b2NvbXBsZXRlLCBBdXRvY29tcGxldGVDb250YWluZXJdO1xyXG5kZWNsYXJlIHZhciBqUXVlcnk7XHJcbmRlY2xhcmUgdmFyIHN3YWw7XHJcbmRlY2xhcmUgdmFyIG1vbWVudDtcclxuQENvbXBvbmVudCh7XHJcblxyXG4gICAgdGVtcGxhdGVVcmw6ICcuL2FwcC9hbWF4L0N1c3RvbWVyL3RlbXBsYXRlcy9DdXN0b21lclNlYXJjaC5odG1sJyxcclxuICAgIGRpcmVjdGl2ZXM6IFtOZ1N3aXRjaCwgTmdTd2l0Y2hXaGVuLCBOZ1N3aXRjaERlZmF1bHQsIEFVVE9DT01QTEVURV9ESVJFQ1RJVkVTLCBDT1JFX0RJUkVDVElWRVMsIEZPUk1fRElSRUNUSVZFUywgQW1heERhdGVdLFxyXG4gICAgcHJvdmlkZXJzOiBbQ3VzdG9tZXJTZXJ2aWNlLCBSZXNvdXJjZVNlcnZpY2VdXHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgQW1heFNlYXJjaEN1c3RvbWVycyBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcbiAgICBtb2RlbElucHV0ID0ge307XHJcbiAgICBjdXN0U2VhcmNoRGF0YTogT2JqZWN0ID0gW107XHJcbiAgICBDSEFOR0VESVI6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBSRVM6IE9iamVjdCA9IHt9O1xyXG4gICAgTGFuZzogc3RyaW5nID0gXCJcIjtcclxuICAgIENoYW5nZURpYWxvZzogc3RyaW5nID0gXCJcIjtcclxuICAgIEZvclBvcFVwOiBudW1iZXIgPSAwO1xyXG4gICAgc3RhdGljICRpbmplY3QgPSBbJyRzY29wZScsICckbG9jYXRpb24nLCAnJGFuY2hvclNjcm9sbCddO1xyXG4gICAgQmFzZUFwcFVybDogc3RyaW5nID0gXCJcIjtcclxuICAgIEZvcm10eXBlOiBzdHJpbmcgPSBcIkNVU1RPTUVSX1NFQVJDSFwiO1xyXG4gICAgSXNidG5kaXNhYmxlOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgU2hvd0xvYWRlcjogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgRnJvbVBhZ2U6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBTZWFyY2hDb250ZW50OiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgRWRpdEljb25Dc3M6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBJc0V4dGVuZGVkOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBFeHRlbmRlZDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgSXNSb3dGb3VuZDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgSXNEaXJlY3Q6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIEZvckJhY2s6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBwcml2YXRlIHNlbGVjdGVkQ2FyOiBzdHJpbmcgPSAnJztcclxuICAgIHByaXZhdGUgYXN5bmNTZWxlY3RlZENhcjogc3RyaW5nID0gJyc7XHJcbiAgICBwcml2YXRlIGF1dG9jb21wbGV0ZUxvYWRpbmc6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHByaXZhdGUgYXV0b2NvbXBsZXRlTm9SZXN1bHRzOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwcml2YXRlIGF1dG9jb21wbGV0ZVNlbGVjdDogYm9vbGVhbiA9IGZhbHNlO1xyXG5cclxuICAgIHByaXZhdGUgZ2V0Q3VycmVudENvbnRleHQoKSB7XHJcblxyXG4gICAgICAgIHJldHVybiB0aGlzO1xyXG4gICAgfVxyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBfcmVzb3VyY2VTZXJ2aWNlOiBSZXNvdXJjZVNlcnZpY2UsIHByaXZhdGUgX2N1c3RvbWVyU2VydmljZTogQ3VzdG9tZXJTZXJ2aWNlLCBwcml2YXRlIF9yb3V0ZVBhcmFtczogUm91dGVQYXJhbXMpIHtcclxuICAgICAgICBcclxuICAgICAgICB0aGlzLlJFUy5DVVNUT01FUl9TRUFSQ0ggPSB7fTtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQgPSB7fTtcclxuICAgICAgICBcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuSXNFeHRlbmRlZCA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5FeHRlbmRlZCA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5jdXN0U2VhcmNoRGF0YSA9IFtdO1xyXG4gICAgICAgIHRoaXMuRm9yUG9wVXAgPSBfcm91dGVQYXJhbXMucGFyYW1zLkZvclBvcHVwO1xyXG4gICAgICAgIHRoaXMuRnJvbVBhZ2UgPSBfcm91dGVQYXJhbXMucGFyYW1zLkZyb21QYWdlO1xyXG4gICAgICAgIFxyXG4gICAgICAgIFxyXG4gICAgICAgIGlmICh0aGlzLkZyb21QYWdlID09IFwiUmVjZWlwdENyZWF0ZVwiKSB7XHJcbiAgICAgICAgICAgIHRoaXMuRWRpdEljb25Dc3MgPSBcIm1kaS1ub3RpZmljYXRpb24tc3luY1wiO1xyXG4gICAgICAgICAgICB0aGlzLklzRGlyZWN0ID0gdHJ1ZTtcclxuICAgICAgICAgICAgdGhpcy5Gb3JCYWNrID0gX3JvdXRlUGFyYW1zLnBhcmFtcy5Gb3JCYWNrO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5FZGl0SWNvbkNzcyA9IFwibWRpLWNvbnRlbnQtY3JlYXRlXCI7XHJcbiAgICAgICAgICAgIHRoaXMuSXNEaXJlY3QgPSBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICAgICAgLy9pZiAodGhpcy5Gb3JQb3BVcCA9PSAxKSB7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgIC8vICAgIGpRdWVyeSgnbXgtbmF2YmFyJykuY3NzKHsgXCJkaXNwbGF5XCI6IFwibm9uZVwiIH0pO1xyXG4gICAgICAgIC8vICAgIGpRdWVyeSgnZm9vdGVyJykuY3NzKHsgXCJkaXNwbGF5XCI6IFwibm9uZVwiIH0pO1xyXG4gICAgICAgIC8vICAgIGpRdWVyeSgnbXgtYnJlYWRjcnVtYicpLmNzcyh7IFwiZGlzcGxheVwiOiBcIm5vbmVcIiB9KTtcclxuICAgICAgICAvL31cclxuICAgICAgICB0aGlzLkhpZGVGb3JQb3BVcCh0aGlzLkZvclBvcFVwKTtcclxuICAgICAgICB0aGlzLkJhc2VBcHBVcmwgPSBfcmVzb3VyY2VTZXJ2aWNlLkFwcFVybDtcclxuICAgICAgICBcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9jYWNoZWRSZXN1bHQ6IGFueTtcclxuICAgIHByaXZhdGUgX3ByZXZpb3VzYXN5bmNTZWxlY3RlZENhcjogc3RyaW5nID0gJyc7XHJcblxyXG4gICAgcHJpdmF0ZSBnZXRBc3luY0RhdGEoY29udGV4dDogYW55KTogRnVuY3Rpb24ge1xyXG5cclxuICAgICAgICB2YXIgU3JjaFZhbCA9IGNvbnRleHQuYXN5bmNTZWxlY3RlZENhcjtcclxuICAgICAgXHJcbiAgICAgICAgLy8gaWYgKFNyY2hWYWwgIT0gdW5kZWZpbmVkICYmIFNyY2hWYWwgIT0gbnVsbCAmJiBTcmNoVmFsICE9IFwiXCIpIHtcclxuXHJcbiAgICAgICBcclxuICAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICBpZiAodGhpcy5fcHJldmlvdXNhc3luY1NlbGVjdGVkQ2FyID09IGNvbnRleHQuYXN5bmNTZWxlY3RlZENhcikge1xyXG4gICAgICAgICAgICAvL2NsZWFyVGltZW91dCh0aGlzLlN0b3BUaW1lT3V0KTtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2NhY2hlZFJlc3VsdDtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIC8vYWxlcnQodGhpcy5fcHJldmlvdXNhc3luY1NlbGVjdGVkQ2FyICsgXCIgfCBcIiArIGNvbnRleHQuYXN5bmNTZWxlY3RlZENhcik7XHJcbiAgICAgICAgICAgIGlmIChjb250ZXh0LmFzeW5jU2VsZWN0ZWRDYXIgIT0gXCJcIikge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcHJldmlvdXNhc3luY1NlbGVjdGVkQ2FyID0gY29udGV4dC5hc3luY1NlbGVjdGVkQ2FyO1xyXG4gICAgICAgICAgICAgICAgLy8gIHRoaXMuU3RvcFRpbWVPdXQgPSBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICAgICAgICAgIC8vICAgIGFsZXJ0KFNyY2hWYWwpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkdldENvbXBsZXRlU2VhcmNoKFNyY2hWYWwpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAgICAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9hbGVydChyZXNwb25zZS5FcnJNc2cpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb250ZXh0LmNhcnNFeGFtcGxlMSA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vcmV0dXJuIGNvbnRleHQuY2Fyc0V4YW1wbGUxO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIC8vIH0sIDUwMCk7XHJcblxyXG4gICAgICAgICAgICAgICAgdGhpcy5fY2FjaGVkUmVzdWx0ID0gY29udGV4dC5jYXJzRXhhbXBsZTE7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9jYWNoZWRSZXN1bHQgPSBbXTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fY2FjaGVkUmVzdWx0O1xyXG4gICAgICAgIH1cclxuXHJcblxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgY2hhbmdlQXV0b2NvbXBsZXRlTG9hZGluZyhlOiBib29sZWFuKSB7XHJcbiAgICAgICAgdGhpcy5hdXRvY29tcGxldGVMb2FkaW5nID0gZTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIGNoYW5nZUF1dG9jb21wbGV0ZU5vUmVzdWx0cyhlOiBib29sZWFuKSB7XHJcbiAgICAgICAgdGhpcy5hdXRvY29tcGxldGVTZWxlY3QgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLmF1dG9jb21wbGV0ZU5vUmVzdWx0cyA9IGU7XHJcbiAgICB9XHJcbiAgICBwcml2YXRlIGF1dG9jb21wbGV0ZU9uU2VsZWN0KGU6IGFueSkge1xyXG4gICAgICAgIHRoaXMuYXV0b2NvbXBsZXRlU2VsZWN0ID0gdHJ1ZTtcclxuICAgICAgICBjb25zb2xlLmxvZyhgU2VsZWN0ZWQgdmFsdWU6ICR7ZS5pdGVtfWApO1xyXG4gICAgICAgIHZhciBDb21wRGF0YSA9IGUuaXRlbS5zcGxpdCgnfCcpO1xyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgaWYgKGUuaXRlbSAhPSB1bmRlZmluZWQgJiYgZS5pdGVtICE9IFwiXCIgJiYgZS5pdGVtICE9IG51bGwpIHtcclxuICAgICAgICAgICAgLy9hbGVydChDb21wRGF0YVswXSk7XHJcblxyXG5cclxuICAgICAgICAgICAgaWYgKHRoaXMuRnJvbVBhZ2UgPT0gXCJSZWNlaXB0Q3JlYXRlXCIpIHtcclxuICAgICAgICAgICAgICAgIHZhciBSZWNlaXB0SWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcIlRlbXBSZWNlaXB0SWRcIik7XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIGRvY3VtZW50LmxvY2F0aW9uPXRoaXMuQmFzZUFwcFVybCArIFwiUmVjZWlwdENyZWF0ZS9cIiArIENvbXBEYXRhWzBdLnRyaW0oKSArIFwiL1wiICsgUmVjZWlwdElkO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dCAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0ICE9IG51bGwpIHtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgamRhdGEgPSBKU09OLnN0cmluZ2lmeSh0aGlzLm1vZGVsSW5wdXQpO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLkZyb21QYWdlID09IFwiUmVjZWlwdENyZWF0ZVwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5zZXRDb29raWUoXCJfU2VhcmNoX0NhY2hlXCIsIGpkYXRhLCAxMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5zZXRDb29raWUoXCJfU2VhcmNoX2F1dG9fQ2FjaGVcIiwgdGhpcy5hc3luY1NlbGVjdGVkQ2FyLCAxMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG5cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dCAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0ICE9IG51bGwpIHtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgamRhdGEgPSBKU09OLnN0cmluZ2lmeSh0aGlzLm1vZGVsSW5wdXQpO1xyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2Uuc2V0Q29va2llKFwiX1NlYXJjaF9DYWNoZVwiLCBqZGF0YSwgMTApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2Uuc2V0Q29va2llKFwiX1NlYXJjaF9hdXRvX0NhY2hlXCIsIHRoaXMuYXN5bmNTZWxlY3RlZENhciwgMTApO1xyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZG9jdW1lbnQubG9jYXRpb249dGhpcy5CYXNlQXBwVXJsICsgXCJDdXN0b21lci9BZGQvXCIgKyBDb21wRGF0YVswXS50cmltKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG5cclxuICAgIEhpZGVGb3JQb3BVcChGb3JQb3BVcCkge1xyXG4gICAgICAgIGlmIChGb3JQb3BVcCA9PSAxKSB7XHJcblxyXG4gICAgICAgICAgICBqUXVlcnkoJ214LW5hdmJhcicpLmNzcyh7IFwiZGlzcGxheVwiOiBcIm5vbmVcIiB9KTtcclxuICAgICAgICAgICAgalF1ZXJ5KCdmb290ZXInKS5jc3MoeyBcImRpc3BsYXlcIjogXCJub25lXCIgfSk7XHJcbiAgICAgICAgICAgIGpRdWVyeSgnbXgtYnJlYWRjcnVtYicpLmNzcyh7IFwiZGlzcGxheVwiOiBcIm5vbmVcIiB9KTtcclxuICAgICAgICB9XHJcbiAgICB9IFxyXG4gICAgQ2hhbmdlRXh0ZW5kZWRBdHRyKCkge1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dCA9IHt9O1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5jdXN0U2VhcmNoRGF0YSA9IFtdO1xyXG4gICAgICAgXHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LlNlYXJjaENvbnRlbnQgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMuYXN5bmNTZWxlY3RlZENhciA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LklzUm93Rm91bmQgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuSXNFeHRlbmRlZCA9IGpRdWVyeShcIiNFeHRlbmRlZF9cIikucHJvcChcImNoZWNrZWRcIik7XHJcbiAgICAgICBcclxuICAgIH1cclxuICAgIE9wZW5DdXN0b21lckNhcmQoQ3VzdE9iaikge1xyXG4gICAgICBcclxuICAgICAgICBpZiAodGhpcy5Gcm9tUGFnZSA9PSBcIlJlY2VpcHRDcmVhdGVcIikge1xyXG4gICAgICAgICAgICB2YXIgUmVjZWlwdElkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJUZW1wUmVjZWlwdElkXCIpO1xyXG4gICAgICAgICAgICBwYXJlbnQud2luZG93Lm9wZW4odGhpcy5CYXNlQXBwVXJsICsgXCJSZWNlaXB0Q3JlYXRlL1wiICsgQ3VzdE9iai5DdXN0b21lcklkICsgXCIvXCIgKyBSZWNlaXB0SWQsXCJfc2VsZlwiKTtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBwYXJlbnQud2luZG93LmxvY2F0aW9uLnJlcGxhY2UodGhpcy5CYXNlQXBwVXJsICsgXCJDdXN0b21lci9BZGQvXCIgKyBDdXN0T2JqLkN1c3RvbWVySWQpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICB9XHJcbiAgICBTZWFyY2hDdXN0b21lcigpIHtcclxuICAgICAgLy8gIGRlYnVnZ2VyO1xyXG4gICAgICAgIHRoaXMuSXNidG5kaXNhYmxlID0gXCJkaXNhYmxlZFwiO1xyXG4gICAgICAgIHRoaXMuU2hvd0xvYWRlciA9IHRydWU7XHJcbiAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkdldENvbXBsZXRlUXVpY2tTZWFyY2godGhpcy5tb2RlbElucHV0LlNlYXJjaENvbnRlbnQpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIC8vYWxlcnQocmVzcG9uc2UuRXJyTXNnKTtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5jdXN0U2VhcmNoRGF0YSA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LmN1c3RTZWFyY2hEYXRhLmxlbmd0aCA9PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LklzUm93Rm91bmQgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5Jc1Jvd0ZvdW5kID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dCAhPSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIGpkYXRhID0gSlNPTi5zdHJpbmdpZnkodGhpcy5tb2RlbElucHV0KTtcclxuICAgICAgICAgICAgICAgICAgICAvL2lmICh0aGlzLkZyb21QYWdlID09IFwiUmVjZWlwdENyZWF0ZVwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5zZXRDb29raWUoXCJfU2VhcmNoX0NhY2hlXCIsIGpkYXRhLCAxMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5zZXRDb29raWUoXCJfU2VhcmNoX2F1dG9fQ2FjaGVcIiwgdGhpcy5hc3luY1NlbGVjdGVkQ2FyLCAxMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy99XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgLy8gICAgLCBlcnJvcj0+IHtcclxuICAgICAgICAvLyAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgLy99LCAoKSA9PiB7XHJcbiAgICAgICAgLy8gICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgLy8gICAgfVxyXG4gICAgICAgICk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5Jc2J0bmRpc2FibGUgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMuU2hvd0xvYWRlciA9IGZhbHNlO1xyXG4gICAgfVxyXG4gICAgQmFja1BhZ2UoKSB7XHJcbiAgICAgICAgaWYgKHRoaXMuRnJvbVBhZ2UgPT0gXCJSZWNlaXB0Q3JlYXRlXCIpIHtcclxuICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgdmFyIFJlY2VpcHRJZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiVGVtcFJlY2VpcHRJZFwiKTtcclxuICAgICAgICAgICAgcGFyZW50LndpbmRvdy5vcGVuKHRoaXMuQmFzZUFwcFVybCArIFwiUmVjZWlwdENyZWF0ZS9cIiArIHRoaXMuRm9yQmFjayArIFwiL1wiICsgUmVjZWlwdElkLCBcIl9zZWxmXCIpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIFNldGRlZmF1bHRQYWdlKCl7XHJcbiAgICAgIFxyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dCA9IHt9O1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5TZWFyY2hDb250ZW50ID0gXCJcIjtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuY3VzdFNlYXJjaERhdGEgPSBbXTtcclxuICAgIH1cclxuICAgIFxyXG4gICAgbmdPbkluaXQoKSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5MYW5nID0gdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmdldENvb2tpZShcImxhbmdcIik7XHJcbiAgICAgICAgaWYgKHRoaXMuTGFuZy5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgIHRoaXMuTGFuZyA9IHRoaXMuTGFuZy5zdWJzdHJpbmcoMSwgdGhpcy5MYW5nLmxlbmd0aCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgXHJcbiAgICAgICAgaWYgKHRoaXMuTGFuZyA9PSBcImhlXCIpIHtcclxuICAgICAgICAgICAgdGhpcy5DSEFOR0VESVIgPSBcInJ0bG1vZGFsXCI7XHJcbiAgICAgICAgICAgIHRoaXMuQ2hhbmdlRGlhbG9nID0gXCJpbnB1dF9yaWdodFwiO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5DSEFOR0VESVIgPSBcImx0cm1vZGFsXCI7XHJcbiAgICAgICAgICAgIHRoaXMuQ2hhbmdlRGlhbG9nID0gXCJpbnB1dF9sZWZ0XCI7XHJcbiAgICAgICAgfVxyXG4gICAgICAgLy8gZGVidWdnZXI7XHJcblxyXG4gICAgICAgIHZhciBqZGF0YSA9IHRoaXMuX3Jlc291cmNlU2VydmljZS5nZXRDb29raWUoXCJfU2VhcmNoX0NhY2hlXCIpO1xyXG4gICAgICAgIGlmIChqZGF0YSAhPSB1bmRlZmluZWQgJiYgamRhdGEgIT0gdW5kZWZpbmVkICYmIGpkYXRhICE9IFwiXCIpIHtcclxuICAgICAgICAgICAgamRhdGEgPSBqZGF0YS5zdWJzdHJpbmcoMSwgamRhdGEubGVuZ3RoKTtcclxuICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0ID0galF1ZXJ5LnBhcnNlSlNPTihqZGF0YSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHZhciBhc3luID0gdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmdldENvb2tpZShcIl9TZWFyY2hfYXV0b19DYWNoZVwiKTtcclxuICAgICAgICBpZiAoYXN5biAhPSB1bmRlZmluZWQgJiYgYXN5biAhPSB1bmRlZmluZWQgJiYgYXN5biAhPSBcIlwiKSB7XHJcbiAgICAgICAgICAgIGFzeW4gPSBhc3luLnN1YnN0cmluZygxLCBhc3luLmxlbmd0aCk7XHJcbiAgICAgICAgICAgIHRoaXMuYXN5bmNTZWxlY3RlZENhciA9IGFzeW47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLkdldExhbmdSZXModGhpcy5Gb3JtdHlwZSwgdGhpcy5MYW5nKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICB0aGlzLlJFUyA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgIC8vYWxlcnQodGhpcy5SRVMpO1xyXG4gICAgICAgICAgIH1cclxuICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgIH0pO1xyXG4gICAgICAgXHJcbiAgICAgICAgXHJcbiAgICB9XHJcbn1cclxuIl19
