System.register(['angular2/common', "../../services/ResourceService", "angular2/router", "angular2/core", "../../services/CustomerService", "../../services/RecieptService", '../../comonComponents/basicComponents'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var common_1, ResourceService_1, router_1, core_1, CustomerService_1, RecieptService_1, basicComponents_1;
    var AmaxSearchProducts;
    return {
        setters:[
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (ResourceService_1_1) {
                ResourceService_1 = ResourceService_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (CustomerService_1_1) {
                CustomerService_1 = CustomerService_1_1;
            },
            function (RecieptService_1_1) {
                RecieptService_1 = RecieptService_1_1;
            },
            function (basicComponents_1_1) {
                basicComponents_1 = basicComponents_1_1;
            }],
        execute: function() {
            AmaxSearchProducts = (function () {
                function AmaxSearchProducts(_resourceService, _customerService, _routeParams, _RecieptService) {
                    this._resourceService = _resourceService;
                    this._customerService = _customerService;
                    this._routeParams = _routeParams;
                    this._RecieptService = _RecieptService;
                    this.modelInput = {};
                    this.custSearchData = [];
                    this._ProdCats = [];
                    this.CHANGEDIR = "";
                    this.RES = {};
                    this.Lang = "";
                    this.ChangeDialog = "";
                    this.ForPopUp = 0;
                    this.BaseAppUrl = "";
                    this.Formtype = "RECEIPT_SEARCH";
                    this.Isbtndisable = "";
                    this.ShowLoader = false;
                    this.FromPage = "";
                    this.SearchContent = "";
                    this.EditIconCss = "";
                    this.IsExtended = false;
                    this.Extended = false;
                    this.IsRowFound = false;
                    this.IsDirect = false;
                    this.ForBack = "";
                    this.RES.RECEIPT_SEARCH = {};
                    this.modelInput = {};
                    this.CustomerId = _routeParams.params.Id;
                    this.modelInput.receiptSearchData = [];
                    this.IsDirect = true;
                    this.EditIconCss = "mdi-notification-sync";
                    //this.ForPopUp = _routeParams.params.ForPopup;
                    //this.FromPage = _routeParams.params.FromPage;
                    //if (this.FromPage == "ReceiptCreate") {
                    //    this.EditIconCss = "mdi-notification-sync";
                    //    this.IsDirect = true;
                    //   // this.ForBack = _routeParams.params.ForBack;
                    //}
                    //else {
                    //    this.EditIconCss = "mdi-content-create";
                    //    this.IsDirect = false;
                    //}
                    //if (this.ForPopUp == 1) {
                    //    jQuery('mx-navbar').css({ "display": "none" });
                    //    jQuery('footer').css({ "display": "none" });
                    //    jQuery('mx-breadcrumb').css({ "display": "none" });
                    //}
                    // this.HideForPopUp(this.ForPopUp);
                    this.BaseAppUrl = _resourceService.AppUrl;
                }
                AmaxSearchProducts.prototype.HideForPopUp = function (ForPopUp) {
                    if (ForPopUp == 1) {
                        jQuery('mx-navbar').css({ "display": "none" });
                        jQuery('footer').css({ "display": "none" });
                        jQuery('mx-breadcrumb').css({ "display": "none" });
                    }
                };
                AmaxSearchProducts.prototype.ChangeExtendedAttr = function () {
                    this.modelInput = {};
                    this.modelInput.custSearchData = [];
                    this.modelInput.SearchContent = "";
                    this.asyncSelectedCar = "";
                    this.modelInput.IsRowFound = false;
                    this.modelInput.IsExtended = jQuery("#Extended_").prop("checked");
                };
                AmaxSearchProducts.prototype.OpenReceiptCard = function (ProdObj) {
                    // debugger;
                    if (ProdObj != undefined && ProdObj != null) {
                        var jdata = JSON.stringify(ProdObj);
                        this._resourceService.setCookie("ReceiptCreate_Product", jdata, 10);
                        var ReceiptId = localStorage.getItem("TempReceiptId");
                        parent.window.open(this.BaseAppUrl + "ReceiptCreate/" + this.CustomerId + "/" + ReceiptId, "_self");
                    }
                };
                //OpenCustomerCard(CustObj) {
                //    if (this.FromPage == "ReceiptCreate") {
                //        var ReceiptId = localStorage.getItem("TempReceiptId");
                //        parent.window.open(this.BaseAppUrl + "ReceiptCreate/" + CustObj.CustomerId + "/" + ReceiptId, "_self");
                //    }
                //    else {
                //        parent.window.location.replace(this.BaseAppUrl + "Customer/Add/" + CustObj.CustomerId);
                //    }
                //}
                AmaxSearchProducts.prototype.SearchReceipt = function () {
                    var _this = this;
                    //  debugger;
                    this.Isbtndisable = "disabled";
                    this.ShowLoader = true;
                    if (this.modelInput.ProdCatId == undefined || this.modelInput.ProdCatId == null) {
                        this.modelInput.ProdCatId = "-1";
                    }
                    if (this.modelInput.PartNumber == undefined || this.modelInput.PartNumber == null) {
                        this.modelInput.PartNumber = "";
                    }
                    if (this.modelInput.ProdNameDis == undefined || this.modelInput.ProdNameDis == null) {
                        this.modelInput.ProdNameDis = "";
                    }
                    this._RecieptService.GetProducts(this.modelInput.ProdCatId, this.modelInput.PartNumber, this.modelInput.ProdNameDis).subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            //alert(response.ErrMsg);
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.modelInput.receiptSearchData = response.Data;
                            if (_this.modelInput.receiptSearchData.length == 0) {
                                _this.modelInput.IsRowFound = false;
                            }
                            else {
                                _this.modelInput.IsRowFound = true;
                            }
                        }
                    });
                    this.Isbtndisable = "";
                    this.ShowLoader = false;
                };
                AmaxSearchProducts.prototype.BackPage = function () {
                    //if (this.FromPage == "ReceiptCreate") {
                    //    debugger;
                    var ReceiptId = localStorage.getItem("TempReceiptId");
                    parent.window.open(this.BaseAppUrl + "ReceiptCreate/" + this.CustomerId + "/" + ReceiptId, "_self");
                    //}
                };
                AmaxSearchProducts.prototype.SetdefaultPage = function () {
                    this.modelInput = {};
                    this.modelInput.SearchContent = "";
                    this.modelInput.custSearchData = [];
                };
                AmaxSearchProducts.prototype.ngOnInit = function () {
                    var _this = this;
                    this.modelInput.PartNumber = "";
                    this.modelInput.ProdNameDis = "";
                    this.modelInput.IsRowFound = false;
                    this._RecieptService.GetProducts(-2, "", "").subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            //alert(response.ErrMsg);
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.modelInput.receiptSearchData = response.Data;
                            if (_this.modelInput.receiptSearchData.length == 0) {
                                _this.modelInput.IsRowFound = false;
                            }
                            else {
                                _this.modelInput.IsRowFound = true;
                            }
                        }
                    });
                    this.Lang = this._resourceService.getCookie("lang");
                    if (this.Lang.length > 0) {
                        this.Lang = this.Lang.substring(1, this.Lang.length);
                    }
                    if (this.Lang == "he") {
                        this.CHANGEDIR = "rtlmodal";
                        this.ChangeDialog = "input_right";
                    }
                    else {
                        this.CHANGEDIR = "ltrmodal";
                        this.ChangeDialog = "input_left";
                    }
                    // debugger;
                    var jdata = this._resourceService.getCookie("_Search_Cache");
                    if (jdata != undefined && jdata != undefined && jdata != "") {
                        jdata = jdata.substring(1, jdata.length);
                        this.modelInput = jQuery.parseJSON(jdata);
                    }
                    this._resourceService.GetLangRes(this.Formtype, this.Lang).subscribe(function (response) {
                        //debugger;
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.RES = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._RecieptService.GetProdCats().subscribe(function (response) {
                        //debugger;
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._ProdCats = response.Data;
                            _this.modelInput.ProdCatId = "-1";
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxSearchProducts.$inject = ['$scope', '$location', '$anchorScroll'];
                AmaxSearchProducts = __decorate([
                    core_1.Component({
                        templateUrl: './app/amax/Receipt/templates/ProductsSearch.html',
                        directives: [common_1.NgSwitch, common_1.NgSwitchWhen, common_1.NgSwitchDefault, common_1.CORE_DIRECTIVES, common_1.FORM_DIRECTIVES, basicComponents_1.AmaxDate],
                        providers: [CustomerService_1.CustomerService, ResourceService_1.ResourceService, RecieptService_1.RecieptService]
                    }), 
                    __metadata('design:paramtypes', [ResourceService_1.ResourceService, CustomerService_1.CustomerService, router_1.RouteParams, RecieptService_1.RecieptService])
                ], AmaxSearchProducts);
                return AmaxSearchProducts;
            }());
            exports_1("AmaxSearchProducts", AmaxSearchProducts);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFtYXgvUmVjZWlwdC9TZWFyY2hQcm9kdWN0cy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztZQXFCQTtnQkF3QkksNEJBQW9CLGdCQUFpQyxFQUFVLGdCQUFpQyxFQUFVLFlBQXlCLEVBQVUsZUFBK0I7b0JBQXhKLHFCQUFnQixHQUFoQixnQkFBZ0IsQ0FBaUI7b0JBQVUscUJBQWdCLEdBQWhCLGdCQUFnQixDQUFpQjtvQkFBVSxpQkFBWSxHQUFaLFlBQVksQ0FBYTtvQkFBVSxvQkFBZSxHQUFmLGVBQWUsQ0FBZ0I7b0JBdkI1SyxlQUFVLEdBQUcsRUFBRSxDQUFDO29CQUVoQixtQkFBYyxHQUFXLEVBQUUsQ0FBQztvQkFDNUIsY0FBUyxHQUFXLEVBQUUsQ0FBQztvQkFDdkIsY0FBUyxHQUFXLEVBQUUsQ0FBQztvQkFDdkIsUUFBRyxHQUFXLEVBQUUsQ0FBQztvQkFDakIsU0FBSSxHQUFXLEVBQUUsQ0FBQztvQkFDbEIsaUJBQVksR0FBVyxFQUFFLENBQUM7b0JBQzFCLGFBQVEsR0FBVyxDQUFDLENBQUM7b0JBRXJCLGVBQVUsR0FBVyxFQUFFLENBQUM7b0JBQ3hCLGFBQVEsR0FBVyxnQkFBZ0IsQ0FBQztvQkFDcEMsaUJBQVksR0FBVyxFQUFFLENBQUM7b0JBQzFCLGVBQVUsR0FBWSxLQUFLLENBQUM7b0JBQzVCLGFBQVEsR0FBVyxFQUFFLENBQUM7b0JBQ3RCLGtCQUFhLEdBQVcsRUFBRSxDQUFDO29CQUMzQixnQkFBVyxHQUFXLEVBQUUsQ0FBQztvQkFDekIsZUFBVSxHQUFZLEtBQUssQ0FBQztvQkFDNUIsYUFBUSxHQUFZLEtBQUssQ0FBQztvQkFDMUIsZUFBVSxHQUFZLEtBQUssQ0FBQztvQkFDNUIsYUFBUSxHQUFZLEtBQUssQ0FBQztvQkFDMUIsWUFBTyxHQUFXLEVBQUUsQ0FBQztvQkFJakIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDO29CQUM3QixJQUFJLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztvQkFDckIsSUFBSSxDQUFDLFVBQVUsR0FBRyxZQUFZLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztvQkFDekMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsR0FBRyxFQUFFLENBQUM7b0JBRXZDLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO29CQUNyQixJQUFJLENBQUMsV0FBVyxHQUFHLHVCQUF1QixDQUFDO29CQUMzQywrQ0FBK0M7b0JBQy9DLCtDQUErQztvQkFHL0MseUNBQXlDO29CQUN6QyxpREFBaUQ7b0JBQ2pELDJCQUEyQjtvQkFDM0IsbURBQW1EO29CQUNuRCxHQUFHO29CQUNILFFBQVE7b0JBQ1IsOENBQThDO29CQUM5Qyw0QkFBNEI7b0JBQzVCLEdBQUc7b0JBRUgsMkJBQTJCO29CQUUzQixxREFBcUQ7b0JBQ3JELGtEQUFrRDtvQkFDbEQseURBQXlEO29CQUN6RCxHQUFHO29CQUNILG9DQUFvQztvQkFDcEMsSUFBSSxDQUFDLFVBQVUsR0FBRyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUM7Z0JBRTlDLENBQUM7Z0JBTUQseUNBQVksR0FBWixVQUFhLFFBQVE7b0JBQ2pCLEVBQUUsQ0FBQyxDQUFDLFFBQVEsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUVoQixNQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsU0FBUyxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUM7d0JBQy9DLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFLENBQUMsQ0FBQzt3QkFDNUMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLFNBQVMsRUFBRSxNQUFNLEVBQUUsQ0FBQyxDQUFDO29CQUN2RCxDQUFDO2dCQUNMLENBQUM7Z0JBQ0QsK0NBQWtCLEdBQWxCO29CQUNJLElBQUksQ0FBQyxVQUFVLEdBQUcsRUFBRSxDQUFDO29CQUNyQixJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxFQUFFLENBQUM7b0JBRXBDLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxHQUFHLEVBQUUsQ0FBQztvQkFDbkMsSUFBSSxDQUFDLGdCQUFnQixHQUFHLEVBQUUsQ0FBQztvQkFDM0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO29CQUNuQyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBRyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO2dCQUV0RSxDQUFDO2dCQUNELDRDQUFlLEdBQWYsVUFBZ0IsT0FBTztvQkFDcEIsWUFBWTtvQkFDWCxFQUFFLENBQUMsQ0FBQyxPQUFPLElBQUksU0FBUyxJQUFJLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO3dCQUMxQyxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDO3dCQUNwQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLHVCQUF1QixFQUFFLEtBQUssRUFBRSxFQUFFLENBQUMsQ0FBQzt3QkFDcEUsSUFBSSxTQUFTLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQzt3QkFDdEQsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsR0FBRyxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsVUFBVSxHQUFHLEdBQUcsR0FBRyxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUM7b0JBQ3hHLENBQUM7Z0JBRUwsQ0FBQztnQkFDRCw2QkFBNkI7Z0JBRTdCLDZDQUE2QztnQkFDN0MsZ0VBQWdFO2dCQUNoRSxpSEFBaUg7Z0JBRWpILE9BQU87Z0JBQ1AsWUFBWTtnQkFDWixpR0FBaUc7Z0JBQ2pHLE9BQU87Z0JBRVAsR0FBRztnQkFDSCwwQ0FBYSxHQUFiO29CQUFBLGlCQWlEQztvQkFoREcsYUFBYTtvQkFDYixJQUFJLENBQUMsWUFBWSxHQUFHLFVBQVUsQ0FBQztvQkFDL0IsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7b0JBQ3ZCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO3dCQUM5RSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7b0JBQ3JDLENBQUM7b0JBQ0QsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7d0JBQ2hGLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztvQkFDcEMsQ0FBQztvQkFDRCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzt3QkFDbEYsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEdBQUcsRUFBRSxDQUFDO29CQUNyQyxDQUFDO29CQUVELElBQUksQ0FBQyxlQUFlLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFFbkksUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IseUJBQXlCOzRCQUN6QixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtnQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUM1QixPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7NEJBQ2xELEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQ2hELEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQzs0QkFDdkMsQ0FBQzs0QkFDRCxJQUFJLENBQUMsQ0FBQztnQ0FDRixLQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7NEJBQ3RDLENBQUM7d0JBQ0wsQ0FBQztvQkFDTCxDQUFDLENBTUEsQ0FBQztvQkFFRixJQUFJLENBQUMsWUFBWSxHQUFHLEVBQUUsQ0FBQztvQkFDdkIsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7Z0JBQzVCLENBQUM7Z0JBQ0QscUNBQVEsR0FBUjtvQkFDSSx5Q0FBeUM7b0JBQ3pDLGVBQWU7b0JBQ1gsSUFBSSxTQUFTLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQztvQkFDdEQsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsR0FBRyxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsVUFBVSxHQUFHLEdBQUcsR0FBRyxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUM7b0JBQ3hHLEdBQUc7Z0JBQ1AsQ0FBQztnQkFDRCwyQ0FBYyxHQUFkO29CQUVJLElBQUksQ0FBQyxVQUFVLEdBQUcsRUFBRSxDQUFDO29CQUNyQixJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsR0FBRyxFQUFFLENBQUM7b0JBQ25DLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLEVBQUUsQ0FBQztnQkFDeEMsQ0FBQztnQkFFRCxxQ0FBUSxHQUFSO29CQUFBLGlCQTJHQztvQkExR0csSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsRUFBRSxDQUFDO29CQUNoQyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsR0FBRyxFQUFFLENBQUM7b0JBQ2pDLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztvQkFFbkMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7d0JBRTNELFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLHlCQUF5Qjs0QkFDekIsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDOzRCQUNsRCxFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUNoRCxLQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7NEJBQ3ZDLENBQUM7NEJBQ0QsSUFBSSxDQUFDLENBQUM7Z0NBQ0YsS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDOzRCQUN0QyxDQUFDO3dCQUNMLENBQUM7b0JBQ0wsQ0FBQyxDQU1BLENBQUM7b0JBQ0YsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUNwRCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUN2QixJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUN6RCxDQUFDO29CQUVELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzt3QkFDcEIsSUFBSSxDQUFDLFNBQVMsR0FBRyxVQUFVLENBQUM7d0JBQzVCLElBQUksQ0FBQyxZQUFZLEdBQUcsYUFBYSxDQUFDO29CQUN0QyxDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUNGLElBQUksQ0FBQyxTQUFTLEdBQUcsVUFBVSxDQUFDO3dCQUM1QixJQUFJLENBQUMsWUFBWSxHQUFHLFlBQVksQ0FBQztvQkFDckMsQ0FBQztvQkFDRCxZQUFZO29CQUVaLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLENBQUM7b0JBQzdELEVBQUUsQ0FBQyxDQUFDLEtBQUssSUFBSSxTQUFTLElBQUksS0FBSyxJQUFJLFNBQVMsSUFBSSxLQUFLLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzt3QkFDMUQsS0FBSyxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQzt3QkFDekMsSUFBSSxDQUFDLFVBQVUsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUM5QyxDQUFDO29CQUdELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFDekUsV0FBVzt3QkFDWCxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDdEQsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLEdBQUcsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO3dCQUU3QixDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUNILElBQUksQ0FBQyxlQUFlLENBQUMsV0FBVyxFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFDakQsV0FBVzt3QkFDWCxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDdEQsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLFNBQVMsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDOzRCQUMvQixLQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7d0JBRXJDLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7Z0JBRVAsQ0FBQztnQkF2UU0sMEJBQU8sR0FBRyxDQUFDLFFBQVEsRUFBRSxXQUFXLEVBQUUsZUFBZSxDQUFDLENBQUM7Z0JBakI5RDtvQkFBQyxnQkFBUyxDQUFDO3dCQUVQLFdBQVcsRUFBRSxrREFBa0Q7d0JBQy9ELFVBQVUsRUFBRSxDQUFDLGlCQUFRLEVBQUUscUJBQVksRUFBRSx3QkFBZSxFQUFFLHdCQUFlLEVBQUUsd0JBQWUsRUFBRSwwQkFBUSxDQUFDO3dCQUNqRyxTQUFTLEVBQUUsQ0FBQyxpQ0FBZSxFQUFFLGlDQUFlLEVBQUUsK0JBQWMsQ0FBQztxQkFDaEUsQ0FBQzs7c0NBQUE7Z0JBb1JGLHlCQUFDO1lBQUQsQ0FsUkEsQUFrUkMsSUFBQTtZQWxSRCxtREFrUkMsQ0FBQSIsImZpbGUiOiJhbWF4L1JlY2VpcHQvU2VhcmNoUHJvZHVjdHMuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBib290c3RyYXAgfSBmcm9tICdhbmd1bGFyMi9wbGF0Zm9ybS9icm93c2VyJzsgICAvLy8vLy8vLy8vLy8vLy9Vc2VkIGZvciBSZWR1eC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vICBcclxuaW1wb3J0IHtOZ1N3aXRjaCwgTmdTd2l0Y2hXaGVuLCBOZ1N3aXRjaERlZmF1bHQsIENPUkVfRElSRUNUSVZFUywgRk9STV9ESVJFQ1RJVkVTfSBmcm9tICdhbmd1bGFyMi9jb21tb24nXHJcbmltcG9ydCB7UmVzb3VyY2VTZXJ2aWNlfSBmcm9tIFwiLi4vLi4vc2VydmljZXMvUmVzb3VyY2VTZXJ2aWNlXCI7XHJcbmltcG9ydCB7Um91dGVQYXJhbXMsIFJPVVRFUl9QUk9WSURFUlMsIEFQUF9CQVNFX0hSRUZ9IGZyb20gXCJhbmd1bGFyMi9yb3V0ZXJcIjsgICAvLy8vLy8vLy8vLy8vLy8vLy8vL1JPVVRFUl9QUk9WSURFUlMsIEFQUF9CQVNFX0hSRUYgVXNlZCBGb3IgUmVkdXgvLy8vXHJcbmltcG9ydCB7Q29tcG9uZW50LCBPdXRwdXQsIElucHV0LCBFdmVudEVtaXR0ZXIsIE9uSW5pdCwgZW5hYmxlUHJvZE1vZGUsIHByb3ZpZGV9IGZyb20gXCJhbmd1bGFyMi9jb3JlXCI7Ly8vLy9lbmFibGVQcm9kTW9kZSxwcm92aWRlIGlzIHVzZWQgZm9yIFJlZHV4XHJcbmltcG9ydCB7Q3VzdG9tZXJTZXJ2aWNlfSBmcm9tIFwiLi4vLi4vc2VydmljZXMvQ3VzdG9tZXJTZXJ2aWNlXCI7XHJcbmltcG9ydCB7UmVjaWVwdFNlcnZpY2V9IGZyb20gXCIuLi8uLi9zZXJ2aWNlcy9SZWNpZXB0U2VydmljZVwiO1xyXG5pbXBvcnQgeyBqc29uUSB9IGZyb20gJy4uLy4uL2pzb25RJztcclxuaW1wb3J0IHtHcm91cEZpbHRlclBpcGUsIEdyb3VwUGFyZW5GaWx0ZXJQaXBlLCBLZW5kb191dGlsaXR5fSBmcm9tIFwiLi4vLi4vYW1heFV0aWxcIjtcclxuaW1wb3J0IHsgQW1heERhdGUgfSBmcm9tICcuLi8uLi9jb21vbkNvbXBvbmVudHMvYmFzaWNDb21wb25lbnRzJztcclxuXHJcbmRlY2xhcmUgdmFyIGpRdWVyeTtcclxuZGVjbGFyZSB2YXIgc3dhbDtcclxuZGVjbGFyZSB2YXIgbW9tZW50O1xyXG5AQ29tcG9uZW50KHtcclxuXHJcbiAgICB0ZW1wbGF0ZVVybDogJy4vYXBwL2FtYXgvUmVjZWlwdC90ZW1wbGF0ZXMvUHJvZHVjdHNTZWFyY2guaHRtbCcsXHJcbiAgICBkaXJlY3RpdmVzOiBbTmdTd2l0Y2gsIE5nU3dpdGNoV2hlbiwgTmdTd2l0Y2hEZWZhdWx0LCBDT1JFX0RJUkVDVElWRVMsIEZPUk1fRElSRUNUSVZFUywgQW1heERhdGVdLFxyXG4gICAgcHJvdmlkZXJzOiBbQ3VzdG9tZXJTZXJ2aWNlLCBSZXNvdXJjZVNlcnZpY2UsIFJlY2llcHRTZXJ2aWNlXVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEFtYXhTZWFyY2hQcm9kdWN0cyBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcbiAgICBtb2RlbElucHV0ID0ge307XHJcbiAgICBDdXN0b21lcklkOiBzdHJpbmc7XHJcbiAgICBjdXN0U2VhcmNoRGF0YTogT2JqZWN0ID0gW107XHJcbiAgICBfUHJvZENhdHM6IE9iamVjdCA9IFtdO1xyXG4gICAgQ0hBTkdFRElSOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgUkVTOiBPYmplY3QgPSB7fTtcclxuICAgIExhbmc6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBDaGFuZ2VEaWFsb2c6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBGb3JQb3BVcDogbnVtYmVyID0gMDtcclxuICAgIHN0YXRpYyAkaW5qZWN0ID0gWyckc2NvcGUnLCAnJGxvY2F0aW9uJywgJyRhbmNob3JTY3JvbGwnXTtcclxuICAgIEJhc2VBcHBVcmw6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBGb3JtdHlwZTogc3RyaW5nID0gXCJSRUNFSVBUX1NFQVJDSFwiO1xyXG4gICAgSXNidG5kaXNhYmxlOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgU2hvd0xvYWRlcjogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgRnJvbVBhZ2U6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBTZWFyY2hDb250ZW50OiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgRWRpdEljb25Dc3M6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBJc0V4dGVuZGVkOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBFeHRlbmRlZDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgSXNSb3dGb3VuZDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgSXNEaXJlY3Q6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIEZvckJhY2s6IHN0cmluZyA9IFwiXCI7XHJcblxyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBfcmVzb3VyY2VTZXJ2aWNlOiBSZXNvdXJjZVNlcnZpY2UsIHByaXZhdGUgX2N1c3RvbWVyU2VydmljZTogQ3VzdG9tZXJTZXJ2aWNlLCBwcml2YXRlIF9yb3V0ZVBhcmFtczogUm91dGVQYXJhbXMsIHByaXZhdGUgX1JlY2llcHRTZXJ2aWNlOiBSZWNpZXB0U2VydmljZSkge1xyXG5cclxuICAgICAgICB0aGlzLlJFUy5SRUNFSVBUX1NFQVJDSCA9IHt9O1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dCA9IHt9O1xyXG4gICAgICAgIHRoaXMuQ3VzdG9tZXJJZCA9IF9yb3V0ZVBhcmFtcy5wYXJhbXMuSWQ7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LnJlY2VpcHRTZWFyY2hEYXRhID0gW107XHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5Jc0RpcmVjdCA9IHRydWU7XHJcbiAgICAgICAgdGhpcy5FZGl0SWNvbkNzcyA9IFwibWRpLW5vdGlmaWNhdGlvbi1zeW5jXCI7XHJcbiAgICAgICAgLy90aGlzLkZvclBvcFVwID0gX3JvdXRlUGFyYW1zLnBhcmFtcy5Gb3JQb3B1cDtcclxuICAgICAgICAvL3RoaXMuRnJvbVBhZ2UgPSBfcm91dGVQYXJhbXMucGFyYW1zLkZyb21QYWdlO1xyXG4gICAgICAgIFxyXG4gICAgICAgXHJcbiAgICAgICAgLy9pZiAodGhpcy5Gcm9tUGFnZSA9PSBcIlJlY2VpcHRDcmVhdGVcIikge1xyXG4gICAgICAgIC8vICAgIHRoaXMuRWRpdEljb25Dc3MgPSBcIm1kaS1ub3RpZmljYXRpb24tc3luY1wiO1xyXG4gICAgICAgIC8vICAgIHRoaXMuSXNEaXJlY3QgPSB0cnVlO1xyXG4gICAgICAgIC8vICAgLy8gdGhpcy5Gb3JCYWNrID0gX3JvdXRlUGFyYW1zLnBhcmFtcy5Gb3JCYWNrO1xyXG4gICAgICAgIC8vfVxyXG4gICAgICAgIC8vZWxzZSB7XHJcbiAgICAgICAgLy8gICAgdGhpcy5FZGl0SWNvbkNzcyA9IFwibWRpLWNvbnRlbnQtY3JlYXRlXCI7XHJcbiAgICAgICAgLy8gICAgdGhpcy5Jc0RpcmVjdCA9IGZhbHNlO1xyXG4gICAgICAgIC8vfVxyXG4gICAgICAgIFxyXG4gICAgICAgIC8vaWYgKHRoaXMuRm9yUG9wVXAgPT0gMSkge1xyXG4gICAgICAgICAgICBcclxuICAgICAgICAvLyAgICBqUXVlcnkoJ214LW5hdmJhcicpLmNzcyh7IFwiZGlzcGxheVwiOiBcIm5vbmVcIiB9KTtcclxuICAgICAgICAvLyAgICBqUXVlcnkoJ2Zvb3RlcicpLmNzcyh7IFwiZGlzcGxheVwiOiBcIm5vbmVcIiB9KTtcclxuICAgICAgICAvLyAgICBqUXVlcnkoJ214LWJyZWFkY3J1bWInKS5jc3MoeyBcImRpc3BsYXlcIjogXCJub25lXCIgfSk7XHJcbiAgICAgICAgLy99XHJcbiAgICAgICAgLy8gdGhpcy5IaWRlRm9yUG9wVXAodGhpcy5Gb3JQb3BVcCk7XHJcbiAgICAgICAgdGhpcy5CYXNlQXBwVXJsID0gX3Jlc291cmNlU2VydmljZS5BcHBVcmw7XHJcblxyXG4gICAgfVxyXG5cclxuXHJcblxyXG5cclxuXHJcbiAgICBIaWRlRm9yUG9wVXAoRm9yUG9wVXApIHtcclxuICAgICAgICBpZiAoRm9yUG9wVXAgPT0gMSkge1xyXG5cclxuICAgICAgICAgICAgalF1ZXJ5KCdteC1uYXZiYXInKS5jc3MoeyBcImRpc3BsYXlcIjogXCJub25lXCIgfSk7XHJcbiAgICAgICAgICAgIGpRdWVyeSgnZm9vdGVyJykuY3NzKHsgXCJkaXNwbGF5XCI6IFwibm9uZVwiIH0pO1xyXG4gICAgICAgICAgICBqUXVlcnkoJ214LWJyZWFkY3J1bWInKS5jc3MoeyBcImRpc3BsYXlcIjogXCJub25lXCIgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgQ2hhbmdlRXh0ZW5kZWRBdHRyKCkge1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dCA9IHt9O1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5jdXN0U2VhcmNoRGF0YSA9IFtdO1xyXG5cclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuU2VhcmNoQ29udGVudCA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5hc3luY1NlbGVjdGVkQ2FyID0gXCJcIjtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuSXNSb3dGb3VuZCA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5Jc0V4dGVuZGVkID0galF1ZXJ5KFwiI0V4dGVuZGVkX1wiKS5wcm9wKFwiY2hlY2tlZFwiKTtcclxuXHJcbiAgICB9XHJcbiAgICBPcGVuUmVjZWlwdENhcmQoUHJvZE9iaikge1xyXG4gICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAgaWYgKFByb2RPYmogIT0gdW5kZWZpbmVkICYmIFByb2RPYmogIT0gbnVsbCkge1xyXG4gICAgICAgICAgICB2YXIgamRhdGEgPSBKU09OLnN0cmluZ2lmeShQcm9kT2JqKTtcclxuICAgICAgICAgICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLnNldENvb2tpZShcIlJlY2VpcHRDcmVhdGVfUHJvZHVjdFwiLCBqZGF0YSwgMTApO1xyXG4gICAgICAgICAgICB2YXIgUmVjZWlwdElkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJUZW1wUmVjZWlwdElkXCIpO1xyXG4gICAgICAgICAgICBwYXJlbnQud2luZG93Lm9wZW4odGhpcy5CYXNlQXBwVXJsICsgXCJSZWNlaXB0Q3JlYXRlL1wiICsgdGhpcy5DdXN0b21lcklkICsgXCIvXCIgKyBSZWNlaXB0SWQsIFwiX3NlbGZcIik7XHJcbiAgICAgICAgfVxyXG5cclxuICAgIH1cclxuICAgIC8vT3BlbkN1c3RvbWVyQ2FyZChDdXN0T2JqKSB7XHJcblxyXG4gICAgLy8gICAgaWYgKHRoaXMuRnJvbVBhZ2UgPT0gXCJSZWNlaXB0Q3JlYXRlXCIpIHtcclxuICAgIC8vICAgICAgICB2YXIgUmVjZWlwdElkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJUZW1wUmVjZWlwdElkXCIpO1xyXG4gICAgLy8gICAgICAgIHBhcmVudC53aW5kb3cub3Blbih0aGlzLkJhc2VBcHBVcmwgKyBcIlJlY2VpcHRDcmVhdGUvXCIgKyBDdXN0T2JqLkN1c3RvbWVySWQgKyBcIi9cIiArIFJlY2VpcHRJZCwgXCJfc2VsZlwiKTtcclxuXHJcbiAgICAvLyAgICB9XHJcbiAgICAvLyAgICBlbHNlIHtcclxuICAgIC8vICAgICAgICBwYXJlbnQud2luZG93LmxvY2F0aW9uLnJlcGxhY2UodGhpcy5CYXNlQXBwVXJsICsgXCJDdXN0b21lci9BZGQvXCIgKyBDdXN0T2JqLkN1c3RvbWVySWQpO1xyXG4gICAgLy8gICAgfVxyXG5cclxuICAgIC8vfVxyXG4gICAgU2VhcmNoUmVjZWlwdCgpIHtcclxuICAgICAgICAvLyAgZGVidWdnZXI7XHJcbiAgICAgICAgdGhpcy5Jc2J0bmRpc2FibGUgPSBcImRpc2FibGVkXCI7XHJcbiAgICAgICAgdGhpcy5TaG93TG9hZGVyID0gdHJ1ZTtcclxuICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LlByb2RDYXRJZCA9PSB1bmRlZmluZWQgfHwgdGhpcy5tb2RlbElucHV0LlByb2RDYXRJZCA9PSBudWxsKSB7XHJcbiAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5Qcm9kQ2F0SWQgPSBcIi0xXCI7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuUGFydE51bWJlciA9PSB1bmRlZmluZWQgfHwgdGhpcy5tb2RlbElucHV0LlBhcnROdW1iZXIgPT0gbnVsbCkge1xyXG4gICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuUGFydE51bWJlciA9IFwiXCI7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuUHJvZE5hbWVEaXMgPT0gdW5kZWZpbmVkIHx8IHRoaXMubW9kZWxJbnB1dC5Qcm9kTmFtZURpcyA9PSBudWxsKSB7XHJcbiAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5Qcm9kTmFtZURpcyA9IFwiXCI7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMuX1JlY2llcHRTZXJ2aWNlLkdldFByb2R1Y3RzKHRoaXMubW9kZWxJbnB1dC5Qcm9kQ2F0SWQsIHRoaXMubW9kZWxJbnB1dC5QYXJ0TnVtYmVyLCB0aGlzLm1vZGVsSW5wdXQuUHJvZE5hbWVEaXMpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuXHJcbiAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIC8vYWxlcnQocmVzcG9uc2UuRXJyTXNnKTtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5yZWNlaXB0U2VhcmNoRGF0YSA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LnJlY2VpcHRTZWFyY2hEYXRhLmxlbmd0aCA9PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LklzUm93Rm91bmQgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5Jc1Jvd0ZvdW5kID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICAgICAgLy8gICAgLCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgLy8gICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgICAgICAvL30sICgpID0+IHtcclxuICAgICAgICAgICAgLy8gICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgICAgIC8vICAgIH1cclxuICAgICAgICApO1xyXG5cclxuICAgICAgICB0aGlzLklzYnRuZGlzYWJsZSA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5TaG93TG9hZGVyID0gZmFsc2U7XHJcbiAgICB9XHJcbiAgICBCYWNrUGFnZSgpIHtcclxuICAgICAgICAvL2lmICh0aGlzLkZyb21QYWdlID09IFwiUmVjZWlwdENyZWF0ZVwiKSB7XHJcbiAgICAgICAgLy8gICAgZGVidWdnZXI7XHJcbiAgICAgICAgICAgIHZhciBSZWNlaXB0SWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcIlRlbXBSZWNlaXB0SWRcIik7XHJcbiAgICAgICAgICAgIHBhcmVudC53aW5kb3cub3Blbih0aGlzLkJhc2VBcHBVcmwgKyBcIlJlY2VpcHRDcmVhdGUvXCIgKyB0aGlzLkN1c3RvbWVySWQgKyBcIi9cIiArIFJlY2VpcHRJZCwgXCJfc2VsZlwiKTtcclxuICAgICAgICAvL31cclxuICAgIH1cclxuICAgIFNldGRlZmF1bHRQYWdlKCkge1xyXG5cclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQgPSB7fTtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuU2VhcmNoQ29udGVudCA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LmN1c3RTZWFyY2hEYXRhID0gW107XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkluaXQoKSB7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LlBhcnROdW1iZXIgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5Qcm9kTmFtZURpcyA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LklzUm93Rm91bmQgPSBmYWxzZTtcclxuXHJcbiAgICAgICAgdGhpcy5fUmVjaWVwdFNlcnZpY2UuR2V0UHJvZHVjdHMoLTIsIFwiXCIsIFwiXCIpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuXHJcbiAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIC8vYWxlcnQocmVzcG9uc2UuRXJyTXNnKTtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5yZWNlaXB0U2VhcmNoRGF0YSA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LnJlY2VpcHRTZWFyY2hEYXRhLmxlbmd0aCA9PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LklzUm93Rm91bmQgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5Jc1Jvd0ZvdW5kID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICAgICAgLy8gICAgLCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgLy8gICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgICAgICAvL30sICgpID0+IHtcclxuICAgICAgICAgICAgLy8gICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgICAgIC8vICAgIH1cclxuICAgICAgICApO1xyXG4gICAgICAgIHRoaXMuTGFuZyA9IHRoaXMuX3Jlc291cmNlU2VydmljZS5nZXRDb29raWUoXCJsYW5nXCIpO1xyXG4gICAgICAgIGlmICh0aGlzLkxhbmcubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICB0aGlzLkxhbmcgPSB0aGlzLkxhbmcuc3Vic3RyaW5nKDEsIHRoaXMuTGFuZy5sZW5ndGgpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHRoaXMuTGFuZyA9PSBcImhlXCIpIHtcclxuICAgICAgICAgICAgdGhpcy5DSEFOR0VESVIgPSBcInJ0bG1vZGFsXCI7XHJcbiAgICAgICAgICAgIHRoaXMuQ2hhbmdlRGlhbG9nID0gXCJpbnB1dF9yaWdodFwiO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5DSEFOR0VESVIgPSBcImx0cm1vZGFsXCI7XHJcbiAgICAgICAgICAgIHRoaXMuQ2hhbmdlRGlhbG9nID0gXCJpbnB1dF9sZWZ0XCI7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vIGRlYnVnZ2VyO1xyXG5cclxuICAgICAgICB2YXIgamRhdGEgPSB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZ2V0Q29va2llKFwiX1NlYXJjaF9DYWNoZVwiKTtcclxuICAgICAgICBpZiAoamRhdGEgIT0gdW5kZWZpbmVkICYmIGpkYXRhICE9IHVuZGVmaW5lZCAmJiBqZGF0YSAhPSBcIlwiKSB7XHJcbiAgICAgICAgICAgIGpkYXRhID0gamRhdGEuc3Vic3RyaW5nKDEsIGpkYXRhLmxlbmd0aCk7XHJcbiAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dCA9IGpRdWVyeS5wYXJzZUpTT04oamRhdGEpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuXHJcbiAgICAgICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLkdldExhbmdSZXModGhpcy5Gb3JtdHlwZSwgdGhpcy5MYW5nKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZywgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLlJFUyA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICAvL2FsZXJ0KHRoaXMuUkVTKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuICAgICAgICB0aGlzLl9SZWNpZXB0U2VydmljZS5HZXRQcm9kQ2F0cygpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX1Byb2RDYXRzID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5Qcm9kQ2F0SWQgPSBcIi0xXCI7XHJcbiAgICAgICAgICAgICAgICAvL2FsZXJ0KHRoaXMuUkVTKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuXHJcbiAgICB9XHJcbn1cclxuIl19
