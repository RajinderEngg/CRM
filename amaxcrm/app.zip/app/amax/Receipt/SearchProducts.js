System.register(['angular2/common', "../../services/ResourceService", "angular2/router", "angular2/core", "../../services/CustomerService", "../../services/RecieptService", '../../comonComponents/basicComponents'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var common_1, ResourceService_1, router_1, core_1, CustomerService_1, RecieptService_1, basicComponents_1;
    var AmaxSearchProducts;
    return {
        setters:[
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (ResourceService_1_1) {
                ResourceService_1 = ResourceService_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (CustomerService_1_1) {
                CustomerService_1 = CustomerService_1_1;
            },
            function (RecieptService_1_1) {
                RecieptService_1 = RecieptService_1_1;
            },
            function (basicComponents_1_1) {
                basicComponents_1 = basicComponents_1_1;
            }],
        execute: function() {
            AmaxSearchProducts = (function () {
                function AmaxSearchProducts(_resourceService, _customerService, _routeParams, _RecieptService) {
                    this._resourceService = _resourceService;
                    this._customerService = _customerService;
                    this._routeParams = _routeParams;
                    this._RecieptService = _RecieptService;
                    this.modelInput = {};
                    this.custSearchData = [];
                    this._ProdCats = [];
                    this.CHANGEDIR = "";
                    this.RES = {};
                    this.Lang = "";
                    this.ChangeDialog = "";
                    this.ForPopUp = 0;
                    this.BaseAppUrl = "";
                    this.Formtype = "RECEIPT_SEARCH";
                    this.Isbtndisable = "";
                    this.ShowLoader = false;
                    this.FromPage = "";
                    this.SearchContent = "";
                    this.EditIconCss = "";
                    this.IsExtended = false;
                    this.Extended = false;
                    this.IsRowFound = false;
                    this.IsDirect = false;
                    this.ForBack = "";
                    this.RES.RECEIPT_SEARCH = {};
                    this.modelInput = {};
                    this.CustomerId = _routeParams.params.Id;
                    this.modelInput.receiptSearchData = [];
                    this.IsDirect = true;
                    this.EditIconCss = "mdi-notification-sync";
                    //this.ForPopUp = _routeParams.params.ForPopup;
                    //this.FromPage = _routeParams.params.FromPage;
                    //if (this.FromPage == "ReceiptCreate") {
                    //    this.EditIconCss = "mdi-notification-sync";
                    //    this.IsDirect = true;
                    //   // this.ForBack = _routeParams.params.ForBack;
                    //}
                    //else {
                    //    this.EditIconCss = "mdi-content-create";
                    //    this.IsDirect = false;
                    //}
                    //if (this.ForPopUp == 1) {
                    //    jQuery('mx-navbar').css({ "display": "none" });
                    //    jQuery('footer').css({ "display": "none" });
                    //    jQuery('mx-breadcrumb').css({ "display": "none" });
                    //}
                    // this.HideForPopUp(this.ForPopUp);
                    this.BaseAppUrl = _resourceService.AppUrl;
                }
                AmaxSearchProducts.prototype.HideForPopUp = function (ForPopUp) {
                    if (ForPopUp == 1) {
                        jQuery('mx-navbar').css({ "display": "none" });
                        jQuery('footer').css({ "display": "none" });
                        jQuery('mx-breadcrumb').css({ "display": "none" });
                    }
                };
                AmaxSearchProducts.prototype.ChangeExtendedAttr = function () {
                    this.modelInput = {};
                    this.modelInput.custSearchData = [];
                    this.modelInput.SearchContent = "";
                    this.asyncSelectedCar = "";
                    this.modelInput.IsRowFound = false;
                    this.modelInput.IsExtended = jQuery("#Extended_").prop("checked");
                };
                AmaxSearchProducts.prototype.OpenReceiptCard = function (ProdObj) {
                    debugger;
                    if (ProdObj != undefined && ProdObj != null) {
                        var jdata = JSON.stringify(ProdObj);
                        this._resourceService.setCookie("ReceiptCreate_Product", jdata, 10);
                        var ReceiptId = localStorage.getItem("TempReceiptId");
                        parent.window.open(this.BaseAppUrl + "ReceiptCreate/" + this.CustomerId + "/" + ReceiptId, "_self");
                    }
                };
                //OpenCustomerCard(CustObj) {
                //    if (this.FromPage == "ReceiptCreate") {
                //        var ReceiptId = localStorage.getItem("TempReceiptId");
                //        parent.window.open(this.BaseAppUrl + "ReceiptCreate/" + CustObj.CustomerId + "/" + ReceiptId, "_self");
                //    }
                //    else {
                //        parent.window.location.replace(this.BaseAppUrl + "Customer/Add/" + CustObj.CustomerId);
                //    }
                //}
                AmaxSearchProducts.prototype.SearchReceipt = function () {
                    var _this = this;
                    //  debugger;
                    this.Isbtndisable = "disabled";
                    this.ShowLoader = true;
                    if (this.modelInput.ProdCatId == undefined || this.modelInput.ProdCatId == null) {
                        this.modelInput.ProdCatId = "-1";
                    }
                    if (this.modelInput.PartNumber == undefined || this.modelInput.PartNumber == null) {
                        this.modelInput.PartNumber = "";
                    }
                    if (this.modelInput.ProdNameDis == undefined || this.modelInput.ProdNameDis == null) {
                        this.modelInput.ProdNameDis = "";
                    }
                    this._RecieptService.GetProducts(this.modelInput.ProdCatId, this.modelInput.PartNumber, this.modelInput.ProdNameDis).subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            //alert(response.ErrMsg);
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.modelInput.receiptSearchData = response.Data;
                            if (_this.modelInput.receiptSearchData.length == 0) {
                                _this.modelInput.IsRowFound = false;
                            }
                            else {
                                _this.modelInput.IsRowFound = true;
                            }
                        }
                    });
                    this.Isbtndisable = "";
                    this.ShowLoader = false;
                };
                AmaxSearchProducts.prototype.BackPage = function () {
                    //if (this.FromPage == "ReceiptCreate") {
                    //    debugger;
                    var ReceiptId = localStorage.getItem("TempReceiptId");
                    parent.window.open(this.BaseAppUrl + "ReceiptCreate/" + this.CustomerId + "/" + ReceiptId, "_self");
                    //}
                };
                AmaxSearchProducts.prototype.SetdefaultPage = function () {
                    this.modelInput = {};
                    this.modelInput.SearchContent = "";
                    this.modelInput.custSearchData = [];
                };
                AmaxSearchProducts.prototype.ngOnInit = function () {
                    var _this = this;
                    this.modelInput.PartNumber = "";
                    this.modelInput.ProdNameDis = "";
                    this.modelInput.IsRowFound = false;
                    this._RecieptService.GetProducts(-2, "", "").subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            //alert(response.ErrMsg);
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.modelInput.receiptSearchData = response.Data;
                            if (_this.modelInput.receiptSearchData.length == 0) {
                                _this.modelInput.IsRowFound = false;
                            }
                            else {
                                _this.modelInput.IsRowFound = true;
                            }
                        }
                    });
                    this.Lang = this._resourceService.getCookie("lang");
                    if (this.Lang.length > 0) {
                        this.Lang = this.Lang.substring(1, this.Lang.length);
                    }
                    if (this.Lang == "he") {
                        this.CHANGEDIR = "rtlmodal";
                        this.ChangeDialog = "input_right";
                    }
                    else {
                        this.CHANGEDIR = "ltrmodal";
                        this.ChangeDialog = "input_left";
                    }
                    // debugger;
                    var jdata = this._resourceService.getCookie("_Search_Cache");
                    if (jdata != undefined && jdata != undefined && jdata != "") {
                        jdata = jdata.substring(1, jdata.length);
                        this.modelInput = jQuery.parseJSON(jdata);
                    }
                    this._resourceService.GetLangRes(this.Formtype, this.Lang).subscribe(function (response) {
                        //debugger;
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.RES = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._RecieptService.GetProdCats().subscribe(function (response) {
                        //debugger;
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._ProdCats = response.Data;
                            _this.modelInput.ProdCatId = "-1";
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxSearchProducts.$inject = ['$scope', '$location', '$anchorScroll'];
                AmaxSearchProducts = __decorate([
                    core_1.Component({
                        templateUrl: './app/amax/Receipt/templates/ProductsSearch.html',
                        directives: [common_1.NgSwitch, common_1.NgSwitchWhen, common_1.NgSwitchDefault, common_1.CORE_DIRECTIVES, common_1.FORM_DIRECTIVES, basicComponents_1.AmaxDate],
                        providers: [CustomerService_1.CustomerService, ResourceService_1.ResourceService, RecieptService_1.RecieptService]
                    }), 
                    __metadata('design:paramtypes', [ResourceService_1.ResourceService, CustomerService_1.CustomerService, router_1.RouteParams, RecieptService_1.RecieptService])
                ], AmaxSearchProducts);
                return AmaxSearchProducts;
            }());
            exports_1("AmaxSearchProducts", AmaxSearchProducts);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFtYXgvUmVjZWlwdC9TZWFyY2hQcm9kdWN0cy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztZQXFCQTtnQkF3QkksNEJBQW9CLGdCQUFpQyxFQUFVLGdCQUFpQyxFQUFVLFlBQXlCLEVBQVUsZUFBK0I7b0JBQXhKLHFCQUFnQixHQUFoQixnQkFBZ0IsQ0FBaUI7b0JBQVUscUJBQWdCLEdBQWhCLGdCQUFnQixDQUFpQjtvQkFBVSxpQkFBWSxHQUFaLFlBQVksQ0FBYTtvQkFBVSxvQkFBZSxHQUFmLGVBQWUsQ0FBZ0I7b0JBdkI1SyxlQUFVLEdBQUcsRUFBRSxDQUFDO29CQUVoQixtQkFBYyxHQUFXLEVBQUUsQ0FBQztvQkFDNUIsY0FBUyxHQUFXLEVBQUUsQ0FBQztvQkFDdkIsY0FBUyxHQUFXLEVBQUUsQ0FBQztvQkFDdkIsUUFBRyxHQUFXLEVBQUUsQ0FBQztvQkFDakIsU0FBSSxHQUFXLEVBQUUsQ0FBQztvQkFDbEIsaUJBQVksR0FBVyxFQUFFLENBQUM7b0JBQzFCLGFBQVEsR0FBVyxDQUFDLENBQUM7b0JBRXJCLGVBQVUsR0FBVyxFQUFFLENBQUM7b0JBQ3hCLGFBQVEsR0FBVyxnQkFBZ0IsQ0FBQztvQkFDcEMsaUJBQVksR0FBVyxFQUFFLENBQUM7b0JBQzFCLGVBQVUsR0FBWSxLQUFLLENBQUM7b0JBQzVCLGFBQVEsR0FBVyxFQUFFLENBQUM7b0JBQ3RCLGtCQUFhLEdBQVcsRUFBRSxDQUFDO29CQUMzQixnQkFBVyxHQUFXLEVBQUUsQ0FBQztvQkFDekIsZUFBVSxHQUFZLEtBQUssQ0FBQztvQkFDNUIsYUFBUSxHQUFZLEtBQUssQ0FBQztvQkFDMUIsZUFBVSxHQUFZLEtBQUssQ0FBQztvQkFDNUIsYUFBUSxHQUFZLEtBQUssQ0FBQztvQkFDMUIsWUFBTyxHQUFXLEVBQUUsQ0FBQztvQkFJakIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDO29CQUM3QixJQUFJLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztvQkFDckIsSUFBSSxDQUFDLFVBQVUsR0FBRyxZQUFZLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztvQkFDekMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsR0FBRyxFQUFFLENBQUM7b0JBRXZDLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO29CQUNyQixJQUFJLENBQUMsV0FBVyxHQUFHLHVCQUF1QixDQUFDO29CQUMzQywrQ0FBK0M7b0JBQy9DLCtDQUErQztvQkFHL0MseUNBQXlDO29CQUN6QyxpREFBaUQ7b0JBQ2pELDJCQUEyQjtvQkFDM0IsbURBQW1EO29CQUNuRCxHQUFHO29CQUNILFFBQVE7b0JBQ1IsOENBQThDO29CQUM5Qyw0QkFBNEI7b0JBQzVCLEdBQUc7b0JBRUgsMkJBQTJCO29CQUUzQixxREFBcUQ7b0JBQ3JELGtEQUFrRDtvQkFDbEQseURBQXlEO29CQUN6RCxHQUFHO29CQUNILG9DQUFvQztvQkFDcEMsSUFBSSxDQUFDLFVBQVUsR0FBRyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUM7Z0JBRTlDLENBQUM7Z0JBTUQseUNBQVksR0FBWixVQUFhLFFBQVE7b0JBQ2pCLEVBQUUsQ0FBQyxDQUFDLFFBQVEsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUVoQixNQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsU0FBUyxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUM7d0JBQy9DLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFLENBQUMsQ0FBQzt3QkFDNUMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLFNBQVMsRUFBRSxNQUFNLEVBQUUsQ0FBQyxDQUFDO29CQUN2RCxDQUFDO2dCQUNMLENBQUM7Z0JBQ0QsK0NBQWtCLEdBQWxCO29CQUNJLElBQUksQ0FBQyxVQUFVLEdBQUcsRUFBRSxDQUFDO29CQUNyQixJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxFQUFFLENBQUM7b0JBRXBDLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxHQUFHLEVBQUUsQ0FBQztvQkFDbkMsSUFBSSxDQUFDLGdCQUFnQixHQUFHLEVBQUUsQ0FBQztvQkFDM0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO29CQUNuQyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBRyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO2dCQUV0RSxDQUFDO2dCQUNELDRDQUFlLEdBQWYsVUFBZ0IsT0FBTztvQkFDbkIsUUFBUSxDQUFDO29CQUNULEVBQUUsQ0FBQyxDQUFDLE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7d0JBQzFDLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUM7d0JBQ3BDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsdUJBQXVCLEVBQUUsS0FBSyxFQUFFLEVBQUUsQ0FBQyxDQUFDO3dCQUNwRSxJQUFJLFNBQVMsR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDO3dCQUN0RCxNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxHQUFHLGdCQUFnQixHQUFHLElBQUksQ0FBQyxVQUFVLEdBQUcsR0FBRyxHQUFHLFNBQVMsRUFBRSxPQUFPLENBQUMsQ0FBQztvQkFDeEcsQ0FBQztnQkFFTCxDQUFDO2dCQUNELDZCQUE2QjtnQkFFN0IsNkNBQTZDO2dCQUM3QyxnRUFBZ0U7Z0JBQ2hFLGlIQUFpSDtnQkFFakgsT0FBTztnQkFDUCxZQUFZO2dCQUNaLGlHQUFpRztnQkFDakcsT0FBTztnQkFFUCxHQUFHO2dCQUNILDBDQUFhLEdBQWI7b0JBQUEsaUJBaURDO29CQWhERyxhQUFhO29CQUNiLElBQUksQ0FBQyxZQUFZLEdBQUcsVUFBVSxDQUFDO29CQUMvQixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztvQkFDdkIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7d0JBQzlFLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQztvQkFDckMsQ0FBQztvQkFDRCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzt3QkFDaEYsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsRUFBRSxDQUFDO29CQUNwQyxDQUFDO29CQUNELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO3dCQUNsRixJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsR0FBRyxFQUFFLENBQUM7b0JBQ3JDLENBQUM7b0JBRUQsSUFBSSxDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUVuSSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQix5QkFBeUI7NEJBQ3pCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO2dDQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQzVCLE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEtBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzs0QkFDbEQsRUFBRSxDQUFDLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDaEQsS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDOzRCQUN2QyxDQUFDOzRCQUNELElBQUksQ0FBQyxDQUFDO2dDQUNGLEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQzs0QkFDdEMsQ0FBQzt3QkFDTCxDQUFDO29CQUNMLENBQUMsQ0FNQSxDQUFDO29CQUVGLElBQUksQ0FBQyxZQUFZLEdBQUcsRUFBRSxDQUFDO29CQUN2QixJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztnQkFDNUIsQ0FBQztnQkFDRCxxQ0FBUSxHQUFSO29CQUNJLHlDQUF5QztvQkFDekMsZUFBZTtvQkFDWCxJQUFJLFNBQVMsR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDO29CQUN0RCxNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxHQUFHLGdCQUFnQixHQUFHLElBQUksQ0FBQyxVQUFVLEdBQUcsR0FBRyxHQUFHLFNBQVMsRUFBRSxPQUFPLENBQUMsQ0FBQztvQkFDeEcsR0FBRztnQkFDUCxDQUFDO2dCQUNELDJDQUFjLEdBQWQ7b0JBRUksSUFBSSxDQUFDLFVBQVUsR0FBRyxFQUFFLENBQUM7b0JBQ3JCLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxHQUFHLEVBQUUsQ0FBQztvQkFDbkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDO2dCQUN4QyxDQUFDO2dCQUVELHFDQUFRLEdBQVI7b0JBQUEsaUJBMkdDO29CQTFHRyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBRyxFQUFFLENBQUM7b0JBQ2hDLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxHQUFHLEVBQUUsQ0FBQztvQkFDakMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO29CQUVuQyxJQUFJLENBQUMsZUFBZSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFFM0QsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IseUJBQXlCOzRCQUN6QixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtnQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUM1QixPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7NEJBQ2xELEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQ2hELEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQzs0QkFDdkMsQ0FBQzs0QkFDRCxJQUFJLENBQUMsQ0FBQztnQ0FDRixLQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7NEJBQ3RDLENBQUM7d0JBQ0wsQ0FBQztvQkFDTCxDQUFDLENBTUEsQ0FBQztvQkFDRixJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQ3BELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ3ZCLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQ3pELENBQUM7b0JBRUQsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO3dCQUNwQixJQUFJLENBQUMsU0FBUyxHQUFHLFVBQVUsQ0FBQzt3QkFDNUIsSUFBSSxDQUFDLFlBQVksR0FBRyxhQUFhLENBQUM7b0JBQ3RDLENBQUM7b0JBQ0QsSUFBSSxDQUFDLENBQUM7d0JBQ0YsSUFBSSxDQUFDLFNBQVMsR0FBRyxVQUFVLENBQUM7d0JBQzVCLElBQUksQ0FBQyxZQUFZLEdBQUcsWUFBWSxDQUFDO29CQUNyQyxDQUFDO29CQUNELFlBQVk7b0JBRVosSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsQ0FBQztvQkFDN0QsRUFBRSxDQUFDLENBQUMsS0FBSyxJQUFJLFNBQVMsSUFBSSxLQUFLLElBQUksU0FBUyxJQUFJLEtBQUssSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO3dCQUMxRCxLQUFLLEdBQUcsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDO3dCQUN6QyxJQUFJLENBQUMsVUFBVSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQzlDLENBQUM7b0JBR0QsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUN6RSxXQUFXO3dCQUNYLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUN0RCxPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsR0FBRyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7d0JBRTdCLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsSUFBSSxDQUFDLGVBQWUsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUNqRCxXQUFXO3dCQUNYLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUN0RCxPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsU0FBUyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7NEJBQy9CLEtBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQzt3QkFFckMsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztnQkFFUCxDQUFDO2dCQXZRTSwwQkFBTyxHQUFHLENBQUMsUUFBUSxFQUFFLFdBQVcsRUFBRSxlQUFlLENBQUMsQ0FBQztnQkFqQjlEO29CQUFDLGdCQUFTLENBQUM7d0JBRVAsV0FBVyxFQUFFLGtEQUFrRDt3QkFDL0QsVUFBVSxFQUFFLENBQUMsaUJBQVEsRUFBRSxxQkFBWSxFQUFFLHdCQUFlLEVBQUUsd0JBQWUsRUFBRSx3QkFBZSxFQUFFLDBCQUFRLENBQUM7d0JBQ2pHLFNBQVMsRUFBRSxDQUFDLGlDQUFlLEVBQUUsaUNBQWUsRUFBRSwrQkFBYyxDQUFDO3FCQUNoRSxDQUFDOztzQ0FBQTtnQkFvUkYseUJBQUM7WUFBRCxDQWxSQSxBQWtSQyxJQUFBO1lBbFJELG1EQWtSQyxDQUFBIiwiZmlsZSI6ImFtYXgvUmVjZWlwdC9TZWFyY2hQcm9kdWN0cy5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGJvb3RzdHJhcCB9IGZyb20gJ2FuZ3VsYXIyL3BsYXRmb3JtL2Jyb3dzZXInOyAgIC8vLy8vLy8vLy8vLy8vL1VzZWQgZm9yIFJlZHV4Ly8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8gIFxyXG5pbXBvcnQge05nU3dpdGNoLCBOZ1N3aXRjaFdoZW4sIE5nU3dpdGNoRGVmYXVsdCwgQ09SRV9ESVJFQ1RJVkVTLCBGT1JNX0RJUkVDVElWRVN9IGZyb20gJ2FuZ3VsYXIyL2NvbW1vbidcclxuaW1wb3J0IHtSZXNvdXJjZVNlcnZpY2V9IGZyb20gXCIuLi8uLi9zZXJ2aWNlcy9SZXNvdXJjZVNlcnZpY2VcIjtcclxuaW1wb3J0IHtSb3V0ZVBhcmFtcywgUk9VVEVSX1BST1ZJREVSUywgQVBQX0JBU0VfSFJFRn0gZnJvbSBcImFuZ3VsYXIyL3JvdXRlclwiOyAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vUk9VVEVSX1BST1ZJREVSUywgQVBQX0JBU0VfSFJFRiBVc2VkIEZvciBSZWR1eC8vLy9cclxuaW1wb3J0IHtDb21wb25lbnQsIE91dHB1dCwgSW5wdXQsIEV2ZW50RW1pdHRlciwgT25Jbml0LCBlbmFibGVQcm9kTW9kZSwgcHJvdmlkZX0gZnJvbSBcImFuZ3VsYXIyL2NvcmVcIjsvLy8vL2VuYWJsZVByb2RNb2RlLHByb3ZpZGUgaXMgdXNlZCBmb3IgUmVkdXhcclxuaW1wb3J0IHtDdXN0b21lclNlcnZpY2V9IGZyb20gXCIuLi8uLi9zZXJ2aWNlcy9DdXN0b21lclNlcnZpY2VcIjtcclxuaW1wb3J0IHtSZWNpZXB0U2VydmljZX0gZnJvbSBcIi4uLy4uL3NlcnZpY2VzL1JlY2llcHRTZXJ2aWNlXCI7XHJcbmltcG9ydCB7IGpzb25RIH0gZnJvbSAnLi4vLi4vanNvblEnO1xyXG5pbXBvcnQge0dyb3VwRmlsdGVyUGlwZSwgR3JvdXBQYXJlbkZpbHRlclBpcGUsIEtlbmRvX3V0aWxpdHl9IGZyb20gXCIuLi8uLi9hbWF4VXRpbFwiO1xyXG5pbXBvcnQgeyBBbWF4RGF0ZSB9IGZyb20gJy4uLy4uL2NvbW9uQ29tcG9uZW50cy9iYXNpY0NvbXBvbmVudHMnO1xyXG5cclxuZGVjbGFyZSB2YXIgalF1ZXJ5O1xyXG5kZWNsYXJlIHZhciBzd2FsO1xyXG5kZWNsYXJlIHZhciBtb21lbnQ7XHJcbkBDb21wb25lbnQoe1xyXG5cclxuICAgIHRlbXBsYXRlVXJsOiAnLi9hcHAvYW1heC9SZWNlaXB0L3RlbXBsYXRlcy9Qcm9kdWN0c1NlYXJjaC5odG1sJyxcclxuICAgIGRpcmVjdGl2ZXM6IFtOZ1N3aXRjaCwgTmdTd2l0Y2hXaGVuLCBOZ1N3aXRjaERlZmF1bHQsIENPUkVfRElSRUNUSVZFUywgRk9STV9ESVJFQ1RJVkVTLCBBbWF4RGF0ZV0sXHJcbiAgICBwcm92aWRlcnM6IFtDdXN0b21lclNlcnZpY2UsIFJlc291cmNlU2VydmljZSwgUmVjaWVwdFNlcnZpY2VdXHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgQW1heFNlYXJjaFByb2R1Y3RzIGltcGxlbWVudHMgT25Jbml0IHtcclxuICAgIG1vZGVsSW5wdXQgPSB7fTtcclxuICAgIEN1c3RvbWVySWQ6IHN0cmluZztcclxuICAgIGN1c3RTZWFyY2hEYXRhOiBPYmplY3QgPSBbXTtcclxuICAgIF9Qcm9kQ2F0czogT2JqZWN0ID0gW107XHJcbiAgICBDSEFOR0VESVI6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBSRVM6IE9iamVjdCA9IHt9O1xyXG4gICAgTGFuZzogc3RyaW5nID0gXCJcIjtcclxuICAgIENoYW5nZURpYWxvZzogc3RyaW5nID0gXCJcIjtcclxuICAgIEZvclBvcFVwOiBudW1iZXIgPSAwO1xyXG4gICAgc3RhdGljICRpbmplY3QgPSBbJyRzY29wZScsICckbG9jYXRpb24nLCAnJGFuY2hvclNjcm9sbCddO1xyXG4gICAgQmFzZUFwcFVybDogc3RyaW5nID0gXCJcIjtcclxuICAgIEZvcm10eXBlOiBzdHJpbmcgPSBcIlJFQ0VJUFRfU0VBUkNIXCI7XHJcbiAgICBJc2J0bmRpc2FibGU6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBTaG93TG9hZGVyOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBGcm9tUGFnZTogc3RyaW5nID0gXCJcIjtcclxuICAgIFNlYXJjaENvbnRlbnQ6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBFZGl0SWNvbkNzczogc3RyaW5nID0gXCJcIjtcclxuICAgIElzRXh0ZW5kZWQ6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIEV4dGVuZGVkOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBJc1Jvd0ZvdW5kOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBJc0RpcmVjdDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgRm9yQmFjazogc3RyaW5nID0gXCJcIjtcclxuXHJcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIF9yZXNvdXJjZVNlcnZpY2U6IFJlc291cmNlU2VydmljZSwgcHJpdmF0ZSBfY3VzdG9tZXJTZXJ2aWNlOiBDdXN0b21lclNlcnZpY2UsIHByaXZhdGUgX3JvdXRlUGFyYW1zOiBSb3V0ZVBhcmFtcywgcHJpdmF0ZSBfUmVjaWVwdFNlcnZpY2U6IFJlY2llcHRTZXJ2aWNlKSB7XHJcblxyXG4gICAgICAgIHRoaXMuUkVTLlJFQ0VJUFRfU0VBUkNIID0ge307XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0ID0ge307XHJcbiAgICAgICAgdGhpcy5DdXN0b21lcklkID0gX3JvdXRlUGFyYW1zLnBhcmFtcy5JZDtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQucmVjZWlwdFNlYXJjaERhdGEgPSBbXTtcclxuICAgICAgICBcclxuICAgICAgICB0aGlzLklzRGlyZWN0ID0gdHJ1ZTtcclxuICAgICAgICB0aGlzLkVkaXRJY29uQ3NzID0gXCJtZGktbm90aWZpY2F0aW9uLXN5bmNcIjtcclxuICAgICAgICAvL3RoaXMuRm9yUG9wVXAgPSBfcm91dGVQYXJhbXMucGFyYW1zLkZvclBvcHVwO1xyXG4gICAgICAgIC8vdGhpcy5Gcm9tUGFnZSA9IF9yb3V0ZVBhcmFtcy5wYXJhbXMuRnJvbVBhZ2U7XHJcbiAgICAgICAgXHJcbiAgICAgICBcclxuICAgICAgICAvL2lmICh0aGlzLkZyb21QYWdlID09IFwiUmVjZWlwdENyZWF0ZVwiKSB7XHJcbiAgICAgICAgLy8gICAgdGhpcy5FZGl0SWNvbkNzcyA9IFwibWRpLW5vdGlmaWNhdGlvbi1zeW5jXCI7XHJcbiAgICAgICAgLy8gICAgdGhpcy5Jc0RpcmVjdCA9IHRydWU7XHJcbiAgICAgICAgLy8gICAvLyB0aGlzLkZvckJhY2sgPSBfcm91dGVQYXJhbXMucGFyYW1zLkZvckJhY2s7XHJcbiAgICAgICAgLy99XHJcbiAgICAgICAgLy9lbHNlIHtcclxuICAgICAgICAvLyAgICB0aGlzLkVkaXRJY29uQ3NzID0gXCJtZGktY29udGVudC1jcmVhdGVcIjtcclxuICAgICAgICAvLyAgICB0aGlzLklzRGlyZWN0ID0gZmFsc2U7XHJcbiAgICAgICAgLy99XHJcbiAgICAgICAgXHJcbiAgICAgICAgLy9pZiAodGhpcy5Gb3JQb3BVcCA9PSAxKSB7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgIC8vICAgIGpRdWVyeSgnbXgtbmF2YmFyJykuY3NzKHsgXCJkaXNwbGF5XCI6IFwibm9uZVwiIH0pO1xyXG4gICAgICAgIC8vICAgIGpRdWVyeSgnZm9vdGVyJykuY3NzKHsgXCJkaXNwbGF5XCI6IFwibm9uZVwiIH0pO1xyXG4gICAgICAgIC8vICAgIGpRdWVyeSgnbXgtYnJlYWRjcnVtYicpLmNzcyh7IFwiZGlzcGxheVwiOiBcIm5vbmVcIiB9KTtcclxuICAgICAgICAvL31cclxuICAgICAgICAvLyB0aGlzLkhpZGVGb3JQb3BVcCh0aGlzLkZvclBvcFVwKTtcclxuICAgICAgICB0aGlzLkJhc2VBcHBVcmwgPSBfcmVzb3VyY2VTZXJ2aWNlLkFwcFVybDtcclxuXHJcbiAgICB9XHJcblxyXG5cclxuXHJcblxyXG5cclxuICAgIEhpZGVGb3JQb3BVcChGb3JQb3BVcCkge1xyXG4gICAgICAgIGlmIChGb3JQb3BVcCA9PSAxKSB7XHJcblxyXG4gICAgICAgICAgICBqUXVlcnkoJ214LW5hdmJhcicpLmNzcyh7IFwiZGlzcGxheVwiOiBcIm5vbmVcIiB9KTtcclxuICAgICAgICAgICAgalF1ZXJ5KCdmb290ZXInKS5jc3MoeyBcImRpc3BsYXlcIjogXCJub25lXCIgfSk7XHJcbiAgICAgICAgICAgIGpRdWVyeSgnbXgtYnJlYWRjcnVtYicpLmNzcyh7IFwiZGlzcGxheVwiOiBcIm5vbmVcIiB9KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBDaGFuZ2VFeHRlbmRlZEF0dHIoKSB7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0ID0ge307XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LmN1c3RTZWFyY2hEYXRhID0gW107XHJcblxyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5TZWFyY2hDb250ZW50ID0gXCJcIjtcclxuICAgICAgICB0aGlzLmFzeW5jU2VsZWN0ZWRDYXIgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5Jc1Jvd0ZvdW5kID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LklzRXh0ZW5kZWQgPSBqUXVlcnkoXCIjRXh0ZW5kZWRfXCIpLnByb3AoXCJjaGVja2VkXCIpO1xyXG5cclxuICAgIH1cclxuICAgIE9wZW5SZWNlaXB0Q2FyZChQcm9kT2JqKSB7XHJcbiAgICAgICAgZGVidWdnZXI7XHJcbiAgICAgICAgaWYgKFByb2RPYmogIT0gdW5kZWZpbmVkICYmIFByb2RPYmogIT0gbnVsbCkge1xyXG4gICAgICAgICAgICB2YXIgamRhdGEgPSBKU09OLnN0cmluZ2lmeShQcm9kT2JqKTtcclxuICAgICAgICAgICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLnNldENvb2tpZShcIlJlY2VpcHRDcmVhdGVfUHJvZHVjdFwiLCBqZGF0YSwgMTApO1xyXG4gICAgICAgICAgICB2YXIgUmVjZWlwdElkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJUZW1wUmVjZWlwdElkXCIpO1xyXG4gICAgICAgICAgICBwYXJlbnQud2luZG93Lm9wZW4odGhpcy5CYXNlQXBwVXJsICsgXCJSZWNlaXB0Q3JlYXRlL1wiICsgdGhpcy5DdXN0b21lcklkICsgXCIvXCIgKyBSZWNlaXB0SWQsIFwiX3NlbGZcIik7XHJcbiAgICAgICAgfVxyXG5cclxuICAgIH1cclxuICAgIC8vT3BlbkN1c3RvbWVyQ2FyZChDdXN0T2JqKSB7XHJcblxyXG4gICAgLy8gICAgaWYgKHRoaXMuRnJvbVBhZ2UgPT0gXCJSZWNlaXB0Q3JlYXRlXCIpIHtcclxuICAgIC8vICAgICAgICB2YXIgUmVjZWlwdElkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJUZW1wUmVjZWlwdElkXCIpO1xyXG4gICAgLy8gICAgICAgIHBhcmVudC53aW5kb3cub3Blbih0aGlzLkJhc2VBcHBVcmwgKyBcIlJlY2VpcHRDcmVhdGUvXCIgKyBDdXN0T2JqLkN1c3RvbWVySWQgKyBcIi9cIiArIFJlY2VpcHRJZCwgXCJfc2VsZlwiKTtcclxuXHJcbiAgICAvLyAgICB9XHJcbiAgICAvLyAgICBlbHNlIHtcclxuICAgIC8vICAgICAgICBwYXJlbnQud2luZG93LmxvY2F0aW9uLnJlcGxhY2UodGhpcy5CYXNlQXBwVXJsICsgXCJDdXN0b21lci9BZGQvXCIgKyBDdXN0T2JqLkN1c3RvbWVySWQpO1xyXG4gICAgLy8gICAgfVxyXG5cclxuICAgIC8vfVxyXG4gICAgU2VhcmNoUmVjZWlwdCgpIHtcclxuICAgICAgICAvLyAgZGVidWdnZXI7XHJcbiAgICAgICAgdGhpcy5Jc2J0bmRpc2FibGUgPSBcImRpc2FibGVkXCI7XHJcbiAgICAgICAgdGhpcy5TaG93TG9hZGVyID0gdHJ1ZTtcclxuICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LlByb2RDYXRJZCA9PSB1bmRlZmluZWQgfHwgdGhpcy5tb2RlbElucHV0LlByb2RDYXRJZCA9PSBudWxsKSB7XHJcbiAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5Qcm9kQ2F0SWQgPSBcIi0xXCI7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuUGFydE51bWJlciA9PSB1bmRlZmluZWQgfHwgdGhpcy5tb2RlbElucHV0LlBhcnROdW1iZXIgPT0gbnVsbCkge1xyXG4gICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuUGFydE51bWJlciA9IFwiXCI7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuUHJvZE5hbWVEaXMgPT0gdW5kZWZpbmVkIHx8IHRoaXMubW9kZWxJbnB1dC5Qcm9kTmFtZURpcyA9PSBudWxsKSB7XHJcbiAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5Qcm9kTmFtZURpcyA9IFwiXCI7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMuX1JlY2llcHRTZXJ2aWNlLkdldFByb2R1Y3RzKHRoaXMubW9kZWxJbnB1dC5Qcm9kQ2F0SWQsIHRoaXMubW9kZWxJbnB1dC5QYXJ0TnVtYmVyLCB0aGlzLm1vZGVsSW5wdXQuUHJvZE5hbWVEaXMpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuXHJcbiAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIC8vYWxlcnQocmVzcG9uc2UuRXJyTXNnKTtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5yZWNlaXB0U2VhcmNoRGF0YSA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LnJlY2VpcHRTZWFyY2hEYXRhLmxlbmd0aCA9PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LklzUm93Rm91bmQgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5Jc1Jvd0ZvdW5kID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICAgICAgLy8gICAgLCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgLy8gICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgICAgICAvL30sICgpID0+IHtcclxuICAgICAgICAgICAgLy8gICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgICAgIC8vICAgIH1cclxuICAgICAgICApO1xyXG5cclxuICAgICAgICB0aGlzLklzYnRuZGlzYWJsZSA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5TaG93TG9hZGVyID0gZmFsc2U7XHJcbiAgICB9XHJcbiAgICBCYWNrUGFnZSgpIHtcclxuICAgICAgICAvL2lmICh0aGlzLkZyb21QYWdlID09IFwiUmVjZWlwdENyZWF0ZVwiKSB7XHJcbiAgICAgICAgLy8gICAgZGVidWdnZXI7XHJcbiAgICAgICAgICAgIHZhciBSZWNlaXB0SWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcIlRlbXBSZWNlaXB0SWRcIik7XHJcbiAgICAgICAgICAgIHBhcmVudC53aW5kb3cub3Blbih0aGlzLkJhc2VBcHBVcmwgKyBcIlJlY2VpcHRDcmVhdGUvXCIgKyB0aGlzLkN1c3RvbWVySWQgKyBcIi9cIiArIFJlY2VpcHRJZCwgXCJfc2VsZlwiKTtcclxuICAgICAgICAvL31cclxuICAgIH1cclxuICAgIFNldGRlZmF1bHRQYWdlKCkge1xyXG5cclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQgPSB7fTtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuU2VhcmNoQ29udGVudCA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LmN1c3RTZWFyY2hEYXRhID0gW107XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkluaXQoKSB7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LlBhcnROdW1iZXIgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5Qcm9kTmFtZURpcyA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LklzUm93Rm91bmQgPSBmYWxzZTtcclxuXHJcbiAgICAgICAgdGhpcy5fUmVjaWVwdFNlcnZpY2UuR2V0UHJvZHVjdHMoLTIsIFwiXCIsIFwiXCIpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuXHJcbiAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIC8vYWxlcnQocmVzcG9uc2UuRXJyTXNnKTtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5yZWNlaXB0U2VhcmNoRGF0YSA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LnJlY2VpcHRTZWFyY2hEYXRhLmxlbmd0aCA9PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LklzUm93Rm91bmQgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5Jc1Jvd0ZvdW5kID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICAgICAgLy8gICAgLCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgLy8gICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgICAgICAvL30sICgpID0+IHtcclxuICAgICAgICAgICAgLy8gICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgICAgIC8vICAgIH1cclxuICAgICAgICApO1xyXG4gICAgICAgIHRoaXMuTGFuZyA9IHRoaXMuX3Jlc291cmNlU2VydmljZS5nZXRDb29raWUoXCJsYW5nXCIpO1xyXG4gICAgICAgIGlmICh0aGlzLkxhbmcubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICB0aGlzLkxhbmcgPSB0aGlzLkxhbmcuc3Vic3RyaW5nKDEsIHRoaXMuTGFuZy5sZW5ndGgpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHRoaXMuTGFuZyA9PSBcImhlXCIpIHtcclxuICAgICAgICAgICAgdGhpcy5DSEFOR0VESVIgPSBcInJ0bG1vZGFsXCI7XHJcbiAgICAgICAgICAgIHRoaXMuQ2hhbmdlRGlhbG9nID0gXCJpbnB1dF9yaWdodFwiO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5DSEFOR0VESVIgPSBcImx0cm1vZGFsXCI7XHJcbiAgICAgICAgICAgIHRoaXMuQ2hhbmdlRGlhbG9nID0gXCJpbnB1dF9sZWZ0XCI7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vIGRlYnVnZ2VyO1xyXG5cclxuICAgICAgICB2YXIgamRhdGEgPSB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZ2V0Q29va2llKFwiX1NlYXJjaF9DYWNoZVwiKTtcclxuICAgICAgICBpZiAoamRhdGEgIT0gdW5kZWZpbmVkICYmIGpkYXRhICE9IHVuZGVmaW5lZCAmJiBqZGF0YSAhPSBcIlwiKSB7XHJcbiAgICAgICAgICAgIGpkYXRhID0gamRhdGEuc3Vic3RyaW5nKDEsIGpkYXRhLmxlbmd0aCk7XHJcbiAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dCA9IGpRdWVyeS5wYXJzZUpTT04oamRhdGEpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuXHJcbiAgICAgICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLkdldExhbmdSZXModGhpcy5Gb3JtdHlwZSwgdGhpcy5MYW5nKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZywgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLlJFUyA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICAvL2FsZXJ0KHRoaXMuUkVTKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuICAgICAgICB0aGlzLl9SZWNpZXB0U2VydmljZS5HZXRQcm9kQ2F0cygpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX1Byb2RDYXRzID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5Qcm9kQ2F0SWQgPSBcIi0xXCI7XHJcbiAgICAgICAgICAgICAgICAvL2FsZXJ0KHRoaXMuUkVTKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuXHJcbiAgICB9XHJcbn1cclxuIl19
