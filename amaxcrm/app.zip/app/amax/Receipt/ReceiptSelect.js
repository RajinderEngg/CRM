System.register(["angular2/core", 'angular2/common', "../../services/ResourceService", "angular2/router", "../../services/RecieptService"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, common_1, ResourceService_1, router_1, RecieptService_1;
    var AmaxReceiptSelect;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (ResourceService_1_1) {
                ResourceService_1 = ResourceService_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (RecieptService_1_1) {
                RecieptService_1 = RecieptService_1_1;
            }],
        execute: function() {
            AmaxReceiptSelect = (function () {
                // @ViewChild('RTLDiv') private myScrollContainer: ElementRef;
                function AmaxReceiptSelect(_resourceService, _RecieptService, _routeParams) {
                    this._resourceService = _resourceService;
                    this._RecieptService = _RecieptService;
                    this._routeParams = _routeParams;
                    this.RES = {};
                    this.Formtype = "SCREEN_RECEIPTCHOOSE";
                    this.Lang = "";
                    this.RecieptMode = "1";
                    this._RecieptModes = [];
                    this._Reciepts = [];
                    this.ReceiptTypeId = "-1";
                    this.EmployeeId = "";
                    this.MsgClass = "text-primary";
                    this.modelInput = {};
                    this.ChangeDialog = "";
                    this.CHANGEDIR = "";
                    this.BaseAppUrl = "";
                    this.RES.SCREEN_RECEIPTCHOOSE = {};
                    this.ReceiptTypeId = "-1";
                    this.modelInput = {};
                    //this.baseUrl = "http://localhost:3000/#/";
                    //debugger;
                    this.baseUrl = _resourceService.AppUrl;
                    this.EmployeeId = _routeParams.params.Id;
                    this.RecieptMode = "1";
                    this.BaseAppUrl = _resourceService.AppUrl;
                }
                AmaxReceiptSelect.prototype.NextPage = function () {
                    if (this.ReceiptTypeId != "-1") {
                        var CustId = this._routeParams.params.CustId;
                        document.location = this.BaseAppUrl + "ReceiptCreate/" + CustId + "/" + this.ReceiptTypeId;
                    }
                    else {
                        bootbox.alert({
                            message: "Please select Receipt Name and then click on Next button",
                            className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                    }
                };
                AmaxReceiptSelect.prototype.SelectReceipt = function (RecTypeId) {
                    this.ReceiptTypeId = RecTypeId;
                    //alert(this.ReceiptTypeId);
                    this._resourceService.setCookie("ReceiptTypeIdLast_" + this.EmployeeId, this.ReceiptTypeId, 7);
                };
                AmaxReceiptSelect.prototype.GetReceipts = function (RModel) {
                    var _this = this;
                    this._resourceService.setCookie("ReceiptModeLast_" + this.EmployeeId, RModel, 7);
                    this._RecieptService.GetReceipts(this.EmployeeId, RModel).subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            //debugger;
                            _this._Reciepts = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxReceiptSelect.prototype.ngOnInit = function () {
                    var _this = this;
                    //  alert("ddd");
                    this.Lang = localStorage.getItem("lang");
                    this._resourceService.GetLangRes(this.Formtype, this.Lang).subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.RES = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._RecieptService.GetRecieptModes().subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._RecieptModes = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //if (this.EmployeeId != "") {
                    //debugger;
                    var getMode = this._resourceService.getCookie("ReceiptModeLast_" + this.EmployeeId);
                    if (getMode.length > 0) {
                        this.RecieptMode = getMode.substring(1, getMode.length);
                        if (this.RecieptMode == "4")
                            this.RecieptMode = "1";
                    }
                    else {
                        this.RecieptMode = "1";
                    }
                    this.GetReceipts(this.RecieptMode);
                    var getRecId = this._resourceService.getCookie("ReceiptTypeIdLast_" + this.EmployeeId);
                    if (getRecId.length > 0) {
                        this.ReceiptTypeId = getRecId.substring(1, getRecId.length);
                    }
                    else {
                        this.ReceiptTypeId = "-1";
                    }
                    var rrmode = this.RecieptMode;
                    var recid = this.ReceiptTypeId;
                    window.setTimeout(function () {
                        //alert(rrmode);
                        jQuery("input[name=recmode][value=" + rrmode + "]").prop("checked", true);
                        jQuery("input[name=ReceiptTypeId][value=" + recid + "]").prop("checked", true);
                    }, 1000);
                    //}
                };
                AmaxReceiptSelect.$inject = ['$scope', '$location', '$anchorScroll'];
                AmaxReceiptSelect = __decorate([
                    core_1.Component({
                        templateUrl: './app/amax/Receipt/templates/ReceiptSelect.html',
                        directives: [common_1.NgSwitch, common_1.NgSwitchWhen, common_1.NgSwitchDefault],
                        providers: [RecieptService_1.RecieptService, ResourceService_1.ResourceService]
                    }), 
                    __metadata('design:paramtypes', [ResourceService_1.ResourceService, RecieptService_1.RecieptService, router_1.RouteParams])
                ], AmaxReceiptSelect);
                return AmaxReceiptSelect;
            }());
            exports_1("AmaxReceiptSelect", AmaxReceiptSelect);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFtYXgvUmVjZWlwdC9SZWNlaXB0U2VsZWN0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1lBaUJBO2dCQWdCRyw4REFBOEQ7Z0JBQzdELDJCQUFvQixnQkFBaUMsRUFBVSxlQUErQixFQUFVLFlBQXlCO29CQUE3RyxxQkFBZ0IsR0FBaEIsZ0JBQWdCLENBQWlCO29CQUFVLG9CQUFlLEdBQWYsZUFBZSxDQUFnQjtvQkFBVSxpQkFBWSxHQUFaLFlBQVksQ0FBYTtvQkFmakksUUFBRyxHQUFXLEVBQUUsQ0FBQztvQkFDakIsYUFBUSxHQUFXLHNCQUFzQixDQUFDO29CQUMxQyxTQUFJLEdBQVcsRUFBRSxDQUFDO29CQUNsQixnQkFBVyxHQUFXLEdBQUcsQ0FBQztvQkFDMUIsa0JBQWEsR0FBRyxFQUFFLENBQUM7b0JBQ25CLGNBQVMsR0FBRyxFQUFFLENBQUM7b0JBQ2Ysa0JBQWEsR0FBVyxJQUFJLENBQUM7b0JBQzdCLGVBQVUsR0FBVyxFQUFFLENBQUM7b0JBQ3hCLGFBQVEsR0FBVyxjQUFjLENBQUM7b0JBQ2xDLGVBQVUsR0FBVyxFQUFFLENBQUM7b0JBQ3hCLGlCQUFZLEdBQVcsRUFBRSxDQUFDO29CQUMxQixjQUFTLEdBQVcsRUFBRSxDQUFDO29CQUN2QixlQUFVLEdBQVcsRUFBRSxDQUFDO29CQUtwQixJQUFJLENBQUMsR0FBRyxDQUFDLG9CQUFvQixHQUFHLEVBQUUsQ0FBQztvQkFDbkMsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7b0JBQzFCLElBQUksQ0FBQyxVQUFVLEdBQUcsRUFBRSxDQUFDO29CQUNyQiw0Q0FBNEM7b0JBQzVDLFdBQVc7b0JBQ1gsSUFBSSxDQUFDLE9BQU8sR0FBRyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUM7b0JBQ3ZDLElBQUksQ0FBQyxVQUFVLEdBQUcsWUFBWSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7b0JBQ3pDLElBQUksQ0FBQyxXQUFXLEdBQUcsR0FBRyxDQUFDO29CQUN2QixJQUFJLENBQUMsVUFBVSxHQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQztnQkFDNUMsQ0FBQztnQkFDRCxvQ0FBUSxHQUFSO29CQUNJLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzt3QkFDN0IsSUFBSSxNQUFNLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO3dCQUM3QyxRQUFRLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxVQUFVLEdBQUcsZ0JBQWdCLEdBQUcsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDO29CQUMvRixDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUNGLE9BQU8sQ0FBQyxLQUFLLENBQUM7NEJBQ1YsT0FBTyxFQUFFLDBEQUEwRDs0QkFDbkUsU0FBUyxFQUFFLElBQUksQ0FBQyxZQUFZOzRCQUM1QixPQUFPLEVBQUU7Z0NBQ0wsRUFBRSxFQUFFO29DQUNBLGNBQWM7b0NBQ2QsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO2lDQUM1Qjs2QkFDSjt5QkFDSixDQUFDLENBQUM7b0JBRVAsQ0FBQztnQkFDTCxDQUFDO2dCQUNELHlDQUFhLEdBQWIsVUFBYyxTQUFTO29CQUNuQixJQUFJLENBQUMsYUFBYSxHQUFHLFNBQVMsQ0FBQztvQkFDL0IsNEJBQTRCO29CQUM1QixJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLG9CQUFvQixHQUFHLElBQUksQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDLENBQUMsQ0FBQztnQkFDbkcsQ0FBQztnQkFDRCx1Q0FBVyxHQUFYLFVBQVksTUFBTTtvQkFBbEIsaUJBMkJDO29CQTFCRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQyxVQUFVLEVBQUUsTUFBTSxFQUFFLENBQUMsQ0FBQyxDQUFDO29CQUNqRixJQUFJLENBQUMsZUFBZSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLE1BQU0sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQ3BFLFdBQVc7d0JBQ1gsSUFBSSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtnQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUM1QixPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixXQUFXOzRCQUNYLEtBQUksQ0FBQyxTQUFTLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzt3QkFFbkMsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztnQkFDUCxDQUFDO2dCQUVELG9DQUFRLEdBQVI7b0JBQUEsaUJBOEVDO29CQTdFQyxpQkFBaUI7b0JBQ2YsSUFBSSxDQUFDLElBQUksR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUN6QyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7d0JBRXpFLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO2dDQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQzVCLE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEtBQUksQ0FBQyxHQUFHLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzt3QkFDN0IsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFFSCxJQUFJLENBQUMsZUFBZSxDQUFDLGVBQWUsRUFBRSxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQ2pELFdBQVc7d0JBQ1gsSUFBSSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtnQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUM1QixPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsYUFBYSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7d0JBRXZDLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsOEJBQThCO29CQUM5QixXQUFXO29CQUNYLElBQUksT0FBTyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO29CQUNwRixFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ3JCLElBQUksQ0FBQyxXQUFXLEdBQUcsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO3dCQUN4RCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxJQUFJLEdBQUcsQ0FBQzs0QkFBQyxJQUFJLENBQUMsV0FBVyxHQUFHLEdBQUcsQ0FBQztvQkFDeEQsQ0FBQztvQkFBQyxJQUFJLENBQUMsQ0FBQzt3QkFDSixJQUFJLENBQUMsV0FBVyxHQUFHLEdBQUcsQ0FBQztvQkFDM0IsQ0FBQztvQkFDRCxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztvQkFFbkMsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxvQkFBb0IsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7b0JBQ3ZGLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDdEIsSUFBSSxDQUFDLGFBQWEsR0FBRyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQ2hFLENBQUM7b0JBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ0osSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7b0JBQzlCLENBQUM7b0JBQ0QsSUFBSSxNQUFNLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQztvQkFDOUIsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQztvQkFFL0IsTUFBTSxDQUFDLFVBQVUsQ0FBQzt3QkFDZCxnQkFBZ0I7d0JBQ2hCLE1BQU0sQ0FBQyw0QkFBNEIsR0FBRyxNQUFNLEdBQUcsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQzt3QkFDMUUsTUFBTSxDQUFDLGtDQUFrQyxHQUFHLEtBQUssR0FBRyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDO29CQUNuRixDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7b0JBRVQsR0FBRztnQkFDUCxDQUFDO2dCQWpKTSx5QkFBTyxHQUFHLENBQUMsUUFBUSxFQUFFLFdBQVcsRUFBRSxlQUFlLENBQUMsQ0FBQztnQkF0QjlEO29CQUFDLGdCQUFTLENBQUM7d0JBRVAsV0FBVyxFQUFFLGlEQUFpRDt3QkFDOUQsVUFBVSxFQUFFLENBQUMsaUJBQVEsRUFBRSxxQkFBWSxFQUFFLHdCQUFlLENBQUM7d0JBQ3JELFNBQVMsRUFBRSxDQUFDLCtCQUFjLEVBQUUsaUNBQWUsQ0FBQztxQkFDL0MsQ0FBQzs7cUNBQUE7Z0JBbUtGLHdCQUFDO1lBQUQsQ0FqS0EsQUFpS0MsSUFBQTtZQWpLRCxpREFpS0MsQ0FBQSIsImZpbGUiOiJhbWF4L1JlY2VpcHQvUmVjZWlwdFNlbGVjdC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7Q29tcG9uZW50LCBPdXRwdXQsIElucHV0LCBFdmVudEVtaXR0ZXIsIE9uSW5pdH0gZnJvbSBcImFuZ3VsYXIyL2NvcmVcIjtcclxuaW1wb3J0IHtOZ1N3aXRjaCwgTmdTd2l0Y2hXaGVuLCBOZ1N3aXRjaERlZmF1bHR9IGZyb20gJ2FuZ3VsYXIyL2NvbW1vbidcclxuaW1wb3J0IHtSZXNvdXJjZVNlcnZpY2V9IGZyb20gXCIuLi8uLi9zZXJ2aWNlcy9SZXNvdXJjZVNlcnZpY2VcIjtcclxuaW1wb3J0IHtSb3V0ZVBhcmFtc30gZnJvbSBcImFuZ3VsYXIyL3JvdXRlclwiO1xyXG5pbXBvcnQge1JlY2llcHRTZXJ2aWNlfSBmcm9tIFwiLi4vLi4vc2VydmljZXMvUmVjaWVwdFNlcnZpY2VcIjtcclxuaW1wb3J0IHsganNvblEgfSBmcm9tICcuLi8uLi9qc29uUSc7XHJcbmltcG9ydCB7R3JvdXBGaWx0ZXJQaXBlLCBHcm91cFBhcmVuRmlsdGVyUGlwZSwgS2VuZG9fdXRpbGl0eX0gZnJvbSBcIi4uLy4uL2FtYXhVdGlsXCI7XHJcblxyXG5kZWNsYXJlIHZhciBqUXVlcnk7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuXHJcbiAgICB0ZW1wbGF0ZVVybDogJy4vYXBwL2FtYXgvUmVjZWlwdC90ZW1wbGF0ZXMvUmVjZWlwdFNlbGVjdC5odG1sJyxcclxuICAgIGRpcmVjdGl2ZXM6IFtOZ1N3aXRjaCwgTmdTd2l0Y2hXaGVuLCBOZ1N3aXRjaERlZmF1bHRdLFxyXG4gICAgcHJvdmlkZXJzOiBbUmVjaWVwdFNlcnZpY2UsIFJlc291cmNlU2VydmljZV1cclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBBbWF4UmVjZWlwdFNlbGVjdCBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcbiAgICBiYXNlVXJsOiBzdHJpbmc7XHJcbiAgICBSRVM6IE9iamVjdCA9IHt9O1xyXG4gICAgRm9ybXR5cGU6IHN0cmluZyA9IFwiU0NSRUVOX1JFQ0VJUFRDSE9PU0VcIjtcclxuICAgIExhbmc6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBSZWNpZXB0TW9kZTogc3RyaW5nID0gXCIxXCI7XHJcbiAgICBfUmVjaWVwdE1vZGVzID0gW107XHJcbiAgICBfUmVjaWVwdHMgPSBbXTtcclxuICAgIFJlY2VpcHRUeXBlSWQ6IHN0cmluZyA9IFwiLTFcIjtcclxuICAgIEVtcGxveWVlSWQ6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBNc2dDbGFzczogc3RyaW5nID0gXCJ0ZXh0LXByaW1hcnlcIjtcclxuICAgIG1vZGVsSW5wdXQ6IE9iamVjdCA9IHt9O1xyXG4gICAgQ2hhbmdlRGlhbG9nOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgQ0hBTkdFRElSOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgQmFzZUFwcFVybDogc3RyaW5nID0gXCJcIjtcclxuICAgIHN0YXRpYyAkaW5qZWN0ID0gWyckc2NvcGUnLCAnJGxvY2F0aW9uJywgJyRhbmNob3JTY3JvbGwnXTtcclxuICAgLy8gQFZpZXdDaGlsZCgnUlRMRGl2JykgcHJpdmF0ZSBteVNjcm9sbENvbnRhaW5lcjogRWxlbWVudFJlZjtcclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgX3Jlc291cmNlU2VydmljZTogUmVzb3VyY2VTZXJ2aWNlLCBwcml2YXRlIF9SZWNpZXB0U2VydmljZTogUmVjaWVwdFNlcnZpY2UsIHByaXZhdGUgX3JvdXRlUGFyYW1zOiBSb3V0ZVBhcmFtcykge1xyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMuUkVTLlNDUkVFTl9SRUNFSVBUQ0hPT1NFID0ge307XHJcbiAgICAgICAgdGhpcy5SZWNlaXB0VHlwZUlkID0gXCItMVwiO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dCA9IHt9O1xyXG4gICAgICAgIC8vdGhpcy5iYXNlVXJsID0gXCJodHRwOi8vbG9jYWxob3N0OjMwMDAvIy9cIjtcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgIHRoaXMuYmFzZVVybCA9IF9yZXNvdXJjZVNlcnZpY2UuQXBwVXJsO1xyXG4gICAgICAgIHRoaXMuRW1wbG95ZWVJZCA9IF9yb3V0ZVBhcmFtcy5wYXJhbXMuSWQ7XHJcbiAgICAgICAgdGhpcy5SZWNpZXB0TW9kZSA9IFwiMVwiO1xyXG4gICAgICAgIHRoaXMuQmFzZUFwcFVybD1fcmVzb3VyY2VTZXJ2aWNlLkFwcFVybDtcclxuICAgIH1cclxuICAgIE5leHRQYWdlKCkge1xyXG4gICAgICAgIGlmICh0aGlzLlJlY2VpcHRUeXBlSWQgIT0gXCItMVwiKSB7XHJcbiAgICAgICAgICAgIHZhciBDdXN0SWQgPSB0aGlzLl9yb3V0ZVBhcmFtcy5wYXJhbXMuQ3VzdElkO1xyXG4gICAgICAgICAgICBkb2N1bWVudC5sb2NhdGlvbiA9IHRoaXMuQmFzZUFwcFVybCArIFwiUmVjZWlwdENyZWF0ZS9cIiArIEN1c3RJZCArIFwiL1wiICsgdGhpcy5SZWNlaXB0VHlwZUlkO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICBtZXNzYWdlOiBcIlBsZWFzZSBzZWxlY3QgUmVjZWlwdCBOYW1lIGFuZCB0aGVuIGNsaWNrIG9uIE5leHQgYnV0dG9uXCIsXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBTZWxlY3RSZWNlaXB0KFJlY1R5cGVJZCkge1xyXG4gICAgICAgIHRoaXMuUmVjZWlwdFR5cGVJZCA9IFJlY1R5cGVJZDtcclxuICAgICAgICAvL2FsZXJ0KHRoaXMuUmVjZWlwdFR5cGVJZCk7XHJcbiAgICAgICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLnNldENvb2tpZShcIlJlY2VpcHRUeXBlSWRMYXN0X1wiICsgdGhpcy5FbXBsb3llZUlkLCB0aGlzLlJlY2VpcHRUeXBlSWQsIDcpOyAgIFxyXG4gICAgfVxyXG4gICAgR2V0UmVjZWlwdHMoUk1vZGVsKSB7XHJcbiAgICAgICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLnNldENvb2tpZShcIlJlY2VpcHRNb2RlTGFzdF9cIiArIHRoaXMuRW1wbG95ZWVJZCwgUk1vZGVsLCA3KTsgICBcclxuICAgICAgICB0aGlzLl9SZWNpZXB0U2VydmljZS5HZXRSZWNlaXB0cyh0aGlzLkVtcGxveWVlSWQsIFJNb2RlbCkuc3Vic2NyaWJlKHJlc3A9PiB7XHJcbiAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgIHZhciByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcCk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9SZWNpZXB0cyA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uSW5pdCgpIHtcclxuICAgICAgLy8gIGFsZXJ0KFwiZGRkXCIpO1xyXG4gICAgICAgIHRoaXMuTGFuZyA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwibGFuZ1wiKTtcclxuICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuR2V0TGFuZ1Jlcyh0aGlzLkZvcm10eXBlLCB0aGlzLkxhbmcpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuUkVTID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgdGhpcy5fUmVjaWVwdFNlcnZpY2UuR2V0UmVjaWVwdE1vZGVzKCkuc3Vic2NyaWJlKHJlc3A9PiB7XHJcbiAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgIHZhciByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcCk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX1JlY2llcHRNb2RlcyA9IHJlc3BvbnNlLkRhdGE7XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIC8vaWYgKHRoaXMuRW1wbG95ZWVJZCAhPSBcIlwiKSB7XHJcbiAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICB2YXIgZ2V0TW9kZSA9IHRoaXMuX3Jlc291cmNlU2VydmljZS5nZXRDb29raWUoXCJSZWNlaXB0TW9kZUxhc3RfXCIgKyB0aGlzLkVtcGxveWVlSWQpO1xyXG4gICAgICAgIGlmIChnZXRNb2RlLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgdGhpcy5SZWNpZXB0TW9kZSA9IGdldE1vZGUuc3Vic3RyaW5nKDEsIGdldE1vZGUubGVuZ3RoKTtcclxuICAgICAgICAgICAgaWYgKHRoaXMuUmVjaWVwdE1vZGUgPT0gXCI0XCIpIHRoaXMuUmVjaWVwdE1vZGUgPSBcIjFcIjtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLlJlY2llcHRNb2RlID0gXCIxXCI7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuR2V0UmVjZWlwdHModGhpcy5SZWNpZXB0TW9kZSk7XHJcblxyXG4gICAgICAgIHZhciBnZXRSZWNJZCA9IHRoaXMuX3Jlc291cmNlU2VydmljZS5nZXRDb29raWUoXCJSZWNlaXB0VHlwZUlkTGFzdF9cIiArIHRoaXMuRW1wbG95ZWVJZCk7XHJcbiAgICAgICAgaWYgKGdldFJlY0lkLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgdGhpcy5SZWNlaXB0VHlwZUlkID0gZ2V0UmVjSWQuc3Vic3RyaW5nKDEsIGdldFJlY0lkLmxlbmd0aCk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5SZWNlaXB0VHlwZUlkID0gXCItMVwiO1xyXG4gICAgICAgIH1cclxuICAgICAgICB2YXIgcnJtb2RlID0gdGhpcy5SZWNpZXB0TW9kZTtcclxuICAgICAgICB2YXIgcmVjaWQgPSB0aGlzLlJlY2VpcHRUeXBlSWQ7XHJcblxyXG4gICAgICAgIHdpbmRvdy5zZXRUaW1lb3V0KGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgLy9hbGVydChycm1vZGUpO1xyXG4gICAgICAgICAgICBqUXVlcnkoXCJpbnB1dFtuYW1lPXJlY21vZGVdW3ZhbHVlPVwiICsgcnJtb2RlICsgXCJdXCIpLnByb3AoXCJjaGVja2VkXCIsIHRydWUpO1xyXG4gICAgICAgICAgICBqUXVlcnkoXCJpbnB1dFtuYW1lPVJlY2VpcHRUeXBlSWRdW3ZhbHVlPVwiICsgcmVjaWQgKyBcIl1cIikucHJvcChcImNoZWNrZWRcIiwgdHJ1ZSk7XHJcbiAgICAgICAgfSwgMTAwMCk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgLy99XHJcbiAgICB9XHJcbn1cclxuIl19
