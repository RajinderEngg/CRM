System.register(["angular2/core", 'angular2/common', "../../services/ResourceService", "angular2/router", "../../services/RecieptService", "../../services/CustomerService", '../../comonComponents/basicComponents', "../../services/ChargeCreditService"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, common_1, ResourceService_1, router_1, RecieptService_1, CustomerService_1, basicComponents_1, ChargeCreditService_1;
    var AmaxReceiptCreate;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (ResourceService_1_1) {
                ResourceService_1 = ResourceService_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (RecieptService_1_1) {
                RecieptService_1 = RecieptService_1_1;
            },
            function (CustomerService_1_1) {
                CustomerService_1 = CustomerService_1_1;
            },
            function (basicComponents_1_1) {
                basicComponents_1 = basicComponents_1_1;
            },
            function (ChargeCreditService_1_1) {
                ChargeCreditService_1 = ChargeCreditService_1_1;
            }],
        execute: function() {
            AmaxReceiptCreate = (function () {
                // @ViewChild('RTLDiv') private myScrollContainer: ElementRef;
                function AmaxReceiptCreate(_resourceService, _RecieptService, _CustomerService, _routeParams, _ChargeCreditService) {
                    this._resourceService = _resourceService;
                    this._RecieptService = _RecieptService;
                    this._CustomerService = _CustomerService;
                    this._routeParams = _routeParams;
                    this._ChargeCreditService = _ChargeCreditService;
                    this.RES = {};
                    this.Formtype = "SCREEN_RECEIPTCREATE";
                    this.Lang = "";
                    this._Banks = [];
                    this._CustomerNotes = [];
                    this._Addresses = [];
                    this._PayTypes = [];
                    this._Accounts = [];
                    this._Goals = [];
                    this._ProjectCats = [];
                    this._Projects = [];
                    this._Currencies = [];
                    this.PasteText = "";
                    this.IsShowProducts = false;
                    //    modelInput.ReceiptLines = [];
                    this._ThankLetters = [];
                    this.RowCount = 0;
                    this.Isbtndisable = "";
                    this.SAVE_BTN_TEXT = "Save";
                    this.MsgClass = "text-primary";
                    this.modelInput = {};
                    this.saveInput = {};
                    this.ChangeDialog = "";
                    this.CHANGEDIR = "";
                    this.ShowMoreText = "";
                    this.ShowMore = false;
                    this.IsBankDetShow = false;
                    this.DefaultDate = "";
                    this.IPopUpOpen = false;
                    this.PopProdObj = {};
                    this.RES.SCREEN_RECEIPTCREATE = {};
                    this.modelInput = {};
                    //this.modelInput.AddModel = {};
                    this.modelInput.ReceiptLines = [];
                    this.modelInput.ReceiptProducts = [];
                    //this.modelInput.ReceiptProducts = [{ RowNo: "1", ProductNo: "", ProductName: "", Price: "0", Qty: "1", Total: "0" }];
                    this.IsShowProducts = false;
                    this.IPopUpOpen = false;
                    this.IsBankDetShow = false;
                    this.modelInput.ReceiptTypeId = _routeParams.params.ReceiptTypeId;
                    //this.baseUrl = "http://localhost:3000/#/";
                    // debugger;
                    // alert(this.modelInput.ReceiptTypeId);
                    this.baseUrl = _resourceService.AppUrl;
                    this.modelInput.CustomerId = _routeParams.params.Id;
                    this.modelInput.CustomerName = "";
                    //this.modelInput.AddModel.ReferenceDate = "";
                    // this.ShowMoreText = "More";
                    this.DefaultDate = moment(new Date()).format('DD-MM-YYYY');
                    this.Lang = localStorage.getItem("lang");
                    var MText = "";
                    if (this.Lang == "en") {
                        MText = "More";
                    }
                    else {
                        MText = "יותר";
                    }
                    var DupObj = {
                        Amount: 0, ValueDate: this.DefaultDate, PayTypeId: 1, AccountId: "", AccountNo: "",
                        BranchNo: "", Bank: "", CreditCardType: "", DonationTypeId: "", ProjectCategoryId: "", ProjectId: "", ReferenceDate: this.DefaultDate,
                        For_Invoice: "", RecievedCustId: "", Payed: false, DepositeRemark: "", ShowMore: false, ShowMoreText: MText,
                        CashCSS: "grey", CreditCSS: "white", BankCSS: "white", OtherCSS: "white", IsShowOthers: false, IsCreditShow: false, IsBankDetShow: false
                    };
                    this.modelInput.ReceiptLines.push(DupObj);
                }
                AmaxReceiptCreate.prototype.dateVSelectionChange = function (evt, dataobj) {
                    console.log(evt);
                    dataobj.ValueDate = evt;
                    // alert(this.modelInput.BirthDate);
                    //this.validateLogin();
                };
                AmaxReceiptCreate.prototype.dateSelectionChange = function (evt, dataobj) {
                    console.log(evt);
                    dataobj.ReferenceDate = evt;
                    // alert(this.modelInput.BirthDate);
                    //this.validateLogin();
                };
                AmaxReceiptCreate.prototype.More = function (modelobj) {
                    // alert("call");
                    if (modelobj.ShowMore == true) {
                        modelobj.ShowMore = false;
                        if (this.Lang == "en") {
                            modelobj.ShowMoreText = "More";
                        }
                        else {
                            modelobj.ShowMoreText = "יותר";
                        }
                    }
                    else {
                        modelobj.ShowMore = true;
                        if (this.Lang == "en") {
                            modelobj.ShowMoreText = "Less";
                        }
                        else {
                            modelobj.ShowMoreText = "פָּחוּת";
                        }
                    }
                };
                AmaxReceiptCreate.prototype.BankDetailShow = function (PayTypeId, dataobj) {
                    if (PayTypeId != 1 && PayTypeId != 3) {
                        dataobj.IsBankDetShow = true;
                        dataobj.IsCreditShow = false;
                        this.BindAutoCompleteBank();
                    }
                    else if (PayTypeId == 3) {
                        dataobj.IsCreditShow = true;
                        dataobj.IsBankDetShow = false;
                    }
                    else {
                        dataobj.IsBankDetShow = false;
                        dataobj.IsCreditShow = false;
                    }
                };
                AmaxReceiptCreate.prototype.setdefaultmode = function () {
                    var _this = this;
                    //document.location = this.baseUrl + "ReceiptCreate/" + this.modelInput.CustomerId + " /" + this.modelInput.ReceiptId;
                    this.IPopUpOpen = false;
                    this.RowCount = 0;
                    window.scrollTo(0, 0);
                    var _ReceiptTypeId = this.modelInput.ReceiptTypeId;
                    var PrevReceiptType = this.modelInput.RecieptType;
                    var CustId = this.modelInput.CustomerId;
                    var CustName = this.modelInput.CustomerName;
                    var addressId = this.modelInput.AddressId;
                    var thnkLetterId = this.modelInput.ThanksLetterId;
                    var PrintValueDate = this.modelInput.ValueDate;
                    var associationName = this.modelInput.associationName;
                    var PrinterId = this.modelInput.PrinterId;
                    var associationid = this.modelInput.associationId;
                    this.modelInput = {};
                    this.IsShowProducts = false;
                    this.modelInput.CustomerId = CustId;
                    this.modelInput.CustomerName = CustName;
                    this.modelInput.AddressId = addressId;
                    this.modelInput.associationName = associationName;
                    this.modelInput.ThanksLetterId = thnkLetterId;
                    this.modelInput.PrintValueDate = PrintValueDate;
                    this.modelInput.ReceiptTypeId = _ReceiptTypeId;
                    this.modelInput.PrinterId = PrinterId;
                    this.modelInput.associationId = associationid;
                    this.modelInput.ReceiptLines = [];
                    this.modelInput.ReceiptProducts = [];
                    //this.modelInput.ReceiptProducts = [{ RowNo: "1", ProductNo: "", ProductName: "", Price: "0", Qty: "1", Total: "0" }];
                    var DupObj = {
                        Amount: 0, ValueDate: this.DefaultDate, PayTypeId: 1, AccountId: "", AccountNo: "",
                        BranchNo: "", Bank: "", CreditCardType: "", DonationTypeId: "", ProjectCategoryId: "", ProjectId: "", ReferenceDate: this.DefaultDate,
                        For_Invoice: "", RecievedCustId: CustId, Payed: false, DepositeRemark: "", ShowMore: false, ShowMoreText: "More",
                        CashCSS: "grey", CreditCSS: "white", BankCSS: "white", OtherCSS: "white", IsShowOthers: false, IsCreditShow: false, IsBankDetShow: false
                    };
                    this.modelInput.ReceiptLines.push(DupObj);
                    //this.GetCustomerDetail(CustId);
                    //this.modelInput.RecieptType = PrevReceiptType;
                    this._RecieptService.GetRecieptType(this._routeParams.params.ReceiptTypeId).subscribe(function (resp) {
                        // debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.modelInput.RecieptType = response.Data[0].RecieptNameEng;
                            _this.modelInput.CurrencyId = response.Data[0].CurrencyId;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    // this.IsBankDetShow = false;
                    this._RecieptService.GetEmployee().subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            //debugger;
                            _this.modelInput.EmployeeId = response.Data[0].Value;
                            _this.modelInput.EmployeeName = response.Data[0].Text;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._RecieptService.GetReceiptDetail().subscribe(function (resp) {
                        // debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.modelInput.RecieptNo = response.Data.Value;
                            _this.modelInput.RecieptDate = response.Data.Text;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxReceiptCreate.prototype.saveReceiptData = function (IsExit) {
                    var _this = this;
                    // debugger;
                    //if (this.IPopUpOpen == false)
                    //{
                    var EmpName = jQuery("#EmpId").val();
                    this._RecieptService.GetEmployeeFromEmpName(EmpName).subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.modelInput.EmployeeId = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    if (this.modelInput.CustomerId != null && this.modelInput.CustomerId != "" && this.modelInput.CustomerId != undefined
                        && this.modelInput.CurrencyId != null && this.modelInput.CurrencyId != "" && this.modelInput.CurrencyId != undefined
                        && this.modelInput.ReceiptLines.length > 0
                        && this.modelInput.associationId != null && this.modelInput.associationId != "" && this.modelInput.associationId != undefined
                        && this.modelInput.EmployeeId != null && this.modelInput.EmployeeId != "-1" && this.modelInput.EmployeeId != undefined
                        && this.modelInput.ThanksLetterId != null && this.modelInput.ThanksLetterId != "" && this.modelInput.ThanksLetterId != undefined
                        && this.modelInput.PrinterId != null && this.modelInput.PrinterId != "" && this.modelInput.PrinterId != undefined
                        && this.modelInput.RecieptNo != null && this.modelInput.RecieptNo != "" && this.modelInput.RecieptNo != undefined) {
                        this.modelInput.RecieptType = this.modelInput.ReceiptTypeId;
                        var LineCount = this.modelInput.ReceiptLines.length;
                        var CheckRowValid = true;
                        if (LineCount < 1) {
                            CheckRowValid = false;
                        }
                        //alert(JSON.stringify(this.modelInput));
                        for (var cnt in this.modelInput.ReceiptLines) {
                            var ErrorMessage = "Row Number - " + (parseInt(cnt) + 1).toString() + " is not valid in Receipt Lines <br>";
                            if (this.ValidateRowModel(this.modelInput.ReceiptLines[cnt], ErrorMessage) == false) {
                                CheckRowValid = false;
                                break;
                            }
                        }
                        for (var cnt in this.modelInput.ReceiptProducts) {
                            var ErrorMessage = "Row Number - " + (parseInt(cnt) + 1).toString() + " is not valid in Products <br>";
                            if (this.ValidateProductRowModel(this.modelInput.ReceiptProducts[cnt], ErrorMessage, cnt) == false) {
                                CheckRowValid = false;
                                break;
                            }
                        }
                        if (CheckRowValid == true) {
                            //debugger;
                            var jdata = JSON.stringify(this.modelInput);
                            //console.log(jdata);
                            this._RecieptService.AddReceipt(jdata).subscribe(function (response) {
                                console.log(response);
                                response = jQuery.parseJSON(response);
                                _this.Isbtndisable = "";
                                if (response.IsError == true) {
                                    alert(response.ErrMsg);
                                    _this.MsgClass = "text-danger";
                                }
                                else {
                                    bootbox.alert({
                                        message: response.ErrMsg,
                                        className: _this.ChangeDialog,
                                        buttons: {
                                            ok: {
                                                //label: 'Ok',
                                                className: _this.CHANGEDIR
                                            }
                                        }
                                    });
                                    var EmpId = localStorage.getItem("employeeid");
                                    var OrgId = localStorage.getItem(EmpId + "_OrgId");
                                    _this._resourceService.deleteCookie(EmpId + "_" + OrgId + "_ReceiptCreate_Cache");
                                    _this._resourceService.deleteCookie(EmpId + "_" + OrgId + "_ReceiptCreate_IsShowProducts");
                                    _this._resourceService.deleteCookie(EmpId + "_" + OrgId + "_ReceiptCreate_Product");
                                    if (IsExit == true) {
                                        document.location = _this.baseUrl + "ReceiptSelect/" + _this.modelInput.EmployeeId + " /" + _this.modelInput.CustomerId;
                                    }
                                    else {
                                        _this.setdefaultmode();
                                        _this.modelInput.PrintRecieptNo = response.Data.RecieptNo;
                                        _this.CustId = response.CustomerId;
                                    }
                                }
                            }, function (error) { return console.log(error); }, function () { return console.log("Save Call Compleated"); });
                        }
                    }
                    else {
                        var msg = "";
                        if (this.modelInput.CustomerId == null || this.modelInput.CustomerId == "" || this.modelInput.CustomerId == undefined) {
                            msg += "<br>Please enter customerid";
                        }
                        if (this.modelInput.CurrencyId == null || this.modelInput.CurrencyId == "" || this.modelInput.CurrencyId == undefined) {
                            msg += "<br>Please select currency";
                        }
                        if (this.modelInput.associationId == null || this.modelInput.associationId == "" || this.modelInput.associationId == undefined) {
                            msg += "<br>Please enter Deposited By";
                        }
                        if (this.modelInput.EmployeeId == null || this.modelInput.EmployeeId == "" || this.modelInput.EmployeeId == undefined) {
                            msg += "<br>Please enter valid employee";
                        }
                        if (this.modelInput.ThanksLetterId == null || this.modelInput.ThanksLetterId == "" || this.modelInput.ThanksLetterId == undefined) {
                            msg += this.modelInput.ThanksLetterId;
                            msg += "<br>Please select print template";
                        }
                        if (this.modelInput.PrinterId == null || this.modelInput.PrinterId == "" || this.modelInput.PrinterId == undefined) {
                            msg += "<br>Please set printer name in database";
                        }
                        if (this.modelInput.RecieptNo == null || this.modelInput.RecieptNo == "" || this.modelInput.RecieptNo == undefined) {
                            msg += "<br>Receipt no is not set";
                        }
                        if (this.modelInput.ReceiptLines.length == 0) {
                            msg += "<br>Please atleast one amount detail in grid";
                        }
                        bootbox.alert({
                            message: msg,
                            className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                    }
                    //}
                };
                AmaxReceiptCreate.prototype.delModel = function (ModelObj) {
                    //debugger;
                    if (this.modelInput.ReceiptLines.length > 1) {
                        var index = 0;
                        jQuery.each(this.modelInput.ReceiptLines, function () {
                            if (this == ModelObj) {
                                return false;
                            }
                            index = index + 1;
                        });
                        this.modelInput.ReceiptLines.splice(index, 1);
                        this.BindTotal();
                    }
                };
                AmaxReceiptCreate.prototype.BindTotal = function () {
                    var _this = this;
                    var ttotal = 0;
                    //debugger;
                    jQuery.each(this.modelInput.ReceiptLines, function () {
                        ttotal += parseFloat(this.Amount);
                    });
                    this.modelInput.Total = ttotal;
                    var vDate = this.modelInput.ValueDate;
                    console.log(vDate);
                    if (vDate == null || vDate == "")
                        vDate = this.DefaultDate;
                    var curID = this.modelInput.CurrencyId;
                    //alert(curID);
                    this._RecieptService.GetLeadcurrency(curID, "NIS", vDate).subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            //var n = num.toFixed(2);
                            _this.modelInput.TotalInLeadCurrent = parseFloat(response.Data) * ttotal;
                            _this.modelInput.TotalInLeadCurrent = _this.modelInput.TotalInLeadCurrent.toFixed(2);
                            jQuery.each(_this.modelInput.ReceiptLines, function () {
                                //ttotal += parseFloat(this.Amount);
                                this.AmountInLeadCurrent = parseFloat(response.Data) * parseFloat(this.Amount);
                                this.AmountInLeadCurrent = this.AmountInLeadCurrent.toFixed(2);
                            });
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxReceiptCreate.prototype.createReceiptPDF = function () {
                    var _this = this;
                    if (this.modelInput.PrintRecieptNo != null) {
                        var Recipt_No = this.modelInput.PrintRecieptNo;
                        var Reciept_Type = this.modelInput.ReceiptTypeId;
                        var Customer_Id = this.modelInput.CustomerId;
                        var ThanksLetter_Id = this.modelInput.ThanksLetterId;
                        var LeadCurrencyId = this.modelInput.CurrencyId;
                        this._RecieptService.CreateReceiptPdf(Customer_Id, ThanksLetter_Id, Recipt_No, Reciept_Type, LeadCurrencyId).subscribe(function (response) {
                            // debugger;
                            response = jQuery.parseJSON(response);
                            if (response.IsError == false) {
                                var l = response.Data.toString().substring(0, 5);
                                if (response.Data.toString().substring(0, 5) == "Link:") {
                                    var PrintData = response.Data.toString().substring(5, response.Data.toString().length);
                                    var windowObject = window.open(PrintData, 'Print', 'scrollbars=yes,resizable=yes,width=1050,height=650');
                                }
                                else {
                                    bootbox.alert({
                                        message: response.Data,
                                        className: _this.ChangeDialog,
                                        buttons: {
                                            ok: {
                                                //label: 'Ok',
                                                className: _this.CHANGEDIR
                                            }
                                        }
                                    });
                                }
                            }
                            else {
                                bootbox.alert({
                                    message: response.ErrMsg,
                                    className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                        }, function (error) {
                            console.log(error);
                        }, function () {
                            console.log("CallCompleted");
                        });
                    }
                };
                AmaxReceiptCreate.prototype.DupModel = function (ModelObj) {
                    var MObj = {};
                    this.RowCount++;
                    ModelObj.RecieptRoWID = this.RowCount;
                    MObj = ModelObj;
                    var Vdate = MObj.ValueDate.split('-');
                    var NewVDate = new Date(parseInt(Vdate[2]), parseInt(Vdate[1]), parseInt(Vdate[0]));
                    NewVDate.setMonth(NewVDate.getMonth());
                    var NVDate = moment(NewVDate).format('DD-MM-YYYY');
                    //var Month = parseInt(Vdate[1]) + 1;
                    //MObj.ValueDate = NewVDate;
                    var DupObj = { Amount: ModelObj.Amount, ValueDate: NewVDate, PayTypeId: ModelObj.PayTypeId, AccountId: ModelObj.AccountId, AccountNo: ModelObj.AccountNo, BranchNo: ModelObj.BranchNo, Bank: ModelObj.Bank, CreditCardType: ModelObj.CreditCardType, DonationTypeId: ModelObj.DonationTypeId, ProjectCategoryId: ModelObj.ProjectCategoryId, ProjectId: ModelObj.ProjectId, ReferenceDate: ModelObj.ReferenceDate, For_Invoice: ModelObj.For_Invoice, RecievedCustId: ModelObj.RecievedCustId, Payed: ModelObj.Payed, DepositeRemark: ModelObj.DepositeRemark };
                    this.modelInput.ReceiptLines.push(DupObj);
                    var index = 0;
                    var TotalRows = this.modelInput.ReceiptLines.length;
                    jQuery.each(this.modelInput.ReceiptLines, function () {
                        if (index == (TotalRows - 1)) {
                            this.ValueDate = NVDate;
                        }
                        index++;
                    });
                    this.BindTotal();
                };
                AmaxReceiptCreate.prototype.ValidateRowModel = function (CurrentModel, msg) {
                    //msg = "";
                    var IsValidData = true;
                    if (CurrentModel.ValueDate != "") {
                        if (moment(CurrentModel.ValueDate, "DD-MM-YYYY", true).isValid() == false) {
                            bootbox.alert({ message: "Value Date is not valid" });
                            return false;
                        }
                    }
                    if (CurrentModel.ReferenceDate != "") {
                        if (moment(CurrentModel.ReferenceDate, "DD-MM-YYYY", true).isValid() == false) {
                            bootbox.alert({ message: "Reference Date is not valid" });
                            return false;
                        }
                    }
                    //var msg = "";
                    if (CurrentModel.Amount == null || CurrentModel.Amount == "" || CurrentModel.Amount == undefined) {
                        IsValidData = false;
                        msg += "<br>Please enter amount";
                    }
                    if (CurrentModel.PayTypeId == null || CurrentModel.PayTypeId == "" || CurrentModel.PayTypeId == undefined) {
                        IsValidData = false;
                        msg += "<br>Please select paytype";
                    }
                    if (CurrentModel.ProjectId == null || CurrentModel.ProjectId == "" || CurrentModel.ProjectId == undefined) {
                        IsValidData = false;
                        msg += "<br>Please select project";
                    }
                    if (CurrentModel.DonationTypeId == null || CurrentModel.DonationTypeId == "" || CurrentModel.DonationTypeId == undefined) {
                        IsValidData = false;
                        msg += "<br>Please select goal";
                    }
                    if (CurrentModel.AccountId == null || CurrentModel.AccountId == "" || CurrentModel.AccountId == undefined) {
                        IsValidData = false;
                        msg += "<br>Please select account";
                    }
                    if (CurrentModel.PayTypeId == 8) {
                        if (CurrentModel.AccountNo == null || CurrentModel.AccountNo == "" || CurrentModel.AccountNo == undefined) {
                            IsValidData = false;
                            msg += "<br>Please enter account no";
                        }
                        if (CurrentModel.BranchNo == null || CurrentModel.BranchNo == "" || CurrentModel.BranchNo == undefined) {
                            IsValidData = false;
                            msg += "<br>Please select branch no";
                        }
                        if (CurrentModel.Bank == null || CurrentModel.Bank == "" || CurrentModel.Bank == undefined) {
                            IsValidData = false;
                            msg += "<br>Please enter bank";
                        }
                    }
                    if (CurrentModel.PayTypeId == 3) {
                        if (CurrentModel.CreditCardType == null || CurrentModel.CreditCardType == "" || CurrentModel.CreditCardType == undefined) {
                            IsValidData = false;
                            msg += "<br>Please enter CreditCard";
                        }
                    }
                    if (IsValidData == false) {
                        bootbox.alert({
                            message: msg,
                            className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                    }
                    return IsValidData;
                };
                AmaxReceiptCreate.prototype.ValidateProductRowModel = function (CurrentModel, msg, rowno) {
                    //msg = "";
                    var IsValidData = true;
                    //var msg = "";
                    if (CurrentModel.ProductNo == null || CurrentModel.ProductNo == "" || CurrentModel.ProductNo == undefined) {
                        IsValidData = false;
                        msg += "<br>Please enter product no";
                    }
                    if (CurrentModel.ProductName == null || CurrentModel.ProductName == "" || CurrentModel.ProductName == undefined) {
                        IsValidData = false;
                        msg += "<br>Please enter product name";
                    }
                    if (CurrentModel.Price == null || CurrentModel.Price == "" || CurrentModel.Price == undefined) {
                        IsValidData = false;
                        msg += "<br>Please enter price";
                    }
                    if (CurrentModel.Qty == null || CurrentModel.Qty == "" || CurrentModel.Qty == undefined) {
                        IsValidData = false;
                        msg += "<br>Please enter quantity";
                    }
                    if (IsValidData == false) {
                        bootbox.alert({
                            message: msg,
                            className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                    }
                    return IsValidData;
                };
                AmaxReceiptCreate.prototype.AddReceiptLine = function (CurrentModel) {
                    // this.modelInput.AddModel.Bank = jQuery("#Bank").val();
                    if (this.ValidateRowModel(CurrentModel, "")) {
                        var MText = "";
                        if (this.Lang == "en") {
                            MText = "More";
                        }
                        else {
                            MText = "יותר";
                        }
                        var ModelObj = {
                            Amount: 0, ValueDate: this.DefaultDate, PayTypeId: "1", AccountId: "", AccountNo: "",
                            BranchNo: "", Bank: "", CreditCardType: "", DonationTypeId: "", ProjectCategoryId: "", ProjectId: "", ReferenceDate: this.DefaultDate,
                            For_Invoice: "", RecievedCustId: "", Payed: false, DepositeRemark: "", ShowMore: false, ShowMoreText: MText,
                            CashCSS: "grey", CreditCSS: "white", BankCSS: "white", OtherCSS: "white", IsShowOthers: false, IsCreditShow: false, IsBankDetShow: false
                        };
                        CurrentModel.RecievedCustId = this.CustId;
                        // debugger;
                        this.modelInput.ReceiptLines.push(ModelObj);
                        this.BindTotal();
                    }
                };
                AmaxReceiptCreate.prototype.ValidatePasteText = function () {
                    var SplitText = this.PasteText.split(/[\t]+/);
                    var IsValidData = true;
                    var msg = "";
                    // debugger;
                    if (SplitText.length == 4) {
                        if (jQuery.isNumeric(SplitText[1].trim()) == false) {
                            IsValidData = false;
                            msg = "Quantity must be numeric only";
                        }
                        var SplitPrice = SplitText[3].trim().split(/[\s]+/);
                        if (SplitPrice.length == 2) {
                            if (jQuery.isNumeric(SplitPrice[1].trim()) == false) {
                                IsValidData = false;
                                msg = "Price must be numeric only";
                            }
                        }
                        else {
                            IsValidData = false;
                            msg = "Please enter text in Product No \t Quantity \t Product Name \t Price format only";
                        }
                    }
                    else {
                        IsValidData = false;
                        msg = "Please enter text in Product No \t Quantity \t Product Name \t Price format only";
                    }
                    if (IsValidData == false) {
                        bootbox.alert({
                            message: msg,
                            className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                    }
                    return IsValidData;
                };
                AmaxReceiptCreate.prototype.GetValidateText = function (keyCode) {
                    if (keyCode == 13) {
                        this.PasteText = jQuery("#PasteText").val();
                        if (this.ValidatePasteText()) {
                            var SplitText = this.PasteText.split(/[\t]+/);
                            this.PopProdObj.ProductNo = SplitText[0].trim();
                            this.PopProdObj.Qty = parseFloat(SplitText[1].trim());
                            this.PopProdObj.ProductName = SplitText[2].trim();
                            var SplitPrice = SplitText[3].trim().split(/[\s]+/);
                            this.PopProdObj.Price = parseFloat(SplitPrice[1].trim()).toFixed(2);
                            this.PopProdObj.Total = (parseFloat(SplitPrice[1].trim()) * parseFloat(SplitText[1].trim())).toFixed(2);
                            this.PasteText = "";
                            jQuery('#PasteTextModal').closeModal();
                            this.BindProdTotal();
                        }
                    }
                };
                AmaxReceiptCreate.prototype.OpenProducts = function (ProdObj) {
                    localStorage.setItem("TempReceiptId", this.modelInput.ReceiptTypeId);
                    this._resourceService.setCookie("TempRowNo", ProdObj.RowNo, 10);
                    var EmpId = localStorage.getItem("employeeid");
                    var OrgId = localStorage.getItem(EmpId + "_OrgId");
                    if (this.modelInput != undefined && this.modelInput != null) {
                        var jdata = JSON.stringify(this.modelInput);
                        this._resourceService.setCookie(EmpId + "_" + OrgId + "_ReceiptCreate_Cache", jdata, 10);
                    }
                    this._resourceService.setCookie(EmpId + "_" + OrgId + "_ReceiptCreate_IsShowProducts", this.IsShowProducts, 10);
                    document.location = this.baseUrl + "SearchProducts/" + this.modelInput.CustomerId + "/ReceiptCreate";
                };
                AmaxReceiptCreate.prototype.OpenPasteModal = function (ProdObj) {
                    if ((ProdObj.ProductNo != undefined || ProdObj.ProductNo != null || ProdObj.ProductNo != "")
                        && (ProdObj.ProductName != undefined || ProdObj.ProductName != null || ProdObj.ProductName != "")
                        && (ProdObj.Price != undefined || ProdObj.Price != null || ProdObj.Price != "")) {
                        this.PasteText = "";
                    }
                    else {
                        this.PasteText = ProdObj.ProductNo + " | " + ProdObj.ProductName + " | " + ProdObj.Price;
                    }
                    this.PopProdObj = ProdObj;
                    jQuery('#PasteTextModal').openModal();
                };
                AmaxReceiptCreate.prototype.OpenCustSearch = function () {
                    this.IPopUpOpen = true;
                    localStorage.setItem("TempReceiptId", this.modelInput.ReceiptTypeId);
                    var EmpId = localStorage.getItem("employeeid");
                    var OrgId = localStorage.getItem(EmpId + "_OrgId");
                    if (this.modelInput != undefined && this.modelInput != null) {
                        var jdata = JSON.stringify(this.modelInput);
                        this._resourceService.setCookie(EmpId + "_" + OrgId + "_ReceiptCreate_Cache", jdata, 10);
                    }
                    this._resourceService.setCookie(EmpId + "_" + OrgId + "_ReceiptCreate_IsShowProducts", this.IsShowProducts, 10);
                    document.location = this.baseUrl + "Customer/Search/0/ReceiptCreate/" + this.modelInput.CustomerId;
                    //jQuery('#CustSearchModal  .modal-content').html('<object data="' + this.baseUrl+'Customer/Search/1/ReceiptCreate" style="width:100%;height:500px"/>');
                    //jQuery('#CustSearchModal').openModal();
                };
                AmaxReceiptCreate.prototype.OpenNotes = function () {
                    //debugger;
                    //if (this.IPopUpOpen == false) {
                    jQuery('#NoteModal').openModal();
                    //}
                    //else {
                    //    this.modelInput.CustomerId = this._routeParams.params.Id;
                    //    window.open(this.baseUrl + "ReceiptCreate/" + this.modelInput.CustomerId + "/" + this.modelInput.ReceiptTypeId, "_self");
                    //    jQuery('#CustSearchModal').closeModal();
                    //    jQuery(".lean-overlay").css({ "display": "none" });
                    //    this.setdefaultmode();
                    //}
                };
                AmaxReceiptCreate.prototype.OpenTemplates = function () {
                    jQuery('#TemplateModal').openModal();
                };
                AmaxReceiptCreate.prototype.ChooseNote = function (objct) {
                    this.modelInput.CustomerNote = objct.Text;
                    this.modelInput.CustomerNoteId = objct.Value;
                };
                AmaxReceiptCreate.prototype.ChooseThanksLetters = function (objct) {
                    // debugger;
                    this.modelInput.ThanksLetterName = objct.Text;
                    this.modelInput.ThanksLetterId = objct.Value;
                };
                AmaxReceiptCreate.prototype.GetCustomerDetail = function () {
                    var _this = this;
                    var CustId = this.modelInput.CustomerId;
                    this._CustomerService.GetCompleteCustDet(CustId).subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            response = response.Data;
                            _this._Addresses = response.CustomerAddresses;
                            var Mainaddress;
                            jQuery.each(response.CustomerAddresses, function () {
                                if (this.MainAddress == true) {
                                    Mainaddress = this.AddressId;
                                }
                            });
                            _this.modelInput.AddressId = Mainaddress;
                            _this.modelInput.CustomerId = response.CustomerId;
                            _this.modelInput.ReceiptLines[0].RecievedCustId = response.CustomerId;
                            _this.CustId = response.CustomerId;
                            _this.modelInput.CustomerName = response.lname + " " + response.fname;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxReceiptCreate.prototype.ChoosePayType = function (dataobject, pTypeId) {
                    // debugger;
                    dataobject.CashCSS = "white";
                    dataobject.CreditCSS = "white";
                    dataobject.BankCSS = "white";
                    dataobject.OtherCSS = "white";
                    dataobject.IsCreditShow = false;
                    //var pTypeId = "";
                    if (pTypeId != 0) {
                        dataobject.PayTypeId = pTypeId;
                        if (pTypeId == 1) {
                            dataobject.CashCSS = "grey";
                        }
                        else if (pTypeId == 3) {
                            dataobject.CreditCSS = "grey";
                            //dataobject.IsBankDetShow == true;
                            dataobject.IsCreditShow = true;
                        }
                        else if (pTypeId == 8) {
                            dataobject.BankCSS = "grey";
                        }
                        dataobject.IsShowOthers = false;
                    }
                    else {
                        dataobject.PayTypeId = 0;
                        dataobject.IsShowOthers = true;
                        dataobject.OtherCSS = "grey";
                    }
                    if (pTypeId != 1 && pTypeId != 3) {
                        dataobject.IsBankDetShow = true;
                        dataobject.IsCreditShow = false;
                        this.BindAutoCompleteBank();
                    }
                    else if (pTypeId == 3) {
                        dataobject.IsCreditShow = true;
                        dataobject.IsBankDetShow = false;
                    }
                    else {
                        dataobject.IsBankDetShow = false;
                        dataobject.IsCreditShow = false;
                    }
                };
                AmaxReceiptCreate.prototype.BindProjects = function (CatId) {
                    this.BindProjectFromProjCat(CatId);
                };
                AmaxReceiptCreate.prototype.BindProjectFromProjCat = function (CatId) {
                    var _this = this;
                    this._RecieptService.GetProjects(CatId).subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Projects = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxReceiptCreate.prototype.BindAutoCompleteBank = function () {
                    var _this = this;
                    this._RecieptService.GetBanks().subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            //this._Banks = response.Data;
                            var typeaheadSource = [];
                            //  debugger;
                            jQuery.each(response.Data, function () {
                                var newtemp = {};
                                newtemp.id = this.Value;
                                newtemp.name = this.Text;
                                typeaheadSource.push(newtemp);
                            });
                            _this._Banks = response.Data;
                            jQuery('.Bank').typeahead({
                                source: typeaheadSource,
                                dataType: "JSON",
                            });
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxReceiptCreate.prototype.ShowHideProducts = function () {
                    if (this.IsShowProducts == false) {
                        this.modelInput.ReceiptProducts = [];
                        this.modelInput.ReceiptProducts = [{ RowNo: "1", ProductNo: "", ProductName: "", Price: "0", Qty: "1", Total: "0" }];
                        this.IsShowProducts = true;
                    }
                    else {
                        if (this.modelInput.ReceiptProducts.length == 0) {
                            this.IsShowProducts = false;
                        }
                    }
                };
                AmaxReceiptCreate.prototype.CanaddProduct = function (prodObj) {
                    //debugger;
                    return (prodObj.ProductNo != undefined && prodObj.ProductNo != "")
                        && (prodObj.ProductName != undefined && prodObj.ProductName != "")
                        && (prodObj.Price != undefined && prodObj.Price != "")
                        && (prodObj.Qty != undefined && prodObj.Qty != "");
                };
                AmaxReceiptCreate.prototype.AddProducts = function (prodObj) {
                    // debugger;
                    if (this.CanaddProduct(prodObj)) {
                        var ProductObj = { RowNo: (this.modelInput.ReceiptProducts.length + 1).toString(), ProductNo: "", ProductName: "", Price: "0", Qty: "1", Total: "0" };
                        this.modelInput.ReceiptProducts.push(ProductObj);
                        this.BindProdTotal();
                    }
                    else {
                        var msg = '';
                        if (prodObj.ProductNo == undefined || prodObj.ProductNo == "") {
                            msg += '\nPlease enter product no';
                        }
                        if (prodObj.ProductName == undefined || prodObj.ProductName == "") {
                            msg += '\nPlease enter product name';
                        }
                        if (prodObj.Price == undefined || prodObj.Price == "") {
                            msg += '\nPlease enter price';
                        }
                        if (prodObj.Qty == undefined || prodObj.Qty == "") {
                            msg += '\nPlease enter quantity';
                        }
                        bootbox.alert({
                            message: msg, className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                    }
                };
                AmaxReceiptCreate.prototype.delProductDet = function (ProdObj) {
                    //  debugger;
                    //if (this.modelInput.ReceiptProducts.length > 1) {
                    var index = 0;
                    jQuery.each(this.modelInput.ReceiptProducts, function () {
                        if (this == ProdObj) {
                            return false;
                        }
                        index = index + 1;
                    });
                    this.modelInput.ReceiptProducts.splice(index, 1);
                    index = 1;
                    jQuery.each(this.modelInput.ReceiptProducts, function () {
                        this.RowNo = index.toString();
                        index = index + 1;
                    });
                    this.BindProdTotal();
                    if (this.modelInput.ReceiptProducts.length == 0) {
                        this.IsShowProducts = false;
                    }
                    //}
                };
                AmaxReceiptCreate.prototype.CalculateProdRowTotal = function (prodObj) {
                    //  debugger;
                    var Price = 0;
                    if (prodObj.Price != undefined && prodObj.Price != null && prodObj.Qty != "") {
                        Price = parseFloat(prodObj.Price);
                    }
                    var Qty = 0;
                    if (prodObj.Qty != undefined && prodObj.Qty != null && prodObj.Qty != "") {
                        Qty = parseFloat(prodObj.Qty);
                    }
                    prodObj.Total = (Price * Qty).toFixed(2);
                    this.BindProdTotal();
                };
                AmaxReceiptCreate.prototype.BindProdTotal = function () {
                    var ProdTotal = 0;
                    jQuery.each(this.modelInput.ReceiptProducts, function () {
                        ProdTotal = parseFloat(ProdTotal.toString()) + parseFloat(this.Total);
                    });
                    this.modelInput.ProductTotal = ProdTotal.toFixed(2);
                };
                AmaxReceiptCreate.prototype.ngOnInit = function () {
                    var _this = this;
                    //jQuery(".lean-overlay").css({ "display": "none" });
                    jQuery("#NoteModal").closeModal();
                    jQuery(".lean-overlay").css({ "display": "none" });
                    window.scrollTo(0, 0);
                    // debugger;
                    var currencyid = "";
                    var EmpId = localStorage.getItem("employeeid");
                    var OrgId = localStorage.getItem(EmpId + "_OrgId");
                    var jdata = this._resourceService.getCookie(EmpId + "_" + OrgId + "_ReceiptCreate_Cache");
                    if (jdata != undefined && jdata != undefined && jdata != "") {
                        jdata = jdata.substring(1, jdata.length);
                        this.modelInput = jQuery.parseJSON(jdata);
                        this.modelInput.CustomerId = this._routeParams.params.Id;
                        currencyid = this.modelInput.CurrencyId;
                        this.GetCustomerDetail();
                    }
                    //  alert("ddd");
                    this.Lang = localStorage.getItem("lang");
                    this._resourceService.GetLangRes(this.Formtype, this.Lang).subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.RES = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._RecieptService.GetCustomerNotes().subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._CustomerNotes = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this.BindAutoCompleteBank();
                    this._RecieptService.GetThanksLetters(this.modelInput.ReceiptTypeId).subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._ThankLetters = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._RecieptService.GetAssociation().subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            //debugger;
                            _this.modelInput.associationId = response.Data[0].Value;
                            _this.modelInput.associationName = response.Data[0].Text;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._RecieptService.GetPrinter().subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            //debugger;
                            _this.modelInput.PrinterId = response.Data[0].Value;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._RecieptService.GetEmployee().subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            //debugger;
                            _this.modelInput.EmployeeId = response.Data[0].Value;
                            _this.modelInput.EmployeeName = response.Data[0].Text;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._RecieptService.GetPayType().subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._PayTypes = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._RecieptService.GetAccounts().subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Accounts = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._RecieptService.GetGoals().subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Goals = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._RecieptService.GetProjectCats().subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._ProjectCats = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this.BindProjectFromProjCat(-1);
                    this._RecieptService.GetCurrenciesFDB().subscribe(function (resp) {
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Currencies = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._RecieptService.GetRecieptType(this._routeParams.params.ReceiptTypeId).subscribe(function (resp) {
                        // debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.modelInput.RecieptType = response.Data[0].RecieptNameEng;
                            if (currencyid == "") {
                                _this.modelInput.CurrencyId = response.Data[0].CurrencyId;
                            }
                            else {
                                _this.modelInput.CurrencyId = currencyid;
                            }
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._RecieptService.GetReceiptDetail().subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.modelInput.RecieptNo = response.Data.Value;
                            _this.modelInput.RecieptDate = _this.DefaultDate;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    var CustId = this.modelInput.CustomerId;
                    this.GetCustomerDetail();
                    //////////////////////Cache Implement//////////////////////////
                    //  debugger;
                    var EmpId = localStorage.getItem("employeeid");
                    var OrgId = localStorage.getItem(EmpId + "_OrgId");
                    var isshow = this._resourceService.getCookie(EmpId + "_" + OrgId + "_ReceiptCreate_IsShowProducts");
                    if (isshow != undefined && isshow != undefined && isshow != "") {
                        isshow = isshow.substring(1, isshow.length);
                        this.IsShowProducts = Boolean(isshow);
                    }
                    var rowno = this._resourceService.getCookie("TempRowNo");
                    if (rowno != undefined && rowno != undefined && rowno != "") {
                        rowno = rowno.substring(1, rowno.length);
                        var pdata = this._resourceService.getCookie(EmpId + "_" + OrgId + "_ReceiptCreate_Product");
                        if (pdata != undefined && pdata != undefined && pdata != "") {
                            pdata = pdata.substring(1, pdata.length);
                            var Product = [];
                            Product = jQuery.parseJSON(pdata);
                            jQuery.each(this.modelInput.ReceiptProducts, function () {
                                if (this.RowNo == rowno) {
                                    this.ProductNo = Product.PartNumber;
                                    this.ProductName = Product.ProdNameDis;
                                    this.Price = parseFloat(Product.Price).toFixed(2);
                                    this.Total = (parseFloat(this.Price) * parseFloat(this.Qty)).toFixed(2);
                                    return false;
                                }
                            });
                            this.BindProdTotal();
                            this._resourceService.deleteCookie("TempRowNo");
                            this._resourceService.deleteCookie(EmpId + "_" + OrgId + "_ReceiptCreate_Product");
                        }
                    }
                };
                AmaxReceiptCreate.$inject = ['$scope', '$location', '$anchorScroll'];
                AmaxReceiptCreate = __decorate([
                    core_1.Component({
                        templateUrl: './app/amax/Receipt/templates/ReceiptCreate.html',
                        directives: [common_1.NgSwitch, common_1.NgSwitchWhen, common_1.NgSwitchDefault, basicComponents_1.AmaxDate],
                        providers: [RecieptService_1.RecieptService, ResourceService_1.ResourceService, CustomerService_1.CustomerService, ChargeCreditService_1.ChargeCreditService]
                    }), 
                    __metadata('design:paramtypes', [ResourceService_1.ResourceService, RecieptService_1.RecieptService, CustomerService_1.CustomerService, router_1.RouteParams, ChargeCreditService_1.ChargeCreditService])
                ], AmaxReceiptCreate);
                return AmaxReceiptCreate;
            }());
            exports_1("AmaxReceiptCreate", AmaxReceiptCreate);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFtYXgvUmVjZWlwdC9SZWNlaXB0Q3JlYXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1lBa0JBO2dCQWtDRyw4REFBOEQ7Z0JBQzdELDJCQUFvQixnQkFBaUMsRUFBVSxlQUErQixFQUFVLGdCQUFpQyxFQUFVLFlBQXlCLEVBQVUsb0JBQXlDO29CQUEzTSxxQkFBZ0IsR0FBaEIsZ0JBQWdCLENBQWlCO29CQUFVLG9CQUFlLEdBQWYsZUFBZSxDQUFnQjtvQkFBVSxxQkFBZ0IsR0FBaEIsZ0JBQWdCLENBQWlCO29CQUFVLGlCQUFZLEdBQVosWUFBWSxDQUFhO29CQUFVLHlCQUFvQixHQUFwQixvQkFBb0IsQ0FBcUI7b0JBakMvTixRQUFHLEdBQVcsRUFBRSxDQUFDO29CQUNqQixhQUFRLEdBQVcsc0JBQXNCLENBQUM7b0JBQzFDLFNBQUksR0FBVyxFQUFFLENBQUM7b0JBQ2xCLFdBQU0sR0FBRyxFQUFFLENBQUM7b0JBQ1osbUJBQWMsR0FBRyxFQUFFLENBQUM7b0JBQ3BCLGVBQVUsR0FBRyxFQUFFLENBQUM7b0JBQ2hCLGNBQVMsR0FBRyxFQUFFLENBQUM7b0JBQ2YsY0FBUyxHQUFHLEVBQUUsQ0FBQztvQkFDZixXQUFNLEdBQUcsRUFBRSxDQUFDO29CQUNaLGlCQUFZLEdBQUcsRUFBRSxDQUFDO29CQUNsQixjQUFTLEdBQUcsRUFBRSxDQUFDO29CQUNmLGdCQUFXLEdBQUcsRUFBRSxDQUFDO29CQUNqQixjQUFTLEdBQVcsRUFBRSxDQUFDO29CQUN2QixtQkFBYyxHQUFZLEtBQUssQ0FBQztvQkFDcEMsbUNBQW1DO29CQUMvQixrQkFBYSxHQUFHLEVBQUUsQ0FBQztvQkFDbkIsYUFBUSxHQUFVLENBQUMsQ0FBQztvQkFDcEIsaUJBQVksR0FBVyxFQUFFLENBQUM7b0JBQzFCLGtCQUFhLEdBQVMsTUFBTSxDQUFDO29CQUM3QixhQUFRLEdBQVcsY0FBYyxDQUFDO29CQUNsQyxlQUFVLEdBQVcsRUFBRSxDQUFDO29CQUN4QixjQUFTLEdBQVcsRUFBRSxDQUFDO29CQUN2QixpQkFBWSxHQUFXLEVBQUUsQ0FBQztvQkFDMUIsY0FBUyxHQUFXLEVBQUUsQ0FBQztvQkFFdkIsaUJBQVksR0FBVyxFQUFFLENBQUM7b0JBQzFCLGFBQVEsR0FBWSxLQUFLLENBQUM7b0JBQzFCLGtCQUFhLEdBQVksS0FBSyxDQUFDO29CQUMvQixnQkFBVyxHQUFXLEVBQUUsQ0FBQztvQkFDekIsZUFBVSxHQUFZLEtBQUssQ0FBQztvQkFDNUIsZUFBVSxHQUFXLEVBQUUsQ0FBQztvQkFLcEIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsR0FBRyxFQUFFLENBQUM7b0JBQ25DLElBQUksQ0FBQyxVQUFVLEdBQUcsRUFBRSxDQUFDO29CQUNyQixnQ0FBZ0M7b0JBQ2hDLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxHQUFHLEVBQUUsQ0FBQztvQkFDbEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLEdBQUcsRUFBRSxDQUFDO29CQUNyQyx1SEFBdUg7b0JBQ3ZILElBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDO29CQUM1QixJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztvQkFDeEIsSUFBSSxDQUFDLGFBQWEsR0FBRyxLQUFLLENBQUM7b0JBQzNCLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxHQUFHLFlBQVksQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDO29CQUNsRSw0Q0FBNEM7b0JBQzVDLFlBQVk7b0JBQ2Isd0NBQXdDO29CQUN2QyxJQUFJLENBQUMsT0FBTyxHQUFHLGdCQUFnQixDQUFDLE1BQU0sQ0FBQztvQkFDdkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsWUFBWSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7b0JBQ3BELElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxHQUFHLEVBQUUsQ0FBQztvQkFDbEMsOENBQThDO29CQUMvQyw4QkFBOEI7b0JBQzdCLElBQUksQ0FBQyxXQUFXLEdBQUcsTUFBTSxDQUFDLElBQUksSUFBSSxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUM7b0JBQzNELElBQUksQ0FBQyxJQUFJLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDekMsSUFBSSxLQUFLLEdBQUcsRUFBRSxDQUFDO29CQUNmLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzt3QkFDcEIsS0FBSyxHQUFHLE1BQU0sQ0FBQztvQkFDbkIsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixLQUFLLEdBQUcsTUFBTSxDQUFDO29CQUNuQixDQUFDO29CQUNELElBQUksTUFBTSxHQUFHO3dCQUNULE1BQU0sRUFBRSxDQUFDLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxXQUFXLEVBQUUsU0FBUyxFQUFFLENBQUMsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFLFNBQVMsRUFBRSxFQUFFO3dCQUNsRixRQUFRLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsY0FBYyxFQUFFLEVBQUUsRUFBRSxjQUFjLEVBQUUsRUFBRSxFQUFFLGlCQUFpQixFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFLGFBQWEsRUFBRSxJQUFJLENBQUMsV0FBVzt3QkFDckksV0FBVyxFQUFFLEVBQUUsRUFBRSxjQUFjLEVBQUUsRUFBRSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsY0FBYyxFQUFFLEVBQUUsRUFBRSxRQUFRLEVBQUUsS0FBSyxFQUFFLFlBQVksRUFBRSxLQUFLO3dCQUMzRyxPQUFPLEVBQUUsTUFBTSxFQUFFLFNBQVMsRUFBRSxPQUFPLEVBQUUsT0FBTyxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsT0FBTyxFQUFFLFlBQVksRUFBRSxLQUFLLEVBQUUsWUFBWSxFQUFFLEtBQUssRUFBRSxhQUFhLEVBQUUsS0FBSztxQkFDM0ksQ0FBQztvQkFFRixJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBRTlDLENBQUM7Z0JBQ0QsZ0RBQW9CLEdBQXBCLFVBQXFCLEdBQUcsRUFBRSxPQUFPO29CQUM3QixPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUNqQixPQUFPLENBQUMsU0FBUyxHQUFHLEdBQUcsQ0FBQztvQkFDeEIsb0NBQW9DO29CQUNwQyx1QkFBdUI7Z0JBQzNCLENBQUM7Z0JBR0QsK0NBQW1CLEdBQW5CLFVBQW9CLEdBQUcsRUFBRSxPQUFPO29CQUM1QixPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUNqQixPQUFPLENBQUMsYUFBYSxHQUFHLEdBQUcsQ0FBQztvQkFDNUIsb0NBQW9DO29CQUNwQyx1QkFBdUI7Z0JBQzNCLENBQUM7Z0JBRUQsZ0NBQUksR0FBSixVQUFLLFFBQVE7b0JBQ1QsaUJBQWlCO29CQUNqQixFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsUUFBUSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7d0JBQzVCLFFBQVEsQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO3dCQUMxQixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQ3BCLFFBQVEsQ0FBQyxZQUFZLEdBQUcsTUFBTSxDQUFDO3dCQUNuQyxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLFFBQVEsQ0FBQyxZQUFZLEdBQUcsTUFBTSxDQUFDO3dCQUNuQyxDQUFDO29CQUVMLENBQUM7b0JBQ0QsSUFBSSxDQUFDLENBQUM7d0JBQ0YsUUFBUSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7d0JBQ3pCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDcEIsUUFBUSxDQUFDLFlBQVksR0FBRyxNQUFNLENBQUM7d0JBQ25DLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsUUFBUSxDQUFDLFlBQVksR0FBRyxTQUFTLENBQUM7d0JBQ3RDLENBQUM7b0JBRUwsQ0FBQztnQkFDTCxDQUFDO2dCQUNELDBDQUFjLEdBQWQsVUFBZSxTQUFTLEVBQUMsT0FBTztvQkFDNUIsRUFBRSxDQUFDLENBQUMsU0FBUyxJQUFJLENBQUMsSUFBSSxTQUFTLElBQUksQ0FBQyxDQUFDLENBQ3JDLENBQUM7d0JBQ0csT0FBTyxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7d0JBQzdCLE9BQU8sQ0FBQyxZQUFZLEdBQUcsS0FBSyxDQUFDO3dCQUM3QixJQUFJLENBQUMsb0JBQW9CLEVBQUUsQ0FBQztvQkFDaEMsQ0FBQztvQkFBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ3hCLE9BQU8sQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDO3dCQUM1QixPQUFPLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztvQkFDbEMsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixPQUFPLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQzt3QkFDOUIsT0FBTyxDQUFDLFlBQVksR0FBRyxLQUFLLENBQUM7b0JBQ2pDLENBQUM7Z0JBQ0wsQ0FBQztnQkFDRCwwQ0FBYyxHQUFkO29CQUFBLGlCQTJIQztvQkExSEcsc0hBQXNIO29CQUN0SCxJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztvQkFFeEIsSUFBSSxDQUFDLFFBQVEsR0FBRyxDQUFDLENBQUM7b0JBQ2xCLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO29CQUN0QixJQUFJLGNBQWMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQTtvQkFDbEQsSUFBSSxlQUFlLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUM7b0JBRWxELElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDO29CQUN4QyxJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQztvQkFDNUMsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUM7b0JBQzFDLElBQUksWUFBWSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDO29CQUNsRCxJQUFJLGNBQWMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQztvQkFDL0MsSUFBSSxlQUFlLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLENBQUM7b0JBQ3RELElBQUksU0FBUyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDO29CQUMxQyxJQUFJLGFBQWEsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQztvQkFDbEQsSUFBSSxDQUFDLFVBQVUsR0FBRyxFQUFFLENBQUM7b0JBQ3JCLElBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDO29CQUM1QixJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBRyxNQUFNLENBQUM7b0JBQ3BDLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxHQUFHLFFBQVEsQ0FBQztvQkFFeEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEdBQUcsU0FBUyxDQUFDO29CQUN0QyxJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsR0FBRyxlQUFlLENBQUM7b0JBRWxELElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLFlBQVksQ0FBQztvQkFDOUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsY0FBYyxDQUFDO29CQUNoRCxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsR0FBRyxjQUFjLENBQUM7b0JBQy9DLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxHQUFHLFNBQVMsQ0FBQztvQkFDdEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEdBQUcsYUFBYSxDQUFDO29CQUM5QyxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUM7b0JBQ2xDLElBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxHQUFHLEVBQUUsQ0FBQztvQkFDckMsdUhBQXVIO29CQUN2SCxJQUFJLE1BQU0sR0FBRzt3QkFDVCxNQUFNLEVBQUUsQ0FBQyxFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsV0FBVyxFQUFFLFNBQVMsRUFBRSxDQUFDLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRTt3QkFDbEYsUUFBUSxFQUFFLEVBQUUsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLGNBQWMsRUFBRSxFQUFFLEVBQUUsY0FBYyxFQUFFLEVBQUUsRUFBRSxpQkFBaUIsRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRSxhQUFhLEVBQUUsSUFBSSxDQUFDLFdBQVc7d0JBQ3JJLFdBQVcsRUFBRSxFQUFFLEVBQUUsY0FBYyxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLGNBQWMsRUFBRSxFQUFFLEVBQUUsUUFBUSxFQUFFLEtBQUssRUFBRSxZQUFZLEVBQUUsTUFBTTt3QkFDaEgsT0FBTyxFQUFFLE1BQU0sRUFBRSxTQUFTLEVBQUUsT0FBTyxFQUFFLE9BQU8sRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLE9BQU8sRUFBRSxZQUFZLEVBQUUsS0FBSyxFQUFFLFlBQVksRUFBRSxLQUFLLEVBQUUsYUFBYSxFQUFFLEtBQUs7cUJBQzNJLENBQUM7b0JBRUYsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUMxQyxpQ0FBaUM7b0JBRWpDLGdEQUFnRDtvQkFDaEQsSUFBSSxDQUFDLGVBQWUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDdEYsWUFBWTt3QkFDWixJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO2dDQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQzVCLE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEtBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDOzRCQUM5RCxLQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQzt3QkFFN0QsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFDSCw4QkFBOEI7b0JBRTlCLElBQUksQ0FBQyxlQUFlLENBQUMsV0FBVyxFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDN0MsV0FBVzt3QkFDWCxJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO2dDQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQzVCLE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLFdBQVc7NEJBQ1gsS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7NEJBQ3BELEtBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO3dCQUV6RCxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUVILElBQUksQ0FBQyxlQUFlLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUNsRCxZQUFZO3dCQUNaLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7NEJBQ2hELEtBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO3dCQUVyRCxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO2dCQUNQLENBQUM7Z0JBQ0QsMkNBQWUsR0FBZixVQUFnQixNQUFNO29CQUF0QixpQkF5SkM7b0JBeEpFLFlBQVk7b0JBQ1gsK0JBQStCO29CQUMvQixHQUFHO29CQUNILElBQUksT0FBTyxHQUFHLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQztvQkFDckMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxzQkFBc0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUMvRCxXQUFXO3dCQUNYLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzt3QkFFL0MsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFFSCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLFNBQVM7MkJBQzlHLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksU0FBUzsyQkFDakgsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsTUFBTSxHQUFHLENBQUM7MkJBQ3ZDLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLElBQUksU0FBUzsyQkFDMUgsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxTQUFTOzJCQUNuSCxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxJQUFJLFNBQVM7MkJBQzdILElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLElBQUksU0FBUzsyQkFDOUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsSUFBSSxTQUM1RyxDQUFDLENBQUMsQ0FBQzt3QkFFQyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQzt3QkFDNUQsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDO3dCQUNwRCxJQUFJLGFBQWEsR0FBRyxJQUFJLENBQUM7d0JBQ3pCLEVBQUUsQ0FBQyxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDOzRCQUNoQixhQUFhLEdBQUcsS0FBSyxDQUFDO3dCQUMxQixDQUFDO3dCQUNELHlDQUF5Qzt3QkFFekMsR0FBRyxDQUFDLENBQUMsSUFBSSxHQUFHLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsQ0FDN0MsQ0FBQzs0QkFDRyxJQUFJLFlBQVksR0FBRyxlQUFlLEdBQUcsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFLEdBQUcscUNBQXFDLENBQUM7NEJBQzVHLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsRUFBRSxZQUFZLENBQUMsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDO2dDQUNsRixhQUFhLEdBQUcsS0FBSyxDQUFDO2dDQUN0QixLQUFLLENBQUM7NEJBQ1YsQ0FBQzt3QkFDTCxDQUFDO3dCQUVELEdBQUcsQ0FBQyxDQUFDLElBQUksR0FBRyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxDQUFDLENBQ2hELENBQUM7NEJBQ0csSUFBSSxZQUFZLEdBQUcsZUFBZSxHQUFHLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRSxHQUFHLGdDQUFnQyxDQUFDOzRCQUN2RyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLEVBQUUsWUFBWSxFQUFDLEdBQUcsQ0FBQyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUM7Z0NBQ2hHLGFBQWEsR0FBRyxLQUFLLENBQUM7Z0NBQ3RCLEtBQUssQ0FBQzs0QkFDVixDQUFDO3dCQUNMLENBQUM7d0JBR0QsRUFBRSxDQUFDLENBQUMsYUFBYSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQ3hCLFdBQVc7NEJBQ1gsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7NEJBQzVDLHFCQUFxQjs0QkFDckIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTtnQ0FDckQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQztnQ0FDdEIsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7Z0NBQ3RDLEtBQUksQ0FBQyxZQUFZLEdBQUcsRUFBRSxDQUFDO2dDQUV2QixFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7b0NBQzNCLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUM7b0NBQ3ZCLEtBQUksQ0FBQyxRQUFRLEdBQUcsYUFBYSxDQUFDO2dDQUNsQyxDQUFDO2dDQUNELElBQUksQ0FBQyxDQUFDO29DQUNGLE9BQU8sQ0FBQyxLQUFLLENBQUM7d0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO3dDQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7d0NBQzVCLE9BQU8sRUFBRTs0Q0FDTCxFQUFFLEVBQUU7Z0RBQ0EsY0FBYztnREFDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7NkNBQzVCO3lDQUNKO3FDQUNKLENBQUMsQ0FBQztvQ0FDSCxJQUFJLEtBQUssR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDO29DQUMvQyxJQUFJLEtBQUssR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUMsQ0FBQztvQ0FDbkQsS0FBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQyxLQUFLLEdBQUcsR0FBRyxHQUFHLEtBQUssR0FBRyxzQkFBc0IsQ0FBQyxDQUFDO29DQUNqRixLQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxDQUFDLEtBQUssR0FBRyxHQUFHLEdBQUcsS0FBSyxHQUFHLCtCQUErQixDQUFDLENBQUM7b0NBQzFGLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLENBQUMsS0FBSyxHQUFHLEdBQUcsR0FBRyxLQUFLLEdBQUMsd0JBQXdCLENBQUMsQ0FBQztvQ0FDakYsRUFBRSxDQUFDLENBQUMsTUFBTSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7d0NBQ2pCLFFBQVEsQ0FBQyxRQUFRLEdBQUcsS0FBSSxDQUFDLE9BQU8sR0FBRyxnQkFBZ0IsR0FBRyxLQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBRyxJQUFJLEdBQUcsS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUM7b0NBQ3pILENBQUM7b0NBQ0QsSUFBSSxDQUFDLENBQUM7d0NBQ0YsS0FBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO3dDQUN0QixLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQzt3Q0FDekQsS0FBSSxDQUFDLE1BQU0sR0FBRyxRQUFRLENBQUMsVUFBVSxDQUFDO29DQUN0QyxDQUFDO2dDQUNMLENBQUM7NEJBRUwsQ0FBQyxFQUNHLFVBQUEsS0FBSyxJQUFHLE9BQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBbEIsQ0FBa0IsRUFDMUIsY0FBTSxPQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsc0JBQXNCLENBQUMsRUFBbkMsQ0FBbUMsQ0FDNUMsQ0FBQzt3QkFFTixDQUFDO29CQUVMLENBQUM7b0JBQ0QsSUFBSSxDQUFDLENBQUM7d0JBQ0YsSUFBSSxHQUFHLEdBQUcsRUFBRSxDQUFDO3dCQUNiLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQzs0QkFDcEgsR0FBRyxJQUFJLDZCQUE2QixDQUFDO3dCQUN6QyxDQUFDO3dCQUNELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQzs0QkFDcEgsR0FBRyxJQUFJLDRCQUE0QixDQUFDO3dCQUN4QyxDQUFDO3dCQUNELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQzs0QkFDN0gsR0FBRyxJQUFJLCtCQUErQixDQUFDO3dCQUMzQyxDQUFDO3dCQUNELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQzs0QkFDcEgsR0FBRyxJQUFJLGlDQUFpQyxDQUFDO3dCQUM3QyxDQUFDO3dCQUNELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQzs0QkFDaEksR0FBRyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDOzRCQUN0QyxHQUFHLElBQUksa0NBQWtDLENBQUM7d0JBQzlDLENBQUM7d0JBQ0QsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDOzRCQUNqSCxHQUFHLElBQUkseUNBQXlDLENBQUM7d0JBQ3JELENBQUM7d0JBQ0QsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDOzRCQUNqSCxHQUFHLElBQUksMkJBQTJCLENBQUM7d0JBQ3ZDLENBQUM7d0JBQ0QsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7NEJBQzNDLEdBQUcsSUFBSSw4Q0FBOEMsQ0FBQzt3QkFDMUQsQ0FBQzt3QkFDRCxPQUFPLENBQUMsS0FBSyxDQUFDOzRCQUNWLE9BQU8sRUFBRSxHQUFHOzRCQUNaLFNBQVMsRUFBRSxJQUFJLENBQUMsWUFBWTs0QkFDNUIsT0FBTyxFQUFFO2dDQUNMLEVBQUUsRUFBRTtvQ0FDQSxjQUFjO29DQUNkLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUztpQ0FDNUI7NkJBQ0o7eUJBQ0osQ0FBQyxDQUFDO29CQUNQLENBQUM7b0JBQ0wsR0FBRztnQkFDSCxDQUFDO2dCQUVELG9DQUFRLEdBQVIsVUFBUyxRQUFRO29CQUNiLFdBQVc7b0JBQ1gsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQzFDLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQzt3QkFDZCxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxFQUFFOzRCQUN0QyxFQUFFLENBQUMsQ0FBQyxJQUFJLElBQUksUUFBUSxDQUFDLENBQUMsQ0FBQztnQ0FDbkIsTUFBTSxDQUFDLEtBQUssQ0FBQTs0QkFDaEIsQ0FBQzs0QkFDRCxLQUFLLEdBQUcsS0FBSyxHQUFHLENBQUMsQ0FBQzt3QkFFdEIsQ0FBQyxDQUFDLENBQUM7d0JBQ0gsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQzt3QkFDOUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO29CQUNyQixDQUFDO2dCQUNMLENBQUM7Z0JBQ0QscUNBQVMsR0FBVDtvQkFBQSxpQkErQ0M7b0JBOUNHLElBQUksTUFBTSxHQUFHLENBQUMsQ0FBQztvQkFDZixXQUFXO29CQUNYLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEVBQUU7d0JBQ3RDLE1BQU0sSUFBSSxVQUFVLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUV0QyxDQUFDLENBQUMsQ0FBQztvQkFDSCxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssR0FBRyxNQUFNLENBQUM7b0JBRS9CLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDO29CQUN0QyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUNuQixFQUFFLENBQUMsQ0FBQyxLQUFLLElBQUksSUFBSSxJQUFJLEtBQUssSUFBSSxFQUFFLENBQUM7d0JBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUM7b0JBQzNELElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDO29CQUN2QyxlQUFlO29CQUNmLElBQUksQ0FBQyxlQUFlLENBQUMsZUFBZSxDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFFeEUsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBRUYseUJBQXlCOzRCQUN6QixLQUFJLENBQUMsVUFBVSxDQUFDLGtCQUFrQixHQUFHLFVBQVUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEdBQUcsTUFBTSxDQUFDOzRCQUN4RSxLQUFJLENBQUMsVUFBVSxDQUFDLGtCQUFrQixHQUFHLEtBQUksQ0FBQyxVQUFVLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDOzRCQUVuRixNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxFQUFFO2dDQUN0QyxvQ0FBb0M7Z0NBQ3BDLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxVQUFVLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLFVBQVUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7Z0NBQy9FLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxJQUFJLENBQUMsbUJBQW1CLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDOzRCQUNuRSxDQUFDLENBQUMsQ0FBQzt3QkFDUCxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO2dCQUVQLENBQUM7Z0JBQ0QsNENBQWdCLEdBQWhCO29CQUFBLGlCQW1EQztvQkFqREcsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzt3QkFDekMsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUM7d0JBQy9DLElBQUksWUFBWSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDO3dCQUNqRCxJQUFJLFdBQVcsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQzt3QkFDN0MsSUFBSSxlQUFlLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUM7d0JBQ3JELElBQUksY0FBYyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDO3dCQUNoRCxJQUFJLENBQUMsZUFBZSxDQUFDLGdCQUFnQixDQUFDLFdBQVcsRUFBRSxlQUFlLEVBQUUsU0FBUyxFQUFFLFlBQVksRUFBRSxjQUFjLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFROzRCQUM1SCxZQUFZOzRCQUNYLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDOzRCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUM7Z0NBQzVCLElBQUksQ0FBQyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztnQ0FDakQsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLE9BQU8sQ0FBQyxDQUFDLENBQUM7b0NBQ3RELElBQUksU0FBUyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxRQUFRLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDO29DQUN2RixJQUFJLFlBQVksR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxPQUFPLEVBQUUsb0RBQW9ELENBQUMsQ0FBQztnQ0FHN0csQ0FBQztnQ0FDRCxJQUFJLENBQUMsQ0FBQztvQ0FDRixPQUFPLENBQUMsS0FBSyxDQUFDO3dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsSUFBSTt3Q0FDdEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO3dDQUM1QixPQUFPLEVBQUU7NENBQ0wsRUFBRSxFQUFFO2dEQUNBLGNBQWM7Z0RBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTOzZDQUM1Qjt5Q0FDSjtxQ0FDSixDQUFDLENBQUM7Z0NBQ1AsQ0FBQzs0QkFDTCxDQUFDOzRCQUFDLElBQUksQ0FBQyxDQUFDO2dDQUVKLE9BQU8sQ0FBQyxLQUFLLENBQUM7b0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO29DQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7b0NBQzVCLE9BQU8sRUFBRTt3Q0FDTCxFQUFFLEVBQUU7NENBQ0EsY0FBYzs0Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7eUNBQzVCO3FDQUNKO2lDQUNKLENBQUMsQ0FBQzs0QkFDUCxDQUFDO3dCQUVMLENBQUMsRUFBRSxVQUFBLEtBQUs7NEJBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQzt3QkFDdkIsQ0FBQyxFQUFFOzRCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7d0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUNQLENBQUM7Z0JBQ0wsQ0FBQztnQkFFRCxvQ0FBUSxHQUFSLFVBQVMsUUFBUTtvQkFDYixJQUFJLElBQUksR0FBRyxFQUFFLENBQUM7b0JBQ2QsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO29CQUNoQixRQUFRLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUM7b0JBQ3RDLElBQUksR0FBRyxRQUFRLENBQUM7b0JBRWhCLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUN0QyxJQUFJLFFBQVEsR0FBRyxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUNuRixRQUFRLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDO29CQUN2QyxJQUFJLE1BQU0sR0FBRyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDO29CQUNuRCxxQ0FBcUM7b0JBQ3JDLDRCQUE0QjtvQkFDNUIsSUFBSSxNQUFNLEdBQUcsRUFBRSxNQUFNLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsUUFBUSxFQUFFLFNBQVMsRUFBRSxRQUFRLENBQUMsU0FBUyxFQUFFLFNBQVMsRUFBRSxRQUFRLENBQUMsU0FBUyxFQUFFLFNBQVMsRUFBRSxRQUFRLENBQUMsU0FBUyxFQUFFLFFBQVEsRUFBRSxRQUFRLENBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxRQUFRLENBQUMsSUFBSSxFQUFFLGNBQWMsRUFBRSxRQUFRLENBQUMsY0FBYyxFQUFFLGNBQWMsRUFBRSxRQUFRLENBQUMsY0FBYyxFQUFFLGlCQUFpQixFQUFFLFFBQVEsQ0FBQyxpQkFBaUIsRUFBRSxTQUFTLEVBQUUsUUFBUSxDQUFDLFNBQVMsRUFBRSxhQUFhLEVBQUUsUUFBUSxDQUFDLGFBQWEsRUFBRSxXQUFXLEVBQUUsUUFBUSxDQUFDLFdBQVcsRUFBRSxjQUFjLEVBQUUsUUFBUSxDQUFDLGNBQWMsRUFBRSxLQUFLLEVBQUUsUUFBUSxDQUFDLEtBQUssRUFBRSxjQUFjLEVBQUUsUUFBUSxDQUFDLGNBQWMsRUFBRyxDQUFDO29CQUNqaUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUMxQyxJQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7b0JBQ2QsSUFBSSxTQUFTLEdBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDO29CQUNsRCxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxFQUFFO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxLQUFLLElBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOzRCQUUzQixJQUFJLENBQUMsU0FBUyxHQUFHLE1BQU0sQ0FBQzt3QkFDNUIsQ0FBQzt3QkFDRyxLQUFLLEVBQUUsQ0FBQztvQkFDaEIsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO2dCQUNyQixDQUFDO2dCQUVELDRDQUFnQixHQUFoQixVQUFpQixZQUFZLEVBQUUsR0FBRztvQkFDOUIsV0FBVztvQkFDWCxJQUFJLFdBQVcsR0FBRyxJQUFJLENBQUM7b0JBQ3ZCLEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxTQUFTLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzt3QkFDL0IsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxTQUFTLEVBQUUsWUFBWSxFQUFFLElBQUksQ0FBQyxDQUFDLE9BQU8sRUFBRSxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUM7NEJBQ3hFLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBRSxPQUFPLEVBQUUseUJBQXlCLEVBQUUsQ0FBQyxDQUFDOzRCQUN0RCxNQUFNLENBQUMsS0FBSyxDQUFDO3dCQUNqQixDQUFDO29CQUNMLENBQUM7b0JBQ0QsRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLGFBQWEsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO3dCQUNuQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLGFBQWEsRUFBRSxZQUFZLEVBQUUsSUFBSSxDQUFDLENBQUMsT0FBTyxFQUFFLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQzs0QkFDNUUsT0FBTyxDQUFDLEtBQUssQ0FBQyxFQUFFLE9BQU8sRUFBRSw2QkFBNkIsRUFBRSxDQUFDLENBQUM7NEJBQzFELE1BQU0sQ0FBQyxLQUFLLENBQUM7d0JBQ2pCLENBQUM7b0JBQ0wsQ0FBQztvQkFFRyxlQUFlO29CQUNmLEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxNQUFNLElBQUksSUFBSSxJQUFJLFlBQVksQ0FBQyxNQUFNLElBQUksRUFBRSxJQUFJLFlBQVksQ0FBQyxNQUFNLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQzt3QkFDL0YsV0FBVyxHQUFHLEtBQUssQ0FBQzt3QkFDcEIsR0FBRyxJQUFJLHlCQUF5QixDQUFDO29CQUNyQyxDQUFDO29CQUNELEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxTQUFTLElBQUksSUFBSSxJQUFJLFlBQVksQ0FBQyxTQUFTLElBQUksRUFBRSxJQUFJLFlBQVksQ0FBQyxTQUFTLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQzt3QkFDeEcsV0FBVyxHQUFHLEtBQUssQ0FBQzt3QkFDcEIsR0FBRyxJQUFJLDJCQUEyQixDQUFDO29CQUN2QyxDQUFDO29CQUNELEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxTQUFTLElBQUksSUFBSSxJQUFJLFlBQVksQ0FBQyxTQUFTLElBQUksRUFBRSxJQUFJLFlBQVksQ0FBQyxTQUFTLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQzt3QkFDeEcsV0FBVyxHQUFHLEtBQUssQ0FBQzt3QkFDcEIsR0FBRyxJQUFJLDJCQUEyQixDQUFDO29CQUN2QyxDQUFDO29CQUNELEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxjQUFjLElBQUksSUFBSSxJQUFJLFlBQVksQ0FBQyxjQUFjLElBQUksRUFBRSxJQUFJLFlBQVksQ0FBQyxjQUFjLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQzt3QkFDdkgsV0FBVyxHQUFHLEtBQUssQ0FBQzt3QkFDcEIsR0FBRyxJQUFJLHdCQUF3QixDQUFDO29CQUNwQyxDQUFDO29CQUNELEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxTQUFTLElBQUksSUFBSSxJQUFJLFlBQVksQ0FBQyxTQUFTLElBQUksRUFBRSxJQUFJLFlBQVksQ0FBQyxTQUFTLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQzt3QkFDeEcsV0FBVyxHQUFHLEtBQUssQ0FBQzt3QkFDcEIsR0FBRyxJQUFJLDJCQUEyQixDQUFDO29CQUN2QyxDQUFDO29CQUNELEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxTQUFTLElBQUksQ0FBQyxDQUFDLENBQ2hDLENBQUM7d0JBQ0csRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLFNBQVMsSUFBSSxJQUFJLElBQUksWUFBWSxDQUFDLFNBQVMsSUFBSSxFQUFFLElBQUksWUFBWSxDQUFDLFNBQVMsSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDOzRCQUN4RyxXQUFXLEdBQUcsS0FBSyxDQUFDOzRCQUNwQixHQUFHLElBQUksNkJBQTZCLENBQUM7d0JBQ3pDLENBQUM7d0JBQ0QsRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLFFBQVEsSUFBSSxJQUFJLElBQUksWUFBWSxDQUFDLFFBQVEsSUFBSSxFQUFFLElBQUksWUFBWSxDQUFDLFFBQVEsSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDOzRCQUNyRyxXQUFXLEdBQUcsS0FBSyxDQUFDOzRCQUNwQixHQUFHLElBQUksNkJBQTZCLENBQUM7d0JBQ3pDLENBQUM7d0JBQ0QsRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLElBQUksSUFBSSxJQUFJLElBQUksWUFBWSxDQUFDLElBQUksSUFBSSxFQUFFLElBQUksWUFBWSxDQUFDLElBQUksSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDOzRCQUN6RixXQUFXLEdBQUcsS0FBSyxDQUFDOzRCQUNwQixHQUFHLElBQUksdUJBQXVCLENBQUM7d0JBQ25DLENBQUM7b0JBQ0wsQ0FBQztvQkFDRCxFQUFFLENBQUMsQ0FBQyxZQUFZLENBQUMsU0FBUyxJQUFJLENBQUMsQ0FBQyxDQUNoQyxDQUFDO3dCQUNHLEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxjQUFjLElBQUksSUFBSSxJQUFJLFlBQVksQ0FBQyxjQUFjLElBQUksRUFBRSxJQUFJLFlBQVksQ0FBQyxjQUFjLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQzs0QkFDdkgsV0FBVyxHQUFHLEtBQUssQ0FBQzs0QkFDcEIsR0FBRyxJQUFJLDZCQUE2QixDQUFDO3dCQUN6QyxDQUFDO29CQUNMLENBQUM7b0JBRUQsRUFBRSxDQUFDLENBQUMsV0FBVyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUM7d0JBQ3ZCLE9BQU8sQ0FBQyxLQUFLLENBQUM7NEJBQ1YsT0FBTyxFQUFFLEdBQUc7NEJBQ1osU0FBUyxFQUFFLElBQUksQ0FBQyxZQUFZOzRCQUM1QixPQUFPLEVBQUU7Z0NBQ0wsRUFBRSxFQUFFO29DQUNBLGNBQWM7b0NBQ2QsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO2lDQUM1Qjs2QkFDSjt5QkFDSixDQUFDLENBQUM7b0JBQ1AsQ0FBQztvQkFDRCxNQUFNLENBQUMsV0FBVyxDQUFDO2dCQUUzQixDQUFDO2dCQUVELG1EQUF1QixHQUF2QixVQUF3QixZQUFZLEVBQUUsR0FBRyxFQUFDLEtBQUs7b0JBQzNDLFdBQVc7b0JBQ1gsSUFBSSxXQUFXLEdBQUcsSUFBSSxDQUFDO29CQUV2QixlQUFlO29CQUNmLEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxTQUFTLElBQUksSUFBSSxJQUFJLFlBQVksQ0FBQyxTQUFTLElBQUksRUFBRSxJQUFJLFlBQVksQ0FBQyxTQUFTLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQzt3QkFDeEcsV0FBVyxHQUFHLEtBQUssQ0FBQzt3QkFDcEIsR0FBRyxJQUFJLDZCQUE2QixDQUFDO29CQUN6QyxDQUFDO29CQUNELEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxXQUFXLElBQUksSUFBSSxJQUFJLFlBQVksQ0FBQyxXQUFXLElBQUksRUFBRSxJQUFJLFlBQVksQ0FBQyxXQUFXLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQzt3QkFDOUcsV0FBVyxHQUFHLEtBQUssQ0FBQzt3QkFDcEIsR0FBRyxJQUFJLCtCQUErQixDQUFDO29CQUMzQyxDQUFDO29CQUNELEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxLQUFLLElBQUksSUFBSSxJQUFJLFlBQVksQ0FBQyxLQUFLLElBQUksRUFBRSxJQUFJLFlBQVksQ0FBQyxLQUFLLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQzt3QkFDNUYsV0FBVyxHQUFHLEtBQUssQ0FBQzt3QkFDcEIsR0FBRyxJQUFJLHdCQUF3QixDQUFDO29CQUNwQyxDQUFDO29CQUNELEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxHQUFHLElBQUksSUFBSSxJQUFJLFlBQVksQ0FBQyxHQUFHLElBQUksRUFBRSxJQUFJLFlBQVksQ0FBQyxHQUFHLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQzt3QkFDdEYsV0FBVyxHQUFHLEtBQUssQ0FBQzt3QkFDcEIsR0FBRyxJQUFJLDJCQUEyQixDQUFDO29CQUN2QyxDQUFDO29CQUdELEVBQUUsQ0FBQyxDQUFDLFdBQVcsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDO3dCQUN2QixPQUFPLENBQUMsS0FBSyxDQUFDOzRCQUNWLE9BQU8sRUFBRSxHQUFHOzRCQUNaLFNBQVMsRUFBRSxJQUFJLENBQUMsWUFBWTs0QkFDNUIsT0FBTyxFQUFFO2dDQUNMLEVBQUUsRUFBRTtvQ0FDQSxjQUFjO29DQUNkLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUztpQ0FDNUI7NkJBQ0o7eUJBQ0osQ0FBQyxDQUFDO29CQUNQLENBQUM7b0JBQ0QsTUFBTSxDQUFDLFdBQVcsQ0FBQztnQkFFdkIsQ0FBQztnQkFHRCwwQ0FBYyxHQUFkLFVBQWUsWUFBWTtvQkFDdkIseURBQXlEO29CQUN6RCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDMUMsSUFBSSxLQUFLLEdBQUcsRUFBRSxDQUFDO3dCQUNmLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDcEIsS0FBSyxHQUFHLE1BQU0sQ0FBQzt3QkFDbkIsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFLLEdBQUcsTUFBTSxDQUFDO3dCQUNuQixDQUFDO3dCQUNELElBQUksUUFBUSxHQUFHOzRCQUNYLE1BQU0sRUFBRSxDQUFDLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxXQUFXLEVBQUUsU0FBUyxFQUFFLEdBQUcsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFLFNBQVMsRUFBRSxFQUFFOzRCQUNwRixRQUFRLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsY0FBYyxFQUFFLEVBQUUsRUFBRSxjQUFjLEVBQUUsRUFBRSxFQUFFLGlCQUFpQixFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFLGFBQWEsRUFBRSxJQUFJLENBQUMsV0FBVzs0QkFDckksV0FBVyxFQUFFLEVBQUUsRUFBRSxjQUFjLEVBQUUsRUFBRSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsY0FBYyxFQUFFLEVBQUUsRUFBRSxRQUFRLEVBQUUsS0FBSyxFQUFFLFlBQVksRUFBRSxLQUFLOzRCQUMzRyxPQUFPLEVBQUUsTUFBTSxFQUFFLFNBQVMsRUFBRSxPQUFPLEVBQUUsT0FBTyxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsT0FBTyxFQUFFLFlBQVksRUFBRSxLQUFLLEVBQUUsWUFBWSxFQUFFLEtBQUssRUFBRSxhQUFhLEVBQUUsS0FBSzt5QkFDM0ksQ0FBQzt3QkFDRixZQUFZLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUM7d0JBQzNDLFlBQVk7d0JBQ1gsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUM1QyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7b0JBQ3JCLENBQUM7Z0JBQ0wsQ0FBQztnQkFDRCw2Q0FBaUIsR0FBakI7b0JBQ0ksSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7b0JBQzlDLElBQUksV0FBVyxHQUFHLElBQUksQ0FBQztvQkFDdkIsSUFBSSxHQUFHLEdBQUcsRUFBRSxDQUFDO29CQUNkLFlBQVk7b0JBQ1gsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUN4QixFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUM7NEJBQ2pELFdBQVcsR0FBRyxLQUFLLENBQUM7NEJBQ3BCLEdBQUcsR0FBRywrQkFBK0IsQ0FBQzt3QkFDMUMsQ0FBQzt3QkFDRCxJQUFJLFVBQVUsR0FBRyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO3dCQUNwRCxFQUFFLENBQUMsQ0FBQyxVQUFVLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7NEJBQ3pCLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQztnQ0FDbEQsV0FBVyxHQUFHLEtBQUssQ0FBQztnQ0FDcEIsR0FBRyxHQUFHLDRCQUE0QixDQUFDOzRCQUN2QyxDQUFDO3dCQUNMLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsV0FBVyxHQUFHLEtBQUssQ0FBQzs0QkFDcEIsR0FBRyxHQUFHLGtGQUFrRixDQUFDO3dCQUM3RixDQUFDO29CQUNMLENBQUM7b0JBQ0QsSUFBSSxDQUFDLENBQUM7d0JBQ0YsV0FBVyxHQUFHLEtBQUssQ0FBQzt3QkFDcEIsR0FBRyxHQUFHLGtGQUFrRixDQUFDO29CQUM3RixDQUFDO29CQUNELEVBQUUsQ0FBQyxDQUFDLFdBQVcsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDO3dCQUN2QixPQUFPLENBQUMsS0FBSyxDQUFDOzRCQUNWLE9BQU8sRUFBRSxHQUFHOzRCQUNaLFNBQVMsRUFBRSxJQUFJLENBQUMsWUFBWTs0QkFDNUIsT0FBTyxFQUFFO2dDQUNMLEVBQUUsRUFBRTtvQ0FDQSxjQUFjO29DQUNkLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUztpQ0FDNUI7NkJBQ0o7eUJBQ0osQ0FBQyxDQUFDO29CQUNQLENBQUM7b0JBQ0QsTUFBTSxDQUFDLFdBQVcsQ0FBQztnQkFDdkIsQ0FBQztnQkFDRCwyQ0FBZSxHQUFmLFVBQWdCLE9BQU87b0JBR25CLEVBQUUsQ0FBQyxDQUFDLE9BQU8sSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO3dCQUNoQixJQUFJLENBQUMsU0FBUyxHQUFHLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQzt3QkFDNUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQzs0QkFDOUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEdBQUcsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDOzRCQUNoRCxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUM7NEJBQ3RELElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxHQUFHLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQzs0QkFDbEQsSUFBSSxVQUFVLEdBQUcsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQzs0QkFDcEQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLEdBQUcsVUFBVSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQzs0QkFDcEUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDLEdBQUcsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDOzRCQUN4RyxJQUFJLENBQUMsU0FBUyxHQUFHLEVBQUUsQ0FBQzs0QkFDcEIsTUFBTSxDQUFDLGlCQUFpQixDQUFDLENBQUMsVUFBVSxFQUFFLENBQUM7NEJBQ3ZDLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQzt3QkFDekIsQ0FBQztvQkFDTCxDQUFDO2dCQUNMLENBQUM7Z0JBQ0Qsd0NBQVksR0FBWixVQUFhLE9BQU87b0JBQ2hCLFlBQVksQ0FBQyxPQUFPLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLENBQUM7b0JBQ3JFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsV0FBVyxFQUFFLE9BQU8sQ0FBQyxLQUFLLEVBQUMsRUFBRSxDQUFDLENBQUM7b0JBQy9ELElBQUksS0FBSyxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUM7b0JBQy9DLElBQUksS0FBSyxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsS0FBSyxHQUFHLFFBQVEsQ0FBQyxDQUFDO29CQUNuRCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7d0JBQzFELElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO3dCQUU1QyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxHQUFHLEdBQUcsS0FBSyxHQUFDLHNCQUFzQixFQUFFLEtBQUssRUFBRSxFQUFFLENBQUMsQ0FBQztvQkFDM0YsQ0FBQztvQkFFRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxHQUFHLEdBQUcsS0FBSyxHQUFDLCtCQUErQixFQUFFLElBQUksQ0FBQyxjQUFjLEVBQUUsRUFBRSxDQUFDLENBQUM7b0JBQzlHLFFBQVEsQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLE9BQU8sR0FBRyxpQkFBaUIsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBQyxnQkFBZ0IsQ0FBQztnQkFDdkcsQ0FBQztnQkFFRCwwQ0FBYyxHQUFkLFVBQWUsT0FBTztvQkFFbEIsRUFBRSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsU0FBUyxJQUFJLFNBQVMsSUFBSSxPQUFPLENBQUMsU0FBUyxJQUFJLElBQUksSUFBSSxPQUFPLENBQUMsU0FBUyxJQUFJLEVBQUUsQ0FBQzsyQkFDckYsQ0FBQyxPQUFPLENBQUMsV0FBVyxJQUFJLFNBQVMsSUFBSSxPQUFPLENBQUMsV0FBVyxJQUFJLElBQUksSUFBSSxPQUFPLENBQUMsV0FBVyxJQUFJLEVBQUUsQ0FBQzsyQkFDOUYsQ0FBQyxPQUFPLENBQUMsS0FBSyxJQUFJLFNBQVMsSUFBSSxPQUFPLENBQUMsS0FBSyxJQUFJLElBQUksSUFBSSxPQUFPLENBQUMsS0FBSyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDbEYsSUFBSSxDQUFDLFNBQVMsR0FBRyxFQUFFLENBQUM7b0JBRXhCLENBQUM7b0JBQ0QsSUFBSSxDQUFDLENBQUM7d0JBQ0YsSUFBSSxDQUFDLFNBQVMsR0FBRyxPQUFPLENBQUMsU0FBUyxHQUFHLEtBQUssR0FBRyxPQUFPLENBQUMsV0FBVyxHQUFHLEtBQUssR0FBRyxPQUFPLENBQUMsS0FBSyxDQUFDO29CQUM3RixDQUFDO29CQUNELElBQUksQ0FBQyxVQUFVLEdBQUcsT0FBTyxDQUFDO29CQUUxQixNQUFNLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxTQUFTLEVBQUUsQ0FBQztnQkFDMUMsQ0FBQztnQkFDRCwwQ0FBYyxHQUFkO29CQUNJLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO29CQUN2QixZQUFZLENBQUMsT0FBTyxDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxDQUFDO29CQUNyRSxJQUFJLEtBQUssR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDO29CQUMvQyxJQUFJLEtBQUssR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUMsQ0FBQztvQkFDbkQsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLFVBQVUsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO3dCQUMxRCxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQzt3QkFFNUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxHQUFHLEtBQUssR0FBQyxzQkFBc0IsRUFBRSxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUM7b0JBQzNGLENBQUM7b0JBQ0QsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxHQUFHLEtBQUssR0FBQywrQkFBK0IsRUFBRSxJQUFJLENBQUMsY0FBYyxFQUFFLEVBQUUsQ0FBQyxDQUFDO29CQUM5RyxRQUFRLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxPQUFPLEdBQUcsa0NBQWtDLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUM7b0JBQ25HLHdKQUF3SjtvQkFDeEoseUNBQXlDO2dCQUU3QyxDQUFDO2dCQUNELHFDQUFTLEdBQVQ7b0JBRUksV0FBVztvQkFDWCxpQ0FBaUM7b0JBQzdCLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxTQUFTLEVBQUUsQ0FBQztvQkFDckMsR0FBRztvQkFDSCxRQUFRO29CQUNSLCtEQUErRDtvQkFDL0QsK0hBQStIO29CQUUvSCw4Q0FBOEM7b0JBQzlDLHlEQUF5RDtvQkFDekQsNEJBQTRCO29CQUM1QixHQUFHO2dCQUNQLENBQUM7Z0JBQ0QseUNBQWEsR0FBYjtvQkFDSSxNQUFNLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxTQUFTLEVBQUUsQ0FBQztnQkFDekMsQ0FBQztnQkFDRCxzQ0FBVSxHQUFWLFVBQVcsS0FBSztvQkFDWixJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDO29CQUMxQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDO2dCQUNqRCxDQUFDO2dCQUNELCtDQUFtQixHQUFuQixVQUFvQixLQUFLO29CQUN0QixZQUFZO29CQUNYLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQztvQkFDOUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQztnQkFDakQsQ0FBQztnQkFDRCw2Q0FBaUIsR0FBakI7b0JBQUEsaUJBd0NDO29CQXZDRyxJQUFJLE1BQU0sR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQztvQkFDeEMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGtCQUFrQixDQUFDLE1BQU0sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQzNELFdBQVc7d0JBQ1gsSUFBSSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtnQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUM1QixPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixRQUFRLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzs0QkFDekIsS0FBSSxDQUFDLFVBQVUsR0FBRyxRQUFRLENBQUMsaUJBQWlCLENBQUM7NEJBQzdDLElBQUksV0FBVyxDQUFDOzRCQUNoQixNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxpQkFBaUIsRUFBRTtnQ0FDcEMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO29DQUMzQixXQUFXLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQztnQ0FFakMsQ0FBQzs0QkFDTCxDQUFDLENBQUMsQ0FBQzs0QkFDSCxLQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsR0FBRyxXQUFXLENBQUM7NEJBQ3hDLEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLFFBQVEsQ0FBQyxVQUFVLENBQUM7NEJBQ2pELEtBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsR0FBRyxRQUFRLENBQUMsVUFBVSxDQUFDOzRCQUNyRSxLQUFJLENBQUMsTUFBTSxHQUFHLFFBQVEsQ0FBQyxVQUFVLENBQUM7NEJBQ2xDLEtBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxHQUFHLFFBQVEsQ0FBQyxLQUFLLEdBQUcsR0FBRyxHQUFHLFFBQVEsQ0FBQyxLQUFLLENBQUM7d0JBRXpFLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7Z0JBRVAsQ0FBQztnQkFFRCx5Q0FBYSxHQUFiLFVBQWMsVUFBVSxFQUFFLE9BQU87b0JBQzlCLFlBQVk7b0JBQ1gsVUFBVSxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUE7b0JBQzVCLFVBQVUsQ0FBQyxTQUFTLEdBQUcsT0FBTyxDQUFBO29CQUM5QixVQUFVLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQTtvQkFDNUIsVUFBVSxDQUFDLFFBQVEsR0FBRyxPQUFPLENBQUE7b0JBQzdCLFVBQVUsQ0FBQyxZQUFZLEdBQUcsS0FBSyxDQUFDO29CQUNoQyxtQkFBbUI7b0JBQ25CLEVBQUUsQ0FBQyxDQUFDLE9BQU8sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUNmLFVBQVUsQ0FBQyxTQUFTLEdBQUcsT0FBTyxDQUFDO3dCQUMvQixFQUFFLENBQUMsQ0FBQyxPQUFPLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQzs0QkFDZixVQUFVLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQzt3QkFFaEMsQ0FBQzt3QkFDRCxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxJQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7NEJBQ2xCLFVBQVUsQ0FBQyxTQUFTLEdBQUcsTUFBTSxDQUFDOzRCQUM5QixtQ0FBbUM7NEJBQ25DLFVBQVUsQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDO3dCQUNuQyxDQUFDO3dCQUNELElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLElBQUUsQ0FBQyxDQUFDLENBQ3BCLENBQUM7NEJBQ0csVUFBVSxDQUFDLE9BQU8sR0FBRyxNQUFNLENBQUE7d0JBRS9CLENBQUM7d0JBQ0QsVUFBVSxDQUFDLFlBQVksR0FBRyxLQUFLLENBQUM7b0JBRXBDLENBQUM7b0JBQ0QsSUFBSSxDQUFBLENBQUM7d0JBQ0QsVUFBVSxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUM7d0JBQ3pCLFVBQVUsQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDO3dCQUMvQixVQUFVLENBQUMsUUFBUSxHQUFHLE1BQU0sQ0FBQztvQkFFakMsQ0FBQztvQkFFRCxFQUFFLENBQUMsQ0FBQyxPQUFPLElBQUksQ0FBQyxJQUFJLE9BQU8sSUFBSSxDQUFDLENBQUMsQ0FDakMsQ0FBQzt3QkFDRyxVQUFVLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQzt3QkFDaEMsVUFBVSxDQUFDLFlBQVksR0FBRyxLQUFLLENBQUM7d0JBQ2hDLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO29CQUVoQyxDQUFDO29CQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDdEIsVUFBVSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUM7d0JBQy9CLFVBQVUsQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDO29CQUNyQyxDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUNGLFVBQVUsQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDO3dCQUNqQyxVQUFVLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQztvQkFDcEMsQ0FBQztnQkFDTCxDQUFDO2dCQUVELHdDQUFZLEdBQVosVUFBYSxLQUFLO29CQUVkLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDdkMsQ0FBQztnQkFDRCxrREFBc0IsR0FBdEIsVUFBdUIsS0FBSztvQkFBNUIsaUJBeUJDO29CQXhCRyxJQUFJLENBQUMsZUFBZSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUNsRCxXQUFXO3dCQUNYLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLFNBQVMsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO3dCQUVuQyxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO2dCQUNQLENBQUM7Z0JBRUQsZ0RBQW9CLEdBQXBCO29CQUFBLGlCQXFDQztvQkFwQ0csSUFBSSxDQUFDLGVBQWUsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUMxQyxXQUFXO3dCQUNYLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsOEJBQThCOzRCQUM5QixJQUFJLGVBQWUsR0FBRyxFQUFFLENBQUM7NEJBQzNCLGFBQWE7NEJBQ1gsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFO2dDQUN2QixJQUFJLE9BQU8sR0FBRyxFQUFFLENBQUM7Z0NBQ2pCLE9BQU8sQ0FBQyxFQUFFLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztnQ0FDeEIsT0FBTyxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO2dDQUN6QixlQUFlLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDOzRCQUNsQyxDQUFDLENBQUMsQ0FBQzs0QkFDSCxLQUFJLENBQUMsTUFBTSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7NEJBQzVCLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUM7Z0NBQ3RCLE1BQU0sRUFBRSxlQUFlO2dDQUN2QixRQUFRLEVBQUUsTUFBTTs2QkFDbkIsQ0FBQyxDQUFDO3dCQUNQLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7Z0JBQ1AsQ0FBQztnQkFDRCw0Q0FBZ0IsR0FBaEI7b0JBRUksRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDO3dCQUMvQixJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsR0FBRyxFQUFFLENBQUM7d0JBQ3JDLElBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxHQUFHLENBQUMsRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFLFNBQVMsRUFBRSxFQUFFLEVBQUUsV0FBVyxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsS0FBSyxFQUFFLEdBQUcsRUFBRSxDQUFDLENBQUM7d0JBQ3JILElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDO29CQUMvQixDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUNGLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDOzRCQUM5QyxJQUFJLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQzt3QkFDaEMsQ0FBQztvQkFDTCxDQUFDO2dCQUNMLENBQUM7Z0JBQ0QseUNBQWEsR0FBYixVQUFjLE9BQU87b0JBQ2pCLFdBQVc7b0JBRVgsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDLFNBQVMsSUFBSSxTQUFTLElBQUksT0FBTyxDQUFDLFNBQVMsSUFBSSxFQUFFLENBQUM7MkJBQzNELENBQUMsT0FBTyxDQUFDLFdBQVcsSUFBSSxTQUFTLElBQUksT0FBTyxDQUFDLFdBQVcsSUFBSSxFQUFFLENBQUM7MkJBQy9ELENBQUMsT0FBTyxDQUFDLEtBQUssSUFBSSxTQUFTLElBQUksT0FBTyxDQUFDLEtBQUssSUFBSSxFQUFFLENBQUM7MkJBQ25ELENBQUMsT0FBTyxDQUFDLEdBQUcsSUFBSSxTQUFTLElBQUksT0FBTyxDQUFDLEdBQUcsSUFBSSxFQUFFLENBQUMsQ0FBQztnQkFFM0QsQ0FBQztnQkFDRCx1Q0FBVyxHQUFYLFVBQVksT0FBTztvQkFDaEIsWUFBWTtvQkFDWCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFHOUIsSUFBSSxVQUFVLEdBQUcsRUFBRSxLQUFLLEVBQUUsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsQ0FBQyxNQUFNLEdBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRSxXQUFXLEVBQUUsRUFBRSxFQUFFLEtBQUssRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFLENBQUM7d0JBQ3BKLElBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQzt3QkFDakQsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO29CQUd6QixDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUNGLElBQUksR0FBRyxHQUFHLEVBQUUsQ0FBQzt3QkFDYixFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsU0FBUyxJQUFJLFNBQVMsSUFBSSxPQUFPLENBQUMsU0FBUyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7NEJBRTVELEdBQUcsSUFBSSwyQkFBMkIsQ0FBRTt3QkFDeEMsQ0FBQzt3QkFDRCxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsV0FBVyxJQUFJLFNBQVMsSUFBSSxPQUFPLENBQUMsV0FBVyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7NEJBRWhFLEdBQUcsSUFBSSw2QkFBNkIsQ0FBQzt3QkFDekMsQ0FBQzt3QkFDRCxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxJQUFJLFNBQVMsSUFBSSxPQUFPLENBQUMsS0FBSyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7NEJBRXBELEdBQUcsSUFBSSxzQkFBc0IsQ0FBQzt3QkFDbEMsQ0FBQzt3QkFDRCxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxJQUFJLFNBQVMsSUFBSSxPQUFPLENBQUMsR0FBRyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7NEJBRWhELEdBQUcsSUFBSSx5QkFBeUIsQ0FBQzt3QkFDckMsQ0FBQzt3QkFDRCxPQUFPLENBQUMsS0FBSyxDQUFDOzRCQUNWLE9BQU8sRUFBRSxHQUFHLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxZQUFZOzRCQUMxQyxPQUFPLEVBQUU7Z0NBQ0wsRUFBRSxFQUFFO29DQUNBLGNBQWM7b0NBQ2QsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO2lDQUM1Qjs2QkFDSjt5QkFDSixDQUFDLENBQUM7b0JBRVAsQ0FBQztnQkFFTCxDQUFDO2dCQUNELHlDQUFhLEdBQWIsVUFBYyxPQUFPO29CQUNuQixhQUFhO29CQUNYLG1EQUFtRDtvQkFDL0MsSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO29CQUNkLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLEVBQUU7d0JBQ3pDLEVBQUUsQ0FBQyxDQUFDLElBQUksSUFBSSxPQUFPLENBQUMsQ0FBQyxDQUFDOzRCQUNsQixNQUFNLENBQUMsS0FBSyxDQUFBO3dCQUNoQixDQUFDO3dCQUNELEtBQUssR0FBRyxLQUFLLEdBQUcsQ0FBQyxDQUFDO29CQUN0QixDQUFDLENBQUMsQ0FBQztvQkFDSCxJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDO29CQUNqRCxLQUFLLEdBQUcsQ0FBQyxDQUFDO29CQUNWLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLEVBQUU7d0JBQ3pDLElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDLFFBQVEsRUFBRSxDQUFDO3dCQUM5QixLQUFLLEdBQUcsS0FBSyxHQUFHLENBQUMsQ0FBQztvQkFDdEIsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO29CQUNyQixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDOUMsSUFBSSxDQUFDLGNBQWMsR0FBRyxLQUFLLENBQUM7b0JBQ2hDLENBQUM7b0JBQ0wsR0FBRztnQkFDUCxDQUFDO2dCQUNELGlEQUFxQixHQUFyQixVQUFzQixPQUFPO29CQUMzQixhQUFhO29CQUNYLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQztvQkFDZCxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxJQUFJLFNBQVMsSUFBSSxPQUFPLENBQUMsS0FBSyxJQUFJLElBQUksSUFBSSxPQUFPLENBQUMsR0FBRyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7d0JBQzNFLEtBQUssR0FBRyxVQUFVLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN0QyxDQUFDO29CQUNELElBQUksR0FBRyxHQUFHLENBQUMsQ0FBQztvQkFDWixFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxJQUFJLFNBQVMsSUFBSSxPQUFPLENBQUMsR0FBRyxJQUFJLElBQUksSUFBSSxPQUFPLENBQUMsR0FBRyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7d0JBQ3ZFLEdBQUcsR0FBRyxVQUFVLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUNsQyxDQUFDO29CQUNELE9BQU8sQ0FBQyxLQUFLLEdBQUcsQ0FBQyxLQUFLLEdBQUcsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUV6QyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7Z0JBQ3pCLENBQUM7Z0JBRUQseUNBQWEsR0FBYjtvQkFDSSxJQUFJLFNBQVMsR0FBRyxDQUFDLENBQUM7b0JBQ2xCLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLEVBQUU7d0JBQ3pDLFNBQVMsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLFFBQVEsRUFBRSxDQUFDLEdBQUUsVUFBVSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDekUsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDeEQsQ0FBQztnQkFDRCxvQ0FBUSxHQUFSO29CQUFBLGlCQW1ZQztvQkFqWUcscURBQXFEO29CQUNyRCxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsVUFBVSxFQUFFLENBQUM7b0JBQ2xDLE1BQU0sQ0FBQyxlQUFlLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFLENBQUMsQ0FBQztvQkFDbkQsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7b0JBQ3ZCLFlBQVk7b0JBQ1gsSUFBSSxVQUFVLEdBQUcsRUFBRSxDQUFDO29CQUNwQixJQUFJLEtBQUssR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDO29CQUMvQyxJQUFJLEtBQUssR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUMsQ0FBQztvQkFDbkQsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxHQUFHLEtBQUssR0FBQyxzQkFBc0IsQ0FBQyxDQUFDO29CQUN4RixFQUFFLENBQUMsQ0FBQyxLQUFLLElBQUksU0FBUyxJQUFJLEtBQUssSUFBSSxTQUFTLElBQUksS0FBSyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7d0JBQzFELEtBQUssR0FBRyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7d0JBQ3pDLElBQUksQ0FBQyxVQUFVLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQzt3QkFDMUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO3dCQUN6RCxVQUFVLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUM7d0JBQ3hDLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO29CQUM3QixDQUFDO29CQUdILGlCQUFpQjtvQkFDZixJQUFJLENBQUMsSUFBSSxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQ3pDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFFekUsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLEdBQUcsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO3dCQUM3QixDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUVILElBQUksQ0FBQyxlQUFlLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUNsRCxXQUFXO3dCQUNYLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLGNBQWMsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO3dCQUV4QyxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUVILElBQUksQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO29CQUM1QixJQUFJLENBQUMsZUFBZSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDL0UsV0FBVzt3QkFDWCxJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO2dDQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQzVCLE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEtBQUksQ0FBQyxhQUFhLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzt3QkFFdkMsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFDSCxJQUFJLENBQUMsZUFBZSxDQUFDLGNBQWMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQ2hELFdBQVc7d0JBQ1gsSUFBSSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtnQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUM1QixPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixXQUFXOzRCQUNYLEtBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDOzRCQUN2RCxLQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQzt3QkFFNUQsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFDSCxJQUFJLENBQUMsZUFBZSxDQUFDLFVBQVUsRUFBRSxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQzVDLFdBQVc7d0JBQ1gsSUFBSSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtnQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUM1QixPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixXQUFXOzRCQUNYLEtBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO3dCQUV2RCxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUNILElBQUksQ0FBQyxlQUFlLENBQUMsV0FBVyxFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDN0MsV0FBVzt3QkFDWCxJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO2dDQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQzVCLE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLFdBQVc7NEJBQ1gsS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7NEJBQ3BELEtBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO3dCQUV6RCxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUNILElBQUksQ0FBQyxlQUFlLENBQUMsVUFBVSxFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDNUMsV0FBVzt3QkFDWCxJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO2dDQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQzVCLE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEtBQUksQ0FBQyxTQUFTLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzt3QkFFbkMsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFFSCxJQUFJLENBQUMsZUFBZSxDQUFDLFdBQVcsRUFBRSxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQzdDLFdBQVc7d0JBQ1gsSUFBSSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtnQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUM1QixPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsU0FBUyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7d0JBRW5DLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBRUgsSUFBSSxDQUFDLGVBQWUsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUMxQyxXQUFXO3dCQUNYLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLE1BQU0sR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO3dCQUVoQyxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUVILElBQUksQ0FBQyxlQUFlLENBQUMsY0FBYyxFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDaEQsV0FBVzt3QkFDWCxJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO2dDQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQzVCLE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEtBQUksQ0FBQyxZQUFZLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzt3QkFFdEMsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFDSCxJQUFJLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDaEMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQ2xELElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLFdBQVcsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO3dCQUVyQyxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUNILElBQUksQ0FBQyxlQUFlLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQ3ZGLFlBQVk7d0JBQ1gsSUFBSSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtnQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUM1QixPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQzs0QkFDOUQsRUFBRSxDQUFDLENBQUMsVUFBVSxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0NBQ25CLEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDOzRCQUM3RCxDQUFDOzRCQUNELElBQUksQ0FBQyxDQUFDO2dDQUNGLEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLFVBQVUsQ0FBQzs0QkFDNUMsQ0FBQzt3QkFFTCxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUVILElBQUksQ0FBQyxlQUFlLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUNsRCxXQUFXO3dCQUNYLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7NEJBQ2hELEtBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxHQUFHLEtBQUksQ0FBQyxXQUFXLENBQUM7d0JBRW5ELENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsSUFBSSxNQUFNLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUM7b0JBQ3hDLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO29CQUN6QiwrREFBK0Q7b0JBQ2pFLGFBQWE7b0JBQ1gsSUFBSSxLQUFLLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQztvQkFDL0MsSUFBSSxLQUFLLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEdBQUcsUUFBUSxDQUFDLENBQUM7b0JBQ25ELElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLEdBQUcsR0FBRyxLQUFLLEdBQUMsK0JBQStCLENBQUMsQ0FBQztvQkFDbEcsRUFBRSxDQUFDLENBQUMsTUFBTSxJQUFJLFNBQVMsSUFBSSxNQUFNLElBQUksU0FBUyxJQUFJLE1BQU0sSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO3dCQUM3RCxNQUFNLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO3dCQUM1QyxJQUFJLENBQUMsY0FBYyxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDMUMsQ0FBQztvQkFDRCxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxDQUFDO29CQUN6RCxFQUFFLENBQUMsQ0FBQyxLQUFLLElBQUksU0FBUyxJQUFJLEtBQUssSUFBSSxTQUFTLElBQUksS0FBSyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7d0JBQzFELEtBQUssR0FBRyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7d0JBQ3pDLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLEdBQUcsR0FBRyxLQUFLLEdBQUMsd0JBQXdCLENBQUMsQ0FBQzt3QkFDMUYsRUFBRSxDQUFDLENBQUMsS0FBSyxJQUFJLFNBQVMsSUFBSSxLQUFLLElBQUksU0FBUyxJQUFJLEtBQUssSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDOzRCQUMxRCxLQUFLLEdBQUcsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDOzRCQUN6QyxJQUFJLE9BQU8sR0FBRyxFQUFFLENBQUM7NEJBQ2pCLE9BQU8sR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDOzRCQUNsQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxFQUFFO2dDQUN6QyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUM7b0NBQ3RCLElBQUksQ0FBQyxTQUFTLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQztvQ0FDcEMsSUFBSSxDQUFDLFdBQVcsR0FBRyxPQUFPLENBQUMsV0FBVyxDQUFDO29DQUN2QyxJQUFJLENBQUMsS0FBSyxHQUFHLFVBQVUsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO29DQUNsRCxJQUFJLENBQUMsS0FBSyxHQUFHLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxVQUFVLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO29DQUV4RSxNQUFNLENBQUMsS0FBSyxDQUFDO2dDQUNqQixDQUFDOzRCQUVMLENBQUMsQ0FBQyxDQUFDOzRCQUNILElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQzs0QkFDckIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQzs0QkFDaEQsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQyxLQUFLLEdBQUcsR0FBRyxHQUFHLEtBQUssR0FBQyx3QkFBd0IsQ0FBQyxDQUFDO3dCQUNyRixDQUFDO29CQUNMLENBQUM7Z0JBQ0wsQ0FBQztnQkFqNkNNLHlCQUFPLEdBQUcsQ0FBQyxRQUFRLEVBQUUsV0FBVyxFQUFFLGVBQWUsQ0FBQyxDQUFDO2dCQXZDOUQ7b0JBQUMsZ0JBQVMsQ0FBQzt3QkFDUCxXQUFXLEVBQUUsaURBQWlEO3dCQUM5RCxVQUFVLEVBQUUsQ0FBQyxpQkFBUSxFQUFFLHFCQUFZLEVBQUUsd0JBQWUsRUFBRSwwQkFBUSxDQUFDO3dCQUMvRCxTQUFTLEVBQUUsQ0FBQywrQkFBYyxFQUFFLGlDQUFlLEVBQUUsaUNBQWUsRUFBRSx5Q0FBbUIsQ0FBQztxQkFDckYsQ0FBQzs7cUNBQUE7Z0JBcThDRix3QkFBQztZQUFELENBbjhDQSxBQW04Q0MsSUFBQTtZQW44Q0QsaURBbThDQyxDQUFBIiwiZmlsZSI6ImFtYXgvUmVjZWlwdC9SZWNlaXB0Q3JlYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtDb21wb25lbnQsIE91dHB1dCwgSW5wdXQsIEV2ZW50RW1pdHRlciwgT25Jbml0fSBmcm9tIFwiYW5ndWxhcjIvY29yZVwiO1xyXG5pbXBvcnQge05nU3dpdGNoLCBOZ1N3aXRjaFdoZW4sIE5nU3dpdGNoRGVmYXVsdH0gZnJvbSAnYW5ndWxhcjIvY29tbW9uJ1xyXG5pbXBvcnQge1Jlc291cmNlU2VydmljZX0gZnJvbSBcIi4uLy4uL3NlcnZpY2VzL1Jlc291cmNlU2VydmljZVwiO1xyXG5pbXBvcnQge1JvdXRlUGFyYW1zfSBmcm9tIFwiYW5ndWxhcjIvcm91dGVyXCI7XHJcbmltcG9ydCB7UmVjaWVwdFNlcnZpY2V9IGZyb20gXCIuLi8uLi9zZXJ2aWNlcy9SZWNpZXB0U2VydmljZVwiO1xyXG5pbXBvcnQge0N1c3RvbWVyU2VydmljZX0gZnJvbSBcIi4uLy4uL3NlcnZpY2VzL0N1c3RvbWVyU2VydmljZVwiO1xyXG5pbXBvcnQgeyBqc29uUSB9IGZyb20gJy4uLy4uL2pzb25RJztcclxuaW1wb3J0IHtHcm91cEZpbHRlclBpcGUsIEdyb3VwUGFyZW5GaWx0ZXJQaXBlLCBLZW5kb191dGlsaXR5fSBmcm9tIFwiLi4vLi4vYW1heFV0aWxcIjtcclxuaW1wb3J0IHsgQW1heERhdGUgfSBmcm9tICcuLi8uLi9jb21vbkNvbXBvbmVudHMvYmFzaWNDb21wb25lbnRzJztcclxuaW1wb3J0IHtDaGFyZ2VDcmVkaXRTZXJ2aWNlfSBmcm9tIFwiLi4vLi4vc2VydmljZXMvQ2hhcmdlQ3JlZGl0U2VydmljZVwiO1xyXG5kZWNsYXJlIHZhciBqUXVlcnk7XHJcbmRlY2xhcmUgdmFyIG1vbWVudDtcclxuQENvbXBvbmVudCh7XHJcbiAgICB0ZW1wbGF0ZVVybDogJy4vYXBwL2FtYXgvUmVjZWlwdC90ZW1wbGF0ZXMvUmVjZWlwdENyZWF0ZS5odG1sJyxcclxuICAgIGRpcmVjdGl2ZXM6IFtOZ1N3aXRjaCwgTmdTd2l0Y2hXaGVuLCBOZ1N3aXRjaERlZmF1bHQsIEFtYXhEYXRlXSxcclxuICAgIHByb3ZpZGVyczogW1JlY2llcHRTZXJ2aWNlLCBSZXNvdXJjZVNlcnZpY2UsIEN1c3RvbWVyU2VydmljZSwgQ2hhcmdlQ3JlZGl0U2VydmljZV1cclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBBbWF4UmVjZWlwdENyZWF0ZSBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcbiAgICBiYXNlVXJsOiBzdHJpbmc7XHJcbiAgICBSRVM6IE9iamVjdCA9IHt9O1xyXG4gICAgRm9ybXR5cGU6IHN0cmluZyA9IFwiU0NSRUVOX1JFQ0VJUFRDUkVBVEVcIjtcclxuICAgIExhbmc6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBfQmFua3MgPSBbXTtcclxuICAgIF9DdXN0b21lck5vdGVzID0gW107XHJcbiAgICBfQWRkcmVzc2VzID0gW107XHJcbiAgICBfUGF5VHlwZXMgPSBbXTtcclxuICAgIF9BY2NvdW50cyA9IFtdO1xyXG4gICAgX0dvYWxzID0gW107XHJcbiAgICBfUHJvamVjdENhdHMgPSBbXTtcclxuICAgIF9Qcm9qZWN0cyA9IFtdO1xyXG4gICAgX0N1cnJlbmNpZXMgPSBbXTtcclxuICAgIFBhc3RlVGV4dDogc3RyaW5nID0gXCJcIjtcclxuICAgIElzU2hvd1Byb2R1Y3RzOiBib29sZWFuID0gZmFsc2U7XHJcbi8vICAgIG1vZGVsSW5wdXQuUmVjZWlwdExpbmVzID0gW107XHJcbiAgICBfVGhhbmtMZXR0ZXJzID0gW107XHJcbiAgICBSb3dDb3VudDpudW1iZXIgPSAwO1xyXG4gICAgSXNidG5kaXNhYmxlOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgU0FWRV9CVE5fVEVYVDogc3RyaW5nPVwiU2F2ZVwiO1xyXG4gICAgTXNnQ2xhc3M6IHN0cmluZyA9IFwidGV4dC1wcmltYXJ5XCI7XHJcbiAgICBtb2RlbElucHV0OiBPYmplY3QgPSB7fTtcclxuICAgIHNhdmVJbnB1dDogT2JqZWN0ID0ge307XHJcbiAgICBDaGFuZ2VEaWFsb2c6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBDSEFOR0VESVI6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBDdXN0SWQ6IG51bWJlcjtcclxuICAgIFNob3dNb3JlVGV4dDogc3RyaW5nID0gXCJcIjtcclxuICAgIFNob3dNb3JlOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBJc0JhbmtEZXRTaG93OiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBEZWZhdWx0RGF0ZTogc3RyaW5nID0gXCJcIjtcclxuICAgIElQb3BVcE9wZW46IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIFBvcFByb2RPYmo6IE9iamVjdCA9IHt9O1xyXG4gICAgc3RhdGljICRpbmplY3QgPSBbJyRzY29wZScsICckbG9jYXRpb24nLCAnJGFuY2hvclNjcm9sbCddO1xyXG4gICAvLyBAVmlld0NoaWxkKCdSVExEaXYnKSBwcml2YXRlIG15U2Nyb2xsQ29udGFpbmVyOiBFbGVtZW50UmVmO1xyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBfcmVzb3VyY2VTZXJ2aWNlOiBSZXNvdXJjZVNlcnZpY2UsIHByaXZhdGUgX1JlY2llcHRTZXJ2aWNlOiBSZWNpZXB0U2VydmljZSwgcHJpdmF0ZSBfQ3VzdG9tZXJTZXJ2aWNlOiBDdXN0b21lclNlcnZpY2UsIHByaXZhdGUgX3JvdXRlUGFyYW1zOiBSb3V0ZVBhcmFtcywgcHJpdmF0ZSBfQ2hhcmdlQ3JlZGl0U2VydmljZTogQ2hhcmdlQ3JlZGl0U2VydmljZSkge1xyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMuUkVTLlNDUkVFTl9SRUNFSVBUQ1JFQVRFID0ge307XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0ID0ge307XHJcbiAgICAgICAgLy90aGlzLm1vZGVsSW5wdXQuQWRkTW9kZWwgPSB7fTtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdExpbmVzID0gW107XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LlJlY2VpcHRQcm9kdWN0cyA9IFtdO1xyXG4gICAgICAgIC8vdGhpcy5tb2RlbElucHV0LlJlY2VpcHRQcm9kdWN0cyA9IFt7IFJvd05vOiBcIjFcIiwgUHJvZHVjdE5vOiBcIlwiLCBQcm9kdWN0TmFtZTogXCJcIiwgUHJpY2U6IFwiMFwiLCBRdHk6IFwiMVwiLCBUb3RhbDogXCIwXCIgfV07XHJcbiAgICAgICAgdGhpcy5Jc1Nob3dQcm9kdWN0cyA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMuSVBvcFVwT3BlbiA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMuSXNCYW5rRGV0U2hvdyA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0VHlwZUlkID0gX3JvdXRlUGFyYW1zLnBhcmFtcy5SZWNlaXB0VHlwZUlkO1xyXG4gICAgICAgIC8vdGhpcy5iYXNlVXJsID0gXCJodHRwOi8vbG9jYWxob3N0OjMwMDAvIy9cIjtcclxuICAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgIC8vIGFsZXJ0KHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0VHlwZUlkKTtcclxuICAgICAgICB0aGlzLmJhc2VVcmwgPSBfcmVzb3VyY2VTZXJ2aWNlLkFwcFVybDtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCA9IF9yb3V0ZVBhcmFtcy5wYXJhbXMuSWQ7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyTmFtZSA9IFwiXCI7XHJcbiAgICAgICAgLy90aGlzLm1vZGVsSW5wdXQuQWRkTW9kZWwuUmVmZXJlbmNlRGF0ZSA9IFwiXCI7XHJcbiAgICAgICAvLyB0aGlzLlNob3dNb3JlVGV4dCA9IFwiTW9yZVwiO1xyXG4gICAgICAgIHRoaXMuRGVmYXVsdERhdGUgPSBtb21lbnQobmV3IERhdGUoKSkuZm9ybWF0KCdERC1NTS1ZWVlZJyk7XHJcbiAgICAgICAgdGhpcy5MYW5nID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJsYW5nXCIpO1xyXG4gICAgICAgIHZhciBNVGV4dCA9IFwiXCI7XHJcbiAgICAgICAgaWYgKHRoaXMuTGFuZyA9PSBcImVuXCIpIHtcclxuICAgICAgICAgICAgTVRleHQgPSBcIk1vcmVcIjtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIE1UZXh0ID0gXCLXmdeV16rXqFwiO1xyXG4gICAgICAgIH1cclxuICAgICAgICB2YXIgRHVwT2JqID0ge1xyXG4gICAgICAgICAgICBBbW91bnQ6IDAsIFZhbHVlRGF0ZTogdGhpcy5EZWZhdWx0RGF0ZSwgUGF5VHlwZUlkOiAxLCBBY2NvdW50SWQ6IFwiXCIsIEFjY291bnRObzogXCJcIixcclxuICAgICAgICAgICAgQnJhbmNoTm86IFwiXCIsIEJhbms6IFwiXCIsIENyZWRpdENhcmRUeXBlOiBcIlwiLCBEb25hdGlvblR5cGVJZDogXCJcIiwgUHJvamVjdENhdGVnb3J5SWQ6IFwiXCIsIFByb2plY3RJZDogXCJcIiwgUmVmZXJlbmNlRGF0ZTogdGhpcy5EZWZhdWx0RGF0ZSxcclxuICAgICAgICAgICAgRm9yX0ludm9pY2U6IFwiXCIsIFJlY2lldmVkQ3VzdElkOiBcIlwiLCBQYXllZDogZmFsc2UsIERlcG9zaXRlUmVtYXJrOiBcIlwiLCBTaG93TW9yZTogZmFsc2UsIFNob3dNb3JlVGV4dDogTVRleHQsXHJcbiAgICAgICAgICAgIENhc2hDU1M6IFwiZ3JleVwiLCBDcmVkaXRDU1M6IFwid2hpdGVcIiwgQmFua0NTUzogXCJ3aGl0ZVwiLCBPdGhlckNTUzogXCJ3aGl0ZVwiLCBJc1Nob3dPdGhlcnM6IGZhbHNlLCBJc0NyZWRpdFNob3c6IGZhbHNlLCBJc0JhbmtEZXRTaG93OiBmYWxzZVxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0TGluZXMucHVzaChEdXBPYmopO1xyXG4gICAgICAgIFxyXG4gICAgfVxyXG4gICAgZGF0ZVZTZWxlY3Rpb25DaGFuZ2UoZXZ0LCBkYXRhb2JqKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coZXZ0KTtcclxuICAgICAgICBkYXRhb2JqLlZhbHVlRGF0ZSA9IGV2dDtcclxuICAgICAgICAvLyBhbGVydCh0aGlzLm1vZGVsSW5wdXQuQmlydGhEYXRlKTtcclxuICAgICAgICAvL3RoaXMudmFsaWRhdGVMb2dpbigpO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICBkYXRlU2VsZWN0aW9uQ2hhbmdlKGV2dCwgZGF0YW9iaikge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGV2dCk7XHJcbiAgICAgICAgZGF0YW9iai5SZWZlcmVuY2VEYXRlID0gZXZ0O1xyXG4gICAgICAgIC8vIGFsZXJ0KHRoaXMubW9kZWxJbnB1dC5CaXJ0aERhdGUpO1xyXG4gICAgICAgIC8vdGhpcy52YWxpZGF0ZUxvZ2luKCk7XHJcbiAgICB9XHJcblxyXG4gICAgTW9yZShtb2RlbG9iail7XHJcbiAgICAgICAgLy8gYWxlcnQoXCJjYWxsXCIpO1xyXG4gICAgICAgIGlmIChtb2RlbG9iai5TaG93TW9yZSA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgIG1vZGVsb2JqLlNob3dNb3JlID0gZmFsc2U7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLkxhbmcgPT0gXCJlblwiKSB7XHJcbiAgICAgICAgICAgICAgICBtb2RlbG9iai5TaG93TW9yZVRleHQgPSBcIk1vcmVcIjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIG1vZGVsb2JqLlNob3dNb3JlVGV4dCA9IFwi15nXldeq16hcIjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAvL3RoaXMuU2hvd01vcmVUZXh0ID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9MTktfTEJMX01PUkU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBtb2RlbG9iai5TaG93TW9yZSA9IHRydWU7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLkxhbmcgPT0gXCJlblwiKSB7XHJcbiAgICAgICAgICAgICAgICBtb2RlbG9iai5TaG93TW9yZVRleHQgPSBcIkxlc3NcIjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIG1vZGVsb2JqLlNob3dNb3JlVGV4dCA9IFwi16TWvNa415fXlda816pcIjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAvL3RoaXMuU2hvd01vcmVUZXh0ID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9MTktfTEJMX0xFU1M7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgQmFua0RldGFpbFNob3coUGF5VHlwZUlkLGRhdGFvYmopIHtcclxuICAgICAgICBpZiAoUGF5VHlwZUlkICE9IDEgJiYgUGF5VHlwZUlkICE9IDMpLy8gTm90IENhc2ggYW5kIG5vdCBDcmVkaXQgY2FyZFxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgZGF0YW9iai5Jc0JhbmtEZXRTaG93ID0gdHJ1ZTtcclxuICAgICAgICAgICAgZGF0YW9iai5Jc0NyZWRpdFNob3cgPSBmYWxzZTtcclxuICAgICAgICAgICAgdGhpcy5CaW5kQXV0b0NvbXBsZXRlQmFuaygpO1xyXG4gICAgICAgIH0gZWxzZSBpZiAoUGF5VHlwZUlkID09IDMpIHtcclxuICAgICAgICAgICAgZGF0YW9iai5Jc0NyZWRpdFNob3cgPSB0cnVlO1xyXG4gICAgICAgICAgICBkYXRhb2JqLklzQmFua0RldFNob3cgPSBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7Ly8gT25seSBGb3IgQ2FzaFxyXG4gICAgICAgICAgICBkYXRhb2JqLklzQmFua0RldFNob3cgPSBmYWxzZTtcclxuICAgICAgICAgICAgZGF0YW9iai5Jc0NyZWRpdFNob3cgPSBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBzZXRkZWZhdWx0bW9kZSgpIHtcclxuICAgICAgICAvL2RvY3VtZW50LmxvY2F0aW9uID0gdGhpcy5iYXNlVXJsICsgXCJSZWNlaXB0Q3JlYXRlL1wiICsgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQgKyBcIiAvXCIgKyB0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdElkO1xyXG4gICAgICAgIHRoaXMuSVBvcFVwT3BlbiA9IGZhbHNlO1xyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMuUm93Q291bnQgPSAwO1xyXG4gICAgICAgIHdpbmRvdy5zY3JvbGxUbygwLCAwKTtcclxuICAgICAgICB2YXIgX1JlY2VpcHRUeXBlSWQgPSB0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdFR5cGVJZFxyXG4gICAgICAgIHZhciBQcmV2UmVjZWlwdFR5cGUgPSB0aGlzLm1vZGVsSW5wdXQuUmVjaWVwdFR5cGU7XHJcblxyXG4gICAgICAgIHZhciBDdXN0SWQgPSB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZDtcclxuICAgICAgICB2YXIgQ3VzdE5hbWUgPSB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJOYW1lO1xyXG4gICAgICAgIHZhciBhZGRyZXNzSWQgPSB0aGlzLm1vZGVsSW5wdXQuQWRkcmVzc0lkO1xyXG4gICAgICAgIHZhciB0aG5rTGV0dGVySWQgPSB0aGlzLm1vZGVsSW5wdXQuVGhhbmtzTGV0dGVySWQ7XHJcbiAgICAgICAgdmFyIFByaW50VmFsdWVEYXRlID0gdGhpcy5tb2RlbElucHV0LlZhbHVlRGF0ZTtcclxuICAgICAgICB2YXIgYXNzb2NpYXRpb25OYW1lID0gdGhpcy5tb2RlbElucHV0LmFzc29jaWF0aW9uTmFtZTtcclxuICAgICAgICB2YXIgUHJpbnRlcklkID0gdGhpcy5tb2RlbElucHV0LlByaW50ZXJJZDtcclxuICAgICAgICB2YXIgYXNzb2NpYXRpb25pZCA9IHRoaXMubW9kZWxJbnB1dC5hc3NvY2lhdGlvbklkO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dCA9IHt9O1xyXG4gICAgICAgIHRoaXMuSXNTaG93UHJvZHVjdHMgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCA9IEN1c3RJZDtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJOYW1lID0gQ3VzdE5hbWU7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkFkZHJlc3NJZCA9IGFkZHJlc3NJZDtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuYXNzb2NpYXRpb25OYW1lID0gYXNzb2NpYXRpb25OYW1lO1xyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5UaGFua3NMZXR0ZXJJZCA9IHRobmtMZXR0ZXJJZDtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuUHJpbnRWYWx1ZURhdGUgPSBQcmludFZhbHVlRGF0ZTtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdFR5cGVJZCA9IF9SZWNlaXB0VHlwZUlkO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5QcmludGVySWQgPSBQcmludGVySWQ7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LmFzc29jaWF0aW9uSWQgPSBhc3NvY2lhdGlvbmlkO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0TGluZXMgPSBbXTtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdFByb2R1Y3RzID0gW107XHJcbiAgICAgICAgLy90aGlzLm1vZGVsSW5wdXQuUmVjZWlwdFByb2R1Y3RzID0gW3sgUm93Tm86IFwiMVwiLCBQcm9kdWN0Tm86IFwiXCIsIFByb2R1Y3ROYW1lOiBcIlwiLCBQcmljZTogXCIwXCIsIFF0eTogXCIxXCIsIFRvdGFsOiBcIjBcIiB9XTtcclxuICAgICAgICB2YXIgRHVwT2JqID0ge1xyXG4gICAgICAgICAgICBBbW91bnQ6IDAsIFZhbHVlRGF0ZTogdGhpcy5EZWZhdWx0RGF0ZSwgUGF5VHlwZUlkOiAxLCBBY2NvdW50SWQ6IFwiXCIsIEFjY291bnRObzogXCJcIixcclxuICAgICAgICAgICAgQnJhbmNoTm86IFwiXCIsIEJhbms6IFwiXCIsIENyZWRpdENhcmRUeXBlOiBcIlwiLCBEb25hdGlvblR5cGVJZDogXCJcIiwgUHJvamVjdENhdGVnb3J5SWQ6IFwiXCIsIFByb2plY3RJZDogXCJcIiwgUmVmZXJlbmNlRGF0ZTogdGhpcy5EZWZhdWx0RGF0ZSxcclxuICAgICAgICAgICAgRm9yX0ludm9pY2U6IFwiXCIsIFJlY2lldmVkQ3VzdElkOiBDdXN0SWQsIFBheWVkOiBmYWxzZSwgRGVwb3NpdGVSZW1hcms6IFwiXCIsIFNob3dNb3JlOiBmYWxzZSwgU2hvd01vcmVUZXh0OiBcIk1vcmVcIixcclxuICAgICAgICAgICAgQ2FzaENTUzogXCJncmV5XCIsIENyZWRpdENTUzogXCJ3aGl0ZVwiLCBCYW5rQ1NTOiBcIndoaXRlXCIsIE90aGVyQ1NTOiBcIndoaXRlXCIsIElzU2hvd090aGVyczogZmFsc2UsIElzQ3JlZGl0U2hvdzogZmFsc2UsIElzQmFua0RldFNob3c6IGZhbHNlXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LlJlY2VpcHRMaW5lcy5wdXNoKER1cE9iaik7XHJcbiAgICAgICAgLy90aGlzLkdldEN1c3RvbWVyRGV0YWlsKEN1c3RJZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAvL3RoaXMubW9kZWxJbnB1dC5SZWNpZXB0VHlwZSA9IFByZXZSZWNlaXB0VHlwZTtcclxuICAgICAgICB0aGlzLl9SZWNpZXB0U2VydmljZS5HZXRSZWNpZXB0VHlwZSh0aGlzLl9yb3V0ZVBhcmFtcy5wYXJhbXMuUmVjZWlwdFR5cGVJZCkuc3Vic2NyaWJlKHJlc3A9PiB7XHJcbiAgICAgICAgICAgIC8vIGRlYnVnZ2VyO1xyXG4gICAgICAgICAgICB2YXIgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3ApO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuUmVjaWVwdFR5cGUgPSByZXNwb25zZS5EYXRhWzBdLlJlY2llcHROYW1lRW5nO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1cnJlbmN5SWQgPSByZXNwb25zZS5EYXRhWzBdLkN1cnJlbmN5SWQ7XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIC8vIHRoaXMuSXNCYW5rRGV0U2hvdyA9IGZhbHNlO1xyXG5cclxuICAgICAgICB0aGlzLl9SZWNpZXB0U2VydmljZS5HZXRFbXBsb3llZSgpLnN1YnNjcmliZShyZXNwPT4ge1xyXG4gICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICB2YXIgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3ApO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkVtcGxveWVlSWQgPSByZXNwb25zZS5EYXRhWzBdLlZhbHVlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkVtcGxveWVlTmFtZSA9IHJlc3BvbnNlLkRhdGFbMF0uVGV4dDtcclxuXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHRoaXMuX1JlY2llcHRTZXJ2aWNlLkdldFJlY2VpcHREZXRhaWwoKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAgICAgIHZhciByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcCk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5SZWNpZXB0Tm8gPSByZXNwb25zZS5EYXRhLlZhbHVlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LlJlY2llcHREYXRlID0gcmVzcG9uc2UuRGF0YS5UZXh0O1xyXG5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuICAgIHNhdmVSZWNlaXB0RGF0YShJc0V4aXQpIHtcclxuICAgICAgIC8vIGRlYnVnZ2VyO1xyXG4gICAgICAgIC8vaWYgKHRoaXMuSVBvcFVwT3BlbiA9PSBmYWxzZSlcclxuICAgICAgICAvL3tcclxuICAgICAgICB2YXIgRW1wTmFtZSA9IGpRdWVyeShcIiNFbXBJZFwiKS52YWwoKTtcclxuICAgICAgICB0aGlzLl9SZWNpZXB0U2VydmljZS5HZXRFbXBsb3llZUZyb21FbXBOYW1lKEVtcE5hbWUpLnN1YnNjcmliZShyZXNwPT4ge1xyXG4gICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICB2YXIgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3ApO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuRW1wbG95ZWVJZCA9IHJlc3BvbnNlLkRhdGE7XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQgIT0gbnVsbCAmJiB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCAhPSBcIlwiICYmIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkICE9IHVuZGVmaW5lZFxyXG4gICAgICAgICAgICAmJiB0aGlzLm1vZGVsSW5wdXQuQ3VycmVuY3lJZCAhPSBudWxsICYmIHRoaXMubW9kZWxJbnB1dC5DdXJyZW5jeUlkICE9IFwiXCIgJiYgdGhpcy5tb2RlbElucHV0LkN1cnJlbmN5SWQgIT0gdW5kZWZpbmVkXHJcbiAgICAgICAgICAgICYmIHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0TGluZXMubGVuZ3RoID4gMFxyXG4gICAgICAgICAgICAmJiB0aGlzLm1vZGVsSW5wdXQuYXNzb2NpYXRpb25JZCAhPSBudWxsICYmIHRoaXMubW9kZWxJbnB1dC5hc3NvY2lhdGlvbklkICE9IFwiXCIgJiYgdGhpcy5tb2RlbElucHV0LmFzc29jaWF0aW9uSWQgIT0gdW5kZWZpbmVkXHJcbiAgICAgICAgICAgICYmIHRoaXMubW9kZWxJbnB1dC5FbXBsb3llZUlkICE9IG51bGwgJiYgdGhpcy5tb2RlbElucHV0LkVtcGxveWVlSWQgIT0gXCItMVwiICYmIHRoaXMubW9kZWxJbnB1dC5FbXBsb3llZUlkICE9IHVuZGVmaW5lZFxyXG4gICAgICAgICAgICAmJiB0aGlzLm1vZGVsSW5wdXQuVGhhbmtzTGV0dGVySWQgIT0gbnVsbCAmJiB0aGlzLm1vZGVsSW5wdXQuVGhhbmtzTGV0dGVySWQgIT0gXCJcIiAmJiB0aGlzLm1vZGVsSW5wdXQuVGhhbmtzTGV0dGVySWQgIT0gdW5kZWZpbmVkXHJcbiAgICAgICAgICAgICYmIHRoaXMubW9kZWxJbnB1dC5QcmludGVySWQgIT0gbnVsbCAmJiB0aGlzLm1vZGVsSW5wdXQuUHJpbnRlcklkICE9IFwiXCIgJiYgdGhpcy5tb2RlbElucHV0LlByaW50ZXJJZCAhPSB1bmRlZmluZWRcclxuICAgICAgICAgICAgJiYgdGhpcy5tb2RlbElucHV0LlJlY2llcHRObyAhPSBudWxsICYmIHRoaXMubW9kZWxJbnB1dC5SZWNpZXB0Tm8gIT0gXCJcIiAmJiB0aGlzLm1vZGVsSW5wdXQuUmVjaWVwdE5vICE9IHVuZGVmaW5lZFxyXG4gICAgICAgICkge1xyXG5cclxuICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LlJlY2llcHRUeXBlID0gdGhpcy5tb2RlbElucHV0LlJlY2VpcHRUeXBlSWQ7XHJcbiAgICAgICAgICAgIHZhciBMaW5lQ291bnQgPSB0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdExpbmVzLmxlbmd0aDtcclxuICAgICAgICAgICAgdmFyIENoZWNrUm93VmFsaWQgPSB0cnVlO1xyXG4gICAgICAgICAgICBpZiAoTGluZUNvdW50IDwgMSkge1xyXG4gICAgICAgICAgICAgICAgQ2hlY2tSb3dWYWxpZCA9IGZhbHNlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8vYWxlcnQoSlNPTi5zdHJpbmdpZnkodGhpcy5tb2RlbElucHV0KSk7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICBmb3IgKHZhciBjbnQgaW4gdGhpcy5tb2RlbElucHV0LlJlY2VpcHRMaW5lcykgLy8gZm9yIGFjdHMgYXMgYSBmb3JlYWNoXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIHZhciBFcnJvck1lc3NhZ2UgPSBcIlJvdyBOdW1iZXIgLSBcIiArIChwYXJzZUludChjbnQpICsgMSkudG9TdHJpbmcoKSArIFwiIGlzIG5vdCB2YWxpZCBpbiBSZWNlaXB0IExpbmVzIDxicj5cIjtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLlZhbGlkYXRlUm93TW9kZWwodGhpcy5tb2RlbElucHV0LlJlY2VpcHRMaW5lc1tjbnRdLCBFcnJvck1lc3NhZ2UpID09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgQ2hlY2tSb3dWYWxpZCA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBmb3IgKHZhciBjbnQgaW4gdGhpcy5tb2RlbElucHV0LlJlY2VpcHRQcm9kdWN0cykgLy8gZm9yIGFjdHMgYXMgYSBmb3JlYWNoXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIHZhciBFcnJvck1lc3NhZ2UgPSBcIlJvdyBOdW1iZXIgLSBcIiArIChwYXJzZUludChjbnQpICsgMSkudG9TdHJpbmcoKSArIFwiIGlzIG5vdCB2YWxpZCBpbiBQcm9kdWN0cyA8YnI+XCI7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5WYWxpZGF0ZVByb2R1Y3RSb3dNb2RlbCh0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdFByb2R1Y3RzW2NudF0sIEVycm9yTWVzc2FnZSxjbnQpID09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgQ2hlY2tSb3dWYWxpZCA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcblxyXG5cclxuICAgICAgICAgICAgaWYgKENoZWNrUm93VmFsaWQgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgIHZhciBqZGF0YSA9IEpTT04uc3RyaW5naWZ5KHRoaXMubW9kZWxJbnB1dCk7XHJcbiAgICAgICAgICAgICAgICAvL2NvbnNvbGUubG9nKGpkYXRhKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX1JlY2llcHRTZXJ2aWNlLkFkZFJlY2VpcHQoamRhdGEpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhyZXNwb25zZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLklzYnRuZGlzYWJsZSA9IFwiXCI7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWxlcnQocmVzcG9uc2UuRXJyTXNnKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5Nc2dDbGFzcyA9IFwidGV4dC1kYW5nZXJcIjtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIEVtcElkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJlbXBsb3llZWlkXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgT3JnSWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShFbXBJZCArIFwiX09yZ0lkXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZGVsZXRlQ29va2llKEVtcElkICsgXCJfXCIgKyBPcmdJZCArIFwiX1JlY2VpcHRDcmVhdGVfQ2FjaGVcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5kZWxldGVDb29raWUoRW1wSWQgKyBcIl9cIiArIE9yZ0lkICsgXCJfUmVjZWlwdENyZWF0ZV9Jc1Nob3dQcm9kdWN0c1wiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmRlbGV0ZUNvb2tpZShFbXBJZCArIFwiX1wiICsgT3JnSWQrXCJfUmVjZWlwdENyZWF0ZV9Qcm9kdWN0XCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoSXNFeGl0ID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRvY3VtZW50LmxvY2F0aW9uID0gdGhpcy5iYXNlVXJsICsgXCJSZWNlaXB0U2VsZWN0L1wiICsgdGhpcy5tb2RlbElucHV0LkVtcGxveWVlSWQgKyBcIiAvXCIgKyB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc2V0ZGVmYXVsdG1vZGUoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5QcmludFJlY2llcHRObyA9IHJlc3BvbnNlLkRhdGEuUmVjaWVwdE5vO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5DdXN0SWQgPSByZXNwb25zZS5DdXN0b21lcklkO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgZXJyb3I9PiBjb25zb2xlLmxvZyhlcnJvciksXHJcbiAgICAgICAgICAgICAgICAgICAgKCkgPT4gY29uc29sZS5sb2coXCJTYXZlIENhbGwgQ29tcGxlYXRlZFwiKVxyXG4gICAgICAgICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICB2YXIgbXNnID0gXCJcIjtcclxuICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkID09IG51bGwgfHwgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQgPT0gXCJcIiB8fCB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCA9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgIG1zZyArPSBcIjxicj5QbGVhc2UgZW50ZXIgY3VzdG9tZXJpZFwiO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VycmVuY3lJZCA9PSBudWxsIHx8IHRoaXMubW9kZWxJbnB1dC5DdXJyZW5jeUlkID09IFwiXCIgfHwgdGhpcy5tb2RlbElucHV0LkN1cnJlbmN5SWQgPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgICAgICBtc2cgKz0gXCI8YnI+UGxlYXNlIHNlbGVjdCBjdXJyZW5jeVwiO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuYXNzb2NpYXRpb25JZCA9PSBudWxsIHx8IHRoaXMubW9kZWxJbnB1dC5hc3NvY2lhdGlvbklkID09IFwiXCIgfHwgdGhpcy5tb2RlbElucHV0LmFzc29jaWF0aW9uSWQgPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgICAgICBtc2cgKz0gXCI8YnI+UGxlYXNlIGVudGVyIERlcG9zaXRlZCBCeVwiO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuRW1wbG95ZWVJZCA9PSBudWxsIHx8IHRoaXMubW9kZWxJbnB1dC5FbXBsb3llZUlkID09IFwiXCIgfHwgdGhpcy5tb2RlbElucHV0LkVtcGxveWVlSWQgPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgICAgICBtc2cgKz0gXCI8YnI+UGxlYXNlIGVudGVyIHZhbGlkIGVtcGxveWVlXCI7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5UaGFua3NMZXR0ZXJJZCA9PSBudWxsIHx8IHRoaXMubW9kZWxJbnB1dC5UaGFua3NMZXR0ZXJJZCA9PSBcIlwiIHx8IHRoaXMubW9kZWxJbnB1dC5UaGFua3NMZXR0ZXJJZCA9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgIG1zZyArPSB0aGlzLm1vZGVsSW5wdXQuVGhhbmtzTGV0dGVySWQ7XHJcbiAgICAgICAgICAgICAgICBtc2cgKz0gXCI8YnI+UGxlYXNlIHNlbGVjdCBwcmludCB0ZW1wbGF0ZVwiO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuUHJpbnRlcklkID09IG51bGwgfHwgdGhpcy5tb2RlbElucHV0LlByaW50ZXJJZCA9PSBcIlwiIHx8IHRoaXMubW9kZWxJbnB1dC5QcmludGVySWQgPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgICAgICBtc2cgKz0gXCI8YnI+UGxlYXNlIHNldCBwcmludGVyIG5hbWUgaW4gZGF0YWJhc2VcIjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LlJlY2llcHRObyA9PSBudWxsIHx8IHRoaXMubW9kZWxJbnB1dC5SZWNpZXB0Tm8gPT0gXCJcIiB8fCB0aGlzLm1vZGVsSW5wdXQuUmVjaWVwdE5vID09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgbXNnICs9IFwiPGJyPlJlY2VpcHQgbm8gaXMgbm90IHNldFwiO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdExpbmVzLmxlbmd0aCA9PSAwKSB7XHJcbiAgICAgICAgICAgICAgICBtc2cgKz0gXCI8YnI+UGxlYXNlIGF0bGVhc3Qgb25lIGFtb3VudCBkZXRhaWwgaW4gZ3JpZFwiO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgbWVzc2FnZTogbXNnLFxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAvL31cclxuICAgIH1cclxuXHJcbiAgICBkZWxNb2RlbChNb2RlbE9iaik6IG9ic2VydmFibGUge1xyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0TGluZXMubGVuZ3RoID4gMSkge1xyXG4gICAgICAgICAgICB2YXIgaW5kZXggPSAwO1xyXG4gICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdExpbmVzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcyA9PSBNb2RlbE9iaikge1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgaW5kZXggPSBpbmRleCArIDE7XHJcblxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LlJlY2VpcHRMaW5lcy5zcGxpY2UoaW5kZXgsIDEpO1xyXG4gICAgICAgICAgICB0aGlzLkJpbmRUb3RhbCgpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIEJpbmRUb3RhbCgpIHtcclxuICAgICAgICB2YXIgdHRvdGFsID0gMDtcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgIGpRdWVyeS5lYWNoKHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0TGluZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgdHRvdGFsICs9IHBhcnNlRmxvYXQodGhpcy5BbW91bnQpO1xyXG5cclxuICAgICAgICB9KTtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuVG90YWwgPSB0dG90YWw7XHJcblxyXG4gICAgICAgIHZhciB2RGF0ZSA9IHRoaXMubW9kZWxJbnB1dC5WYWx1ZURhdGU7XHJcbiAgICAgICAgY29uc29sZS5sb2codkRhdGUpO1xyXG4gICAgICAgIGlmICh2RGF0ZSA9PSBudWxsIHx8IHZEYXRlID09IFwiXCIpIHZEYXRlID0gdGhpcy5EZWZhdWx0RGF0ZTtcclxuICAgICAgICB2YXIgY3VySUQgPSB0aGlzLm1vZGVsSW5wdXQuQ3VycmVuY3lJZDtcclxuICAgICAgICAvL2FsZXJ0KGN1cklEKTtcclxuICAgICAgICB0aGlzLl9SZWNpZXB0U2VydmljZS5HZXRMZWFkY3VycmVuY3koY3VySUQsIFwiTklTXCIsIHZEYXRlKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcblxyXG4gICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcblxyXG4gICAgICAgICAgICAgICAgLy92YXIgbiA9IG51bS50b0ZpeGVkKDIpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LlRvdGFsSW5MZWFkQ3VycmVudCA9IHBhcnNlRmxvYXQocmVzcG9uc2UuRGF0YSkgKiB0dG90YWw7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuVG90YWxJbkxlYWRDdXJyZW50ID0gdGhpcy5tb2RlbElucHV0LlRvdGFsSW5MZWFkQ3VycmVudC50b0ZpeGVkKDIpO1xyXG5cclxuICAgICAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0TGluZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgICAgICAvL3R0b3RhbCArPSBwYXJzZUZsb2F0KHRoaXMuQW1vdW50KTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLkFtb3VudEluTGVhZEN1cnJlbnQgPSBwYXJzZUZsb2F0KHJlc3BvbnNlLkRhdGEpICogcGFyc2VGbG9hdCh0aGlzLkFtb3VudCk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5BbW91bnRJbkxlYWRDdXJyZW50ID0gdGhpcy5BbW91bnRJbkxlYWRDdXJyZW50LnRvRml4ZWQoMik7XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuICAgICAgICBcclxuICAgIH1cclxuICAgIGNyZWF0ZVJlY2VpcHRQREYoKSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5QcmludFJlY2llcHRObyAhPSBudWxsKSB7XHJcbiAgICAgICAgICAgIHZhciBSZWNpcHRfTm8gPSB0aGlzLm1vZGVsSW5wdXQuUHJpbnRSZWNpZXB0Tm87XHJcbiAgICAgICAgICAgIHZhciBSZWNpZXB0X1R5cGUgPSB0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdFR5cGVJZDtcclxuICAgICAgICAgICAgdmFyIEN1c3RvbWVyX0lkID0gdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQ7XHJcbiAgICAgICAgICAgIHZhciBUaGFua3NMZXR0ZXJfSWQgPSB0aGlzLm1vZGVsSW5wdXQuVGhhbmtzTGV0dGVySWQ7XHJcbiAgICAgICAgICAgIHZhciBMZWFkQ3VycmVuY3lJZCA9IHRoaXMubW9kZWxJbnB1dC5DdXJyZW5jeUlkO1xyXG4gICAgICAgICAgICB0aGlzLl9SZWNpZXB0U2VydmljZS5DcmVhdGVSZWNlaXB0UGRmKEN1c3RvbWVyX0lkLCBUaGFua3NMZXR0ZXJfSWQsIFJlY2lwdF9ObywgUmVjaWVwdF9UeXBlLCBMZWFkQ3VycmVuY3lJZCkuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBsID0gcmVzcG9uc2UuRGF0YS50b1N0cmluZygpLnN1YnN0cmluZygwLCA1KTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuRGF0YS50b1N0cmluZygpLnN1YnN0cmluZygwLCA1KSA9PSBcIkxpbms6XCIpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIFByaW50RGF0YSA9IHJlc3BvbnNlLkRhdGEudG9TdHJpbmcoKS5zdWJzdHJpbmcoNSwgcmVzcG9uc2UuRGF0YS50b1N0cmluZygpLmxlbmd0aCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciB3aW5kb3dPYmplY3QgPSB3aW5kb3cub3BlbihQcmludERhdGEsICdQcmludCcsICdzY3JvbGxiYXJzPXllcyxyZXNpemFibGU9eWVzLHdpZHRoPTEwNTAsaGVpZ2h0PTY1MCcpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL3dpbmRvd09iamVjdC5kb2N1bWVudC53cml0ZShQcmludERhdGEpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL3dpbmRvd09iamVjdC5kb2N1bWVudC5jbG9zZSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBEdXBNb2RlbChNb2RlbE9iaikge1xyXG4gICAgICAgIHZhciBNT2JqID0ge307XHJcbiAgICAgICAgdGhpcy5Sb3dDb3VudCsrO1xyXG4gICAgICAgIE1vZGVsT2JqLlJlY2llcHRSb1dJRCA9IHRoaXMuUm93Q291bnQ7XHJcbiAgICAgICAgTU9iaiA9IE1vZGVsT2JqO1xyXG4gICAgICAgIFxyXG4gICAgICAgIHZhciBWZGF0ZSA9IE1PYmouVmFsdWVEYXRlLnNwbGl0KCctJyk7XHJcbiAgICAgICAgdmFyIE5ld1ZEYXRlID0gbmV3IERhdGUocGFyc2VJbnQoIFZkYXRlWzJdKSxwYXJzZUludChWZGF0ZVsxXSkscGFyc2VJbnQoVmRhdGVbMF0pKTtcclxuICAgICAgICBOZXdWRGF0ZS5zZXRNb250aChOZXdWRGF0ZS5nZXRNb250aCgpKTtcclxuICAgICAgICB2YXIgTlZEYXRlID0gbW9tZW50KE5ld1ZEYXRlKS5mb3JtYXQoJ0RELU1NLVlZWVknKTtcclxuICAgICAgICAvL3ZhciBNb250aCA9IHBhcnNlSW50KFZkYXRlWzFdKSArIDE7XHJcbiAgICAgICAgLy9NT2JqLlZhbHVlRGF0ZSA9IE5ld1ZEYXRlO1xyXG4gICAgICAgIHZhciBEdXBPYmogPSB7IEFtb3VudDogTW9kZWxPYmouQW1vdW50LCBWYWx1ZURhdGU6IE5ld1ZEYXRlLCBQYXlUeXBlSWQ6IE1vZGVsT2JqLlBheVR5cGVJZCwgQWNjb3VudElkOiBNb2RlbE9iai5BY2NvdW50SWQsIEFjY291bnRObzogTW9kZWxPYmouQWNjb3VudE5vLCBCcmFuY2hObzogTW9kZWxPYmouQnJhbmNoTm8sIEJhbms6IE1vZGVsT2JqLkJhbmssIENyZWRpdENhcmRUeXBlOiBNb2RlbE9iai5DcmVkaXRDYXJkVHlwZSwgRG9uYXRpb25UeXBlSWQ6IE1vZGVsT2JqLkRvbmF0aW9uVHlwZUlkLCBQcm9qZWN0Q2F0ZWdvcnlJZDogTW9kZWxPYmouUHJvamVjdENhdGVnb3J5SWQsIFByb2plY3RJZDogTW9kZWxPYmouUHJvamVjdElkLCBSZWZlcmVuY2VEYXRlOiBNb2RlbE9iai5SZWZlcmVuY2VEYXRlLCBGb3JfSW52b2ljZTogTW9kZWxPYmouRm9yX0ludm9pY2UsIFJlY2lldmVkQ3VzdElkOiBNb2RlbE9iai5SZWNpZXZlZEN1c3RJZCwgUGF5ZWQ6IE1vZGVsT2JqLlBheWVkLCBEZXBvc2l0ZVJlbWFyazogTW9kZWxPYmouRGVwb3NpdGVSZW1hcmsgIH07XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LlJlY2VpcHRMaW5lcy5wdXNoKER1cE9iaik7XHJcbiAgICAgICAgdmFyIGluZGV4ID0gMDtcclxuICAgICAgICB2YXIgVG90YWxSb3dzPXRoaXMubW9kZWxJbnB1dC5SZWNlaXB0TGluZXMubGVuZ3RoO1xyXG4gICAgICAgIGpRdWVyeS5lYWNoKHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0TGluZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgaWYgKGluZGV4ID09IChUb3RhbFJvd3MgLSAxKSkge1xyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICB0aGlzLlZhbHVlRGF0ZSA9IE5WRGF0ZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgaW5kZXgrKztcclxuICAgICAgICB9KTtcclxuICAgICAgICB0aGlzLkJpbmRUb3RhbCgpO1xyXG4gICAgfVxyXG5cclxuICAgIFZhbGlkYXRlUm93TW9kZWwoQ3VycmVudE1vZGVsLCBtc2cpIHtcclxuICAgICAgICAvL21zZyA9IFwiXCI7XHJcbiAgICAgICAgdmFyIElzVmFsaWREYXRhID0gdHJ1ZTtcclxuICAgICAgICBpZiAoQ3VycmVudE1vZGVsLlZhbHVlRGF0ZSAhPSBcIlwiKSB7XHJcbiAgICAgICAgICAgIGlmIChtb21lbnQoQ3VycmVudE1vZGVsLlZhbHVlRGF0ZSwgXCJERC1NTS1ZWVlZXCIsIHRydWUpLmlzVmFsaWQoKSA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7IG1lc3NhZ2U6IFwiVmFsdWUgRGF0ZSBpcyBub3QgdmFsaWRcIiB9KTtcclxuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoQ3VycmVudE1vZGVsLlJlZmVyZW5jZURhdGUgIT0gXCJcIikge1xyXG4gICAgICAgICAgICBpZiAobW9tZW50KEN1cnJlbnRNb2RlbC5SZWZlcmVuY2VEYXRlLCBcIkRELU1NLVlZWVlcIiwgdHJ1ZSkuaXNWYWxpZCgpID09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHsgbWVzc2FnZTogXCJSZWZlcmVuY2UgRGF0ZSBpcyBub3QgdmFsaWRcIiB9KTtcclxuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgICAgICAgICAgLy92YXIgbXNnID0gXCJcIjtcclxuICAgICAgICAgICAgaWYgKEN1cnJlbnRNb2RlbC5BbW91bnQgPT0gbnVsbCB8fCBDdXJyZW50TW9kZWwuQW1vdW50ID09IFwiXCIgfHwgQ3VycmVudE1vZGVsLkFtb3VudCA9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgIElzVmFsaWREYXRhID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICBtc2cgKz0gXCI8YnI+UGxlYXNlIGVudGVyIGFtb3VudFwiO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChDdXJyZW50TW9kZWwuUGF5VHlwZUlkID09IG51bGwgfHwgQ3VycmVudE1vZGVsLlBheVR5cGVJZCA9PSBcIlwiIHx8IEN1cnJlbnRNb2RlbC5QYXlUeXBlSWQgPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgICAgICBJc1ZhbGlkRGF0YSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgbXNnICs9IFwiPGJyPlBsZWFzZSBzZWxlY3QgcGF5dHlwZVwiO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChDdXJyZW50TW9kZWwuUHJvamVjdElkID09IG51bGwgfHwgQ3VycmVudE1vZGVsLlByb2plY3RJZCA9PSBcIlwiIHx8IEN1cnJlbnRNb2RlbC5Qcm9qZWN0SWQgPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgICAgICBJc1ZhbGlkRGF0YSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgbXNnICs9IFwiPGJyPlBsZWFzZSBzZWxlY3QgcHJvamVjdFwiO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChDdXJyZW50TW9kZWwuRG9uYXRpb25UeXBlSWQgPT0gbnVsbCB8fCBDdXJyZW50TW9kZWwuRG9uYXRpb25UeXBlSWQgPT0gXCJcIiB8fCBDdXJyZW50TW9kZWwuRG9uYXRpb25UeXBlSWQgPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgICAgICBJc1ZhbGlkRGF0YSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgbXNnICs9IFwiPGJyPlBsZWFzZSBzZWxlY3QgZ29hbFwiO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChDdXJyZW50TW9kZWwuQWNjb3VudElkID09IG51bGwgfHwgQ3VycmVudE1vZGVsLkFjY291bnRJZCA9PSBcIlwiIHx8IEN1cnJlbnRNb2RlbC5BY2NvdW50SWQgPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgICAgICBJc1ZhbGlkRGF0YSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgbXNnICs9IFwiPGJyPlBsZWFzZSBzZWxlY3QgYWNjb3VudFwiO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChDdXJyZW50TW9kZWwuUGF5VHlwZUlkID09IDgpIC8vQmFua1xyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICBpZiAoQ3VycmVudE1vZGVsLkFjY291bnRObyA9PSBudWxsIHx8IEN1cnJlbnRNb2RlbC5BY2NvdW50Tm8gPT0gXCJcIiB8fCBDdXJyZW50TW9kZWwuQWNjb3VudE5vID09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgICAgIElzVmFsaWREYXRhID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgbXNnICs9IFwiPGJyPlBsZWFzZSBlbnRlciBhY2NvdW50IG5vXCI7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBpZiAoQ3VycmVudE1vZGVsLkJyYW5jaE5vID09IG51bGwgfHwgQ3VycmVudE1vZGVsLkJyYW5jaE5vID09IFwiXCIgfHwgQ3VycmVudE1vZGVsLkJyYW5jaE5vID09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgICAgIElzVmFsaWREYXRhID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgbXNnICs9IFwiPGJyPlBsZWFzZSBzZWxlY3QgYnJhbmNoIG5vXCI7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBpZiAoQ3VycmVudE1vZGVsLkJhbmsgPT0gbnVsbCB8fCBDdXJyZW50TW9kZWwuQmFuayA9PSBcIlwiIHx8IEN1cnJlbnRNb2RlbC5CYW5rID09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgICAgIElzVmFsaWREYXRhID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgbXNnICs9IFwiPGJyPlBsZWFzZSBlbnRlciBiYW5rXCI7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKEN1cnJlbnRNb2RlbC5QYXlUeXBlSWQgPT0gMykgLy9DcmVkaXRcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgaWYgKEN1cnJlbnRNb2RlbC5DcmVkaXRDYXJkVHlwZSA9PSBudWxsIHx8IEN1cnJlbnRNb2RlbC5DcmVkaXRDYXJkVHlwZSA9PSBcIlwiIHx8IEN1cnJlbnRNb2RlbC5DcmVkaXRDYXJkVHlwZSA9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgICAgICBJc1ZhbGlkRGF0YSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIG1zZyArPSBcIjxicj5QbGVhc2UgZW50ZXIgQ3JlZGl0Q2FyZFwiO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICBpZiAoSXNWYWxpZERhdGEgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IG1zZyxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gSXNWYWxpZERhdGE7XHJcbiAgICAgICAgXHJcbiAgICB9XHJcblxyXG4gICAgVmFsaWRhdGVQcm9kdWN0Um93TW9kZWwoQ3VycmVudE1vZGVsLCBtc2cscm93bm8pIHtcclxuICAgICAgICAvL21zZyA9IFwiXCI7XHJcbiAgICAgICAgdmFyIElzVmFsaWREYXRhID0gdHJ1ZTtcclxuICAgICAgICBcclxuICAgICAgICAvL3ZhciBtc2cgPSBcIlwiO1xyXG4gICAgICAgIGlmIChDdXJyZW50TW9kZWwuUHJvZHVjdE5vID09IG51bGwgfHwgQ3VycmVudE1vZGVsLlByb2R1Y3RObyA9PSBcIlwiIHx8IEN1cnJlbnRNb2RlbC5Qcm9kdWN0Tm8gPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgIElzVmFsaWREYXRhID0gZmFsc2U7XHJcbiAgICAgICAgICAgIG1zZyArPSBcIjxicj5QbGVhc2UgZW50ZXIgcHJvZHVjdCBub1wiO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoQ3VycmVudE1vZGVsLlByb2R1Y3ROYW1lID09IG51bGwgfHwgQ3VycmVudE1vZGVsLlByb2R1Y3ROYW1lID09IFwiXCIgfHwgQ3VycmVudE1vZGVsLlByb2R1Y3ROYW1lID09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICBJc1ZhbGlkRGF0YSA9IGZhbHNlO1xyXG4gICAgICAgICAgICBtc2cgKz0gXCI8YnI+UGxlYXNlIGVudGVyIHByb2R1Y3QgbmFtZVwiO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoQ3VycmVudE1vZGVsLlByaWNlID09IG51bGwgfHwgQ3VycmVudE1vZGVsLlByaWNlID09IFwiXCIgfHwgQ3VycmVudE1vZGVsLlByaWNlID09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICBJc1ZhbGlkRGF0YSA9IGZhbHNlO1xyXG4gICAgICAgICAgICBtc2cgKz0gXCI8YnI+UGxlYXNlIGVudGVyIHByaWNlXCI7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChDdXJyZW50TW9kZWwuUXR5ID09IG51bGwgfHwgQ3VycmVudE1vZGVsLlF0eSA9PSBcIlwiIHx8IEN1cnJlbnRNb2RlbC5RdHkgPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgIElzVmFsaWREYXRhID0gZmFsc2U7XHJcbiAgICAgICAgICAgIG1zZyArPSBcIjxicj5QbGVhc2UgZW50ZXIgcXVhbnRpdHlcIjtcclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcblxyXG4gICAgICAgIGlmIChJc1ZhbGlkRGF0YSA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgIG1lc3NhZ2U6IG1zZyxcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBJc1ZhbGlkRGF0YTtcclxuXHJcbiAgICB9XHJcblxyXG5cclxuICAgIEFkZFJlY2VpcHRMaW5lKEN1cnJlbnRNb2RlbCkge1xyXG4gICAgICAgIC8vIHRoaXMubW9kZWxJbnB1dC5BZGRNb2RlbC5CYW5rID0galF1ZXJ5KFwiI0JhbmtcIikudmFsKCk7XHJcbiAgICAgICAgaWYgKHRoaXMuVmFsaWRhdGVSb3dNb2RlbChDdXJyZW50TW9kZWwsIFwiXCIpKSB7XHJcbiAgICAgICAgICAgIHZhciBNVGV4dCA9IFwiXCI7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLkxhbmcgPT0gXCJlblwiKSB7XHJcbiAgICAgICAgICAgICAgICBNVGV4dCA9IFwiTW9yZVwiO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgTVRleHQgPSBcIteZ15XXqteoXCI7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdmFyIE1vZGVsT2JqID0ge1xyXG4gICAgICAgICAgICAgICAgQW1vdW50OiAwLCBWYWx1ZURhdGU6IHRoaXMuRGVmYXVsdERhdGUsIFBheVR5cGVJZDogXCIxXCIsIEFjY291bnRJZDogXCJcIiwgQWNjb3VudE5vOiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgQnJhbmNoTm86IFwiXCIsIEJhbms6IFwiXCIsIENyZWRpdENhcmRUeXBlOiBcIlwiLCBEb25hdGlvblR5cGVJZDogXCJcIiwgUHJvamVjdENhdGVnb3J5SWQ6IFwiXCIsIFByb2plY3RJZDogXCJcIiwgUmVmZXJlbmNlRGF0ZTogdGhpcy5EZWZhdWx0RGF0ZSxcclxuICAgICAgICAgICAgICAgIEZvcl9JbnZvaWNlOiBcIlwiLCBSZWNpZXZlZEN1c3RJZDogXCJcIiwgUGF5ZWQ6IGZhbHNlLCBEZXBvc2l0ZVJlbWFyazogXCJcIiwgU2hvd01vcmU6IGZhbHNlLCBTaG93TW9yZVRleHQ6IE1UZXh0LFxyXG4gICAgICAgICAgICAgICAgQ2FzaENTUzogXCJncmV5XCIsIENyZWRpdENTUzogXCJ3aGl0ZVwiLCBCYW5rQ1NTOiBcIndoaXRlXCIsIE90aGVyQ1NTOiBcIndoaXRlXCIsIElzU2hvd090aGVyczogZmFsc2UsIElzQ3JlZGl0U2hvdzogZmFsc2UsIElzQmFua0RldFNob3c6IGZhbHNlXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIEN1cnJlbnRNb2RlbC5SZWNpZXZlZEN1c3RJZCA9IHRoaXMuQ3VzdElkO1xyXG4gICAgICAgICAgIC8vIGRlYnVnZ2VyO1xyXG4gICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdExpbmVzLnB1c2goTW9kZWxPYmopO1xyXG4gICAgICAgICAgICB0aGlzLkJpbmRUb3RhbCgpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIFZhbGlkYXRlUGFzdGVUZXh0KCkge1xyXG4gICAgICAgIHZhciBTcGxpdFRleHQgPSB0aGlzLlBhc3RlVGV4dC5zcGxpdCgvW1xcdF0rLyk7XHJcbiAgICAgICAgdmFyIElzVmFsaWREYXRhID0gdHJ1ZTtcclxuICAgICAgICB2YXIgbXNnID0gXCJcIjtcclxuICAgICAgIC8vIGRlYnVnZ2VyO1xyXG4gICAgICAgIGlmIChTcGxpdFRleHQubGVuZ3RoID09IDQpIHtcclxuICAgICAgICAgICAgaWYgKGpRdWVyeS5pc051bWVyaWMoU3BsaXRUZXh0WzFdLnRyaW0oKSkgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgIElzVmFsaWREYXRhID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICBtc2cgPSBcIlF1YW50aXR5IG11c3QgYmUgbnVtZXJpYyBvbmx5XCI7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdmFyIFNwbGl0UHJpY2UgPSBTcGxpdFRleHRbM10udHJpbSgpLnNwbGl0KC9bXFxzXSsvKTtcclxuICAgICAgICAgICAgaWYgKFNwbGl0UHJpY2UubGVuZ3RoID09IDIpIHtcclxuICAgICAgICAgICAgICAgIGlmIChqUXVlcnkuaXNOdW1lcmljKFNwbGl0UHJpY2VbMV0udHJpbSgpKSA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIElzVmFsaWREYXRhID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgbXNnID0gXCJQcmljZSBtdXN0IGJlIG51bWVyaWMgb25seVwiO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgSXNWYWxpZERhdGEgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIG1zZyA9IFwiUGxlYXNlIGVudGVyIHRleHQgaW4gUHJvZHVjdCBObyBcXHQgUXVhbnRpdHkgXFx0IFByb2R1Y3QgTmFtZSBcXHQgUHJpY2UgZm9ybWF0IG9ubHlcIjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgSXNWYWxpZERhdGEgPSBmYWxzZTtcclxuICAgICAgICAgICAgbXNnID0gXCJQbGVhc2UgZW50ZXIgdGV4dCBpbiBQcm9kdWN0IE5vIFxcdCBRdWFudGl0eSBcXHQgUHJvZHVjdCBOYW1lIFxcdCBQcmljZSBmb3JtYXQgb25seVwiO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoSXNWYWxpZERhdGEgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICBtZXNzYWdlOiBtc2csXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gSXNWYWxpZERhdGE7XHJcbiAgICB9XHJcbiAgICBHZXRWYWxpZGF0ZVRleHQoa2V5Q29kZSkge1xyXG4gICAgICAgIFxyXG4gICAgICAgIFxyXG4gICAgICAgIGlmIChrZXlDb2RlID09IDEzKSB7XHJcbiAgICAgICAgICAgIHRoaXMuUGFzdGVUZXh0ID0galF1ZXJ5KFwiI1Bhc3RlVGV4dFwiKS52YWwoKTtcclxuICAgICAgICAgICAgaWYgKHRoaXMuVmFsaWRhdGVQYXN0ZVRleHQoKSkge1xyXG4gICAgICAgICAgICAgICAgdmFyIFNwbGl0VGV4dCA9IHRoaXMuUGFzdGVUZXh0LnNwbGl0KC9bXFx0XSsvKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuUG9wUHJvZE9iai5Qcm9kdWN0Tm8gPSBTcGxpdFRleHRbMF0udHJpbSgpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5Qb3BQcm9kT2JqLlF0eSA9IHBhcnNlRmxvYXQoU3BsaXRUZXh0WzFdLnRyaW0oKSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLlBvcFByb2RPYmouUHJvZHVjdE5hbWUgPSBTcGxpdFRleHRbMl0udHJpbSgpO1xyXG4gICAgICAgICAgICAgICAgdmFyIFNwbGl0UHJpY2UgPSBTcGxpdFRleHRbM10udHJpbSgpLnNwbGl0KC9bXFxzXSsvKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuUG9wUHJvZE9iai5QcmljZSA9IHBhcnNlRmxvYXQoU3BsaXRQcmljZVsxXS50cmltKCkpLnRvRml4ZWQoMik7XHJcbiAgICAgICAgICAgICAgICB0aGlzLlBvcFByb2RPYmouVG90YWwgPSAocGFyc2VGbG9hdChTcGxpdFByaWNlWzFdLnRyaW0oKSkgKiBwYXJzZUZsb2F0KFNwbGl0VGV4dFsxXS50cmltKCkpKS50b0ZpeGVkKDIpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5QYXN0ZVRleHQgPSBcIlwiO1xyXG4gICAgICAgICAgICAgICAgalF1ZXJ5KCcjUGFzdGVUZXh0TW9kYWwnKS5jbG9zZU1vZGFsKCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLkJpbmRQcm9kVG90YWwoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIE9wZW5Qcm9kdWN0cyhQcm9kT2JqKSB7XHJcbiAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJUZW1wUmVjZWlwdElkXCIsIHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0VHlwZUlkKTtcclxuICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2Uuc2V0Q29va2llKFwiVGVtcFJvd05vXCIsIFByb2RPYmouUm93Tm8sMTApO1xyXG4gICAgICAgIHZhciBFbXBJZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiZW1wbG95ZWVpZFwiKTtcclxuICAgICAgICB2YXIgT3JnSWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShFbXBJZCArIFwiX09yZ0lkXCIpO1xyXG4gICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dCAhPSBudWxsKSB7XHJcbiAgICAgICAgICAgIHZhciBqZGF0YSA9IEpTT04uc3RyaW5naWZ5KHRoaXMubW9kZWxJbnB1dCk7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2Uuc2V0Q29va2llKEVtcElkICsgXCJfXCIgKyBPcmdJZCtcIl9SZWNlaXB0Q3JlYXRlX0NhY2hlXCIsIGpkYXRhLCAxMCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2Uuc2V0Q29va2llKEVtcElkICsgXCJfXCIgKyBPcmdJZCtcIl9SZWNlaXB0Q3JlYXRlX0lzU2hvd1Byb2R1Y3RzXCIsIHRoaXMuSXNTaG93UHJvZHVjdHMsIDEwKTtcclxuICAgICAgICBkb2N1bWVudC5sb2NhdGlvbiA9IHRoaXMuYmFzZVVybCArIFwiU2VhcmNoUHJvZHVjdHMvXCIgKyB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCtcIi9SZWNlaXB0Q3JlYXRlXCI7XHJcbiAgICB9XHJcblxyXG4gICAgT3BlblBhc3RlTW9kYWwoUHJvZE9iaikge1xyXG4gICAgICAgXHJcbiAgICAgICAgaWYgKChQcm9kT2JqLlByb2R1Y3RObyAhPSB1bmRlZmluZWQgfHwgUHJvZE9iai5Qcm9kdWN0Tm8gIT0gbnVsbCB8fCBQcm9kT2JqLlByb2R1Y3RObyAhPSBcIlwiKVxyXG4gICAgICAgICAgICAmJiAoUHJvZE9iai5Qcm9kdWN0TmFtZSAhPSB1bmRlZmluZWQgfHwgUHJvZE9iai5Qcm9kdWN0TmFtZSAhPSBudWxsIHx8IFByb2RPYmouUHJvZHVjdE5hbWUgIT0gXCJcIilcclxuICAgICAgICAgICAgJiYgKFByb2RPYmouUHJpY2UgIT0gdW5kZWZpbmVkIHx8IFByb2RPYmouUHJpY2UgIT0gbnVsbCB8fCBQcm9kT2JqLlByaWNlICE9IFwiXCIpKSB7XHJcbiAgICAgICAgICAgIHRoaXMuUGFzdGVUZXh0ID0gXCJcIjtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLlBhc3RlVGV4dCA9IFByb2RPYmouUHJvZHVjdE5vICsgXCIgfCBcIiArIFByb2RPYmouUHJvZHVjdE5hbWUgKyBcIiB8IFwiICsgUHJvZE9iai5QcmljZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5Qb3BQcm9kT2JqID0gUHJvZE9iajtcclxuICAgICAgICBcclxuICAgICAgICBqUXVlcnkoJyNQYXN0ZVRleHRNb2RhbCcpLm9wZW5Nb2RhbCgpO1xyXG4gICAgfVxyXG4gICAgT3BlbkN1c3RTZWFyY2goKSB7XHJcbiAgICAgICAgdGhpcy5JUG9wVXBPcGVuID0gdHJ1ZTtcclxuICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcIlRlbXBSZWNlaXB0SWRcIiwgdGhpcy5tb2RlbElucHV0LlJlY2VpcHRUeXBlSWQpO1xyXG4gICAgICAgIHZhciBFbXBJZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiZW1wbG95ZWVpZFwiKTtcclxuICAgICAgICB2YXIgT3JnSWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShFbXBJZCArIFwiX09yZ0lkXCIpO1xyXG4gICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dCAhPSBudWxsKSB7XHJcbiAgICAgICAgICAgIHZhciBqZGF0YSA9IEpTT04uc3RyaW5naWZ5KHRoaXMubW9kZWxJbnB1dCk7XHJcblxyXG4gICAgICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2Uuc2V0Q29va2llKEVtcElkICsgXCJfXCIgKyBPcmdJZCtcIl9SZWNlaXB0Q3JlYXRlX0NhY2hlXCIsIGpkYXRhLCAxMCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5zZXRDb29raWUoRW1wSWQgKyBcIl9cIiArIE9yZ0lkK1wiX1JlY2VpcHRDcmVhdGVfSXNTaG93UHJvZHVjdHNcIiwgdGhpcy5Jc1Nob3dQcm9kdWN0cywgMTApO1xyXG4gICAgICAgIGRvY3VtZW50LmxvY2F0aW9uID0gdGhpcy5iYXNlVXJsICsgXCJDdXN0b21lci9TZWFyY2gvMC9SZWNlaXB0Q3JlYXRlL1wiICsgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQ7XHJcbiAgICAgICAgLy9qUXVlcnkoJyNDdXN0U2VhcmNoTW9kYWwgIC5tb2RhbC1jb250ZW50JykuaHRtbCgnPG9iamVjdCBkYXRhPVwiJyArIHRoaXMuYmFzZVVybCsnQ3VzdG9tZXIvU2VhcmNoLzEvUmVjZWlwdENyZWF0ZVwiIHN0eWxlPVwid2lkdGg6MTAwJTtoZWlnaHQ6NTAwcHhcIi8+Jyk7XHJcbiAgICAgICAgLy9qUXVlcnkoJyNDdXN0U2VhcmNoTW9kYWwnKS5vcGVuTW9kYWwoKTtcclxuXHJcbiAgICB9XHJcbiAgICBPcGVuTm90ZXMoKSB7XHJcblxyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgLy9pZiAodGhpcy5JUG9wVXBPcGVuID09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgIGpRdWVyeSgnI05vdGVNb2RhbCcpLm9wZW5Nb2RhbCgpO1xyXG4gICAgICAgIC8vfVxyXG4gICAgICAgIC8vZWxzZSB7XHJcbiAgICAgICAgLy8gICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQgPSB0aGlzLl9yb3V0ZVBhcmFtcy5wYXJhbXMuSWQ7XHJcbiAgICAgICAgLy8gICAgd2luZG93Lm9wZW4odGhpcy5iYXNlVXJsICsgXCJSZWNlaXB0Q3JlYXRlL1wiICsgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQgKyBcIi9cIiArIHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0VHlwZUlkLCBcIl9zZWxmXCIpO1xyXG4gICAgICAgICAgICBcclxuICAgICAgICAvLyAgICBqUXVlcnkoJyNDdXN0U2VhcmNoTW9kYWwnKS5jbG9zZU1vZGFsKCk7XHJcbiAgICAgICAgLy8gICAgalF1ZXJ5KFwiLmxlYW4tb3ZlcmxheVwiKS5jc3MoeyBcImRpc3BsYXlcIjogXCJub25lXCIgfSk7XHJcbiAgICAgICAgLy8gICAgdGhpcy5zZXRkZWZhdWx0bW9kZSgpO1xyXG4gICAgICAgIC8vfVxyXG4gICAgfVxyXG4gICAgT3BlblRlbXBsYXRlcygpIHtcclxuICAgICAgICBqUXVlcnkoJyNUZW1wbGF0ZU1vZGFsJykub3Blbk1vZGFsKCk7XHJcbiAgICB9XHJcbiAgICBDaG9vc2VOb3RlKG9iamN0KSB7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyTm90ZSA9IG9iamN0LlRleHQ7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyTm90ZUlkID0gb2JqY3QuVmFsdWU7XHJcbiAgICB9XHJcbiAgICBDaG9vc2VUaGFua3NMZXR0ZXJzKG9iamN0KSB7XHJcbiAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuVGhhbmtzTGV0dGVyTmFtZSA9IG9iamN0LlRleHQ7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LlRoYW5rc0xldHRlcklkID0gb2JqY3QuVmFsdWU7XHJcbiAgICB9XHJcbiAgICBHZXRDdXN0b21lckRldGFpbCgpIHtcclxuICAgICAgICB2YXIgQ3VzdElkID0gdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQ7XHJcbiAgICAgICAgdGhpcy5fQ3VzdG9tZXJTZXJ2aWNlLkdldENvbXBsZXRlQ3VzdERldChDdXN0SWQpLnN1YnNjcmliZShyZXNwPT4ge1xyXG4gICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICB2YXIgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3ApO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICByZXNwb25zZSA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9BZGRyZXNzZXMgPSByZXNwb25zZS5DdXN0b21lckFkZHJlc3NlcztcclxuICAgICAgICAgICAgICAgIHZhciBNYWluYWRkcmVzcztcclxuICAgICAgICAgICAgICAgIGpRdWVyeS5lYWNoKHJlc3BvbnNlLkN1c3RvbWVyQWRkcmVzc2VzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuTWFpbkFkZHJlc3MgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBNYWluYWRkcmVzcyA9IHRoaXMuQWRkcmVzc0lkO1xyXG4gICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQWRkcmVzc0lkID0gTWFpbmFkZHJlc3M7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCA9IHJlc3BvbnNlLkN1c3RvbWVySWQ7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdExpbmVzWzBdLlJlY2lldmVkQ3VzdElkID0gcmVzcG9uc2UuQ3VzdG9tZXJJZDtcclxuICAgICAgICAgICAgICAgIHRoaXMuQ3VzdElkID0gcmVzcG9uc2UuQ3VzdG9tZXJJZDtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lck5hbWUgPSByZXNwb25zZS5sbmFtZSArIFwiIFwiICsgcmVzcG9uc2UuZm5hbWU7XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIFxyXG4gICAgfVxyXG4gICAgXHJcbiAgICBDaG9vc2VQYXlUeXBlKGRhdGFvYmplY3QsIHBUeXBlSWQpIHtcclxuICAgICAgIC8vIGRlYnVnZ2VyO1xyXG4gICAgICAgIGRhdGFvYmplY3QuQ2FzaENTUyA9IFwid2hpdGVcIlxyXG4gICAgICAgIGRhdGFvYmplY3QuQ3JlZGl0Q1NTID0gXCJ3aGl0ZVwiXHJcbiAgICAgICAgZGF0YW9iamVjdC5CYW5rQ1NTID0gXCJ3aGl0ZVwiXHJcbiAgICAgICAgZGF0YW9iamVjdC5PdGhlckNTUyA9IFwid2hpdGVcIlxyXG4gICAgICAgIGRhdGFvYmplY3QuSXNDcmVkaXRTaG93ID0gZmFsc2U7XHJcbiAgICAgICAgLy92YXIgcFR5cGVJZCA9IFwiXCI7XHJcbiAgICAgICAgaWYgKHBUeXBlSWQgIT0gMCkge1xyXG4gICAgICAgICAgICBkYXRhb2JqZWN0LlBheVR5cGVJZCA9IHBUeXBlSWQ7XHJcbiAgICAgICAgICAgIGlmIChwVHlwZUlkID09IDEpIHtcclxuICAgICAgICAgICAgICAgIGRhdGFvYmplY3QuQ2FzaENTUyA9IFwiZ3JleVwiO1xyXG4gICAgICAgICAgICAgICAgLy9kYXRhb2JqZWN0LklzQmFua0RldFNob3cgPT0gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSBpZiAocFR5cGVJZD09Mykge1xyXG4gICAgICAgICAgICAgICAgZGF0YW9iamVjdC5DcmVkaXRDU1MgPSBcImdyZXlcIjtcclxuICAgICAgICAgICAgICAgIC8vZGF0YW9iamVjdC5Jc0JhbmtEZXRTaG93ID09IHRydWU7XHJcbiAgICAgICAgICAgICAgICBkYXRhb2JqZWN0LklzQ3JlZGl0U2hvdyA9IHRydWU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSBpZiAocFR5cGVJZD09OCkvL1xyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICBkYXRhb2JqZWN0LkJhbmtDU1MgPSBcImdyZXlcIlxyXG4gICAgICAgICAgICAgIC8vICBkYXRhb2JqZWN0LklzQmFua0RldFNob3cgPT0gdHJ1ZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBkYXRhb2JqZWN0LklzU2hvd090aGVycyA9IGZhbHNlO1xyXG4gICAgICAgICAgICBcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZXtcclxuICAgICAgICAgICAgZGF0YW9iamVjdC5QYXlUeXBlSWQgPSAwO1xyXG4gICAgICAgICAgICBkYXRhb2JqZWN0LklzU2hvd090aGVycyA9IHRydWU7XHJcbiAgICAgICAgICAgIGRhdGFvYmplY3QuT3RoZXJDU1MgPSBcImdyZXlcIjtcclxuICAgICAgICAgICAgLy9kYXRhb2JqZWN0LklzQmFua0RldFNob3cgPT0gZmFsc2U7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAocFR5cGVJZCAhPSAxICYmIHBUeXBlSWQgIT0gMykvLyBOb3QgQ2FzaCBhbmQgbm90IENyZWRpdCBjYXJkXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBkYXRhb2JqZWN0LklzQmFua0RldFNob3cgPSB0cnVlO1xyXG4gICAgICAgICAgICBkYXRhb2JqZWN0LklzQ3JlZGl0U2hvdyA9IGZhbHNlO1xyXG4gICAgICAgICAgICB0aGlzLkJpbmRBdXRvQ29tcGxldGVCYW5rKCk7XHJcblxyXG4gICAgICAgIH0gZWxzZSBpZiAocFR5cGVJZCA9PSAzKSB7XHJcbiAgICAgICAgICAgIGRhdGFvYmplY3QuSXNDcmVkaXRTaG93ID0gdHJ1ZTtcclxuICAgICAgICAgICAgZGF0YW9iamVjdC5Jc0JhbmtEZXRTaG93ID0gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Ugey8vIE9ubHkgRm9yIENhc2hcclxuICAgICAgICAgICAgZGF0YW9iamVjdC5Jc0JhbmtEZXRTaG93ID0gZmFsc2U7XHJcbiAgICAgICAgICAgIGRhdGFvYmplY3QuSXNDcmVkaXRTaG93ID0gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIEJpbmRQcm9qZWN0cyhDYXRJZCkge1xyXG5cclxuICAgICAgICB0aGlzLkJpbmRQcm9qZWN0RnJvbVByb2pDYXQoQ2F0SWQpO1xyXG4gICAgfVxyXG4gICAgQmluZFByb2plY3RGcm9tUHJvakNhdChDYXRJZCkge1xyXG4gICAgICAgIHRoaXMuX1JlY2llcHRTZXJ2aWNlLkdldFByb2plY3RzKENhdElkKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fUHJvamVjdHMgPSByZXNwb25zZS5EYXRhO1xyXG5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBCaW5kQXV0b0NvbXBsZXRlQmFuaygpIHtcclxuICAgICAgICB0aGlzLl9SZWNpZXB0U2VydmljZS5HZXRCYW5rcygpLnN1YnNjcmliZShyZXNwPT4ge1xyXG4gICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICB2YXIgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3ApO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAvL3RoaXMuX0JhbmtzID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgIHZhciB0eXBlYWhlYWRTb3VyY2UgPSBbXTtcclxuICAgICAgICAgICAgICAvLyAgZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaChyZXNwb25zZS5EYXRhLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIG5ld3RlbXAgPSB7fTtcclxuICAgICAgICAgICAgICAgICAgICBuZXd0ZW1wLmlkID0gdGhpcy5WYWx1ZTtcclxuICAgICAgICAgICAgICAgICAgICBuZXd0ZW1wLm5hbWUgPSB0aGlzLlRleHQ7XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZWFoZWFkU291cmNlLnB1c2gobmV3dGVtcCk7XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX0JhbmtzID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgIGpRdWVyeSgnLkJhbmsnKS50eXBlYWhlYWQoe1xyXG4gICAgICAgICAgICAgICAgICAgIHNvdXJjZTogdHlwZWFoZWFkU291cmNlLFxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGFUeXBlOiBcIkpTT05cIixcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG4gICAgU2hvd0hpZGVQcm9kdWN0cygpIHtcclxuICAgICAgICBcclxuICAgICAgICBpZiAodGhpcy5Jc1Nob3dQcm9kdWN0cyA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdFByb2R1Y3RzID0gW107XHJcbiAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0UHJvZHVjdHMgPSBbeyBSb3dObzogXCIxXCIsIFByb2R1Y3RObzogXCJcIiwgUHJvZHVjdE5hbWU6IFwiXCIsIFByaWNlOiBcIjBcIiwgUXR5OiBcIjFcIiwgVG90YWw6IFwiMFwiIH1dO1xyXG4gICAgICAgICAgICB0aGlzLklzU2hvd1Byb2R1Y3RzID0gdHJ1ZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdFByb2R1Y3RzLmxlbmd0aCA9PSAwKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLklzU2hvd1Byb2R1Y3RzID0gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBDYW5hZGRQcm9kdWN0KHByb2RPYmopOiBib29sZWFuIHtcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgIFxyXG4gICAgICAgIHJldHVybiAocHJvZE9iai5Qcm9kdWN0Tm8gIT0gdW5kZWZpbmVkICYmIHByb2RPYmouUHJvZHVjdE5vICE9IFwiXCIpXHJcbiAgICAgICAgICAgICYmIChwcm9kT2JqLlByb2R1Y3ROYW1lICE9IHVuZGVmaW5lZCAmJiBwcm9kT2JqLlByb2R1Y3ROYW1lICE9IFwiXCIpXHJcbiAgICAgICAgICAgICYmIChwcm9kT2JqLlByaWNlICE9IHVuZGVmaW5lZCAmJiBwcm9kT2JqLlByaWNlICE9IFwiXCIpXHJcbiAgICAgICAgICAgICYmIChwcm9kT2JqLlF0eSAhPSB1bmRlZmluZWQgJiYgcHJvZE9iai5RdHkgIT0gXCJcIik7XHJcbiAgICAgICAgXHJcbiAgICB9XHJcbiAgICBBZGRQcm9kdWN0cyhwcm9kT2JqKTogb2JzZXJ2YWJsZSB7XHJcbiAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICBpZiAodGhpcy5DYW5hZGRQcm9kdWN0KHByb2RPYmopKSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICB2YXIgUHJvZHVjdE9iaiA9IHsgUm93Tm86ICh0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdFByb2R1Y3RzLmxlbmd0aCsxKS50b1N0cmluZygpLCBQcm9kdWN0Tm86IFwiXCIsIFByb2R1Y3ROYW1lOiBcIlwiLCBQcmljZTogXCIwXCIsIFF0eTogXCIxXCIsIFRvdGFsOiBcIjBcIiB9O1xyXG4gICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdFByb2R1Y3RzLnB1c2goUHJvZHVjdE9iaik7XHJcbiAgICAgICAgICAgIHRoaXMuQmluZFByb2RUb3RhbCgpO1xyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICB2YXIgbXNnID0gJyc7XHJcbiAgICAgICAgICAgIGlmIChwcm9kT2JqLlByb2R1Y3RObyA9PSB1bmRlZmluZWQgfHwgcHJvZE9iai5Qcm9kdWN0Tm8gPT0gXCJcIikge1xyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICBtc2cgKz0gJ1xcblBsZWFzZSBlbnRlciBwcm9kdWN0IG5vJyA7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKHByb2RPYmouUHJvZHVjdE5hbWUgPT0gdW5kZWZpbmVkIHx8IHByb2RPYmouUHJvZHVjdE5hbWUgPT0gXCJcIikge1xyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICBtc2cgKz0gJ1xcblBsZWFzZSBlbnRlciBwcm9kdWN0IG5hbWUnO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChwcm9kT2JqLlByaWNlID09IHVuZGVmaW5lZCB8fCBwcm9kT2JqLlByaWNlID09IFwiXCIpIHtcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgbXNnICs9ICdcXG5QbGVhc2UgZW50ZXIgcHJpY2UnO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChwcm9kT2JqLlF0eSA9PSB1bmRlZmluZWQgfHwgcHJvZE9iai5RdHkgPT0gXCJcIikge1xyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICBtc2cgKz0gJ1xcblBsZWFzZSBlbnRlciBxdWFudGl0eSc7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICBtZXNzYWdlOiBtc2csIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIH1cclxuXHJcbiAgICB9XHJcbiAgICBkZWxQcm9kdWN0RGV0KFByb2RPYmopOiBvYnNlcnZhYmxlIHtcclxuICAgICAgLy8gIGRlYnVnZ2VyO1xyXG4gICAgICAgIC8vaWYgKHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0UHJvZHVjdHMubGVuZ3RoID4gMSkge1xyXG4gICAgICAgICAgICB2YXIgaW5kZXggPSAwO1xyXG4gICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdFByb2R1Y3RzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcyA9PSBQcm9kT2JqKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBpbmRleCA9IGluZGV4ICsgMTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0UHJvZHVjdHMuc3BsaWNlKGluZGV4LCAxKTtcclxuICAgICAgICAgICAgaW5kZXggPSAxO1xyXG4gICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdFByb2R1Y3RzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLlJvd05vID0gaW5kZXgudG9TdHJpbmcoKTtcclxuICAgICAgICAgICAgICAgIGluZGV4ID0gaW5kZXggKyAxO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgdGhpcy5CaW5kUHJvZFRvdGFsKCk7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdFByb2R1Y3RzLmxlbmd0aCA9PSAwKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLklzU2hvd1Byb2R1Y3RzID0gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAvL31cclxuICAgIH1cclxuICAgIENhbGN1bGF0ZVByb2RSb3dUb3RhbChwcm9kT2JqKSB7XHJcbiAgICAgIC8vICBkZWJ1Z2dlcjtcclxuICAgICAgICB2YXIgUHJpY2UgPSAwO1xyXG4gICAgICAgIGlmIChwcm9kT2JqLlByaWNlICE9IHVuZGVmaW5lZCAmJiBwcm9kT2JqLlByaWNlICE9IG51bGwgJiYgcHJvZE9iai5RdHkgIT0gXCJcIikge1xyXG4gICAgICAgICAgICBQcmljZSA9IHBhcnNlRmxvYXQocHJvZE9iai5QcmljZSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHZhciBRdHkgPSAwO1xyXG4gICAgICAgIGlmIChwcm9kT2JqLlF0eSAhPSB1bmRlZmluZWQgJiYgcHJvZE9iai5RdHkgIT0gbnVsbCAmJiBwcm9kT2JqLlF0eSAhPSBcIlwiKSB7XHJcbiAgICAgICAgICAgIFF0eSA9IHBhcnNlRmxvYXQocHJvZE9iai5RdHkpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBwcm9kT2JqLlRvdGFsID0gKFByaWNlICogUXR5KS50b0ZpeGVkKDIpO1xyXG5cclxuICAgICAgICB0aGlzLkJpbmRQcm9kVG90YWwoKTtcclxuICAgIH1cclxuXHJcbiAgICBCaW5kUHJvZFRvdGFsKCkge1xyXG4gICAgICAgIHZhciBQcm9kVG90YWwgPSAwO1xyXG4gICAgICAgIGpRdWVyeS5lYWNoKHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0UHJvZHVjdHMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgUHJvZFRvdGFsID0gcGFyc2VGbG9hdChQcm9kVG90YWwudG9TdHJpbmcoKSkrIHBhcnNlRmxvYXQodGhpcy5Ub3RhbCk7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LlByb2R1Y3RUb3RhbCA9IFByb2RUb3RhbC50b0ZpeGVkKDIpO1xyXG4gICAgfVxyXG4gICAgbmdPbkluaXQoKSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgLy9qUXVlcnkoXCIubGVhbi1vdmVybGF5XCIpLmNzcyh7IFwiZGlzcGxheVwiOiBcIm5vbmVcIiB9KTtcclxuICAgICAgICBqUXVlcnkoXCIjTm90ZU1vZGFsXCIpLmNsb3NlTW9kYWwoKTtcclxuICAgICAgICBqUXVlcnkoXCIubGVhbi1vdmVybGF5XCIpLmNzcyh7IFwiZGlzcGxheVwiOiBcIm5vbmVcIiB9KTtcclxuICAgICAgICB3aW5kb3cuc2Nyb2xsVG8oMCwgMCk7XHJcbiAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICB2YXIgY3VycmVuY3lpZCA9IFwiXCI7XHJcbiAgICAgICAgdmFyIEVtcElkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJlbXBsb3llZWlkXCIpO1xyXG4gICAgICAgIHZhciBPcmdJZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKEVtcElkICsgXCJfT3JnSWRcIik7XHJcbiAgICAgICAgdmFyIGpkYXRhID0gdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmdldENvb2tpZShFbXBJZCArIFwiX1wiICsgT3JnSWQrXCJfUmVjZWlwdENyZWF0ZV9DYWNoZVwiKTtcclxuICAgICAgICBpZiAoamRhdGEgIT0gdW5kZWZpbmVkICYmIGpkYXRhICE9IHVuZGVmaW5lZCAmJiBqZGF0YSAhPSBcIlwiKSB7XHJcbiAgICAgICAgICAgIGpkYXRhID0gamRhdGEuc3Vic3RyaW5nKDEsIGpkYXRhLmxlbmd0aCk7XHJcbiAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dCA9IGpRdWVyeS5wYXJzZUpTT04oamRhdGEpO1xyXG4gICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCA9IHRoaXMuX3JvdXRlUGFyYW1zLnBhcmFtcy5JZDtcclxuICAgICAgICAgICAgY3VycmVuY3lpZCA9IHRoaXMubW9kZWxJbnB1dC5DdXJyZW5jeUlkO1xyXG4gICAgICAgICAgICB0aGlzLkdldEN1c3RvbWVyRGV0YWlsKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgICAgIFxyXG4gICAgICAvLyAgYWxlcnQoXCJkZGRcIik7XHJcbiAgICAgICAgdGhpcy5MYW5nID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJsYW5nXCIpO1xyXG4gICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5HZXRMYW5nUmVzKHRoaXMuRm9ybXR5cGUsIHRoaXMuTGFuZykuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5SRVMgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMuX1JlY2llcHRTZXJ2aWNlLkdldEN1c3RvbWVyTm90ZXMoKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fQ3VzdG9tZXJOb3RlcyA9IHJlc3BvbnNlLkRhdGE7XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMuQmluZEF1dG9Db21wbGV0ZUJhbmsoKTtcclxuICAgICAgICB0aGlzLl9SZWNpZXB0U2VydmljZS5HZXRUaGFua3NMZXR0ZXJzKHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0VHlwZUlkKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fVGhhbmtMZXR0ZXJzID0gcmVzcG9uc2UuRGF0YTtcclxuXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgdGhpcy5fUmVjaWVwdFNlcnZpY2UuR2V0QXNzb2NpYXRpb24oKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5hc3NvY2lhdGlvbklkID0gcmVzcG9uc2UuRGF0YVswXS5WYWx1ZTtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5hc3NvY2lhdGlvbk5hbWUgPSByZXNwb25zZS5EYXRhWzBdLlRleHQ7XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHRoaXMuX1JlY2llcHRTZXJ2aWNlLkdldFByaW50ZXIoKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5QcmludGVySWQgPSByZXNwb25zZS5EYXRhWzBdLlZhbHVlO1xyXG5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuICAgICAgICB0aGlzLl9SZWNpZXB0U2VydmljZS5HZXRFbXBsb3llZSgpLnN1YnNjcmliZShyZXNwPT4ge1xyXG4gICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICB2YXIgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3ApO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkVtcGxveWVlSWQgPSByZXNwb25zZS5EYXRhWzBdLlZhbHVlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkVtcGxveWVlTmFtZSA9IHJlc3BvbnNlLkRhdGFbMF0uVGV4dDtcclxuXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgdGhpcy5fUmVjaWVwdFNlcnZpY2UuR2V0UGF5VHlwZSgpLnN1YnNjcmliZShyZXNwPT4ge1xyXG4gICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICB2YXIgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3ApO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9QYXlUeXBlcyA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgdGhpcy5fUmVjaWVwdFNlcnZpY2UuR2V0QWNjb3VudHMoKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fQWNjb3VudHMgPSByZXNwb25zZS5EYXRhO1xyXG5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgdGhpcy5fUmVjaWVwdFNlcnZpY2UuR2V0R29hbHMoKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fR29hbHMgPSByZXNwb25zZS5EYXRhO1xyXG5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgdGhpcy5fUmVjaWVwdFNlcnZpY2UuR2V0UHJvamVjdENhdHMoKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fUHJvamVjdENhdHMgPSByZXNwb25zZS5EYXRhO1xyXG5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuICAgICAgICB0aGlzLkJpbmRQcm9qZWN0RnJvbVByb2pDYXQoLTEpO1xyXG4gICAgICAgIHRoaXMuX1JlY2llcHRTZXJ2aWNlLkdldEN1cnJlbmNpZXNGREIoKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fQ3VycmVuY2llcyA9IHJlc3BvbnNlLkRhdGE7XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHRoaXMuX1JlY2llcHRTZXJ2aWNlLkdldFJlY2llcHRUeXBlKHRoaXMuX3JvdXRlUGFyYW1zLnBhcmFtcy5SZWNlaXB0VHlwZUlkKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LlJlY2llcHRUeXBlID0gcmVzcG9uc2UuRGF0YVswXS5SZWNpZXB0TmFtZUVuZztcclxuICAgICAgICAgICAgICAgIGlmIChjdXJyZW5jeWlkID09IFwiXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VycmVuY3lJZCA9IHJlc3BvbnNlLkRhdGFbMF0uQ3VycmVuY3lJZDtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXJyZW5jeUlkID0gY3VycmVuY3lpZDtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICB0aGlzLl9SZWNpZXB0U2VydmljZS5HZXRSZWNlaXB0RGV0YWlsKCkuc3Vic2NyaWJlKHJlc3A9PiB7XHJcbiAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgIHZhciByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcCk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5SZWNpZXB0Tm8gPSByZXNwb25zZS5EYXRhLlZhbHVlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LlJlY2llcHREYXRlID0gdGhpcy5EZWZhdWx0RGF0ZTtcclxuXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgdmFyIEN1c3RJZCA9IHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkO1xyXG4gICAgICAgIHRoaXMuR2V0Q3VzdG9tZXJEZXRhaWwoKTtcclxuICAgICAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vQ2FjaGUgSW1wbGVtZW50Ly8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgICAgLy8gIGRlYnVnZ2VyO1xyXG4gICAgICAgIHZhciBFbXBJZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiZW1wbG95ZWVpZFwiKTtcclxuICAgICAgICB2YXIgT3JnSWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShFbXBJZCArIFwiX09yZ0lkXCIpO1xyXG4gICAgICAgIHZhciBpc3Nob3cgPSB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZ2V0Q29va2llKEVtcElkICsgXCJfXCIgKyBPcmdJZCtcIl9SZWNlaXB0Q3JlYXRlX0lzU2hvd1Byb2R1Y3RzXCIpO1xyXG4gICAgICAgIGlmIChpc3Nob3cgIT0gdW5kZWZpbmVkICYmIGlzc2hvdyAhPSB1bmRlZmluZWQgJiYgaXNzaG93ICE9IFwiXCIpIHtcclxuICAgICAgICAgICAgaXNzaG93ID0gaXNzaG93LnN1YnN0cmluZygxLCBpc3Nob3cubGVuZ3RoKTtcclxuICAgICAgICAgICAgdGhpcy5Jc1Nob3dQcm9kdWN0cyA9IEJvb2xlYW4oaXNzaG93KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdmFyIHJvd25vID0gdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmdldENvb2tpZShcIlRlbXBSb3dOb1wiKTtcclxuICAgICAgICBpZiAocm93bm8gIT0gdW5kZWZpbmVkICYmIHJvd25vICE9IHVuZGVmaW5lZCAmJiByb3dubyAhPSBcIlwiKSB7XHJcbiAgICAgICAgICAgIHJvd25vID0gcm93bm8uc3Vic3RyaW5nKDEsIHJvd25vLmxlbmd0aCk7XHJcbiAgICAgICAgICAgIHZhciBwZGF0YSA9IHRoaXMuX3Jlc291cmNlU2VydmljZS5nZXRDb29raWUoRW1wSWQgKyBcIl9cIiArIE9yZ0lkK1wiX1JlY2VpcHRDcmVhdGVfUHJvZHVjdFwiKTtcclxuICAgICAgICAgICAgaWYgKHBkYXRhICE9IHVuZGVmaW5lZCAmJiBwZGF0YSAhPSB1bmRlZmluZWQgJiYgcGRhdGEgIT0gXCJcIikge1xyXG4gICAgICAgICAgICAgICAgcGRhdGEgPSBwZGF0YS5zdWJzdHJpbmcoMSwgcGRhdGEubGVuZ3RoKTtcclxuICAgICAgICAgICAgICAgIHZhciBQcm9kdWN0ID0gW107XHJcbiAgICAgICAgICAgICAgICBQcm9kdWN0ID0galF1ZXJ5LnBhcnNlSlNPTihwZGF0YSk7XHJcbiAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdFByb2R1Y3RzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuUm93Tm8gPT0gcm93bm8pIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5Qcm9kdWN0Tm8gPSBQcm9kdWN0LlBhcnROdW1iZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuUHJvZHVjdE5hbWUgPSBQcm9kdWN0LlByb2ROYW1lRGlzO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLlByaWNlID0gcGFyc2VGbG9hdChQcm9kdWN0LlByaWNlKS50b0ZpeGVkKDIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLlRvdGFsID0gKHBhcnNlRmxvYXQodGhpcy5QcmljZSkgKiBwYXJzZUZsb2F0KHRoaXMuUXR5KSkudG9GaXhlZCgyKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIHRoaXMuQmluZFByb2RUb3RhbCgpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmRlbGV0ZUNvb2tpZShcIlRlbXBSb3dOb1wiKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5kZWxldGVDb29raWUoRW1wSWQgKyBcIl9cIiArIE9yZ0lkK1wiX1JlY2VpcHRDcmVhdGVfUHJvZHVjdFwiKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG4iXX0=
