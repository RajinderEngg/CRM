System.register(["angular2/core", 'angular2/common', "../../services/ResourceService", "angular2/router", "../../services/RecieptService", "../../services/CustomerService", '../../comonComponents/basicComponents', "../../services/ChargeCreditService"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, common_1, ResourceService_1, router_1, RecieptService_1, CustomerService_1, basicComponents_1, ChargeCreditService_1;
    var AmaxReceiptCreate;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (ResourceService_1_1) {
                ResourceService_1 = ResourceService_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (RecieptService_1_1) {
                RecieptService_1 = RecieptService_1_1;
            },
            function (CustomerService_1_1) {
                CustomerService_1 = CustomerService_1_1;
            },
            function (basicComponents_1_1) {
                basicComponents_1 = basicComponents_1_1;
            },
            function (ChargeCreditService_1_1) {
                ChargeCreditService_1 = ChargeCreditService_1_1;
            }],
        execute: function() {
            AmaxReceiptCreate = (function () {
                // @ViewChild('RTLDiv') private myScrollContainer: ElementRef;
                function AmaxReceiptCreate(_resourceService, _RecieptService, _CustomerService, _routeParams, _ChargeCreditService) {
                    this._resourceService = _resourceService;
                    this._RecieptService = _RecieptService;
                    this._CustomerService = _CustomerService;
                    this._routeParams = _routeParams;
                    this._ChargeCreditService = _ChargeCreditService;
                    this.RES = {};
                    this.Formtype = "SCREEN_RECEIPTCREATE";
                    this.Lang = "";
                    this._Banks = [];
                    this._CustomerNotes = [];
                    this._Addresses = [];
                    this._PayTypes = [];
                    this._Accounts = [];
                    this._Goals = [];
                    this._ProjectCats = [];
                    this._Projects = [];
                    this._Currencies = [];
                    this.PasteText = "";
                    this.IsShowProducts = false;
                    //    modelInput.ReceiptLines = [];
                    this._ThankLetters = [];
                    this.RowCount = 0;
                    this.Isbtndisable = "";
                    this.SAVE_BTN_TEXT = "Save";
                    this.MsgClass = "text-primary";
                    this.modelInput = {};
                    this.saveInput = {};
                    this.ChangeDialog = "";
                    this.CHANGEDIR = "";
                    this.ShowMoreText = "";
                    this.ShowMore = false;
                    this.IsBankDetShow = false;
                    this.DefaultDate = "";
                    this.IPopUpOpen = false;
                    this.PopProdObj = {};
                    this.RES.SCREEN_RECEIPTCREATE = {};
                    this.modelInput = {};
                    //this.modelInput.AddModel = {};
                    this.modelInput.ReceiptLines = [];
                    this.modelInput.ReceiptProducts = [];
                    //this.modelInput.ReceiptProducts = [{ RowNo: "1", ProductNo: "", ProductName: "", Price: "0", Qty: "1", Total: "0" }];
                    this.IsShowProducts = false;
                    this.IPopUpOpen = false;
                    this.IsBankDetShow = false;
                    this.modelInput.ReceiptTypeId = _routeParams.params.ReceiptTypeId;
                    //this.baseUrl = "http://localhost:3000/#/";
                    // debugger;
                    // alert(this.modelInput.ReceiptTypeId);
                    this.baseUrl = _resourceService.AppUrl;
                    this.modelInput.CustomerId = _routeParams.params.Id;
                    this.modelInput.CustomerName = "";
                    //this.modelInput.AddModel.ReferenceDate = "";
                    // this.ShowMoreText = "More";
                    this.DefaultDate = moment(new Date()).format('DD-MM-YYYY');
                    this.Lang = localStorage.getItem("lang");
                    var MText = "";
                    if (this.Lang == "en") {
                        MText = "More";
                    }
                    else {
                        MText = "יותר";
                    }
                    var DupObj = {
                        Amount: 0, ValueDate: this.DefaultDate, PayTypeId: 1, AccountId: "", AccountNo: "",
                        BranchNo: "", Bank: "", CreditCardType: "", DonationTypeId: "", ProjectCategoryId: "", ProjectId: "", ReferenceDate: this.DefaultDate,
                        For_Invoice: "", RecievedCustId: "", Payed: false, DepositeRemark: "", ShowMore: false, ShowMoreText: MText,
                        CashCSS: "grey", CreditCSS: "white", BankCSS: "white", OtherCSS: "white", IsShowOthers: false, IsCreditShow: false, IsBankDetShow: false
                    };
                    this.modelInput.ReceiptLines.push(DupObj);
                }
                AmaxReceiptCreate.prototype.dateVSelectionChange = function (evt, dataobj) {
                    console.log(evt);
                    dataobj.ValueDate = evt;
                    // alert(this.modelInput.BirthDate);
                    //this.validateLogin();
                };
                AmaxReceiptCreate.prototype.dateSelectionChange = function (evt, dataobj) {
                    console.log(evt);
                    dataobj.ReferenceDate = evt;
                    // alert(this.modelInput.BirthDate);
                    //this.validateLogin();
                };
                AmaxReceiptCreate.prototype.More = function (modelobj) {
                    // alert("call");
                    if (modelobj.ShowMore == true) {
                        modelobj.ShowMore = false;
                        if (this.Lang == "en") {
                            modelobj.ShowMoreText = "More";
                        }
                        else {
                            modelobj.ShowMoreText = "יותר";
                        }
                    }
                    else {
                        modelobj.ShowMore = true;
                        if (this.Lang == "en") {
                            modelobj.ShowMoreText = "Less";
                        }
                        else {
                            modelobj.ShowMoreText = "פָּחוּת";
                        }
                    }
                };
                AmaxReceiptCreate.prototype.BankDetailShow = function (PayTypeId, dataobj) {
                    if (PayTypeId != 1 && PayTypeId != 3) {
                        dataobj.IsBankDetShow = true;
                        dataobj.IsCreditShow = false;
                        this.BindAutoCompleteBank();
                    }
                    else if (PayTypeId == 3) {
                        dataobj.IsCreditShow = true;
                        dataobj.IsBankDetShow = false;
                    }
                    else {
                        dataobj.IsBankDetShow = false;
                        dataobj.IsCreditShow = false;
                    }
                };
                AmaxReceiptCreate.prototype.setdefaultmode = function () {
                    var _this = this;
                    //document.location = this.baseUrl + "ReceiptCreate/" + this.modelInput.CustomerId + " /" + this.modelInput.ReceiptId;
                    this.IPopUpOpen = false;
                    this.RowCount = 0;
                    window.scrollTo(0, 0);
                    var _ReceiptTypeId = this.modelInput.ReceiptTypeId;
                    var PrevReceiptType = this.modelInput.RecieptType;
                    var CustId = this.modelInput.CustomerId;
                    var CustName = this.modelInput.CustomerName;
                    var addressId = this.modelInput.AddressId;
                    var thnkLetterId = this.modelInput.ThanksLetterId;
                    var PrintValueDate = this.modelInput.ValueDate;
                    var associationName = this.modelInput.associationName;
                    var PrinterId = this.modelInput.PrinterId;
                    var associationid = this.modelInput.associationId;
                    this.modelInput = {};
                    this.IsShowProducts = false;
                    this.modelInput.CustomerId = CustId;
                    this.modelInput.CustomerName = CustName;
                    this.modelInput.AddressId = addressId;
                    this.modelInput.associationName = associationName;
                    this.modelInput.ThanksLetterId = thnkLetterId;
                    this.modelInput.PrintValueDate = PrintValueDate;
                    this.modelInput.ReceiptTypeId = _ReceiptTypeId;
                    this.modelInput.PrinterId = PrinterId;
                    this.modelInput.associationId = associationid;
                    this.modelInput.ReceiptLines = [];
                    this.modelInput.ReceiptProducts = [];
                    //this.modelInput.ReceiptProducts = [{ RowNo: "1", ProductNo: "", ProductName: "", Price: "0", Qty: "1", Total: "0" }];
                    var DupObj = {
                        Amount: 0, ValueDate: this.DefaultDate, PayTypeId: 1, AccountId: "", AccountNo: "",
                        BranchNo: "", Bank: "", CreditCardType: "", DonationTypeId: "", ProjectCategoryId: "", ProjectId: "", ReferenceDate: this.DefaultDate,
                        For_Invoice: "", RecievedCustId: CustId, Payed: false, DepositeRemark: "", ShowMore: false, ShowMoreText: "More",
                        CashCSS: "grey", CreditCSS: "white", BankCSS: "white", OtherCSS: "white", IsShowOthers: false, IsCreditShow: false, IsBankDetShow: false
                    };
                    this.modelInput.ReceiptLines.push(DupObj);
                    //this.GetCustomerDetail(CustId);
                    //this.modelInput.RecieptType = PrevReceiptType;
                    this._RecieptService.GetRecieptType(this._routeParams.params.ReceiptTypeId).subscribe(function (resp) {
                        // debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.modelInput.RecieptType = response.Data[0].RecieptNameEng;
                            _this.modelInput.CurrencyId = response.Data[0].CurrencyId;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    // this.IsBankDetShow = false;
                    this._RecieptService.GetEmployee().subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            //debugger;
                            _this.modelInput.EmployeeId = response.Data[0].Value;
                            _this.modelInput.EmployeeName = response.Data[0].Text;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._RecieptService.GetReceiptDetail().subscribe(function (resp) {
                        // debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.modelInput.RecieptNo = response.Data.Value;
                            _this.modelInput.RecieptDate = response.Data.Text;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxReceiptCreate.prototype.saveReceiptData = function (IsExit) {
                    var _this = this;
                    // debugger;
                    //if (this.IPopUpOpen == false)
                    //{
                    var EmpName = jQuery("#EmpId").val();
                    this._RecieptService.GetEmployeeFromEmpName(EmpName).subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.modelInput.EmployeeId = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    if (this.modelInput.CustomerId != null && this.modelInput.CustomerId != "" && this.modelInput.CustomerId != undefined
                        && this.modelInput.CurrencyId != null && this.modelInput.CurrencyId != "" && this.modelInput.CurrencyId != undefined
                        && this.modelInput.ReceiptLines.length > 0
                        && this.modelInput.associationId != null && this.modelInput.associationId != "" && this.modelInput.associationId != undefined
                        && this.modelInput.EmployeeId != null && this.modelInput.EmployeeId != "-1" && this.modelInput.EmployeeId != undefined
                        && this.modelInput.ThanksLetterId != null && this.modelInput.ThanksLetterId != "" && this.modelInput.ThanksLetterId != undefined
                        && this.modelInput.PrinterId != null && this.modelInput.PrinterId != "" && this.modelInput.PrinterId != undefined
                        && this.modelInput.RecieptNo != null && this.modelInput.RecieptNo != "" && this.modelInput.RecieptNo != undefined) {
                        this.modelInput.RecieptType = this.modelInput.ReceiptTypeId;
                        var LineCount = this.modelInput.ReceiptLines.length;
                        var CheckRowValid = true;
                        if (LineCount < 1) {
                            CheckRowValid = false;
                        }
                        //alert(JSON.stringify(this.modelInput));
                        for (var cnt in this.modelInput.ReceiptLines) {
                            var ErrorMessage = "Row Number - " + (parseInt(cnt) + 1).toString() + " is not valid in Receipt Lines <br>";
                            if (this.ValidateRowModel(this.modelInput.ReceiptLines[cnt], ErrorMessage) == false) {
                                CheckRowValid = false;
                                break;
                            }
                        }
                        for (var cnt in this.modelInput.ReceiptProducts) {
                            var ErrorMessage = "Row Number - " + (parseInt(cnt) + 1).toString() + " is not valid in Products <br>";
                            if (this.ValidateProductRowModel(this.modelInput.ReceiptProducts[cnt], ErrorMessage, cnt) == false) {
                                CheckRowValid = false;
                                break;
                            }
                        }
                        if (CheckRowValid == true) {
                            //debugger;
                            var jdata = JSON.stringify(this.modelInput);
                            //console.log(jdata);
                            this._RecieptService.AddReceipt(jdata).subscribe(function (response) {
                                console.log(response);
                                response = jQuery.parseJSON(response);
                                _this.Isbtndisable = "";
                                if (response.IsError == true) {
                                    alert(response.ErrMsg);
                                    _this.MsgClass = "text-danger";
                                }
                                else {
                                    bootbox.alert({
                                        message: response.ErrMsg,
                                        className: _this.ChangeDialog,
                                        buttons: {
                                            ok: {
                                                //label: 'Ok',
                                                className: _this.CHANGEDIR
                                            }
                                        }
                                    });
                                    _this._resourceService.deleteCookie("ReceiptCreate_Cache");
                                    if (IsExit == true) {
                                        document.location = _this.baseUrl + "ReceiptSelect/" + _this.modelInput.EmployeeId + " /" + _this.modelInput.CustomerId;
                                    }
                                    else {
                                        _this.setdefaultmode();
                                        _this.modelInput.PrintRecieptNo = response.Data.RecieptNo;
                                        _this.CustId = response.CustomerId;
                                    }
                                }
                            }, function (error) { return console.log(error); }, function () { return console.log("Save Call Compleated"); });
                        }
                    }
                    else {
                        var msg = "";
                        if (this.modelInput.CustomerId == null || this.modelInput.CustomerId == "" || this.modelInput.CustomerId == undefined) {
                            msg += "<br>Please enter customerid";
                        }
                        if (this.modelInput.CurrencyId == null || this.modelInput.CurrencyId == "" || this.modelInput.CurrencyId == undefined) {
                            msg += "<br>Please select currency";
                        }
                        if (this.modelInput.associationId == null || this.modelInput.associationId == "" || this.modelInput.associationId == undefined) {
                            msg += "<br>Please enter Deposited By";
                        }
                        if (this.modelInput.EmployeeId == null || this.modelInput.EmployeeId == "" || this.modelInput.EmployeeId == undefined) {
                            msg += "<br>Please enter valid employee";
                        }
                        if (this.modelInput.ThanksLetterId == null || this.modelInput.ThanksLetterId == "" || this.modelInput.ThanksLetterId == undefined) {
                            msg += this.modelInput.ThanksLetterId;
                            msg += "<br>Please select print template";
                        }
                        if (this.modelInput.PrinterId == null || this.modelInput.PrinterId == "" || this.modelInput.PrinterId == undefined) {
                            msg += "<br>Please set printer name in database";
                        }
                        if (this.modelInput.RecieptNo == null || this.modelInput.RecieptNo == "" || this.modelInput.RecieptNo == undefined) {
                            msg += "<br>Receipt no is not set";
                        }
                        if (this.modelInput.ReceiptLines.length == 0) {
                            msg += "<br>Please atleast one amount detail in grid";
                        }
                        bootbox.alert({
                            message: msg,
                            className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                    }
                    //}
                };
                AmaxReceiptCreate.prototype.delModel = function (ModelObj) {
                    //debugger;
                    if (this.modelInput.ReceiptLines.length > 1) {
                        var index = 0;
                        jQuery.each(this.modelInput.ReceiptLines, function () {
                            if (this == ModelObj) {
                                return false;
                            }
                            index = index + 1;
                        });
                        this.modelInput.ReceiptLines.splice(index, 1);
                        this.BindTotal();
                    }
                };
                AmaxReceiptCreate.prototype.BindTotal = function () {
                    var _this = this;
                    var ttotal = 0;
                    //debugger;
                    jQuery.each(this.modelInput.ReceiptLines, function () {
                        ttotal += parseFloat(this.Amount);
                    });
                    this.modelInput.Total = ttotal;
                    var vDate = this.modelInput.ValueDate;
                    console.log(vDate);
                    if (vDate == null || vDate == "")
                        vDate = this.DefaultDate;
                    var curID = this.modelInput.CurrencyId;
                    //alert(curID);
                    this._RecieptService.GetLeadcurrency(curID, "NIS", vDate).subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            //var n = num.toFixed(2);
                            _this.modelInput.TotalInLeadCurrent = parseFloat(response.Data) * ttotal;
                            _this.modelInput.TotalInLeadCurrent = _this.modelInput.TotalInLeadCurrent.toFixed(2);
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxReceiptCreate.prototype.createReceiptPDF = function () {
                    var _this = this;
                    if (this.modelInput.PrintRecieptNo != null) {
                        var Recipt_No = this.modelInput.PrintRecieptNo;
                        var Reciept_Type = this.modelInput.ReceiptTypeId;
                        var Customer_Id = this.modelInput.CustomerId;
                        var ThanksLetter_Id = this.modelInput.ThanksLetterId;
                        var LeadCurrencyId = this.modelInput.CurrencyId;
                        this._RecieptService.CreateReceiptPdf(Customer_Id, ThanksLetter_Id, Recipt_No, Reciept_Type, LeadCurrencyId).subscribe(function (response) {
                            // debugger;
                            response = jQuery.parseJSON(response);
                            if (response.IsError == false) {
                                var l = response.Data.toString().substring(0, 5);
                                if (response.Data.toString().substring(0, 5) == "Link:") {
                                    var PrintData = response.Data.toString().substring(5, response.Data.toString().length);
                                    var windowObject = window.open(PrintData, 'Print', 'scrollbars=yes,resizable=yes,width=1050,height=650');
                                }
                                else {
                                    bootbox.alert({
                                        message: response.Data,
                                        className: _this.ChangeDialog,
                                        buttons: {
                                            ok: {
                                                //label: 'Ok',
                                                className: _this.CHANGEDIR
                                            }
                                        }
                                    });
                                }
                            }
                            else {
                                bootbox.alert({
                                    message: response.ErrMsg,
                                    className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                        }, function (error) {
                            console.log(error);
                        }, function () {
                            console.log("CallCompleted");
                        });
                    }
                };
                AmaxReceiptCreate.prototype.DupModel = function (ModelObj) {
                    var MObj = {};
                    this.RowCount++;
                    ModelObj.RecieptRoWID = this.RowCount;
                    MObj = ModelObj;
                    var Vdate = MObj.ValueDate.split('-');
                    var NewVDate = new Date(parseInt(Vdate[2]), parseInt(Vdate[1]), parseInt(Vdate[0]));
                    NewVDate.setMonth(NewVDate.getMonth());
                    var NVDate = moment(NewVDate).format('DD-MM-YYYY');
                    //var Month = parseInt(Vdate[1]) + 1;
                    //MObj.ValueDate = NewVDate;
                    var DupObj = { Amount: ModelObj.Amount, ValueDate: NewVDate, PayTypeId: ModelObj.PayTypeId, AccountId: ModelObj.AccountId, AccountNo: ModelObj.AccountNo, BranchNo: ModelObj.BranchNo, Bank: ModelObj.Bank, CreditCardType: ModelObj.CreditCardType, DonationTypeId: ModelObj.DonationTypeId, ProjectCategoryId: ModelObj.ProjectCategoryId, ProjectId: ModelObj.ProjectId, ReferenceDate: ModelObj.ReferenceDate, For_Invoice: ModelObj.For_Invoice, RecievedCustId: ModelObj.RecievedCustId, Payed: ModelObj.Payed, DepositeRemark: ModelObj.DepositeRemark };
                    this.modelInput.ReceiptLines.push(DupObj);
                    var index = 0;
                    var TotalRows = this.modelInput.ReceiptLines.length;
                    jQuery.each(this.modelInput.ReceiptLines, function () {
                        if (index == (TotalRows - 1)) {
                            this.ValueDate = NVDate;
                        }
                        index++;
                    });
                    this.BindTotal();
                };
                AmaxReceiptCreate.prototype.ValidateRowModel = function (CurrentModel, msg) {
                    //msg = "";
                    var IsValidData = true;
                    if (CurrentModel.ValueDate != "") {
                        if (moment(CurrentModel.ValueDate, "DD-MM-YYYY", true).isValid() == false) {
                            bootbox.alert({ message: "Value Date is not valid" });
                            return false;
                        }
                    }
                    if (CurrentModel.ReferenceDate != "") {
                        if (moment(CurrentModel.ReferenceDate, "DD-MM-YYYY", true).isValid() == false) {
                            bootbox.alert({ message: "Reference Date is not valid" });
                            return false;
                        }
                    }
                    //var msg = "";
                    if (CurrentModel.Amount == null || CurrentModel.Amount == "" || CurrentModel.Amount == undefined) {
                        IsValidData = false;
                        msg += "<br>Please enter amount";
                    }
                    if (CurrentModel.PayTypeId == null || CurrentModel.PayTypeId == "" || CurrentModel.PayTypeId == undefined) {
                        IsValidData = false;
                        msg += "<br>Please select paytype";
                    }
                    if (CurrentModel.ProjectId == null || CurrentModel.ProjectId == "" || CurrentModel.ProjectId == undefined) {
                        IsValidData = false;
                        msg += "<br>Please select project";
                    }
                    if (CurrentModel.DonationTypeId == null || CurrentModel.DonationTypeId == "" || CurrentModel.DonationTypeId == undefined) {
                        IsValidData = false;
                        msg += "<br>Please select goal";
                    }
                    if (CurrentModel.AccountId == null || CurrentModel.AccountId == "" || CurrentModel.AccountId == undefined) {
                        IsValidData = false;
                        msg += "<br>Please select account";
                    }
                    if (CurrentModel.PayTypeId == 8) {
                        if (CurrentModel.AccountNo == null || CurrentModel.AccountNo == "" || CurrentModel.AccountNo == undefined) {
                            IsValidData = false;
                            msg += "<br>Please enter account no";
                        }
                        if (CurrentModel.BranchNo == null || CurrentModel.BranchNo == "" || CurrentModel.BranchNo == undefined) {
                            IsValidData = false;
                            msg += "<br>Please select branch no";
                        }
                        if (CurrentModel.Bank == null || CurrentModel.Bank == "" || CurrentModel.Bank == undefined) {
                            IsValidData = false;
                            msg += "<br>Please enter bank";
                        }
                    }
                    if (CurrentModel.PayTypeId == 3) {
                        if (CurrentModel.CreditCardType == null || CurrentModel.CreditCardType == "" || CurrentModel.CreditCardType == undefined) {
                            IsValidData = false;
                            msg += "<br>Please enter CreditCard";
                        }
                    }
                    if (IsValidData == false) {
                        bootbox.alert({
                            message: msg,
                            className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                    }
                    return IsValidData;
                };
                AmaxReceiptCreate.prototype.ValidateProductRowModel = function (CurrentModel, msg, rowno) {
                    //msg = "";
                    var IsValidData = true;
                    //var msg = "";
                    if (CurrentModel.ProductNo == null || CurrentModel.ProductNo == "" || CurrentModel.ProductNo == undefined) {
                        IsValidData = false;
                        msg += "<br>Please enter product no";
                    }
                    if (CurrentModel.ProductName == null || CurrentModel.ProductName == "" || CurrentModel.ProductName == undefined) {
                        IsValidData = false;
                        msg += "<br>Please enter product name";
                    }
                    if (CurrentModel.Price == null || CurrentModel.Price == "" || CurrentModel.Price == undefined) {
                        IsValidData = false;
                        msg += "<br>Please enter price";
                    }
                    if (CurrentModel.Qty == null || CurrentModel.Qty == "" || CurrentModel.Qty == undefined) {
                        IsValidData = false;
                        msg += "<br>Please enter quantity";
                    }
                    if (IsValidData == false) {
                        bootbox.alert({
                            message: msg,
                            className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                    }
                    return IsValidData;
                };
                AmaxReceiptCreate.prototype.AddReceiptLine = function (CurrentModel) {
                    // this.modelInput.AddModel.Bank = jQuery("#Bank").val();
                    if (this.ValidateRowModel(CurrentModel, "")) {
                        var MText = "";
                        if (this.Lang == "en") {
                            MText = "More";
                        }
                        else {
                            MText = "יותר";
                        }
                        var ModelObj = {
                            Amount: 0, ValueDate: this.DefaultDate, PayTypeId: "1", AccountId: "", AccountNo: "",
                            BranchNo: "", Bank: "", CreditCardType: "", DonationTypeId: "", ProjectCategoryId: "", ProjectId: "", ReferenceDate: this.DefaultDate,
                            For_Invoice: "", RecievedCustId: "", Payed: false, DepositeRemark: "", ShowMore: false, ShowMoreText: MText,
                            CashCSS: "grey", CreditCSS: "white", BankCSS: "white", OtherCSS: "white", IsShowOthers: false, IsCreditShow: false, IsBankDetShow: false
                        };
                        CurrentModel.RecievedCustId = this.CustId;
                        // debugger;
                        this.modelInput.ReceiptLines.push(ModelObj);
                        this.BindTotal();
                    }
                };
                AmaxReceiptCreate.prototype.ValidatePasteText = function () {
                    var SplitText = this.PasteText.split(/[\t]+/);
                    var IsValidData = true;
                    var msg = "";
                    // debugger;
                    if (SplitText.length == 4) {
                        if (jQuery.isNumeric(SplitText[1].trim()) == false) {
                            IsValidData = false;
                            msg = "Quantity must be numeric only";
                        }
                        var SplitPrice = SplitText[3].trim().split(/[\s]+/);
                        if (SplitPrice.length == 2) {
                            if (jQuery.isNumeric(SplitPrice[1].trim()) == false) {
                                IsValidData = false;
                                msg = "Price must be numeric only";
                            }
                        }
                        else {
                            IsValidData = false;
                            msg = "Please enter text in Product No \t Quantity \t Product Name \t Price format only";
                        }
                    }
                    else {
                        IsValidData = false;
                        msg = "Please enter text in Product No \t Quantity \t Product Name \t Price format only";
                    }
                    if (IsValidData == false) {
                        bootbox.alert({
                            message: msg,
                            className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                    }
                    return IsValidData;
                };
                AmaxReceiptCreate.prototype.GetValidateText = function (keyCode) {
                    if (keyCode == 13) {
                        this.PasteText = jQuery("#PasteText").val();
                        if (this.ValidatePasteText()) {
                            var SplitText = this.PasteText.split(/[\t]+/);
                            this.PopProdObj.ProductNo = SplitText[0].trim();
                            this.PopProdObj.Qty = parseFloat(SplitText[1].trim());
                            this.PopProdObj.ProductName = SplitText[2].trim();
                            var SplitPrice = SplitText[3].trim().split(/[\s]+/);
                            this.PopProdObj.Price = parseFloat(SplitPrice[1].trim()).toFixed(2);
                            this.PopProdObj.Total = (parseFloat(SplitPrice[1].trim()) * parseFloat(SplitText[1].trim())).toFixed(2);
                            this.PasteText = "";
                            jQuery('#PasteTextModal').closeModal();
                            this.BindProdTotal();
                        }
                    }
                };
                AmaxReceiptCreate.prototype.OpenProducts = function (ProdObj) {
                    localStorage.setItem("TempReceiptId", this.modelInput.ReceiptTypeId);
                    this._resourceService.setCookie("TempRowNo", ProdObj.RowNo, 10);
                    if (this.modelInput != undefined && this.modelInput != null) {
                        var jdata = JSON.stringify(this.modelInput);
                        this._resourceService.setCookie("ReceiptCreate_Cache", jdata, 10);
                    }
                    this._resourceService.setCookie("ReceiptCreate_IsShowProducts", this.IsShowProducts, 10);
                    document.location = this.baseUrl + "SearchProducts/" + this.modelInput.CustomerId + "/ReceiptCreate";
                };
                AmaxReceiptCreate.prototype.OpenPasteModal = function (ProdObj) {
                    if ((ProdObj.ProductNo != undefined || ProdObj.ProductNo != null || ProdObj.ProductNo != "")
                        && (ProdObj.ProductName != undefined || ProdObj.ProductName != null || ProdObj.ProductName != "")
                        && (ProdObj.Price != undefined || ProdObj.Price != null || ProdObj.Price != "")) {
                        this.PasteText = "";
                    }
                    else {
                        this.PasteText = ProdObj.ProductNo + " | " + ProdObj.ProductName + " | " + ProdObj.Price;
                    }
                    this.PopProdObj = ProdObj;
                    jQuery('#PasteTextModal').openModal();
                };
                AmaxReceiptCreate.prototype.OpenCustSearch = function () {
                    this.IPopUpOpen = true;
                    localStorage.setItem("TempReceiptId", this.modelInput.ReceiptTypeId);
                    if (this.modelInput != undefined && this.modelInput != null) {
                        var jdata = JSON.stringify(this.modelInput);
                        this._resourceService.setCookie("ReceiptCreate_Cache", jdata, 10);
                    }
                    this._resourceService.setCookie("ReceiptCreate_IsShowProducts", this.IsShowProducts, 10);
                    document.location = this.baseUrl + "Customer/Search/0/ReceiptCreate/" + this.modelInput.CustomerId;
                    //jQuery('#CustSearchModal  .modal-content').html('<object data="' + this.baseUrl+'Customer/Search/1/ReceiptCreate" style="width:100%;height:500px"/>');
                    //jQuery('#CustSearchModal').openModal();
                };
                AmaxReceiptCreate.prototype.OpenNotes = function () {
                    //debugger;
                    //if (this.IPopUpOpen == false) {
                    jQuery('#NoteModal').openModal();
                    //}
                    //else {
                    //    this.modelInput.CustomerId = this._routeParams.params.Id;
                    //    window.open(this.baseUrl + "ReceiptCreate/" + this.modelInput.CustomerId + "/" + this.modelInput.ReceiptTypeId, "_self");
                    //    jQuery('#CustSearchModal').closeModal();
                    //    jQuery(".lean-overlay").css({ "display": "none" });
                    //    this.setdefaultmode();
                    //}
                };
                AmaxReceiptCreate.prototype.OpenTemplates = function () {
                    jQuery('#TemplateModal').openModal();
                };
                AmaxReceiptCreate.prototype.ChooseNote = function (objct) {
                    this.modelInput.CustomerNote = objct.Text;
                    this.modelInput.CustomerNoteId = objct.Value;
                };
                AmaxReceiptCreate.prototype.ChooseThanksLetters = function (objct) {
                    // debugger;
                    this.modelInput.ThanksLetterName = objct.Text;
                    this.modelInput.ThanksLetterId = objct.Value;
                };
                AmaxReceiptCreate.prototype.GetCustomerDetail = function () {
                    var _this = this;
                    var CustId = this.modelInput.CustomerId;
                    this._CustomerService.GetCompleteCustDet(CustId).subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            response = response.Data;
                            _this._Addresses = response.CustomerAddresses;
                            var Mainaddress;
                            jQuery.each(response.CustomerAddresses, function () {
                                if (this.MainAddress == true) {
                                    Mainaddress = this.AddressId;
                                }
                            });
                            _this.modelInput.AddressId = Mainaddress;
                            _this.modelInput.CustomerId = response.CustomerId;
                            _this.modelInput.ReceiptLines[0].RecievedCustId = response.CustomerId;
                            _this.CustId = response.CustomerId;
                            _this.modelInput.CustomerName = response.lname + " " + response.fname;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxReceiptCreate.prototype.ChoosePayType = function (dataobject, pTypeId) {
                    // debugger;
                    dataobject.CashCSS = "white";
                    dataobject.CreditCSS = "white";
                    dataobject.BankCSS = "white";
                    dataobject.OtherCSS = "white";
                    dataobject.IsCreditShow = false;
                    //var pTypeId = "";
                    if (pTypeId != 0) {
                        dataobject.PayTypeId = pTypeId;
                        if (pTypeId == 1) {
                            dataobject.CashCSS = "grey";
                        }
                        else if (pTypeId == 3) {
                            dataobject.CreditCSS = "grey";
                            //dataobject.IsBankDetShow == true;
                            dataobject.IsCreditShow = true;
                        }
                        else if (pTypeId == 8) {
                            dataobject.BankCSS = "grey";
                        }
                        dataobject.IsShowOthers = false;
                    }
                    else {
                        dataobject.PayTypeId = 0;
                        dataobject.IsShowOthers = true;
                        dataobject.OtherCSS = "grey";
                    }
                    if (pTypeId != 1 && pTypeId != 3) {
                        dataobject.IsBankDetShow = true;
                        dataobject.IsCreditShow = false;
                        this.BindAutoCompleteBank();
                    }
                    else if (pTypeId == 3) {
                        dataobject.IsCreditShow = true;
                        dataobject.IsBankDetShow = false;
                    }
                    else {
                        dataobject.IsBankDetShow = false;
                        dataobject.IsCreditShow = false;
                    }
                };
                AmaxReceiptCreate.prototype.BindProjects = function (CatId) {
                    this.BindProjectFromProjCat(CatId);
                };
                AmaxReceiptCreate.prototype.BindProjectFromProjCat = function (CatId) {
                    var _this = this;
                    this._RecieptService.GetProjects(CatId).subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Projects = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxReceiptCreate.prototype.BindAutoCompleteBank = function () {
                    var _this = this;
                    this._RecieptService.GetBanks().subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            //this._Banks = response.Data;
                            var typeaheadSource = [];
                            //  debugger;
                            jQuery.each(response.Data, function () {
                                var newtemp = {};
                                newtemp.id = this.Value;
                                newtemp.name = this.Text;
                                typeaheadSource.push(newtemp);
                            });
                            _this._Banks = response.Data;
                            jQuery('.Bank').typeahead({
                                source: typeaheadSource,
                                dataType: "JSON",
                            });
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxReceiptCreate.prototype.ShowHideProducts = function () {
                    if (this.IsShowProducts == false) {
                        this.modelInput.ReceiptProducts = [];
                        this.modelInput.ReceiptProducts = [{ RowNo: "1", ProductNo: "", ProductName: "", Price: "0", Qty: "1", Total: "0" }];
                        this.IsShowProducts = true;
                    }
                    else {
                        if (this.modelInput.ReceiptProducts.length == 0) {
                            this.IsShowProducts = false;
                        }
                    }
                };
                AmaxReceiptCreate.prototype.CanaddProduct = function (prodObj) {
                    //debugger;
                    return (prodObj.ProductNo != undefined && prodObj.ProductNo != "")
                        && (prodObj.ProductName != undefined && prodObj.ProductName != "")
                        && (prodObj.Price != undefined && prodObj.Price != "")
                        && (prodObj.Qty != undefined && prodObj.Qty != "");
                };
                AmaxReceiptCreate.prototype.AddProducts = function (prodObj) {
                    // debugger;
                    if (this.CanaddProduct(prodObj)) {
                        var ProductObj = { RowNo: (this.modelInput.ReceiptProducts.length + 1).toString(), ProductNo: "", ProductName: "", Price: "0", Qty: "1", Total: "0" };
                        this.modelInput.ReceiptProducts.push(ProductObj);
                        this.BindProdTotal();
                    }
                    else {
                        var msg = '';
                        if (prodObj.ProductNo == undefined || prodObj.ProductNo == "") {
                            msg += '\nPlease enter product no';
                        }
                        if (prodObj.ProductName == undefined || prodObj.ProductName == "") {
                            msg += '\nPlease enter product name';
                        }
                        if (prodObj.Price == undefined || prodObj.Price == "") {
                            msg += '\nPlease enter price';
                        }
                        if (prodObj.Qty == undefined || prodObj.Qty == "") {
                            msg += '\nPlease enter quantity';
                        }
                        bootbox.alert({
                            message: msg, className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                    }
                };
                AmaxReceiptCreate.prototype.delProductDet = function (ProdObj) {
                    //  debugger;
                    //if (this.modelInput.ReceiptProducts.length > 1) {
                    var index = 0;
                    jQuery.each(this.modelInput.ReceiptProducts, function () {
                        if (this == ProdObj) {
                            return false;
                        }
                        index = index + 1;
                    });
                    this.modelInput.ReceiptProducts.splice(index, 1);
                    index = 1;
                    jQuery.each(this.modelInput.ReceiptProducts, function () {
                        this.RowNo = index.toString();
                        index = index + 1;
                    });
                    this.BindProdTotal();
                    if (this.modelInput.ReceiptProducts.length == 0) {
                        this.IsShowProducts = false;
                    }
                    //}
                };
                AmaxReceiptCreate.prototype.CalculateProdRowTotal = function (prodObj) {
                    //  debugger;
                    var Price = 0;
                    if (prodObj.Price != undefined && prodObj.Price != null && prodObj.Qty != "") {
                        Price = parseFloat(prodObj.Price);
                    }
                    var Qty = 0;
                    if (prodObj.Qty != undefined && prodObj.Qty != null && prodObj.Qty != "") {
                        Qty = parseFloat(prodObj.Qty);
                    }
                    prodObj.Total = (Price * Qty).toFixed(2);
                    this.BindProdTotal();
                };
                AmaxReceiptCreate.prototype.BindProdTotal = function () {
                    var ProdTotal = 0;
                    jQuery.each(this.modelInput.ReceiptProducts, function () {
                        ProdTotal = parseFloat(ProdTotal.toString()) + parseFloat(this.Total);
                    });
                    this.modelInput.ProductTotal = ProdTotal.toFixed(2);
                };
                AmaxReceiptCreate.prototype.ngOnInit = function () {
                    var _this = this;
                    //jQuery(".lean-overlay").css({ "display": "none" });
                    jQuery("#NoteModal").closeModal();
                    jQuery(".lean-overlay").css({ "display": "none" });
                    window.scrollTo(0, 0);
                    debugger;
                    var jdata = this._resourceService.getCookie("ReceiptCreate_Cache");
                    if (jdata != undefined && jdata != undefined && jdata != "") {
                        jdata = jdata.substring(1, jdata.length);
                        this.modelInput = jQuery.parseJSON(jdata);
                        this.modelInput.CustomerId = this._routeParams.params.Id;
                        this.GetCustomerDetail();
                    }
                    //  alert("ddd");
                    this.Lang = localStorage.getItem("lang");
                    this._resourceService.GetLangRes(this.Formtype, this.Lang).subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.RES = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._RecieptService.GetCustomerNotes().subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._CustomerNotes = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this.BindAutoCompleteBank();
                    this._RecieptService.GetThanksLetters(this.modelInput.ReceiptTypeId).subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._ThankLetters = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._RecieptService.GetAssociation().subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            //debugger;
                            _this.modelInput.associationId = response.Data[0].Value;
                            _this.modelInput.associationName = response.Data[0].Text;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._RecieptService.GetPrinter().subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            //debugger;
                            _this.modelInput.PrinterId = response.Data[0].Value;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._RecieptService.GetEmployee().subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            //debugger;
                            _this.modelInput.EmployeeId = response.Data[0].Value;
                            _this.modelInput.EmployeeName = response.Data[0].Text;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._RecieptService.GetPayType().subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._PayTypes = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._RecieptService.GetAccounts().subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Accounts = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._RecieptService.GetGoals().subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Goals = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._RecieptService.GetProjectCats().subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._ProjectCats = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this.BindProjectFromProjCat(-1);
                    this._RecieptService.GetCurrenciesFDB().subscribe(function (resp) {
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Currencies = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._RecieptService.GetRecieptType(this._routeParams.params.ReceiptTypeId).subscribe(function (resp) {
                        // debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.modelInput.RecieptType = response.Data[0].RecieptNameEng;
                            _this.modelInput.CurrencyId = response.Data[0].CurrencyId;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._RecieptService.GetReceiptDetail().subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.modelInput.RecieptNo = response.Data.Value;
                            _this.modelInput.RecieptDate = _this.DefaultDate;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    var CustId = this.modelInput.CustomerId;
                    this.GetCustomerDetail();
                    var isshow = this._resourceService.getCookie("ReceiptCreate_IsShowProducts");
                    if (isshow != undefined && isshow != undefined && isshow != "") {
                        isshow = isshow.substring(1, isshow.length);
                        this.IsShowProducts = Boolean(isshow);
                    }
                    var rowno = this._resourceService.getCookie("TempRowNo");
                    if (rowno != undefined && rowno != undefined && rowno != "") {
                        rowno = rowno.substring(1, rowno.length);
                        var pdata = this._resourceService.getCookie("ReceiptCreate_Product");
                        if (pdata != undefined && pdata != undefined && pdata != "") {
                            pdata = pdata.substring(1, pdata.length);
                            var Product = [];
                            Product = jQuery.parseJSON(pdata);
                            jQuery.each(this.modelInput.ReceiptProducts, function () {
                                if (this.RowNo == rowno) {
                                    this.ProductNo = Product.PartNumber;
                                    this.ProductName = Product.ProdNameDis;
                                    this.Price = parseFloat(Product.Price).toFixed(2);
                                    this.Total = (parseFloat(this.Price) * parseFloat(this.Qty)).toFixed(2);
                                    return false;
                                }
                            });
                            this.BindProdTotal();
                            this._resourceService.deleteCookie("TempRowNo");
                            this._resourceService.deleteCookie("ReceiptCreate_Product");
                        }
                    }
                };
                AmaxReceiptCreate.$inject = ['$scope', '$location', '$anchorScroll'];
                AmaxReceiptCreate = __decorate([
                    core_1.Component({
                        templateUrl: './app/amax/Receipt/templates/ReceiptCreate.html',
                        directives: [common_1.NgSwitch, common_1.NgSwitchWhen, common_1.NgSwitchDefault, basicComponents_1.AmaxDate],
                        providers: [RecieptService_1.RecieptService, ResourceService_1.ResourceService, CustomerService_1.CustomerService, ChargeCreditService_1.ChargeCreditService]
                    }), 
                    __metadata('design:paramtypes', [ResourceService_1.ResourceService, RecieptService_1.RecieptService, CustomerService_1.CustomerService, router_1.RouteParams, ChargeCreditService_1.ChargeCreditService])
                ], AmaxReceiptCreate);
                return AmaxReceiptCreate;
            }());
            exports_1("AmaxReceiptCreate", AmaxReceiptCreate);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFtYXgvUmVjZWlwdC9SZWNlaXB0Q3JlYXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1lBa0JBO2dCQWtDRyw4REFBOEQ7Z0JBQzdELDJCQUFvQixnQkFBaUMsRUFBVSxlQUErQixFQUFVLGdCQUFpQyxFQUFVLFlBQXlCLEVBQVUsb0JBQXlDO29CQUEzTSxxQkFBZ0IsR0FBaEIsZ0JBQWdCLENBQWlCO29CQUFVLG9CQUFlLEdBQWYsZUFBZSxDQUFnQjtvQkFBVSxxQkFBZ0IsR0FBaEIsZ0JBQWdCLENBQWlCO29CQUFVLGlCQUFZLEdBQVosWUFBWSxDQUFhO29CQUFVLHlCQUFvQixHQUFwQixvQkFBb0IsQ0FBcUI7b0JBakMvTixRQUFHLEdBQVcsRUFBRSxDQUFDO29CQUNqQixhQUFRLEdBQVcsc0JBQXNCLENBQUM7b0JBQzFDLFNBQUksR0FBVyxFQUFFLENBQUM7b0JBQ2xCLFdBQU0sR0FBRyxFQUFFLENBQUM7b0JBQ1osbUJBQWMsR0FBRyxFQUFFLENBQUM7b0JBQ3BCLGVBQVUsR0FBRyxFQUFFLENBQUM7b0JBQ2hCLGNBQVMsR0FBRyxFQUFFLENBQUM7b0JBQ2YsY0FBUyxHQUFHLEVBQUUsQ0FBQztvQkFDZixXQUFNLEdBQUcsRUFBRSxDQUFDO29CQUNaLGlCQUFZLEdBQUcsRUFBRSxDQUFDO29CQUNsQixjQUFTLEdBQUcsRUFBRSxDQUFDO29CQUNmLGdCQUFXLEdBQUcsRUFBRSxDQUFDO29CQUNqQixjQUFTLEdBQVcsRUFBRSxDQUFDO29CQUN2QixtQkFBYyxHQUFZLEtBQUssQ0FBQztvQkFDcEMsbUNBQW1DO29CQUMvQixrQkFBYSxHQUFHLEVBQUUsQ0FBQztvQkFDbkIsYUFBUSxHQUFVLENBQUMsQ0FBQztvQkFDcEIsaUJBQVksR0FBVyxFQUFFLENBQUM7b0JBQzFCLGtCQUFhLEdBQVMsTUFBTSxDQUFDO29CQUM3QixhQUFRLEdBQVcsY0FBYyxDQUFDO29CQUNsQyxlQUFVLEdBQVcsRUFBRSxDQUFDO29CQUN4QixjQUFTLEdBQVcsRUFBRSxDQUFDO29CQUN2QixpQkFBWSxHQUFXLEVBQUUsQ0FBQztvQkFDMUIsY0FBUyxHQUFXLEVBQUUsQ0FBQztvQkFFdkIsaUJBQVksR0FBVyxFQUFFLENBQUM7b0JBQzFCLGFBQVEsR0FBWSxLQUFLLENBQUM7b0JBQzFCLGtCQUFhLEdBQVksS0FBSyxDQUFDO29CQUMvQixnQkFBVyxHQUFXLEVBQUUsQ0FBQztvQkFDekIsZUFBVSxHQUFZLEtBQUssQ0FBQztvQkFDNUIsZUFBVSxHQUFXLEVBQUUsQ0FBQztvQkFLcEIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsR0FBRyxFQUFFLENBQUM7b0JBQ25DLElBQUksQ0FBQyxVQUFVLEdBQUcsRUFBRSxDQUFDO29CQUNyQixnQ0FBZ0M7b0JBQ2hDLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxHQUFHLEVBQUUsQ0FBQztvQkFDbEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLEdBQUcsRUFBRSxDQUFDO29CQUNyQyx1SEFBdUg7b0JBQ3ZILElBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDO29CQUM1QixJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztvQkFDeEIsSUFBSSxDQUFDLGFBQWEsR0FBRyxLQUFLLENBQUM7b0JBQzNCLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxHQUFHLFlBQVksQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDO29CQUNsRSw0Q0FBNEM7b0JBQzVDLFlBQVk7b0JBQ2Isd0NBQXdDO29CQUN2QyxJQUFJLENBQUMsT0FBTyxHQUFHLGdCQUFnQixDQUFDLE1BQU0sQ0FBQztvQkFDdkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsWUFBWSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7b0JBQ3BELElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxHQUFHLEVBQUUsQ0FBQztvQkFDbEMsOENBQThDO29CQUMvQyw4QkFBOEI7b0JBQzdCLElBQUksQ0FBQyxXQUFXLEdBQUcsTUFBTSxDQUFDLElBQUksSUFBSSxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUM7b0JBQzNELElBQUksQ0FBQyxJQUFJLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDekMsSUFBSSxLQUFLLEdBQUcsRUFBRSxDQUFDO29CQUNmLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzt3QkFDcEIsS0FBSyxHQUFHLE1BQU0sQ0FBQztvQkFDbkIsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixLQUFLLEdBQUcsTUFBTSxDQUFDO29CQUNuQixDQUFDO29CQUNELElBQUksTUFBTSxHQUFHO3dCQUNULE1BQU0sRUFBRSxDQUFDLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxXQUFXLEVBQUUsU0FBUyxFQUFFLENBQUMsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFLFNBQVMsRUFBRSxFQUFFO3dCQUNsRixRQUFRLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsY0FBYyxFQUFFLEVBQUUsRUFBRSxjQUFjLEVBQUUsRUFBRSxFQUFFLGlCQUFpQixFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFLGFBQWEsRUFBRSxJQUFJLENBQUMsV0FBVzt3QkFDckksV0FBVyxFQUFFLEVBQUUsRUFBRSxjQUFjLEVBQUUsRUFBRSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsY0FBYyxFQUFFLEVBQUUsRUFBRSxRQUFRLEVBQUUsS0FBSyxFQUFFLFlBQVksRUFBRSxLQUFLO3dCQUMzRyxPQUFPLEVBQUUsTUFBTSxFQUFFLFNBQVMsRUFBRSxPQUFPLEVBQUUsT0FBTyxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsT0FBTyxFQUFFLFlBQVksRUFBRSxLQUFLLEVBQUUsWUFBWSxFQUFFLEtBQUssRUFBRSxhQUFhLEVBQUUsS0FBSztxQkFDM0ksQ0FBQztvQkFFRixJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBRTlDLENBQUM7Z0JBQ0QsZ0RBQW9CLEdBQXBCLFVBQXFCLEdBQUcsRUFBRSxPQUFPO29CQUM3QixPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUNqQixPQUFPLENBQUMsU0FBUyxHQUFHLEdBQUcsQ0FBQztvQkFDeEIsb0NBQW9DO29CQUNwQyx1QkFBdUI7Z0JBQzNCLENBQUM7Z0JBR0QsK0NBQW1CLEdBQW5CLFVBQW9CLEdBQUcsRUFBRSxPQUFPO29CQUM1QixPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUNqQixPQUFPLENBQUMsYUFBYSxHQUFHLEdBQUcsQ0FBQztvQkFDNUIsb0NBQW9DO29CQUNwQyx1QkFBdUI7Z0JBQzNCLENBQUM7Z0JBRUQsZ0NBQUksR0FBSixVQUFLLFFBQVE7b0JBQ1QsaUJBQWlCO29CQUNqQixFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsUUFBUSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7d0JBQzVCLFFBQVEsQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO3dCQUMxQixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQ3BCLFFBQVEsQ0FBQyxZQUFZLEdBQUcsTUFBTSxDQUFDO3dCQUNuQyxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLFFBQVEsQ0FBQyxZQUFZLEdBQUcsTUFBTSxDQUFDO3dCQUNuQyxDQUFDO29CQUVMLENBQUM7b0JBQ0QsSUFBSSxDQUFDLENBQUM7d0JBQ0YsUUFBUSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7d0JBQ3pCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDcEIsUUFBUSxDQUFDLFlBQVksR0FBRyxNQUFNLENBQUM7d0JBQ25DLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsUUFBUSxDQUFDLFlBQVksR0FBRyxTQUFTLENBQUM7d0JBQ3RDLENBQUM7b0JBRUwsQ0FBQztnQkFDTCxDQUFDO2dCQUNELDBDQUFjLEdBQWQsVUFBZSxTQUFTLEVBQUMsT0FBTztvQkFDNUIsRUFBRSxDQUFDLENBQUMsU0FBUyxJQUFJLENBQUMsSUFBSSxTQUFTLElBQUksQ0FBQyxDQUFDLENBQ3JDLENBQUM7d0JBQ0csT0FBTyxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7d0JBQzdCLE9BQU8sQ0FBQyxZQUFZLEdBQUcsS0FBSyxDQUFDO3dCQUM3QixJQUFJLENBQUMsb0JBQW9CLEVBQUUsQ0FBQztvQkFDaEMsQ0FBQztvQkFBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ3hCLE9BQU8sQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDO3dCQUM1QixPQUFPLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztvQkFDbEMsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixPQUFPLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQzt3QkFDOUIsT0FBTyxDQUFDLFlBQVksR0FBRyxLQUFLLENBQUM7b0JBQ2pDLENBQUM7Z0JBQ0wsQ0FBQztnQkFDRCwwQ0FBYyxHQUFkO29CQUFBLGlCQTJIQztvQkExSEcsc0hBQXNIO29CQUN0SCxJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztvQkFFeEIsSUFBSSxDQUFDLFFBQVEsR0FBRyxDQUFDLENBQUM7b0JBQ2xCLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO29CQUN0QixJQUFJLGNBQWMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQTtvQkFDbEQsSUFBSSxlQUFlLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUM7b0JBRWxELElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDO29CQUN4QyxJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQztvQkFDNUMsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUM7b0JBQzFDLElBQUksWUFBWSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDO29CQUNsRCxJQUFJLGNBQWMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQztvQkFDL0MsSUFBSSxlQUFlLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLENBQUM7b0JBQ3RELElBQUksU0FBUyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDO29CQUMxQyxJQUFJLGFBQWEsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQztvQkFDbEQsSUFBSSxDQUFDLFVBQVUsR0FBRyxFQUFFLENBQUM7b0JBQ3JCLElBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDO29CQUM1QixJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBRyxNQUFNLENBQUM7b0JBQ3BDLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxHQUFHLFFBQVEsQ0FBQztvQkFFeEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEdBQUcsU0FBUyxDQUFDO29CQUN0QyxJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsR0FBRyxlQUFlLENBQUM7b0JBRWxELElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLFlBQVksQ0FBQztvQkFDOUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsY0FBYyxDQUFDO29CQUNoRCxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsR0FBRyxjQUFjLENBQUM7b0JBQy9DLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxHQUFHLFNBQVMsQ0FBQztvQkFDdEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEdBQUcsYUFBYSxDQUFDO29CQUM5QyxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUM7b0JBQ2xDLElBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxHQUFHLEVBQUUsQ0FBQztvQkFDckMsdUhBQXVIO29CQUN2SCxJQUFJLE1BQU0sR0FBRzt3QkFDVCxNQUFNLEVBQUUsQ0FBQyxFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsV0FBVyxFQUFFLFNBQVMsRUFBRSxDQUFDLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRTt3QkFDbEYsUUFBUSxFQUFFLEVBQUUsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLGNBQWMsRUFBRSxFQUFFLEVBQUUsY0FBYyxFQUFFLEVBQUUsRUFBRSxpQkFBaUIsRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRSxhQUFhLEVBQUUsSUFBSSxDQUFDLFdBQVc7d0JBQ3JJLFdBQVcsRUFBRSxFQUFFLEVBQUUsY0FBYyxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLGNBQWMsRUFBRSxFQUFFLEVBQUUsUUFBUSxFQUFFLEtBQUssRUFBRSxZQUFZLEVBQUUsTUFBTTt3QkFDaEgsT0FBTyxFQUFFLE1BQU0sRUFBRSxTQUFTLEVBQUUsT0FBTyxFQUFFLE9BQU8sRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLE9BQU8sRUFBRSxZQUFZLEVBQUUsS0FBSyxFQUFFLFlBQVksRUFBRSxLQUFLLEVBQUUsYUFBYSxFQUFFLEtBQUs7cUJBQzNJLENBQUM7b0JBRUYsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUMxQyxpQ0FBaUM7b0JBRWpDLGdEQUFnRDtvQkFDaEQsSUFBSSxDQUFDLGVBQWUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDdEYsWUFBWTt3QkFDWixJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO2dDQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQzVCLE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEtBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDOzRCQUM5RCxLQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQzt3QkFFN0QsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFDSCw4QkFBOEI7b0JBRTlCLElBQUksQ0FBQyxlQUFlLENBQUMsV0FBVyxFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDN0MsV0FBVzt3QkFDWCxJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO2dDQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQzVCLE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLFdBQVc7NEJBQ1gsS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7NEJBQ3BELEtBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO3dCQUV6RCxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUVILElBQUksQ0FBQyxlQUFlLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUNsRCxZQUFZO3dCQUNaLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7NEJBQ2hELEtBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO3dCQUVyRCxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO2dCQUNQLENBQUM7Z0JBQ0QsMkNBQWUsR0FBZixVQUFnQixNQUFNO29CQUF0QixpQkFzSkM7b0JBckpFLFlBQVk7b0JBQ1gsK0JBQStCO29CQUMvQixHQUFHO29CQUNILElBQUksT0FBTyxHQUFHLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQztvQkFDckMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxzQkFBc0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUMvRCxXQUFXO3dCQUNYLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzt3QkFFL0MsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFFSCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLFNBQVM7MkJBQzlHLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksU0FBUzsyQkFDakgsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsTUFBTSxHQUFHLENBQUM7MkJBQ3ZDLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLElBQUksU0FBUzsyQkFDMUgsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxTQUFTOzJCQUNuSCxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxJQUFJLFNBQVM7MkJBQzdILElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLElBQUksU0FBUzsyQkFDOUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsSUFBSSxTQUM1RyxDQUFDLENBQUMsQ0FBQzt3QkFFQyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQzt3QkFDNUQsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDO3dCQUNwRCxJQUFJLGFBQWEsR0FBRyxJQUFJLENBQUM7d0JBQ3pCLEVBQUUsQ0FBQyxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDOzRCQUNoQixhQUFhLEdBQUcsS0FBSyxDQUFDO3dCQUMxQixDQUFDO3dCQUNELHlDQUF5Qzt3QkFFekMsR0FBRyxDQUFDLENBQUMsSUFBSSxHQUFHLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsQ0FDN0MsQ0FBQzs0QkFDRyxJQUFJLFlBQVksR0FBRyxlQUFlLEdBQUcsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFLEdBQUcscUNBQXFDLENBQUM7NEJBQzVHLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsRUFBRSxZQUFZLENBQUMsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDO2dDQUNsRixhQUFhLEdBQUcsS0FBSyxDQUFDO2dDQUN0QixLQUFLLENBQUM7NEJBQ1YsQ0FBQzt3QkFDTCxDQUFDO3dCQUVELEdBQUcsQ0FBQyxDQUFDLElBQUksR0FBRyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxDQUFDLENBQ2hELENBQUM7NEJBQ0csSUFBSSxZQUFZLEdBQUcsZUFBZSxHQUFHLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRSxHQUFHLGdDQUFnQyxDQUFDOzRCQUN2RyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLEVBQUUsWUFBWSxFQUFDLEdBQUcsQ0FBQyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUM7Z0NBQ2hHLGFBQWEsR0FBRyxLQUFLLENBQUM7Z0NBQ3RCLEtBQUssQ0FBQzs0QkFDVixDQUFDO3dCQUNMLENBQUM7d0JBR0QsRUFBRSxDQUFDLENBQUMsYUFBYSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQ3hCLFdBQVc7NEJBQ1gsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7NEJBQzVDLHFCQUFxQjs0QkFDckIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTtnQ0FDckQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQztnQ0FDdEIsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7Z0NBQ3RDLEtBQUksQ0FBQyxZQUFZLEdBQUcsRUFBRSxDQUFDO2dDQUV2QixFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7b0NBQzNCLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUM7b0NBQ3ZCLEtBQUksQ0FBQyxRQUFRLEdBQUcsYUFBYSxDQUFDO2dDQUNsQyxDQUFDO2dDQUNELElBQUksQ0FBQyxDQUFDO29DQUNGLE9BQU8sQ0FBQyxLQUFLLENBQUM7d0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO3dDQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7d0NBQzVCLE9BQU8sRUFBRTs0Q0FDTCxFQUFFLEVBQUU7Z0RBQ0EsY0FBYztnREFDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7NkNBQzVCO3lDQUNKO3FDQUNKLENBQUMsQ0FBQztvQ0FDSCxLQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxDQUFDLHFCQUFxQixDQUFDLENBQUM7b0NBRTFELEVBQUUsQ0FBQyxDQUFDLE1BQU0sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO3dDQUNqQixRQUFRLENBQUMsUUFBUSxHQUFHLEtBQUksQ0FBQyxPQUFPLEdBQUcsZ0JBQWdCLEdBQUcsS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsSUFBSSxHQUFHLEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDO29DQUN6SCxDQUFDO29DQUNELElBQUksQ0FBQyxDQUFDO3dDQUNGLEtBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQzt3Q0FDdEIsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUM7d0NBQ3pELEtBQUksQ0FBQyxNQUFNLEdBQUcsUUFBUSxDQUFDLFVBQVUsQ0FBQztvQ0FDdEMsQ0FBQztnQ0FDTCxDQUFDOzRCQUVMLENBQUMsRUFDRyxVQUFBLEtBQUssSUFBRyxPQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEVBQWxCLENBQWtCLEVBQzFCLGNBQU0sT0FBQSxPQUFPLENBQUMsR0FBRyxDQUFDLHNCQUFzQixDQUFDLEVBQW5DLENBQW1DLENBQzVDLENBQUM7d0JBRU4sQ0FBQztvQkFFTCxDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUNGLElBQUksR0FBRyxHQUFHLEVBQUUsQ0FBQzt3QkFDYixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUM7NEJBQ3BILEdBQUcsSUFBSSw2QkFBNkIsQ0FBQzt3QkFDekMsQ0FBQzt3QkFDRCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUM7NEJBQ3BILEdBQUcsSUFBSSw0QkFBNEIsQ0FBQzt3QkFDeEMsQ0FBQzt3QkFDRCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUM7NEJBQzdILEdBQUcsSUFBSSwrQkFBK0IsQ0FBQzt3QkFDM0MsQ0FBQzt3QkFDRCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUM7NEJBQ3BILEdBQUcsSUFBSSxpQ0FBaUMsQ0FBQzt3QkFDN0MsQ0FBQzt3QkFDRCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUM7NEJBQ2hJLEdBQUcsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQzs0QkFDdEMsR0FBRyxJQUFJLGtDQUFrQyxDQUFDO3dCQUM5QyxDQUFDO3dCQUNELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQzs0QkFDakgsR0FBRyxJQUFJLHlDQUF5QyxDQUFDO3dCQUNyRCxDQUFDO3dCQUNELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQzs0QkFDakgsR0FBRyxJQUFJLDJCQUEyQixDQUFDO3dCQUN2QyxDQUFDO3dCQUNELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDOzRCQUMzQyxHQUFHLElBQUksOENBQThDLENBQUM7d0JBQzFELENBQUM7d0JBQ0QsT0FBTyxDQUFDLEtBQUssQ0FBQzs0QkFDVixPQUFPLEVBQUUsR0FBRzs0QkFDWixTQUFTLEVBQUUsSUFBSSxDQUFDLFlBQVk7NEJBQzVCLE9BQU8sRUFBRTtnQ0FDTCxFQUFFLEVBQUU7b0NBQ0EsY0FBYztvQ0FDZCxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVM7aUNBQzVCOzZCQUNKO3lCQUNKLENBQUMsQ0FBQztvQkFDUCxDQUFDO29CQUNMLEdBQUc7Z0JBQ0gsQ0FBQztnQkFFRCxvQ0FBUSxHQUFSLFVBQVMsUUFBUTtvQkFDYixXQUFXO29CQUNYLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUMxQyxJQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7d0JBQ2QsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksRUFBRTs0QkFDdEMsRUFBRSxDQUFDLENBQUMsSUFBSSxJQUFJLFFBQVEsQ0FBQyxDQUFDLENBQUM7Z0NBQ25CLE1BQU0sQ0FBQyxLQUFLLENBQUE7NEJBQ2hCLENBQUM7NEJBQ0QsS0FBSyxHQUFHLEtBQUssR0FBRyxDQUFDLENBQUM7d0JBRXRCLENBQUMsQ0FBQyxDQUFDO3dCQUNILElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUM7d0JBQzlDLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztvQkFDckIsQ0FBQztnQkFDTCxDQUFDO2dCQUNELHFDQUFTLEdBQVQ7b0JBQUEsaUJBeUNDO29CQXhDRyxJQUFJLE1BQU0sR0FBRyxDQUFDLENBQUM7b0JBQ2YsV0FBVztvQkFDWCxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxFQUFFO3dCQUN0QyxNQUFNLElBQUksVUFBVSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFFdEMsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLEdBQUcsTUFBTSxDQUFDO29CQUUvQixJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQztvQkFDdEMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDbkIsRUFBRSxDQUFDLENBQUMsS0FBSyxJQUFJLElBQUksSUFBSSxLQUFLLElBQUksRUFBRSxDQUFDO3dCQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDO29CQUMzRCxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQztvQkFDdkMsZUFBZTtvQkFDZixJQUFJLENBQUMsZUFBZSxDQUFDLGVBQWUsQ0FBQyxLQUFLLEVBQUUsS0FBSyxFQUFFLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7d0JBRXhFLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO2dDQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQzVCLE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUVGLHlCQUF5Qjs0QkFDekIsS0FBSSxDQUFDLFVBQVUsQ0FBQyxrQkFBa0IsR0FBRyxVQUFVLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLE1BQU0sQ0FBQzs0QkFDeEUsS0FBSSxDQUFDLFVBQVUsQ0FBQyxrQkFBa0IsR0FBRyxLQUFJLENBQUMsVUFBVSxDQUFDLGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDdkYsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztnQkFFUCxDQUFDO2dCQUNELDRDQUFnQixHQUFoQjtvQkFBQSxpQkFtREM7b0JBakRHLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7d0JBQ3pDLElBQUksU0FBUyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDO3dCQUMvQyxJQUFJLFlBQVksR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQzt3QkFDakQsSUFBSSxXQUFXLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUM7d0JBQzdDLElBQUksZUFBZSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDO3dCQUNyRCxJQUFJLGNBQWMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQzt3QkFDaEQsSUFBSSxDQUFDLGVBQWUsQ0FBQyxnQkFBZ0IsQ0FBQyxXQUFXLEVBQUUsZUFBZSxFQUFFLFNBQVMsRUFBRSxZQUFZLEVBQUUsY0FBYyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTs0QkFDNUgsWUFBWTs0QkFDWCxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzs0QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDO2dDQUM1QixJQUFJLENBQUMsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0NBQ2pELEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxPQUFPLENBQUMsQ0FBQyxDQUFDO29DQUN0RCxJQUFJLFNBQVMsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsUUFBUSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQztvQ0FDdkYsSUFBSSxZQUFZLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsT0FBTyxFQUFFLG9EQUFvRCxDQUFDLENBQUM7Z0NBRzdHLENBQUM7Z0NBQ0QsSUFBSSxDQUFDLENBQUM7b0NBQ0YsT0FBTyxDQUFDLEtBQUssQ0FBQzt3Q0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLElBQUk7d0NBQ3RCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTt3Q0FDNUIsT0FBTyxFQUFFOzRDQUNMLEVBQUUsRUFBRTtnREFDQSxjQUFjO2dEQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUzs2Q0FDNUI7eUNBQ0o7cUNBQ0osQ0FBQyxDQUFDO2dDQUNQLENBQUM7NEJBQ0wsQ0FBQzs0QkFBQyxJQUFJLENBQUMsQ0FBQztnQ0FFSixPQUFPLENBQUMsS0FBSyxDQUFDO29DQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtvQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO29DQUM1QixPQUFPLEVBQUU7d0NBQ0wsRUFBRSxFQUFFOzRDQUNBLGNBQWM7NENBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3lDQUM1QjtxQ0FDSjtpQ0FDSixDQUFDLENBQUM7NEJBQ1AsQ0FBQzt3QkFFTCxDQUFDLEVBQUUsVUFBQSxLQUFLOzRCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7d0JBQ3ZCLENBQUMsRUFBRTs0QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO3dCQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFDUCxDQUFDO2dCQUNMLENBQUM7Z0JBRUQsb0NBQVEsR0FBUixVQUFTLFFBQVE7b0JBQ2IsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDO29CQUNkLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztvQkFDaEIsUUFBUSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDO29CQUN0QyxJQUFJLEdBQUcsUUFBUSxDQUFDO29CQUVoQixJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztvQkFDdEMsSUFBSSxRQUFRLEdBQUcsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDbkYsUUFBUSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQztvQkFDdkMsSUFBSSxNQUFNLEdBQUcsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQztvQkFDbkQscUNBQXFDO29CQUNyQyw0QkFBNEI7b0JBQzVCLElBQUksTUFBTSxHQUFHLEVBQUUsTUFBTSxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLFFBQVEsRUFBRSxTQUFTLEVBQUUsUUFBUSxDQUFDLFNBQVMsRUFBRSxTQUFTLEVBQUUsUUFBUSxDQUFDLFNBQVMsRUFBRSxTQUFTLEVBQUUsUUFBUSxDQUFDLFNBQVMsRUFBRSxRQUFRLEVBQUUsUUFBUSxDQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsUUFBUSxDQUFDLElBQUksRUFBRSxjQUFjLEVBQUUsUUFBUSxDQUFDLGNBQWMsRUFBRSxjQUFjLEVBQUUsUUFBUSxDQUFDLGNBQWMsRUFBRSxpQkFBaUIsRUFBRSxRQUFRLENBQUMsaUJBQWlCLEVBQUUsU0FBUyxFQUFFLFFBQVEsQ0FBQyxTQUFTLEVBQUUsYUFBYSxFQUFFLFFBQVEsQ0FBQyxhQUFhLEVBQUUsV0FBVyxFQUFFLFFBQVEsQ0FBQyxXQUFXLEVBQUUsY0FBYyxFQUFFLFFBQVEsQ0FBQyxjQUFjLEVBQUUsS0FBSyxFQUFFLFFBQVEsQ0FBQyxLQUFLLEVBQUUsY0FBYyxFQUFFLFFBQVEsQ0FBQyxjQUFjLEVBQUcsQ0FBQztvQkFDamlCLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDMUMsSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO29CQUNkLElBQUksU0FBUyxHQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQztvQkFDbEQsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksRUFBRTt3QkFDdEMsRUFBRSxDQUFDLENBQUMsS0FBSyxJQUFJLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs0QkFFM0IsSUFBSSxDQUFDLFNBQVMsR0FBRyxNQUFNLENBQUM7d0JBQzVCLENBQUM7d0JBQ0csS0FBSyxFQUFFLENBQUM7b0JBQ2hCLENBQUMsQ0FBQyxDQUFDO29CQUNILElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztnQkFDckIsQ0FBQztnQkFFRCw0Q0FBZ0IsR0FBaEIsVUFBaUIsWUFBWSxFQUFFLEdBQUc7b0JBQzlCLFdBQVc7b0JBQ1gsSUFBSSxXQUFXLEdBQUcsSUFBSSxDQUFDO29CQUN2QixFQUFFLENBQUMsQ0FBQyxZQUFZLENBQUMsU0FBUyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7d0JBQy9CLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsU0FBUyxFQUFFLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQyxPQUFPLEVBQUUsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDOzRCQUN4RSxPQUFPLENBQUMsS0FBSyxDQUFDLEVBQUUsT0FBTyxFQUFFLHlCQUF5QixFQUFFLENBQUMsQ0FBQzs0QkFDdEQsTUFBTSxDQUFDLEtBQUssQ0FBQzt3QkFDakIsQ0FBQztvQkFDTCxDQUFDO29CQUNELEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxhQUFhLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzt3QkFDbkMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxhQUFhLEVBQUUsWUFBWSxFQUFFLElBQUksQ0FBQyxDQUFDLE9BQU8sRUFBRSxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUM7NEJBQzVFLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBRSxPQUFPLEVBQUUsNkJBQTZCLEVBQUUsQ0FBQyxDQUFDOzRCQUMxRCxNQUFNLENBQUMsS0FBSyxDQUFDO3dCQUNqQixDQUFDO29CQUNMLENBQUM7b0JBRUcsZUFBZTtvQkFDZixFQUFFLENBQUMsQ0FBQyxZQUFZLENBQUMsTUFBTSxJQUFJLElBQUksSUFBSSxZQUFZLENBQUMsTUFBTSxJQUFJLEVBQUUsSUFBSSxZQUFZLENBQUMsTUFBTSxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUM7d0JBQy9GLFdBQVcsR0FBRyxLQUFLLENBQUM7d0JBQ3BCLEdBQUcsSUFBSSx5QkFBeUIsQ0FBQztvQkFDckMsQ0FBQztvQkFDRCxFQUFFLENBQUMsQ0FBQyxZQUFZLENBQUMsU0FBUyxJQUFJLElBQUksSUFBSSxZQUFZLENBQUMsU0FBUyxJQUFJLEVBQUUsSUFBSSxZQUFZLENBQUMsU0FBUyxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUM7d0JBQ3hHLFdBQVcsR0FBRyxLQUFLLENBQUM7d0JBQ3BCLEdBQUcsSUFBSSwyQkFBMkIsQ0FBQztvQkFDdkMsQ0FBQztvQkFDRCxFQUFFLENBQUMsQ0FBQyxZQUFZLENBQUMsU0FBUyxJQUFJLElBQUksSUFBSSxZQUFZLENBQUMsU0FBUyxJQUFJLEVBQUUsSUFBSSxZQUFZLENBQUMsU0FBUyxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUM7d0JBQ3hHLFdBQVcsR0FBRyxLQUFLLENBQUM7d0JBQ3BCLEdBQUcsSUFBSSwyQkFBMkIsQ0FBQztvQkFDdkMsQ0FBQztvQkFDRCxFQUFFLENBQUMsQ0FBQyxZQUFZLENBQUMsY0FBYyxJQUFJLElBQUksSUFBSSxZQUFZLENBQUMsY0FBYyxJQUFJLEVBQUUsSUFBSSxZQUFZLENBQUMsY0FBYyxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUM7d0JBQ3ZILFdBQVcsR0FBRyxLQUFLLENBQUM7d0JBQ3BCLEdBQUcsSUFBSSx3QkFBd0IsQ0FBQztvQkFDcEMsQ0FBQztvQkFDRCxFQUFFLENBQUMsQ0FBQyxZQUFZLENBQUMsU0FBUyxJQUFJLElBQUksSUFBSSxZQUFZLENBQUMsU0FBUyxJQUFJLEVBQUUsSUFBSSxZQUFZLENBQUMsU0FBUyxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUM7d0JBQ3hHLFdBQVcsR0FBRyxLQUFLLENBQUM7d0JBQ3BCLEdBQUcsSUFBSSwyQkFBMkIsQ0FBQztvQkFDdkMsQ0FBQztvQkFDRCxFQUFFLENBQUMsQ0FBQyxZQUFZLENBQUMsU0FBUyxJQUFJLENBQUMsQ0FBQyxDQUNoQyxDQUFDO3dCQUNHLEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxTQUFTLElBQUksSUFBSSxJQUFJLFlBQVksQ0FBQyxTQUFTLElBQUksRUFBRSxJQUFJLFlBQVksQ0FBQyxTQUFTLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQzs0QkFDeEcsV0FBVyxHQUFHLEtBQUssQ0FBQzs0QkFDcEIsR0FBRyxJQUFJLDZCQUE2QixDQUFDO3dCQUN6QyxDQUFDO3dCQUNELEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxRQUFRLElBQUksSUFBSSxJQUFJLFlBQVksQ0FBQyxRQUFRLElBQUksRUFBRSxJQUFJLFlBQVksQ0FBQyxRQUFRLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQzs0QkFDckcsV0FBVyxHQUFHLEtBQUssQ0FBQzs0QkFDcEIsR0FBRyxJQUFJLDZCQUE2QixDQUFDO3dCQUN6QyxDQUFDO3dCQUNELEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxJQUFJLElBQUksSUFBSSxJQUFJLFlBQVksQ0FBQyxJQUFJLElBQUksRUFBRSxJQUFJLFlBQVksQ0FBQyxJQUFJLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQzs0QkFDekYsV0FBVyxHQUFHLEtBQUssQ0FBQzs0QkFDcEIsR0FBRyxJQUFJLHVCQUF1QixDQUFDO3dCQUNuQyxDQUFDO29CQUNMLENBQUM7b0JBQ0QsRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLFNBQVMsSUFBSSxDQUFDLENBQUMsQ0FDaEMsQ0FBQzt3QkFDRyxFQUFFLENBQUMsQ0FBQyxZQUFZLENBQUMsY0FBYyxJQUFJLElBQUksSUFBSSxZQUFZLENBQUMsY0FBYyxJQUFJLEVBQUUsSUFBSSxZQUFZLENBQUMsY0FBYyxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUM7NEJBQ3ZILFdBQVcsR0FBRyxLQUFLLENBQUM7NEJBQ3BCLEdBQUcsSUFBSSw2QkFBNkIsQ0FBQzt3QkFDekMsQ0FBQztvQkFDTCxDQUFDO29CQUVELEVBQUUsQ0FBQyxDQUFDLFdBQVcsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDO3dCQUN2QixPQUFPLENBQUMsS0FBSyxDQUFDOzRCQUNWLE9BQU8sRUFBRSxHQUFHOzRCQUNaLFNBQVMsRUFBRSxJQUFJLENBQUMsWUFBWTs0QkFDNUIsT0FBTyxFQUFFO2dDQUNMLEVBQUUsRUFBRTtvQ0FDQSxjQUFjO29DQUNkLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUztpQ0FDNUI7NkJBQ0o7eUJBQ0osQ0FBQyxDQUFDO29CQUNQLENBQUM7b0JBQ0QsTUFBTSxDQUFDLFdBQVcsQ0FBQztnQkFFM0IsQ0FBQztnQkFFRCxtREFBdUIsR0FBdkIsVUFBd0IsWUFBWSxFQUFFLEdBQUcsRUFBQyxLQUFLO29CQUMzQyxXQUFXO29CQUNYLElBQUksV0FBVyxHQUFHLElBQUksQ0FBQztvQkFFdkIsZUFBZTtvQkFDZixFQUFFLENBQUMsQ0FBQyxZQUFZLENBQUMsU0FBUyxJQUFJLElBQUksSUFBSSxZQUFZLENBQUMsU0FBUyxJQUFJLEVBQUUsSUFBSSxZQUFZLENBQUMsU0FBUyxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUM7d0JBQ3hHLFdBQVcsR0FBRyxLQUFLLENBQUM7d0JBQ3BCLEdBQUcsSUFBSSw2QkFBNkIsQ0FBQztvQkFDekMsQ0FBQztvQkFDRCxFQUFFLENBQUMsQ0FBQyxZQUFZLENBQUMsV0FBVyxJQUFJLElBQUksSUFBSSxZQUFZLENBQUMsV0FBVyxJQUFJLEVBQUUsSUFBSSxZQUFZLENBQUMsV0FBVyxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUM7d0JBQzlHLFdBQVcsR0FBRyxLQUFLLENBQUM7d0JBQ3BCLEdBQUcsSUFBSSwrQkFBK0IsQ0FBQztvQkFDM0MsQ0FBQztvQkFDRCxFQUFFLENBQUMsQ0FBQyxZQUFZLENBQUMsS0FBSyxJQUFJLElBQUksSUFBSSxZQUFZLENBQUMsS0FBSyxJQUFJLEVBQUUsSUFBSSxZQUFZLENBQUMsS0FBSyxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUM7d0JBQzVGLFdBQVcsR0FBRyxLQUFLLENBQUM7d0JBQ3BCLEdBQUcsSUFBSSx3QkFBd0IsQ0FBQztvQkFDcEMsQ0FBQztvQkFDRCxFQUFFLENBQUMsQ0FBQyxZQUFZLENBQUMsR0FBRyxJQUFJLElBQUksSUFBSSxZQUFZLENBQUMsR0FBRyxJQUFJLEVBQUUsSUFBSSxZQUFZLENBQUMsR0FBRyxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUM7d0JBQ3RGLFdBQVcsR0FBRyxLQUFLLENBQUM7d0JBQ3BCLEdBQUcsSUFBSSwyQkFBMkIsQ0FBQztvQkFDdkMsQ0FBQztvQkFHRCxFQUFFLENBQUMsQ0FBQyxXQUFXLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQzt3QkFDdkIsT0FBTyxDQUFDLEtBQUssQ0FBQzs0QkFDVixPQUFPLEVBQUUsR0FBRzs0QkFDWixTQUFTLEVBQUUsSUFBSSxDQUFDLFlBQVk7NEJBQzVCLE9BQU8sRUFBRTtnQ0FDTCxFQUFFLEVBQUU7b0NBQ0EsY0FBYztvQ0FDZCxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVM7aUNBQzVCOzZCQUNKO3lCQUNKLENBQUMsQ0FBQztvQkFDUCxDQUFDO29CQUNELE1BQU0sQ0FBQyxXQUFXLENBQUM7Z0JBRXZCLENBQUM7Z0JBR0QsMENBQWMsR0FBZCxVQUFlLFlBQVk7b0JBQ3ZCLHlEQUF5RDtvQkFDekQsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQzFDLElBQUksS0FBSyxHQUFHLEVBQUUsQ0FBQzt3QkFDZixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQ3BCLEtBQUssR0FBRyxNQUFNLENBQUM7d0JBQ25CLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSyxHQUFHLE1BQU0sQ0FBQzt3QkFDbkIsQ0FBQzt3QkFDRCxJQUFJLFFBQVEsR0FBRzs0QkFDWCxNQUFNLEVBQUUsQ0FBQyxFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsV0FBVyxFQUFFLFNBQVMsRUFBRSxHQUFHLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRTs0QkFDcEYsUUFBUSxFQUFFLEVBQUUsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLGNBQWMsRUFBRSxFQUFFLEVBQUUsY0FBYyxFQUFFLEVBQUUsRUFBRSxpQkFBaUIsRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRSxhQUFhLEVBQUUsSUFBSSxDQUFDLFdBQVc7NEJBQ3JJLFdBQVcsRUFBRSxFQUFFLEVBQUUsY0FBYyxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLGNBQWMsRUFBRSxFQUFFLEVBQUUsUUFBUSxFQUFFLEtBQUssRUFBRSxZQUFZLEVBQUUsS0FBSzs0QkFDM0csT0FBTyxFQUFFLE1BQU0sRUFBRSxTQUFTLEVBQUUsT0FBTyxFQUFFLE9BQU8sRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLE9BQU8sRUFBRSxZQUFZLEVBQUUsS0FBSyxFQUFFLFlBQVksRUFBRSxLQUFLLEVBQUUsYUFBYSxFQUFFLEtBQUs7eUJBQzNJLENBQUM7d0JBQ0YsWUFBWSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDO3dCQUMzQyxZQUFZO3dCQUNYLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDNUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO29CQUNyQixDQUFDO2dCQUNMLENBQUM7Z0JBQ0QsNkNBQWlCLEdBQWpCO29CQUNJLElBQUksU0FBUyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO29CQUM5QyxJQUFJLFdBQVcsR0FBRyxJQUFJLENBQUM7b0JBQ3ZCLElBQUksR0FBRyxHQUFHLEVBQUUsQ0FBQztvQkFDZCxZQUFZO29CQUNYLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDeEIsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUMsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDOzRCQUNqRCxXQUFXLEdBQUcsS0FBSyxDQUFDOzRCQUNwQixHQUFHLEdBQUcsK0JBQStCLENBQUM7d0JBQzFDLENBQUM7d0JBQ0QsSUFBSSxVQUFVLEdBQUcsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQzt3QkFDcEQsRUFBRSxDQUFDLENBQUMsVUFBVSxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDOzRCQUN6QixFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUM7Z0NBQ2xELFdBQVcsR0FBRyxLQUFLLENBQUM7Z0NBQ3BCLEdBQUcsR0FBRyw0QkFBNEIsQ0FBQzs0QkFDdkMsQ0FBQzt3QkFDTCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLFdBQVcsR0FBRyxLQUFLLENBQUM7NEJBQ3BCLEdBQUcsR0FBRyxrRkFBa0YsQ0FBQzt3QkFDN0YsQ0FBQztvQkFDTCxDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUNGLFdBQVcsR0FBRyxLQUFLLENBQUM7d0JBQ3BCLEdBQUcsR0FBRyxrRkFBa0YsQ0FBQztvQkFDN0YsQ0FBQztvQkFDRCxFQUFFLENBQUMsQ0FBQyxXQUFXLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQzt3QkFDdkIsT0FBTyxDQUFDLEtBQUssQ0FBQzs0QkFDVixPQUFPLEVBQUUsR0FBRzs0QkFDWixTQUFTLEVBQUUsSUFBSSxDQUFDLFlBQVk7NEJBQzVCLE9BQU8sRUFBRTtnQ0FDTCxFQUFFLEVBQUU7b0NBQ0EsY0FBYztvQ0FDZCxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVM7aUNBQzVCOzZCQUNKO3lCQUNKLENBQUMsQ0FBQztvQkFDUCxDQUFDO29CQUNELE1BQU0sQ0FBQyxXQUFXLENBQUM7Z0JBQ3ZCLENBQUM7Z0JBQ0QsMkNBQWUsR0FBZixVQUFnQixPQUFPO29CQUduQixFQUFFLENBQUMsQ0FBQyxPQUFPLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzt3QkFDaEIsSUFBSSxDQUFDLFNBQVMsR0FBRyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUM7d0JBQzVDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7NEJBQzlDLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxHQUFHLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQzs0QkFDaEQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLEdBQUcsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDOzRCQUN0RCxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsR0FBRyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7NEJBQ2xELElBQUksVUFBVSxHQUFHLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7NEJBQ3BELElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxHQUFHLFVBQVUsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7NEJBQ3BFLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxHQUFHLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQzs0QkFDeEcsSUFBSSxDQUFDLFNBQVMsR0FBRyxFQUFFLENBQUM7NEJBQ3BCLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLFVBQVUsRUFBRSxDQUFDOzRCQUN2QyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7d0JBQ3pCLENBQUM7b0JBQ0wsQ0FBQztnQkFDTCxDQUFDO2dCQUNELHdDQUFZLEdBQVosVUFBYSxPQUFPO29CQUNoQixZQUFZLENBQUMsT0FBTyxDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxDQUFDO29CQUNyRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLFdBQVcsRUFBRSxPQUFPLENBQUMsS0FBSyxFQUFDLEVBQUUsQ0FBQyxDQUFDO29CQUMvRCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7d0JBQzFELElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO3dCQUM1QyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLHFCQUFxQixFQUFFLEtBQUssRUFBRSxFQUFFLENBQUMsQ0FBQztvQkFDdEUsQ0FBQztvQkFDRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLDhCQUE4QixFQUFFLElBQUksQ0FBQyxjQUFjLEVBQUUsRUFBRSxDQUFDLENBQUM7b0JBQ3pGLFFBQVEsQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLE9BQU8sR0FBRyxpQkFBaUIsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBQyxnQkFBZ0IsQ0FBQztnQkFDdkcsQ0FBQztnQkFFRCwwQ0FBYyxHQUFkLFVBQWUsT0FBTztvQkFFbEIsRUFBRSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsU0FBUyxJQUFJLFNBQVMsSUFBSSxPQUFPLENBQUMsU0FBUyxJQUFJLElBQUksSUFBSSxPQUFPLENBQUMsU0FBUyxJQUFJLEVBQUUsQ0FBQzsyQkFDckYsQ0FBQyxPQUFPLENBQUMsV0FBVyxJQUFJLFNBQVMsSUFBSSxPQUFPLENBQUMsV0FBVyxJQUFJLElBQUksSUFBSSxPQUFPLENBQUMsV0FBVyxJQUFJLEVBQUUsQ0FBQzsyQkFDOUYsQ0FBQyxPQUFPLENBQUMsS0FBSyxJQUFJLFNBQVMsSUFBSSxPQUFPLENBQUMsS0FBSyxJQUFJLElBQUksSUFBSSxPQUFPLENBQUMsS0FBSyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDbEYsSUFBSSxDQUFDLFNBQVMsR0FBRyxFQUFFLENBQUM7b0JBRXhCLENBQUM7b0JBQ0QsSUFBSSxDQUFDLENBQUM7d0JBQ0YsSUFBSSxDQUFDLFNBQVMsR0FBRyxPQUFPLENBQUMsU0FBUyxHQUFHLEtBQUssR0FBRyxPQUFPLENBQUMsV0FBVyxHQUFHLEtBQUssR0FBRyxPQUFPLENBQUMsS0FBSyxDQUFDO29CQUM3RixDQUFDO29CQUNELElBQUksQ0FBQyxVQUFVLEdBQUcsT0FBTyxDQUFDO29CQUUxQixNQUFNLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxTQUFTLEVBQUUsQ0FBQztnQkFDMUMsQ0FBQztnQkFDRCwwQ0FBYyxHQUFkO29CQUNJLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO29CQUN2QixZQUFZLENBQUMsT0FBTyxDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxDQUFDO29CQUVyRSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7d0JBQzFELElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO3dCQUM1QyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLHFCQUFxQixFQUFFLEtBQUssRUFBRSxFQUFFLENBQUMsQ0FBQztvQkFDdEUsQ0FBQztvQkFDRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLDhCQUE4QixFQUFFLElBQUksQ0FBQyxjQUFjLEVBQUUsRUFBRSxDQUFDLENBQUM7b0JBQ3pGLFFBQVEsQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLE9BQU8sR0FBRyxrQ0FBa0MsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQztvQkFDbkcsd0pBQXdKO29CQUN4Six5Q0FBeUM7Z0JBRTdDLENBQUM7Z0JBQ0QscUNBQVMsR0FBVDtvQkFFSSxXQUFXO29CQUNYLGlDQUFpQztvQkFDN0IsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDO29CQUNyQyxHQUFHO29CQUNILFFBQVE7b0JBQ1IsK0RBQStEO29CQUMvRCwrSEFBK0g7b0JBRS9ILDhDQUE4QztvQkFDOUMseURBQXlEO29CQUN6RCw0QkFBNEI7b0JBQzVCLEdBQUc7Z0JBQ1AsQ0FBQztnQkFDRCx5Q0FBYSxHQUFiO29CQUNJLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDO2dCQUN6QyxDQUFDO2dCQUNELHNDQUFVLEdBQVYsVUFBVyxLQUFLO29CQUNaLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUM7b0JBQzFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUM7Z0JBQ2pELENBQUM7Z0JBQ0QsK0NBQW1CLEdBQW5CLFVBQW9CLEtBQUs7b0JBQ3RCLFlBQVk7b0JBQ1gsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDO29CQUM5QyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDO2dCQUNqRCxDQUFDO2dCQUNELDZDQUFpQixHQUFqQjtvQkFBQSxpQkF3Q0M7b0JBdkNHLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDO29CQUN4QyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsa0JBQWtCLENBQUMsTUFBTSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDM0QsV0FBVzt3QkFDWCxJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO2dDQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQzVCLE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLFFBQVEsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDOzRCQUN6QixLQUFJLENBQUMsVUFBVSxHQUFHLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQzs0QkFDN0MsSUFBSSxXQUFXLENBQUM7NEJBQ2hCLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLGlCQUFpQixFQUFFO2dDQUNwQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7b0NBQzNCLFdBQVcsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDO2dDQUVqQyxDQUFDOzRCQUNMLENBQUMsQ0FBQyxDQUFDOzRCQUNILEtBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxHQUFHLFdBQVcsQ0FBQzs0QkFDeEMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsUUFBUSxDQUFDLFVBQVUsQ0FBQzs0QkFDakQsS0FBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxHQUFHLFFBQVEsQ0FBQyxVQUFVLENBQUM7NEJBQ3JFLEtBQUksQ0FBQyxNQUFNLEdBQUcsUUFBUSxDQUFDLFVBQVUsQ0FBQzs0QkFDbEMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEdBQUcsUUFBUSxDQUFDLEtBQUssR0FBRyxHQUFHLEdBQUcsUUFBUSxDQUFDLEtBQUssQ0FBQzt3QkFFekUsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztnQkFFUCxDQUFDO2dCQUVELHlDQUFhLEdBQWIsVUFBYyxVQUFVLEVBQUUsT0FBTztvQkFDOUIsWUFBWTtvQkFDWCxVQUFVLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQTtvQkFDNUIsVUFBVSxDQUFDLFNBQVMsR0FBRyxPQUFPLENBQUE7b0JBQzlCLFVBQVUsQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFBO29CQUM1QixVQUFVLENBQUMsUUFBUSxHQUFHLE9BQU8sQ0FBQTtvQkFDN0IsVUFBVSxDQUFDLFlBQVksR0FBRyxLQUFLLENBQUM7b0JBQ2hDLG1CQUFtQjtvQkFDbkIsRUFBRSxDQUFDLENBQUMsT0FBTyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ2YsVUFBVSxDQUFDLFNBQVMsR0FBRyxPQUFPLENBQUM7d0JBQy9CLEVBQUUsQ0FBQyxDQUFDLE9BQU8sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDOzRCQUNmLFVBQVUsQ0FBQyxPQUFPLEdBQUcsTUFBTSxDQUFDO3dCQUVoQyxDQUFDO3dCQUNELElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLElBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQzs0QkFDbEIsVUFBVSxDQUFDLFNBQVMsR0FBRyxNQUFNLENBQUM7NEJBQzlCLG1DQUFtQzs0QkFDbkMsVUFBVSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUM7d0JBQ25DLENBQUM7d0JBQ0QsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sSUFBRSxDQUFDLENBQUMsQ0FDcEIsQ0FBQzs0QkFDRyxVQUFVLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQTt3QkFFL0IsQ0FBQzt3QkFDRCxVQUFVLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQztvQkFFcEMsQ0FBQztvQkFDRCxJQUFJLENBQUEsQ0FBQzt3QkFDRCxVQUFVLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQzt3QkFDekIsVUFBVSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUM7d0JBQy9CLFVBQVUsQ0FBQyxRQUFRLEdBQUcsTUFBTSxDQUFDO29CQUVqQyxDQUFDO29CQUVELEVBQUUsQ0FBQyxDQUFDLE9BQU8sSUFBSSxDQUFDLElBQUksT0FBTyxJQUFJLENBQUMsQ0FBQyxDQUNqQyxDQUFDO3dCQUNHLFVBQVUsQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO3dCQUNoQyxVQUFVLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQzt3QkFDaEMsSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUM7b0JBRWhDLENBQUM7b0JBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUN0QixVQUFVLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQzt3QkFDL0IsVUFBVSxDQUFDLGFBQWEsR0FBRyxLQUFLLENBQUM7b0JBQ3JDLENBQUM7b0JBQ0QsSUFBSSxDQUFDLENBQUM7d0JBQ0YsVUFBVSxDQUFDLGFBQWEsR0FBRyxLQUFLLENBQUM7d0JBQ2pDLFVBQVUsQ0FBQyxZQUFZLEdBQUcsS0FBSyxDQUFDO29CQUNwQyxDQUFDO2dCQUNMLENBQUM7Z0JBRUQsd0NBQVksR0FBWixVQUFhLEtBQUs7b0JBRWQsSUFBSSxDQUFDLHNCQUFzQixDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUN2QyxDQUFDO2dCQUNELGtEQUFzQixHQUF0QixVQUF1QixLQUFLO29CQUE1QixpQkF5QkM7b0JBeEJHLElBQUksQ0FBQyxlQUFlLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQ2xELFdBQVc7d0JBQ1gsSUFBSSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtnQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUM1QixPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsU0FBUyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7d0JBRW5DLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7Z0JBQ1AsQ0FBQztnQkFFRCxnREFBb0IsR0FBcEI7b0JBQUEsaUJBcUNDO29CQXBDRyxJQUFJLENBQUMsZUFBZSxDQUFDLFFBQVEsRUFBRSxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQzFDLFdBQVc7d0JBQ1gsSUFBSSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtnQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUM1QixPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRiw4QkFBOEI7NEJBQzlCLElBQUksZUFBZSxHQUFHLEVBQUUsQ0FBQzs0QkFDM0IsYUFBYTs0QkFDWCxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUU7Z0NBQ3ZCLElBQUksT0FBTyxHQUFHLEVBQUUsQ0FBQztnQ0FDakIsT0FBTyxDQUFDLEVBQUUsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO2dDQUN4QixPQUFPLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUM7Z0NBQ3pCLGVBQWUsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7NEJBQ2xDLENBQUMsQ0FBQyxDQUFDOzRCQUNILEtBQUksQ0FBQyxNQUFNLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzs0QkFDNUIsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQztnQ0FDdEIsTUFBTSxFQUFFLGVBQWU7Z0NBQ3ZCLFFBQVEsRUFBRSxNQUFNOzZCQUNuQixDQUFDLENBQUM7d0JBQ1AsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztnQkFDUCxDQUFDO2dCQUNELDRDQUFnQixHQUFoQjtvQkFFSSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUM7d0JBQy9CLElBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxHQUFHLEVBQUUsQ0FBQzt3QkFDckMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLEdBQUcsQ0FBQyxFQUFFLEtBQUssRUFBRSxHQUFHLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRSxXQUFXLEVBQUUsRUFBRSxFQUFFLEtBQUssRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFLENBQUMsQ0FBQzt3QkFDckgsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUM7b0JBQy9CLENBQUM7b0JBQ0QsSUFBSSxDQUFDLENBQUM7d0JBQ0YsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7NEJBQzlDLElBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDO3dCQUNoQyxDQUFDO29CQUNMLENBQUM7Z0JBQ0wsQ0FBQztnQkFDRCx5Q0FBYSxHQUFiLFVBQWMsT0FBTztvQkFDakIsV0FBVztvQkFFWCxNQUFNLENBQUMsQ0FBQyxPQUFPLENBQUMsU0FBUyxJQUFJLFNBQVMsSUFBSSxPQUFPLENBQUMsU0FBUyxJQUFJLEVBQUUsQ0FBQzsyQkFDM0QsQ0FBQyxPQUFPLENBQUMsV0FBVyxJQUFJLFNBQVMsSUFBSSxPQUFPLENBQUMsV0FBVyxJQUFJLEVBQUUsQ0FBQzsyQkFDL0QsQ0FBQyxPQUFPLENBQUMsS0FBSyxJQUFJLFNBQVMsSUFBSSxPQUFPLENBQUMsS0FBSyxJQUFJLEVBQUUsQ0FBQzsyQkFDbkQsQ0FBQyxPQUFPLENBQUMsR0FBRyxJQUFJLFNBQVMsSUFBSSxPQUFPLENBQUMsR0FBRyxJQUFJLEVBQUUsQ0FBQyxDQUFDO2dCQUUzRCxDQUFDO2dCQUNELHVDQUFXLEdBQVgsVUFBWSxPQUFPO29CQUNoQixZQUFZO29CQUNYLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUc5QixJQUFJLFVBQVUsR0FBRyxFQUFFLEtBQUssRUFBRSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxDQUFDLE1BQU0sR0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFLFdBQVcsRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEtBQUssRUFBRSxHQUFHLEVBQUUsQ0FBQzt3QkFDcEosSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO3dCQUNqRCxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7b0JBR3pCLENBQUM7b0JBQ0QsSUFBSSxDQUFDLENBQUM7d0JBQ0YsSUFBSSxHQUFHLEdBQUcsRUFBRSxDQUFDO3dCQUNiLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxTQUFTLElBQUksU0FBUyxJQUFJLE9BQU8sQ0FBQyxTQUFTLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzs0QkFFNUQsR0FBRyxJQUFJLDJCQUEyQixDQUFFO3dCQUN4QyxDQUFDO3dCQUNELEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxXQUFXLElBQUksU0FBUyxJQUFJLE9BQU8sQ0FBQyxXQUFXLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzs0QkFFaEUsR0FBRyxJQUFJLDZCQUE2QixDQUFDO3dCQUN6QyxDQUFDO3dCQUNELEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLElBQUksU0FBUyxJQUFJLE9BQU8sQ0FBQyxLQUFLLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzs0QkFFcEQsR0FBRyxJQUFJLHNCQUFzQixDQUFDO3dCQUNsQyxDQUFDO3dCQUNELEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLElBQUksU0FBUyxJQUFJLE9BQU8sQ0FBQyxHQUFHLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzs0QkFFaEQsR0FBRyxJQUFJLHlCQUF5QixDQUFDO3dCQUNyQyxDQUFDO3dCQUNELE9BQU8sQ0FBQyxLQUFLLENBQUM7NEJBQ1YsT0FBTyxFQUFFLEdBQUcsRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLFlBQVk7NEJBQzFDLE9BQU8sRUFBRTtnQ0FDTCxFQUFFLEVBQUU7b0NBQ0EsY0FBYztvQ0FDZCxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVM7aUNBQzVCOzZCQUNKO3lCQUNKLENBQUMsQ0FBQztvQkFFUCxDQUFDO2dCQUVMLENBQUM7Z0JBQ0QseUNBQWEsR0FBYixVQUFjLE9BQU87b0JBQ25CLGFBQWE7b0JBQ1gsbURBQW1EO29CQUMvQyxJQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7b0JBQ2QsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsRUFBRTt3QkFDekMsRUFBRSxDQUFDLENBQUMsSUFBSSxJQUFJLE9BQU8sQ0FBQyxDQUFDLENBQUM7NEJBQ2xCLE1BQU0sQ0FBQyxLQUFLLENBQUE7d0JBQ2hCLENBQUM7d0JBQ0QsS0FBSyxHQUFHLEtBQUssR0FBRyxDQUFDLENBQUM7b0JBQ3RCLENBQUMsQ0FBQyxDQUFDO29CQUNILElBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUM7b0JBQ2pELEtBQUssR0FBRyxDQUFDLENBQUM7b0JBQ1YsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsRUFBRTt3QkFDekMsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUMsUUFBUSxFQUFFLENBQUM7d0JBQzlCLEtBQUssR0FBRyxLQUFLLEdBQUcsQ0FBQyxDQUFDO29CQUN0QixDQUFDLENBQUMsQ0FBQztvQkFDSCxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7b0JBQ3JCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUM5QyxJQUFJLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQztvQkFDaEMsQ0FBQztvQkFDTCxHQUFHO2dCQUNQLENBQUM7Z0JBQ0QsaURBQXFCLEdBQXJCLFVBQXNCLE9BQU87b0JBQzNCLGFBQWE7b0JBQ1gsSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO29CQUNkLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLElBQUksU0FBUyxJQUFJLE9BQU8sQ0FBQyxLQUFLLElBQUksSUFBSSxJQUFJLE9BQU8sQ0FBQyxHQUFHLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzt3QkFDM0UsS0FBSyxHQUFHLFVBQVUsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3RDLENBQUM7b0JBQ0QsSUFBSSxHQUFHLEdBQUcsQ0FBQyxDQUFDO29CQUNaLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLElBQUksU0FBUyxJQUFJLE9BQU8sQ0FBQyxHQUFHLElBQUksSUFBSSxJQUFJLE9BQU8sQ0FBQyxHQUFHLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzt3QkFDdkUsR0FBRyxHQUFHLFVBQVUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUM7b0JBQ2xDLENBQUM7b0JBQ0QsT0FBTyxDQUFDLEtBQUssR0FBRyxDQUFDLEtBQUssR0FBRyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBRXpDLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztnQkFDekIsQ0FBQztnQkFFRCx5Q0FBYSxHQUFiO29CQUNJLElBQUksU0FBUyxHQUFHLENBQUMsQ0FBQztvQkFDbEIsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsRUFBRTt3QkFDekMsU0FBUyxHQUFHLFVBQVUsQ0FBQyxTQUFTLENBQUMsUUFBUSxFQUFFLENBQUMsR0FBRSxVQUFVLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN6RSxDQUFDLENBQUMsQ0FBQztvQkFDSCxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUN4RCxDQUFDO2dCQUNELG9DQUFRLEdBQVI7b0JBQUEsaUJBc1hDO29CQXBYRyxxREFBcUQ7b0JBQ3JELE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxVQUFVLEVBQUUsQ0FBQztvQkFDbEMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLFNBQVMsRUFBRSxNQUFNLEVBQUUsQ0FBQyxDQUFDO29CQUNuRCxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztvQkFDdEIsUUFBUSxDQUFDO29CQUVULElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMscUJBQXFCLENBQUMsQ0FBQztvQkFDbkUsRUFBRSxDQUFDLENBQUMsS0FBSyxJQUFJLFNBQVMsSUFBSSxLQUFLLElBQUksU0FBUyxJQUFJLEtBQUssSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO3dCQUMxRCxLQUFLLEdBQUcsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDO3dCQUN6QyxJQUFJLENBQUMsVUFBVSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUM7d0JBQzFDLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQzt3QkFDekQsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7b0JBQzdCLENBQUM7b0JBRUgsaUJBQWlCO29CQUNmLElBQUksQ0FBQyxJQUFJLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDekMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUV6RSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtnQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUM1QixPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsR0FBRyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7d0JBQzdCLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBRUgsSUFBSSxDQUFDLGVBQWUsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQ2xELFdBQVc7d0JBQ1gsSUFBSSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtnQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUM1QixPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsY0FBYyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7d0JBRXhDLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBRUgsSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUM7b0JBQzVCLElBQUksQ0FBQyxlQUFlLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUMvRSxXQUFXO3dCQUNYLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLGFBQWEsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO3dCQUV2QyxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUNILElBQUksQ0FBQyxlQUFlLENBQUMsY0FBYyxFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDaEQsV0FBVzt3QkFDWCxJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO2dDQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQzVCLE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLFdBQVc7NEJBQ1gsS0FBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7NEJBQ3ZELEtBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO3dCQUU1RCxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUNILElBQUksQ0FBQyxlQUFlLENBQUMsVUFBVSxFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDNUMsV0FBVzt3QkFDWCxJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO2dDQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQzVCLE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLFdBQVc7NEJBQ1gsS0FBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7d0JBRXZELENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsSUFBSSxDQUFDLGVBQWUsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUM3QyxXQUFXO3dCQUNYLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsV0FBVzs0QkFDWCxLQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQzs0QkFDcEQsS0FBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7d0JBRXpELENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsSUFBSSxDQUFDLGVBQWUsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUM1QyxXQUFXO3dCQUNYLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLFNBQVMsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO3dCQUVuQyxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUVILElBQUksQ0FBQyxlQUFlLENBQUMsV0FBVyxFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDN0MsV0FBVzt3QkFDWCxJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO2dDQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQzVCLE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEtBQUksQ0FBQyxTQUFTLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzt3QkFFbkMsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFFSCxJQUFJLENBQUMsZUFBZSxDQUFDLFFBQVEsRUFBRSxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQzFDLFdBQVc7d0JBQ1gsSUFBSSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtnQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUM1QixPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsTUFBTSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7d0JBRWhDLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBRUgsSUFBSSxDQUFDLGVBQWUsQ0FBQyxjQUFjLEVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUNoRCxXQUFXO3dCQUNYLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLFlBQVksR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO3dCQUV0QyxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUNILElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUNoQyxJQUFJLENBQUMsZUFBZSxDQUFDLGdCQUFnQixFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDbEQsSUFBSSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtnQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUM1QixPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsV0FBVyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7d0JBRXJDLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsSUFBSSxDQUFDLGVBQWUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDdkYsWUFBWTt3QkFDWCxJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO2dDQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQzVCLE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEtBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDOzRCQUM5RCxLQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQzt3QkFFN0QsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFFSCxJQUFJLENBQUMsZUFBZSxDQUFDLGdCQUFnQixFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDbEQsV0FBVzt3QkFDWCxJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO2dDQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQzVCLE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEtBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDOzRCQUNoRCxLQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsR0FBRyxLQUFJLENBQUMsV0FBVyxDQUFDO3dCQUVuRCxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUNILElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDO29CQUN4QyxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztvQkFDekIsSUFBSSxNQUFNLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDO29CQUM3RSxFQUFFLENBQUMsQ0FBQyxNQUFNLElBQUksU0FBUyxJQUFJLE1BQU0sSUFBSSxTQUFTLElBQUksTUFBTSxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7d0JBQzdELE1BQU0sR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7d0JBQzVDLElBQUksQ0FBQyxjQUFjLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUMxQyxDQUFDO29CQUNELElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLENBQUM7b0JBQ3pELEVBQUUsQ0FBQyxDQUFDLEtBQUssSUFBSSxTQUFTLElBQUksS0FBSyxJQUFJLFNBQVMsSUFBSSxLQUFLLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzt3QkFDMUQsS0FBSyxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQzt3QkFDekMsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO3dCQUNyRSxFQUFFLENBQUMsQ0FBQyxLQUFLLElBQUksU0FBUyxJQUFJLEtBQUssSUFBSSxTQUFTLElBQUksS0FBSyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7NEJBQzFELEtBQUssR0FBRyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7NEJBQ3pDLElBQUksT0FBTyxHQUFHLEVBQUUsQ0FBQzs0QkFDakIsT0FBTyxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUM7NEJBQ2xDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLEVBQUU7Z0NBQ3pDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQztvQ0FDdEIsSUFBSSxDQUFDLFNBQVMsR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDO29DQUNwQyxJQUFJLENBQUMsV0FBVyxHQUFHLE9BQU8sQ0FBQyxXQUFXLENBQUM7b0NBQ3ZDLElBQUksQ0FBQyxLQUFLLEdBQUcsVUFBVSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7b0NBQ2xELElBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLFVBQVUsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7b0NBRXhFLE1BQU0sQ0FBQyxLQUFLLENBQUM7Z0NBQ2pCLENBQUM7NEJBRUwsQ0FBQyxDQUFDLENBQUM7NEJBQ0gsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDOzRCQUNyQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxDQUFDOzRCQUNoRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxDQUFDLHVCQUF1QixDQUFDLENBQUM7d0JBQ2hFLENBQUM7b0JBQ0wsQ0FBQztnQkFDTCxDQUFDO2dCQXI0Q00seUJBQU8sR0FBRyxDQUFDLFFBQVEsRUFBRSxXQUFXLEVBQUUsZUFBZSxDQUFDLENBQUM7Z0JBdkM5RDtvQkFBQyxnQkFBUyxDQUFDO3dCQUNQLFdBQVcsRUFBRSxpREFBaUQ7d0JBQzlELFVBQVUsRUFBRSxDQUFDLGlCQUFRLEVBQUUscUJBQVksRUFBRSx3QkFBZSxFQUFFLDBCQUFRLENBQUM7d0JBQy9ELFNBQVMsRUFBRSxDQUFDLCtCQUFjLEVBQUUsaUNBQWUsRUFBRSxpQ0FBZSxFQUFFLHlDQUFtQixDQUFDO3FCQUNyRixDQUFDOztxQ0FBQTtnQkF5NkNGLHdCQUFDO1lBQUQsQ0F2NkNBLEFBdTZDQyxJQUFBO1lBdjZDRCxpREF1NkNDLENBQUEiLCJmaWxlIjoiYW1heC9SZWNlaXB0L1JlY2VpcHRDcmVhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge0NvbXBvbmVudCwgT3V0cHV0LCBJbnB1dCwgRXZlbnRFbWl0dGVyLCBPbkluaXR9IGZyb20gXCJhbmd1bGFyMi9jb3JlXCI7XHJcbmltcG9ydCB7TmdTd2l0Y2gsIE5nU3dpdGNoV2hlbiwgTmdTd2l0Y2hEZWZhdWx0fSBmcm9tICdhbmd1bGFyMi9jb21tb24nXHJcbmltcG9ydCB7UmVzb3VyY2VTZXJ2aWNlfSBmcm9tIFwiLi4vLi4vc2VydmljZXMvUmVzb3VyY2VTZXJ2aWNlXCI7XHJcbmltcG9ydCB7Um91dGVQYXJhbXN9IGZyb20gXCJhbmd1bGFyMi9yb3V0ZXJcIjtcclxuaW1wb3J0IHtSZWNpZXB0U2VydmljZX0gZnJvbSBcIi4uLy4uL3NlcnZpY2VzL1JlY2llcHRTZXJ2aWNlXCI7XHJcbmltcG9ydCB7Q3VzdG9tZXJTZXJ2aWNlfSBmcm9tIFwiLi4vLi4vc2VydmljZXMvQ3VzdG9tZXJTZXJ2aWNlXCI7XHJcbmltcG9ydCB7IGpzb25RIH0gZnJvbSAnLi4vLi4vanNvblEnO1xyXG5pbXBvcnQge0dyb3VwRmlsdGVyUGlwZSwgR3JvdXBQYXJlbkZpbHRlclBpcGUsIEtlbmRvX3V0aWxpdHl9IGZyb20gXCIuLi8uLi9hbWF4VXRpbFwiO1xyXG5pbXBvcnQgeyBBbWF4RGF0ZSB9IGZyb20gJy4uLy4uL2NvbW9uQ29tcG9uZW50cy9iYXNpY0NvbXBvbmVudHMnO1xyXG5pbXBvcnQge0NoYXJnZUNyZWRpdFNlcnZpY2V9IGZyb20gXCIuLi8uLi9zZXJ2aWNlcy9DaGFyZ2VDcmVkaXRTZXJ2aWNlXCI7XHJcbmRlY2xhcmUgdmFyIGpRdWVyeTtcclxuZGVjbGFyZSB2YXIgbW9tZW50O1xyXG5AQ29tcG9uZW50KHtcclxuICAgIHRlbXBsYXRlVXJsOiAnLi9hcHAvYW1heC9SZWNlaXB0L3RlbXBsYXRlcy9SZWNlaXB0Q3JlYXRlLmh0bWwnLFxyXG4gICAgZGlyZWN0aXZlczogW05nU3dpdGNoLCBOZ1N3aXRjaFdoZW4sIE5nU3dpdGNoRGVmYXVsdCwgQW1heERhdGVdLFxyXG4gICAgcHJvdmlkZXJzOiBbUmVjaWVwdFNlcnZpY2UsIFJlc291cmNlU2VydmljZSwgQ3VzdG9tZXJTZXJ2aWNlLCBDaGFyZ2VDcmVkaXRTZXJ2aWNlXVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEFtYXhSZWNlaXB0Q3JlYXRlIGltcGxlbWVudHMgT25Jbml0IHtcclxuICAgIGJhc2VVcmw6IHN0cmluZztcclxuICAgIFJFUzogT2JqZWN0ID0ge307XHJcbiAgICBGb3JtdHlwZTogc3RyaW5nID0gXCJTQ1JFRU5fUkVDRUlQVENSRUFURVwiO1xyXG4gICAgTGFuZzogc3RyaW5nID0gXCJcIjtcclxuICAgIF9CYW5rcyA9IFtdO1xyXG4gICAgX0N1c3RvbWVyTm90ZXMgPSBbXTtcclxuICAgIF9BZGRyZXNzZXMgPSBbXTtcclxuICAgIF9QYXlUeXBlcyA9IFtdO1xyXG4gICAgX0FjY291bnRzID0gW107XHJcbiAgICBfR29hbHMgPSBbXTtcclxuICAgIF9Qcm9qZWN0Q2F0cyA9IFtdO1xyXG4gICAgX1Byb2plY3RzID0gW107XHJcbiAgICBfQ3VycmVuY2llcyA9IFtdO1xyXG4gICAgUGFzdGVUZXh0OiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgSXNTaG93UHJvZHVjdHM6IGJvb2xlYW4gPSBmYWxzZTtcclxuLy8gICAgbW9kZWxJbnB1dC5SZWNlaXB0TGluZXMgPSBbXTtcclxuICAgIF9UaGFua0xldHRlcnMgPSBbXTtcclxuICAgIFJvd0NvdW50Om51bWJlciA9IDA7XHJcbiAgICBJc2J0bmRpc2FibGU6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBTQVZFX0JUTl9URVhUOiBzdHJpbmc9XCJTYXZlXCI7XHJcbiAgICBNc2dDbGFzczogc3RyaW5nID0gXCJ0ZXh0LXByaW1hcnlcIjtcclxuICAgIG1vZGVsSW5wdXQ6IE9iamVjdCA9IHt9O1xyXG4gICAgc2F2ZUlucHV0OiBPYmplY3QgPSB7fTtcclxuICAgIENoYW5nZURpYWxvZzogc3RyaW5nID0gXCJcIjtcclxuICAgIENIQU5HRURJUjogc3RyaW5nID0gXCJcIjtcclxuICAgIEN1c3RJZDogbnVtYmVyO1xyXG4gICAgU2hvd01vcmVUZXh0OiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgU2hvd01vcmU6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIElzQmFua0RldFNob3c6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIERlZmF1bHREYXRlOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgSVBvcFVwT3BlbjogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgUG9wUHJvZE9iajogT2JqZWN0ID0ge307XHJcbiAgICBzdGF0aWMgJGluamVjdCA9IFsnJHNjb3BlJywgJyRsb2NhdGlvbicsICckYW5jaG9yU2Nyb2xsJ107XHJcbiAgIC8vIEBWaWV3Q2hpbGQoJ1JUTERpdicpIHByaXZhdGUgbXlTY3JvbGxDb250YWluZXI6IEVsZW1lbnRSZWY7XHJcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIF9yZXNvdXJjZVNlcnZpY2U6IFJlc291cmNlU2VydmljZSwgcHJpdmF0ZSBfUmVjaWVwdFNlcnZpY2U6IFJlY2llcHRTZXJ2aWNlLCBwcml2YXRlIF9DdXN0b21lclNlcnZpY2U6IEN1c3RvbWVyU2VydmljZSwgcHJpdmF0ZSBfcm91dGVQYXJhbXM6IFJvdXRlUGFyYW1zLCBwcml2YXRlIF9DaGFyZ2VDcmVkaXRTZXJ2aWNlOiBDaGFyZ2VDcmVkaXRTZXJ2aWNlKSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5SRVMuU0NSRUVOX1JFQ0VJUFRDUkVBVEUgPSB7fTtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQgPSB7fTtcclxuICAgICAgICAvL3RoaXMubW9kZWxJbnB1dC5BZGRNb2RlbCA9IHt9O1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0TGluZXMgPSBbXTtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdFByb2R1Y3RzID0gW107XHJcbiAgICAgICAgLy90aGlzLm1vZGVsSW5wdXQuUmVjZWlwdFByb2R1Y3RzID0gW3sgUm93Tm86IFwiMVwiLCBQcm9kdWN0Tm86IFwiXCIsIFByb2R1Y3ROYW1lOiBcIlwiLCBQcmljZTogXCIwXCIsIFF0eTogXCIxXCIsIFRvdGFsOiBcIjBcIiB9XTtcclxuICAgICAgICB0aGlzLklzU2hvd1Byb2R1Y3RzID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5JUG9wVXBPcGVuID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5Jc0JhbmtEZXRTaG93ID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LlJlY2VpcHRUeXBlSWQgPSBfcm91dGVQYXJhbXMucGFyYW1zLlJlY2VpcHRUeXBlSWQ7XHJcbiAgICAgICAgLy90aGlzLmJhc2VVcmwgPSBcImh0dHA6Ly9sb2NhbGhvc3Q6MzAwMC8jL1wiO1xyXG4gICAgICAgIC8vIGRlYnVnZ2VyO1xyXG4gICAgICAgLy8gYWxlcnQodGhpcy5tb2RlbElucHV0LlJlY2VpcHRUeXBlSWQpO1xyXG4gICAgICAgIHRoaXMuYmFzZVVybCA9IF9yZXNvdXJjZVNlcnZpY2UuQXBwVXJsO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkID0gX3JvdXRlUGFyYW1zLnBhcmFtcy5JZDtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJOYW1lID0gXCJcIjtcclxuICAgICAgICAvL3RoaXMubW9kZWxJbnB1dC5BZGRNb2RlbC5SZWZlcmVuY2VEYXRlID0gXCJcIjtcclxuICAgICAgIC8vIHRoaXMuU2hvd01vcmVUZXh0ID0gXCJNb3JlXCI7XHJcbiAgICAgICAgdGhpcy5EZWZhdWx0RGF0ZSA9IG1vbWVudChuZXcgRGF0ZSgpKS5mb3JtYXQoJ0RELU1NLVlZWVknKTtcclxuICAgICAgICB0aGlzLkxhbmcgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImxhbmdcIik7XHJcbiAgICAgICAgdmFyIE1UZXh0ID0gXCJcIjtcclxuICAgICAgICBpZiAodGhpcy5MYW5nID09IFwiZW5cIikge1xyXG4gICAgICAgICAgICBNVGV4dCA9IFwiTW9yZVwiO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgTVRleHQgPSBcIteZ15XXqteoXCI7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHZhciBEdXBPYmogPSB7XHJcbiAgICAgICAgICAgIEFtb3VudDogMCwgVmFsdWVEYXRlOiB0aGlzLkRlZmF1bHREYXRlLCBQYXlUeXBlSWQ6IDEsIEFjY291bnRJZDogXCJcIiwgQWNjb3VudE5vOiBcIlwiLFxyXG4gICAgICAgICAgICBCcmFuY2hObzogXCJcIiwgQmFuazogXCJcIiwgQ3JlZGl0Q2FyZFR5cGU6IFwiXCIsIERvbmF0aW9uVHlwZUlkOiBcIlwiLCBQcm9qZWN0Q2F0ZWdvcnlJZDogXCJcIiwgUHJvamVjdElkOiBcIlwiLCBSZWZlcmVuY2VEYXRlOiB0aGlzLkRlZmF1bHREYXRlLFxyXG4gICAgICAgICAgICBGb3JfSW52b2ljZTogXCJcIiwgUmVjaWV2ZWRDdXN0SWQ6IFwiXCIsIFBheWVkOiBmYWxzZSwgRGVwb3NpdGVSZW1hcms6IFwiXCIsIFNob3dNb3JlOiBmYWxzZSwgU2hvd01vcmVUZXh0OiBNVGV4dCxcclxuICAgICAgICAgICAgQ2FzaENTUzogXCJncmV5XCIsIENyZWRpdENTUzogXCJ3aGl0ZVwiLCBCYW5rQ1NTOiBcIndoaXRlXCIsIE90aGVyQ1NTOiBcIndoaXRlXCIsIElzU2hvd090aGVyczogZmFsc2UsIElzQ3JlZGl0U2hvdzogZmFsc2UsIElzQmFua0RldFNob3c6IGZhbHNlXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LlJlY2VpcHRMaW5lcy5wdXNoKER1cE9iaik7XHJcbiAgICAgICAgXHJcbiAgICB9XHJcbiAgICBkYXRlVlNlbGVjdGlvbkNoYW5nZShldnQsIGRhdGFvYmopIHtcclxuICAgICAgICBjb25zb2xlLmxvZyhldnQpO1xyXG4gICAgICAgIGRhdGFvYmouVmFsdWVEYXRlID0gZXZ0O1xyXG4gICAgICAgIC8vIGFsZXJ0KHRoaXMubW9kZWxJbnB1dC5CaXJ0aERhdGUpO1xyXG4gICAgICAgIC8vdGhpcy52YWxpZGF0ZUxvZ2luKCk7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIGRhdGVTZWxlY3Rpb25DaGFuZ2UoZXZ0LCBkYXRhb2JqKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coZXZ0KTtcclxuICAgICAgICBkYXRhb2JqLlJlZmVyZW5jZURhdGUgPSBldnQ7XHJcbiAgICAgICAgLy8gYWxlcnQodGhpcy5tb2RlbElucHV0LkJpcnRoRGF0ZSk7XHJcbiAgICAgICAgLy90aGlzLnZhbGlkYXRlTG9naW4oKTtcclxuICAgIH1cclxuXHJcbiAgICBNb3JlKG1vZGVsb2JqKXtcclxuICAgICAgICAvLyBhbGVydChcImNhbGxcIik7XHJcbiAgICAgICAgaWYgKG1vZGVsb2JqLlNob3dNb3JlID09IHRydWUpIHtcclxuICAgICAgICAgICAgbW9kZWxvYmouU2hvd01vcmUgPSBmYWxzZTtcclxuICAgICAgICAgICAgaWYgKHRoaXMuTGFuZyA9PSBcImVuXCIpIHtcclxuICAgICAgICAgICAgICAgIG1vZGVsb2JqLlNob3dNb3JlVGV4dCA9IFwiTW9yZVwiO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgbW9kZWxvYmouU2hvd01vcmVUZXh0ID0gXCLXmdeV16rXqFwiO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8vdGhpcy5TaG93TW9yZVRleHQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0xOS19MQkxfTU9SRTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIG1vZGVsb2JqLlNob3dNb3JlID0gdHJ1ZTtcclxuICAgICAgICAgICAgaWYgKHRoaXMuTGFuZyA9PSBcImVuXCIpIHtcclxuICAgICAgICAgICAgICAgIG1vZGVsb2JqLlNob3dNb3JlVGV4dCA9IFwiTGVzc1wiO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgbW9kZWxvYmouU2hvd01vcmVUZXh0ID0gXCLXpNa81rjXl9eV1rzXqlwiO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8vdGhpcy5TaG93TW9yZVRleHQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0xOS19MQkxfTEVTUztcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBCYW5rRGV0YWlsU2hvdyhQYXlUeXBlSWQsZGF0YW9iaikge1xyXG4gICAgICAgIGlmIChQYXlUeXBlSWQgIT0gMSAmJiBQYXlUeXBlSWQgIT0gMykvLyBOb3QgQ2FzaCBhbmQgbm90IENyZWRpdCBjYXJkXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBkYXRhb2JqLklzQmFua0RldFNob3cgPSB0cnVlO1xyXG4gICAgICAgICAgICBkYXRhb2JqLklzQ3JlZGl0U2hvdyA9IGZhbHNlO1xyXG4gICAgICAgICAgICB0aGlzLkJpbmRBdXRvQ29tcGxldGVCYW5rKCk7XHJcbiAgICAgICAgfSBlbHNlIGlmIChQYXlUeXBlSWQgPT0gMykge1xyXG4gICAgICAgICAgICBkYXRhb2JqLklzQ3JlZGl0U2hvdyA9IHRydWU7XHJcbiAgICAgICAgICAgIGRhdGFvYmouSXNCYW5rRGV0U2hvdyA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHsvLyBPbmx5IEZvciBDYXNoXHJcbiAgICAgICAgICAgIGRhdGFvYmouSXNCYW5rRGV0U2hvdyA9IGZhbHNlO1xyXG4gICAgICAgICAgICBkYXRhb2JqLklzQ3JlZGl0U2hvdyA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIHNldGRlZmF1bHRtb2RlKCkge1xyXG4gICAgICAgIC8vZG9jdW1lbnQubG9jYXRpb24gPSB0aGlzLmJhc2VVcmwgKyBcIlJlY2VpcHRDcmVhdGUvXCIgKyB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCArIFwiIC9cIiArIHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0SWQ7XHJcbiAgICAgICAgdGhpcy5JUG9wVXBPcGVuID0gZmFsc2U7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5Sb3dDb3VudCA9IDA7XHJcbiAgICAgICAgd2luZG93LnNjcm9sbFRvKDAsIDApO1xyXG4gICAgICAgIHZhciBfUmVjZWlwdFR5cGVJZCA9IHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0VHlwZUlkXHJcbiAgICAgICAgdmFyIFByZXZSZWNlaXB0VHlwZSA9IHRoaXMubW9kZWxJbnB1dC5SZWNpZXB0VHlwZTtcclxuXHJcbiAgICAgICAgdmFyIEN1c3RJZCA9IHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkO1xyXG4gICAgICAgIHZhciBDdXN0TmFtZSA9IHRoaXMubW9kZWxJbnB1dC5DdXN0b21lck5hbWU7XHJcbiAgICAgICAgdmFyIGFkZHJlc3NJZCA9IHRoaXMubW9kZWxJbnB1dC5BZGRyZXNzSWQ7XHJcbiAgICAgICAgdmFyIHRobmtMZXR0ZXJJZCA9IHRoaXMubW9kZWxJbnB1dC5UaGFua3NMZXR0ZXJJZDtcclxuICAgICAgICB2YXIgUHJpbnRWYWx1ZURhdGUgPSB0aGlzLm1vZGVsSW5wdXQuVmFsdWVEYXRlO1xyXG4gICAgICAgIHZhciBhc3NvY2lhdGlvbk5hbWUgPSB0aGlzLm1vZGVsSW5wdXQuYXNzb2NpYXRpb25OYW1lO1xyXG4gICAgICAgIHZhciBQcmludGVySWQgPSB0aGlzLm1vZGVsSW5wdXQuUHJpbnRlcklkO1xyXG4gICAgICAgIHZhciBhc3NvY2lhdGlvbmlkID0gdGhpcy5tb2RlbElucHV0LmFzc29jaWF0aW9uSWQ7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0ID0ge307XHJcbiAgICAgICAgdGhpcy5Jc1Nob3dQcm9kdWN0cyA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkID0gQ3VzdElkO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lck5hbWUgPSBDdXN0TmFtZTtcclxuICAgICAgICBcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQWRkcmVzc0lkID0gYWRkcmVzc0lkO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5hc3NvY2lhdGlvbk5hbWUgPSBhc3NvY2lhdGlvbk5hbWU7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LlRoYW5rc0xldHRlcklkID0gdGhua0xldHRlcklkO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5QcmludFZhbHVlRGF0ZSA9IFByaW50VmFsdWVEYXRlO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0VHlwZUlkID0gX1JlY2VpcHRUeXBlSWQ7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LlByaW50ZXJJZCA9IFByaW50ZXJJZDtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuYXNzb2NpYXRpb25JZCA9IGFzc29jaWF0aW9uaWQ7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LlJlY2VpcHRMaW5lcyA9IFtdO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0UHJvZHVjdHMgPSBbXTtcclxuICAgICAgICAvL3RoaXMubW9kZWxJbnB1dC5SZWNlaXB0UHJvZHVjdHMgPSBbeyBSb3dObzogXCIxXCIsIFByb2R1Y3RObzogXCJcIiwgUHJvZHVjdE5hbWU6IFwiXCIsIFByaWNlOiBcIjBcIiwgUXR5OiBcIjFcIiwgVG90YWw6IFwiMFwiIH1dO1xyXG4gICAgICAgIHZhciBEdXBPYmogPSB7XHJcbiAgICAgICAgICAgIEFtb3VudDogMCwgVmFsdWVEYXRlOiB0aGlzLkRlZmF1bHREYXRlLCBQYXlUeXBlSWQ6IDEsIEFjY291bnRJZDogXCJcIiwgQWNjb3VudE5vOiBcIlwiLFxyXG4gICAgICAgICAgICBCcmFuY2hObzogXCJcIiwgQmFuazogXCJcIiwgQ3JlZGl0Q2FyZFR5cGU6IFwiXCIsIERvbmF0aW9uVHlwZUlkOiBcIlwiLCBQcm9qZWN0Q2F0ZWdvcnlJZDogXCJcIiwgUHJvamVjdElkOiBcIlwiLCBSZWZlcmVuY2VEYXRlOiB0aGlzLkRlZmF1bHREYXRlLFxyXG4gICAgICAgICAgICBGb3JfSW52b2ljZTogXCJcIiwgUmVjaWV2ZWRDdXN0SWQ6IEN1c3RJZCwgUGF5ZWQ6IGZhbHNlLCBEZXBvc2l0ZVJlbWFyazogXCJcIiwgU2hvd01vcmU6IGZhbHNlLCBTaG93TW9yZVRleHQ6IFwiTW9yZVwiLFxyXG4gICAgICAgICAgICBDYXNoQ1NTOiBcImdyZXlcIiwgQ3JlZGl0Q1NTOiBcIndoaXRlXCIsIEJhbmtDU1M6IFwid2hpdGVcIiwgT3RoZXJDU1M6IFwid2hpdGVcIiwgSXNTaG93T3RoZXJzOiBmYWxzZSwgSXNDcmVkaXRTaG93OiBmYWxzZSwgSXNCYW5rRGV0U2hvdzogZmFsc2VcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdExpbmVzLnB1c2goRHVwT2JqKTtcclxuICAgICAgICAvL3RoaXMuR2V0Q3VzdG9tZXJEZXRhaWwoQ3VzdElkKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgIC8vdGhpcy5tb2RlbElucHV0LlJlY2llcHRUeXBlID0gUHJldlJlY2VpcHRUeXBlO1xyXG4gICAgICAgIHRoaXMuX1JlY2llcHRTZXJ2aWNlLkdldFJlY2llcHRUeXBlKHRoaXMuX3JvdXRlUGFyYW1zLnBhcmFtcy5SZWNlaXB0VHlwZUlkKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAgICAgIHZhciByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcCk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5SZWNpZXB0VHlwZSA9IHJlc3BvbnNlLkRhdGFbMF0uUmVjaWVwdE5hbWVFbmc7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VycmVuY3lJZCA9IHJlc3BvbnNlLkRhdGFbMF0uQ3VycmVuY3lJZDtcclxuXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgLy8gdGhpcy5Jc0JhbmtEZXRTaG93ID0gZmFsc2U7XHJcblxyXG4gICAgICAgIHRoaXMuX1JlY2llcHRTZXJ2aWNlLkdldEVtcGxveWVlKCkuc3Vic2NyaWJlKHJlc3A9PiB7XHJcbiAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgIHZhciByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcCk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuRW1wbG95ZWVJZCA9IHJlc3BvbnNlLkRhdGFbMF0uVmFsdWU7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuRW1wbG95ZWVOYW1lID0gcmVzcG9uc2UuRGF0YVswXS5UZXh0O1xyXG5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgdGhpcy5fUmVjaWVwdFNlcnZpY2UuR2V0UmVjZWlwdERldGFpbCgpLnN1YnNjcmliZShyZXNwPT4ge1xyXG4gICAgICAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LlJlY2llcHRObyA9IHJlc3BvbnNlLkRhdGEuVmFsdWU7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuUmVjaWVwdERhdGUgPSByZXNwb25zZS5EYXRhLlRleHQ7XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG4gICAgc2F2ZVJlY2VpcHREYXRhKElzRXhpdCkge1xyXG4gICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAgLy9pZiAodGhpcy5JUG9wVXBPcGVuID09IGZhbHNlKVxyXG4gICAgICAgIC8ve1xyXG4gICAgICAgIHZhciBFbXBOYW1lID0galF1ZXJ5KFwiI0VtcElkXCIpLnZhbCgpO1xyXG4gICAgICAgIHRoaXMuX1JlY2llcHRTZXJ2aWNlLkdldEVtcGxveWVlRnJvbUVtcE5hbWUoRW1wTmFtZSkuc3Vic2NyaWJlKHJlc3A9PiB7XHJcbiAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgIHZhciByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcCk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5FbXBsb3llZUlkID0gcmVzcG9uc2UuRGF0YTtcclxuXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCAhPSBudWxsICYmIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkICE9IFwiXCIgJiYgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQgIT0gdW5kZWZpbmVkXHJcbiAgICAgICAgICAgICYmIHRoaXMubW9kZWxJbnB1dC5DdXJyZW5jeUlkICE9IG51bGwgJiYgdGhpcy5tb2RlbElucHV0LkN1cnJlbmN5SWQgIT0gXCJcIiAmJiB0aGlzLm1vZGVsSW5wdXQuQ3VycmVuY3lJZCAhPSB1bmRlZmluZWRcclxuICAgICAgICAgICAgJiYgdGhpcy5tb2RlbElucHV0LlJlY2VpcHRMaW5lcy5sZW5ndGggPiAwXHJcbiAgICAgICAgICAgICYmIHRoaXMubW9kZWxJbnB1dC5hc3NvY2lhdGlvbklkICE9IG51bGwgJiYgdGhpcy5tb2RlbElucHV0LmFzc29jaWF0aW9uSWQgIT0gXCJcIiAmJiB0aGlzLm1vZGVsSW5wdXQuYXNzb2NpYXRpb25JZCAhPSB1bmRlZmluZWRcclxuICAgICAgICAgICAgJiYgdGhpcy5tb2RlbElucHV0LkVtcGxveWVlSWQgIT0gbnVsbCAmJiB0aGlzLm1vZGVsSW5wdXQuRW1wbG95ZWVJZCAhPSBcIi0xXCIgJiYgdGhpcy5tb2RlbElucHV0LkVtcGxveWVlSWQgIT0gdW5kZWZpbmVkXHJcbiAgICAgICAgICAgICYmIHRoaXMubW9kZWxJbnB1dC5UaGFua3NMZXR0ZXJJZCAhPSBudWxsICYmIHRoaXMubW9kZWxJbnB1dC5UaGFua3NMZXR0ZXJJZCAhPSBcIlwiICYmIHRoaXMubW9kZWxJbnB1dC5UaGFua3NMZXR0ZXJJZCAhPSB1bmRlZmluZWRcclxuICAgICAgICAgICAgJiYgdGhpcy5tb2RlbElucHV0LlByaW50ZXJJZCAhPSBudWxsICYmIHRoaXMubW9kZWxJbnB1dC5QcmludGVySWQgIT0gXCJcIiAmJiB0aGlzLm1vZGVsSW5wdXQuUHJpbnRlcklkICE9IHVuZGVmaW5lZFxyXG4gICAgICAgICAgICAmJiB0aGlzLm1vZGVsSW5wdXQuUmVjaWVwdE5vICE9IG51bGwgJiYgdGhpcy5tb2RlbElucHV0LlJlY2llcHRObyAhPSBcIlwiICYmIHRoaXMubW9kZWxJbnB1dC5SZWNpZXB0Tm8gIT0gdW5kZWZpbmVkXHJcbiAgICAgICAgKSB7XHJcblxyXG4gICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuUmVjaWVwdFR5cGUgPSB0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdFR5cGVJZDtcclxuICAgICAgICAgICAgdmFyIExpbmVDb3VudCA9IHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0TGluZXMubGVuZ3RoO1xyXG4gICAgICAgICAgICB2YXIgQ2hlY2tSb3dWYWxpZCA9IHRydWU7XHJcbiAgICAgICAgICAgIGlmIChMaW5lQ291bnQgPCAxKSB7XHJcbiAgICAgICAgICAgICAgICBDaGVja1Jvd1ZhbGlkID0gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgLy9hbGVydChKU09OLnN0cmluZ2lmeSh0aGlzLm1vZGVsSW5wdXQpKTtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIGZvciAodmFyIGNudCBpbiB0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdExpbmVzKSAvLyBmb3IgYWN0cyBhcyBhIGZvcmVhY2hcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgdmFyIEVycm9yTWVzc2FnZSA9IFwiUm93IE51bWJlciAtIFwiICsgKHBhcnNlSW50KGNudCkgKyAxKS50b1N0cmluZygpICsgXCIgaXMgbm90IHZhbGlkIGluIFJlY2VpcHQgTGluZXMgPGJyPlwiO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuVmFsaWRhdGVSb3dNb2RlbCh0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdExpbmVzW2NudF0sIEVycm9yTWVzc2FnZSkgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgICAgICBDaGVja1Jvd1ZhbGlkID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGZvciAodmFyIGNudCBpbiB0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdFByb2R1Y3RzKSAvLyBmb3IgYWN0cyBhcyBhIGZvcmVhY2hcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgdmFyIEVycm9yTWVzc2FnZSA9IFwiUm93IE51bWJlciAtIFwiICsgKHBhcnNlSW50KGNudCkgKyAxKS50b1N0cmluZygpICsgXCIgaXMgbm90IHZhbGlkIGluIFByb2R1Y3RzIDxicj5cIjtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLlZhbGlkYXRlUHJvZHVjdFJvd01vZGVsKHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0UHJvZHVjdHNbY250XSwgRXJyb3JNZXNzYWdlLGNudCkgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgICAgICBDaGVja1Jvd1ZhbGlkID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuXHJcblxyXG4gICAgICAgICAgICBpZiAoQ2hlY2tSb3dWYWxpZCA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgdmFyIGpkYXRhID0gSlNPTi5zdHJpbmdpZnkodGhpcy5tb2RlbElucHV0KTtcclxuICAgICAgICAgICAgICAgIC8vY29uc29sZS5sb2coamRhdGEpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fUmVjaWVwdFNlcnZpY2UuQWRkUmVjZWlwdChqZGF0YSkuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuSXNidG5kaXNhYmxlID0gXCJcIjtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBhbGVydChyZXNwb25zZS5FcnJNc2cpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLk1zZ0NsYXNzID0gXCJ0ZXh0LWRhbmdlclwiO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZGVsZXRlQ29va2llKFwiUmVjZWlwdENyZWF0ZV9DYWNoZVwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChJc0V4aXQgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZG9jdW1lbnQubG9jYXRpb24gPSB0aGlzLmJhc2VVcmwgKyBcIlJlY2VpcHRTZWxlY3QvXCIgKyB0aGlzLm1vZGVsSW5wdXQuRW1wbG95ZWVJZCArIFwiIC9cIiArIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zZXRkZWZhdWx0bW9kZSgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LlByaW50UmVjaWVwdE5vID0gcmVzcG9uc2UuRGF0YS5SZWNpZXB0Tm87XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLkN1c3RJZCA9IHJlc3BvbnNlLkN1c3RvbWVySWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICBlcnJvcj0+IGNvbnNvbGUubG9nKGVycm9yKSxcclxuICAgICAgICAgICAgICAgICAgICAoKSA9PiBjb25zb2xlLmxvZyhcIlNhdmUgQ2FsbCBDb21wbGVhdGVkXCIpXHJcbiAgICAgICAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHZhciBtc2cgPSBcIlwiO1xyXG4gICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQgPT0gbnVsbCB8fCB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCA9PSBcIlwiIHx8IHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkID09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgbXNnICs9IFwiPGJyPlBsZWFzZSBlbnRlciBjdXN0b21lcmlkXCI7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5DdXJyZW5jeUlkID09IG51bGwgfHwgdGhpcy5tb2RlbElucHV0LkN1cnJlbmN5SWQgPT0gXCJcIiB8fCB0aGlzLm1vZGVsSW5wdXQuQ3VycmVuY3lJZCA9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgIG1zZyArPSBcIjxicj5QbGVhc2Ugc2VsZWN0IGN1cnJlbmN5XCI7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5hc3NvY2lhdGlvbklkID09IG51bGwgfHwgdGhpcy5tb2RlbElucHV0LmFzc29jaWF0aW9uSWQgPT0gXCJcIiB8fCB0aGlzLm1vZGVsSW5wdXQuYXNzb2NpYXRpb25JZCA9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgIG1zZyArPSBcIjxicj5QbGVhc2UgZW50ZXIgRGVwb3NpdGVkIEJ5XCI7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5FbXBsb3llZUlkID09IG51bGwgfHwgdGhpcy5tb2RlbElucHV0LkVtcGxveWVlSWQgPT0gXCJcIiB8fCB0aGlzLm1vZGVsSW5wdXQuRW1wbG95ZWVJZCA9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgIG1zZyArPSBcIjxicj5QbGVhc2UgZW50ZXIgdmFsaWQgZW1wbG95ZWVcIjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LlRoYW5rc0xldHRlcklkID09IG51bGwgfHwgdGhpcy5tb2RlbElucHV0LlRoYW5rc0xldHRlcklkID09IFwiXCIgfHwgdGhpcy5tb2RlbElucHV0LlRoYW5rc0xldHRlcklkID09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgbXNnICs9IHRoaXMubW9kZWxJbnB1dC5UaGFua3NMZXR0ZXJJZDtcclxuICAgICAgICAgICAgICAgIG1zZyArPSBcIjxicj5QbGVhc2Ugc2VsZWN0IHByaW50IHRlbXBsYXRlXCI7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5QcmludGVySWQgPT0gbnVsbCB8fCB0aGlzLm1vZGVsSW5wdXQuUHJpbnRlcklkID09IFwiXCIgfHwgdGhpcy5tb2RlbElucHV0LlByaW50ZXJJZCA9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgIG1zZyArPSBcIjxicj5QbGVhc2Ugc2V0IHByaW50ZXIgbmFtZSBpbiBkYXRhYmFzZVwiO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuUmVjaWVwdE5vID09IG51bGwgfHwgdGhpcy5tb2RlbElucHV0LlJlY2llcHRObyA9PSBcIlwiIHx8IHRoaXMubW9kZWxJbnB1dC5SZWNpZXB0Tm8gPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgICAgICBtc2cgKz0gXCI8YnI+UmVjZWlwdCBubyBpcyBub3Qgc2V0XCI7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0TGluZXMubGVuZ3RoID09IDApIHtcclxuICAgICAgICAgICAgICAgIG1zZyArPSBcIjxicj5QbGVhc2UgYXRsZWFzdCBvbmUgYW1vdW50IGRldGFpbCBpbiBncmlkXCI7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICBtZXNzYWdlOiBtc2csXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgIC8vfVxyXG4gICAgfVxyXG5cclxuICAgIGRlbE1vZGVsKE1vZGVsT2JqKTogb2JzZXJ2YWJsZSB7XHJcbiAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LlJlY2VpcHRMaW5lcy5sZW5ndGggPiAxKSB7XHJcbiAgICAgICAgICAgIHZhciBpbmRleCA9IDA7XHJcbiAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0TGluZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzID09IE1vZGVsT2JqKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBpbmRleCA9IGluZGV4ICsgMTtcclxuXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdExpbmVzLnNwbGljZShpbmRleCwgMSk7XHJcbiAgICAgICAgICAgIHRoaXMuQmluZFRvdGFsKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgQmluZFRvdGFsKCkge1xyXG4gICAgICAgIHZhciB0dG90YWwgPSAwO1xyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5tb2RlbElucHV0LlJlY2VpcHRMaW5lcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICB0dG90YWwgKz0gcGFyc2VGbG9hdCh0aGlzLkFtb3VudCk7XHJcblxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5Ub3RhbCA9IHR0b3RhbDtcclxuXHJcbiAgICAgICAgdmFyIHZEYXRlID0gdGhpcy5tb2RlbElucHV0LlZhbHVlRGF0ZTtcclxuICAgICAgICBjb25zb2xlLmxvZyh2RGF0ZSk7XHJcbiAgICAgICAgaWYgKHZEYXRlID09IG51bGwgfHwgdkRhdGUgPT0gXCJcIikgdkRhdGUgPSB0aGlzLkRlZmF1bHREYXRlO1xyXG4gICAgICAgIHZhciBjdXJJRCA9IHRoaXMubW9kZWxJbnB1dC5DdXJyZW5jeUlkO1xyXG4gICAgICAgIC8vYWxlcnQoY3VySUQpO1xyXG4gICAgICAgIHRoaXMuX1JlY2llcHRTZXJ2aWNlLkdldExlYWRjdXJyZW5jeShjdXJJRCwgXCJOSVNcIiwgdkRhdGUpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuXHJcbiAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuXHJcbiAgICAgICAgICAgICAgICAvL3ZhciBuID0gbnVtLnRvRml4ZWQoMik7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuVG90YWxJbkxlYWRDdXJyZW50ID0gcGFyc2VGbG9hdChyZXNwb25zZS5EYXRhKSAqIHR0b3RhbDtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5Ub3RhbEluTGVhZEN1cnJlbnQgPSB0aGlzLm1vZGVsSW5wdXQuVG90YWxJbkxlYWRDdXJyZW50LnRvRml4ZWQoMik7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgXHJcbiAgICB9XHJcbiAgICBjcmVhdGVSZWNlaXB0UERGKCkge1xyXG4gICAgICAgIFxyXG4gICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuUHJpbnRSZWNpZXB0Tm8gIT0gbnVsbCkge1xyXG4gICAgICAgICAgICB2YXIgUmVjaXB0X05vID0gdGhpcy5tb2RlbElucHV0LlByaW50UmVjaWVwdE5vO1xyXG4gICAgICAgICAgICB2YXIgUmVjaWVwdF9UeXBlID0gdGhpcy5tb2RlbElucHV0LlJlY2VpcHRUeXBlSWQ7XHJcbiAgICAgICAgICAgIHZhciBDdXN0b21lcl9JZCA9IHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkO1xyXG4gICAgICAgICAgICB2YXIgVGhhbmtzTGV0dGVyX0lkID0gdGhpcy5tb2RlbElucHV0LlRoYW5rc0xldHRlcklkO1xyXG4gICAgICAgICAgICB2YXIgTGVhZEN1cnJlbmN5SWQgPSB0aGlzLm1vZGVsSW5wdXQuQ3VycmVuY3lJZDtcclxuICAgICAgICAgICAgdGhpcy5fUmVjaWVwdFNlcnZpY2UuQ3JlYXRlUmVjZWlwdFBkZihDdXN0b21lcl9JZCwgVGhhbmtzTGV0dGVyX0lkLCBSZWNpcHRfTm8sIFJlY2llcHRfVHlwZSwgTGVhZEN1cnJlbmN5SWQpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgbCA9IHJlc3BvbnNlLkRhdGEudG9TdHJpbmcoKS5zdWJzdHJpbmcoMCwgNSk7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLkRhdGEudG9TdHJpbmcoKS5zdWJzdHJpbmcoMCwgNSkgPT0gXCJMaW5rOlwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBQcmludERhdGEgPSByZXNwb25zZS5EYXRhLnRvU3RyaW5nKCkuc3Vic3RyaW5nKDUsIHJlc3BvbnNlLkRhdGEudG9TdHJpbmcoKS5sZW5ndGgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgd2luZG93T2JqZWN0ID0gd2luZG93Lm9wZW4oUHJpbnREYXRhLCAnUHJpbnQnLCAnc2Nyb2xsYmFycz15ZXMscmVzaXphYmxlPXllcyx3aWR0aD0xMDUwLGhlaWdodD02NTAnKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy93aW5kb3dPYmplY3QuZG9jdW1lbnQud3JpdGUoUHJpbnREYXRhKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy93aW5kb3dPYmplY3QuZG9jdW1lbnQuY2xvc2UoKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgRHVwTW9kZWwoTW9kZWxPYmopIHtcclxuICAgICAgICB2YXIgTU9iaiA9IHt9O1xyXG4gICAgICAgIHRoaXMuUm93Q291bnQrKztcclxuICAgICAgICBNb2RlbE9iai5SZWNpZXB0Um9XSUQgPSB0aGlzLlJvd0NvdW50O1xyXG4gICAgICAgIE1PYmogPSBNb2RlbE9iajtcclxuICAgICAgICBcclxuICAgICAgICB2YXIgVmRhdGUgPSBNT2JqLlZhbHVlRGF0ZS5zcGxpdCgnLScpO1xyXG4gICAgICAgIHZhciBOZXdWRGF0ZSA9IG5ldyBEYXRlKHBhcnNlSW50KCBWZGF0ZVsyXSkscGFyc2VJbnQoVmRhdGVbMV0pLHBhcnNlSW50KFZkYXRlWzBdKSk7XHJcbiAgICAgICAgTmV3VkRhdGUuc2V0TW9udGgoTmV3VkRhdGUuZ2V0TW9udGgoKSk7XHJcbiAgICAgICAgdmFyIE5WRGF0ZSA9IG1vbWVudChOZXdWRGF0ZSkuZm9ybWF0KCdERC1NTS1ZWVlZJyk7XHJcbiAgICAgICAgLy92YXIgTW9udGggPSBwYXJzZUludChWZGF0ZVsxXSkgKyAxO1xyXG4gICAgICAgIC8vTU9iai5WYWx1ZURhdGUgPSBOZXdWRGF0ZTtcclxuICAgICAgICB2YXIgRHVwT2JqID0geyBBbW91bnQ6IE1vZGVsT2JqLkFtb3VudCwgVmFsdWVEYXRlOiBOZXdWRGF0ZSwgUGF5VHlwZUlkOiBNb2RlbE9iai5QYXlUeXBlSWQsIEFjY291bnRJZDogTW9kZWxPYmouQWNjb3VudElkLCBBY2NvdW50Tm86IE1vZGVsT2JqLkFjY291bnRObywgQnJhbmNoTm86IE1vZGVsT2JqLkJyYW5jaE5vLCBCYW5rOiBNb2RlbE9iai5CYW5rLCBDcmVkaXRDYXJkVHlwZTogTW9kZWxPYmouQ3JlZGl0Q2FyZFR5cGUsIERvbmF0aW9uVHlwZUlkOiBNb2RlbE9iai5Eb25hdGlvblR5cGVJZCwgUHJvamVjdENhdGVnb3J5SWQ6IE1vZGVsT2JqLlByb2plY3RDYXRlZ29yeUlkLCBQcm9qZWN0SWQ6IE1vZGVsT2JqLlByb2plY3RJZCwgUmVmZXJlbmNlRGF0ZTogTW9kZWxPYmouUmVmZXJlbmNlRGF0ZSwgRm9yX0ludm9pY2U6IE1vZGVsT2JqLkZvcl9JbnZvaWNlLCBSZWNpZXZlZEN1c3RJZDogTW9kZWxPYmouUmVjaWV2ZWRDdXN0SWQsIFBheWVkOiBNb2RlbE9iai5QYXllZCwgRGVwb3NpdGVSZW1hcms6IE1vZGVsT2JqLkRlcG9zaXRlUmVtYXJrICB9O1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0TGluZXMucHVzaChEdXBPYmopO1xyXG4gICAgICAgIHZhciBpbmRleCA9IDA7XHJcbiAgICAgICAgdmFyIFRvdGFsUm93cz10aGlzLm1vZGVsSW5wdXQuUmVjZWlwdExpbmVzLmxlbmd0aDtcclxuICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdExpbmVzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIGlmIChpbmRleCA9PSAoVG90YWxSb3dzIC0gMSkpIHtcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgdGhpcy5WYWx1ZURhdGUgPSBOVkRhdGU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGluZGV4Kys7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgdGhpcy5CaW5kVG90YWwoKTtcclxuICAgIH1cclxuXHJcbiAgICBWYWxpZGF0ZVJvd01vZGVsKEN1cnJlbnRNb2RlbCwgbXNnKSB7XHJcbiAgICAgICAgLy9tc2cgPSBcIlwiO1xyXG4gICAgICAgIHZhciBJc1ZhbGlkRGF0YSA9IHRydWU7XHJcbiAgICAgICAgaWYgKEN1cnJlbnRNb2RlbC5WYWx1ZURhdGUgIT0gXCJcIikge1xyXG4gICAgICAgICAgICBpZiAobW9tZW50KEN1cnJlbnRNb2RlbC5WYWx1ZURhdGUsIFwiREQtTU0tWVlZWVwiLCB0cnVlKS5pc1ZhbGlkKCkgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoeyBtZXNzYWdlOiBcIlZhbHVlIERhdGUgaXMgbm90IHZhbGlkXCIgfSk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKEN1cnJlbnRNb2RlbC5SZWZlcmVuY2VEYXRlICE9IFwiXCIpIHtcclxuICAgICAgICAgICAgaWYgKG1vbWVudChDdXJyZW50TW9kZWwuUmVmZXJlbmNlRGF0ZSwgXCJERC1NTS1ZWVlZXCIsIHRydWUpLmlzVmFsaWQoKSA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7IG1lc3NhZ2U6IFwiUmVmZXJlbmNlIERhdGUgaXMgbm90IHZhbGlkXCIgfSk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICAgICAgICAgIC8vdmFyIG1zZyA9IFwiXCI7XHJcbiAgICAgICAgICAgIGlmIChDdXJyZW50TW9kZWwuQW1vdW50ID09IG51bGwgfHwgQ3VycmVudE1vZGVsLkFtb3VudCA9PSBcIlwiIHx8IEN1cnJlbnRNb2RlbC5BbW91bnQgPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgICAgICBJc1ZhbGlkRGF0YSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgbXNnICs9IFwiPGJyPlBsZWFzZSBlbnRlciBhbW91bnRcIjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoQ3VycmVudE1vZGVsLlBheVR5cGVJZCA9PSBudWxsIHx8IEN1cnJlbnRNb2RlbC5QYXlUeXBlSWQgPT0gXCJcIiB8fCBDdXJyZW50TW9kZWwuUGF5VHlwZUlkID09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgSXNWYWxpZERhdGEgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIG1zZyArPSBcIjxicj5QbGVhc2Ugc2VsZWN0IHBheXR5cGVcIjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoQ3VycmVudE1vZGVsLlByb2plY3RJZCA9PSBudWxsIHx8IEN1cnJlbnRNb2RlbC5Qcm9qZWN0SWQgPT0gXCJcIiB8fCBDdXJyZW50TW9kZWwuUHJvamVjdElkID09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgSXNWYWxpZERhdGEgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIG1zZyArPSBcIjxicj5QbGVhc2Ugc2VsZWN0IHByb2plY3RcIjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoQ3VycmVudE1vZGVsLkRvbmF0aW9uVHlwZUlkID09IG51bGwgfHwgQ3VycmVudE1vZGVsLkRvbmF0aW9uVHlwZUlkID09IFwiXCIgfHwgQ3VycmVudE1vZGVsLkRvbmF0aW9uVHlwZUlkID09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgSXNWYWxpZERhdGEgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIG1zZyArPSBcIjxicj5QbGVhc2Ugc2VsZWN0IGdvYWxcIjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoQ3VycmVudE1vZGVsLkFjY291bnRJZCA9PSBudWxsIHx8IEN1cnJlbnRNb2RlbC5BY2NvdW50SWQgPT0gXCJcIiB8fCBDdXJyZW50TW9kZWwuQWNjb3VudElkID09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgSXNWYWxpZERhdGEgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIG1zZyArPSBcIjxicj5QbGVhc2Ugc2VsZWN0IGFjY291bnRcIjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoQ3VycmVudE1vZGVsLlBheVR5cGVJZCA9PSA4KSAvL0JhbmtcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgaWYgKEN1cnJlbnRNb2RlbC5BY2NvdW50Tm8gPT0gbnVsbCB8fCBDdXJyZW50TW9kZWwuQWNjb3VudE5vID09IFwiXCIgfHwgQ3VycmVudE1vZGVsLkFjY291bnRObyA9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgICAgICBJc1ZhbGlkRGF0YSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIG1zZyArPSBcIjxicj5QbGVhc2UgZW50ZXIgYWNjb3VudCBub1wiO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgaWYgKEN1cnJlbnRNb2RlbC5CcmFuY2hObyA9PSBudWxsIHx8IEN1cnJlbnRNb2RlbC5CcmFuY2hObyA9PSBcIlwiIHx8IEN1cnJlbnRNb2RlbC5CcmFuY2hObyA9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgICAgICBJc1ZhbGlkRGF0YSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIG1zZyArPSBcIjxicj5QbGVhc2Ugc2VsZWN0IGJyYW5jaCBub1wiO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgaWYgKEN1cnJlbnRNb2RlbC5CYW5rID09IG51bGwgfHwgQ3VycmVudE1vZGVsLkJhbmsgPT0gXCJcIiB8fCBDdXJyZW50TW9kZWwuQmFuayA9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgICAgICBJc1ZhbGlkRGF0YSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIG1zZyArPSBcIjxicj5QbGVhc2UgZW50ZXIgYmFua1wiO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChDdXJyZW50TW9kZWwuUGF5VHlwZUlkID09IDMpIC8vQ3JlZGl0XHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIGlmIChDdXJyZW50TW9kZWwuQ3JlZGl0Q2FyZFR5cGUgPT0gbnVsbCB8fCBDdXJyZW50TW9kZWwuQ3JlZGl0Q2FyZFR5cGUgPT0gXCJcIiB8fCBDdXJyZW50TW9kZWwuQ3JlZGl0Q2FyZFR5cGUgPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgSXNWYWxpZERhdGEgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICBtc2cgKz0gXCI8YnI+UGxlYXNlIGVudGVyIENyZWRpdENhcmRcIjtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgaWYgKElzVmFsaWREYXRhID09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBtc2csXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIElzVmFsaWREYXRhO1xyXG4gICAgICAgIFxyXG4gICAgfVxyXG5cclxuICAgIFZhbGlkYXRlUHJvZHVjdFJvd01vZGVsKEN1cnJlbnRNb2RlbCwgbXNnLHJvd25vKSB7XHJcbiAgICAgICAgLy9tc2cgPSBcIlwiO1xyXG4gICAgICAgIHZhciBJc1ZhbGlkRGF0YSA9IHRydWU7XHJcbiAgICAgICAgXHJcbiAgICAgICAgLy92YXIgbXNnID0gXCJcIjtcclxuICAgICAgICBpZiAoQ3VycmVudE1vZGVsLlByb2R1Y3RObyA9PSBudWxsIHx8IEN1cnJlbnRNb2RlbC5Qcm9kdWN0Tm8gPT0gXCJcIiB8fCBDdXJyZW50TW9kZWwuUHJvZHVjdE5vID09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICBJc1ZhbGlkRGF0YSA9IGZhbHNlO1xyXG4gICAgICAgICAgICBtc2cgKz0gXCI8YnI+UGxlYXNlIGVudGVyIHByb2R1Y3Qgbm9cIjtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKEN1cnJlbnRNb2RlbC5Qcm9kdWN0TmFtZSA9PSBudWxsIHx8IEN1cnJlbnRNb2RlbC5Qcm9kdWN0TmFtZSA9PSBcIlwiIHx8IEN1cnJlbnRNb2RlbC5Qcm9kdWN0TmFtZSA9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgSXNWYWxpZERhdGEgPSBmYWxzZTtcclxuICAgICAgICAgICAgbXNnICs9IFwiPGJyPlBsZWFzZSBlbnRlciBwcm9kdWN0IG5hbWVcIjtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKEN1cnJlbnRNb2RlbC5QcmljZSA9PSBudWxsIHx8IEN1cnJlbnRNb2RlbC5QcmljZSA9PSBcIlwiIHx8IEN1cnJlbnRNb2RlbC5QcmljZSA9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgSXNWYWxpZERhdGEgPSBmYWxzZTtcclxuICAgICAgICAgICAgbXNnICs9IFwiPGJyPlBsZWFzZSBlbnRlciBwcmljZVwiO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoQ3VycmVudE1vZGVsLlF0eSA9PSBudWxsIHx8IEN1cnJlbnRNb2RlbC5RdHkgPT0gXCJcIiB8fCBDdXJyZW50TW9kZWwuUXR5ID09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICBJc1ZhbGlkRGF0YSA9IGZhbHNlO1xyXG4gICAgICAgICAgICBtc2cgKz0gXCI8YnI+UGxlYXNlIGVudGVyIHF1YW50aXR5XCI7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG5cclxuICAgICAgICBpZiAoSXNWYWxpZERhdGEgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICBtZXNzYWdlOiBtc2csXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gSXNWYWxpZERhdGE7XHJcblxyXG4gICAgfVxyXG5cclxuXHJcbiAgICBBZGRSZWNlaXB0TGluZShDdXJyZW50TW9kZWwpIHtcclxuICAgICAgICAvLyB0aGlzLm1vZGVsSW5wdXQuQWRkTW9kZWwuQmFuayA9IGpRdWVyeShcIiNCYW5rXCIpLnZhbCgpO1xyXG4gICAgICAgIGlmICh0aGlzLlZhbGlkYXRlUm93TW9kZWwoQ3VycmVudE1vZGVsLCBcIlwiKSkge1xyXG4gICAgICAgICAgICB2YXIgTVRleHQgPSBcIlwiO1xyXG4gICAgICAgICAgICBpZiAodGhpcy5MYW5nID09IFwiZW5cIikge1xyXG4gICAgICAgICAgICAgICAgTVRleHQgPSBcIk1vcmVcIjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIE1UZXh0ID0gXCLXmdeV16rXqFwiO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHZhciBNb2RlbE9iaiA9IHtcclxuICAgICAgICAgICAgICAgIEFtb3VudDogMCwgVmFsdWVEYXRlOiB0aGlzLkRlZmF1bHREYXRlLCBQYXlUeXBlSWQ6IFwiMVwiLCBBY2NvdW50SWQ6IFwiXCIsIEFjY291bnRObzogXCJcIixcclxuICAgICAgICAgICAgICAgIEJyYW5jaE5vOiBcIlwiLCBCYW5rOiBcIlwiLCBDcmVkaXRDYXJkVHlwZTogXCJcIiwgRG9uYXRpb25UeXBlSWQ6IFwiXCIsIFByb2plY3RDYXRlZ29yeUlkOiBcIlwiLCBQcm9qZWN0SWQ6IFwiXCIsIFJlZmVyZW5jZURhdGU6IHRoaXMuRGVmYXVsdERhdGUsXHJcbiAgICAgICAgICAgICAgICBGb3JfSW52b2ljZTogXCJcIiwgUmVjaWV2ZWRDdXN0SWQ6IFwiXCIsIFBheWVkOiBmYWxzZSwgRGVwb3NpdGVSZW1hcms6IFwiXCIsIFNob3dNb3JlOiBmYWxzZSwgU2hvd01vcmVUZXh0OiBNVGV4dCxcclxuICAgICAgICAgICAgICAgIENhc2hDU1M6IFwiZ3JleVwiLCBDcmVkaXRDU1M6IFwid2hpdGVcIiwgQmFua0NTUzogXCJ3aGl0ZVwiLCBPdGhlckNTUzogXCJ3aGl0ZVwiLCBJc1Nob3dPdGhlcnM6IGZhbHNlLCBJc0NyZWRpdFNob3c6IGZhbHNlLCBJc0JhbmtEZXRTaG93OiBmYWxzZVxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICBDdXJyZW50TW9kZWwuUmVjaWV2ZWRDdXN0SWQgPSB0aGlzLkN1c3RJZDtcclxuICAgICAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LlJlY2VpcHRMaW5lcy5wdXNoKE1vZGVsT2JqKTtcclxuICAgICAgICAgICAgdGhpcy5CaW5kVG90YWwoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBWYWxpZGF0ZVBhc3RlVGV4dCgpIHtcclxuICAgICAgICB2YXIgU3BsaXRUZXh0ID0gdGhpcy5QYXN0ZVRleHQuc3BsaXQoL1tcXHRdKy8pO1xyXG4gICAgICAgIHZhciBJc1ZhbGlkRGF0YSA9IHRydWU7XHJcbiAgICAgICAgdmFyIG1zZyA9IFwiXCI7XHJcbiAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICBpZiAoU3BsaXRUZXh0Lmxlbmd0aCA9PSA0KSB7XHJcbiAgICAgICAgICAgIGlmIChqUXVlcnkuaXNOdW1lcmljKFNwbGl0VGV4dFsxXS50cmltKCkpID09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgICAgICBJc1ZhbGlkRGF0YSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgbXNnID0gXCJRdWFudGl0eSBtdXN0IGJlIG51bWVyaWMgb25seVwiO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHZhciBTcGxpdFByaWNlID0gU3BsaXRUZXh0WzNdLnRyaW0oKS5zcGxpdCgvW1xcc10rLyk7XHJcbiAgICAgICAgICAgIGlmIChTcGxpdFByaWNlLmxlbmd0aCA9PSAyKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoalF1ZXJ5LmlzTnVtZXJpYyhTcGxpdFByaWNlWzFdLnRyaW0oKSkgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgICAgICBJc1ZhbGlkRGF0YSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIG1zZyA9IFwiUHJpY2UgbXVzdCBiZSBudW1lcmljIG9ubHlcIjtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIElzVmFsaWREYXRhID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICBtc2cgPSBcIlBsZWFzZSBlbnRlciB0ZXh0IGluIFByb2R1Y3QgTm8gXFx0IFF1YW50aXR5IFxcdCBQcm9kdWN0IE5hbWUgXFx0IFByaWNlIGZvcm1hdCBvbmx5XCI7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIElzVmFsaWREYXRhID0gZmFsc2U7XHJcbiAgICAgICAgICAgIG1zZyA9IFwiUGxlYXNlIGVudGVyIHRleHQgaW4gUHJvZHVjdCBObyBcXHQgUXVhbnRpdHkgXFx0IFByb2R1Y3QgTmFtZSBcXHQgUHJpY2UgZm9ybWF0IG9ubHlcIjtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKElzVmFsaWREYXRhID09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgbWVzc2FnZTogbXNnLFxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIElzVmFsaWREYXRhO1xyXG4gICAgfVxyXG4gICAgR2V0VmFsaWRhdGVUZXh0KGtleUNvZGUpIHtcclxuICAgICAgICBcclxuICAgICAgICBcclxuICAgICAgICBpZiAoa2V5Q29kZSA9PSAxMykge1xyXG4gICAgICAgICAgICB0aGlzLlBhc3RlVGV4dCA9IGpRdWVyeShcIiNQYXN0ZVRleHRcIikudmFsKCk7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLlZhbGlkYXRlUGFzdGVUZXh0KCkpIHtcclxuICAgICAgICAgICAgICAgIHZhciBTcGxpdFRleHQgPSB0aGlzLlBhc3RlVGV4dC5zcGxpdCgvW1xcdF0rLyk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLlBvcFByb2RPYmouUHJvZHVjdE5vID0gU3BsaXRUZXh0WzBdLnRyaW0oKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuUG9wUHJvZE9iai5RdHkgPSBwYXJzZUZsb2F0KFNwbGl0VGV4dFsxXS50cmltKCkpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5Qb3BQcm9kT2JqLlByb2R1Y3ROYW1lID0gU3BsaXRUZXh0WzJdLnRyaW0oKTtcclxuICAgICAgICAgICAgICAgIHZhciBTcGxpdFByaWNlID0gU3BsaXRUZXh0WzNdLnRyaW0oKS5zcGxpdCgvW1xcc10rLyk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLlBvcFByb2RPYmouUHJpY2UgPSBwYXJzZUZsb2F0KFNwbGl0UHJpY2VbMV0udHJpbSgpKS50b0ZpeGVkKDIpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5Qb3BQcm9kT2JqLlRvdGFsID0gKHBhcnNlRmxvYXQoU3BsaXRQcmljZVsxXS50cmltKCkpICogcGFyc2VGbG9hdChTcGxpdFRleHRbMV0udHJpbSgpKSkudG9GaXhlZCgyKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuUGFzdGVUZXh0ID0gXCJcIjtcclxuICAgICAgICAgICAgICAgIGpRdWVyeSgnI1Bhc3RlVGV4dE1vZGFsJykuY2xvc2VNb2RhbCgpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5CaW5kUHJvZFRvdGFsKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBPcGVuUHJvZHVjdHMoUHJvZE9iaikge1xyXG4gICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwiVGVtcFJlY2VpcHRJZFwiLCB0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdFR5cGVJZCk7XHJcbiAgICAgICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLnNldENvb2tpZShcIlRlbXBSb3dOb1wiLCBQcm9kT2JqLlJvd05vLDEwKTtcclxuICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0ICE9IHVuZGVmaW5lZCAmJiB0aGlzLm1vZGVsSW5wdXQgIT0gbnVsbCkge1xyXG4gICAgICAgICAgICB2YXIgamRhdGEgPSBKU09OLnN0cmluZ2lmeSh0aGlzLm1vZGVsSW5wdXQpO1xyXG4gICAgICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2Uuc2V0Q29va2llKFwiUmVjZWlwdENyZWF0ZV9DYWNoZVwiLCBqZGF0YSwgMTApO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2Uuc2V0Q29va2llKFwiUmVjZWlwdENyZWF0ZV9Jc1Nob3dQcm9kdWN0c1wiLCB0aGlzLklzU2hvd1Byb2R1Y3RzLCAxMCk7XHJcbiAgICAgICAgZG9jdW1lbnQubG9jYXRpb24gPSB0aGlzLmJhc2VVcmwgKyBcIlNlYXJjaFByb2R1Y3RzL1wiICsgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQrXCIvUmVjZWlwdENyZWF0ZVwiO1xyXG4gICAgfVxyXG5cclxuICAgIE9wZW5QYXN0ZU1vZGFsKFByb2RPYmopIHtcclxuICAgICAgIFxyXG4gICAgICAgIGlmICgoUHJvZE9iai5Qcm9kdWN0Tm8gIT0gdW5kZWZpbmVkIHx8IFByb2RPYmouUHJvZHVjdE5vICE9IG51bGwgfHwgUHJvZE9iai5Qcm9kdWN0Tm8gIT0gXCJcIilcclxuICAgICAgICAgICAgJiYgKFByb2RPYmouUHJvZHVjdE5hbWUgIT0gdW5kZWZpbmVkIHx8IFByb2RPYmouUHJvZHVjdE5hbWUgIT0gbnVsbCB8fCBQcm9kT2JqLlByb2R1Y3ROYW1lICE9IFwiXCIpXHJcbiAgICAgICAgICAgICYmIChQcm9kT2JqLlByaWNlICE9IHVuZGVmaW5lZCB8fCBQcm9kT2JqLlByaWNlICE9IG51bGwgfHwgUHJvZE9iai5QcmljZSAhPSBcIlwiKSkge1xyXG4gICAgICAgICAgICB0aGlzLlBhc3RlVGV4dCA9IFwiXCI7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5QYXN0ZVRleHQgPSBQcm9kT2JqLlByb2R1Y3RObyArIFwiIHwgXCIgKyBQcm9kT2JqLlByb2R1Y3ROYW1lICsgXCIgfCBcIiArIFByb2RPYmouUHJpY2U7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuUG9wUHJvZE9iaiA9IFByb2RPYmo7XHJcbiAgICAgICAgXHJcbiAgICAgICAgalF1ZXJ5KCcjUGFzdGVUZXh0TW9kYWwnKS5vcGVuTW9kYWwoKTtcclxuICAgIH1cclxuICAgIE9wZW5DdXN0U2VhcmNoKCkge1xyXG4gICAgICAgIHRoaXMuSVBvcFVwT3BlbiA9IHRydWU7XHJcbiAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJUZW1wUmVjZWlwdElkXCIsIHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0VHlwZUlkKTtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dCAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0ICE9IG51bGwpIHtcclxuICAgICAgICAgICAgdmFyIGpkYXRhID0gSlNPTi5zdHJpbmdpZnkodGhpcy5tb2RlbElucHV0KTtcclxuICAgICAgICAgICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLnNldENvb2tpZShcIlJlY2VpcHRDcmVhdGVfQ2FjaGVcIiwgamRhdGEsIDEwKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLnNldENvb2tpZShcIlJlY2VpcHRDcmVhdGVfSXNTaG93UHJvZHVjdHNcIiwgdGhpcy5Jc1Nob3dQcm9kdWN0cywgMTApO1xyXG4gICAgICAgIGRvY3VtZW50LmxvY2F0aW9uID0gdGhpcy5iYXNlVXJsICsgXCJDdXN0b21lci9TZWFyY2gvMC9SZWNlaXB0Q3JlYXRlL1wiICsgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQ7XHJcbiAgICAgICAgLy9qUXVlcnkoJyNDdXN0U2VhcmNoTW9kYWwgIC5tb2RhbC1jb250ZW50JykuaHRtbCgnPG9iamVjdCBkYXRhPVwiJyArIHRoaXMuYmFzZVVybCsnQ3VzdG9tZXIvU2VhcmNoLzEvUmVjZWlwdENyZWF0ZVwiIHN0eWxlPVwid2lkdGg6MTAwJTtoZWlnaHQ6NTAwcHhcIi8+Jyk7XHJcbiAgICAgICAgLy9qUXVlcnkoJyNDdXN0U2VhcmNoTW9kYWwnKS5vcGVuTW9kYWwoKTtcclxuXHJcbiAgICB9XHJcbiAgICBPcGVuTm90ZXMoKSB7XHJcblxyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgLy9pZiAodGhpcy5JUG9wVXBPcGVuID09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgIGpRdWVyeSgnI05vdGVNb2RhbCcpLm9wZW5Nb2RhbCgpO1xyXG4gICAgICAgIC8vfVxyXG4gICAgICAgIC8vZWxzZSB7XHJcbiAgICAgICAgLy8gICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQgPSB0aGlzLl9yb3V0ZVBhcmFtcy5wYXJhbXMuSWQ7XHJcbiAgICAgICAgLy8gICAgd2luZG93Lm9wZW4odGhpcy5iYXNlVXJsICsgXCJSZWNlaXB0Q3JlYXRlL1wiICsgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQgKyBcIi9cIiArIHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0VHlwZUlkLCBcIl9zZWxmXCIpO1xyXG4gICAgICAgICAgICBcclxuICAgICAgICAvLyAgICBqUXVlcnkoJyNDdXN0U2VhcmNoTW9kYWwnKS5jbG9zZU1vZGFsKCk7XHJcbiAgICAgICAgLy8gICAgalF1ZXJ5KFwiLmxlYW4tb3ZlcmxheVwiKS5jc3MoeyBcImRpc3BsYXlcIjogXCJub25lXCIgfSk7XHJcbiAgICAgICAgLy8gICAgdGhpcy5zZXRkZWZhdWx0bW9kZSgpO1xyXG4gICAgICAgIC8vfVxyXG4gICAgfVxyXG4gICAgT3BlblRlbXBsYXRlcygpIHtcclxuICAgICAgICBqUXVlcnkoJyNUZW1wbGF0ZU1vZGFsJykub3Blbk1vZGFsKCk7XHJcbiAgICB9XHJcbiAgICBDaG9vc2VOb3RlKG9iamN0KSB7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyTm90ZSA9IG9iamN0LlRleHQ7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyTm90ZUlkID0gb2JqY3QuVmFsdWU7XHJcbiAgICB9XHJcbiAgICBDaG9vc2VUaGFua3NMZXR0ZXJzKG9iamN0KSB7XHJcbiAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuVGhhbmtzTGV0dGVyTmFtZSA9IG9iamN0LlRleHQ7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LlRoYW5rc0xldHRlcklkID0gb2JqY3QuVmFsdWU7XHJcbiAgICB9XHJcbiAgICBHZXRDdXN0b21lckRldGFpbCgpIHtcclxuICAgICAgICB2YXIgQ3VzdElkID0gdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQ7XHJcbiAgICAgICAgdGhpcy5fQ3VzdG9tZXJTZXJ2aWNlLkdldENvbXBsZXRlQ3VzdERldChDdXN0SWQpLnN1YnNjcmliZShyZXNwPT4ge1xyXG4gICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICB2YXIgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3ApO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICByZXNwb25zZSA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9BZGRyZXNzZXMgPSByZXNwb25zZS5DdXN0b21lckFkZHJlc3NlcztcclxuICAgICAgICAgICAgICAgIHZhciBNYWluYWRkcmVzcztcclxuICAgICAgICAgICAgICAgIGpRdWVyeS5lYWNoKHJlc3BvbnNlLkN1c3RvbWVyQWRkcmVzc2VzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuTWFpbkFkZHJlc3MgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBNYWluYWRkcmVzcyA9IHRoaXMuQWRkcmVzc0lkO1xyXG4gICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQWRkcmVzc0lkID0gTWFpbmFkZHJlc3M7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCA9IHJlc3BvbnNlLkN1c3RvbWVySWQ7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdExpbmVzWzBdLlJlY2lldmVkQ3VzdElkID0gcmVzcG9uc2UuQ3VzdG9tZXJJZDtcclxuICAgICAgICAgICAgICAgIHRoaXMuQ3VzdElkID0gcmVzcG9uc2UuQ3VzdG9tZXJJZDtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lck5hbWUgPSByZXNwb25zZS5sbmFtZSArIFwiIFwiICsgcmVzcG9uc2UuZm5hbWU7XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIFxyXG4gICAgfVxyXG4gICAgXHJcbiAgICBDaG9vc2VQYXlUeXBlKGRhdGFvYmplY3QsIHBUeXBlSWQpIHtcclxuICAgICAgIC8vIGRlYnVnZ2VyO1xyXG4gICAgICAgIGRhdGFvYmplY3QuQ2FzaENTUyA9IFwid2hpdGVcIlxyXG4gICAgICAgIGRhdGFvYmplY3QuQ3JlZGl0Q1NTID0gXCJ3aGl0ZVwiXHJcbiAgICAgICAgZGF0YW9iamVjdC5CYW5rQ1NTID0gXCJ3aGl0ZVwiXHJcbiAgICAgICAgZGF0YW9iamVjdC5PdGhlckNTUyA9IFwid2hpdGVcIlxyXG4gICAgICAgIGRhdGFvYmplY3QuSXNDcmVkaXRTaG93ID0gZmFsc2U7XHJcbiAgICAgICAgLy92YXIgcFR5cGVJZCA9IFwiXCI7XHJcbiAgICAgICAgaWYgKHBUeXBlSWQgIT0gMCkge1xyXG4gICAgICAgICAgICBkYXRhb2JqZWN0LlBheVR5cGVJZCA9IHBUeXBlSWQ7XHJcbiAgICAgICAgICAgIGlmIChwVHlwZUlkID09IDEpIHtcclxuICAgICAgICAgICAgICAgIGRhdGFvYmplY3QuQ2FzaENTUyA9IFwiZ3JleVwiO1xyXG4gICAgICAgICAgICAgICAgLy9kYXRhb2JqZWN0LklzQmFua0RldFNob3cgPT0gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSBpZiAocFR5cGVJZD09Mykge1xyXG4gICAgICAgICAgICAgICAgZGF0YW9iamVjdC5DcmVkaXRDU1MgPSBcImdyZXlcIjtcclxuICAgICAgICAgICAgICAgIC8vZGF0YW9iamVjdC5Jc0JhbmtEZXRTaG93ID09IHRydWU7XHJcbiAgICAgICAgICAgICAgICBkYXRhb2JqZWN0LklzQ3JlZGl0U2hvdyA9IHRydWU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSBpZiAocFR5cGVJZD09OCkvL1xyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICBkYXRhb2JqZWN0LkJhbmtDU1MgPSBcImdyZXlcIlxyXG4gICAgICAgICAgICAgIC8vICBkYXRhb2JqZWN0LklzQmFua0RldFNob3cgPT0gdHJ1ZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBkYXRhb2JqZWN0LklzU2hvd090aGVycyA9IGZhbHNlO1xyXG4gICAgICAgICAgICBcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZXtcclxuICAgICAgICAgICAgZGF0YW9iamVjdC5QYXlUeXBlSWQgPSAwO1xyXG4gICAgICAgICAgICBkYXRhb2JqZWN0LklzU2hvd090aGVycyA9IHRydWU7XHJcbiAgICAgICAgICAgIGRhdGFvYmplY3QuT3RoZXJDU1MgPSBcImdyZXlcIjtcclxuICAgICAgICAgICAgLy9kYXRhb2JqZWN0LklzQmFua0RldFNob3cgPT0gZmFsc2U7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAocFR5cGVJZCAhPSAxICYmIHBUeXBlSWQgIT0gMykvLyBOb3QgQ2FzaCBhbmQgbm90IENyZWRpdCBjYXJkXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBkYXRhb2JqZWN0LklzQmFua0RldFNob3cgPSB0cnVlO1xyXG4gICAgICAgICAgICBkYXRhb2JqZWN0LklzQ3JlZGl0U2hvdyA9IGZhbHNlO1xyXG4gICAgICAgICAgICB0aGlzLkJpbmRBdXRvQ29tcGxldGVCYW5rKCk7XHJcblxyXG4gICAgICAgIH0gZWxzZSBpZiAocFR5cGVJZCA9PSAzKSB7XHJcbiAgICAgICAgICAgIGRhdGFvYmplY3QuSXNDcmVkaXRTaG93ID0gdHJ1ZTtcclxuICAgICAgICAgICAgZGF0YW9iamVjdC5Jc0JhbmtEZXRTaG93ID0gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Ugey8vIE9ubHkgRm9yIENhc2hcclxuICAgICAgICAgICAgZGF0YW9iamVjdC5Jc0JhbmtEZXRTaG93ID0gZmFsc2U7XHJcbiAgICAgICAgICAgIGRhdGFvYmplY3QuSXNDcmVkaXRTaG93ID0gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIEJpbmRQcm9qZWN0cyhDYXRJZCkge1xyXG5cclxuICAgICAgICB0aGlzLkJpbmRQcm9qZWN0RnJvbVByb2pDYXQoQ2F0SWQpO1xyXG4gICAgfVxyXG4gICAgQmluZFByb2plY3RGcm9tUHJvakNhdChDYXRJZCkge1xyXG4gICAgICAgIHRoaXMuX1JlY2llcHRTZXJ2aWNlLkdldFByb2plY3RzKENhdElkKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fUHJvamVjdHMgPSByZXNwb25zZS5EYXRhO1xyXG5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBCaW5kQXV0b0NvbXBsZXRlQmFuaygpIHtcclxuICAgICAgICB0aGlzLl9SZWNpZXB0U2VydmljZS5HZXRCYW5rcygpLnN1YnNjcmliZShyZXNwPT4ge1xyXG4gICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICB2YXIgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3ApO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAvL3RoaXMuX0JhbmtzID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgIHZhciB0eXBlYWhlYWRTb3VyY2UgPSBbXTtcclxuICAgICAgICAgICAgICAvLyAgZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaChyZXNwb25zZS5EYXRhLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIG5ld3RlbXAgPSB7fTtcclxuICAgICAgICAgICAgICAgICAgICBuZXd0ZW1wLmlkID0gdGhpcy5WYWx1ZTtcclxuICAgICAgICAgICAgICAgICAgICBuZXd0ZW1wLm5hbWUgPSB0aGlzLlRleHQ7XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZWFoZWFkU291cmNlLnB1c2gobmV3dGVtcCk7XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX0JhbmtzID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgIGpRdWVyeSgnLkJhbmsnKS50eXBlYWhlYWQoe1xyXG4gICAgICAgICAgICAgICAgICAgIHNvdXJjZTogdHlwZWFoZWFkU291cmNlLFxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGFUeXBlOiBcIkpTT05cIixcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG4gICAgU2hvd0hpZGVQcm9kdWN0cygpIHtcclxuICAgICAgICBcclxuICAgICAgICBpZiAodGhpcy5Jc1Nob3dQcm9kdWN0cyA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdFByb2R1Y3RzID0gW107XHJcbiAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0UHJvZHVjdHMgPSBbeyBSb3dObzogXCIxXCIsIFByb2R1Y3RObzogXCJcIiwgUHJvZHVjdE5hbWU6IFwiXCIsIFByaWNlOiBcIjBcIiwgUXR5OiBcIjFcIiwgVG90YWw6IFwiMFwiIH1dO1xyXG4gICAgICAgICAgICB0aGlzLklzU2hvd1Byb2R1Y3RzID0gdHJ1ZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdFByb2R1Y3RzLmxlbmd0aCA9PSAwKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLklzU2hvd1Byb2R1Y3RzID0gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBDYW5hZGRQcm9kdWN0KHByb2RPYmopOiBib29sZWFuIHtcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgIFxyXG4gICAgICAgIHJldHVybiAocHJvZE9iai5Qcm9kdWN0Tm8gIT0gdW5kZWZpbmVkICYmIHByb2RPYmouUHJvZHVjdE5vICE9IFwiXCIpXHJcbiAgICAgICAgICAgICYmIChwcm9kT2JqLlByb2R1Y3ROYW1lICE9IHVuZGVmaW5lZCAmJiBwcm9kT2JqLlByb2R1Y3ROYW1lICE9IFwiXCIpXHJcbiAgICAgICAgICAgICYmIChwcm9kT2JqLlByaWNlICE9IHVuZGVmaW5lZCAmJiBwcm9kT2JqLlByaWNlICE9IFwiXCIpXHJcbiAgICAgICAgICAgICYmIChwcm9kT2JqLlF0eSAhPSB1bmRlZmluZWQgJiYgcHJvZE9iai5RdHkgIT0gXCJcIik7XHJcbiAgICAgICAgXHJcbiAgICB9XHJcbiAgICBBZGRQcm9kdWN0cyhwcm9kT2JqKTogb2JzZXJ2YWJsZSB7XHJcbiAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICBpZiAodGhpcy5DYW5hZGRQcm9kdWN0KHByb2RPYmopKSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICB2YXIgUHJvZHVjdE9iaiA9IHsgUm93Tm86ICh0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdFByb2R1Y3RzLmxlbmd0aCsxKS50b1N0cmluZygpLCBQcm9kdWN0Tm86IFwiXCIsIFByb2R1Y3ROYW1lOiBcIlwiLCBQcmljZTogXCIwXCIsIFF0eTogXCIxXCIsIFRvdGFsOiBcIjBcIiB9O1xyXG4gICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdFByb2R1Y3RzLnB1c2goUHJvZHVjdE9iaik7XHJcbiAgICAgICAgICAgIHRoaXMuQmluZFByb2RUb3RhbCgpO1xyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICB2YXIgbXNnID0gJyc7XHJcbiAgICAgICAgICAgIGlmIChwcm9kT2JqLlByb2R1Y3RObyA9PSB1bmRlZmluZWQgfHwgcHJvZE9iai5Qcm9kdWN0Tm8gPT0gXCJcIikge1xyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICBtc2cgKz0gJ1xcblBsZWFzZSBlbnRlciBwcm9kdWN0IG5vJyA7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKHByb2RPYmouUHJvZHVjdE5hbWUgPT0gdW5kZWZpbmVkIHx8IHByb2RPYmouUHJvZHVjdE5hbWUgPT0gXCJcIikge1xyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICBtc2cgKz0gJ1xcblBsZWFzZSBlbnRlciBwcm9kdWN0IG5hbWUnO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChwcm9kT2JqLlByaWNlID09IHVuZGVmaW5lZCB8fCBwcm9kT2JqLlByaWNlID09IFwiXCIpIHtcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgbXNnICs9ICdcXG5QbGVhc2UgZW50ZXIgcHJpY2UnO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChwcm9kT2JqLlF0eSA9PSB1bmRlZmluZWQgfHwgcHJvZE9iai5RdHkgPT0gXCJcIikge1xyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICBtc2cgKz0gJ1xcblBsZWFzZSBlbnRlciBxdWFudGl0eSc7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICBtZXNzYWdlOiBtc2csIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIH1cclxuXHJcbiAgICB9XHJcbiAgICBkZWxQcm9kdWN0RGV0KFByb2RPYmopOiBvYnNlcnZhYmxlIHtcclxuICAgICAgLy8gIGRlYnVnZ2VyO1xyXG4gICAgICAgIC8vaWYgKHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0UHJvZHVjdHMubGVuZ3RoID4gMSkge1xyXG4gICAgICAgICAgICB2YXIgaW5kZXggPSAwO1xyXG4gICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdFByb2R1Y3RzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcyA9PSBQcm9kT2JqKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBpbmRleCA9IGluZGV4ICsgMTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0UHJvZHVjdHMuc3BsaWNlKGluZGV4LCAxKTtcclxuICAgICAgICAgICAgaW5kZXggPSAxO1xyXG4gICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdFByb2R1Y3RzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLlJvd05vID0gaW5kZXgudG9TdHJpbmcoKTtcclxuICAgICAgICAgICAgICAgIGluZGV4ID0gaW5kZXggKyAxO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgdGhpcy5CaW5kUHJvZFRvdGFsKCk7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdFByb2R1Y3RzLmxlbmd0aCA9PSAwKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLklzU2hvd1Byb2R1Y3RzID0gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAvL31cclxuICAgIH1cclxuICAgIENhbGN1bGF0ZVByb2RSb3dUb3RhbChwcm9kT2JqKSB7XHJcbiAgICAgIC8vICBkZWJ1Z2dlcjtcclxuICAgICAgICB2YXIgUHJpY2UgPSAwO1xyXG4gICAgICAgIGlmIChwcm9kT2JqLlByaWNlICE9IHVuZGVmaW5lZCAmJiBwcm9kT2JqLlByaWNlICE9IG51bGwgJiYgcHJvZE9iai5RdHkgIT0gXCJcIikge1xyXG4gICAgICAgICAgICBQcmljZSA9IHBhcnNlRmxvYXQocHJvZE9iai5QcmljZSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHZhciBRdHkgPSAwO1xyXG4gICAgICAgIGlmIChwcm9kT2JqLlF0eSAhPSB1bmRlZmluZWQgJiYgcHJvZE9iai5RdHkgIT0gbnVsbCAmJiBwcm9kT2JqLlF0eSAhPSBcIlwiKSB7XHJcbiAgICAgICAgICAgIFF0eSA9IHBhcnNlRmxvYXQocHJvZE9iai5RdHkpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBwcm9kT2JqLlRvdGFsID0gKFByaWNlICogUXR5KS50b0ZpeGVkKDIpO1xyXG5cclxuICAgICAgICB0aGlzLkJpbmRQcm9kVG90YWwoKTtcclxuICAgIH1cclxuXHJcbiAgICBCaW5kUHJvZFRvdGFsKCkge1xyXG4gICAgICAgIHZhciBQcm9kVG90YWwgPSAwO1xyXG4gICAgICAgIGpRdWVyeS5lYWNoKHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0UHJvZHVjdHMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgUHJvZFRvdGFsID0gcGFyc2VGbG9hdChQcm9kVG90YWwudG9TdHJpbmcoKSkrIHBhcnNlRmxvYXQodGhpcy5Ub3RhbCk7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LlByb2R1Y3RUb3RhbCA9IFByb2RUb3RhbC50b0ZpeGVkKDIpO1xyXG4gICAgfVxyXG4gICAgbmdPbkluaXQoKSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgLy9qUXVlcnkoXCIubGVhbi1vdmVybGF5XCIpLmNzcyh7IFwiZGlzcGxheVwiOiBcIm5vbmVcIiB9KTtcclxuICAgICAgICBqUXVlcnkoXCIjTm90ZU1vZGFsXCIpLmNsb3NlTW9kYWwoKTtcclxuICAgICAgICBqUXVlcnkoXCIubGVhbi1vdmVybGF5XCIpLmNzcyh7IFwiZGlzcGxheVwiOiBcIm5vbmVcIiB9KTtcclxuICAgICAgICB3aW5kb3cuc2Nyb2xsVG8oMCwgMCk7XHJcbiAgICAgICAgZGVidWdnZXI7XHJcblxyXG4gICAgICAgIHZhciBqZGF0YSA9IHRoaXMuX3Jlc291cmNlU2VydmljZS5nZXRDb29raWUoXCJSZWNlaXB0Q3JlYXRlX0NhY2hlXCIpO1xyXG4gICAgICAgIGlmIChqZGF0YSAhPSB1bmRlZmluZWQgJiYgamRhdGEgIT0gdW5kZWZpbmVkICYmIGpkYXRhICE9IFwiXCIpIHtcclxuICAgICAgICAgICAgamRhdGEgPSBqZGF0YS5zdWJzdHJpbmcoMSwgamRhdGEubGVuZ3RoKTtcclxuICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0ID0galF1ZXJ5LnBhcnNlSlNPTihqZGF0YSk7XHJcbiAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkID0gdGhpcy5fcm91dGVQYXJhbXMucGFyYW1zLklkO1xyXG4gICAgICAgICAgICB0aGlzLkdldEN1c3RvbWVyRGV0YWlsKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgICAvLyAgYWxlcnQoXCJkZGRcIik7XHJcbiAgICAgICAgdGhpcy5MYW5nID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJsYW5nXCIpO1xyXG4gICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5HZXRMYW5nUmVzKHRoaXMuRm9ybXR5cGUsIHRoaXMuTGFuZykuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5SRVMgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMuX1JlY2llcHRTZXJ2aWNlLkdldEN1c3RvbWVyTm90ZXMoKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fQ3VzdG9tZXJOb3RlcyA9IHJlc3BvbnNlLkRhdGE7XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMuQmluZEF1dG9Db21wbGV0ZUJhbmsoKTtcclxuICAgICAgICB0aGlzLl9SZWNpZXB0U2VydmljZS5HZXRUaGFua3NMZXR0ZXJzKHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0VHlwZUlkKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fVGhhbmtMZXR0ZXJzID0gcmVzcG9uc2UuRGF0YTtcclxuXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgdGhpcy5fUmVjaWVwdFNlcnZpY2UuR2V0QXNzb2NpYXRpb24oKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5hc3NvY2lhdGlvbklkID0gcmVzcG9uc2UuRGF0YVswXS5WYWx1ZTtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5hc3NvY2lhdGlvbk5hbWUgPSByZXNwb25zZS5EYXRhWzBdLlRleHQ7XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHRoaXMuX1JlY2llcHRTZXJ2aWNlLkdldFByaW50ZXIoKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5QcmludGVySWQgPSByZXNwb25zZS5EYXRhWzBdLlZhbHVlO1xyXG5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuICAgICAgICB0aGlzLl9SZWNpZXB0U2VydmljZS5HZXRFbXBsb3llZSgpLnN1YnNjcmliZShyZXNwPT4ge1xyXG4gICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICB2YXIgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3ApO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkVtcGxveWVlSWQgPSByZXNwb25zZS5EYXRhWzBdLlZhbHVlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkVtcGxveWVlTmFtZSA9IHJlc3BvbnNlLkRhdGFbMF0uVGV4dDtcclxuXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgdGhpcy5fUmVjaWVwdFNlcnZpY2UuR2V0UGF5VHlwZSgpLnN1YnNjcmliZShyZXNwPT4ge1xyXG4gICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICB2YXIgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3ApO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9QYXlUeXBlcyA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgdGhpcy5fUmVjaWVwdFNlcnZpY2UuR2V0QWNjb3VudHMoKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fQWNjb3VudHMgPSByZXNwb25zZS5EYXRhO1xyXG5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgdGhpcy5fUmVjaWVwdFNlcnZpY2UuR2V0R29hbHMoKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fR29hbHMgPSByZXNwb25zZS5EYXRhO1xyXG5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgdGhpcy5fUmVjaWVwdFNlcnZpY2UuR2V0UHJvamVjdENhdHMoKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fUHJvamVjdENhdHMgPSByZXNwb25zZS5EYXRhO1xyXG5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuICAgICAgICB0aGlzLkJpbmRQcm9qZWN0RnJvbVByb2pDYXQoLTEpO1xyXG4gICAgICAgIHRoaXMuX1JlY2llcHRTZXJ2aWNlLkdldEN1cnJlbmNpZXNGREIoKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fQ3VycmVuY2llcyA9IHJlc3BvbnNlLkRhdGE7XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHRoaXMuX1JlY2llcHRTZXJ2aWNlLkdldFJlY2llcHRUeXBlKHRoaXMuX3JvdXRlUGFyYW1zLnBhcmFtcy5SZWNlaXB0VHlwZUlkKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LlJlY2llcHRUeXBlID0gcmVzcG9uc2UuRGF0YVswXS5SZWNpZXB0TmFtZUVuZztcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXJyZW5jeUlkID0gcmVzcG9uc2UuRGF0YVswXS5DdXJyZW5jeUlkO1xyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHRoaXMuX1JlY2llcHRTZXJ2aWNlLkdldFJlY2VpcHREZXRhaWwoKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LlJlY2llcHRObyA9IHJlc3BvbnNlLkRhdGEuVmFsdWU7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuUmVjaWVwdERhdGUgPSB0aGlzLkRlZmF1bHREYXRlO1xyXG5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuICAgICAgICB2YXIgQ3VzdElkID0gdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQ7XHJcbiAgICAgICAgdGhpcy5HZXRDdXN0b21lckRldGFpbCgpO1xyXG4gICAgICAgIHZhciBpc3Nob3cgPSB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZ2V0Q29va2llKFwiUmVjZWlwdENyZWF0ZV9Jc1Nob3dQcm9kdWN0c1wiKTtcclxuICAgICAgICBpZiAoaXNzaG93ICE9IHVuZGVmaW5lZCAmJiBpc3Nob3cgIT0gdW5kZWZpbmVkICYmIGlzc2hvdyAhPSBcIlwiKSB7XHJcbiAgICAgICAgICAgIGlzc2hvdyA9IGlzc2hvdy5zdWJzdHJpbmcoMSwgaXNzaG93Lmxlbmd0aCk7XHJcbiAgICAgICAgICAgIHRoaXMuSXNTaG93UHJvZHVjdHMgPSBCb29sZWFuKGlzc2hvdyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHZhciByb3dubyA9IHRoaXMuX3Jlc291cmNlU2VydmljZS5nZXRDb29raWUoXCJUZW1wUm93Tm9cIik7XHJcbiAgICAgICAgaWYgKHJvd25vICE9IHVuZGVmaW5lZCAmJiByb3dubyAhPSB1bmRlZmluZWQgJiYgcm93bm8gIT0gXCJcIikge1xyXG4gICAgICAgICAgICByb3dubyA9IHJvd25vLnN1YnN0cmluZygxLCByb3duby5sZW5ndGgpO1xyXG4gICAgICAgICAgICB2YXIgcGRhdGEgPSB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZ2V0Q29va2llKFwiUmVjZWlwdENyZWF0ZV9Qcm9kdWN0XCIpO1xyXG4gICAgICAgICAgICBpZiAocGRhdGEgIT0gdW5kZWZpbmVkICYmIHBkYXRhICE9IHVuZGVmaW5lZCAmJiBwZGF0YSAhPSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICBwZGF0YSA9IHBkYXRhLnN1YnN0cmluZygxLCBwZGF0YS5sZW5ndGgpO1xyXG4gICAgICAgICAgICAgICAgdmFyIFByb2R1Y3QgPSBbXTtcclxuICAgICAgICAgICAgICAgIFByb2R1Y3QgPSBqUXVlcnkucGFyc2VKU09OKHBkYXRhKTtcclxuICAgICAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0UHJvZHVjdHMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5Sb3dObyA9PSByb3dubykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLlByb2R1Y3RObyA9IFByb2R1Y3QuUGFydE51bWJlcjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5Qcm9kdWN0TmFtZSA9IFByb2R1Y3QuUHJvZE5hbWVEaXM7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuUHJpY2UgPSBwYXJzZUZsb2F0KFByb2R1Y3QuUHJpY2UpLnRvRml4ZWQoMik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuVG90YWwgPSAocGFyc2VGbG9hdCh0aGlzLlByaWNlKSAqIHBhcnNlRmxvYXQodGhpcy5RdHkpKS50b0ZpeGVkKDIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5CaW5kUHJvZFRvdGFsKCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZGVsZXRlQ29va2llKFwiVGVtcFJvd05vXCIpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmRlbGV0ZUNvb2tpZShcIlJlY2VpcHRDcmVhdGVfUHJvZHVjdFwiKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG4iXX0=
