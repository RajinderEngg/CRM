System.register(["angular2/core"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1;
    var AmaxLogoutComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            }],
        execute: function() {
            //import {ResourceService} from "../services/ResourceService";
            AmaxLogoutComponent = (function () {
                function AmaxLogoutComponent() {
                }
                AmaxLogoutComponent.prototype.ngOnInit = function () {
                    //debugger;
                    //this._resourceService.deleteCookie("RememberKey");
                };
                AmaxLogoutComponent = __decorate([
                    core_1.Component({
                        template: "<h1>Cleaning user information...</h1>"
                    }), 
                    __metadata('design:paramtypes', [])
                ], AmaxLogoutComponent);
                return AmaxLogoutComponent;
            }());
            exports_1("AmaxLogoutComponent", AmaxLogoutComponent);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFtYXgvbG9nb3V0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1lBQ0EsOERBQThEO1lBSzlEO2dCQUNJO2dCQUNBLENBQUM7Z0JBR0Qsc0NBQVEsR0FBUjtvQkFDSSxXQUFXO29CQUNYLG9EQUFvRDtnQkFDeEQsQ0FBQztnQkFaTDtvQkFBQyxnQkFBUyxDQUFDO3dCQUNQLFFBQVEsRUFBRSx1Q0FBdUM7cUJBRXBELENBQUM7O3VDQUFBO2dCQVVGLDBCQUFDO1lBQUQsQ0FUQSxBQVNDLElBQUE7WUFURCxxREFTQyxDQUFBIiwiZmlsZSI6ImFtYXgvbG9nb3V0LmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtDb21wb25lbnQsIE9uSW5pdH0gZnJvbSBcImFuZ3VsYXIyL2NvcmVcIjtcclxuLy9pbXBvcnQge1Jlc291cmNlU2VydmljZX0gZnJvbSBcIi4uL3NlcnZpY2VzL1Jlc291cmNlU2VydmljZVwiO1xyXG5AQ29tcG9uZW50KHtcclxuICAgIHRlbXBsYXRlOiBcIjxoMT5DbGVhbmluZyB1c2VyIGluZm9ybWF0aW9uLi4uPC9oMT5cIlxyXG4gICAgXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBBbWF4TG9nb3V0Q29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0e1xyXG4gICAgY29uc3RydWN0b3IoKSB7ICAvKnByaXZhdGUgX3Jlc291cmNlU2VydmljZTogUmVzb3VyY2VTZXJ2aWNlKi9cclxuICAgIH1cclxuXHJcblxyXG4gICAgbmdPbkluaXQoKSB7XHJcbiAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAvL3RoaXMuX3Jlc291cmNlU2VydmljZS5kZWxldGVDb29raWUoXCJSZW1lbWJlcktleVwiKTtcclxuICAgIH1cclxufSJdfQ==
