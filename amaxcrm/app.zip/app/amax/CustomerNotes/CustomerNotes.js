System.register(['angular2/common', "../../services/ResourceService", "angular2/router", "angular2/core", "../../services/CustomerService", "../../amaxUtil", '../../autocomplete/autocomplete-container', '../../autocomplete/autocomplete.component', '../../comonComponents/basicComponents'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var common_1, ResourceService_1, router_1, core_1, CustomerService_1, amaxUtil_1, autocomplete_container_1, autocomplete_component_1, basicComponents_1;
    var AUTOCOMPLETE_DIRECTIVES, AmaxCustomers;
    return {
        setters:[
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (ResourceService_1_1) {
                ResourceService_1 = ResourceService_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (CustomerService_1_1) {
                CustomerService_1 = CustomerService_1_1;
            },
            function (amaxUtil_1_1) {
                amaxUtil_1 = amaxUtil_1_1;
            },
            function (autocomplete_container_1_1) {
                autocomplete_container_1 = autocomplete_container_1_1;
            },
            function (autocomplete_component_1_1) {
                autocomplete_component_1 = autocomplete_component_1_1;
            },
            function (basicComponents_1_1) {
                basicComponents_1 = basicComponents_1_1;
            }],
        execute: function() {
            exports_1("AUTOCOMPLETE_DIRECTIVES", AUTOCOMPLETE_DIRECTIVES = [autocomplete_component_1.Autocomplete, autocomplete_container_1.AutocompleteContainer]);
            AmaxCustomers = (function () {
                function AmaxCustomers(_resourceService, _customerService, _routeParams) {
                    this._resourceService = _resourceService;
                    this._customerService = _customerService;
                    this._routeParams = _routeParams;
                    this.modelInput = {};
                    this.TempmodelInput = {};
                    this.custSearchData = [];
                    this.RES = {};
                    this.SelectedPhType = {};
                    this.tempstreetmsg = "";
                    this.Formtype = "CUSTOMER_MASTER";
                    this.Lang = "";
                    //modelInput.lname= "";
                    this.ShowMore = false;
                    this.IsRecordEditMode = false;
                    this.ShowMoreText = "More";
                    this.ShowLoader = false;
                    this.ShowMsg = false;
                    this.ShowGroups = true;
                    this.GroupText = "Show Groups";
                    this.Msg = "";
                    this.MsgClass = "text-primary";
                    this.Isbtndisable = "";
                    this.IsFileAsSaveBtn = "";
                    this.IsFileAsCancelBtn = "";
                    this.languageArray = [];
                    this.Address = {};
                    this.PhoneModel = {};
                    this.EmailModel = {};
                    this.IsShowAll = false;
                    this.CustList = {};
                    this.SAVE_BTN_TEXT = "";
                    this.BTN_PHADD = "";
                    this.EditPhoneData = {};
                    this.EditAddressData = {};
                    this.EditEmailData = {};
                    this.IsFileAstxtShow = false;
                    this.FILEAS_BTN_TEXT = "";
                    this.cssFileAsBtn = "";
                    this.IsCancel = false;
                    this.SearchVal = "";
                    this.EnterCount = 0;
                    this.CustIdText = "";
                    this.BaseAppUrl = "";
                    this.PhIndex = 0;
                    this.KendoRTLCSS = "";
                    this.CHANGEDIR = "";
                    this.ChangeDialog = "";
                    //IsFileAsSave: boolean = false;
                    //Email: string = "";
                    //CustomerEmail: Object = {};
                    //modelInput.CustomerEmails = [];
                    this._CustTypes = [];
                    this._Sources = [];
                    this._Employees = [];
                    this._Suffixes = [];
                    this._PhoneTypes = [];
                    this._AddressTypes = [];
                    this._Groups = [];
                    this._Countries = [];
                    this._States = [];
                    this._Cities = [];
                    this.selectedCar = '';
                    this.asyncSelectedCar = '';
                    this.autocompleteLoading = false;
                    this.autocompleteNoResults = false;
                    this.autocompleteSelect = false;
                    this._previousasyncSelectedCar = '';
                    this.modelInput.BirthDate = "";
                    this.modelInput.CustomerAddresses = [];
                    this.modelInput.CustomerPhones = [];
                    this.modelInput.CustomerEmails = [];
                    this.modelInput.CustomerGroups = [];
                    this.Address.CountryCode = "";
                    this.Address.StateId = "";
                    this.modelInput.employeeid = "";
                    this.modelInput.CustomerType = "";
                    this.modelInput.CameFromCustomer = "";
                    this.modelInput.Safixid = "";
                    this.modelInput.Gender = "0";
                    this.PhoneModel.PhoneTypeId = "";
                    this.RES.CUSTOMER_MASTER = {};
                    this.IsShowAll = false;
                    this.SAVE_BTN_TEXT = this.RES.CUSTOMER_MASTER.APP_BTN_SAVE;
                    this.BTN_PHADD = this.RES.CUSTOMER_MASTER.APP_BTN_PHADD;
                    this.ADD_NEW_CUST_TEXT = this.RES.CUSTOMER_MASTER.APP_LBL_NEW_CUST;
                    this.modelInput.CustomerEmails = [{ Email: "", EmailName: "", Newslettere: true, publish: 1, NewsOrder: "News1", EPublishOrder: "EPub1" }];
                    this.modelInput.CustomerPhones = [{ PhoneTypeId: "", Prefix: "", Area: "", Phone: "", IsSms: 1, Comments: "", IsShowRemarks: false, phpublish: 1, SMSOrder: "SMS1", PublishOrder: "Pub1" }];
                    // debugger;
                    var empid = localStorage.getItem("employeeid");
                    var ccode = this._resourceService.getCookie(empid + "ccode");
                    if (ccode.length > 0)
                        ccode = ccode.substring(1, ccode.length);
                    this.modelInput.CustomerAddresses = [{
                            Street: "", Street2: "", CityName: "", Zip: "", CountryCode: ccode, StateId: "", AddressTypeId: "",
                            ForDelivery: true, MainAddress: true, MainOrder: "MainAddr1", DelvryOrder: "Delvry1"
                        }];
                    var custtype = this._resourceService.getCookie(empid + "cust");
                    if (custtype.length > 0) {
                        custtype = custtype.substring(1, custtype.length);
                    }
                    this.modelInput.CustomerType = custtype;
                    var emp = this._resourceService.getCookie(empid + "emp");
                    if (emp.length > 0)
                        emp = emp.substring(1, emp.length);
                    this.modelInput.employeeid = emp;
                    var source = this._resourceService.getCookie(empid + "src");
                    if (source.length > 0)
                        source = source.substring(1, source.length);
                    else {
                    }
                    this.modelInput.CameFromCustomer = source;
                    this.CSSTEXT = "mdi-content-add";
                    this.cssFileAsBtn = "mdi-content-create";
                    this.IsFileAstxtShow = false;
                    clearTimeout(this.StopTimeOut);
                    this.modelInput.CustomerId = _routeParams.params.Id;
                    this.BaseAppUrl = _resourceService.AppUrl;
                    this.TempmodelInput = this.modelInput;
                    //alert(this._resourceService.getCookie(empid + "cust"));
                    //this.ShowMoreText = "More";
                }
                AmaxCustomers.prototype.getCurrentContext = function () {
                    return this;
                };
                AmaxCustomers.prototype.dateSelectionChange = function (evt) {
                    console.log(evt);
                    this.modelInput.BirthDate = evt;
                    // alert(this.modelInput.BirthDate);
                    //this.validateLogin();
                };
                AmaxCustomers.prototype.getAsyncData = function (context) {
                    var _this = this;
                    var SrchVal = context.asyncSelectedCar;
                    // if (SrchVal != undefined && SrchVal != null && SrchVal != "") {
                    // debugger;
                    if (this._previousasyncSelectedCar == context.asyncSelectedCar) {
                        //clearTimeout(this.StopTimeOut);
                        return this._cachedResult;
                    }
                    else {
                        //alert(this._previousasyncSelectedCar + " | " + context.asyncSelectedCar);
                        if (context.asyncSelectedCar != "") {
                            this._previousasyncSelectedCar = context.asyncSelectedCar;
                            //  this.StopTimeOut = setTimeout(() => {
                            //    alert(SrchVal);
                            this._customerService.GetCompleteSearch(SrchVal).subscribe(function (response) {
                                // debugger;
                                response = jQuery.parseJSON(response);
                                if (response.IsError == true) {
                                    //alert(response.ErrMsg);
                                    bootbox.alert({ message: response.ErrMsg,
                                        className: _this.ChangeDialog,
                                        buttons: {
                                            ok: {
                                                //label: 'Ok',
                                                className: _this.CHANGEDIR
                                            }
                                        }
                                    });
                                }
                                else {
                                    context.carsExample1 = response.Data;
                                }
                            }, function (error) {
                                console.log(error);
                            }, function () {
                                console.log("CallCompleted");
                            });
                            // }, 500);
                            this._cachedResult = context.carsExample1;
                        }
                        else {
                            this._cachedResult = [];
                        }
                        return this._cachedResult;
                    }
                };
                AmaxCustomers.prototype.changeAutocompleteLoading = function (e) {
                    this.autocompleteLoading = e;
                };
                AmaxCustomers.prototype.changeAutocompleteNoResults = function (e) {
                    this.autocompleteSelect = false;
                    this.autocompleteNoResults = e;
                };
                AmaxCustomers.prototype.autocompleteOnSelect = function (e) {
                    var _this = this;
                    this.autocompleteSelect = true;
                    console.log("Selected value: " + e.item);
                    var CompData = e.item.split('|');
                    //debugger;
                    if (e.item != undefined && e.item != "" && e.item != null) {
                        //alert(CompData[0]);
                        this._customerService.GetCompleteCustDet(CompData[0].trim()).subscribe(function (response) {
                            //debugger;
                            response = jQuery.parseJSON(response);
                            if (response.IsError == true) {
                                //alert(response.ErrMsg);
                                bootbox.alert({ message: response.ErrMsg,
                                    className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                            else {
                                _this.modelInput = response.Data;
                                // alert(this.modelInput.BirthDate);
                                _this.SAVE_BTN_TEXT = _this.RES.CUSTOMER_MASTER.APP_BTN_UPDATE;
                                _this.ADD_NEW_CUST_TEXT = _this.RES.CUSTOMER_MASTER.APP_LBL_UPDATE_CUST;
                                _this.CSSTEXT = "mdi-content-create";
                                if (_this.modelInput.CustomerEmails.length == 0) {
                                    _this.modelInput.CustomerEmails = [{ Email: "", EmailName: _this.modelInput.FileAs, Newslettere: false }];
                                }
                                if (_this.modelInput.CustomerPhones.length == 0) {
                                    var phid = "";
                                    jQuery.each(_this._PhoneTypes, function () {
                                        if (this.Text == "CellPhone") {
                                            phid = this.Value;
                                            return false;
                                        }
                                    });
                                    _this.modelInput.CustomerPhones = [{ PhoneTypeId: phid, Prefix: "", Area: "", Phone: "", IsSms: 0, Comments: "", phpublish: 0 }];
                                }
                                if (_this.modelInput.CustomerAddresses.length == 0) {
                                    var empid = localStorage.getItem("employeeid");
                                    var ccode = _this._resourceService.getCookie(empid + "ccode");
                                    if (ccode.length > 0)
                                        ccode = ccode.substring(1, ccode.length);
                                    var adid = "";
                                    var comptext = "Home";
                                    if (_this.modelInput.Company != "" && _this.modelInput.Company != undefined && _this.modelInput.Company != null) {
                                        comptext = "Work";
                                    }
                                    jQuery.each(_this._AddressTypes, function () {
                                        if (this.Text == comptext) {
                                            adid = this.Value;
                                            return false;
                                        }
                                    });
                                    _this.modelInput.CustomerAddresses = [{ Street: "", Street2: "", CityName: "", Zip: "", CountryCode: ccode, StateId: "", AddressTypeId: adid, ForDelivery: false, MainAddress: false }];
                                }
                                _this.CustIdText = "( " + _this.modelInput.CustomerId + " )";
                                _this.IsFileAstxtShow = false;
                                //this.IsCancel = true;
                                //this.HideShowFileAstxt();
                                _this.CancelFileAstxt();
                                _this.IsShowAll = true;
                                //this.bindGroup();
                                //alert(this.RES);
                                _this.bindGroupTree(true);
                            }
                        }, function (error) {
                            console.log(error);
                        }, function () {
                            console.log("CallCompleted");
                        });
                    }
                };
                AmaxCustomers.prototype.OpenNewReceipt = function () {
                    if (this.modelInput != undefined && this.modelInput.CustomerId != undefined && this.modelInput.CustomerId >= 0) {
                        var custId = this.modelInput.CustomerId;
                        if (custId != -1) {
                            var emid = localStorage.getItem("employeeid");
                            document.location = this.BaseAppUrl + "ReceiptSelect/" + emid;
                        }
                    }
                };
                AmaxCustomers.prototype.OpenChargeCreditPage = function () {
                    var _this = this;
                    this.Isbtndisable = "disabled";
                    this._customerService.CheckIsOpenCharge().subscribe(function (response) {
                        console.log(response);
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    } } });
                        }
                        else {
                            //debugger;
                            if (response.Data != undefined && response.Data != null && response.Data.length == 1) {
                                var custId = -1;
                                if (_this.TempmodelInput != undefined && _this.TempmodelInput.CustomerId != undefined && _this.TempmodelInput.CustomerId >= 0) {
                                    custId = _this.TempmodelInput.CustomerId;
                                }
                                if (_this.modelInput != undefined && _this.modelInput.CustomerId != undefined && _this.modelInput.CustomerId >= 0) {
                                    custId = _this.modelInput.CustomerId;
                                }
                                if (custId != -1) {
                                    document.location = _this.BaseAppUrl + "ChargeCredit/" + custId + "/" + response.Data[0].Value;
                                }
                                else {
                                    bootbox.alert({
                                        message: 'Please save new or load previous customer and then click on charge credit button',
                                        className: _this.ChangeDialog,
                                        buttons: {
                                            ok: {
                                                //label: 'Ok',
                                                className: _this.CHANGEDIR
                                            }
                                        }
                                    });
                                }
                            }
                            else if (response.Data != undefined && response.Data != null && response.Data.length > 1) {
                                //debugger;
                                var custId = -1;
                                if (_this.TempmodelInput != undefined && _this.TempmodelInput.CustomerId != undefined && _this.TempmodelInput.CustomerId >= 0) {
                                    custId = _this.TempmodelInput.CustomerId;
                                }
                                if (_this.modelInput != undefined && _this.modelInput.CustomerId != undefined && _this.modelInput.CustomerId >= 0) {
                                    custId = _this.modelInput.CustomerId;
                                }
                                if (custId != -1) {
                                    document.location = _this.BaseAppUrl + "Terminals/Show/" + custId;
                                }
                                else {
                                    bootbox.alert({
                                        message: 'Please save new or load previous customer and then click on charge credit button',
                                        className: _this.ChangeDialog,
                                        buttons: {
                                            ok: {
                                                //label: 'Ok',
                                                className: _this.CHANGEDIR
                                            }
                                        }
                                    });
                                }
                            }
                            else {
                                bootbox.alert({
                                    message: _this.RES.CUSTOMER_MASTER.APP_MSG_CHARGECREDIT,
                                    className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        } }
                                });
                            }
                        }
                        _this.ShowMsg = true;
                        _this.Msg = response.ErrMsg;
                    }, function (error) { return console.log(error); }, function () { return console.log("Save Call Compleated"); });
                    this.Isbtndisable = "";
                };
                AmaxCustomers.prototype.StopTimer = function () {
                    bootbox.alert({
                        message: 'From Stop Timer' + this.StopTimeOut, className: this.ChangeDialog,
                        buttons: {
                            ok: {
                                //label: 'Ok',
                                className: this.CHANGEDIR
                            }
                        }
                    });
                    clearTimeout(this.StopTimeOut);
                };
                AmaxCustomers.prototype.SetdefaultPage = function () {
                    var _this = this;
                    document.location = this.BaseAppUrl + "Customer/Add/-1";
                    this.IsFileAstxtShow = true;
                    this.IsCancel = true;
                    var empid = localStorage.getItem("employeeid");
                    this.asyncSelectedCar = "";
                    this.modelInput = {};
                    this.modelInput.BirthDate = "";
                    this.modelInput.CustomerId = -1;
                    this.CustIdText = "";
                    this.HideShowFileAstxt();
                    var custtype = this._resourceService.getCookie(empid + "cust");
                    if (custtype.length > 0)
                        custtype = custtype.substring(1, custtype.length);
                    this.modelInput.CustomerType = custtype;
                    var emp = this._resourceService.getCookie(empid + "emp");
                    if (emp.length > 0)
                        emp = emp.substring(1, emp.length);
                    this.modelInput.employeeid = emp;
                    var source = this._resourceService.getCookie(empid + "src");
                    if (source.length > 0)
                        source = source.substring(1, source.length);
                    this.modelInput.CameFromCustomer = source;
                    this.ShowMore = false;
                    //this.ShowMoreText = "More"; 
                    this.ShowMoreText = this.RES.CUSTOMER_MASTER.APP_LNK_LBL_MORE;
                    this.SAVE_BTN_TEXT = this.RES.CUSTOMER_MASTER.APP_BTN_SAVE;
                    this.CSSTEXT = "mdi-content-add";
                    this.ADD_NEW_CUST_TEXT = this.RES.CUSTOMER_MASTER.APP_LBL_NEW_CUST;
                    this.ShowGroups = true;
                    this.showhideGroups();
                    //this.GroupText = this.RES.CUSTOMER_MASTER.APP_LBL_SHOWGROUPS;
                    var phid = "";
                    var SMS = 0;
                    var publish = 0;
                    var epublish = 0;
                    jQuery.each(this._PhoneTypes, function () {
                        if (this.Text == "CellPhone") {
                            phid = this.Value;
                            SMS = 1;
                            publish = 1;
                            epublish = 1;
                            return false;
                        }
                    });
                    this.modelInput.CustomerPhones = [{ PhoneTypeId: phid, Prefix: "", Area: "", Phone: "", IsSms: SMS, Comments: "", phpublish: publish }];
                    //debugger;
                    this.modelInput.CustomerEmails = [{ Email: "", EmailName: "", Newslettere: false, publish: epublish }];
                    var cntrycode = this._resourceService.getCookie(empid + "ccode");
                    if (cntrycode.length > 0)
                        cntrycode = cntrycode.substring(1, cntrycode.length);
                    var adid = "";
                    jQuery.each(this._AddressTypes, function () {
                        if (this.Text == "Home") {
                            adid = this.Value;
                            return false;
                        }
                    });
                    this.modelInput.CustomerAddresses = [{ Street: "", Street2: "", CityName: "", Zip: "", CountryCode: cntrycode, StateId: "", AddressTypeId: adid, ForDelivery: false, MainAddress: false }];
                    this.modelInput.CustomerGroups = [];
                    this.Address.CountryCode = "";
                    this.Address.StateId = "";
                    this.modelInput.Safixid = "";
                    this.modelInput.Gender = "0";
                    this.ShowMsg = false;
                    this.Msg = "";
                    this.IsShowAll = false;
                    this._customerService.GetGeneralGroups(this.IsShowAll).subscribe(function (data) {
                        // debugger;
                        if (_this.IsShowAll == false) {
                            jQuery("#groupTree").html("Loding...");
                            var res = jQuery.parseJSON(data).Data;
                            jQuery("#groupTree").kendoTreeView({
                                loadOnDemand: true,
                                checkboxes: {
                                    checkChildren: true
                                },
                                //check: this.onGroupSelect,
                                dataSource: res
                            });
                        }
                        else {
                            jQuery("#groupTree1").html("Loding...");
                            var res = jQuery.parseJSON(data).Data;
                            jQuery("#groupTree1").kendoTreeView({
                                loadOnDemand: true,
                                checkboxes: {
                                    checkChildren: true
                                },
                                //check: this.onGroupSelect,
                                dataSource: res
                            });
                        }
                    }, function (err) {
                    }, function () {
                    });
                };
                AmaxCustomers.prototype.CancelFileAstxt = function () {
                    this.IsFileAstxtShow = true;
                    this.IsFileAstxtShow = false;
                    this.IsCancel = true;
                    jQuery("#FileAstxt").hide();
                    jQuery("#FileAsSpn").show();
                    this.FILEAS_BTN_TEXT = this.RES.CUSTOMER_MASTER.APP_BTN_FILEAS;
                    if (this.modelInput.CustomerId != undefined && this.modelInput.CustomerId != null && parseInt(this.modelInput.CustomerId) > -1) {
                        jQuery("#FileAsSaveBtn").show();
                        this.cssFileAsBtn = "mdi-content-create";
                        jQuery("#FileAsCancelBtn").hide();
                    }
                    else {
                        jQuery("#FileAsSaveBtn").hide();
                        jQuery("#FileAsCancelBtn").hide();
                    }
                };
                AmaxCustomers.prototype.HideShowFileAstxt = function () {
                    var _this = this;
                    if (this.IsFileAstxtShow == false) {
                        this.IsFileAstxtShow = true;
                        jQuery("#FileAstxt").show();
                        jQuery("#FileAsSpn").hide();
                        this.IsCancel = false;
                        this.FILEAS_BTN_TEXT = this.RES.CUSTOMER_MASTER.APP_BTN_SAVEFILEAS;
                        // alert(this.modelInput.CustomerId);
                        if (this.modelInput.CustomerId != undefined && this.modelInput.CustomerId != null && parseInt(this.modelInput.CustomerId) > -1) {
                            jQuery("#FileAsSaveBtn").show();
                            this.cssFileAsBtn = "mdi-content-save";
                            jQuery("#FileAsCancelBtn").show();
                        }
                        else {
                            jQuery("#FileAsSaveBtn").hide();
                            jQuery("#FileAsCancelBtn").hide();
                        }
                    }
                    else {
                        this.IsFileAstxtShow = false;
                        jQuery("#FileAstxt").hide();
                        jQuery("#FileAsSpn").show();
                        this.FILEAS_BTN_TEXT = this.RES.CUSTOMER_MASTER.APP_BTN_FILEAS;
                        if (this.modelInput.CustomerId != undefined && this.modelInput.CustomerId != null && parseInt(this.modelInput.CustomerId) > -1) {
                            jQuery("#FileAsSaveBtn").show();
                            this.cssFileAsBtn = "mdi-content-create";
                            jQuery("#FileAsCancelBtn").hide();
                            if (this.modelInput.FileAs != "" && this.modelInput.FileAs != undefined && this.modelInput.FileAs != null && this.IsCancel == false) {
                                this._customerService.SaveFileAs(this.modelInput.CustomerId, this.modelInput.FileAs).subscribe(function (response) {
                                    response = jQuery.parseJSON(response);
                                    //alert('hello');
                                    if (response.IsError == true) {
                                        //alert(response.ErrMsg);
                                        bootbox.alert({
                                            message: response.ErrMsg, className: _this.ChangeDialog,
                                            buttons: {
                                                ok: {
                                                    //label: 'Ok',
                                                    className: _this.CHANGEDIR
                                                }
                                            }
                                        });
                                    }
                                    //this.IsFileAsSave = false;
                                    bootbox.alert({
                                        message: response.ErrMsg, className: _this.ChangeDialog,
                                        buttons: {
                                            ok: {
                                                //label: 'Ok',
                                                className: _this.CHANGEDIR
                                            }
                                        }
                                    });
                                    _this.IsCancel = true;
                                    //}
                                    //else {
                                    //}
                                });
                            }
                            else {
                                bootbox.alert({
                                    message: this.RES.CUSTOMER_MASTER.APP_EMPTYFILEAS, className: this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: this.CHANGEDIR
                                        }
                                    }
                                });
                                this.bindFileAs();
                                this.IsFileAstxtShow = false;
                                this.HideShowFileAstxt();
                            }
                        }
                        else {
                            jQuery("#FileAsSaveBtn").hide();
                            jQuery("#FileAsCancelBtn").hide();
                        }
                    }
                };
                AmaxCustomers.prototype.SetEmailName = function () {
                    if (this.modelInput.FileAs != undefined && this.modelInput.FileAs != null) {
                        if (this.modelInput.CustomerEmails.length > 0) {
                            this.modelInput.CustomerEmails[this.modelInput.CustomerEmails.length - 1].EmailName = this.modelInput.FileAs;
                        }
                    }
                };
                AmaxCustomers.prototype.CheckCustWithSameName = function () {
                };
                AmaxCustomers.prototype.SetDefaultCust = function () {
                    //alert();
                    //debugger;
                };
                AmaxCustomers.prototype.setdefaultAddress = function () {
                    this.bindFileAs();
                    this.CheckCustWithfnamelnamecompphsemails();
                    var adid = "";
                    var adtext = "Home";
                    if (this.modelInput.Company != "" && this.modelInput.Company != undefined) {
                        adtext = "Work";
                    }
                    jQuery.each(this._AddressTypes, function () {
                        if (this.Text == adtext) {
                            adid = this.Value;
                            return false;
                        }
                    });
                    this.modelInput.CustomerAddresses[this.modelInput.CustomerAddresses.length - 1].AddressTypeId = adid;
                };
                AmaxCustomers.prototype.bindFileAs = function () {
                    if (this.modelInput.FileAs == "" || this.modelInput.FileAs == undefined) {
                        //debugger;
                        if ((this.modelInput.Company == "" || this.modelInput.Company == undefined)) {
                            var fileastext = "";
                            if (this.modelInput.fname != "" && this.modelInput.fname != undefined && this.modelInput.lname != "" && this.modelInput.lname != undefined) {
                                fileastext = this.modelInput.lname + " " + this.modelInput.fname;
                            }
                            else if (this.modelInput.fname != "" && this.modelInput.fname != undefined && (this.modelInput.lname == "" || this.modelInput.lname == undefined)) {
                                fileastext = " " + this.modelInput.fname;
                            }
                            else if ((this.modelInput.fname == "" || this.modelInput.fname == undefined) && (this.modelInput.lname != "" && this.modelInput.lname != undefined)) {
                                fileastext = this.modelInput.lname + " ";
                            }
                            this.modelInput.FileAs = fileastext;
                        }
                        else if ((this.modelInput.lname == "" || this.modelInput.lname == undefined) && (this.modelInput.fname == "" || this.modelInput.lname == undefined)) {
                            var fileastext = "";
                            if ((this.modelInput.Company != "" && this.modelInput.Company != undefined)) {
                                fileastext = this.modelInput.Company;
                            }
                            this.modelInput.FileAs = fileastext;
                        }
                        else
                            this.modelInput.FileAs = "(" + this.modelInput.Company + ") " + this.modelInput.lname + " " + this.modelInput.fname; //+ " " & m_strSpouse
                        if (this.modelInput.CustomerEmails.length > 0) {
                            this.modelInput.CustomerEmails[this.modelInput.CustomerEmails.length - 1].EmailName = this.modelInput.FileAs;
                        }
                    }
                    this.SetEmailName();
                };
                AmaxCustomers.prototype.bindGroup = function () {
                    //alert(this.IsShowAll); this function is calling on click of checkbox
                    var isshow = false;
                    if (this.IsShowAll == true) {
                        isshow = false;
                        this.IsShowAll = false;
                    }
                    else {
                        this.IsShowAll = true;
                        isshow = true;
                    }
                    this.bindGroupTree(isshow);
                };
                AmaxCustomers.prototype.saveCustomerData = function () {
                    var _this = this;
                    //debugger;
                    this.Isbtndisable = "disabled";
                    this.ShowLoader = true;
                    this.getSelectedGroups();
                    var count = 0;
                    if (this.modelInput.CustomerAddresses != undefined && this.modelInput.CustomerAddresses != null) {
                        jQuery.each(this.modelInput.CustomerAddresses, function () {
                            if (this.MainAddress == true) {
                                count = count + 1;
                            }
                            if (count > 1) {
                                //bootbox.alert("Main Address sholud be only one");
                                this.Isbtndisable = "";
                                this.ShowLoader = false;
                                return false;
                            }
                        });
                    }
                    //alert(this.modelInput.BirthDate);
                    if (this.modelInput.BirthDate != "") {
                        if (moment(this.modelInput.BirthDate, "DD-MM-YYYY", true).isValid() == false) {
                            bootbox.alert({ message: "Birthdate is not valid" });
                            this.Isbtndisable = "";
                            this.ShowLoader = false;
                            return false;
                        }
                    }
                    if (count <= 1 || this.modelInput.CustomerAddresses == undefined || this.modelInput.CustomerAddresses == null) {
                        if (this.modelInput.CustomerPhones != undefined && this.modelInput.CustomerPhones != null) {
                            var phtemp = [];
                            jQuery('input[name^="ph"]').each(function () {
                                phtemp.push(jQuery(this).val());
                            });
                            var artemp = [];
                            jQuery('input[name^="ar"]').each(function () {
                                artemp.push(jQuery(this).val());
                            });
                            var pretemp = [];
                            jQuery('input[name^="pre"]').each(function () {
                                pretemp.push(jQuery(this).val());
                            });
                            var i = 0;
                            jQuery.each(this.modelInput.CustomerPhones, function () {
                                if (this.IsSms == true) {
                                    this.IsSms = "1";
                                }
                                else {
                                    this.IsSms = "0";
                                }
                                if (this.phpublish == true) {
                                    this.phpublish = "1";
                                }
                                else {
                                    this.phpublish = "0";
                                }
                                this.Phone = phtemp[i];
                                this.Area = artemp[i];
                                this.Prefix = pretemp[i];
                                i++;
                                //var temp = this.PhoneTypeId.split(';');
                                //this.PhoneTypeId = parseInt(temp[1]);
                                //this.PhoneType = temp[0];
                            });
                        }
                        if (this.modelInput.CustomerEmails != undefined && this.modelInput.CustomerEmails != null) {
                            jQuery.each(this.modelInput.CustomerEmails, function () {
                                if (this.publish == true) {
                                    this.publish = "1";
                                }
                                else {
                                    this.publish = "0";
                                }
                                i++;
                            });
                        }
                        var jdata = JSON.stringify(this.modelInput);
                        console.log(jdata);
                        this._customerService.AddCustomer(jdata).subscribe(function (response) {
                            console.log(response);
                            response = jQuery.parseJSON(response);
                            _this.Isbtndisable = "";
                            _this.ShowLoader = false;
                            if (response.IsError == true) {
                                //alert(response.ErrMsg);
                                _this.MsgClass = "text-danger";
                            }
                            else {
                                //alert(response.ErrMsg);
                                _this.MsgClass = "text-success";
                                var empid = localStorage.getItem("employeeid");
                                _this._resourceService.setCookie(empid + "cust", _this.modelInput.CustomerType, 10);
                                _this._resourceService.setCookie(empid + "emp", _this.modelInput.employeeid, 10);
                                _this._resourceService.setCookie(empid + "src", _this.modelInput.CameFromCustomer, 10);
                                if (_this.modelInput.CustomerAddresses.length > 0)
                                    _this._resourceService.setCookie(empid + "ccode", _this.modelInput.CustomerAddresses[_this.modelInput.CustomerAddresses.length - 1].CountryCode, 10);
                                // debugger;
                                //document.location = this.BaseAppUrl + "Customer/Add/-1";
                                //debugger;
                                _this.TempmodelInput = response.Data;
                                _this.modelInput = response.Data;
                                _this.editCustDet(_this.modelInput);
                            }
                            _this.ShowMsg = true;
                            _this.Msg = response.ErrMsg;
                        }, function (error) { return console.log(error); }, function () { return console.log("Save Call Compleated"); });
                    }
                    else {
                        bootbox.alert({
                            message: this.RES.CUSTOMER_MASTER.APP_MSG_ISMAINADD, className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                        this.Isbtndisable = "";
                        this.ShowLoader = false;
                    }
                };
                AmaxCustomers.prototype.CheckCustWithfnamelnamecompphsemails = function () {
                    var _this = this;
                    var jdata = JSON.stringify(this.modelInput);
                    //debugger;
                    var fname = "";
                    var lname = "";
                    var company = "";
                    var phones = "";
                    var emails = "";
                    if (this.modelInput.fname == undefined)
                        fname = "";
                    else
                        fname = this.modelInput.fname;
                    if (this.modelInput.lname == undefined)
                        lname = "";
                    else
                        lname = this.modelInput.lname;
                    if (this.modelInput.Company == undefined)
                        company = "";
                    else
                        company = this.modelInput.Company;
                    jQuery('input[name^="ph"]').each(function () {
                        if (jQuery(this).val() != "" && jQuery(this).val() != undefined && jQuery(this).val() != null && jQuery(this).val().length >= 3) {
                            phones += jQuery(this).val() + "','";
                        }
                    });
                    if (phones.length > 0)
                        phones = phones.substring(0, phones.length - 3);
                    jQuery.each(this.modelInput.CustomerEmails, function () {
                        if (this.Email != "" && this.Email != undefined && this.Email != null && this.Email.length >= 3) {
                            emails += this.Email + "','";
                        }
                    });
                    if (emails.length > 0)
                        emails = emails.substring(0, emails.length - 3);
                    if ((fname != "" && fname.length >= 2 && lname != "" && lname.length >= 2)
                        || (company != "" && company.length >= 3)
                        || (phones != "")
                        || (emails != "")) {
                        this._customerService.GetCustomersSearchData(fname, lname, company, phones, emails).subscribe(function (response) {
                            //debugger;
                            response = jQuery.parseJSON(response);
                            if (response.IsError == true) {
                                bootbox.alert({
                                    message: response.ErrMsg, className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                            else {
                                _this.CustList = {};
                                _this.CustList = response.Data;
                                if (response.Data != null && response.Data != undefined) {
                                    _this.custSearchData = response.Data;
                                    jQuery('#CustModal').openModal();
                                }
                            }
                        }, function (error) {
                            console.log(error);
                        }, function () {
                            console.log("CallCompleted");
                        });
                    }
                    //this.bindFileAs();
                };
                AmaxCustomers.prototype.CheckCustWithfnamelname = function (fname, lname, company) {
                    var _this = this;
                    var jdata = JSON.stringify(this.modelInput);
                    //debugger;
                    if (this.modelInput.fname == undefined)
                        fname = "";
                    else
                        fname = this.modelInput.fname;
                    if (this.modelInput.lname == undefined)
                        lname = "";
                    else
                        lname = this.modelInput.lname;
                    if (this.modelInput.Company == undefined)
                        company = "";
                    else
                        company = this.modelInput.Company;
                    this._customerService.CheckCustWithSameName(fname, lname, company).subscribe(function (response) {
                        //debugger;
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.CustList = {};
                            _this.CustList = response.Data;
                            if (response.Data != null && response.Data != undefined) {
                                _this.custSearchData = response.Data;
                                jQuery("#CustModal").openModal();
                            }
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //this.bindFileAs();
                };
                AmaxCustomers.prototype.CheckCustWithEmail = function () {
                    //var Email = "";
                    //if (this.EmailModel.Email != "" && this.EmailModel.Email != undefined)
                    //    Email = this.EmailModel.Email;
                    //this._customerService.CheckCustWithSameEmail(Email).subscribe(response=> {
                    //    //debugger;
                    //    response = jQuery.parseJSON(response);
                    //    if (response.IsError == true) {
                    //        alert(response.ErrMsg);
                    //    }
                    //    else {
                    //        this.CustList = {};
                    //        this.CustList = response.Data;
                    //        if (response.Data != null && response.Data != undefined) {
                    //            this.custSearchData = response.Data;
                    //            jQuery("#CustModal").modal("show");
                    //        }
                    //        //alert(this.RES);
                    //    }
                    //}, error=> {
                    //    console.log(error);
                    //}, () => {
                    //    console.log("CallCompleted")
                    //});
                };
                AmaxCustomers.prototype.CheckCustWithPhone = function () {
                    var _this = this;
                    var Phone = "";
                    if (this.PhoneModel.Phone != "" && this.PhoneModel.Phone != undefined)
                        Phone = this.PhoneModel.Phone;
                    this._customerService.CheckCustWithSamePhone(this.PhoneModel.Phone).subscribe(function (response) {
                        //debugger;
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.CustList = {};
                            _this.CustList = response.Data;
                            if (response.Data != null && response.Data != undefined) {
                                _this.custSearchData = response.Data;
                                jQuery("#CustModal").openModal();
                            }
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxCustomers.prototype.ShowRemarks = function (PhObj) {
                    jQuery.each(this.modelInput.CustomerPhones, function () {
                        if (this == PhObj) {
                            this.IsShowRemarks = true;
                        }
                    });
                };
                AmaxCustomers.prototype.showAddPopup = function () {
                    this.Address = {};
                    this.PhoneModel = {};
                    this.PhoneModel.PhoneTypeId = "";
                    this.Address.CountryCode = "";
                    this.Address.StateId = "";
                    this.Address.CityName = "";
                    this.Address.AddressTypeId = "";
                    this.EmailModel = {};
                    this.BTN_PHADD = this.RES.CUSTOMER_MASTER.APP_BTN_PHADD;
                };
                AmaxCustomers.prototype.showhideGroups = function () {
                    //debugger;
                    if (this.ShowGroups == false) {
                        this.ShowGroups = true;
                        this.GroupText = this.RES.CUSTOMER_MASTER.APP_LBL_HIDEGROUP;
                        jQuery("#GrpDiv").show(1000);
                    }
                    else {
                        this.ShowGroups = false;
                        this.GroupText = this.RES.CUSTOMER_MASTER.APP_LBL_SHOWGROUPS;
                        jQuery("#GrpDiv").hide(1000);
                    }
                };
                AmaxCustomers.prototype.CanaddAddress = function (adobj) {
                    //alert('Hello');
                    return (adobj.Street != undefined && adobj.Street != "")
                        && (adobj.Street2 != undefined && adobj.Street2 != "")
                        && (adobj.Zip != undefined && adobj.Zip != "")
                        && (adobj.CountryCode != undefined && adobj.CountryCode != "")
                        && (adobj.AddressTypeId != undefined && adobj.AddressTypeId != "");
                };
                AmaxCustomers.prototype.AddAddresses = function (adobj) {
                    var IsMainAdd = false;
                    adobj.CityName = jQuery("#City").val();
                    if (this.CanaddAddress(adobj)) {
                        var empid = localStorage.getItem("employeeid");
                        this._resourceService.setCookie(empid + "ccode", adobj.CountryCode, 10);
                        var adid = "";
                        var adtext = "Home";
                        if (this.modelInput.Company != "" && this.modelInput.Company != undefined) {
                            adtext = "Work";
                        }
                        jQuery.each(this._AddressTypes, function () {
                            if (this.Text == adtext) {
                                adid = this.Value;
                                return false;
                            }
                        });
                        var AddresObj = { Street: "", Street2: "", CityName: "", Zip: "", CountryCode: adobj.CountryCode, StateId: "", AddressTypeId: adid, ForDelivery: false, MainAddress: false, MainOrder: "MainAddr" + (this.modelInput.CustomerAddresses.length + 1).toString(), DelvryOrder: "Delvry" + (this.modelInput.CustomerAddresses.length + 1).toString() };
                        //jQuery.each(this.modelInput.CustomerAddresses, function () {
                        //    if (this.MainAddress == true && adobj.MainAddress == true && this != adobj) {
                        //        adobj.MainAddress = false;
                        //        return false;
                        //    }
                        //});
                        if (IsMainAdd == false) {
                            this.modelInput.CustomerAddresses.push(AddresObj);
                        }
                    }
                    else {
                        var msg = '';
                        if (adobj.Street == undefined || adobj.Street == "") {
                            //msg += '\nStreet is not filled'; APP_AL_MSG_STREET
                            msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_MSG_STREET;
                        }
                        if (adobj.Street2 == undefined || adobj.Street2 == "") {
                            //msg += '\nArea is not filled';
                            msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_MSG_AREA;
                        }
                        //if (adobj.CityName == undefined || adobj.CityName == "")
                        //    //msg += '\nCity is not filled'; 
                        //    msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_MSG_CITY;
                        if (adobj.Zip == undefined || adobj.Zip == "") {
                            //msg += '\nZip is not filled'; 
                            msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_MSG_ZIP;
                        }
                        if (adobj.CountryCode == undefined || adobj.CountryCode == "") {
                            //msg += '\nCountry is not selected';
                            msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_MSG_COUNTRY;
                        }
                        //if (this.Address.StateId == undefined || this.Address.StateId == "") {
                        //    msg += '\nState is not selected';
                        //}
                        if (adobj.AddressTypeId == undefined || adobj.AddressTypeId == "") {
                            //msg += '\nAddress type is not selected';
                            msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_MSG_ADTYPE;
                        }
                        bootbox.alert({
                            message: msg, className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                    }
                };
                AmaxCustomers.prototype.CanaddPhone = function (phoneObj) {
                    //debugger;
                    //alert(this.PhoneModel.PhoneTypeId + ' ' + this.PhoneModel.PhoneType + ' ' + this.PhoneModel.Prefix + ' ' + this.PhoneModel.Area + ' ' + this.PhoneModel.Phone);
                    return (phoneObj.PhoneTypeId != undefined && phoneObj.PhoneTypeId != "");
                    // && (this.PhoneModel.PhoneType != undefined&& this.PhoneModel.PhoneType != "" )
                    //&& (this.PhoneModel.Prefix != undefined&& this.PhoneModel.Prefix != ""  )
                    //&& (this.PhoneModel.Area != undefined&&this.PhoneModel.Area != ""  )
                    //&& (phoneObj.Phone != undefined && phoneObj.Phone != "");
                    //&& (this.PhoneModel.Prefix != undefined && this.PhoneModel.Prefix.length != 3);            ;
                };
                AmaxCustomers.prototype.AddPhones = function (phoneObj) {
                    if (this.CanaddPhone(phoneObj)) {
                        debugger;
                        //if (this.IsRecordEditMode == false) {
                        var phid = "";
                        var SMS = 0;
                        var publish = 0;
                        jQuery.each(this._PhoneTypes, function () {
                            if (this.Text == "CellPhone") {
                                phid = this.Value;
                                SMS = 1;
                                publish = 1;
                                return false;
                            }
                        });
                        var PhoneObj = { PhoneTypeId: phid, PhoneType: "", Prefix: "", Area: "", Phone: "", IsSms: SMS, Comments: "", IsShowRemarks: false, phpublish: publish, SMSOrder: "SMS" + (this.modelInput.CustomerPhones.length + 1).toString(), PublishOrder: "Pub" + (this.modelInput.CustomerPhones.length + 1).toString() };
                        this.modelInput.CustomerPhones.push(PhoneObj);
                    }
                    else {
                        var msg = '';
                        if (phoneObj.PhoneTypeId == undefined || phoneObj.PhoneTypeId == "") {
                            //msg += '\nPhone type is not selected';
                            msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_REGMSG_PHTYPE;
                        }
                        //if (phoneObj.Phone == undefined || phoneObj.Phone == "") {
                        //    //msg += '\nPhone number is not filled';
                        //    msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_REGMSG_PHNO;
                        //}
                        //if (this.PhoneModel.Prefix.length!=3) {
                        //    msg += '\nPrefix must of 3 numeric digits';
                        //}
                        bootbox.alert({
                            message: msg, className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                    }
                };
                AmaxCustomers.prototype.CanaddEmail = function (EmailObj) {
                    //debugger;
                    //alert('Hello');
                    return (EmailObj.EmailName != undefined && EmailObj.EmailName != "");
                    //(EmailObj.Email != undefined && EmailObj.Email != "") &&
                };
                AmaxCustomers.prototype.AddEmails = function (EmailObj) {
                    //debugger;
                    if (this.CanaddEmail(EmailObj)) {
                        var epublish = 0;
                        jQuery.each(this._PhoneTypes, function () {
                            if (this.Text == "CellPhone") {
                                epublish = 1;
                                return false;
                            }
                        });
                        //if (this.IsRecordEditMode == false) {
                        var eObj = {};
                        eObj.Email = "";
                        eObj.EmailName = this.modelInput.FileAs;
                        eObj.Newslettere = true;
                        eObj.publish = epublish;
                        eObj.NewsOrder = "News" + (this.modelInput.CustomerEmails.length + 1).toString();
                        eObj.EPublishOrder = "EPub" + (this.modelInput.CustomerEmails.length + 1).toString();
                        this.modelInput.CustomerEmails.push(eObj);
                    }
                    else {
                        var msg = '';
                        //if (EmailObj.Email == undefined || EmailObj.Email == "")
                        //    //msg += '\nEmail is not filled';
                        //    msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_REGMSG_EMAIL;
                        if (EmailObj.EmailName == undefined || EmailObj.EmailName == "") {
                            //msg += '\nName is not filled';
                            msg += '\n' + this.RES.CUSTOMER_MASTER.APP_AL_REGMSG_ENAME;
                        }
                        bootbox.alert({
                            message: msg, className: this.ChangeDialog,
                            buttons: {
                                ok: {
                                    //label: 'Ok',
                                    className: this.CHANGEDIR
                                }
                            }
                        });
                    }
                    // this.modelInput.CustomerAddresses = this.CustomerAddresses;
                };
                AmaxCustomers.prototype.editCustDet = function (Obj) {
                    var _this = this;
                    this._customerService.GetCompleteCustDet(Obj.CustomerId).subscribe(function (response) {
                        // debugger;
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.modelInput = response.Data;
                            _this.SAVE_BTN_TEXT = _this.RES.CUSTOMER_MASTER.APP_BTN_UPDATE;
                            //this.ADD_NEW_CUST_TEXT = this.RES.CUSTOMER_MASTER.APP_LBL_UPDATE_CUST;
                            _this.CSSTEXT = "mdi-content-add";
                            if (_this.modelInput.CustomerEmails.length == 0) {
                                _this.modelInput.CustomerEmails = [{ Email: "", EmailName: _this.modelInput.FileAs, Newslettere: false, publish: 0, NewsOrder: "News1", EPublishOrder: "EPub1" }];
                            }
                            else {
                                var count = 1;
                                jQuery.each(_this.modelInput.CustomerEmails, function () {
                                    this.NewsOrder = "News" + count;
                                    this.EPublishOrder = "EPub" + count++;
                                });
                            }
                            if (_this.modelInput.CustomerPhones.length == 0) {
                                var phid = "";
                                jQuery.each(_this._PhoneTypes, function () {
                                    if (this.Text == "CellPhone") {
                                        phid = this.Value;
                                        return false;
                                    }
                                });
                                _this.modelInput.CustomerPhones = [{ PhoneTypeId: phid, Prefix: "", Area: "", Phone: "", IsSms: 0, Comments: "", phpublish: 0, SMSOrder: "SMS1", PublishOrder: "Pub1" }];
                            }
                            else {
                                var count = 1;
                                jQuery.each(_this.modelInput.CustomerPhones, function () {
                                    this.SMSOrder = "SMS" + count;
                                    this.PublishOrder = "Pub" + count++;
                                });
                            }
                            if (_this.modelInput.CustomerAddresses.length == 0) {
                                var empid = localStorage.getItem("employeeid");
                                var ccode = _this._resourceService.getCookie(empid + "ccode");
                                if (ccode.length > 0)
                                    ccode = ccode.substring(1, ccode.length);
                                var adid = "";
                                var comptext = "Home";
                                if (_this.modelInput.Company != "" && _this.modelInput.Company != undefined && _this.modelInput.Company != null) {
                                    comptext = "Work";
                                }
                                jQuery.each(_this._AddressTypes, function () {
                                    if (this.Text == comptext) {
                                        adid = this.Value;
                                        return false;
                                    }
                                });
                                _this.modelInput.CustomerAddresses = [{ Street: "", Street2: "", CityName: "", Zip: "", CountryCode: ccode, StateId: "", AddressTypeId: adid, ForDelivery: false, MainAddress: false, MainOrder: "MainAddr1", DelvryOrder: "Delvry1" }];
                            }
                            else {
                                var count = 1;
                                jQuery.each(_this.modelInput.CustomerAddresses, function () {
                                    this.MainOrder = "MainAddr" + count;
                                    this.DelvryOrder = "Delvry" + count++;
                                });
                            }
                            //var treeview = jQuery("#groupTree").data("kendoTreeView");
                            //var bar = treeview.findById("Bar");
                            //jQuery.each(this.modelInput.CustomerGroups, function () {
                            //    var data = jQuery("#groupTree").data("kendoTreeView").dataSource.getByUid(this.CustomerGeneralGroupId);
                            //    if (data) {
                            //        data.set("checked", true);
                            //    }
                            //    //var GroupNode = treeview.findById(this.CustomerGeneralGroupId);
                            //    //treeview.dataItem(GroupNode).set("checked", true);
                            //});
                            _this.CustIdText = "( " + _this.modelInput.CustomerId + " )";
                            _this.IsFileAstxtShow = false;
                            _this.HideShowFileAstxt();
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxCustomers.prototype.CheckPhoneType = function (PhoneObj) {
                    var _this = this;
                    //debugger;
                    //alert(PhoneObj.PhoneTypeId + " | " + jQuery("#PhoneType").val());
                    var pretemp = [];
                    jQuery('select[name^="phtype"]').each(function () {
                        pretemp.push(jQuery(this).val());
                    });
                    var index = 0;
                    jQuery.each(this.modelInput.CustomerPhones, function () {
                        if (this == PhoneObj) {
                            return false;
                        }
                        index = index + 1;
                    });
                    if (pretemp[index] != undefined && pretemp[index] != null && pretemp[index] != "") {
                        var PhoneTypeId = pretemp[index];
                        this._customerService.GetPhoneTypeDet(PhoneTypeId).subscribe(function (data) {
                            //debugger;
                            //
                            var response = jQuery.parseJSON(data);
                            if (response.IsError == true) {
                                bootbox.alert({
                                    message: response.ErrMsg, className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                            else {
                                if (response.Data != undefined && response.Data != null && response.Data != "") {
                                    //debugger;
                                    //alert(index + " | " + this.modelInput.CustomerPhones[index].IsSms + " | " + response.Data.Text);
                                    if (response.Data.Text == "1") {
                                        _this.modelInput.CustomerPhones[index].IsSms = 1;
                                        _this.modelInput.CustomerPhones[index].phpublish = 1;
                                        _this.modelInput.CustomerEmails[_this.modelInput.CustomerEmails.length - 1].publish = 1;
                                    }
                                    else {
                                        _this.modelInput.CustomerPhones[index].phpublish = 0;
                                        _this.modelInput.CustomerPhones[index].IsSms = 0;
                                        _this.modelInput.CustomerEmails[_this.modelInput.CustomerEmails.length - 1].publish = 0;
                                    }
                                }
                            }
                            //var treeviewDataSource = jQuery("#groupTree").data("kendoTreeView").dataSource.view();
                        }, function (err) {
                        }, function () {
                        });
                    }
                };
                AmaxCustomers.prototype.editEmailDet = function (EmailObj) {
                    //debugger;
                    var index = 0;
                    this.IsRecordEditMode = true;
                    this.BTN_PHADD = this.RES.CUSTOMER_MASTER.APP_BTN_PHEDIT;
                    this.EmailModel.Email = EmailObj.Email;
                    this.EmailModel.EmailName = EmailObj.EmailName;
                    this.EmailModel.Newslettere = EmailObj.Newslettere;
                    this.EditEmailData = {};
                    this.EditEmailData = EmailObj;
                };
                AmaxCustomers.prototype.delEmailDet = function (EmailObj) {
                    //debugger;
                    var index = 0;
                    jQuery.each(this.modelInput.CustomerEmails, function () {
                        if (this == EmailObj) {
                            return false;
                        }
                        index = index + 1;
                    });
                    this.modelInput.CustomerEmails.splice(index, 1);
                };
                AmaxCustomers.prototype.editAddressDet = function (AddressObj) {
                    //debugger;
                    var index = 0;
                    this.IsRecordEditMode = true;
                    this.BTN_PHADD = this.RES.CUSTOMER_MASTER.APP_BTN_PHEDIT;
                    // AddressObj.CityName = jQuery("#City").val();
                    this.Address.Street = AddressObj.Street;
                    this.Address.Street2 = AddressObj.Street2;
                    this.Address.CityName = AddressObj.CityName;
                    this.Address.Zip = AddressObj.Zip;
                    this.Address.CountryCode = AddressObj.CountryCode;
                    this.Address.StateId = AddressObj.StateId;
                    this.Address.AddressTypeId = AddressObj.AddressTypeId;
                    this.Address.MainAddress = AddressObj.MainAddress;
                    this.Address.ForDelivery = AddressObj.ForDelivery;
                    this.EditAddressData = {};
                    this.EditAddressData = AddressObj;
                };
                AmaxCustomers.prototype.delAddressDet = function (AddressObj) {
                    // debugger; 
                    var index = 0;
                    jQuery.each(this.modelInput.CustomerAddresses, function () {
                        if (this == AddressObj) {
                            return false;
                        }
                        index = index + 1;
                    });
                    this.modelInput.CustomerAddresses.splice(index, 1);
                };
                AmaxCustomers.prototype.editPhoneDet = function (PhoneObj) {
                    var index = 0;
                    this.BTN_PHADD = this.RES.CUSTOMER_MASTER.APP_BTN_PHEDIT;
                    var temp = PhoneObj.PhoneTypeId.split(';');
                    this.PhoneModel.PhoneTypeId = PhoneObj.PhoneType + ";" + PhoneObj.PhoneTypeId;
                    this.PhoneModel.PhoneType = PhoneObj.PhoneType;
                    this.PhoneModel.Prefix = PhoneObj.Prefix;
                    this.PhoneModel.Area = PhoneObj.Area;
                    this.PhoneModel.Phone = PhoneObj.Phone;
                    this.PhoneModel.IsSms = PhoneObj.IsSms;
                    this.PhoneModel.Comments = PhoneObj.Comments;
                    this.EditPhoneData = {};
                    this.EditPhoneData = PhoneObj;
                };
                AmaxCustomers.prototype.delPhoneDet = function (PhoneObj) {
                    var index = 0;
                    jQuery.each(this.modelInput.CustomerPhones, function () {
                        if (this == PhoneObj) {
                            return false;
                        }
                        index = index + 1;
                    });
                    this.modelInput.CustomerPhones.splice(index, 1);
                };
                AmaxCustomers.prototype.getSelectedGroups = function () {
                    this.modelInput.CustomerGroups = [];
                    var _CheckedGroups = [];
                    if (this.IsShowAll == false) {
                        amaxUtil_1.Kendo_utility.checkedNodeIds(jQuery("#groupTree").data("kendoTreeView").dataSource.view(), _CheckedGroups);
                    }
                    else {
                        amaxUtil_1.Kendo_utility.checkedNodeIds(jQuery("#groupTree1").data("kendoTreeView").dataSource.view(), _CheckedGroups);
                    }
                    for (var i = 0; i < _CheckedGroups.length; i++) {
                        var GObj = {};
                        GObj.CustomerGeneralGroupId = _CheckedGroups[i];
                        this.modelInput.CustomerGroups.push(GObj);
                    }
                };
                AmaxCustomers.prototype.More = function () {
                    // alert("call");
                    if (this.ShowMore == true) {
                        this.ShowMore = false;
                        //this.ShowMoreText = "More";
                        this.ShowMoreText = this.RES.CUSTOMER_MASTER.APP_LNK_LBL_MORE;
                    }
                    else {
                        this.ShowMore = true;
                        //this.ShowMoreText = "Less"; 
                        this.ShowMoreText = this.RES.CUSTOMER_MASTER.APP_LNK_LBL_LESS;
                    }
                };
                AmaxCustomers.prototype.bindGroupTree = function (Isshowall) {
                    var _this = this;
                    this._customerService.GetGeneralGroups(Isshowall).subscribe(function (data) {
                        //debugger;
                        //
                        //alert(Isshowall);
                        if (Isshowall == false) {
                            jQuery("#groupTree").html("Loding...");
                            var res = jQuery.parseJSON(data).Data;
                            jQuery("#groupTree").kendoTreeView({
                                loadOnDemand: true,
                                checkboxes: {
                                    checkChildren: true
                                },
                                //check: this.onGroupSelect,
                                dataSource: res
                            });
                            var grpids = "";
                            jQuery.each(_this.modelInput.CustomerGroups, function () {
                                grpids += this.CustomerGeneralGroupId + ";";
                            });
                            if (grpids.length > 0) {
                                amaxUtil_1.Kendo_utility.checkingNodeIds(jQuery("#groupTree").data("kendoTreeView").dataSource.view(), grpids.substring(0, grpids.length - 1));
                            }
                        }
                        else {
                            jQuery("#groupTree1").html("Loding...");
                            var res = jQuery.parseJSON(data).Data;
                            jQuery("#groupTree1").kendoTreeView({
                                loadOnDemand: true,
                                checkboxes: {
                                    checkChildren: true
                                },
                                //check: this.onGroupSelect,
                                dataSource: res
                            });
                            var grpids = "";
                            jQuery.each(_this.modelInput.CustomerGroups, function () {
                                grpids += this.CustomerGeneralGroupId + ";";
                            });
                            if (grpids.length > 0) {
                                amaxUtil_1.Kendo_utility.checkingNodeIds(jQuery("#groupTree1").data("kendoTreeView").dataSource.view(), grpids.substring(0, grpids.length - 1));
                            }
                        }
                        //var treeviewDataSource = jQuery("#groupTree").data("kendoTreeView").dataSource.view();
                    }, function (err) {
                    }, function () {
                    });
                };
                AmaxCustomers.prototype.GetDataForSearch = function (event) {
                    //this.SearchVal = jQuery("#Searchtxt").val();
                    //alert(event.keyCode);
                    //if (this.SearchVal != undefined && this.SearchVal != "" && this.SearchVal != null && event.keyCode == 13) {
                    //alert(this.autocompleteSelect + " " + this.autocompleteNoResults);
                    //    this.EnterCount++;
                    //    if (this.EnterCount >= 2) {
                    //        this._customerService.GetCompleteSearch(this.SearchVal).subscribe(response=> {
                    //            response = jQuery.parseJSON(response);
                    //            if (response.IsError == true) {
                    //                alert(response.ErrMsg);
                    //            }
                    //            else {
                    //                this.CustList = {};
                    //                this.CustList = response.Data;
                    //                if (response.Data != null && response.Data != undefined) {
                    //                    this.custSearchData = response.Data;
                    //                    jQuery("#CustModal").modal("show");
                    //                }
                    //            }
                    //        }, error=> {
                    //            console.log(error);
                    //        }, () => {
                    //            console.log("CallCompleted")
                    //        });
                    //        this.EnterCount = 0;
                    //    }
                    //}
                    //this.SearchVal = "";
                };
                AmaxCustomers.prototype.ngOnInit = function () {
                    var _this = this;
                    // debugger;
                    //bootbox.alert("This is the default alert!");
                    if (localStorage.getItem("lang") == "") {
                        localStorage.setItem("lang", "en");
                    }
                    if (this._resourceService.getCookie("lang") == "") {
                        this._resourceService.setCookie("lang", "en", 10);
                    }
                    this.IsCancel = false;
                    this.showhideGroups();
                    this.IsFileAstxtShow = true;
                    //this.modelInput.CustomerId = -1;
                    if (this.modelInput.CustomerId >= 0) {
                        //this.IsFileAstxtShow = false;
                        this.editCustDet(this.modelInput);
                        this.SAVE_BTN_TEXT = this.RES.CUSTOMER_MASTER.APP_BTN_UPDATE;
                        //this.ADD_NEW_CUST_TEXT = this.RES.CUSTOMER_MASTER.APP_LBL_UPDATE_CUST;
                        //this.CSSTEXT = "mdi-content-add";
                        if (this.modelInput.CustomerAddresses.length == 0) {
                            var empid = localStorage.getItem("employeeid");
                            var ccode = this._resourceService.getCookie(empid + "ccode");
                            if (ccode.length > 0)
                                ccode = ccode.substring(1, ccode.length);
                            var adid = "";
                            var comptext = "Home";
                            if (this.modelInput.Company != "" && this.modelInput.Company != undefined && this.modelInput.Company != null) {
                                comptext = "Work";
                            }
                            jQuery.each(this._AddressTypes, function () {
                                if (this.Text == comptext) {
                                    adid = this.Value;
                                    return false;
                                }
                            });
                            this.modelInput.CustomerAddresses = [{ Street: "", Street2: "", CityName: "", Zip: "", CountryCode: ccode, StateId: "", AddressTypeId: adid, ForDelivery: false, MainAddress: false, MainOrder: "MainAddr1", DelvryOrder: "Delvry1" }];
                        }
                        this.CustIdText = "( " + this.modelInput.CustomerId + " )";
                        this.IsFileAstxtShow = false;
                    }
                    this.Lang = this._resourceService.getCookie("lang");
                    if (this.Lang.length > 0) {
                        this.Lang = this.Lang.substring(1, this.Lang.length);
                    }
                    this.HideShowFileAstxt();
                    //this.RES = jQuery.parseJSON(this._customerService.GetLangRes(this.Formtype, this.Lang)).Data; //jQuery.parseJSON(localStorage.getItem("langresource"));
                    if (this.Lang == "he") {
                        this.KendoRTLCSS = "k-rtl";
                        this.CHANGEDIR = "rtlmodal";
                        this.ChangeDialog = "input_right";
                    }
                    else {
                        this.CHANGEDIR = "ltrmodal";
                        this.ChangeDialog = "input_left";
                    }
                    this._resourceService.GetLangRes(this.Formtype, this.Lang).subscribe(function (response) {
                        //debugger;
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.RES = response.Data;
                            _this.ShowMoreText = _this.RES.CUSTOMER_MASTER.APP_LNK_LBL_MORE;
                            _this.GroupText = _this.RES.CUSTOMER_MASTER.APP_LBL_SHOWGROUPS;
                            _this.SAVE_BTN_TEXT = _this.RES.CUSTOMER_MASTER.APP_BTN_SAVE;
                            _this.ADD_NEW_CUST_TEXT = _this.RES.CUSTOMER_MASTER.APP_LBL_NEW_CUST;
                            _this.FILEAS_BTN_TEXT = _this.RES.CUSTOMER_MASTER.APP_BTN_FILEAS;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //this.ShowMoreText = "More";
                    ////Cities
                    var CountryCode = this.Address.CountryCode;
                    var StateName = this.Address.StateId;
                    this._customerService.GetCities(CountryCode, StateName).subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            var typeaheadSource = [];
                            jQuery.each(response.Data, function () {
                                var newtemp = {};
                                newtemp.id = this.Value;
                                newtemp.name = this.Text;
                                typeaheadSource.push(newtemp);
                            });
                            _this._Cities = response.Data;
                            jQuery('#City').typeahead({
                                //data: this._Cities,
                                source: typeaheadSource,
                                //display: "text",
                                dataType: "JSON",
                            });
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this.languageArray = this._resourceService.GetAvailableLanguages();
                    this._customerService.GetCustomerTypes().subscribe(function (resp) {
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._CustTypes = response.Data;
                            if (_this.modelInput.CustomerType == "" || _this.modelInput.CustomerType == undefined || _this.modelInput.CustomerType == null) {
                                var CusttypeId;
                                jQuery.each(_this._CustTypes, function () {
                                    CusttypeId = this.Value;
                                    return false;
                                });
                                _this.modelInput.CustomerType = CusttypeId;
                            }
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    ////Sources
                    this._customerService.GetSources().subscribe(function (resp) {
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Sources = response.Data;
                            if (_this.modelInput.CameFromCustomer == "" || _this.modelInput.CameFromCustomer == undefined || _this.modelInput.CameFromCustomer == null) {
                                var Source;
                                jQuery.each(_this._Sources, function () {
                                    Source = this.Value;
                                    return false;
                                });
                                _this.modelInput.CameFromCustomer = Source;
                            }
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //GetEmployees
                    this._customerService.GetEmployees().subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Employees = response.Data;
                            if (_this.modelInput.employeeid == "" || _this.modelInput.employeeid == undefined || _this.modelInput.employeeid == null) {
                                var empid;
                                jQuery.each(_this._Employees, function () {
                                    empid = this.Value;
                                    return false;
                                });
                                _this.modelInput.employeeid = empid;
                            }
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //GetSuffixes
                    this._customerService.GetSuffixes().subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Suffixes = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //GetPhoneTypes
                    this._customerService.GetPhoneTypes().subscribe(function (response) {
                        // debugger;
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._PhoneTypes = response.Data;
                            var phid = "";
                            jQuery.each(_this._PhoneTypes, function () {
                                if (this.Text == "CellPhone") {
                                    phid = this.Value;
                                    return false;
                                }
                            });
                            _this.modelInput.CustomerPhones[0].PhoneTypeId = phid;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    var epublish = 0;
                    if (this.modelInput.CustomerPhones.length == 0) {
                        var phid = "";
                        jQuery.each(this._PhoneTypes, function () {
                            if (this.Text == "CellPhone") {
                                phid = this.Value;
                                epublish = 1;
                                return false;
                            }
                        });
                        this.modelInput.CustomerPhones = [{ PhoneTypeId: phid, Prefix: "", Area: "", Phone: "", IsSms: epublish, Comments: "", phpublish: epublish, SMSOrder: "SMS1", PublishOrder: "Pub1" }];
                    }
                    if (this.modelInput.CustomerEmails.length == 0) {
                        this.modelInput.CustomerEmails = [{ Email: "", EmailName: this.modelInput.FileAs, Newslettere: false, publish: epublish, NewsOrder: "News1", EPublishOrder: "EPub1" }];
                    }
                    //GetAddressTypes
                    this._customerService.GetAddressTypes().subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._AddressTypes = response.Data;
                            // debugger;
                            var adid = "";
                            jQuery.each(_this._AddressTypes, function () {
                                if (this.Text == "Home") {
                                    adid = this.Value;
                                    return false;
                                }
                            });
                            _this.modelInput.CustomerAddresses[0].AddressTypeId = adid;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //Groups
                    this._customerService.GetGroups().subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Groups = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    ////Countries
                    this._customerService.GetCountries().subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._Countries = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    ////States
                    var CountryCode = this.Address.CountryCode;
                    this._customerService.GetStates(CountryCode).subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg, className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._States = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //Tree Group
                    //this.bindGroupTree(this.IsShowAll);
                    this._customerService.GetGeneralGroups(this.IsShowAll).subscribe(function (data) {
                        // debugger;
                        if (_this.IsShowAll == false) {
                            jQuery("#groupTree").html("Loding...");
                            var res = jQuery.parseJSON(data).Data;
                            jQuery("#groupTree").kendoTreeView({
                                loadOnDemand: true,
                                checkboxes: {
                                    checkChildren: true
                                },
                                //check: this.onGroupSelect,
                                dataSource: res
                            });
                            var grpids = "";
                            jQuery.each(_this.modelInput.CustomerGroups, function () {
                                grpids += this.CustomerGeneralGroupId + ";";
                            });
                            if (grpids.length > 0) {
                                amaxUtil_1.Kendo_utility.checkingNodeIds(jQuery("#groupTree").data("kendoTreeView").dataSource.view(), grpids.substring(0, grpids.length - 1));
                            }
                        }
                        else {
                            jQuery("#groupTree1").html("Loding...");
                            var res = jQuery.parseJSON(data).Data;
                            jQuery("#groupTree1").kendoTreeView({
                                loadOnDemand: true,
                                checkboxes: {
                                    checkChildren: true
                                },
                                //check: this.onGroupSelect,
                                dataSource: res
                            });
                            var grpids = "";
                            jQuery.each(_this.modelInput.CustomerGroups, function () {
                                grpids += this.CustomerGeneralGroupId + ";";
                            });
                            if (grpids.length > 0) {
                                amaxUtil_1.Kendo_utility.checkingNodeIds(jQuery("#groupTree1").data("kendoTreeView").dataSource.view(), grpids.substring(0, grpids.length - 1));
                            }
                        }
                    }, function (err) {
                    }, function () {
                    });
                    //alert(moment().format('D MMM YYYY'));       
                    // this.baseUrl + "Dropdown/BindAutoCompleteSrch"
                    var SrchData = null;
                    //alert('Hi');
                    jQuery("#EmailTable tbody tr td a[name=delEbtn]").not(":last").hide();
                    jQuery("#EmailTable tbody tr a[name=addEbtn]").not(":last").show();
                    //$('.modal').modal();
                };
                AmaxCustomers.$inject = ['$scope', '$location', '$anchorScroll'];
                AmaxCustomers = __decorate([
                    core_1.Component({
                        templateUrl: './app/amax/Customer/templates/customer.html',
                        directives: [common_1.NgSwitch, common_1.NgSwitchWhen, common_1.NgSwitchDefault, AUTOCOMPLETE_DIRECTIVES, common_1.CORE_DIRECTIVES, common_1.FORM_DIRECTIVES, basicComponents_1.AmaxDate],
                        providers: [CustomerService_1.CustomerService, ResourceService_1.ResourceService]
                    }), 
                    __metadata('design:paramtypes', [ResourceService_1.ResourceService, CustomerService_1.CustomerService, router_1.RouteParams])
                ], AmaxCustomers);
                return AmaxCustomers;
            }());
            exports_1("AmaxCustomers", AmaxCustomers);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFtYXgvQ3VzdG9tZXJOb3Rlcy9DdXN0b21lck5vdGVzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7UUFXYSx1QkFBdUI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7WUFBdkIscUNBQUEsdUJBQXVCLEdBQUcsQ0FBQyxxQ0FBWSxFQUFFLDhDQUFxQixDQUFDLENBQUEsQ0FBQztZQVc3RTtnQkFpRkksdUJBQW9CLGdCQUFpQyxFQUFVLGdCQUFpQyxFQUFVLFlBQXlCO29CQUEvRyxxQkFBZ0IsR0FBaEIsZ0JBQWdCLENBQWlCO29CQUFVLHFCQUFnQixHQUFoQixnQkFBZ0IsQ0FBaUI7b0JBQVUsaUJBQVksR0FBWixZQUFZLENBQWE7b0JBaEZuSSxlQUFVLEdBQUcsRUFBRSxDQUFDO29CQUNoQixtQkFBYyxHQUFHLEVBQUUsQ0FBQztvQkFDcEIsbUJBQWMsR0FBVyxFQUFFLENBQUM7b0JBQzVCLFFBQUcsR0FBVyxFQUFFLENBQUM7b0JBQ2pCLG1CQUFjLEdBQVcsRUFBRSxDQUFDO29CQUM1QixrQkFBYSxHQUFXLEVBQUUsQ0FBQztvQkFDM0IsYUFBUSxHQUFVLGlCQUFpQixDQUFDO29CQUNwQyxTQUFJLEdBQVMsRUFBRSxDQUFDO29CQUNoQix1QkFBdUI7b0JBQ3ZCLGFBQVEsR0FBWSxLQUFLLENBQUM7b0JBQzFCLHFCQUFnQixHQUFZLEtBQUssQ0FBQztvQkFDbEMsaUJBQVksR0FBVyxNQUFNLENBQUM7b0JBRTlCLGVBQVUsR0FBWSxLQUFLLENBQUM7b0JBQzVCLFlBQU8sR0FBWSxLQUFLLENBQUM7b0JBQ3pCLGVBQVUsR0FBWSxJQUFJLENBQUM7b0JBQzNCLGNBQVMsR0FBUyxhQUFhLENBQUM7b0JBQ2hDLFFBQUcsR0FBVyxFQUFFLENBQUM7b0JBQ2pCLGFBQVEsR0FBVyxjQUFjLENBQUM7b0JBQ2xDLGlCQUFZLEdBQVcsRUFBRSxDQUFDO29CQUMxQixvQkFBZSxHQUFXLEVBQUUsQ0FBQztvQkFDN0Isc0JBQWlCLEdBQVcsRUFBRSxDQUFDO29CQUMvQixrQkFBYSxHQUFHLEVBQUUsQ0FBQztvQkFFbkIsWUFBTyxHQUFXLEVBQUUsQ0FBQztvQkFDckIsZUFBVSxHQUFXLEVBQUUsQ0FBQztvQkFDeEIsZUFBVSxHQUFXLEVBQUUsQ0FBQztvQkFDeEIsY0FBUyxHQUFZLEtBQUssQ0FBQztvQkFDM0IsYUFBUSxHQUFXLEVBQUUsQ0FBQztvQkFDdEIsa0JBQWEsR0FBVyxFQUFFLENBQUM7b0JBRTNCLGNBQVMsR0FBVyxFQUFFLENBQUM7b0JBQ3ZCLGtCQUFhLEdBQVcsRUFBRSxDQUFDO29CQUMzQixvQkFBZSxHQUFXLEVBQUUsQ0FBQztvQkFDN0Isa0JBQWEsR0FBVyxFQUFFLENBQUM7b0JBSzNCLG9CQUFlLEdBQVksS0FBSyxDQUFDO29CQUNqQyxvQkFBZSxHQUFXLEVBQUUsQ0FBQztvQkFDN0IsaUJBQVksR0FBVyxFQUFFLENBQUM7b0JBQzFCLGFBQVEsR0FBWSxLQUFLLENBQUM7b0JBQzFCLGNBQVMsR0FBVyxFQUFFLENBQUM7b0JBQ3ZCLGVBQVUsR0FBVyxDQUFDLENBQUM7b0JBRXZCLGVBQVUsR0FBVyxFQUFFLENBQUM7b0JBRXhCLGVBQVUsR0FBVyxFQUFFLENBQUM7b0JBQ3hCLFlBQU8sR0FBVyxDQUFDLENBQUM7b0JBQ3BCLGdCQUFXLEdBQVcsRUFBRSxDQUFDO29CQUN6QixjQUFTLEdBQVcsRUFBRSxDQUFDO29CQUN2QixpQkFBWSxHQUFXLEVBQUUsQ0FBQztvQkFDMUIsZ0NBQWdDO29CQUVoQyxxQkFBcUI7b0JBQ3JCLDZCQUE2QjtvQkFDN0IsaUNBQWlDO29CQUVqQyxlQUFVLEdBQUcsRUFBRSxDQUFDO29CQUNoQixhQUFRLEdBQUcsRUFBRSxDQUFDO29CQUNkLGVBQVUsR0FBRyxFQUFFLENBQUM7b0JBQ2hCLGNBQVMsR0FBRyxFQUFFLENBQUM7b0JBQ2YsZ0JBQVcsR0FBRyxFQUFFLENBQUM7b0JBQ2pCLGtCQUFhLEdBQUcsRUFBRSxDQUFDO29CQUNuQixZQUFPLEdBQUcsRUFBRSxDQUFDO29CQUNiLGVBQVUsR0FBRyxFQUFFLENBQUM7b0JBQ2hCLFlBQU8sR0FBRyxFQUFFLENBQUM7b0JBQ2IsWUFBTyxHQUFHLEVBQUUsQ0FBQztvQkFFTCxnQkFBVyxHQUFXLEVBQUUsQ0FBQztvQkFDekIscUJBQWdCLEdBQVcsRUFBRSxDQUFDO29CQUM5Qix3QkFBbUIsR0FBWSxLQUFLLENBQUM7b0JBQ3JDLDBCQUFxQixHQUFZLEtBQUssQ0FBQztvQkFDdkMsdUJBQWtCLEdBQVksS0FBSyxDQUFDO29CQTRFcEMsOEJBQXlCLEdBQVMsRUFBRSxDQUFDO29CQXBFekMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEdBQUcsRUFBRSxDQUFDO29CQUMvQixJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixHQUFHLEVBQUUsQ0FBQztvQkFDdkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDO29CQUNwQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxFQUFFLENBQUM7b0JBQ3BDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLEVBQUUsQ0FBQztvQkFDcEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEdBQUMsRUFBRSxDQUFDO29CQUM1QixJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7b0JBQzFCLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztvQkFDaEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEdBQUcsRUFBRSxDQUFDO29CQUNsQyxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixHQUFHLEVBQUUsQ0FBQztvQkFDdEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEdBQUcsRUFBRSxDQUFDO29CQUM3QixJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxHQUFHLENBQUM7b0JBQzdCLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxHQUFHLEVBQUUsQ0FBQztvQkFDakMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLEdBQUcsRUFBRSxDQUFDO29CQUM5QixJQUFJLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQztvQkFDdkIsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUM7b0JBQzNELElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsYUFBYSxDQUFDO29CQUN4RCxJQUFJLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsZ0JBQWdCLENBQUM7b0JBQ25FLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLENBQUMsRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFFLFNBQVMsRUFBRSxFQUFFLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFFLFNBQVMsRUFBRSxPQUFPLEVBQUUsYUFBYSxFQUFDLE9BQU8sRUFBRSxDQUFDLENBQUE7b0JBQ3pJLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLENBQUMsRUFBRSxXQUFXLEVBQUUsRUFBRSxFQUFFLE1BQU0sRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUUsUUFBUSxFQUFFLEVBQUUsRUFBRSxhQUFhLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxDQUFDLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBQyxZQUFZLEVBQUUsTUFBTSxFQUFDLENBQUMsQ0FBQTtvQkFDMUwsWUFBWTtvQkFDWCxJQUFJLEtBQUssR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDO29CQUUvQyxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxPQUFPLENBQUMsQ0FBQztvQkFDN0QsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7d0JBQ2pCLEtBQUssR0FBRyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBRTdDLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLEdBQUcsQ0FBQzs0QkFDakMsTUFBTSxFQUFFLEVBQUUsRUFBRSxPQUFPLEVBQUUsRUFBRSxFQUFFLFFBQVEsRUFBRSxFQUFFLEVBQUUsR0FBRyxFQUFFLEVBQUUsRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLE9BQU8sRUFBRSxFQUFFLEVBQUUsYUFBYSxFQUFFLEVBQUU7NEJBQ2xHLFdBQVcsRUFBRSxJQUFJLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUUsV0FBVyxFQUFFLFdBQVcsRUFBRSxTQUFTO3lCQUN2RixDQUFDLENBQUE7b0JBS0YsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsTUFBTSxDQUFDLENBQUM7b0JBQy9ELEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFFdEIsUUFBUSxHQUFHLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDdEQsQ0FBQztvQkFDRCxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksR0FBRyxRQUFRLENBQUM7b0JBR3hDLElBQUksR0FBRyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQyxDQUFDO29CQUN6RCxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQzt3QkFDZixHQUFHLEdBQUcsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUN2QyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBRyxHQUFHLENBQUM7b0JBRWpDLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQyxDQUFDO29CQUM1RCxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQzt3QkFDbEIsTUFBTSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDaEQsSUFBSSxDQUFDLENBQUM7b0JBRU4sQ0FBQztvQkFDRCxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixHQUFHLE1BQU0sQ0FBQztvQkFDMUMsSUFBSSxDQUFDLE9BQU8sR0FBRyxpQkFBaUIsQ0FBQztvQkFDakMsSUFBSSxDQUFDLFlBQVksR0FBRyxvQkFBb0IsQ0FBQztvQkFDekMsSUFBSSxDQUFDLGVBQWUsR0FBRyxLQUFLLENBQUM7b0JBQzdCLFlBQVksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7b0JBQy9CLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLFlBQVksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO29CQUNwRCxJQUFJLENBQUMsVUFBVSxHQUFHLGdCQUFnQixDQUFDLE1BQU0sQ0FBQztvQkFDMUMsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDO29CQUV0Qyx5REFBeUQ7b0JBQ3pELDZCQUE2QjtnQkFFakMsQ0FBQztnQkF4RU8seUNBQWlCLEdBQXpCO29CQUVJLE1BQU0sQ0FBQyxJQUFJLENBQUM7Z0JBQ2hCLENBQUM7Z0JBeUVELDJDQUFtQixHQUFuQixVQUFvQixHQUFHO29CQUNuQixPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUNqQixJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsR0FBRyxHQUFHLENBQUM7b0JBQ2pDLG9DQUFvQztvQkFDbkMsdUJBQXVCO2dCQUMzQixDQUFDO2dCQUVNLG9DQUFZLEdBQXBCLFVBQXFCLE9BQVk7b0JBQWpDLGlCQXNERTtvQkFwREUsSUFBSSxPQUFPLEdBQUcsT0FBTyxDQUFDLGdCQUFnQixDQUFDO29CQUV4QyxrRUFBa0U7b0JBRzlELFlBQVk7b0JBQ2YsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLHlCQUF5QixJQUFJLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUM7d0JBQ3pELGlDQUFpQzt3QkFDakMsTUFBTSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUM7b0JBQzlCLENBQUM7b0JBQ0wsSUFBSSxDQUFDLENBQUM7d0JBQ0YsMkVBQTJFO3dCQUN2RSxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzs0QkFDakMsSUFBSSxDQUFDLHlCQUF5QixHQUFHLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQzs0QkFDNUQseUNBQXlDOzRCQUN2QyxxQkFBcUI7NEJBQ2pCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO2dDQUNoRSxZQUFZO2dDQUNYLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dDQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7b0NBQzNCLHlCQUF5QjtvQ0FDekIsT0FBTyxDQUFDLEtBQUssQ0FBQyxFQUFDLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTt3Q0FDdEMsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO3dDQUN6QixPQUFPLEVBQUU7NENBQ0wsRUFBRSxFQUFFO2dEQUNBLGNBQWM7Z0RBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTOzZDQUM1Qjt5Q0FDSjtxQ0FDSixDQUFDLENBQUM7Z0NBQ1AsQ0FBQztnQ0FDRCxJQUFJLENBQUMsQ0FBQztvQ0FDRixPQUFPLENBQUMsWUFBWSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7Z0NBR3pDLENBQUM7NEJBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSztnQ0FDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDOzRCQUN2QixDQUFDLEVBQUU7Z0NBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTs0QkFDaEMsQ0FBQyxDQUFDLENBQUM7NEJBQ1IsV0FBVzs0QkFFVixJQUFJLENBQUMsYUFBYSxHQUFHLE9BQU8sQ0FBQyxZQUFZLENBQUM7d0JBQzlDLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsSUFBSSxDQUFDLGFBQWEsR0FBRyxFQUFFLENBQUM7d0JBQzVCLENBQUM7d0JBQ0QsTUFBTSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUM7b0JBQzlCLENBQUM7Z0JBR1IsQ0FBQztnQkFFTyxpREFBeUIsR0FBakMsVUFBa0MsQ0FBVTtvQkFDeEMsSUFBSSxDQUFDLG1CQUFtQixHQUFHLENBQUMsQ0FBQztnQkFDakMsQ0FBQztnQkFFTyxtREFBMkIsR0FBbkMsVUFBb0MsQ0FBVTtvQkFDMUMsSUFBSSxDQUFDLGtCQUFrQixHQUFHLEtBQUssQ0FBQztvQkFDaEMsSUFBSSxDQUFDLHFCQUFxQixHQUFHLENBQUMsQ0FBQztnQkFDbkMsQ0FBQztnQkFDTyw0Q0FBb0IsR0FBNUIsVUFBNkIsQ0FBTTtvQkFBbkMsaUJBa0ZDO29CQWpGRyxJQUFJLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDO29CQUMvQixPQUFPLENBQUMsR0FBRyxDQUFDLHFCQUFtQixDQUFDLENBQUMsSUFBTSxDQUFDLENBQUM7b0JBQ3pDLElBQUksUUFBUSxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUNqQyxXQUFXO29CQUNYLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksU0FBUyxJQUFJLENBQUMsQ0FBQyxJQUFJLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzt3QkFDeEQscUJBQXFCO3dCQUNyQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsa0JBQWtCLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTs0QkFDM0UsV0FBVzs0QkFDWCxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzs0QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO2dDQUMzQix5QkFBeUI7Z0NBQ3pCLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBQyxPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07b0NBQ25DLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtvQ0FDNUIsT0FBTyxFQUFFO3dDQUNMLEVBQUUsRUFBRTs0Q0FDQSxjQUFjOzRDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUzt5Q0FDNUI7cUNBQ0o7aUNBQ0osQ0FBQyxDQUFDOzRCQUNQLENBQUM7NEJBQ0QsSUFBSSxDQUFDLENBQUM7Z0NBQ0YsS0FBSSxDQUFDLFVBQVUsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO2dDQUNqQyxvQ0FBb0M7Z0NBQ25DLEtBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsY0FBYyxDQUFDO2dDQUM3RCxLQUFJLENBQUMsaUJBQWlCLEdBQUcsS0FBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsbUJBQW1CLENBQUM7Z0NBQ3RFLEtBQUksQ0FBQyxPQUFPLEdBQUcsb0JBQW9CLENBQUM7Z0NBQ3BDLEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO29DQUM3QyxLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxDQUFDLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsS0FBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUE7Z0NBQzNHLENBQUM7Z0NBQ0QsRUFBRSxDQUFDLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7b0NBQzdDLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQztvQ0FDZCxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUksQ0FBQyxXQUFXLEVBQUU7d0NBQzFCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksV0FBVyxDQUFDLENBQUMsQ0FBQzs0Q0FFM0IsSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7NENBQ2xCLE1BQU0sQ0FBQyxLQUFLLENBQUM7d0NBQ2pCLENBQUM7b0NBQ0wsQ0FBQyxDQUFDLENBQUM7b0NBRUgsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsQ0FBQyxFQUFFLFdBQVcsRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLEVBQUUsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRSxRQUFRLEVBQUUsRUFBRSxFQUFFLFNBQVMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2dDQUdwSSxDQUFDO2dDQUNELEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7b0NBQ2hELElBQUksS0FBSyxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUM7b0NBRS9DLElBQUksS0FBSyxHQUFHLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLE9BQU8sQ0FBQyxDQUFDO29DQUM3RCxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQzt3Q0FDakIsS0FBSyxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQztvQ0FDN0MsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDO29DQUNkLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQztvQ0FDdEIsRUFBRSxDQUFDLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLElBQUksRUFBRSxJQUFJLEtBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxJQUFJLFNBQVMsSUFBSSxLQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO3dDQUMzRyxRQUFRLEdBQUcsTUFBTSxDQUFDO29DQUN0QixDQUFDO29DQUNELE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLGFBQWEsRUFBRTt3Q0FDNUIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxRQUFRLENBQUMsQ0FBQyxDQUFDOzRDQUN4QixJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQzs0Q0FDbEIsTUFBTSxDQUFDLEtBQUssQ0FBQzt3Q0FDakIsQ0FBQztvQ0FDTCxDQUFDLENBQUMsQ0FBQztvQ0FFSCxLQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixHQUFHLENBQUMsRUFBRSxNQUFNLEVBQUUsRUFBRSxFQUFFLE9BQU8sRUFBRSxFQUFFLEVBQUUsUUFBUSxFQUFFLEVBQUUsRUFBRSxHQUFHLEVBQUUsRUFBRSxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsT0FBTyxFQUFFLEVBQUUsRUFBRSxhQUFhLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUM7Z0NBQzNMLENBQUM7Z0NBRUQsS0FBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLEdBQUcsS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO2dDQUMzRCxLQUFJLENBQUMsZUFBZSxHQUFHLEtBQUssQ0FBQztnQ0FDN0IsdUJBQXVCO2dDQUN2QiwyQkFBMkI7Z0NBQzNCLEtBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztnQ0FDdkIsS0FBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7Z0NBQ3RCLG1CQUFtQjtnQ0FDbkIsa0JBQWtCO2dDQUNsQixLQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxDQUFDOzRCQUM3QixDQUFDO3dCQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7NEJBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQzt3QkFDdkIsQ0FBQyxFQUFFOzRCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7d0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUNQLENBQUM7Z0JBQ0wsQ0FBQztnQkFDRCxzQ0FBYyxHQUFkO29CQUNJLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUM3RyxJQUFJLE1BQU0sR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQzt3QkFDeEMsRUFBRSxDQUFDLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs0QkFDZixJQUFJLElBQUksR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDOzRCQUM5QyxRQUFRLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxVQUFVLEdBQUcsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDO3dCQUNsRSxDQUFDO29CQUNMLENBQUM7Z0JBQ0wsQ0FBQztnQkFDRCw0Q0FBb0IsR0FBcEI7b0JBQUEsaUJBeUZDO29CQXhGRyxJQUFJLENBQUMsWUFBWSxHQUFHLFVBQVUsQ0FBQztvQkFDL0IsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGlCQUFpQixFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFDeEQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDdEIsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBR3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQ3RELE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCLEVBQUUsRUFBQyxDQUFDLENBQUM7d0JBQ2xCLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsV0FBVzs0QkFDWCxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxJQUFJLFNBQVMsSUFBSSxRQUFRLENBQUMsSUFBSSxJQUFJLElBQUksSUFBSSxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUNuRixJQUFJLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQztnQ0FDaEIsRUFBRSxDQUFDLENBQUMsS0FBSSxDQUFDLGNBQWMsSUFBSSxTQUFTLElBQUksS0FBSSxDQUFDLGNBQWMsQ0FBQyxVQUFVLElBQUksU0FBUyxJQUFJLEtBQUksQ0FBQyxjQUFjLENBQUMsVUFBVSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7b0NBQ3pILE1BQU0sR0FBRyxLQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQTtnQ0FDM0MsQ0FBQztnQ0FDRCxFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsVUFBVSxJQUFJLFNBQVMsSUFBSSxLQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxTQUFTLElBQUksS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztvQ0FDN0csTUFBTSxHQUFHLEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFBO2dDQUN2QyxDQUFDO2dDQUNELEVBQUUsQ0FBQyxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7b0NBQ2YsUUFBUSxDQUFDLFFBQVEsR0FBRyxLQUFJLENBQUMsVUFBVSxHQUFHLGVBQWUsR0FBRyxNQUFNLEdBQUcsR0FBRyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO2dDQUNsRyxDQUFDO2dDQUNELElBQUksQ0FBQyxDQUFDO29DQUVGLE9BQU8sQ0FBQyxLQUFLLENBQUM7d0NBQ1YsT0FBTyxFQUFFLGtGQUFrRjt3Q0FDM0YsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO3dDQUM1QixPQUFPLEVBQUU7NENBQ0wsRUFBRSxFQUFFO2dEQUNBLGNBQWM7Z0RBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTOzZDQUM1Qjt5Q0FFSjtxQ0FDSixDQUFDLENBQUM7Z0NBQ1AsQ0FBQzs0QkFDTCxDQUFDOzRCQUNELElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxJQUFJLFNBQVMsSUFBSSxRQUFRLENBQUMsSUFBSSxJQUFJLElBQUksSUFBSSxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUN2RixXQUFXO2dDQUNYLElBQUksTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDO2dDQUNoQixFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsY0FBYyxJQUFJLFNBQVMsSUFBSSxLQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsSUFBSSxTQUFTLElBQUksS0FBSSxDQUFDLGNBQWMsQ0FBQyxVQUFVLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztvQ0FDekgsTUFBTSxHQUFHLEtBQUksQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFBO2dDQUMzQyxDQUFDO2dDQUNELEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxVQUFVLElBQUksU0FBUyxJQUFJLEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLFNBQVMsSUFBSSxLQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO29DQUM3RyxNQUFNLEdBQUcsS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUE7Z0NBQ3ZDLENBQUM7Z0NBQ0QsRUFBRSxDQUFDLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQ0FDZixRQUFRLENBQUMsUUFBUSxHQUFHLEtBQUksQ0FBQyxVQUFVLEdBQUcsaUJBQWlCLEdBQUcsTUFBTSxDQUFDO2dDQUNyRSxDQUFDO2dDQUNELElBQUksQ0FBQyxDQUFDO29DQUNGLE9BQU8sQ0FBQyxLQUFLLENBQUM7d0NBQ1YsT0FBTyxFQUFFLGtGQUFrRjt3Q0FDM0YsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO3dDQUM1QixPQUFPLEVBQUU7NENBQ0wsRUFBRSxFQUFFO2dEQUNBLGNBQWM7Z0RBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTOzZDQUM1Qjt5Q0FDSjtxQ0FDSixDQUFDLENBQUM7Z0NBQ1AsQ0FBQzs0QkFFTCxDQUFDOzRCQUNELElBQUksQ0FBQyxDQUFDO2dDQUNGLE9BQU8sQ0FBQyxLQUFLLENBQUM7b0NBQ1YsT0FBTyxFQUFFLEtBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLG9CQUFvQjtvQ0FDdEQsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO29DQUM1QixPQUFPLEVBQUU7d0NBQ0wsRUFBRSxFQUFFOzRDQUNBLGNBQWM7NENBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3lDQUM1QixFQUFDO2lDQUNULENBQUMsQ0FBQzs0QkFDUCxDQUFDO3dCQUNMLENBQUM7d0JBQ0QsS0FBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7d0JBQ3BCLEtBQUksQ0FBQyxHQUFHLEdBQUcsUUFBUSxDQUFDLE1BQU0sQ0FBQztvQkFDL0IsQ0FBQyxFQUNHLFVBQUEsS0FBSyxJQUFHLE9BQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBbEIsQ0FBa0IsRUFDMUIsY0FBTSxPQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsc0JBQXNCLENBQUMsRUFBbkMsQ0FBbUMsQ0FDNUMsQ0FBQztvQkFDRixJQUFJLENBQUMsWUFBWSxHQUFHLEVBQUUsQ0FBQztnQkFDM0IsQ0FBQztnQkFDRCxpQ0FBUyxHQUFUO29CQUNJLE9BQU8sQ0FBQyxLQUFLLENBQUM7d0JBQ1YsT0FBTyxFQUFFLGlCQUFpQixHQUFHLElBQUksQ0FBQyxXQUFXLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxZQUFZO3dCQUMzRSxPQUFPLEVBQUU7NEJBQ0wsRUFBRSxFQUFFO2dDQUNBLGNBQWM7Z0NBQ2QsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTOzZCQUM1Qjt5QkFDSjtxQkFDSixDQUFDLENBQUM7b0JBQ0gsWUFBWSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztnQkFDbkMsQ0FBQztnQkFDRCxzQ0FBYyxHQUFkO29CQUFBLGlCQW9IQztvQkFuSEcsUUFBUSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsVUFBVSxHQUFHLGlCQUFpQixDQUFDO29CQUN4RCxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQztvQkFDNUIsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7b0JBRXJCLElBQUksS0FBSyxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUM7b0JBQy9DLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxFQUFFLENBQUM7b0JBRTNCLElBQUksQ0FBQyxVQUFVLEdBQUcsRUFBRSxDQUFDO29CQUNyQixJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsR0FBRyxFQUFFLENBQUM7b0JBQy9CLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLENBQUMsQ0FBQyxDQUFDO29CQUNoQyxJQUFJLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztvQkFDckIsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7b0JBQ3pCLElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLE1BQU0sQ0FBQyxDQUFDO29CQUMvRCxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQzt3QkFDcEIsUUFBUSxHQUFHLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDdEQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEdBQUcsUUFBUSxDQUFDO29CQUN4QyxJQUFJLEdBQUcsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUMsQ0FBQztvQkFDekQsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7d0JBQ2YsR0FBRyxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDdkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsR0FBRyxDQUFDO29CQUNqQyxJQUFJLE1BQU0sR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUMsQ0FBQztvQkFDNUQsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7d0JBQ2xCLE1BQU0sR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQ2hELElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLEdBQUcsTUFBTSxDQUFDO29CQUUxQyxJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQztvQkFDdEIsOEJBQThCO29CQUM5QixJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGdCQUFnQixDQUFDO29CQUM5RCxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLFlBQVksQ0FBQztvQkFDM0QsSUFBSSxDQUFDLE9BQU8sR0FBRyxpQkFBaUIsQ0FBQztvQkFDakMsSUFBSSxDQUFDLGlCQUFpQixHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGdCQUFnQixDQUFDO29CQUNuRSxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztvQkFDdkIsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO29CQUN0QiwrREFBK0Q7b0JBSS9ELElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQztvQkFDZCxJQUFJLEdBQUcsR0FBRyxDQUFDLENBQUM7b0JBQ1osSUFBSSxPQUFPLEdBQUcsQ0FBQyxDQUFDO29CQUNoQixJQUFJLFFBQVEsR0FBRyxDQUFDLENBQUM7b0JBQ2pCLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRTt3QkFDMUIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxXQUFXLENBQUMsQ0FBQyxDQUFDOzRCQUUzQixJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQzs0QkFDbEIsR0FBRyxHQUFHLENBQUMsQ0FBQzs0QkFDUixPQUFPLEdBQUcsQ0FBQyxDQUFDOzRCQUNaLFFBQVEsR0FBRyxDQUFDLENBQUM7NEJBQ2IsTUFBTSxDQUFDLEtBQUssQ0FBQzt3QkFDakIsQ0FBQztvQkFDTCxDQUFDLENBQUMsQ0FBQztvQkFFSCxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxDQUFDLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFLFFBQVEsRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFFLE9BQU8sRUFBRSxDQUFDLENBQUE7b0JBQ3ZJLFdBQVc7b0JBRVgsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsQ0FBQyxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFBO29CQUN0RyxJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxPQUFPLENBQUMsQ0FBQztvQkFDakUsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7d0JBQ3JCLFNBQVMsR0FBRyxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBRXpELElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQztvQkFDZCxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUU7d0JBQzVCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksTUFBTSxDQUFDLENBQUMsQ0FBQzs0QkFFdEIsSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7NEJBQ2xCLE1BQU0sQ0FBQyxLQUFLLENBQUM7d0JBQ2pCLENBQUM7b0JBRUwsQ0FBQyxDQUFDLENBQUM7b0JBR0gsSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsR0FBRyxDQUFDLEVBQUUsTUFBTSxFQUFFLEVBQUUsRUFBRSxPQUFPLEVBQUUsRUFBRSxFQUFFLFFBQVEsRUFBRSxFQUFFLEVBQUUsR0FBRyxFQUFFLEVBQUUsRUFBRSxXQUFXLEVBQUUsU0FBUyxFQUFFLE9BQU8sRUFBRSxFQUFFLEVBQUUsYUFBYSxFQUFFLElBQUksRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFBO29CQUMxTCxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxFQUFFLENBQUM7b0JBQ3BDLElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxHQUFHLEVBQUUsQ0FBQztvQkFDOUIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLEdBQUcsRUFBRSxDQUFDO29CQUMxQixJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7b0JBQzdCLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxHQUFHLEdBQUcsQ0FBQztvQkFDN0IsSUFBSSxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7b0JBQ3JCLElBQUksQ0FBQyxHQUFHLEdBQUcsRUFBRSxDQUFDO29CQUNkLElBQUksQ0FBQyxTQUFTLEdBQUcsS0FBSyxDQUFDO29CQUN2QixJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFNBQVMsQ0FDNUQsVUFBQyxJQUFJO3dCQUNELFlBQVk7d0JBQ1osRUFBRSxDQUFDLENBQUMsS0FBSSxDQUFDLFNBQVMsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDOzRCQUMxQixNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDOzRCQUN2QyxJQUFJLEdBQUcsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQTs0QkFDckMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLGFBQWEsQ0FBQztnQ0FDL0IsWUFBWSxFQUFFLElBQUk7Z0NBQ2xCLFVBQVUsRUFBRTtvQ0FDUixhQUFhLEVBQUUsSUFBSTtpQ0FDdEI7Z0NBQ0QsNEJBQTRCO2dDQUM1QixVQUFVLEVBQUUsR0FBRzs2QkFDbEIsQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQzs0QkFDeEMsSUFBSSxHQUFHLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUE7NEJBQ3JDLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQyxhQUFhLENBQUM7Z0NBQ2hDLFlBQVksRUFBRSxJQUFJO2dDQUNsQixVQUFVLEVBQUU7b0NBQ1IsYUFBYSxFQUFFLElBQUk7aUNBQ3RCO2dDQUNELDRCQUE0QjtnQ0FDNUIsVUFBVSxFQUFFLEdBQUc7NkJBQ2xCLENBQUMsQ0FBQzt3QkFDUCxDQUFDO29CQUNMLENBQUMsRUFDRCxVQUFDLEdBQUc7b0JBRUosQ0FBQyxFQUNEO29CQUVBLENBQUMsQ0FDSixDQUFDO2dCQUNOLENBQUM7Z0JBQ0QsdUNBQWUsR0FBZjtvQkFDSSxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQztvQkFDNUIsSUFBSSxDQUFDLGVBQWUsR0FBRyxLQUFLLENBQUM7b0JBQzdCLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO29CQUNyQixNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQzVCLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztvQkFDNUIsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxjQUFjLENBQUM7b0JBQy9ELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxJQUFJLElBQUksUUFBUSxDQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLEdBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUM3SCxNQUFNLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQzt3QkFDaEMsSUFBSSxDQUFDLFlBQVksR0FBRyxvQkFBb0IsQ0FBQzt3QkFDekMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ3RDLENBQUM7b0JBQ0QsSUFBSSxDQUFDLENBQUM7d0JBQ0YsTUFBTSxDQUFDLGdCQUFnQixDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7d0JBQ2hDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO29CQUN0QyxDQUFDO2dCQUNMLENBQUM7Z0JBRUQseUNBQWlCLEdBQWpCO29CQUFBLGlCQW9GQztvQkFsRkcsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDO3dCQUNoQyxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQzt3QkFDNUIsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO3dCQUM1QixNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7d0JBQzVCLElBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO3dCQUN0QixJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGtCQUFrQixDQUFDO3dCQUNwRSxxQ0FBcUM7d0JBQ3BDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxJQUFJLElBQUksUUFBUSxDQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLEdBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOzRCQUM3SCxNQUFNLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQzs0QkFDaEMsSUFBSSxDQUFDLFlBQVksR0FBRyxrQkFBa0IsQ0FBQzs0QkFDdkMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7d0JBQ3RDLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsTUFBTSxDQUFDLGdCQUFnQixDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7NEJBQ2hDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO3dCQUN0QyxDQUFDO29CQUNMLENBQUM7b0JBQ0QsSUFBSSxDQUFDLENBQUM7d0JBQ0YsSUFBSSxDQUFDLGVBQWUsR0FBRyxLQUFLLENBQUM7d0JBQzdCLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQzt3QkFDNUIsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO3dCQUM1QixJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGNBQWMsQ0FBQzt3QkFFL0QsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLElBQUksSUFBSSxRQUFRLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7NEJBQzNILE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDOzRCQUNoQyxJQUFJLENBQUMsWUFBWSxHQUFHLG9CQUFvQixDQUFDOzRCQUN6QyxNQUFNLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQzs0QkFFbEMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLFFBQVEsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDO2dDQUNsSSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTtvQ0FDbkcsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7b0NBQ3RDLGlCQUFpQjtvQ0FDakIsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO3dDQUMzQix5QkFBeUI7d0NBQ3pCLE9BQU8sQ0FBQyxLQUFLLENBQUM7NENBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZOzRDQUN0RCxPQUFPLEVBQUU7Z0RBQ0wsRUFBRSxFQUFFO29EQUNBLGNBQWM7b0RBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO2lEQUM1Qjs2Q0FDSjt5Q0FDSixDQUFDLENBQUM7b0NBQ1AsQ0FBQztvQ0FDRCw0QkFBNEI7b0NBQzVCLE9BQU8sQ0FBQyxLQUFLLENBQUM7d0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO3dDQUN0RCxPQUFPLEVBQUU7NENBQ0wsRUFBRSxFQUFFO2dEQUNBLGNBQWM7Z0RBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTOzZDQUM1Qjt5Q0FDSjtxQ0FDSixDQUFDLENBQUM7b0NBQ0gsS0FBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7b0NBQ3JCLEdBQUc7b0NBQ0gsUUFBUTtvQ0FFUixHQUFHO2dDQUNQLENBQUMsQ0FBQyxDQUFDOzRCQUNQLENBQUM7NEJBQ0QsSUFBSSxDQUFDLENBQUM7Z0NBQ0YsT0FBTyxDQUFDLEtBQUssQ0FBQztvQ0FDVixPQUFPLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsZUFBZSxFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsWUFBWTtvQ0FDL0UsT0FBTyxFQUFFO3dDQUNMLEVBQUUsRUFBRTs0Q0FDQSxjQUFjOzRDQUNkLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUzt5Q0FDNUI7cUNBQ0o7aUNBQ0osQ0FBQyxDQUFDO2dDQUNILElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztnQ0FDbEIsSUFBSSxDQUFDLGVBQWUsR0FBRyxLQUFLLENBQUM7Z0NBQzdCLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDOzRCQUM3QixDQUFDO3dCQUNMLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsTUFBTSxDQUFDLGdCQUFnQixDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7NEJBQ2hDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO3dCQUN0QyxDQUFDO29CQUNMLENBQUM7Z0JBRUwsQ0FBQztnQkFDRCxvQ0FBWSxHQUFaO29CQUNJLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO3dCQUN4RSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQzs0QkFDNUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQzt3QkFDakgsQ0FBQztvQkFDTCxDQUFDO2dCQUNMLENBQUM7Z0JBQ0QsNkNBQXFCLEdBQXJCO2dCQUVBLENBQUM7Z0JBQ0Qsc0NBQWMsR0FBZDtvQkFDSSxVQUFVO29CQUNWLFdBQVc7Z0JBRWYsQ0FBQztnQkFFRCx5Q0FBaUIsR0FBakI7b0JBRUksSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO29CQUNsQixJQUFJLENBQUMsb0NBQW9DLEVBQUUsQ0FBQztvQkFDNUMsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDO29CQUNkLElBQUksTUFBTSxHQUFHLE1BQU0sQ0FBQztvQkFFcEIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUM7d0JBQ3hFLE1BQU0sR0FBRyxNQUFNLENBQUM7b0JBRXBCLENBQUM7b0JBQ0QsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFO3dCQUM1QixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLE1BQU0sQ0FBQyxDQUFDLENBQUM7NEJBQ3RCLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDOzRCQUNsQixNQUFNLENBQUMsS0FBSyxDQUFDO3dCQUNqQixDQUFDO29CQUVMLENBQUMsQ0FBQyxDQUFDO29CQUVILElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQztnQkFDekcsQ0FBQztnQkFDRCxrQ0FBVSxHQUFWO29CQUVJLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDO3dCQUN0RSxXQUFXO3dCQUNYLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxJQUFJLFNBQVMsQ0FBRSxDQUFDLENBQUQsQ0FBQzs0QkFDekUsSUFBSSxVQUFVLEdBQUcsRUFBRSxDQUFDOzRCQUNwQixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDO2dDQUN6SSxVQUFVLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDOzRCQUVyRSxDQUFDOzRCQUNELElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLElBQUksU0FBUyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDaEosVUFBVSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQzs0QkFDN0MsQ0FBQzs0QkFDRCxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLElBQUksU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUNsSixVQUFVLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLEdBQUcsR0FBRyxDQUFDOzRCQUM3QyxDQUFDOzRCQUNELElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxHQUFHLFVBQVUsQ0FBQzt3QkFDeEMsQ0FBQzt3QkFDRCxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLElBQUksU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDOzRCQUNsSixJQUFJLFVBQVUsR0FBRyxFQUFFLENBQUM7NEJBQ3BCLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDMUUsVUFBVSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDOzRCQUN6QyxDQUFDOzRCQUNELElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxHQUFHLFVBQVUsQ0FBQzt3QkFDeEMsQ0FBQzt3QkFDRCxJQUFJOzRCQUNBLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUMscUJBQXFCO3dCQUM5SSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQzs0QkFDNUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQzt3QkFDakgsQ0FBQztvQkFDTCxDQUFDO29CQUNELElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztnQkFDeEIsQ0FBQztnQkFDRCxpQ0FBUyxHQUFUO29CQUNJLHNFQUFzRTtvQkFDdEUsSUFBSSxNQUFNLEdBQUcsS0FBSyxDQUFDO29CQUNuQixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7d0JBQ3pCLE1BQU0sR0FBRyxLQUFLLENBQUE7d0JBQ2QsSUFBSSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUM7b0JBQzNCLENBQUM7b0JBQ0QsSUFBSSxDQUFDLENBQUM7d0JBQ0YsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7d0JBQ3RCLE1BQU0sR0FBRyxJQUFJLENBQUM7b0JBQ2xCLENBQUM7b0JBRUQsSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFDL0IsQ0FBQztnQkFDRCx3Q0FBZ0IsR0FBaEI7b0JBQUEsaUJBdUlDO29CQXRJRyxXQUFXO29CQUNYLElBQUksQ0FBQyxZQUFZLEdBQUcsVUFBVSxDQUFDO29CQUMvQixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztvQkFDdkIsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7b0JBRXpCLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQztvQkFDZCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7d0JBQzlGLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsRUFBRTs0QkFDM0MsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO2dDQUMzQixLQUFLLEdBQUcsS0FBSyxHQUFHLENBQUMsQ0FBQzs0QkFDdEIsQ0FBQzs0QkFDRCxFQUFFLENBQUMsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDWixtREFBbUQ7Z0NBRW5ELElBQUksQ0FBQyxZQUFZLEdBQUcsRUFBRSxDQUFDO2dDQUN2QixJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztnQ0FDeEIsTUFBTSxDQUFDLEtBQUssQ0FBQzs0QkFDakIsQ0FBQzt3QkFDTCxDQUFDLENBQUMsQ0FBQztvQkFDUCxDQUFDO29CQUNELG1DQUFtQztvQkFDbkMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzt3QkFDbEMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQyxPQUFPLEVBQUUsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDOzRCQUMzRSxPQUFPLENBQUMsS0FBSyxDQUFDLEVBQUUsT0FBTyxFQUFFLHdCQUF3QixFQUFFLENBQUMsQ0FBQzs0QkFFckQsSUFBSSxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUM7NEJBQ3ZCLElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDOzRCQUN4QixNQUFNLENBQUMsS0FBSyxDQUFDO3dCQUNqQixDQUFDO29CQUNMLENBQUM7b0JBQ0QsRUFBRSxDQUFDLENBQUMsS0FBSyxJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7d0JBRTVHLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUN4RixJQUFJLE1BQU0sR0FBRyxFQUFFLENBQUM7NEJBQ2hCLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLElBQUksQ0FBQztnQ0FDN0IsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQzs0QkFDcEMsQ0FBQyxDQUFDLENBQUM7NEJBQ0gsSUFBSSxNQUFNLEdBQUcsRUFBRSxDQUFDOzRCQUNoQixNQUFNLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0NBQzdCLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7NEJBQ3BDLENBQUMsQ0FBQyxDQUFDOzRCQUNILElBQUksT0FBTyxHQUFHLEVBQUUsQ0FBQzs0QkFDakIsTUFBTSxDQUFDLG9CQUFvQixDQUFDLENBQUMsSUFBSSxDQUFDO2dDQUM5QixPQUFPLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDOzRCQUNyQyxDQUFDLENBQUMsQ0FBQzs0QkFDSCxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7NEJBQ1YsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRTtnQ0FDeEMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO29DQUNyQixJQUFJLENBQUMsS0FBSyxHQUFHLEdBQUcsQ0FBQztnQ0FDckIsQ0FBQztnQ0FDRCxJQUFJLENBQUMsQ0FBQztvQ0FDRixJQUFJLENBQUMsS0FBSyxHQUFHLEdBQUcsQ0FBQztnQ0FDckIsQ0FBQztnQ0FDRCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7b0NBQ3pCLElBQUksQ0FBQyxTQUFTLEdBQUcsR0FBRyxDQUFDO2dDQUN6QixDQUFDO2dDQUNELElBQUksQ0FBQyxDQUFDO29DQUNGLElBQUksQ0FBQyxTQUFTLEdBQUcsR0FBRyxDQUFDO2dDQUN6QixDQUFDO2dDQUNELElBQUksQ0FBQyxLQUFLLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUN2QixJQUFJLENBQUMsSUFBSSxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDdEIsSUFBSSxDQUFDLE1BQU0sR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQ3pCLENBQUMsRUFBRSxDQUFDO2dDQUNKLHlDQUF5QztnQ0FDekMsdUNBQXVDO2dDQUN2QywyQkFBMkI7NEJBQy9CLENBQUMsQ0FBQyxDQUFDO3dCQUVQLENBQUM7d0JBQ0QsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQ3hGLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUU7Z0NBQ3hDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQztvQ0FDdkIsSUFBSSxDQUFDLE9BQU8sR0FBRyxHQUFHLENBQUM7Z0NBQ3ZCLENBQUM7Z0NBQ0QsSUFBSSxDQUFDLENBQUM7b0NBQ0YsSUFBSSxDQUFDLE9BQU8sR0FBRyxHQUFHLENBQUM7Z0NBQ3ZCLENBQUM7Z0NBQ0QsQ0FBQyxFQUFFLENBQUM7NEJBQ1IsQ0FBQyxDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQzt3QkFDNUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQTt3QkFDbEIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFROzRCQUN2RCxPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDOzRCQUN0QixRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzs0QkFDdEMsS0FBSSxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUM7NEJBQ3ZCLEtBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDOzRCQUV4QixFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7Z0NBQzNCLHlCQUF5QjtnQ0FDekIsS0FBSSxDQUFDLFFBQVEsR0FBRyxhQUFhLENBQUM7NEJBQ2xDLENBQUM7NEJBQ0QsSUFBSSxDQUFDLENBQUM7Z0NBQ0YseUJBQXlCO2dDQUV6QixLQUFJLENBQUMsUUFBUSxHQUFHLGNBQWMsQ0FBQztnQ0FDL0IsSUFBSSxLQUFLLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQztnQ0FDL0MsS0FBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsTUFBTSxFQUFFLEtBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxFQUFFLEVBQUUsQ0FBQyxDQUFDO2dDQUNsRixLQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxLQUFLLEVBQUUsS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEVBQUUsRUFBRSxDQUFDLENBQUM7Z0NBQy9FLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLEtBQUssRUFBRSxLQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixFQUFFLEVBQUUsQ0FBQyxDQUFDO2dDQUNyRixFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sR0FBQyxDQUFDLENBQUM7b0NBQzNDLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLE9BQU8sRUFBRSxLQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLFdBQVcsRUFBRSxFQUFFLENBQUMsQ0FBQztnQ0FDdkosWUFBWTtnQ0FDWCwwREFBMEQ7Z0NBQzFELFdBQVc7Z0NBQ1gsS0FBSSxDQUFDLGNBQWMsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO2dDQUNwQyxLQUFJLENBQUMsVUFBVSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7Z0NBQ2hDLEtBQUksQ0FBQyxXQUFXLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDOzRCQU10QyxDQUFDOzRCQUNELEtBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDOzRCQUNwQixLQUFJLENBQUMsR0FBRyxHQUFHLFFBQVEsQ0FBQyxNQUFNLENBQUM7d0JBQy9CLENBQUMsRUFDRyxVQUFBLEtBQUssSUFBRyxPQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEVBQWxCLENBQWtCLEVBQzFCLGNBQU0sT0FBQSxPQUFPLENBQUMsR0FBRyxDQUFDLHNCQUFzQixDQUFDLEVBQW5DLENBQW1DLENBQzVDLENBQUM7b0JBQ04sQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixPQUFPLENBQUMsS0FBSyxDQUFDOzRCQUNWLE9BQU8sRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxpQkFBaUIsRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLFlBQVk7NEJBQ2pGLE9BQU8sRUFBRTtnQ0FDTCxFQUFFLEVBQUU7b0NBQ0EsY0FBYztvQ0FDZCxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVM7aUNBQzVCOzZCQUNKO3lCQUNKLENBQUMsQ0FBQzt3QkFDSCxJQUFJLENBQUMsWUFBWSxHQUFHLEVBQUUsQ0FBQzt3QkFDdkIsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7b0JBQzVCLENBQUM7Z0JBQ0wsQ0FBQztnQkFFRCw0REFBb0MsR0FBcEM7b0JBQUEsaUJBMEVDO29CQXpFRyxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztvQkFDNUMsV0FBVztvQkFDWCxJQUFJLEtBQUssR0FBRyxFQUFFLENBQUM7b0JBQ2YsSUFBSSxLQUFLLEdBQUcsRUFBRSxDQUFDO29CQUNmLElBQUksT0FBTyxHQUFHLEVBQUUsQ0FBQztvQkFDakIsSUFBSSxNQUFNLEdBQUcsRUFBRSxDQUFDO29CQUNoQixJQUFJLE1BQU0sR0FBRyxFQUFFLENBQUM7b0JBRWhCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLFNBQVMsQ0FBQzt3QkFDbkMsS0FBSyxHQUFHLEVBQUUsQ0FBQztvQkFDZixJQUFJO3dCQUNBLEtBQUssR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQztvQkFFbEMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLElBQUksU0FBUyxDQUFDO3dCQUNuQyxLQUFLLEdBQUcsRUFBRSxDQUFDO29CQUNmLElBQUk7d0JBQ0EsS0FBSyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDO29CQUNsQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sSUFBSSxTQUFTLENBQUM7d0JBQ3JDLE9BQU8sR0FBRyxFQUFFLENBQUM7b0JBQ2pCLElBQUk7d0JBQ0EsT0FBTyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDO29CQUV0QyxNQUFNLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxJQUFJLENBQUM7d0JBRTdCLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLEVBQUUsSUFBSSxFQUFFLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsRUFBRSxJQUFJLFNBQVMsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxFQUFFLElBQUksSUFBSSxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxNQUFNLElBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQzs0QkFDNUgsTUFBTSxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxLQUFLLENBQUM7d0JBQ3pDLENBQUM7b0JBQ0wsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7d0JBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7b0JBQ3ZFLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUU7d0JBQ3hDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxLQUFLLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxLQUFLLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxJQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7NEJBQzVGLE1BQU0sSUFBSSxJQUFJLENBQUMsS0FBSyxHQUFDLEtBQUssQ0FBQzt3QkFDL0IsQ0FBQztvQkFFTCxDQUFDLENBQUMsQ0FBQztvQkFDSCxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQzt3QkFBQyxNQUFNLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQztvQkFDdkUsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLElBQUksRUFBRSxJQUFJLEtBQUssQ0FBQyxNQUFNLElBQUksQ0FBQyxJQUFJLEtBQUssSUFBSSxFQUFFLElBQUksS0FBSyxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUM7MkJBQ25FLENBQUMsT0FBTyxJQUFJLEVBQUUsSUFBSSxPQUFPLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQzsyQkFDdEMsQ0FBQyxNQUFNLElBQUksRUFBRSxDQUFDOzJCQUNkLENBQUMsTUFBTSxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFFcEIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLHNCQUFzQixDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxNQUFNLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFROzRCQUNsRyxXQUFXOzRCQUNYLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDOzRCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7Z0NBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7b0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO29DQUN0RCxPQUFPLEVBQUU7d0NBQ0wsRUFBRSxFQUFFOzRDQUNBLGNBQWM7NENBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3lDQUM1QjtxQ0FDSjtpQ0FDSixDQUFDLENBQUM7NEJBQ1AsQ0FBQzs0QkFDRCxJQUFJLENBQUMsQ0FBQztnQ0FDRixLQUFJLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQztnQ0FDbkIsS0FBSSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO2dDQUM5QixFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxJQUFJLElBQUksSUFBSSxRQUFRLENBQUMsSUFBSSxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUM7b0NBQ3RELEtBQUksQ0FBQyxjQUFjLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQztvQ0FDcEMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFBO2dDQUdwQyxDQUFDOzRCQUVMLENBQUM7d0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzs0QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO3dCQUN2QixDQUFDLEVBQUU7NEJBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTt3QkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBQ1AsQ0FBQztvQkFDRCxvQkFBb0I7Z0JBQ3hCLENBQUM7Z0JBSUQsK0NBQXVCLEdBQXZCLFVBQXdCLEtBQUssRUFBRSxLQUFLLEVBQUMsT0FBTztvQkFBNUMsaUJBOENDO29CQTdDRyxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztvQkFDNUMsV0FBVztvQkFDWCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssSUFBSSxTQUFTLENBQUM7d0JBQ25DLEtBQUssR0FBRyxFQUFFLENBQUM7b0JBQ2YsSUFBSTt3QkFDQSxLQUFLLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUM7b0JBRWxDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLFNBQVMsQ0FBQzt3QkFDbkMsS0FBSyxHQUFHLEVBQUUsQ0FBQztvQkFDZixJQUFJO3dCQUNBLEtBQUssR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQztvQkFDbEMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLElBQUksU0FBUyxDQUFDO3dCQUNyQyxPQUFPLEdBQUcsRUFBRSxDQUFDO29CQUNqQixJQUFJO3dCQUNBLE9BQU8sR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQztvQkFDdEMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLHFCQUFxQixDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFDakYsV0FBVzt3QkFDWCxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDdEQsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUM7NEJBQ25CLEtBQUksQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzs0QkFDOUIsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksSUFBSSxJQUFJLElBQUksUUFBUSxDQUFDLElBQUksSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDO2dDQUN0RCxLQUFJLENBQUMsY0FBYyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7Z0NBQ3BDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxTQUFTLEVBQUUsQ0FBQzs0QkFFckMsQ0FBQzt3QkFFTCxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUNILG9CQUFvQjtnQkFDeEIsQ0FBQztnQkFLRCwwQ0FBa0IsR0FBbEI7b0JBRUksaUJBQWlCO29CQUNqQix3RUFBd0U7b0JBQ3hFLG9DQUFvQztvQkFDcEMsNEVBQTRFO29CQUM1RSxpQkFBaUI7b0JBQ2pCLDRDQUE0QztvQkFDNUMscUNBQXFDO29CQUNyQyxpQ0FBaUM7b0JBQ2pDLE9BQU87b0JBQ1AsWUFBWTtvQkFDWiw2QkFBNkI7b0JBQzdCLHdDQUF3QztvQkFDeEMsb0VBQW9FO29CQUNwRSxrREFBa0Q7b0JBQ2xELGlEQUFpRDtvQkFDakQsV0FBVztvQkFDWCw0QkFBNEI7b0JBQzVCLE9BQU87b0JBQ1AsY0FBYztvQkFDZCx5QkFBeUI7b0JBQ3pCLFlBQVk7b0JBQ1osa0NBQWtDO29CQUNsQyxLQUFLO2dCQUNULENBQUM7Z0JBQ0QsMENBQWtCLEdBQWxCO29CQUFBLGlCQWdDQztvQkEvQkcsSUFBSSxLQUFLLEdBQUcsRUFBRSxDQUFDO29CQUNmLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssSUFBSSxTQUFTLENBQUM7d0JBQ2xFLEtBQUssR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQztvQkFDbEMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLHNCQUFzQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFDbEYsV0FBVzt3QkFDWCxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDdEQsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUM7NEJBQ25CLEtBQUksQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzs0QkFDOUIsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksSUFBSSxJQUFJLElBQUksUUFBUSxDQUFDLElBQUksSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDO2dDQUN0RCxLQUFJLENBQUMsY0FBYyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7Z0NBQ3BDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxTQUFTLEVBQUUsQ0FBQzs0QkFDckMsQ0FBQzt3QkFFTCxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO2dCQUNQLENBQUM7Z0JBQ0QsbUNBQVcsR0FBWCxVQUFZLEtBQUs7b0JBQ2IsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRTt3QkFDeEMsRUFBRSxDQUFDLENBQUMsSUFBSSxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUM7NEJBQ2hCLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO3dCQUM5QixDQUFDO29CQUVMLENBQUMsQ0FBQyxDQUFDO2dCQUNQLENBQUM7Z0JBQ0Qsb0NBQVksR0FBWjtvQkFDSSxJQUFJLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztvQkFDbEIsSUFBSSxDQUFDLFVBQVUsR0FBRyxFQUFFLENBQUM7b0JBQ3JCLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxHQUFHLEVBQUUsQ0FBQztvQkFDakMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEdBQUcsRUFBRSxDQUFDO29CQUM5QixJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7b0JBQzFCLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQztvQkFDM0IsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLEdBQUcsRUFBRSxDQUFDO29CQUNoQyxJQUFJLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztvQkFDckIsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxhQUFhLENBQUE7Z0JBRzNELENBQUM7Z0JBQ0Qsc0NBQWMsR0FBZDtvQkFDSSxXQUFXO29CQUNYLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQzt3QkFDM0IsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7d0JBQ3ZCLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsaUJBQWlCLENBQUM7d0JBQzVELE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBQ2pDLENBQUM7b0JBQ0QsSUFBSSxDQUFDLENBQUM7d0JBQ0YsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7d0JBQ3hCLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsa0JBQWtCLENBQUM7d0JBQzdELE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBQ2pDLENBQUM7Z0JBRUwsQ0FBQztnQkFHRCxxQ0FBYSxHQUFiLFVBQWMsS0FBSztvQkFDZixpQkFBaUI7b0JBQ2pCLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLElBQUksU0FBUyxJQUFJLEtBQUssQ0FBQyxNQUFNLElBQUksRUFBRSxDQUFDOzJCQUNqRCxDQUFDLEtBQUssQ0FBQyxPQUFPLElBQUksU0FBUyxJQUFJLEtBQUssQ0FBQyxPQUFPLElBQUksRUFBRSxDQUFDOzJCQUVuRCxDQUFDLEtBQUssQ0FBQyxHQUFHLElBQUksU0FBUyxJQUFJLEtBQUssQ0FBQyxHQUFHLElBQUksRUFBRSxDQUFDOzJCQUMzQyxDQUFDLEtBQUssQ0FBQyxXQUFXLElBQUksU0FBUyxJQUFJLEtBQUssQ0FBQyxXQUFXLElBQUksRUFBRSxDQUFFOzJCQUU1RCxDQUFDLEtBQUssQ0FBQyxhQUFhLElBQUksU0FBUyxJQUFJLEtBQUssQ0FBQyxhQUFhLElBQUksRUFBRSxDQUFDLENBQUM7Z0JBQzNFLENBQUM7Z0JBQ0Qsb0NBQVksR0FBWixVQUFhLEtBQUs7b0JBRWQsSUFBSSxTQUFTLEdBQUcsS0FBSyxDQUFDO29CQUN0QixLQUFLLENBQUMsUUFBUSxHQUFHLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQztvQkFFdkMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBRTVCLElBQUksS0FBSyxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUM7d0JBQy9DLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLE9BQU8sRUFBRSxLQUFLLENBQUMsV0FBVyxFQUFFLEVBQUUsQ0FBQyxDQUFDO3dCQUN4RSxJQUFJLElBQUksR0FBRyxFQUFFLENBQUM7d0JBQ2QsSUFBSSxNQUFNLEdBQUcsTUFBTSxDQUFDO3dCQUNwQixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQzs0QkFDeEUsTUFBTSxHQUFHLE1BQU0sQ0FBQzt3QkFDcEIsQ0FBQzt3QkFDRCxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUU7NEJBQzVCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksTUFBTSxDQUFDLENBQUMsQ0FBQztnQ0FDdEIsSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7Z0NBQ2xCLE1BQU0sQ0FBQyxLQUFLLENBQUM7NEJBQ2pCLENBQUM7d0JBRUwsQ0FBQyxDQUFDLENBQUM7d0JBQ0gsSUFBSSxTQUFTLEdBQUcsRUFBRSxNQUFNLEVBQUUsRUFBRSxFQUFFLE9BQU8sRUFBRSxFQUFFLEVBQUUsUUFBUSxFQUFFLEVBQUUsRUFBRSxHQUFHLEVBQUUsRUFBRSxFQUFFLFdBQVcsRUFBRSxLQUFLLENBQUMsV0FBVyxFQUFFLE9BQU8sRUFBRSxFQUFFLEVBQUUsYUFBYSxFQUFFLElBQUksRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUcsU0FBUyxFQUFFLFVBQVUsR0FBRyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsTUFBTSxHQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLFdBQVcsRUFBRSxRQUFRLEdBQUcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sR0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDO3dCQUU1VSw4REFBOEQ7d0JBQzlELG1GQUFtRjt3QkFFbkYsb0NBQW9DO3dCQUNwQyx1QkFBdUI7d0JBQ3ZCLE9BQU87d0JBQ1AsS0FBSzt3QkFDTCxFQUFFLENBQUMsQ0FBQyxTQUFTLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQzs0QkFDckIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7d0JBQ3RELENBQUM7b0JBRVQsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixJQUFJLEdBQUcsR0FBRyxFQUFFLENBQUM7d0JBQ2IsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sSUFBSSxTQUFTLElBQUksS0FBSyxDQUFDLE1BQU0sSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDOzRCQUNsRCxvREFBb0Q7NEJBQ3BELEdBQUcsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsaUJBQWlCLENBQUM7d0JBQzdELENBQUM7d0JBQ0QsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sSUFBSSxTQUFTLElBQUksS0FBSyxDQUFDLE9BQU8sSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDOzRCQUNwRCxnQ0FBZ0M7NEJBQ2hDLEdBQUcsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsZUFBZSxDQUFDO3dCQUMzRCxDQUFDO3dCQUNELDBEQUEwRDt3QkFDMUQsdUNBQXVDO3dCQUN2Qyw2REFBNkQ7d0JBQzdELEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLElBQUksU0FBUyxJQUFJLEtBQUssQ0FBQyxHQUFHLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzs0QkFDNUMsZ0NBQWdDOzRCQUNoQyxHQUFHLElBQUksSUFBSSxHQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGNBQWMsQ0FBQzt3QkFDeEQsQ0FBQzt3QkFDRCxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsV0FBVyxJQUFJLFNBQVMsSUFBSSxLQUFLLENBQUMsV0FBVyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7NEJBQzVELHFDQUFxQzs0QkFDckMsR0FBRyxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxrQkFBa0IsQ0FBQzt3QkFDOUQsQ0FBQzt3QkFDRCx3RUFBd0U7d0JBQ3hFLHVDQUF1Qzt3QkFDdkMsR0FBRzt3QkFDSCxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsYUFBYSxJQUFJLFNBQVMsSUFBSSxLQUFLLENBQUMsYUFBYSxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7NEJBQ2hFLDBDQUEwQzs0QkFDMUMsR0FBRyxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxpQkFBaUIsQ0FBQzt3QkFDN0QsQ0FBQzt3QkFDRCxPQUFPLENBQUMsS0FBSyxDQUFDOzRCQUNWLE9BQU8sRUFBRSxHQUFHLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxZQUFZOzRCQUMxQyxPQUFPLEVBQUU7Z0NBQ0wsRUFBRSxFQUFFO29DQUNBLGNBQWM7b0NBQ2QsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO2lDQUM1Qjs2QkFDSjt5QkFDSixDQUFDLENBQUM7b0JBQ1AsQ0FBQztnQkFFTCxDQUFDO2dCQUNELG1DQUFXLEdBQVgsVUFBWSxRQUFRO29CQUNoQixXQUFXO29CQUNYLGlLQUFpSztvQkFDakssTUFBTSxDQUFDLENBQUMsUUFBUSxDQUFDLFdBQVcsSUFBSSxTQUFTLElBQUksUUFBUSxDQUFDLFdBQVcsSUFBSSxFQUFFLENBQUMsQ0FBQTtvQkFDcEUsaUZBQWlGO29CQUNqRiwyRUFBMkU7b0JBQzNFLHNFQUFzRTtvQkFDdEUsMkRBQTJEO29CQUMzRCw4RkFBOEY7Z0JBQ3RHLENBQUM7Z0JBQ0QsaUNBQVMsR0FBVCxVQUFVLFFBQVE7b0JBQ2QsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBRTdCLFFBQVEsQ0FBQzt3QkFDVCx1Q0FBdUM7d0JBQ3ZDLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQzt3QkFDZCxJQUFJLEdBQUcsR0FBRyxDQUFDLENBQUM7d0JBQ1osSUFBSSxPQUFPLEdBQUcsQ0FBQyxDQUFDO3dCQUNoQixNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUU7NEJBQzFCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksV0FBVyxDQUFDLENBQUMsQ0FBQztnQ0FFM0IsSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7Z0NBQ2xCLEdBQUcsR0FBRyxDQUFDLENBQUM7Z0NBQ1IsT0FBTyxHQUFHLENBQUMsQ0FBQztnQ0FDWixNQUFNLENBQUMsS0FBSyxDQUFDOzRCQUNqQixDQUFDO3dCQUNMLENBQUMsQ0FBQyxDQUFDO3dCQUNILElBQUksUUFBUSxHQUFHLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFLE1BQU0sRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFFLEtBQUssRUFBRSxHQUFHLEVBQUUsUUFBUSxFQUFFLEVBQUUsRUFBRSxhQUFhLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLEtBQUssR0FBRyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxZQUFZLEVBQUUsS0FBSyxHQUFHLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUM7d0JBRWpULElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFJbEQsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixJQUFJLEdBQUcsR0FBRyxFQUFFLENBQUM7d0JBQ2IsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLFdBQVcsSUFBSSxTQUFTLElBQUksUUFBUSxDQUFDLFdBQVcsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDOzRCQUNsRSx3Q0FBd0M7NEJBQ3hDLEdBQUcsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsb0JBQW9CLENBQUM7d0JBQ2hFLENBQUM7d0JBQ0QsNERBQTREO3dCQUM1RCw4Q0FBOEM7d0JBQzlDLGdFQUFnRTt3QkFDaEUsR0FBRzt3QkFDSCx5Q0FBeUM7d0JBQ3pDLGlEQUFpRDt3QkFDakQsR0FBRzt3QkFDSCxPQUFPLENBQUMsS0FBSyxDQUFDOzRCQUNWLE9BQU8sRUFBRSxHQUFHLEVBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxZQUFZOzRCQUN6QyxPQUFPLEVBQUU7Z0NBQ0wsRUFBRSxFQUFFO29DQUNBLGNBQWM7b0NBQ2QsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO2lDQUM1Qjs2QkFDSjt5QkFDSixDQUFDLENBQUM7b0JBRVAsQ0FBQztnQkFFTCxDQUFDO2dCQUNELG1DQUFXLEdBQVgsVUFBWSxRQUFRO29CQUNoQixXQUFXO29CQUNYLGlCQUFpQjtvQkFDakIsTUFBTSxDQUFDLENBQUMsUUFBUSxDQUFDLFNBQVMsSUFBSSxTQUFTLElBQUksUUFBUSxDQUFDLFNBQVMsSUFBSSxFQUFFLENBQUMsQ0FBQztvQkFDckUsMERBQTBEO2dCQUU5RCxDQUFDO2dCQUNELGlDQUFTLEdBQVQsVUFBVSxRQUFRO29CQUNkLFdBQVc7b0JBQ1gsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQzdCLElBQUksUUFBUSxHQUFHLENBQUMsQ0FBQzt3QkFDakIsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFOzRCQUMzQixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLFdBQVcsQ0FBQyxDQUFDLENBQUM7Z0NBSTNCLFFBQVEsR0FBRyxDQUFDLENBQUM7Z0NBQ1osTUFBTSxDQUFDLEtBQUssQ0FBQzs0QkFDakIsQ0FBQzt3QkFDTCxDQUFDLENBQUMsQ0FBQzt3QkFDSCx1Q0FBdUM7d0JBQ3ZDLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQzt3QkFDZCxJQUFJLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQzt3QkFDaEIsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQzt3QkFDeEMsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUM7d0JBQ3hCLElBQUksQ0FBQyxPQUFPLEdBQUcsUUFBUSxDQUFDO3dCQUN4QixJQUFJLENBQUMsU0FBUyxHQUFFLE1BQU0sR0FBRyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sR0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQzt3QkFDOUUsSUFBSSxDQUFDLGFBQWEsR0FBRSxNQUFNLEdBQUcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUM7d0JBQ2hGLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFHbEQsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixJQUFJLEdBQUcsR0FBRyxFQUFFLENBQUM7d0JBQ2IsMERBQTBEO3dCQUMxRCx1Q0FBdUM7d0JBQ3ZDLGlFQUFpRTt3QkFDakUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLFNBQVMsSUFBSSxTQUFTLElBQUksUUFBUSxDQUFDLFNBQVMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDOzRCQUM5RCxnQ0FBZ0M7NEJBQ2hDLEdBQUcsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsbUJBQW1CLENBQUM7d0JBQy9ELENBQUM7d0JBQ0QsT0FBTyxDQUFDLEtBQUssQ0FBQzs0QkFDVixPQUFPLEVBQUUsR0FBRyxFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsWUFBWTs0QkFDMUMsT0FBTyxFQUFFO2dDQUNMLEVBQUUsRUFBRTtvQ0FDQSxjQUFjO29DQUNkLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUztpQ0FDNUI7NkJBQ0o7eUJBQ0osQ0FBQyxDQUFDO29CQUVQLENBQUM7b0JBRUQsOERBQThEO2dCQUNsRSxDQUFDO2dCQUVELG1DQUFXLEdBQVgsVUFBWSxHQUFHO29CQUFmLGlCQTJHQztvQkExR0csSUFBSSxDQUFDLGdCQUFnQixDQUFDLGtCQUFrQixDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUN4RSxZQUFZO3dCQUNYLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUN0RCxPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsVUFBVSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7NEJBQ2hDLEtBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsY0FBYyxDQUFDOzRCQUM3RCx3RUFBd0U7NEJBQ3hFLEtBQUksQ0FBQyxPQUFPLEdBQUcsaUJBQWlCLENBQUM7NEJBQ2pDLEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUM3QyxLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxDQUFDLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsS0FBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFFLFNBQVMsRUFBRSxPQUFPLEVBQUUsYUFBYSxFQUFFLE9BQU8sRUFBRSxDQUFDLENBQUE7NEJBQ25LLENBQUM7NEJBQ0QsSUFBSSxDQUFDLENBQUM7Z0NBQ0YsSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO2dDQUVkLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUU7b0NBQ3hDLElBQUksQ0FBQyxTQUFTLEdBQUcsTUFBTSxHQUFHLEtBQUssQ0FBQztvQ0FDaEMsSUFBSSxDQUFDLGFBQWEsR0FBRyxNQUFNLEdBQUcsS0FBSyxFQUFFLENBQUM7Z0NBQzFDLENBQUMsQ0FBQyxDQUFDOzRCQUNQLENBQUM7NEJBQ0QsRUFBRSxDQUFDLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQzdDLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQztnQ0FFZCxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUksQ0FBQyxXQUFXLEVBQUU7b0NBRTFCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksV0FBVyxDQUFDLENBQUMsQ0FBQzt3Q0FFM0IsSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7d0NBQ2xCLE1BQU0sQ0FBQyxLQUFLLENBQUM7b0NBQ2pCLENBQUM7Z0NBQ0wsQ0FBQyxDQUFDLENBQUM7Z0NBRUgsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsQ0FBQyxFQUFFLFdBQVcsRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLEVBQUUsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRSxRQUFRLEVBQUUsRUFBRSxFQUFFLFNBQVMsRUFBRSxDQUFDLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRSxZQUFZLEVBQUUsTUFBTSxFQUFFLENBQUMsQ0FBQzs0QkFHNUssQ0FBQzs0QkFDRCxJQUFJLENBQUMsQ0FBQztnQ0FDRixJQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7Z0NBQ2QsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRTtvQ0FFeEMsSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLEdBQUcsS0FBSyxDQUFDO29DQUM5QixJQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssR0FBRyxLQUFLLEVBQUUsQ0FBQztnQ0FDeEMsQ0FBQyxDQUFDLENBQUM7NEJBQ1AsQ0FBQzs0QkFDRCxFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUNoRCxJQUFJLEtBQUssR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDO2dDQUUvQyxJQUFJLEtBQUssR0FBRyxLQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxPQUFPLENBQUMsQ0FBQztnQ0FDN0QsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7b0NBQ2pCLEtBQUssR0FBRyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7Z0NBQzdDLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQztnQ0FDZCxJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUM7Z0NBQ3RCLEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxJQUFJLEVBQUUsSUFBSSxLQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sSUFBSSxTQUFTLElBQUksS0FBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQztvQ0FDM0csUUFBUSxHQUFHLE1BQU0sQ0FBQztnQ0FDdEIsQ0FBQztnQ0FDRCxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUksQ0FBQyxhQUFhLEVBQUU7b0NBQzVCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksUUFBUSxDQUFDLENBQUMsQ0FBQzt3Q0FFeEIsSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7d0NBQ2xCLE1BQU0sQ0FBQyxLQUFLLENBQUM7b0NBQ2pCLENBQUM7Z0NBRUwsQ0FBQyxDQUFDLENBQUM7Z0NBQ0gsS0FBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsR0FBRyxDQUFDLEVBQUUsTUFBTSxFQUFFLEVBQUUsRUFBRSxPQUFPLEVBQUUsRUFBRSxFQUFFLFFBQVEsRUFBRSxFQUFFLEVBQUUsR0FBRyxFQUFFLEVBQUUsRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLE9BQU8sRUFBRSxFQUFFLEVBQUUsYUFBYSxFQUFFLElBQUksRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFFLFdBQVcsRUFBRSxXQUFXLEVBQUUsU0FBUyxFQUFFLENBQUMsQ0FBQzs0QkFDM08sQ0FBQzs0QkFDRCxJQUFJLENBQUMsQ0FBQztnQ0FDRixJQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7Z0NBQ2xCLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsRUFBRTtvQ0FDM0MsSUFBSSxDQUFDLFNBQVMsR0FBRyxVQUFVLEdBQUcsS0FBSyxDQUFDO29DQUNwQyxJQUFJLENBQUMsV0FBVyxHQUFHLFFBQVEsR0FBRyxLQUFLLEVBQUUsQ0FBQztnQ0FDMUMsQ0FBQyxDQUFDLENBQUM7NEJBQ0gsQ0FBQzs0QkFDRCw0REFBNEQ7NEJBRTVELHFDQUFxQzs0QkFHckMsMkRBQTJEOzRCQUMzRCw2R0FBNkc7NEJBQzdHLGlCQUFpQjs0QkFDakIsb0NBQW9DOzRCQUNwQyxPQUFPOzRCQUNQLHVFQUF1RTs0QkFDdkUsMERBQTBEOzRCQUMxRCxLQUFLOzRCQUNMLEtBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxHQUFHLEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQzs0QkFDM0QsS0FBSSxDQUFDLGVBQWUsR0FBRyxLQUFLLENBQUM7NEJBQzdCLEtBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO3dCQUc3QixDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO2dCQUNQLENBQUM7Z0JBQ0Qsc0NBQWMsR0FBZCxVQUFlLFFBQVE7b0JBQXZCLGlCQStEQztvQkE5REcsV0FBVztvQkFDWCxtRUFBbUU7b0JBQ25FLElBQUksT0FBTyxHQUFHLEVBQUUsQ0FBQztvQkFDakIsTUFBTSxDQUFDLHdCQUF3QixDQUFDLENBQUMsSUFBSSxDQUFDO3dCQUNsQyxPQUFPLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO29CQUNyQyxDQUFDLENBQUMsQ0FBQztvQkFDSCxJQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7b0JBQ2QsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRTt3QkFDeEMsRUFBRSxDQUFDLENBQUMsSUFBSSxJQUFJLFFBQVEsQ0FBQyxDQUFDLENBQUM7NEJBRW5CLE1BQU0sQ0FBQyxLQUFLLENBQUE7d0JBQ2hCLENBQUM7d0JBQ0QsS0FBSyxHQUFHLEtBQUssR0FBRyxDQUFDLENBQUM7b0JBQ3RCLENBQUMsQ0FBQyxDQUFDO29CQUVILEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsSUFBSSxTQUFTLElBQUksT0FBTyxDQUFDLEtBQUssQ0FBQyxJQUFJLElBQUksSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzt3QkFDaEYsSUFBSSxXQUFXLEdBQUcsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO3dCQUNqQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZUFBZSxDQUFDLFdBQVcsQ0FBQyxDQUFDLFNBQVMsQ0FDeEQsVUFBQyxJQUFJOzRCQUNELFdBQVc7NEJBQ1gsRUFBRTs0QkFDRixJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDOzRCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7Z0NBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7b0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO29DQUN0RCxPQUFPLEVBQUU7d0NBQ0wsRUFBRSxFQUFFOzRDQUNBLGNBQWM7NENBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3lDQUM1QjtxQ0FDSjtpQ0FDSixDQUFDLENBQUM7NEJBQ1AsQ0FBQzs0QkFDRCxJQUFJLENBQUMsQ0FBQztnQ0FDRixFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxJQUFJLFNBQVMsSUFBSSxRQUFRLENBQUMsSUFBSSxJQUFJLElBQUksSUFBSSxRQUFRLENBQUMsSUFBSSxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7b0NBRTdFLFdBQVc7b0NBRVgsa0dBQWtHO29DQUNsRyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxHQUFHLENBQUMsQ0FBQyxDQUFDO3dDQUM1QixLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDO3dDQUNoRCxLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDO3dDQUNwRCxLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsT0FBTyxHQUFHLENBQUMsQ0FBQztvQ0FDMUYsQ0FBQztvQ0FDRCxJQUFJLENBQUMsQ0FBQzt3Q0FDRixLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDO3dDQUNwRCxLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDO3dDQUNoRCxLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsT0FBTyxHQUFHLENBQUMsQ0FBQztvQ0FDMUYsQ0FBQztnQ0FFTCxDQUFDOzRCQUVMLENBQUM7NEJBQ0Qsd0ZBQXdGO3dCQUM1RixDQUFDLEVBQ0QsVUFBQyxHQUFHO3dCQUVKLENBQUMsRUFDRDt3QkFFQSxDQUFDLENBQUMsQ0FBQztvQkFDUCxDQUFDO2dCQUNULENBQUM7Z0JBQ0Qsb0NBQVksR0FBWixVQUFhLFFBQVE7b0JBQ2pCLFdBQVc7b0JBQ1gsSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO29CQUNkLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUM7b0JBQzdCLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsY0FBYyxDQUFDO29CQUl6RCxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUMsS0FBSyxDQUFDO29CQUN2QyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsR0FBRyxRQUFRLENBQUMsU0FBUyxDQUFDO29CQUMvQyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsR0FBRyxRQUFRLENBQUMsV0FBVyxDQUFDO29CQUduRCxJQUFJLENBQUMsYUFBYSxHQUFHLEVBQUUsQ0FBQztvQkFDeEIsSUFBSSxDQUFDLGFBQWEsR0FBRyxRQUFRLENBQUM7Z0JBQ2xDLENBQUM7Z0JBQ0QsbUNBQVcsR0FBWCxVQUFZLFFBQVE7b0JBQ2hCLFdBQVc7b0JBQ1gsSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO29CQUNkLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUU7d0JBQ3hDLEVBQUUsQ0FBQyxDQUFDLElBQUksSUFBSSxRQUFRLENBQUMsQ0FBQyxDQUFDOzRCQUNuQixNQUFNLENBQUMsS0FBSyxDQUFBO3dCQUNoQixDQUFDO3dCQUNELEtBQUssR0FBRyxLQUFLLEdBQUcsQ0FBQyxDQUFDO29CQUV0QixDQUFDLENBQUMsQ0FBQztvQkFDSCxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDO2dCQUNwRCxDQUFDO2dCQUVELHNDQUFjLEdBQWQsVUFBZSxVQUFVO29CQUNyQixXQUFXO29CQUNYLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQztvQkFDZCxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDO29CQUM3QixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGNBQWMsQ0FBQztvQkFFMUQsK0NBQStDO29CQUU5QyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDO29CQUN4QyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sR0FBRyxVQUFVLENBQUMsT0FBTyxDQUFDO29CQUMxQyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsR0FBRyxVQUFVLENBQUMsUUFBUSxDQUFDO29CQUM1QyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsR0FBRyxVQUFVLENBQUMsR0FBRyxDQUFDO29CQUNsQyxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsR0FBRyxVQUFVLENBQUMsV0FBVyxDQUFDO29CQUNsRCxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sR0FBRyxVQUFVLENBQUMsT0FBTyxDQUFDO29CQUMxQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsR0FBRyxVQUFVLENBQUMsYUFBYSxDQUFDO29CQUN0RCxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsR0FBRyxVQUFVLENBQUMsV0FBVyxDQUFDO29CQUNsRCxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsR0FBRyxVQUFVLENBQUMsV0FBVyxDQUFDO29CQUdsRCxJQUFJLENBQUMsZUFBZSxHQUFHLEVBQUUsQ0FBQztvQkFDMUIsSUFBSSxDQUFDLGVBQWUsR0FBRyxVQUFVLENBQUM7Z0JBQ3RDLENBQUM7Z0JBRUQscUNBQWEsR0FBYixVQUFjLFVBQVU7b0JBQ3JCLGFBQWE7b0JBQ1osSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO29CQUNkLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsRUFBRTt3QkFDM0MsRUFBRSxDQUFDLENBQUMsSUFBSSxJQUFJLFVBQVUsQ0FBQyxDQUFDLENBQUM7NEJBQ3JCLE1BQU0sQ0FBQyxLQUFLLENBQUE7d0JBQ2hCLENBQUM7d0JBQ0QsS0FBSyxHQUFHLEtBQUssR0FBRyxDQUFDLENBQUM7b0JBQ3RCLENBQUMsQ0FBQyxDQUFDO29CQUNILElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQztnQkFDdkQsQ0FBQztnQkFDRCxvQ0FBWSxHQUFaLFVBQWEsUUFBUTtvQkFFakIsSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO29CQUNkLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsY0FBYyxDQUFBO29CQUN4RCxJQUFJLElBQUksR0FBRyxRQUFRLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztvQkFFM0MsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLFNBQVMsR0FBRyxHQUFHLEdBQUcsUUFBUSxDQUFDLFdBQVcsQ0FBQztvQkFFOUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEdBQUcsUUFBUSxDQUFDLFNBQVMsQ0FBQztvQkFDL0MsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsUUFBUSxDQUFDLE1BQU0sQ0FBQztvQkFDekMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQztvQkFDckMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLEdBQUcsUUFBUSxDQUFDLEtBQUssQ0FBQztvQkFDdkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLEdBQUcsUUFBUSxDQUFDLEtBQUssQ0FBQztvQkFDdkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFDLFFBQVEsQ0FBQztvQkFDN0MsSUFBSSxDQUFDLGFBQWEsR0FBRyxFQUFFLENBQUM7b0JBQ3hCLElBQUksQ0FBQyxhQUFhLEdBQUcsUUFBUSxDQUFDO2dCQUNsQyxDQUFDO2dCQUNELG1DQUFXLEdBQVgsVUFBWSxRQUFRO29CQUVoQixJQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7b0JBQ2QsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRTt3QkFDeEMsRUFBRSxDQUFDLENBQUMsSUFBSSxJQUFJLFFBQVEsQ0FBQyxDQUFDLENBQUM7NEJBQ25CLE1BQU0sQ0FBQyxLQUFLLENBQUE7d0JBQ2hCLENBQUM7d0JBQ0QsS0FBSyxHQUFHLEtBQUssR0FBRyxDQUFDLENBQUM7b0JBQ3RCLENBQUMsQ0FBQyxDQUFDO29CQUNILElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0JBQ3BELENBQUM7Z0JBR0QseUNBQWlCLEdBQWpCO29CQUNJLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLEVBQUUsQ0FBQztvQkFDcEMsSUFBSSxjQUFjLEdBQUcsRUFBRSxDQUFDO29CQUN4QixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUM7d0JBQzFCLHdCQUFhLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxFQUFFLGNBQWMsQ0FBQyxDQUFDO29CQUMvRyxDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUVGLHdCQUFhLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxFQUFFLGNBQWMsQ0FBQyxDQUFDO29CQUNoSCxDQUFDO29CQUNELEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBQyxDQUFDLEdBQUMsY0FBYyxDQUFDLE1BQU0sRUFBQyxDQUFDLEVBQUUsRUFBQyxDQUFDO3dCQUN4QyxJQUFJLElBQUksR0FBRyxFQUFFLENBQUM7d0JBQ2QsSUFBSSxDQUFDLHNCQUFzQixHQUFHLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDaEQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO29CQUU5QyxDQUFDO2dCQUVMLENBQUM7Z0JBRUQsNEJBQUksR0FBSjtvQkFDRyxpQkFBaUI7b0JBQ2hCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzt3QkFDeEIsSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7d0JBRXRCLDZCQUE2Qjt3QkFDN0IsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxnQkFBZ0IsQ0FBQztvQkFDbEUsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDTixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQzt3QkFDckIsOEJBQThCO3dCQUM5QixJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGdCQUFnQixDQUFDO29CQUM5RCxDQUFDO2dCQUNMLENBQUM7Z0JBQ0QscUNBQWEsR0FBYixVQUFjLFNBQVM7b0JBQXZCLGlCQXNEQztvQkFyREcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxDQUFDLFNBQVMsQ0FDdkQsVUFBQyxJQUFJO3dCQUNELFdBQVc7d0JBQ1gsRUFBRTt3QkFDRixtQkFBbUI7d0JBQ25CLEVBQUUsQ0FBQyxDQUFDLFNBQVMsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDOzRCQUNyQixNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDOzRCQUN2QyxJQUFJLEdBQUcsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQTs0QkFDckMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLGFBQWEsQ0FBQztnQ0FDL0IsWUFBWSxFQUFFLElBQUk7Z0NBQ2xCLFVBQVUsRUFBRTtvQ0FDUixhQUFhLEVBQUUsSUFBSTtpQ0FDdEI7Z0NBQ0QsNEJBQTRCO2dDQUM1QixVQUFVLEVBQUUsR0FBRzs2QkFDbEIsQ0FBQyxDQUFDOzRCQUNILElBQUksTUFBTSxHQUFHLEVBQUUsQ0FBQzs0QkFFaEIsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRTtnQ0FDeEMsTUFBTSxJQUFJLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxHQUFHLENBQUM7NEJBQ2hELENBQUMsQ0FBQyxDQUFDOzRCQUNILEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDcEIsd0JBQWEsQ0FBQyxlQUFlLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLEVBQUUsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFBOzRCQUN2SSxDQUFDO3dCQUNMLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQzs0QkFDeEMsSUFBSSxHQUFHLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUE7NEJBQ3JDLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQyxhQUFhLENBQUM7Z0NBQ2hDLFlBQVksRUFBRSxJQUFJO2dDQUNsQixVQUFVLEVBQUU7b0NBQ1IsYUFBYSxFQUFFLElBQUk7aUNBQ3RCO2dDQUNELDRCQUE0QjtnQ0FDNUIsVUFBVSxFQUFFLEdBQUc7NkJBQ2xCLENBQUMsQ0FBQzs0QkFDSCxJQUFJLE1BQU0sR0FBRyxFQUFFLENBQUM7NEJBQ2hCLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUU7Z0NBQ3hDLE1BQU0sSUFBSSxJQUFJLENBQUMsc0JBQXNCLEdBQUcsR0FBRyxDQUFDOzRCQUNoRCxDQUFDLENBQUMsQ0FBQzs0QkFDSCxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQ3BCLHdCQUFhLENBQUMsZUFBZSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxFQUFFLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQTs0QkFDeEksQ0FBQzt3QkFDTCxDQUFDO3dCQUNELHdGQUF3RjtvQkFDNUYsQ0FBQyxFQUNELFVBQUMsR0FBRztvQkFFSixDQUFDLEVBQ0Q7b0JBRUEsQ0FBQyxDQUNKLENBQUM7Z0JBQ04sQ0FBQztnQkFDRCx3Q0FBZ0IsR0FBaEIsVUFBaUIsS0FBVTtvQkFFdkIsOENBQThDO29CQUM5Qyx1QkFBdUI7b0JBQ3ZCLDZHQUE2RztvQkFDekcsb0VBQW9FO29CQUN4RSx3QkFBd0I7b0JBQ3hCLGlDQUFpQztvQkFDakMsd0ZBQXdGO29CQUV4RixvREFBb0Q7b0JBQ3BELDZDQUE2QztvQkFDN0MseUNBQXlDO29CQUN6QyxlQUFlO29CQUNmLG9CQUFvQjtvQkFDcEIscUNBQXFDO29CQUNyQyxnREFBZ0Q7b0JBQ2hELDRFQUE0RTtvQkFDNUUsMERBQTBEO29CQUMxRCx5REFBeUQ7b0JBRXpELG1CQUFtQjtvQkFFbkIsZUFBZTtvQkFDZixzQkFBc0I7b0JBQ3RCLGlDQUFpQztvQkFDakMsb0JBQW9CO29CQUNwQiwwQ0FBMEM7b0JBQzFDLGFBQWE7b0JBQ2IsOEJBQThCO29CQUM5QixPQUFPO29CQUVQLEdBQUc7b0JBQ0gsc0JBQXNCO2dCQUMxQixDQUFDO2dCQUdELGdDQUFRLEdBQVI7b0JBQUEsaUJBcWVDO29CQW5lRSxZQUFZO29CQUNYLDhDQUE4QztvQkFDOUMsRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO3dCQUNyQyxZQUFZLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQztvQkFDdkMsQ0FBQztvQkFDRCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7d0JBRWhELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLElBQUksRUFBRSxFQUFFLENBQUMsQ0FBQztvQkFDdEQsQ0FBQztvQkFDRCxJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQztvQkFDdEIsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO29CQUN0QixJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQztvQkFFNUIsa0NBQWtDO29CQUVsQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUNsQywrQkFBK0I7d0JBQy9CLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO3dCQUVsQyxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLGNBQWMsQ0FBQzt3QkFDN0Qsd0VBQXdFO3dCQUN4RSxtQ0FBbUM7d0JBRW5DLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7NEJBQ2hELElBQUksS0FBSyxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUM7NEJBRS9DLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLE9BQU8sQ0FBQyxDQUFDOzRCQUM3RCxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztnQ0FDakIsS0FBSyxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQzs0QkFDN0MsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDOzRCQUNkLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQzs0QkFDdEIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO2dDQUMzRyxRQUFRLEdBQUcsTUFBTSxDQUFDOzRCQUN0QixDQUFDOzRCQUNELE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRTtnQ0FDNUIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxRQUFRLENBQUMsQ0FBQyxDQUFDO29DQUV4QixJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztvQ0FDbEIsTUFBTSxDQUFDLEtBQUssQ0FBQztnQ0FDakIsQ0FBQzs0QkFFTCxDQUFDLENBQUMsQ0FBQzs0QkFDSCxJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixHQUFHLENBQUMsRUFBRSxNQUFNLEVBQUUsRUFBRSxFQUFFLE9BQU8sRUFBRSxFQUFFLEVBQUUsUUFBUSxFQUFFLEVBQUUsRUFBRSxHQUFHLEVBQUUsRUFBRSxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsT0FBTyxFQUFFLEVBQUUsRUFBRSxhQUFhLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsV0FBVyxFQUFFLFdBQVcsRUFBRSxTQUFTLEVBQUUsQ0FBQyxDQUFDO3dCQUMzTyxDQUFDO3dCQUNELElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQTt3QkFDMUQsSUFBSSxDQUFDLGVBQWUsR0FBRyxLQUFLLENBQUM7b0JBRWpDLENBQUM7b0JBQ0QsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUNwRCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUN2QixJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUN6RCxDQUFDO29CQUNELElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO29CQUMxQix5SkFBeUo7b0JBRXhKLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzt3QkFDcEIsSUFBSSxDQUFDLFdBQVcsR0FBRyxPQUFPLENBQUM7d0JBQzNCLElBQUksQ0FBQyxTQUFTLEdBQUcsVUFBVSxDQUFDO3dCQUM1QixJQUFJLENBQUMsWUFBWSxHQUFHLGFBQWEsQ0FBQztvQkFJdEMsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixJQUFJLENBQUMsU0FBUyxHQUFHLFVBQVUsQ0FBQzt3QkFDNUIsSUFBSSxDQUFDLFlBQVksR0FBRyxZQUFZLENBQUM7b0JBQ3JDLENBQUM7b0JBR0YsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUN6RSxXQUFXO3dCQUNYLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUN0RCxPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsR0FBRyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7NEJBQ3pCLEtBQUksQ0FBQyxZQUFZLEdBQUcsS0FBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsZ0JBQWdCLENBQUM7NEJBQzlELEtBQUksQ0FBQyxTQUFTLEdBQUcsS0FBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsa0JBQWtCLENBQUM7NEJBQzdELEtBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsWUFBWSxDQUFDOzRCQUMzRCxLQUFJLENBQUMsaUJBQWlCLEdBQUcsS0FBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsZ0JBQWdCLENBQUM7NEJBQ25FLEtBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsY0FBYyxDQUFDO3dCQUVuRSxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUNILDZCQUE2QjtvQkFFN0IsVUFBVTtvQkFDVixJQUFJLFdBQVcsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQztvQkFDM0MsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUM7b0JBQ3JDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsV0FBVyxFQUFFLFNBQVMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7d0JBQ3RFLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUN0RCxPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixJQUFJLGVBQWUsR0FBRyxFQUFFLENBQUM7NEJBQ3pCLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRTtnQ0FDdkIsSUFBSSxPQUFPLEdBQUcsRUFBRSxDQUFDO2dDQUNqQixPQUFPLENBQUMsRUFBRSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7Z0NBQ3hCLE9BQU8sQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQztnQ0FDekIsZUFBZSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQzs0QkFDbEMsQ0FBQyxDQUFDLENBQUM7NEJBQ0gsS0FBSSxDQUFDLE9BQU8sR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDOzRCQUM3QixNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDO2dDQUN0QixxQkFBcUI7Z0NBQ3JCLE1BQU0sRUFBRSxlQUFlO2dDQUN2QixrQkFBa0I7Z0NBQ2xCLFFBQVEsRUFBRSxNQUFNOzZCQUluQixDQUFDLENBQUM7d0JBQ1AsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFPRixJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO29CQUNuRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUVuRCxJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUN0RCxPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsVUFBVSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7NEJBQ2hDLEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxJQUFJLEVBQUUsSUFBSSxLQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksSUFBSSxTQUFTLElBQUksS0FBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQztnQ0FDMUgsSUFBSSxVQUFVLENBQUM7Z0NBQ2YsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsVUFBVSxFQUFFO29DQUN6QixVQUFVLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztvQ0FDeEIsTUFBTSxDQUFDLEtBQUssQ0FBQztnQ0FDakIsQ0FBQyxDQUFDLENBQUM7Z0NBQ0gsS0FBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEdBQUcsVUFBVSxDQUFDOzRCQUM5QyxDQUFDO3dCQUNMLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBR0gsV0FBVztvQkFDWCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDN0MsSUFBSSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDdEQsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDOzRCQUM5QixFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixJQUFJLEVBQUUsSUFBSSxLQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixJQUFJLFNBQVMsSUFBSSxLQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7Z0NBQ3RJLElBQUksTUFBTSxDQUFDO2dDQUNYLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLFFBQVEsRUFBRTtvQ0FDdkIsTUFBTSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7b0NBQ3BCLE1BQU0sQ0FBQyxLQUFLLENBQUM7Z0NBQ2pCLENBQUMsQ0FBQyxDQUFDO2dDQUNILEtBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLEdBQUcsTUFBTSxDQUFDOzRCQUM5QyxDQUFDO3dCQUNMLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBRUgsY0FBYztvQkFDZCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFDbkQsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQ3RELE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEtBQUksQ0FBQyxVQUFVLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzs0QkFDaEMsRUFBRSxDQUFDLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksRUFBRSxJQUFJLEtBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxJQUFJLFNBQVMsSUFBSSxLQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO2dDQUNwSCxJQUFJLEtBQUssQ0FBQztnQ0FDVixNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUksQ0FBQyxVQUFVLEVBQUU7b0NBQ3pCLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO29DQUNuQixNQUFNLENBQUMsS0FBSyxDQUFDO2dDQUNqQixDQUFDLENBQUMsQ0FBQztnQ0FDSCxLQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7NEJBQ3ZDLENBQUM7d0JBQ0wsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFDSCxhQUFhO29CQUNiLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUNsRCxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDdEQsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLFNBQVMsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO3dCQUNuQyxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUNILGVBQWU7b0JBQ2YsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGFBQWEsRUFBRSxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7d0JBQ3JELFlBQVk7d0JBQ1gsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQ3RELE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEtBQUksQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzs0QkFDakMsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDOzRCQUNkLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLFdBQVcsRUFBRTtnQ0FDMUIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxXQUFXLENBQUMsQ0FBQyxDQUFDO29DQUUzQixJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztvQ0FDbEIsTUFBTSxDQUFDLEtBQUssQ0FBQztnQ0FDakIsQ0FBQzs0QkFDTCxDQUFDLENBQUMsQ0FBQzs0QkFDSCxLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDO3dCQUN6RCxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUdILElBQUksUUFBUSxHQUFHLENBQUMsQ0FBQztvQkFDakIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQzdDLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQzt3QkFFZCxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUU7NEJBQzFCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksV0FBVyxDQUFDLENBQUMsQ0FBQztnQ0FFM0IsSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7Z0NBQ2xCLFFBQVEsR0FBRyxDQUFDLENBQUM7Z0NBQ2IsTUFBTSxDQUFDLEtBQUssQ0FBQzs0QkFDakIsQ0FBQzt3QkFDTCxDQUFDLENBQUMsQ0FBQzt3QkFFSCxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxDQUFDLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUUsTUFBTSxFQUFFLFlBQVksRUFBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDO29CQUd6TCxDQUFDO29CQUNELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUM3QyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxDQUFDLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLFNBQVMsRUFBRSxPQUFPLEVBQUUsYUFBYSxFQUFDLE9BQU8sRUFBRSxDQUFDLENBQUE7b0JBQ3pLLENBQUM7b0JBRUQsaUJBQWlCO29CQUNqQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsZUFBZSxFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFDdEQsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQ3RELE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEtBQUksQ0FBQyxhQUFhLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzs0QkFDcEMsWUFBWTs0QkFDWCxJQUFJLElBQUksR0FBRyxFQUFFLENBQUM7NEJBQ2QsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsYUFBYSxFQUFFO2dDQUM1QixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLE1BQU0sQ0FBQyxDQUFDLENBQUM7b0NBRXRCLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO29DQUNsQixNQUFNLENBQUMsS0FBSyxDQUFDO2dDQUNqQixDQUFDOzRCQUVMLENBQUMsQ0FBQyxDQUFDOzRCQUNILEtBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQzt3QkFDOUQsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFDSCxRQUFRO29CQUVSLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUNoRCxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDdEQsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLE9BQU8sR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO3dCQUNqQyxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUNILGFBQWE7b0JBRWIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksRUFBRSxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7d0JBQ25ELFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUN0RCxPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsVUFBVSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7d0JBQ3BDLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsVUFBVTtvQkFDVixJQUFJLFdBQVcsR0FBRSxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQztvQkFDMUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUMzRCxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDdEQsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLE9BQU8sR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO3dCQUNqQyxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUdILFlBQVk7b0JBRVoscUNBQXFDO29CQUNyQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFNBQVMsQ0FDNUQsVUFBQyxJQUFJO3dCQUNGLFlBQVk7d0JBQ1gsRUFBRSxDQUFDLENBQUMsS0FBSSxDQUFDLFNBQVMsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDOzRCQUMxQixNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDOzRCQUN2QyxJQUFJLEdBQUcsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQTs0QkFDckMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLGFBQWEsQ0FBQztnQ0FDL0IsWUFBWSxFQUFFLElBQUk7Z0NBQ2xCLFVBQVUsRUFBRTtvQ0FDUixhQUFhLEVBQUUsSUFBSTtpQ0FDdEI7Z0NBQ0QsNEJBQTRCO2dDQUM1QixVQUFVLEVBQUUsR0FBRzs2QkFFbEIsQ0FBQyxDQUFDOzRCQUNILElBQUksTUFBTSxHQUFHLEVBQUUsQ0FBQzs0QkFDaEIsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRTtnQ0FDeEMsTUFBTSxJQUFJLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxHQUFHLENBQUM7NEJBQ2hELENBQUMsQ0FBQyxDQUFDOzRCQUNILEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDcEIsd0JBQWEsQ0FBQyxlQUFlLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLEVBQUUsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFBOzRCQUN2SSxDQUFDO3dCQUNMLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQzs0QkFDeEMsSUFBSSxHQUFHLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUE7NEJBQ3JDLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQyxhQUFhLENBQUM7Z0NBQ2hDLFlBQVksRUFBRSxJQUFJO2dDQUNsQixVQUFVLEVBQUU7b0NBQ1IsYUFBYSxFQUFFLElBQUk7aUNBQ3RCO2dDQUNELDRCQUE0QjtnQ0FDNUIsVUFBVSxFQUFFLEdBQUc7NkJBQ2xCLENBQUMsQ0FBQzs0QkFDSCxJQUFJLE1BQU0sR0FBRyxFQUFFLENBQUM7NEJBQ2hCLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUU7Z0NBQ3hDLE1BQU0sSUFBSSxJQUFJLENBQUMsc0JBQXNCLEdBQUcsR0FBRyxDQUFDOzRCQUNoRCxDQUFDLENBQUMsQ0FBQzs0QkFDSCxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQ3BCLHdCQUFhLENBQUMsZUFBZSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxFQUFFLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQTs0QkFDeEksQ0FBQzt3QkFDTCxDQUFDO29CQUNMLENBQUMsRUFDRCxVQUFDLEdBQUc7b0JBRUosQ0FBQyxFQUNEO29CQUVBLENBQUMsQ0FDSixDQUFDO29CQUVGLDhDQUE4QztvQkFDL0MsaURBQWlEO29CQUNoRCxJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUM7b0JBRXBCLGNBQWM7b0JBQ2QsTUFBTSxDQUFDLHlDQUF5QyxDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO29CQUN0RSxNQUFNLENBQUMsc0NBQXNDLENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ25FLHNCQUFzQjtnQkFFMUIsQ0FBQztnQkFoa0VNLHFCQUFPLEdBQUcsQ0FBQyxRQUFRLEVBQUUsV0FBVyxFQUFFLGVBQWUsQ0FBQyxDQUFDO2dCQXZEOUQ7b0JBQUMsZ0JBQVMsQ0FBQzt3QkFFUCxXQUFXLEVBQUUsNkNBQTZDO3dCQUMxRCxVQUFVLEVBQUUsQ0FBQyxpQkFBUSxFQUFFLHFCQUFZLEVBQUUsd0JBQWUsRUFBRSx1QkFBdUIsRUFBRSx3QkFBZSxFQUFFLHdCQUFlLEVBQUUsMEJBQVEsQ0FBQzt3QkFDMUgsU0FBUyxFQUFFLENBQUMsaUNBQWUsRUFBRSxpQ0FBZSxDQUFDO3FCQUNoRCxDQUFDOztpQ0FBQTtnQkFtbkVGLG9CQUFDO1lBQUQsQ0FqbkVBLEFBaW5FQyxJQUFBO1lBam5FRCx5Q0FpbkVDLENBQUEiLCJmaWxlIjoiYW1heC9DdXN0b21lck5vdGVzL0N1c3RvbWVyTm90ZXMuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge05nU3dpdGNoLCBOZ1N3aXRjaFdoZW4sIE5nU3dpdGNoRGVmYXVsdCwgQ09SRV9ESVJFQ1RJVkVTLCBGT1JNX0RJUkVDVElWRVN9IGZyb20gJ2FuZ3VsYXIyL2NvbW1vbidcclxuaW1wb3J0IHtSZXNvdXJjZVNlcnZpY2V9IGZyb20gXCIuLi8uLi9zZXJ2aWNlcy9SZXNvdXJjZVNlcnZpY2VcIjtcclxuaW1wb3J0IHtSb3V0ZVBhcmFtc30gZnJvbSBcImFuZ3VsYXIyL3JvdXRlclwiO1xyXG5pbXBvcnQge0NvbXBvbmVudCwgT3V0cHV0LCBJbnB1dCwgRXZlbnRFbWl0dGVyLCBPbkluaXR9IGZyb20gXCJhbmd1bGFyMi9jb3JlXCI7XHJcbmltcG9ydCB7Q3VzdG9tZXJTZXJ2aWNlfSBmcm9tIFwiLi4vLi4vc2VydmljZXMvQ3VzdG9tZXJTZXJ2aWNlXCI7XHJcbmltcG9ydCB7IGpzb25RIH0gZnJvbSAnLi4vLi4vanNvblEnO1xyXG5pbXBvcnQge0dyb3VwRmlsdGVyUGlwZSwgR3JvdXBQYXJlbkZpbHRlclBpcGUsIEtlbmRvX3V0aWxpdHl9IGZyb20gXCIuLi8uLi9hbWF4VXRpbFwiO1xyXG5pbXBvcnQge0F1dG9jb21wbGV0ZUNvbnRhaW5lcn0gZnJvbSAnLi4vLi4vYXV0b2NvbXBsZXRlL2F1dG9jb21wbGV0ZS1jb250YWluZXInO1xyXG5pbXBvcnQge0F1dG9jb21wbGV0ZX0gZnJvbSAnLi4vLi4vYXV0b2NvbXBsZXRlL2F1dG9jb21wbGV0ZS5jb21wb25lbnQnO1xyXG5pbXBvcnQgeyBBbWF4RGF0ZSB9IGZyb20gJy4uLy4uL2NvbW9uQ29tcG9uZW50cy9iYXNpY0NvbXBvbmVudHMnO1xyXG5cclxuZXhwb3J0IGNvbnN0IEFVVE9DT01QTEVURV9ESVJFQ1RJVkVTID0gW0F1dG9jb21wbGV0ZSwgQXV0b2NvbXBsZXRlQ29udGFpbmVyXTtcclxuZGVjbGFyZSB2YXIgalF1ZXJ5O1xyXG5kZWNsYXJlIHZhciBzd2FsO1xyXG5kZWNsYXJlIHZhciBtb21lbnQ7XHJcbkBDb21wb25lbnQoe1xyXG5cclxuICAgIHRlbXBsYXRlVXJsOiAnLi9hcHAvYW1heC9DdXN0b21lci90ZW1wbGF0ZXMvY3VzdG9tZXIuaHRtbCcsXHJcbiAgICBkaXJlY3RpdmVzOiBbTmdTd2l0Y2gsIE5nU3dpdGNoV2hlbiwgTmdTd2l0Y2hEZWZhdWx0LCBBVVRPQ09NUExFVEVfRElSRUNUSVZFUywgQ09SRV9ESVJFQ1RJVkVTLCBGT1JNX0RJUkVDVElWRVMsIEFtYXhEYXRlXSxcclxuICAgIHByb3ZpZGVyczogW0N1c3RvbWVyU2VydmljZSwgUmVzb3VyY2VTZXJ2aWNlXVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEFtYXhDdXN0b21lcnMgaW1wbGVtZW50cyBPbkluaXQge1xyXG4gICAgbW9kZWxJbnB1dCA9IHt9O1xyXG4gICAgVGVtcG1vZGVsSW5wdXQgPSB7fTtcclxuICAgIGN1c3RTZWFyY2hEYXRhOiBPYmplY3QgPSBbXTtcclxuICAgIFJFUzogT2JqZWN0ID0ge307XHJcbiAgICBTZWxlY3RlZFBoVHlwZTogT2JqZWN0ID0ge307XHJcbiAgICB0ZW1wc3RyZWV0bXNnOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgRm9ybXR5cGU6IHN0cmluZyA9XCJDVVNUT01FUl9NQVNURVJcIjtcclxuICAgIExhbmc6IHN0cmluZz1cIlwiO1xyXG4gICAgLy9tb2RlbElucHV0LmxuYW1lPSBcIlwiO1xyXG4gICAgU2hvd01vcmU6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIElzUmVjb3JkRWRpdE1vZGU6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIFNob3dNb3JlVGV4dDogc3RyaW5nID0gXCJNb3JlXCI7XHJcblxyXG4gICAgU2hvd0xvYWRlcjogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgU2hvd01zZzogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgU2hvd0dyb3VwczogYm9vbGVhbiA9IHRydWU7XHJcbiAgICBHcm91cFRleHQ6IHN0cmluZz1cIlNob3cgR3JvdXBzXCI7XHJcbiAgICBNc2c6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBNc2dDbGFzczogc3RyaW5nID0gXCJ0ZXh0LXByaW1hcnlcIjtcclxuICAgIElzYnRuZGlzYWJsZTogc3RyaW5nID0gXCJcIjtcclxuICAgIElzRmlsZUFzU2F2ZUJ0bjogc3RyaW5nID0gXCJcIjtcclxuICAgIElzRmlsZUFzQ2FuY2VsQnRuOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgbGFuZ3VhZ2VBcnJheSA9IFtdO1xyXG5cclxuICAgIEFkZHJlc3M6IE9iamVjdCA9IHt9O1xyXG4gICAgUGhvbmVNb2RlbDogT2JqZWN0ID0ge307XHJcbiAgICBFbWFpbE1vZGVsOiBPYmplY3QgPSB7fTtcclxuICAgIElzU2hvd0FsbDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgQ3VzdExpc3Q6IE9iamVjdCA9IHt9O1xyXG4gICAgU0FWRV9CVE5fVEVYVDogc3RyaW5nID0gXCJcIjtcclxuICAgIFxyXG4gICAgQlROX1BIQUREOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgRWRpdFBob25lRGF0YTogT2JqZWN0ID0ge307XHJcbiAgICBFZGl0QWRkcmVzc0RhdGE6IE9iamVjdCA9IHt9O1xyXG4gICAgRWRpdEVtYWlsRGF0YTogT2JqZWN0ID0ge307XHJcbiAgICBhZElkOiBzdHJpbmc7XHJcbiAgICBJc0ZpbGVBc09wZW46IGJvb2xlYW47XHJcbiAgICBBRERfTkVXX0NVU1RfVEVYVDogc3RyaW5nO1xyXG4gICAgQ1NTVEVYVDogc3RyaW5nO1xyXG4gICAgSXNGaWxlQXN0eHRTaG93OiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBGSUxFQVNfQlROX1RFWFQ6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBjc3NGaWxlQXNCdG46IHN0cmluZyA9IFwiXCI7XHJcbiAgICBJc0NhbmNlbDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgU2VhcmNoVmFsOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgRW50ZXJDb3VudDogbnVtYmVyID0gMDtcclxuICAgIFN0b3BUaW1lT3V0OiBhbnk7XHJcbiAgICBDdXN0SWRUZXh0OiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgc3RhdGljICRpbmplY3QgPSBbJyRzY29wZScsICckbG9jYXRpb24nLCAnJGFuY2hvclNjcm9sbCddO1xyXG4gICAgQmFzZUFwcFVybDogc3RyaW5nID0gXCJcIjtcclxuICAgIFBoSW5kZXg6IG51bWJlciA9IDA7XHJcbiAgICBLZW5kb1JUTENTUzogc3RyaW5nID0gXCJcIjtcclxuICAgIENIQU5HRURJUjogc3RyaW5nID0gXCJcIjtcclxuICAgIENoYW5nZURpYWxvZzogc3RyaW5nID0gXCJcIjtcclxuICAgIC8vSXNGaWxlQXNTYXZlOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBcclxuICAgIC8vRW1haWw6IHN0cmluZyA9IFwiXCI7XHJcbiAgICAvL0N1c3RvbWVyRW1haWw6IE9iamVjdCA9IHt9O1xyXG4gICAgLy9tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzID0gW107XHJcbiAgICBcclxuICAgIF9DdXN0VHlwZXMgPSBbXTtcclxuICAgIF9Tb3VyY2VzID0gW107XHJcbiAgICBfRW1wbG95ZWVzID0gW107XHJcbiAgICBfU3VmZml4ZXMgPSBbXTtcclxuICAgIF9QaG9uZVR5cGVzID0gW107XHJcbiAgICBfQWRkcmVzc1R5cGVzID0gW107XHJcbiAgICBfR3JvdXBzID0gW107XHJcbiAgICBfQ291bnRyaWVzID0gW107XHJcbiAgICBfU3RhdGVzID0gW107XHJcbiAgICBfQ2l0aWVzID0gW107XHJcblxyXG4gICAgcHJpdmF0ZSBzZWxlY3RlZENhcjogc3RyaW5nID0gJyc7XHJcbiAgICBwcml2YXRlIGFzeW5jU2VsZWN0ZWRDYXI6IHN0cmluZyA9ICcnO1xyXG4gICAgcHJpdmF0ZSBhdXRvY29tcGxldGVMb2FkaW5nOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwcml2YXRlIGF1dG9jb21wbGV0ZU5vUmVzdWx0czogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHJpdmF0ZSBhdXRvY29tcGxldGVTZWxlY3Q6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIFxyXG4gICAgcHJpdmF0ZSBnZXRDdXJyZW50Q29udGV4dCgpIHtcclxuICAgICAgICBcclxuICAgICAgICByZXR1cm4gdGhpcztcclxuICAgIH1cclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgX3Jlc291cmNlU2VydmljZTogUmVzb3VyY2VTZXJ2aWNlLCBwcml2YXRlIF9jdXN0b21lclNlcnZpY2U6IEN1c3RvbWVyU2VydmljZSwgcHJpdmF0ZSBfcm91dGVQYXJhbXM6IFJvdXRlUGFyYW1zKSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkJpcnRoRGF0ZSA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzID0gW107XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzID0gW107XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzID0gW107XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyR3JvdXBzID0gW107XHJcbiAgICAgICAgdGhpcy5BZGRyZXNzLkNvdW50cnlDb2RlPVwiXCI7XHJcbiAgICAgICAgdGhpcy5BZGRyZXNzLlN0YXRlSWQgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5lbXBsb3llZWlkID0gXCJcIjtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJUeXBlID0gXCJcIjtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ2FtZUZyb21DdXN0b21lciA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LlNhZml4aWQgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5HZW5kZXIgPSBcIjBcIjtcclxuICAgICAgICB0aGlzLlBob25lTW9kZWwuUGhvbmVUeXBlSWQgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUiA9IHt9O1xyXG4gICAgICAgIHRoaXMuSXNTaG93QWxsID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5TQVZFX0JUTl9URVhUID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9CVE5fU0FWRTtcclxuICAgICAgICB0aGlzLkJUTl9QSEFERCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfQlROX1BIQUREO1xyXG4gICAgICAgIHRoaXMuQUREX05FV19DVVNUX1RFWFQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0xCTF9ORVdfQ1VTVDtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMgPSBbeyBFbWFpbDogXCJcIiwgRW1haWxOYW1lOiBcIlwiLCBOZXdzbGV0dGVyZTogdHJ1ZSwgcHVibGlzaDogMSwgTmV3c09yZGVyOiBcIk5ld3MxXCIsIEVQdWJsaXNoT3JkZXI6XCJFUHViMVwiIH1dXHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzID0gW3sgUGhvbmVUeXBlSWQ6IFwiXCIsIFByZWZpeDogXCJcIiwgQXJlYTogXCJcIiwgUGhvbmU6IFwiXCIsIElzU21zOiAxLCBDb21tZW50czogXCJcIiwgSXNTaG93UmVtYXJrczogZmFsc2UsIHBocHVibGlzaDogMSwgU01TT3JkZXI6IFwiU01TMVwiLFB1Ymxpc2hPcmRlcjogXCJQdWIxXCJ9XVxyXG4gICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAgdmFyIGVtcGlkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJlbXBsb3llZWlkXCIpO1xyXG4gICAgICAgIFxyXG4gICAgICAgIHZhciBjY29kZSA9IHRoaXMuX3Jlc291cmNlU2VydmljZS5nZXRDb29raWUoZW1waWQgKyBcImNjb2RlXCIpO1xyXG4gICAgICAgIGlmIChjY29kZS5sZW5ndGggPiAwKVxyXG4gICAgICAgICAgICBjY29kZSA9IGNjb2RlLnN1YnN0cmluZygxLCBjY29kZS5sZW5ndGgpO1xyXG5cclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMgPSBbe1xyXG4gICAgICAgICAgICBTdHJlZXQ6IFwiXCIsIFN0cmVldDI6IFwiXCIsIENpdHlOYW1lOiBcIlwiLCBaaXA6IFwiXCIsIENvdW50cnlDb2RlOiBjY29kZSwgU3RhdGVJZDogXCJcIiwgQWRkcmVzc1R5cGVJZDogXCJcIixcclxuICAgICAgICAgICAgRm9yRGVsaXZlcnk6IHRydWUsIE1haW5BZGRyZXNzOiB0cnVlLCBNYWluT3JkZXI6IFwiTWFpbkFkZHIxXCIsIERlbHZyeU9yZGVyOiBcIkRlbHZyeTFcIlxyXG4gICAgICAgIH1dXHJcblxyXG4gICAgICAgIFxyXG4gICAgICAgIFxyXG5cclxuICAgICAgICB2YXIgY3VzdHR5cGUgPSB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZ2V0Q29va2llKGVtcGlkICsgXCJjdXN0XCIpO1xyXG4gICAgICAgIGlmIChjdXN0dHlwZS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICBjdXN0dHlwZSA9IGN1c3R0eXBlLnN1YnN0cmluZygxLCBjdXN0dHlwZS5sZW5ndGgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJUeXBlID0gY3VzdHR5cGU7XHJcblxyXG5cclxuICAgICAgICB2YXIgZW1wID0gdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmdldENvb2tpZShlbXBpZCArIFwiZW1wXCIpO1xyXG4gICAgICAgIGlmIChlbXAubGVuZ3RoID4gMClcclxuICAgICAgICAgICAgZW1wID0gZW1wLnN1YnN0cmluZygxLCBlbXAubGVuZ3RoKTtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuZW1wbG95ZWVpZCA9IGVtcDtcclxuXHJcbiAgICAgICAgdmFyIHNvdXJjZSA9IHRoaXMuX3Jlc291cmNlU2VydmljZS5nZXRDb29raWUoZW1waWQgKyBcInNyY1wiKTtcclxuICAgICAgICBpZiAoc291cmNlLmxlbmd0aCA+IDApXHJcbiAgICAgICAgICAgIHNvdXJjZSA9IHNvdXJjZS5zdWJzdHJpbmcoMSwgc291cmNlLmxlbmd0aCk7XHJcbiAgICAgICAgZWxzZSB7XHJcblxyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ2FtZUZyb21DdXN0b21lciA9IHNvdXJjZTtcclxuICAgICAgICB0aGlzLkNTU1RFWFQgPSBcIm1kaS1jb250ZW50LWFkZFwiO1xyXG4gICAgICAgIHRoaXMuY3NzRmlsZUFzQnRuID0gXCJtZGktY29udGVudC1jcmVhdGVcIjtcclxuICAgICAgICB0aGlzLklzRmlsZUFzdHh0U2hvdyA9IGZhbHNlO1xyXG4gICAgICAgIGNsZWFyVGltZW91dCh0aGlzLlN0b3BUaW1lT3V0KTtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCA9IF9yb3V0ZVBhcmFtcy5wYXJhbXMuSWQ7XHJcbiAgICAgICAgdGhpcy5CYXNlQXBwVXJsID0gX3Jlc291cmNlU2VydmljZS5BcHBVcmw7XHJcbiAgICAgICAgdGhpcy5UZW1wbW9kZWxJbnB1dCA9IHRoaXMubW9kZWxJbnB1dDtcclxuICAgICAgICBcclxuICAgICAgICAvL2FsZXJ0KHRoaXMuX3Jlc291cmNlU2VydmljZS5nZXRDb29raWUoZW1waWQgKyBcImN1c3RcIikpO1xyXG4gICAgICAgIC8vdGhpcy5TaG93TW9yZVRleHQgPSBcIk1vcmVcIjtcclxuICAgICAgICBcclxuICAgIH1cclxuICAgIHByaXZhdGUgX2NhY2hlZFJlc3VsdDogYW55O1xyXG4gICAgcHJpdmF0ZSBfcHJldmlvdXNhc3luY1NlbGVjdGVkQ2FyOiBzdHJpbmc9Jyc7XHJcbiAgICBcclxuICAgIGRhdGVTZWxlY3Rpb25DaGFuZ2UoZXZ0KSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coZXZ0KTtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQmlydGhEYXRlID0gZXZ0O1xyXG4gICAgICAgLy8gYWxlcnQodGhpcy5tb2RlbElucHV0LkJpcnRoRGF0ZSk7XHJcbiAgICAgICAgLy90aGlzLnZhbGlkYXRlTG9naW4oKTtcclxuICAgIH1cclxuXHJcbiAgIHByaXZhdGUgZ2V0QXN5bmNEYXRhKGNvbnRleHQ6IGFueSk6IEZ1bmN0aW9uIHtcclxuICAgICAgICBcclxuICAgICAgIHZhciBTcmNoVmFsID0gY29udGV4dC5hc3luY1NlbGVjdGVkQ2FyO1xyXG4gICAgICBcclxuICAgICAgLy8gaWYgKFNyY2hWYWwgIT0gdW5kZWZpbmVkICYmIFNyY2hWYWwgIT0gbnVsbCAmJiBTcmNoVmFsICE9IFwiXCIpIHtcclxuXHJcbiAgICAgICBcclxuICAgICAgICAgIC8vIGRlYnVnZ2VyO1xyXG4gICAgICAgaWYgKHRoaXMuX3ByZXZpb3VzYXN5bmNTZWxlY3RlZENhciA9PSBjb250ZXh0LmFzeW5jU2VsZWN0ZWRDYXIpIHtcclxuICAgICAgICAgICAgICAgLy9jbGVhclRpbWVvdXQodGhpcy5TdG9wVGltZU91dCk7XHJcbiAgICAgICAgICAgICAgIHJldHVybiB0aGlzLl9jYWNoZWRSZXN1bHQ7XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgLy9hbGVydCh0aGlzLl9wcmV2aW91c2FzeW5jU2VsZWN0ZWRDYXIgKyBcIiB8IFwiICsgY29udGV4dC5hc3luY1NlbGVjdGVkQ2FyKTtcclxuICAgICAgICAgICAgICAgaWYgKGNvbnRleHQuYXN5bmNTZWxlY3RlZENhciAhPSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICB0aGlzLl9wcmV2aW91c2FzeW5jU2VsZWN0ZWRDYXIgPSBjb250ZXh0LmFzeW5jU2VsZWN0ZWRDYXI7XHJcbiAgICAgICAgICAgICAgICAgLy8gIHRoaXMuU3RvcFRpbWVPdXQgPSBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgIC8vICAgIGFsZXJ0KFNyY2hWYWwpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRDb21wbGV0ZVNlYXJjaChTcmNoVmFsKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vYWxlcnQocmVzcG9uc2UuRXJyTXNnKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe21lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRleHQuY2Fyc0V4YW1wbGUxID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vcmV0dXJuIGNvbnRleHQuY2Fyc0V4YW1wbGUxO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgLy8gfSwgNTAwKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICB0aGlzLl9jYWNoZWRSZXN1bHQgPSBjb250ZXh0LmNhcnNFeGFtcGxlMTtcclxuICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgIHRoaXMuX2NhY2hlZFJlc3VsdCA9IFtdO1xyXG4gICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgIHJldHVybiB0aGlzLl9jYWNoZWRSZXN1bHQ7XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgICAgIFxyXG4gICAgICAgIFxyXG4gICAgfVxyXG4gICBcclxuICAgIHByaXZhdGUgY2hhbmdlQXV0b2NvbXBsZXRlTG9hZGluZyhlOiBib29sZWFuKSB7XHJcbiAgICAgICAgdGhpcy5hdXRvY29tcGxldGVMb2FkaW5nID0gZTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIGNoYW5nZUF1dG9jb21wbGV0ZU5vUmVzdWx0cyhlOiBib29sZWFuKSB7XHJcbiAgICAgICAgdGhpcy5hdXRvY29tcGxldGVTZWxlY3QgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLmF1dG9jb21wbGV0ZU5vUmVzdWx0cyA9IGU7XHJcbiAgICB9XHJcbiAgICBwcml2YXRlIGF1dG9jb21wbGV0ZU9uU2VsZWN0KGU6IGFueSkge1xyXG4gICAgICAgIHRoaXMuYXV0b2NvbXBsZXRlU2VsZWN0ID0gdHJ1ZTtcclxuICAgICAgICBjb25zb2xlLmxvZyhgU2VsZWN0ZWQgdmFsdWU6ICR7ZS5pdGVtfWApO1xyXG4gICAgICAgIHZhciBDb21wRGF0YSA9IGUuaXRlbS5zcGxpdCgnfCcpO1xyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgaWYgKGUuaXRlbSAhPSB1bmRlZmluZWQgJiYgZS5pdGVtICE9IFwiXCIgJiYgZS5pdGVtICE9IG51bGwpIHtcclxuICAgICAgICAgICAgLy9hbGVydChDb21wRGF0YVswXSk7XHJcbiAgICAgICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRDb21wbGV0ZUN1c3REZXQoQ29tcERhdGFbMF0udHJpbSgpKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAvL2FsZXJ0KHJlc3BvbnNlLkVyck1zZyk7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7bWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgICAgLy8gYWxlcnQodGhpcy5tb2RlbElucHV0LkJpcnRoRGF0ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5TQVZFX0JUTl9URVhUID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9CVE5fVVBEQVRFO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuQUREX05FV19DVVNUX1RFWFQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0xCTF9VUERBVEVfQ1VTVDtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLkNTU1RFWFQgPSBcIm1kaS1jb250ZW50LWNyZWF0ZVwiO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMubGVuZ3RoID09IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzID0gW3sgRW1haWw6IFwiXCIsIEVtYWlsTmFtZTogdGhpcy5tb2RlbElucHV0LkZpbGVBcywgTmV3c2xldHRlcmU6IGZhbHNlIH1dXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXMubGVuZ3RoID09IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHBoaWQgPSBcIlwiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLl9QaG9uZVR5cGVzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5UZXh0ID09IFwiQ2VsbFBob25lXCIpIHtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGhpZCA9IHRoaXMuVmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lcyA9IFt7IFBob25lVHlwZUlkOiBwaGlkLCBQcmVmaXg6IFwiXCIsIEFyZWE6IFwiXCIsIFBob25lOiBcIlwiLCBJc1NtczogMCwgQ29tbWVudHM6IFwiXCIsIHBocHVibGlzaDogMCB9XTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMubGVuZ3RoID09IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGVtcGlkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJlbXBsb3llZWlkXCIpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGNjb2RlID0gdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmdldENvb2tpZShlbXBpZCArIFwiY2NvZGVcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChjY29kZS5sZW5ndGggPiAwKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2NvZGUgPSBjY29kZS5zdWJzdHJpbmcoMSwgY2NvZGUubGVuZ3RoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGFkaWQgPSBcIlwiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgY29tcHRleHQgPSBcIkhvbWVcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5Db21wYW55ICE9IFwiXCIgJiYgdGhpcy5tb2RlbElucHV0LkNvbXBhbnkgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dC5Db21wYW55ICE9IG51bGwpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbXB0ZXh0ID0gXCJXb3JrXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5fQWRkcmVzc1R5cGVzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5UZXh0ID09IGNvbXB0ZXh0KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWRpZCA9IHRoaXMuVmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3NlcyA9IFt7IFN0cmVldDogXCJcIiwgU3RyZWV0MjogXCJcIiwgQ2l0eU5hbWU6IFwiXCIsIFppcDogXCJcIiwgQ291bnRyeUNvZGU6IGNjb2RlLCBTdGF0ZUlkOiBcIlwiLCBBZGRyZXNzVHlwZUlkOiBhZGlkLCBGb3JEZWxpdmVyeTogZmFsc2UsIE1haW5BZGRyZXNzOiBmYWxzZSB9XTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuQ3VzdElkVGV4dCA9IFwiKCBcIiArIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkICsgXCIgKVwiO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuSXNGaWxlQXN0eHRTaG93ID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgLy90aGlzLklzQ2FuY2VsID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICAvL3RoaXMuSGlkZVNob3dGaWxlQXN0eHQoKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLkNhbmNlbEZpbGVBc3R4dCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuSXNTaG93QWxsID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICAvL3RoaXMuYmluZEdyb3VwKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9hbGVydCh0aGlzLlJFUyk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5iaW5kR3JvdXBUcmVlKHRydWUpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIE9wZW5OZXdSZWNlaXB0KCkge1xyXG4gICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkICE9IHVuZGVmaW5lZCAmJiB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCA+PSAwKSB7XHJcbiAgICAgICAgICAgIHZhciBjdXN0SWQgPSB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZDtcclxuICAgICAgICAgICAgaWYgKGN1c3RJZCAhPSAtMSkge1xyXG4gICAgICAgICAgICAgICAgdmFyIGVtaWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImVtcGxveWVlaWRcIik7XHJcbiAgICAgICAgICAgICAgICBkb2N1bWVudC5sb2NhdGlvbiA9IHRoaXMuQmFzZUFwcFVybCArIFwiUmVjZWlwdFNlbGVjdC9cIiArIGVtaWQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBPcGVuQ2hhcmdlQ3JlZGl0UGFnZSgpIHtcclxuICAgICAgICB0aGlzLklzYnRuZGlzYWJsZSA9IFwiZGlzYWJsZWRcIjtcclxuICAgICAgICB0aGlzLl9jdXN0b21lclNlcnZpY2UuQ2hlY2tJc09wZW5DaGFyZ2UoKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgXHJcblxyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczogeyAgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gfX0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5EYXRhICE9IHVuZGVmaW5lZCAmJiByZXNwb25zZS5EYXRhICE9IG51bGwgJiYgcmVzcG9uc2UuRGF0YS5sZW5ndGggPT0gMSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBjdXN0SWQgPSAtMTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5UZW1wbW9kZWxJbnB1dCAhPSB1bmRlZmluZWQgJiYgdGhpcy5UZW1wbW9kZWxJbnB1dC5DdXN0b21lcklkICE9IHVuZGVmaW5lZCAmJiB0aGlzLlRlbXBtb2RlbElucHV0LkN1c3RvbWVySWQgPj0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjdXN0SWQgPSB0aGlzLlRlbXBtb2RlbElucHV0LkN1c3RvbWVySWRcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dCAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkID49IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY3VzdElkID0gdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWRcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGN1c3RJZCAhPSAtMSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBkb2N1bWVudC5sb2NhdGlvbiA9IHRoaXMuQmFzZUFwcFVybCArIFwiQ2hhcmdlQ3JlZGl0L1wiICsgY3VzdElkICsgXCIvXCIgKyByZXNwb25zZS5EYXRhWzBdLlZhbHVlO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogJ1BsZWFzZSBzYXZlIG5ldyBvciBsb2FkIHByZXZpb3VzIGN1c3RvbWVyIGFuZCB0aGVuIGNsaWNrIG9uIGNoYXJnZSBjcmVkaXQgYnV0dG9uJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIGlmIChyZXNwb25zZS5EYXRhICE9IHVuZGVmaW5lZCAmJiByZXNwb25zZS5EYXRhICE9IG51bGwgJiYgcmVzcG9uc2UuRGF0YS5sZW5ndGggPiAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgY3VzdElkID0gLTE7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuVGVtcG1vZGVsSW5wdXQgIT0gdW5kZWZpbmVkICYmIHRoaXMuVGVtcG1vZGVsSW5wdXQuQ3VzdG9tZXJJZCAhPSB1bmRlZmluZWQgJiYgdGhpcy5UZW1wbW9kZWxJbnB1dC5DdXN0b21lcklkID49IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY3VzdElkID0gdGhpcy5UZW1wbW9kZWxJbnB1dC5DdXN0b21lcklkXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkICE9IHVuZGVmaW5lZCAmJiB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCA+PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGN1c3RJZCA9IHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChjdXN0SWQgIT0gLTEpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZG9jdW1lbnQubG9jYXRpb24gPSB0aGlzLkJhc2VBcHBVcmwgKyBcIlRlcm1pbmFscy9TaG93L1wiICsgY3VzdElkO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiAnUGxlYXNlIHNhdmUgbmV3IG9yIGxvYWQgcHJldmlvdXMgY3VzdG9tZXIgYW5kIHRoZW4gY2xpY2sgb24gY2hhcmdlIGNyZWRpdCBidXR0b24nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAvLyBhbGVydChyZXNwb25zZS5EYXRhLmxlbmd0aCArICcgVGVybWluYWwgU2NyZWVuIGhlbGxvJyk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9NU0dfQ0hBUkdFQ1JFRElULFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0aGlzLlNob3dNc2cgPSB0cnVlO1xyXG4gICAgICAgICAgICB0aGlzLk1zZyA9IHJlc3BvbnNlLkVyck1zZztcclxuICAgICAgICB9LFxyXG4gICAgICAgICAgICBlcnJvcj0+IGNvbnNvbGUubG9nKGVycm9yKSxcclxuICAgICAgICAgICAgKCkgPT4gY29uc29sZS5sb2coXCJTYXZlIENhbGwgQ29tcGxlYXRlZFwiKVxyXG4gICAgICAgICk7XHJcbiAgICAgICAgdGhpcy5Jc2J0bmRpc2FibGUgPSBcIlwiO1xyXG4gICAgfVxyXG4gICAgU3RvcFRpbWVyKCk6IG9ic2VydmFibGUge1xyXG4gICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICBtZXNzYWdlOiAnRnJvbSBTdG9wIFRpbWVyJyArIHRoaXMuU3RvcFRpbWVPdXQsIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgICAgICBjbGVhclRpbWVvdXQodGhpcy5TdG9wVGltZU91dCk7XHJcbiAgICB9XHJcbiAgICBTZXRkZWZhdWx0UGFnZSgpe1xyXG4gICAgICAgIGRvY3VtZW50LmxvY2F0aW9uID0gdGhpcy5CYXNlQXBwVXJsICsgXCJDdXN0b21lci9BZGQvLTFcIjtcclxuICAgICAgICB0aGlzLklzRmlsZUFzdHh0U2hvdyA9IHRydWU7XHJcbiAgICAgICAgdGhpcy5Jc0NhbmNlbCA9IHRydWU7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdmFyIGVtcGlkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJlbXBsb3llZWlkXCIpO1xyXG4gICAgICAgIHRoaXMuYXN5bmNTZWxlY3RlZENhciA9IFwiXCI7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0ID0ge307XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkJpcnRoRGF0ZSA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQgPSAtMTtcclxuICAgICAgICB0aGlzLkN1c3RJZFRleHQgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMuSGlkZVNob3dGaWxlQXN0eHQoKTtcclxuICAgICAgICB2YXIgY3VzdHR5cGUgPSB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZ2V0Q29va2llKGVtcGlkICsgXCJjdXN0XCIpO1xyXG4gICAgICAgIGlmIChjdXN0dHlwZS5sZW5ndGggPiAwKVxyXG4gICAgICAgICAgICBjdXN0dHlwZSA9IGN1c3R0eXBlLnN1YnN0cmluZygxLCBjdXN0dHlwZS5sZW5ndGgpO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclR5cGUgPSBjdXN0dHlwZTtcclxuICAgICAgICB2YXIgZW1wID0gdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmdldENvb2tpZShlbXBpZCArIFwiZW1wXCIpO1xyXG4gICAgICAgIGlmIChlbXAubGVuZ3RoID4gMClcclxuICAgICAgICAgICAgZW1wID0gZW1wLnN1YnN0cmluZygxLCBlbXAubGVuZ3RoKTtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuZW1wbG95ZWVpZCA9IGVtcDtcclxuICAgICAgICB2YXIgc291cmNlID0gdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmdldENvb2tpZShlbXBpZCArIFwic3JjXCIpO1xyXG4gICAgICAgIGlmIChzb3VyY2UubGVuZ3RoID4gMClcclxuICAgICAgICAgICAgc291cmNlID0gc291cmNlLnN1YnN0cmluZygxLCBzb3VyY2UubGVuZ3RoKTtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ2FtZUZyb21DdXN0b21lciA9IHNvdXJjZTtcclxuXHJcbiAgICAgICAgdGhpcy5TaG93TW9yZSA9IGZhbHNlO1xyXG4gICAgICAgIC8vdGhpcy5TaG93TW9yZVRleHQgPSBcIk1vcmVcIjsgXHJcbiAgICAgICAgdGhpcy5TaG93TW9yZVRleHQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0xOS19MQkxfTU9SRTtcclxuICAgICAgICB0aGlzLlNBVkVfQlROX1RFWFQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0JUTl9TQVZFO1xyXG4gICAgICAgIHRoaXMuQ1NTVEVYVCA9IFwibWRpLWNvbnRlbnQtYWRkXCI7XHJcbiAgICAgICAgdGhpcy5BRERfTkVXX0NVU1RfVEVYVCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfTEJMX05FV19DVVNUO1xyXG4gICAgICAgIHRoaXMuU2hvd0dyb3VwcyA9IHRydWU7XHJcbiAgICAgICAgdGhpcy5zaG93aGlkZUdyb3VwcygpO1xyXG4gICAgICAgIC8vdGhpcy5Hcm91cFRleHQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0xCTF9TSE9XR1JPVVBTO1xyXG5cclxuICAgICAgICBcclxuXHJcbiAgICAgICAgdmFyIHBoaWQgPSBcIlwiO1xyXG4gICAgICAgIHZhciBTTVMgPSAwO1xyXG4gICAgICAgIHZhciBwdWJsaXNoID0gMDtcclxuICAgICAgICB2YXIgZXB1Ymxpc2ggPSAwO1xyXG4gICAgICAgIGpRdWVyeS5lYWNoKHRoaXMuX1Bob25lVHlwZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuVGV4dCA9PSBcIkNlbGxQaG9uZVwiKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgcGhpZCA9IHRoaXMuVmFsdWU7XHJcbiAgICAgICAgICAgICAgICBTTVMgPSAxO1xyXG4gICAgICAgICAgICAgICAgcHVibGlzaCA9IDE7XHJcbiAgICAgICAgICAgICAgICBlcHVibGlzaCA9IDE7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzID0gW3sgUGhvbmVUeXBlSWQ6IHBoaWQsIFByZWZpeDogXCJcIiwgQXJlYTogXCJcIiwgUGhvbmU6IFwiXCIsIElzU21zOiBTTVMsIENvbW1lbnRzOiBcIlwiLCBwaHB1Ymxpc2g6IHB1Ymxpc2ggfV1cclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG5cclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMgPSBbeyBFbWFpbDogXCJcIiwgRW1haWxOYW1lOiBcIlwiLCBOZXdzbGV0dGVyZTogZmFsc2UsIHB1Ymxpc2g6IGVwdWJsaXNoIH1dXHJcbiAgICAgICAgdmFyIGNudHJ5Y29kZSA9IHRoaXMuX3Jlc291cmNlU2VydmljZS5nZXRDb29raWUoZW1waWQgKyBcImNjb2RlXCIpO1xyXG4gICAgICAgIGlmIChjbnRyeWNvZGUubGVuZ3RoID4gMClcclxuICAgICAgICAgICAgY250cnljb2RlID0gY250cnljb2RlLnN1YnN0cmluZygxLCBjbnRyeWNvZGUubGVuZ3RoKTtcclxuXHJcbiAgICAgICAgdmFyIGFkaWQgPSBcIlwiO1xyXG4gICAgICAgIGpRdWVyeS5lYWNoKHRoaXMuX0FkZHJlc3NUeXBlcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5UZXh0ID09IFwiSG9tZVwiKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgYWRpZCA9IHRoaXMuVmFsdWU7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgfSk7XHJcblxyXG5cclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMgPSBbeyBTdHJlZXQ6IFwiXCIsIFN0cmVldDI6IFwiXCIsIENpdHlOYW1lOiBcIlwiLCBaaXA6IFwiXCIsIENvdW50cnlDb2RlOiBjbnRyeWNvZGUsIFN0YXRlSWQ6IFwiXCIsIEFkZHJlc3NUeXBlSWQ6IGFkaWQsIEZvckRlbGl2ZXJ5OiBmYWxzZSwgTWFpbkFkZHJlc3M6IGZhbHNlIH1dXHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyR3JvdXBzID0gW107XHJcbiAgICAgICAgdGhpcy5BZGRyZXNzLkNvdW50cnlDb2RlID0gXCJcIjtcclxuICAgICAgICB0aGlzLkFkZHJlc3MuU3RhdGVJZCA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LlNhZml4aWQgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5HZW5kZXIgPSBcIjBcIjtcclxuICAgICAgICB0aGlzLlNob3dNc2cgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLk1zZyA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5Jc1Nob3dBbGwgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLl9jdXN0b21lclNlcnZpY2UuR2V0R2VuZXJhbEdyb3Vwcyh0aGlzLklzU2hvd0FsbCkuc3Vic2NyaWJlKFxyXG4gICAgICAgICAgICAoZGF0YSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5Jc1Nob3dBbGwgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkoXCIjZ3JvdXBUcmVlXCIpLmh0bWwoXCJMb2RpbmcuLi5cIik7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIHJlcyA9IGpRdWVyeS5wYXJzZUpTT04oZGF0YSkuRGF0YVxyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeShcIiNncm91cFRyZWVcIikua2VuZG9UcmVlVmlldyh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRPbkRlbWFuZDogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tib3hlczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tDaGlsZHJlbjogdHJ1ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2NoZWNrOiB0aGlzLm9uR3JvdXBTZWxlY3QsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhdGFTb3VyY2U6IHJlc1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5KFwiI2dyb3VwVHJlZTFcIikuaHRtbChcIkxvZGluZy4uLlwiKTtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgcmVzID0galF1ZXJ5LnBhcnNlSlNPTihkYXRhKS5EYXRhXHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5KFwiI2dyb3VwVHJlZTFcIikua2VuZG9UcmVlVmlldyh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRPbkRlbWFuZDogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tib3hlczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tDaGlsZHJlbjogdHJ1ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2NoZWNrOiB0aGlzLm9uR3JvdXBTZWxlY3QsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhdGFTb3VyY2U6IHJlc1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAoZXJyKSA9PiB7XHJcblxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAoKSA9PiB7XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgKTtcclxuICAgIH1cclxuICAgIENhbmNlbEZpbGVBc3R4dCgpIHtcclxuICAgICAgICB0aGlzLklzRmlsZUFzdHh0U2hvdyA9IHRydWU7XHJcbiAgICAgICAgdGhpcy5Jc0ZpbGVBc3R4dFNob3cgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLklzQ2FuY2VsID0gdHJ1ZTtcclxuICAgICAgICBqUXVlcnkoXCIjRmlsZUFzdHh0XCIpLmhpZGUoKTtcclxuICAgICAgICBqUXVlcnkoXCIjRmlsZUFzU3BuXCIpLnNob3coKTtcclxuICAgICAgICB0aGlzLkZJTEVBU19CVE5fVEVYVCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfQlROX0ZJTEVBUztcclxuICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkICE9IG51bGwgJiYgcGFyc2VJbnQoIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkKSA+LTEpIHtcclxuICAgICAgICAgICAgalF1ZXJ5KFwiI0ZpbGVBc1NhdmVCdG5cIikuc2hvdygpO1xyXG4gICAgICAgICAgICB0aGlzLmNzc0ZpbGVBc0J0biA9IFwibWRpLWNvbnRlbnQtY3JlYXRlXCI7XHJcbiAgICAgICAgICAgIGpRdWVyeShcIiNGaWxlQXNDYW5jZWxCdG5cIikuaGlkZSgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgalF1ZXJ5KFwiI0ZpbGVBc1NhdmVCdG5cIikuaGlkZSgpO1xyXG4gICAgICAgICAgICBqUXVlcnkoXCIjRmlsZUFzQ2FuY2VsQnRuXCIpLmhpZGUoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBcclxuICAgIEhpZGVTaG93RmlsZUFzdHh0KCk6IG9ic2VydmFibGUge1xyXG4gICAgICAgXHJcbiAgICAgICAgaWYgKHRoaXMuSXNGaWxlQXN0eHRTaG93ID09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuSXNGaWxlQXN0eHRTaG93ID0gdHJ1ZTtcclxuICAgICAgICAgICAgalF1ZXJ5KFwiI0ZpbGVBc3R4dFwiKS5zaG93KCk7XHJcbiAgICAgICAgICAgIGpRdWVyeShcIiNGaWxlQXNTcG5cIikuaGlkZSgpO1xyXG4gICAgICAgICAgICB0aGlzLklzQ2FuY2VsID0gZmFsc2U7XHJcbiAgICAgICAgICAgIHRoaXMuRklMRUFTX0JUTl9URVhUID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9CVE5fU0FWRUZJTEVBUztcclxuICAgICAgICAgICAvLyBhbGVydCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCk7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQgIT0gbnVsbCAmJiBwYXJzZUludCggdGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQpID4tMSkge1xyXG4gICAgICAgICAgICAgICAgalF1ZXJ5KFwiI0ZpbGVBc1NhdmVCdG5cIikuc2hvdygpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jc3NGaWxlQXNCdG4gPSBcIm1kaS1jb250ZW50LXNhdmVcIjtcclxuICAgICAgICAgICAgICAgIGpRdWVyeShcIiNGaWxlQXNDYW5jZWxCdG5cIikuc2hvdygpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgalF1ZXJ5KFwiI0ZpbGVBc1NhdmVCdG5cIikuaGlkZSgpO1xyXG4gICAgICAgICAgICAgICAgalF1ZXJ5KFwiI0ZpbGVBc0NhbmNlbEJ0blwiKS5oaWRlKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuSXNGaWxlQXN0eHRTaG93ID0gZmFsc2U7XHJcbiAgICAgICAgICAgIGpRdWVyeShcIiNGaWxlQXN0eHRcIikuaGlkZSgpO1xyXG4gICAgICAgICAgICBqUXVlcnkoXCIjRmlsZUFzU3BuXCIpLnNob3coKTtcclxuICAgICAgICAgICAgdGhpcy5GSUxFQVNfQlROX1RFWFQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0JUTl9GSUxFQVM7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkICE9IG51bGwgJiYgcGFyc2VJbnQodGhpcy5tb2RlbElucHV0LkN1c3RvbWVySWQpPi0xKSB7XHJcbiAgICAgICAgICAgICAgICBqUXVlcnkoXCIjRmlsZUFzU2F2ZUJ0blwiKS5zaG93KCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNzc0ZpbGVBc0J0biA9IFwibWRpLWNvbnRlbnQtY3JlYXRlXCI7XHJcbiAgICAgICAgICAgICAgICBqUXVlcnkoXCIjRmlsZUFzQ2FuY2VsQnRuXCIpLmhpZGUoKTtcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5GaWxlQXMgIT0gXCJcIiAmJiB0aGlzLm1vZGVsSW5wdXQuRmlsZUFzICE9IHVuZGVmaW5lZCAmJiB0aGlzLm1vZGVsSW5wdXQuRmlsZUFzICE9IG51bGwgJiYgdGhpcy5Jc0NhbmNlbCA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5TYXZlRmlsZUFzKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkLCB0aGlzLm1vZGVsSW5wdXQuRmlsZUFzKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vYWxlcnQoJ2hlbGxvJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vYWxlcnQocmVzcG9uc2UuRXJyTXNnKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZywgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLy90aGlzLklzRmlsZUFzU2F2ZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZywgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5Jc0NhbmNlbCA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2Vsc2Uge1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgLy99XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9FTVBUWUZJTEVBUywgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYmluZEZpbGVBcygpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuSXNGaWxlQXN0eHRTaG93ID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5IaWRlU2hvd0ZpbGVBc3R4dCgpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgalF1ZXJ5KFwiI0ZpbGVBc1NhdmVCdG5cIikuaGlkZSgpO1xyXG4gICAgICAgICAgICAgICAgalF1ZXJ5KFwiI0ZpbGVBc0NhbmNlbEJ0blwiKS5oaWRlKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICB9XHJcbiAgICBTZXRFbWFpbE5hbWUoKTogb2JzZXJ2YWJsZSB7XHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5GaWxlQXMgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dC5GaWxlQXMgIT0gbnVsbCkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlsc1t0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMubGVuZ3RoIC0gMV0uRW1haWxOYW1lID0gdGhpcy5tb2RlbElucHV0LkZpbGVBcztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIENoZWNrQ3VzdFdpdGhTYW1lTmFtZSgpOiBvYnNlcnZhYmxlIHtcclxuXHJcbiAgICB9XHJcbiAgICBTZXREZWZhdWx0Q3VzdCgpIHtcclxuICAgICAgICAvL2FsZXJ0KCk7XHJcbiAgICAgICAgLy9kZWJ1Z2dlcjtcclxuXHJcbiAgICB9XHJcblxyXG4gICAgc2V0ZGVmYXVsdEFkZHJlc3MoKSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5iaW5kRmlsZUFzKCk7XHJcbiAgICAgICAgdGhpcy5DaGVja0N1c3RXaXRoZm5hbWVsbmFtZWNvbXBwaHNlbWFpbHMoKTtcclxuICAgICAgICB2YXIgYWRpZCA9IFwiXCI7XHJcbiAgICAgICAgdmFyIGFkdGV4dCA9IFwiSG9tZVwiO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkNvbXBhbnkgIT0gXCJcIiAmJiB0aGlzLm1vZGVsSW5wdXQuQ29tcGFueSAhPSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgYWR0ZXh0ID0gXCJXb3JrXCI7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgIH1cclxuICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLl9BZGRyZXNzVHlwZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuVGV4dCA9PSBhZHRleHQpIHtcclxuICAgICAgICAgICAgICAgIGFkaWQgPSB0aGlzLlZhbHVlO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3Nlc1t0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMubGVuZ3RoIC0gMV0uQWRkcmVzc1R5cGVJZCA9IGFkaWQ7XHJcbiAgICB9XHJcbiAgICBiaW5kRmlsZUFzKCk6IG9ic2VydmFibGUge1xyXG4gICAgICAgIFxyXG4gICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuRmlsZUFzID09IFwiXCIgfHwgdGhpcy5tb2RlbElucHV0LkZpbGVBcyA9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgaWYgKCh0aGlzLm1vZGVsSW5wdXQuQ29tcGFueSA9PSBcIlwiIHx8IHRoaXMubW9kZWxJbnB1dC5Db21wYW55ID09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgdmFyIGZpbGVhc3RleHQgPSBcIlwiO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5mbmFtZSAhPSBcIlwiICYmIHRoaXMubW9kZWxJbnB1dC5mbmFtZSAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0LmxuYW1lICE9IFwiXCIgJiYgdGhpcy5tb2RlbElucHV0LmxuYW1lICE9IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGZpbGVhc3RleHQgPSB0aGlzLm1vZGVsSW5wdXQubG5hbWUgKyBcIiBcIiArIHRoaXMubW9kZWxJbnB1dC5mbmFtZTtcclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKHRoaXMubW9kZWxJbnB1dC5mbmFtZSAhPSBcIlwiICYmIHRoaXMubW9kZWxJbnB1dC5mbmFtZSAhPSB1bmRlZmluZWQgJiYgKHRoaXMubW9kZWxJbnB1dC5sbmFtZSA9PSBcIlwiIHx8IHRoaXMubW9kZWxJbnB1dC5sbmFtZSA9PSB1bmRlZmluZWQpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZmlsZWFzdGV4dCA9IFwiIFwiICsgdGhpcy5tb2RlbElucHV0LmZuYW1lO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSBpZiAoKHRoaXMubW9kZWxJbnB1dC5mbmFtZSA9PSBcIlwiIHx8IHRoaXMubW9kZWxJbnB1dC5mbmFtZSA9PSB1bmRlZmluZWQpICYmICh0aGlzLm1vZGVsSW5wdXQubG5hbWUgIT0gXCJcIiAmJiB0aGlzLm1vZGVsSW5wdXQubG5hbWUgIT0gdW5kZWZpbmVkKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGZpbGVhc3RleHQgPSB0aGlzLm1vZGVsSW5wdXQubG5hbWUgKyBcIiBcIjtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5GaWxlQXMgPSBmaWxlYXN0ZXh0O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2UgaWYgKCh0aGlzLm1vZGVsSW5wdXQubG5hbWUgPT0gXCJcIiB8fCB0aGlzLm1vZGVsSW5wdXQubG5hbWUgPT0gdW5kZWZpbmVkKSAmJiAodGhpcy5tb2RlbElucHV0LmZuYW1lID09IFwiXCIgfHwgdGhpcy5tb2RlbElucHV0LmxuYW1lID09IHVuZGVmaW5lZCkpIHtcclxuICAgICAgICAgICAgICAgIHZhciBmaWxlYXN0ZXh0ID0gXCJcIjtcclxuICAgICAgICAgICAgICAgIGlmICgodGhpcy5tb2RlbElucHV0LkNvbXBhbnkgIT0gXCJcIiAmJiB0aGlzLm1vZGVsSW5wdXQuQ29tcGFueSAhPSB1bmRlZmluZWQpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZmlsZWFzdGV4dCA9IHRoaXMubW9kZWxJbnB1dC5Db21wYW55O1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkZpbGVBcyA9IGZpbGVhc3RleHQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZVxyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkZpbGVBcyA9IFwiKFwiICsgdGhpcy5tb2RlbElucHV0LkNvbXBhbnkgKyBcIikgXCIgKyB0aGlzLm1vZGVsSW5wdXQubG5hbWUgKyBcIiBcIiArIHRoaXMubW9kZWxJbnB1dC5mbmFtZTsgLy8rIFwiIFwiICYgbV9zdHJTcG91c2VcclxuICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlscy5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHNbdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzLmxlbmd0aCAtIDFdLkVtYWlsTmFtZSA9IHRoaXMubW9kZWxJbnB1dC5GaWxlQXM7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5TZXRFbWFpbE5hbWUoKTtcclxuICAgIH1cclxuICAgIGJpbmRHcm91cCgpOiB2b2lkIHtcclxuICAgICAgICAvL2FsZXJ0KHRoaXMuSXNTaG93QWxsKTsgdGhpcyBmdW5jdGlvbiBpcyBjYWxsaW5nIG9uIGNsaWNrIG9mIGNoZWNrYm94XHJcbiAgICAgICAgdmFyIGlzc2hvdyA9IGZhbHNlO1xyXG4gICAgICAgIGlmICh0aGlzLklzU2hvd0FsbCA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgIGlzc2hvdyA9IGZhbHNlXHJcbiAgICAgICAgICAgIHRoaXMuSXNTaG93QWxsID0gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLklzU2hvd0FsbCA9IHRydWU7XHJcbiAgICAgICAgICAgIGlzc2hvdyA9IHRydWU7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLmJpbmRHcm91cFRyZWUoaXNzaG93KTtcclxuICAgIH1cclxuICAgIHNhdmVDdXN0b21lckRhdGEoKTogdm9pZCB7XHJcbiAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICB0aGlzLklzYnRuZGlzYWJsZSA9IFwiZGlzYWJsZWRcIjtcclxuICAgICAgICB0aGlzLlNob3dMb2FkZXIgPSB0cnVlO1xyXG4gICAgICAgIHRoaXMuZ2V0U2VsZWN0ZWRHcm91cHMoKTtcclxuICAgICAgIFxyXG4gICAgICAgIHZhciBjb3VudCA9IDA7XHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3NlcyAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzICE9IG51bGwpIHtcclxuICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5NYWluQWRkcmVzcyA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY291bnQgPSBjb3VudCArIDE7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBpZiAoY291bnQgPiAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9ib290Ym94LmFsZXJ0KFwiTWFpbiBBZGRyZXNzIHNob2x1ZCBiZSBvbmx5IG9uZVwiKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5Jc2J0bmRpc2FibGUgPSBcIlwiO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuU2hvd0xvYWRlciA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vYWxlcnQodGhpcy5tb2RlbElucHV0LkJpcnRoRGF0ZSk7XHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5CaXJ0aERhdGUgIT0gXCJcIikge1xyXG4gICAgICAgICAgICBpZiAobW9tZW50KHRoaXMubW9kZWxJbnB1dC5CaXJ0aERhdGUsIFwiREQtTU0tWVlZWVwiLCB0cnVlKS5pc1ZhbGlkKCkgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoeyBtZXNzYWdlOiBcIkJpcnRoZGF0ZSBpcyBub3QgdmFsaWRcIiB9KTtcclxuXHJcbiAgICAgICAgICAgICAgICB0aGlzLklzYnRuZGlzYWJsZSA9IFwiXCI7XHJcbiAgICAgICAgICAgICAgICB0aGlzLlNob3dMb2FkZXIgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoY291bnQgPD0gMSB8fCB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMgPT0gdW5kZWZpbmVkIHx8IHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3NlcyA9PSBudWxsKSB7XHJcblxyXG4gICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzICE9IHVuZGVmaW5lZCAmJiB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXMgIT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgdmFyIHBodGVtcCA9IFtdO1xyXG4gICAgICAgICAgICAgICAgalF1ZXJ5KCdpbnB1dFtuYW1lXj1cInBoXCJdJykuZWFjaChmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcGh0ZW1wLnB1c2goalF1ZXJ5KHRoaXMpLnZhbCgpKTtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgdmFyIGFydGVtcCA9IFtdO1xyXG4gICAgICAgICAgICAgICAgalF1ZXJ5KCdpbnB1dFtuYW1lXj1cImFyXCJdJykuZWFjaChmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYXJ0ZW1wLnB1c2goalF1ZXJ5KHRoaXMpLnZhbCgpKTtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgdmFyIHByZXRlbXAgPSBbXTtcclxuICAgICAgICAgICAgICAgIGpRdWVyeSgnaW5wdXRbbmFtZV49XCJwcmVcIl0nKS5lYWNoKGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgICAgICBwcmV0ZW1wLnB1c2goalF1ZXJ5KHRoaXMpLnZhbCgpKTtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgdmFyIGkgPSAwO1xyXG4gICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuSXNTbXMgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLklzU21zID0gXCIxXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLklzU21zID0gXCIwXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLnBocHVibGlzaCA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucGhwdWJsaXNoID0gXCIxXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnBocHVibGlzaCA9IFwiMFwiO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB0aGlzLlBob25lID0gcGh0ZW1wW2ldO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuQXJlYSA9IGFydGVtcFtpXTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLlByZWZpeCA9IHByZXRlbXBbaV07XHJcbiAgICAgICAgICAgICAgICAgICAgaSsrO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vdmFyIHRlbXAgPSB0aGlzLlBob25lVHlwZUlkLnNwbGl0KCc7Jyk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy90aGlzLlBob25lVHlwZUlkID0gcGFyc2VJbnQodGVtcFsxXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy90aGlzLlBob25lVHlwZSA9IHRlbXBbMF07XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlscyAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzICE9IG51bGwpIHtcclxuICAgICAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlscywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLnB1Ymxpc2ggPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnB1Ymxpc2ggPSBcIjFcIjtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucHVibGlzaCA9IFwiMFwiO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBpKys7XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB2YXIgamRhdGEgPSBKU09OLnN0cmluZ2lmeSh0aGlzLm1vZGVsSW5wdXQpO1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhqZGF0YSlcclxuICAgICAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkFkZEN1c3RvbWVyKGpkYXRhKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhyZXNwb25zZSk7XHJcbiAgICAgICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5Jc2J0bmRpc2FibGUgPSBcIlwiO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5TaG93TG9hZGVyID0gZmFsc2U7XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIC8vYWxlcnQocmVzcG9uc2UuRXJyTXNnKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLk1zZ0NsYXNzID0gXCJ0ZXh0LWRhbmdlclwiO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9hbGVydChyZXNwb25zZS5FcnJNc2cpO1xyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuTXNnQ2xhc3MgPSBcInRleHQtc3VjY2Vzc1wiO1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBlbXBpZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiZW1wbG95ZWVpZFwiKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2Uuc2V0Q29va2llKGVtcGlkICsgXCJjdXN0XCIsIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclR5cGUsIDEwKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2Uuc2V0Q29va2llKGVtcGlkICsgXCJlbXBcIiwgdGhpcy5tb2RlbElucHV0LmVtcGxveWVlaWQsIDEwKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2Uuc2V0Q29va2llKGVtcGlkICsgXCJzcmNcIiwgdGhpcy5tb2RlbElucHV0LkNhbWVGcm9tQ3VzdG9tZXIsIDEwKTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzLmxlbmd0aD4wKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2Uuc2V0Q29va2llKGVtcGlkICsgXCJjY29kZVwiLCB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXNbdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzLmxlbmd0aCAtIDFdLkNvdW50cnlDb2RlLCAxMCk7XHJcbiAgICAgICAgICAgICAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgICAgICAvL2RvY3VtZW50LmxvY2F0aW9uID0gdGhpcy5CYXNlQXBwVXJsICsgXCJDdXN0b21lci9BZGQvLTFcIjtcclxuICAgICAgICAgICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuVGVtcG1vZGVsSW5wdXQgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dCA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5lZGl0Q3VzdERldCh0aGlzLm1vZGVsSW5wdXQpO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vdGhpcy5TZXRkZWZhdWx0UGFnZSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIFJlc2V0IGZvcm0gdmFsdWVzXHJcbiAgICAgICAgICAgICAgICAgICAgLy90aGlzLl9DdXN0VHlwZXMgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgdGhpcy5TaG93TXNnID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIHRoaXMuTXNnID0gcmVzcG9uc2UuRXJyTXNnO1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgZXJyb3I9PiBjb25zb2xlLmxvZyhlcnJvciksXHJcbiAgICAgICAgICAgICAgICAoKSA9PiBjb25zb2xlLmxvZyhcIlNhdmUgQ2FsbCBDb21wbGVhdGVkXCIpXHJcbiAgICAgICAgICAgICk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfTVNHX0lTTUFJTkFERCwgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgdGhpcy5Jc2J0bmRpc2FibGUgPSBcIlwiO1xyXG4gICAgICAgICAgICB0aGlzLlNob3dMb2FkZXIgPSBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgQ2hlY2tDdXN0V2l0aGZuYW1lbG5hbWVjb21wcGhzZW1haWxzKCk6IG9ic2VydmFibGUge1xyXG4gICAgICAgIHZhciBqZGF0YSA9IEpTT04uc3RyaW5naWZ5KHRoaXMubW9kZWxJbnB1dCk7XHJcbiAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICB2YXIgZm5hbWUgPSBcIlwiO1xyXG4gICAgICAgIHZhciBsbmFtZSA9IFwiXCI7XHJcbiAgICAgICAgdmFyIGNvbXBhbnkgPSBcIlwiO1xyXG4gICAgICAgIHZhciBwaG9uZXMgPSBcIlwiO1xyXG4gICAgICAgIHZhciBlbWFpbHMgPSBcIlwiO1xyXG4gICAgICAgIFxyXG4gICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuZm5hbWUgPT0gdW5kZWZpbmVkKVxyXG4gICAgICAgICAgICBmbmFtZSA9IFwiXCI7XHJcbiAgICAgICAgZWxzZVxyXG4gICAgICAgICAgICBmbmFtZSA9IHRoaXMubW9kZWxJbnB1dC5mbmFtZTtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5sbmFtZSA9PSB1bmRlZmluZWQpXHJcbiAgICAgICAgICAgIGxuYW1lID0gXCJcIjtcclxuICAgICAgICBlbHNlXHJcbiAgICAgICAgICAgIGxuYW1lID0gdGhpcy5tb2RlbElucHV0LmxuYW1lO1xyXG4gICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ29tcGFueSA9PSB1bmRlZmluZWQpXHJcbiAgICAgICAgICAgIGNvbXBhbnkgPSBcIlwiO1xyXG4gICAgICAgIGVsc2VcclxuICAgICAgICAgICAgY29tcGFueSA9IHRoaXMubW9kZWxJbnB1dC5Db21wYW55O1xyXG4gICAgICAgIFxyXG4gICAgICAgIGpRdWVyeSgnaW5wdXRbbmFtZV49XCJwaFwiXScpLmVhY2goZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgaWYgKGpRdWVyeSh0aGlzKS52YWwoKSAhPSBcIlwiICYmIGpRdWVyeSh0aGlzKS52YWwoKSAhPSB1bmRlZmluZWQgJiYgalF1ZXJ5KHRoaXMpLnZhbCgpICE9IG51bGwgJiYgalF1ZXJ5KHRoaXMpLnZhbCgpLmxlbmd0aD49Mykge1xyXG4gICAgICAgICAgICAgICAgcGhvbmVzICs9IGpRdWVyeSh0aGlzKS52YWwoKSArIFwiJywnXCI7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgICAgICBpZiAocGhvbmVzLmxlbmd0aCA+IDApIHBob25lcyA9IHBob25lcy5zdWJzdHJpbmcoMCwgcGhvbmVzLmxlbmd0aCAtIDMpO1xyXG4gICAgICAgIGpRdWVyeS5lYWNoKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlscywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5FbWFpbCAhPSBcIlwiICYmIHRoaXMuRW1haWwgIT0gdW5kZWZpbmVkICYmIHRoaXMuRW1haWwgIT0gbnVsbCAmJiB0aGlzLkVtYWlsLmxlbmd0aD49Mykge1xyXG4gICAgICAgICAgICAgICAgZW1haWxzICs9IHRoaXMuRW1haWwrXCInLCdcIjtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICB9KTtcclxuICAgICAgICBpZiAoZW1haWxzLmxlbmd0aCA+IDApIGVtYWlscyA9IGVtYWlscy5zdWJzdHJpbmcoMCwgZW1haWxzLmxlbmd0aCAtIDMpO1xyXG4gICAgICAgIGlmICgoZm5hbWUgIT0gXCJcIiAmJiBmbmFtZS5sZW5ndGggPj0gMiAmJiBsbmFtZSAhPSBcIlwiICYmIGxuYW1lLmxlbmd0aCA+PSAyKVxyXG4gICAgICAgICAgICB8fCAoY29tcGFueSAhPSBcIlwiICYmIGNvbXBhbnkubGVuZ3RoID49IDMpXHJcbiAgICAgICAgICAgIHx8IChwaG9uZXMgIT0gXCJcIilcclxuICAgICAgICAgICAgfHwgKGVtYWlscyAhPSBcIlwiKSkge1xyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkdldEN1c3RvbWVyc1NlYXJjaERhdGEoZm5hbWUsIGxuYW1lLCBjb21wYW55LCBwaG9uZXMsIGVtYWlscykuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZywgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5DdXN0TGlzdCA9IHt9O1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuQ3VzdExpc3QgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5EYXRhICE9IG51bGwgJiYgcmVzcG9uc2UuRGF0YSAhPSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jdXN0U2VhcmNoRGF0YSA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGpRdWVyeSgnI0N1c3RNb2RhbCcpLm9wZW5Nb2RhbCgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8valF1ZXJ5KCcjQ3VzdE1vZGFsJykubW9kYWwoJ29wZW4nKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9qUXVlcnkoXCIjQ3VzdE1vZGFsXCIpLnNob3coMTAwMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8vYWxlcnQodGhpcy5SRVMpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgICAvL3RoaXMuYmluZEZpbGVBcygpO1xyXG4gICAgfVxyXG5cclxuXHJcblxyXG4gICAgQ2hlY2tDdXN0V2l0aGZuYW1lbG5hbWUoZm5hbWUsIGxuYW1lLGNvbXBhbnkpOiBvYnNlcnZhYmxlIHtcclxuICAgICAgICB2YXIgamRhdGEgPSBKU09OLnN0cmluZ2lmeSh0aGlzLm1vZGVsSW5wdXQpO1xyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5mbmFtZSA9PSB1bmRlZmluZWQpXHJcbiAgICAgICAgICAgIGZuYW1lID0gXCJcIjtcclxuICAgICAgICBlbHNlXHJcbiAgICAgICAgICAgIGZuYW1lID0gdGhpcy5tb2RlbElucHV0LmZuYW1lO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LmxuYW1lID09IHVuZGVmaW5lZClcclxuICAgICAgICAgICAgbG5hbWUgPSBcIlwiO1xyXG4gICAgICAgIGVsc2VcclxuICAgICAgICAgICAgbG5hbWUgPSB0aGlzLm1vZGVsSW5wdXQubG5hbWU7XHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5Db21wYW55ID09IHVuZGVmaW5lZClcclxuICAgICAgICAgICAgY29tcGFueSA9IFwiXCI7XHJcbiAgICAgICAgZWxzZVxyXG4gICAgICAgICAgICBjb21wYW55ID0gdGhpcy5tb2RlbElucHV0LkNvbXBhbnk7XHJcbiAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkNoZWNrQ3VzdFdpdGhTYW1lTmFtZShmbmFtZSwgbG5hbWUsIGNvbXBhbnkpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuQ3VzdExpc3QgPSB7fTtcclxuICAgICAgICAgICAgICAgIHRoaXMuQ3VzdExpc3QgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLkRhdGEgIT0gbnVsbCAmJiByZXNwb25zZS5EYXRhICE9IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY3VzdFNlYXJjaERhdGEgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeShcIiNDdXN0TW9kYWxcIikub3Blbk1vZGFsKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9qUXVlcnkoXCIjQ3VzdE1vZGFsXCIpLnNob3coMTAwMCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvL2FsZXJ0KHRoaXMuUkVTKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuICAgICAgICAvL3RoaXMuYmluZEZpbGVBcygpO1xyXG4gICAgfVxyXG5cclxuXHJcblxyXG5cclxuICAgIENoZWNrQ3VzdFdpdGhFbWFpbCgpOiBvYnNlcnZhYmxlIHtcclxuICAgICAgICBcclxuICAgICAgICAvL3ZhciBFbWFpbCA9IFwiXCI7XHJcbiAgICAgICAgLy9pZiAodGhpcy5FbWFpbE1vZGVsLkVtYWlsICE9IFwiXCIgJiYgdGhpcy5FbWFpbE1vZGVsLkVtYWlsICE9IHVuZGVmaW5lZClcclxuICAgICAgICAvLyAgICBFbWFpbCA9IHRoaXMuRW1haWxNb2RlbC5FbWFpbDtcclxuICAgICAgICAvL3RoaXMuX2N1c3RvbWVyU2VydmljZS5DaGVja0N1c3RXaXRoU2FtZUVtYWlsKEVtYWlsKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgLy8gICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAvLyAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgIC8vICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAvLyAgICAgICAgYWxlcnQocmVzcG9uc2UuRXJyTXNnKTtcclxuICAgICAgICAvLyAgICB9XHJcbiAgICAgICAgLy8gICAgZWxzZSB7XHJcbiAgICAgICAgLy8gICAgICAgIHRoaXMuQ3VzdExpc3QgPSB7fTtcclxuICAgICAgICAvLyAgICAgICAgdGhpcy5DdXN0TGlzdCA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgLy8gICAgICAgIGlmIChyZXNwb25zZS5EYXRhICE9IG51bGwgJiYgcmVzcG9uc2UuRGF0YSAhPSB1bmRlZmluZWQpIHtcclxuICAgICAgICAvLyAgICAgICAgICAgIHRoaXMuY3VzdFNlYXJjaERhdGEgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgIC8vICAgICAgICAgICAgalF1ZXJ5KFwiI0N1c3RNb2RhbFwiKS5tb2RhbChcInNob3dcIik7XHJcbiAgICAgICAgLy8gICAgICAgIH1cclxuICAgICAgICAvLyAgICAgICAgLy9hbGVydCh0aGlzLlJFUyk7XHJcbiAgICAgICAgLy8gICAgfVxyXG4gICAgICAgIC8vfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgLy8gICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIC8vfSwgKCkgPT4ge1xyXG4gICAgICAgIC8vICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIC8vfSk7XHJcbiAgICB9XHJcbiAgICBDaGVja0N1c3RXaXRoUGhvbmUoKTogb2JzZXJ2YWJsZSB7XHJcbiAgICAgICAgdmFyIFBob25lID0gXCJcIjtcclxuICAgICAgICBpZiAodGhpcy5QaG9uZU1vZGVsLlBob25lICE9IFwiXCIgJiYgdGhpcy5QaG9uZU1vZGVsLlBob25lICE9IHVuZGVmaW5lZClcclxuICAgICAgICAgICAgUGhvbmUgPSB0aGlzLlBob25lTW9kZWwuUGhvbmU7XHJcbiAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkNoZWNrQ3VzdFdpdGhTYW1lUGhvbmUodGhpcy5QaG9uZU1vZGVsLlBob25lKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZywgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLkN1c3RMaXN0ID0ge307XHJcbiAgICAgICAgICAgICAgICB0aGlzLkN1c3RMaXN0ID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5EYXRhICE9IG51bGwgJiYgcmVzcG9uc2UuRGF0YSAhPSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmN1c3RTZWFyY2hEYXRhID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkoXCIjQ3VzdE1vZGFsXCIpLm9wZW5Nb2RhbCgpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLy9hbGVydCh0aGlzLlJFUyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcbiAgICBTaG93UmVtYXJrcyhQaE9iaik6IE9ic2VydmFibGUge1xyXG4gICAgICAgIGpRdWVyeS5lYWNoKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICBpZiAodGhpcyA9PSBQaE9iaikge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5Jc1Nob3dSZW1hcmtzID0gdHJ1ZTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICB9KTtcclxuICAgIH1cclxuICAgIHNob3dBZGRQb3B1cCgpOiBvYnNlcnZhYmxlIHtcclxuICAgICAgICB0aGlzLkFkZHJlc3MgPSB7fTtcclxuICAgICAgICB0aGlzLlBob25lTW9kZWwgPSB7fTtcclxuICAgICAgICB0aGlzLlBob25lTW9kZWwuUGhvbmVUeXBlSWQgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMuQWRkcmVzcy5Db3VudHJ5Q29kZSA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5BZGRyZXNzLlN0YXRlSWQgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMuQWRkcmVzcy5DaXR5TmFtZSA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5BZGRyZXNzLkFkZHJlc3NUeXBlSWQgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMuRW1haWxNb2RlbCA9IHt9O1xyXG4gICAgICAgIHRoaXMuQlROX1BIQUREID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9CVE5fUEhBRERcclxuICAgICAgICBcclxuXHJcbiAgICB9XHJcbiAgICBzaG93aGlkZUdyb3VwcygpOiBvYnNlcnZhYmxlIHtcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgIGlmICh0aGlzLlNob3dHcm91cHMgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgdGhpcy5TaG93R3JvdXBzID0gdHJ1ZTtcclxuICAgICAgICAgICAgdGhpcy5Hcm91cFRleHQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0xCTF9ISURFR1JPVVA7XHJcbiAgICAgICAgICAgIGpRdWVyeShcIiNHcnBEaXZcIikuc2hvdygxMDAwKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuU2hvd0dyb3VwcyA9IGZhbHNlO1xyXG4gICAgICAgICAgICB0aGlzLkdyb3VwVGV4dCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfTEJMX1NIT1dHUk9VUFM7XHJcbiAgICAgICAgICAgIGpRdWVyeShcIiNHcnBEaXZcIikuaGlkZSgxMDAwKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgfVxyXG5cclxuXHJcbiAgICBDYW5hZGRBZGRyZXNzKGFkb2JqKTogYm9vbGVhbiB7XHJcbiAgICAgICAgLy9hbGVydCgnSGVsbG8nKTtcclxuICAgICAgICByZXR1cm4gKGFkb2JqLlN0cmVldCAhPSB1bmRlZmluZWQgJiYgYWRvYmouU3RyZWV0ICE9IFwiXCIpXHJcbiAgICAgICAgICAgICYmIChhZG9iai5TdHJlZXQyICE9IHVuZGVmaW5lZCAmJiBhZG9iai5TdHJlZXQyICE9IFwiXCIpXHJcbiAgICAgICAgICAgIC8vJiYgKGFkb2JqLkNpdHlOYW1lICE9IHVuZGVmaW5lZCAmJiBhZG9iai5DaXR5TmFtZSAhPSBcIlwiKVxyXG4gICAgICAgICAgICAmJiAoYWRvYmouWmlwICE9IHVuZGVmaW5lZCAmJiBhZG9iai5aaXAgIT0gXCJcIikgXHJcbiAgICAgICAgICAgICYmIChhZG9iai5Db3VudHJ5Q29kZSAhPSB1bmRlZmluZWQgJiYgYWRvYmouQ291bnRyeUNvZGUgIT0gXCJcIiApXHJcbiAgICAgICAgICAgIC8vJiYgKHRoaXMuQWRkcmVzcy5TdGF0ZUlkICE9IHVuZGVmaW5lZCAmJiB0aGlzLkFkZHJlc3MuU3RhdGVJZCAhPSBcIlwiKVxyXG4gICAgICAgICAgICAmJiAoYWRvYmouQWRkcmVzc1R5cGVJZCAhPSB1bmRlZmluZWQgJiYgYWRvYmouQWRkcmVzc1R5cGVJZCAhPSBcIlwiKTtcclxuICAgIH1cclxuICAgIEFkZEFkZHJlc3NlcyhhZG9iaik6IG9ic2VydmFibGUge1xyXG4gICAgICAgIFxyXG4gICAgICAgIHZhciBJc01haW5BZGQgPSBmYWxzZTtcclxuICAgICAgICBhZG9iai5DaXR5TmFtZSA9IGpRdWVyeShcIiNDaXR5XCIpLnZhbCgpO1xyXG4gICAgICAgIFxyXG4gICAgICAgIGlmICh0aGlzLkNhbmFkZEFkZHJlc3MoYWRvYmopKSB7XHJcblxyXG4gICAgICAgICAgICB2YXIgZW1waWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImVtcGxveWVlaWRcIik7XHJcbiAgICAgICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5zZXRDb29raWUoZW1waWQgKyBcImNjb2RlXCIsIGFkb2JqLkNvdW50cnlDb2RlLCAxMCk7XHJcbiAgICAgICAgICAgIHZhciBhZGlkID0gXCJcIjtcclxuICAgICAgICAgICAgdmFyIGFkdGV4dCA9IFwiSG9tZVwiO1xyXG4gICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkNvbXBhbnkgIT0gXCJcIiAmJiB0aGlzLm1vZGVsSW5wdXQuQ29tcGFueSAhPSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgIGFkdGV4dCA9IFwiV29ya1wiO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMuX0FkZHJlc3NUeXBlcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuVGV4dCA9PSBhZHRleHQpIHtcclxuICAgICAgICAgICAgICAgICAgICBhZGlkID0gdGhpcy5WYWx1ZTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgdmFyIEFkZHJlc09iaiA9IHsgU3RyZWV0OiBcIlwiLCBTdHJlZXQyOiBcIlwiLCBDaXR5TmFtZTogXCJcIiwgWmlwOiBcIlwiLCBDb3VudHJ5Q29kZTogYWRvYmouQ291bnRyeUNvZGUsIFN0YXRlSWQ6IFwiXCIsIEFkZHJlc3NUeXBlSWQ6IGFkaWQsIEZvckRlbGl2ZXJ5OiBmYWxzZSwgTWFpbkFkZHJlc3M6IGZhbHNlLCwgTWFpbk9yZGVyOiBcIk1haW5BZGRyXCIgKyAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzLmxlbmd0aCsxKS50b1N0cmluZygpLCBEZWx2cnlPcmRlcjogXCJEZWx2cnlcIiArICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMubGVuZ3RoKzEpLnRvU3RyaW5nKCkgfTtcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgLy9qUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgIC8vICAgIGlmICh0aGlzLk1haW5BZGRyZXNzID09IHRydWUgJiYgYWRvYmouTWFpbkFkZHJlc3MgPT0gdHJ1ZSAmJiB0aGlzICE9IGFkb2JqKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgIGFkb2JqLk1haW5BZGRyZXNzID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgLy8gICAgfVxyXG4gICAgICAgICAgICAgICAgLy99KTtcclxuICAgICAgICAgICAgICAgIGlmIChJc01haW5BZGQgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMucHVzaChBZGRyZXNPYmopO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHZhciBtc2cgPSAnJztcclxuICAgICAgICAgICAgaWYgKGFkb2JqLlN0cmVldCA9PSB1bmRlZmluZWQgfHwgYWRvYmouU3RyZWV0ID09IFwiXCIpIHtcclxuICAgICAgICAgICAgICAgIC8vbXNnICs9ICdcXG5TdHJlZXQgaXMgbm90IGZpbGxlZCc7IEFQUF9BTF9NU0dfU1RSRUVUXHJcbiAgICAgICAgICAgICAgICBtc2cgKz0gJ1xcbicgKyB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0FMX01TR19TVFJFRVQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKGFkb2JqLlN0cmVldDIgPT0gdW5kZWZpbmVkIHx8IGFkb2JqLlN0cmVldDIgPT0gXCJcIikge1xyXG4gICAgICAgICAgICAgICAgLy9tc2cgKz0gJ1xcbkFyZWEgaXMgbm90IGZpbGxlZCc7XHJcbiAgICAgICAgICAgICAgICBtc2cgKz0gJ1xcbicgKyB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0FMX01TR19BUkVBO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8vaWYgKGFkb2JqLkNpdHlOYW1lID09IHVuZGVmaW5lZCB8fCBhZG9iai5DaXR5TmFtZSA9PSBcIlwiKVxyXG4gICAgICAgICAgICAvLyAgICAvL21zZyArPSAnXFxuQ2l0eSBpcyBub3QgZmlsbGVkJzsgXHJcbiAgICAgICAgICAgIC8vICAgIG1zZyArPSAnXFxuJyArIHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfQUxfTVNHX0NJVFk7XHJcbiAgICAgICAgICAgIGlmIChhZG9iai5aaXAgPT0gdW5kZWZpbmVkIHx8IGFkb2JqLlppcCA9PSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICAvL21zZyArPSAnXFxuWmlwIGlzIG5vdCBmaWxsZWQnOyBcclxuICAgICAgICAgICAgICAgIG1zZyArPSAnXFxuJyt0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0FMX01TR19aSVA7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKGFkb2JqLkNvdW50cnlDb2RlID09IHVuZGVmaW5lZCB8fCBhZG9iai5Db3VudHJ5Q29kZSA9PSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICAvL21zZyArPSAnXFxuQ291bnRyeSBpcyBub3Qgc2VsZWN0ZWQnO1xyXG4gICAgICAgICAgICAgICAgbXNnICs9ICdcXG4nICsgdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9BTF9NU0dfQ09VTlRSWTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAvL2lmICh0aGlzLkFkZHJlc3MuU3RhdGVJZCA9PSB1bmRlZmluZWQgfHwgdGhpcy5BZGRyZXNzLlN0YXRlSWQgPT0gXCJcIikge1xyXG4gICAgICAgICAgICAvLyAgICBtc2cgKz0gJ1xcblN0YXRlIGlzIG5vdCBzZWxlY3RlZCc7XHJcbiAgICAgICAgICAgIC8vfVxyXG4gICAgICAgICAgICBpZiAoYWRvYmouQWRkcmVzc1R5cGVJZCA9PSB1bmRlZmluZWQgfHwgYWRvYmouQWRkcmVzc1R5cGVJZCA9PSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICAvL21zZyArPSAnXFxuQWRkcmVzcyB0eXBlIGlzIG5vdCBzZWxlY3RlZCc7XHJcbiAgICAgICAgICAgICAgICBtc2cgKz0gJ1xcbicgKyB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0FMX01TR19BRFRZUEU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICBtZXNzYWdlOiBtc2csIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgIH1cclxuICAgIENhbmFkZFBob25lKHBob25lT2JqKTogYm9vbGVhbiB7XHJcbiAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAvL2FsZXJ0KHRoaXMuUGhvbmVNb2RlbC5QaG9uZVR5cGVJZCArICcgJyArIHRoaXMuUGhvbmVNb2RlbC5QaG9uZVR5cGUgKyAnICcgKyB0aGlzLlBob25lTW9kZWwuUHJlZml4ICsgJyAnICsgdGhpcy5QaG9uZU1vZGVsLkFyZWEgKyAnICcgKyB0aGlzLlBob25lTW9kZWwuUGhvbmUpO1xyXG4gICAgICAgIHJldHVybiAocGhvbmVPYmouUGhvbmVUeXBlSWQgIT0gdW5kZWZpbmVkICYmIHBob25lT2JqLlBob25lVHlwZUlkICE9IFwiXCIpXHJcbiAgICAgICAgICAgIC8vICYmICh0aGlzLlBob25lTW9kZWwuUGhvbmVUeXBlICE9IHVuZGVmaW5lZCYmIHRoaXMuUGhvbmVNb2RlbC5QaG9uZVR5cGUgIT0gXCJcIiApXHJcbiAgICAgICAgICAgIC8vJiYgKHRoaXMuUGhvbmVNb2RlbC5QcmVmaXggIT0gdW5kZWZpbmVkJiYgdGhpcy5QaG9uZU1vZGVsLlByZWZpeCAhPSBcIlwiICApXHJcbiAgICAgICAgICAgIC8vJiYgKHRoaXMuUGhvbmVNb2RlbC5BcmVhICE9IHVuZGVmaW5lZCYmdGhpcy5QaG9uZU1vZGVsLkFyZWEgIT0gXCJcIiAgKVxyXG4gICAgICAgICAgICAvLyYmIChwaG9uZU9iai5QaG9uZSAhPSB1bmRlZmluZWQgJiYgcGhvbmVPYmouUGhvbmUgIT0gXCJcIik7XHJcbiAgICAgICAgICAgIC8vJiYgKHRoaXMuUGhvbmVNb2RlbC5QcmVmaXggIT0gdW5kZWZpbmVkICYmIHRoaXMuUGhvbmVNb2RlbC5QcmVmaXgubGVuZ3RoICE9IDMpOyAgICAgICAgICAgIDtcclxuICAgIH1cclxuICAgIEFkZFBob25lcyhwaG9uZU9iaik6IG9ic2VydmFibGUge1xyXG4gICAgICAgIGlmICh0aGlzLkNhbmFkZFBob25lKHBob25lT2JqKSkge1xyXG5cclxuICAgICAgICAgICAgZGVidWdnZXI7XHJcbiAgICAgICAgICAgIC8vaWYgKHRoaXMuSXNSZWNvcmRFZGl0TW9kZSA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICB2YXIgcGhpZCA9IFwiXCI7XHJcbiAgICAgICAgICAgIHZhciBTTVMgPSAwO1xyXG4gICAgICAgICAgICB2YXIgcHVibGlzaCA9IDA7XHJcbiAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMuX1Bob25lVHlwZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLlRleHQgPT0gXCJDZWxsUGhvbmVcIikge1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBwaGlkID0gdGhpcy5WYWx1ZTtcclxuICAgICAgICAgICAgICAgICAgICBTTVMgPSAxO1xyXG4gICAgICAgICAgICAgICAgICAgIHB1Ymxpc2ggPSAxO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIHZhciBQaG9uZU9iaiA9IHsgUGhvbmVUeXBlSWQ6IHBoaWQsIFBob25lVHlwZTogXCJcIiwgUHJlZml4OiBcIlwiLCBBcmVhOiBcIlwiLCBQaG9uZTogXCJcIiwgSXNTbXM6IFNNUywgQ29tbWVudHM6IFwiXCIsIElzU2hvd1JlbWFya3M6IGZhbHNlLCBwaHB1Ymxpc2g6IHB1Ymxpc2gsIFNNU09yZGVyOiBcIlNNU1wiICsgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lcy5sZW5ndGggKyAxKS50b1N0cmluZygpLCBQdWJsaXNoT3JkZXI6IFwiUHViXCIgKyAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzLmxlbmd0aCArIDEpLnRvU3RyaW5nKCkgfTtcclxuICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lcy5wdXNoKFBob25lT2JqKTtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAvL3RoaXMuQ2hlY2tDdXN0V2l0aGZuYW1lbG5hbWVjb21wcGhzZW1haWxzKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICB2YXIgbXNnID0gJyc7XHJcbiAgICAgICAgICAgIGlmIChwaG9uZU9iai5QaG9uZVR5cGVJZCA9PSB1bmRlZmluZWQgfHwgcGhvbmVPYmouUGhvbmVUeXBlSWQgPT0gXCJcIikge1xyXG4gICAgICAgICAgICAgICAgLy9tc2cgKz0gJ1xcblBob25lIHR5cGUgaXMgbm90IHNlbGVjdGVkJztcclxuICAgICAgICAgICAgICAgIG1zZyArPSAnXFxuJyArIHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfQUxfUkVHTVNHX1BIVFlQRTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAvL2lmIChwaG9uZU9iai5QaG9uZSA9PSB1bmRlZmluZWQgfHwgcGhvbmVPYmouUGhvbmUgPT0gXCJcIikge1xyXG4gICAgICAgICAgICAvLyAgICAvL21zZyArPSAnXFxuUGhvbmUgbnVtYmVyIGlzIG5vdCBmaWxsZWQnO1xyXG4gICAgICAgICAgICAvLyAgICBtc2cgKz0gJ1xcbicgKyB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0FMX1JFR01TR19QSE5PO1xyXG4gICAgICAgICAgICAvL31cclxuICAgICAgICAgICAgLy9pZiAodGhpcy5QaG9uZU1vZGVsLlByZWZpeC5sZW5ndGghPTMpIHtcclxuICAgICAgICAgICAgLy8gICAgbXNnICs9ICdcXG5QcmVmaXggbXVzdCBvZiAzIG51bWVyaWMgZGlnaXRzJztcclxuICAgICAgICAgICAgLy99XHJcbiAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgbWVzc2FnZTogbXNnLGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgIH1cclxuICAgIENhbmFkZEVtYWlsKEVtYWlsT2JqKTogYm9vbGVhbiB7XHJcbiAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAvL2FsZXJ0KCdIZWxsbycpO1xyXG4gICAgICAgIHJldHVybiAoRW1haWxPYmouRW1haWxOYW1lICE9IHVuZGVmaW5lZCAmJiBFbWFpbE9iai5FbWFpbE5hbWUgIT0gXCJcIik7XHJcbiAgICAgICAgLy8oRW1haWxPYmouRW1haWwgIT0gdW5kZWZpbmVkICYmIEVtYWlsT2JqLkVtYWlsICE9IFwiXCIpICYmXHJcbiAgICAgICAgICAgICBcclxuICAgIH1cclxuICAgIEFkZEVtYWlscyhFbWFpbE9iaik6IG9ic2VydmFibGUge1xyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgaWYgKHRoaXMuQ2FuYWRkRW1haWwoRW1haWxPYmopKSB7XHJcbiAgICAgICAgICAgIHZhciBlcHVibGlzaCA9IDA7XHJcbiAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMuX1Bob25lVHlwZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgaWYgKHRoaXMuVGV4dCA9PSBcIkNlbGxQaG9uZVwiKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgZXB1Ymxpc2ggPSAxO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIC8vaWYgKHRoaXMuSXNSZWNvcmRFZGl0TW9kZSA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICB2YXIgZU9iaiA9IHt9O1xyXG4gICAgICAgICAgICBlT2JqLkVtYWlsID0gXCJcIjtcclxuICAgICAgICAgICAgZU9iai5FbWFpbE5hbWUgPSB0aGlzLm1vZGVsSW5wdXQuRmlsZUFzO1xyXG4gICAgICAgICAgICBlT2JqLk5ld3NsZXR0ZXJlID0gdHJ1ZTtcclxuICAgICAgICAgICAgZU9iai5wdWJsaXNoID0gZXB1Ymxpc2g7XHJcbiAgICAgICAgICAgIGVPYmouTmV3c09yZGVyPSBcIk5ld3NcIiArICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMubGVuZ3RoKzEpLnRvU3RyaW5nKCk7XHJcbiAgICAgICAgICAgIGVPYmouRVB1Ymxpc2hPcmRlcj0gXCJFUHViXCIgKyAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzLmxlbmd0aCArIDEpLnRvU3RyaW5nKCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMucHVzaChlT2JqKTtcclxuICAgICAgICAgICAgICAgIC8vdGhpcy5DaGVja0N1c3RXaXRoZm5hbWVsbmFtZWNvbXBwaHNlbWFpbHMoKTtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICB2YXIgbXNnID0gJyc7XHJcbiAgICAgICAgICAgIC8vaWYgKEVtYWlsT2JqLkVtYWlsID09IHVuZGVmaW5lZCB8fCBFbWFpbE9iai5FbWFpbCA9PSBcIlwiKVxyXG4gICAgICAgICAgICAvLyAgICAvL21zZyArPSAnXFxuRW1haWwgaXMgbm90IGZpbGxlZCc7XHJcbiAgICAgICAgICAgIC8vICAgIG1zZyArPSAnXFxuJyArIHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfQUxfUkVHTVNHX0VNQUlMO1xyXG4gICAgICAgICAgICBpZiAoRW1haWxPYmouRW1haWxOYW1lID09IHVuZGVmaW5lZCB8fCBFbWFpbE9iai5FbWFpbE5hbWUgPT0gXCJcIikge1xyXG4gICAgICAgICAgICAgICAgLy9tc2cgKz0gJ1xcbk5hbWUgaXMgbm90IGZpbGxlZCc7XHJcbiAgICAgICAgICAgICAgICBtc2cgKz0gJ1xcbicgKyB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0FMX1JFR01TR19FTkFNRTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgIG1lc3NhZ2U6IG1zZywgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgICAgIC8vIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3NlcyA9IHRoaXMuQ3VzdG9tZXJBZGRyZXNzZXM7XHJcbiAgICB9XHJcbiAgICBcclxuICAgIGVkaXRDdXN0RGV0KE9iaikge1xyXG4gICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRDb21wbGV0ZUN1c3REZXQoT2JqLkN1c3RvbWVySWQpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dCA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICB0aGlzLlNBVkVfQlROX1RFWFQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0JUTl9VUERBVEU7XHJcbiAgICAgICAgICAgICAgICAvL3RoaXMuQUREX05FV19DVVNUX1RFWFQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0xCTF9VUERBVEVfQ1VTVDtcclxuICAgICAgICAgICAgICAgIHRoaXMuQ1NTVEVYVCA9IFwibWRpLWNvbnRlbnQtYWRkXCI7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzLmxlbmd0aCA9PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzID0gW3sgRW1haWw6IFwiXCIsIEVtYWlsTmFtZTogdGhpcy5tb2RlbElucHV0LkZpbGVBcywgTmV3c2xldHRlcmU6IGZhbHNlLCBwdWJsaXNoOiAwLCBOZXdzT3JkZXI6IFwiTmV3czFcIiwgRVB1Ymxpc2hPcmRlcjogXCJFUHViMVwiIH1dXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgY291bnQgPSAxO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5OZXdzT3JkZXIgPSBcIk5ld3NcIiArIGNvdW50O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLkVQdWJsaXNoT3JkZXIgPSBcIkVQdWJcIiArIGNvdW50Kys7XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzLmxlbmd0aCA9PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIHBoaWQgPSBcIlwiO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLl9QaG9uZVR5cGVzLCBmdW5jdGlvbiAoKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5UZXh0ID09IFwiQ2VsbFBob25lXCIpIHtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwaGlkID0gdGhpcy5WYWx1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXMgPSBbeyBQaG9uZVR5cGVJZDogcGhpZCwgUHJlZml4OiBcIlwiLCBBcmVhOiBcIlwiLCBQaG9uZTogXCJcIiwgSXNTbXM6IDAsIENvbW1lbnRzOiBcIlwiLCBwaHB1Ymxpc2g6IDAsIFNNU09yZGVyOiBcIlNNUzFcIiwgUHVibGlzaE9yZGVyOiBcIlB1YjFcIiB9XTtcclxuICAgICAgICAgICAgICAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBjb3VudCA9IDE7XHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzLCBmdW5jdGlvbiAoKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLlNNU09yZGVyID0gXCJTTVNcIiArIGNvdW50O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLlB1Ymxpc2hPcmRlciA9IFwiUHViXCIgKyBjb3VudCsrO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3Nlcy5sZW5ndGggPT0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBlbXBpZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiZW1wbG95ZWVpZFwiKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIGNjb2RlID0gdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmdldENvb2tpZShlbXBpZCArIFwiY2NvZGVcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGNjb2RlLmxlbmd0aCA+IDApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNjb2RlID0gY2NvZGUuc3Vic3RyaW5nKDEsIGNjb2RlLmxlbmd0aCk7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIGFkaWQgPSBcIlwiO1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBjb21wdGV4dCA9IFwiSG9tZVwiO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ29tcGFueSAhPSBcIlwiICYmIHRoaXMubW9kZWxJbnB1dC5Db21wYW55ICE9IHVuZGVmaW5lZCAmJiB0aGlzLm1vZGVsSW5wdXQuQ29tcGFueSAhPSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbXB0ZXh0ID0gXCJXb3JrXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMuX0FkZHJlc3NUeXBlcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5UZXh0ID09IGNvbXB0ZXh0KSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYWRpZCA9IHRoaXMuVmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzID0gW3sgU3RyZWV0OiBcIlwiLCBTdHJlZXQyOiBcIlwiLCBDaXR5TmFtZTogXCJcIiwgWmlwOiBcIlwiLCBDb3VudHJ5Q29kZTogY2NvZGUsIFN0YXRlSWQ6IFwiXCIsIEFkZHJlc3NUeXBlSWQ6IGFkaWQsIEZvckRlbGl2ZXJ5OiBmYWxzZSwgTWFpbkFkZHJlc3M6IGZhbHNlLCBNYWluT3JkZXI6IFwiTWFpbkFkZHIxXCIsIERlbHZyeU9yZGVyOiBcIkRlbHZyeTFcIiB9XTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBjb3VudCA9IDE7XHJcbiAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLk1haW5PcmRlciA9IFwiTWFpbkFkZHJcIiArIGNvdW50O1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuRGVsdnJ5T3JkZXIgPSBcIkRlbHZyeVwiICsgY291bnQrKztcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLy92YXIgdHJlZXZpZXcgPSBqUXVlcnkoXCIjZ3JvdXBUcmVlXCIpLmRhdGEoXCJrZW5kb1RyZWVWaWV3XCIpO1xyXG5cclxuICAgICAgICAgICAgICAgIC8vdmFyIGJhciA9IHRyZWV2aWV3LmZpbmRCeUlkKFwiQmFyXCIpO1xyXG5cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgLy9qUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJHcm91cHMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgIC8vICAgIHZhciBkYXRhID0galF1ZXJ5KFwiI2dyb3VwVHJlZVwiKS5kYXRhKFwia2VuZG9UcmVlVmlld1wiKS5kYXRhU291cmNlLmdldEJ5VWlkKHRoaXMuQ3VzdG9tZXJHZW5lcmFsR3JvdXBJZCk7XHJcbiAgICAgICAgICAgICAgICAvLyAgICBpZiAoZGF0YSkge1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgIGRhdGEuc2V0KFwiY2hlY2tlZFwiLCB0cnVlKTtcclxuICAgICAgICAgICAgICAgIC8vICAgIH1cclxuICAgICAgICAgICAgICAgIC8vICAgIC8vdmFyIEdyb3VwTm9kZSA9IHRyZWV2aWV3LmZpbmRCeUlkKHRoaXMuQ3VzdG9tZXJHZW5lcmFsR3JvdXBJZCk7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAvL3RyZWV2aWV3LmRhdGFJdGVtKEdyb3VwTm9kZSkuc2V0KFwiY2hlY2tlZFwiLCB0cnVlKTtcclxuICAgICAgICAgICAgICAgIC8vfSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLkN1c3RJZFRleHQgPSBcIiggXCIgKyB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCArIFwiIClcIjtcclxuICAgICAgICAgICAgICAgIHRoaXMuSXNGaWxlQXN0eHRTaG93ID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB0aGlzLkhpZGVTaG93RmlsZUFzdHh0KCk7XHJcblxyXG4gICAgICAgICAgICAgICAgLy9hbGVydCh0aGlzLlJFUyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcbiAgICBDaGVja1Bob25lVHlwZShQaG9uZU9iaikge1xyXG4gICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgLy9hbGVydChQaG9uZU9iai5QaG9uZVR5cGVJZCArIFwiIHwgXCIgKyBqUXVlcnkoXCIjUGhvbmVUeXBlXCIpLnZhbCgpKTtcclxuICAgICAgICB2YXIgcHJldGVtcCA9IFtdO1xyXG4gICAgICAgIGpRdWVyeSgnc2VsZWN0W25hbWVePVwicGh0eXBlXCJdJykuZWFjaChmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIHByZXRlbXAucHVzaChqUXVlcnkodGhpcykudmFsKCkpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHZhciBpbmRleCA9IDA7XHJcbiAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzID09IFBob25lT2JqKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaW5kZXggPSBpbmRleCArIDE7XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGlmIChwcmV0ZW1wW2luZGV4XSAhPSB1bmRlZmluZWQgJiYgcHJldGVtcFtpbmRleF0gIT0gbnVsbCAmJiBwcmV0ZW1wW2luZGV4XSAhPSBcIlwiKSB7XHJcbiAgICAgICAgICAgIHZhciBQaG9uZVR5cGVJZCA9IHByZXRlbXBbaW5kZXhdO1xyXG4gICAgICAgICAgICB0aGlzLl9jdXN0b21lclNlcnZpY2UuR2V0UGhvbmVUeXBlRGV0KFBob25lVHlwZUlkKS5zdWJzY3JpYmUoXHJcbiAgICAgICAgICAgICAgICAoZGF0YSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9cclxuICAgICAgICAgICAgICAgICAgICB2YXIgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKGRhdGEpO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuRGF0YSAhPSB1bmRlZmluZWQgJiYgcmVzcG9uc2UuRGF0YSAhPSBudWxsICYmIHJlc3BvbnNlLkRhdGEgIT0gXCJcIikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2FsZXJ0KGluZGV4ICsgXCIgfCBcIiArIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lc1tpbmRleF0uSXNTbXMgKyBcIiB8IFwiICsgcmVzcG9uc2UuRGF0YS5UZXh0KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5EYXRhLlRleHQgPT0gXCIxXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXNbaW5kZXhdLklzU21zID0gMTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXNbaW5kZXhdLnBocHVibGlzaCA9IDE7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzW3RoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlscy5sZW5ndGggLSAxXS5wdWJsaXNoID0gMTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lc1tpbmRleF0ucGhwdWJsaXNoID0gMDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXNbaW5kZXhdLklzU21zID0gMDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJFbWFpbHNbdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzLmxlbmd0aCAtIDFdLnB1Ymxpc2ggPSAwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2FsZXJ0KHRoaXMuUkVTKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgLy92YXIgdHJlZXZpZXdEYXRhU291cmNlID0galF1ZXJ5KFwiI2dyb3VwVHJlZVwiKS5kYXRhKFwia2VuZG9UcmVlVmlld1wiKS5kYXRhU291cmNlLnZpZXcoKTtcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAoZXJyKSA9PiB7XHJcblxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICgpID0+IHtcclxuXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgZWRpdEVtYWlsRGV0KEVtYWlsT2JqKTogb2JzZXJ2YWJsZSB7XHJcbiAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICB2YXIgaW5kZXggPSAwO1xyXG4gICAgICAgIHRoaXMuSXNSZWNvcmRFZGl0TW9kZSA9IHRydWU7XHJcbiAgICAgICAgdGhpcy5CVE5fUEhBREQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0JUTl9QSEVESVQ7XHJcbiAgICAgICAgXHJcblxyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMuRW1haWxNb2RlbC5FbWFpbCA9IEVtYWlsT2JqLkVtYWlsO1xyXG4gICAgICAgIHRoaXMuRW1haWxNb2RlbC5FbWFpbE5hbWUgPSBFbWFpbE9iai5FbWFpbE5hbWU7XHJcbiAgICAgICAgdGhpcy5FbWFpbE1vZGVsLk5ld3NsZXR0ZXJlID0gRW1haWxPYmouTmV3c2xldHRlcmU7XHJcblxyXG5cclxuICAgICAgICB0aGlzLkVkaXRFbWFpbERhdGEgPSB7fTtcclxuICAgICAgICB0aGlzLkVkaXRFbWFpbERhdGEgPSBFbWFpbE9iajtcclxuICAgIH1cclxuICAgIGRlbEVtYWlsRGV0KEVtYWlsT2JqKTogb2JzZXJ2YWJsZSB7XHJcbiAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICB2YXIgaW5kZXggPSAwO1xyXG4gICAgICAgIGpRdWVyeS5lYWNoKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlscywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICBpZiAodGhpcyA9PSBFbWFpbE9iaikge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaW5kZXggPSBpbmRleCArIDE7XHJcblxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlscy5zcGxpY2UoaW5kZXgsIDEpO1xyXG4gICAgfVxyXG5cclxuICAgIGVkaXRBZGRyZXNzRGV0KEFkZHJlc3NPYmopOiBvYnNlcnZhYmxlIHtcclxuICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgIHZhciBpbmRleCA9IDA7XHJcbiAgICAgICAgdGhpcy5Jc1JlY29yZEVkaXRNb2RlID0gdHJ1ZTtcclxuICAgICAgICB0aGlzLkJUTl9QSEFERCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfQlROX1BIRURJVDtcclxuICAgICAgICBcclxuICAgICAgIC8vIEFkZHJlc3NPYmouQ2l0eU5hbWUgPSBqUXVlcnkoXCIjQ2l0eVwiKS52YWwoKTtcclxuXHJcbiAgICAgICAgdGhpcy5BZGRyZXNzLlN0cmVldCA9IEFkZHJlc3NPYmouU3RyZWV0O1xyXG4gICAgICAgIHRoaXMuQWRkcmVzcy5TdHJlZXQyID0gQWRkcmVzc09iai5TdHJlZXQyO1xyXG4gICAgICAgIHRoaXMuQWRkcmVzcy5DaXR5TmFtZSA9IEFkZHJlc3NPYmouQ2l0eU5hbWU7XHJcbiAgICAgICAgdGhpcy5BZGRyZXNzLlppcCA9IEFkZHJlc3NPYmouWmlwO1xyXG4gICAgICAgIHRoaXMuQWRkcmVzcy5Db3VudHJ5Q29kZSA9IEFkZHJlc3NPYmouQ291bnRyeUNvZGU7XHJcbiAgICAgICAgdGhpcy5BZGRyZXNzLlN0YXRlSWQgPSBBZGRyZXNzT2JqLlN0YXRlSWQ7XHJcbiAgICAgICAgdGhpcy5BZGRyZXNzLkFkZHJlc3NUeXBlSWQgPSBBZGRyZXNzT2JqLkFkZHJlc3NUeXBlSWQ7XHJcbiAgICAgICAgdGhpcy5BZGRyZXNzLk1haW5BZGRyZXNzID0gQWRkcmVzc09iai5NYWluQWRkcmVzcztcclxuICAgICAgICB0aGlzLkFkZHJlc3MuRm9yRGVsaXZlcnkgPSBBZGRyZXNzT2JqLkZvckRlbGl2ZXJ5O1xyXG5cclxuXHJcbiAgICAgICAgdGhpcy5FZGl0QWRkcmVzc0RhdGEgPSB7fTtcclxuICAgICAgICB0aGlzLkVkaXRBZGRyZXNzRGF0YSA9IEFkZHJlc3NPYmo7XHJcbiAgICB9XHJcblxyXG4gICAgZGVsQWRkcmVzc0RldChBZGRyZXNzT2JqKTogb2JzZXJ2YWJsZSB7XHJcbiAgICAgICAvLyBkZWJ1Z2dlcjsgXHJcbiAgICAgICAgdmFyIGluZGV4ID0gMDtcclxuICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMgPT0gQWRkcmVzc09iaikge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaW5kZXggPSBpbmRleCArIDE7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzLnNwbGljZShpbmRleCwgMSk7XHJcbiAgICB9XHJcbiAgICBlZGl0UGhvbmVEZXQoUGhvbmVPYmopOiBvYnNlcnZhYmxlIHtcclxuICAgICAgICBcclxuICAgICAgICB2YXIgaW5kZXggPSAwO1xyXG4gICAgICAgIHRoaXMuQlROX1BIQUREID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9CVE5fUEhFRElUXHJcbiAgICAgICAgdmFyIHRlbXAgPSBQaG9uZU9iai5QaG9uZVR5cGVJZC5zcGxpdCgnOycpO1xyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMuUGhvbmVNb2RlbC5QaG9uZVR5cGVJZCA9IFBob25lT2JqLlBob25lVHlwZSArIFwiO1wiICsgUGhvbmVPYmouUGhvbmVUeXBlSWQ7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5QaG9uZU1vZGVsLlBob25lVHlwZSA9IFBob25lT2JqLlBob25lVHlwZTtcclxuICAgICAgICB0aGlzLlBob25lTW9kZWwuUHJlZml4ID0gUGhvbmVPYmouUHJlZml4O1xyXG4gICAgICAgIHRoaXMuUGhvbmVNb2RlbC5BcmVhID0gUGhvbmVPYmouQXJlYTtcclxuICAgICAgICB0aGlzLlBob25lTW9kZWwuUGhvbmUgPSBQaG9uZU9iai5QaG9uZTtcclxuICAgICAgICB0aGlzLlBob25lTW9kZWwuSXNTbXMgPSBQaG9uZU9iai5Jc1NtcztcclxuICAgICAgICB0aGlzLlBob25lTW9kZWwuQ29tbWVudHMgPSBQaG9uZU9iai5Db21tZW50cztcclxuICAgICAgICB0aGlzLkVkaXRQaG9uZURhdGEgPSB7fTtcclxuICAgICAgICB0aGlzLkVkaXRQaG9uZURhdGEgPSBQaG9uZU9iajtcclxuICAgIH1cclxuICAgIGRlbFBob25lRGV0KFBob25lT2JqKTogb2JzZXJ2YWJsZSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdmFyIGluZGV4ID0gMDtcclxuICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMgPT0gUGhvbmVPYmopIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGluZGV4ID0gaW5kZXggKyAxO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lcy5zcGxpY2UoaW5kZXgsIDEpO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICBnZXRTZWxlY3RlZEdyb3VwcygpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJHcm91cHMgPSBbXTtcclxuICAgICAgICB2YXIgX0NoZWNrZWRHcm91cHMgPSBbXTtcclxuICAgICAgICBpZiAodGhpcy5Jc1Nob3dBbGwgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgS2VuZG9fdXRpbGl0eS5jaGVja2VkTm9kZUlkcyhqUXVlcnkoXCIjZ3JvdXBUcmVlXCIpLmRhdGEoXCJrZW5kb1RyZWVWaWV3XCIpLmRhdGFTb3VyY2UudmlldygpLCBfQ2hlY2tlZEdyb3Vwcyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgIFxyXG4gICAgICAgICAgICBLZW5kb191dGlsaXR5LmNoZWNrZWROb2RlSWRzKGpRdWVyeShcIiNncm91cFRyZWUxXCIpLmRhdGEoXCJrZW5kb1RyZWVWaWV3XCIpLmRhdGFTb3VyY2UudmlldygpLCBfQ2hlY2tlZEdyb3Vwcyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGZvciAodmFyIGkgPSAwO2k8X0NoZWNrZWRHcm91cHMubGVuZ3RoO2krKyl7XHJcbiAgICAgICAgICAgIHZhciBHT2JqID0ge307XHJcbiAgICAgICAgICAgIEdPYmouQ3VzdG9tZXJHZW5lcmFsR3JvdXBJZCA9IF9DaGVja2VkR3JvdXBzW2ldO1xyXG4gICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJHcm91cHMucHVzaChHT2JqKTtcclxuICAgICBcclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICB9XHJcblxyXG4gICAgTW9yZSgpOiBvYnNlcnZhYmxlIHtcclxuICAgICAgIC8vIGFsZXJ0KFwiY2FsbFwiKTtcclxuICAgICAgICBpZiAodGhpcy5TaG93TW9yZSA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuU2hvd01vcmUgPSBmYWxzZTtcclxuXHJcbiAgICAgICAgICAgIC8vdGhpcy5TaG93TW9yZVRleHQgPSBcIk1vcmVcIjtcclxuICAgICAgICAgICAgdGhpcy5TaG93TW9yZVRleHQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0xOS19MQkxfTU9SRTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgdGhpcy5TaG93TW9yZSA9IHRydWU7XHJcbiAgICAgICAgLy90aGlzLlNob3dNb3JlVGV4dCA9IFwiTGVzc1wiOyBcclxuICAgICAgICB0aGlzLlNob3dNb3JlVGV4dCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfTE5LX0xCTF9MRVNTO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIGJpbmRHcm91cFRyZWUoSXNzaG93YWxsKTogb2JzZXJ2YWJsZSB7XHJcbiAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkdldEdlbmVyYWxHcm91cHMoSXNzaG93YWxsKS5zdWJzY3JpYmUoXHJcbiAgICAgICAgICAgIChkYXRhKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgLy9cclxuICAgICAgICAgICAgICAgIC8vYWxlcnQoSXNzaG93YWxsKTtcclxuICAgICAgICAgICAgICAgIGlmIChJc3Nob3dhbGwgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkoXCIjZ3JvdXBUcmVlXCIpLmh0bWwoXCJMb2RpbmcuLi5cIik7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIHJlcyA9IGpRdWVyeS5wYXJzZUpTT04oZGF0YSkuRGF0YVxyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeShcIiNncm91cFRyZWVcIikua2VuZG9UcmVlVmlldyh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRPbkRlbWFuZDogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tib3hlczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tDaGlsZHJlbjogdHJ1ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2NoZWNrOiB0aGlzLm9uR3JvdXBTZWxlY3QsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhdGFTb3VyY2U6IHJlc1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBncnBpZHMgPSBcIlwiO1xyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckdyb3VwcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBncnBpZHMgKz0gdGhpcy5DdXN0b21lckdlbmVyYWxHcm91cElkICsgXCI7XCI7XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGdycGlkcy5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEtlbmRvX3V0aWxpdHkuY2hlY2tpbmdOb2RlSWRzKGpRdWVyeShcIiNncm91cFRyZWVcIikuZGF0YShcImtlbmRvVHJlZVZpZXdcIikuZGF0YVNvdXJjZS52aWV3KCksIGdycGlkcy5zdWJzdHJpbmcoMCwgZ3JwaWRzLmxlbmd0aCAtIDEpKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeShcIiNncm91cFRyZWUxXCIpLmh0bWwoXCJMb2RpbmcuLi5cIik7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIHJlcyA9IGpRdWVyeS5wYXJzZUpTT04oZGF0YSkuRGF0YVxyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeShcIiNncm91cFRyZWUxXCIpLmtlbmRvVHJlZVZpZXcoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsb2FkT25EZW1hbmQ6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrYm94ZXM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrQ2hpbGRyZW46IHRydWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9jaGVjazogdGhpcy5vbkdyb3VwU2VsZWN0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkYXRhU291cmNlOiByZXNcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgZ3JwaWRzID0gXCJcIjtcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJHcm91cHMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZ3JwaWRzICs9IHRoaXMuQ3VzdG9tZXJHZW5lcmFsR3JvdXBJZCArIFwiO1wiO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChncnBpZHMubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBLZW5kb191dGlsaXR5LmNoZWNraW5nTm9kZUlkcyhqUXVlcnkoXCIjZ3JvdXBUcmVlMVwiKS5kYXRhKFwia2VuZG9UcmVlVmlld1wiKS5kYXRhU291cmNlLnZpZXcoKSwgZ3JwaWRzLnN1YnN0cmluZygwLCBncnBpZHMubGVuZ3RoIC0gMSkpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLy92YXIgdHJlZXZpZXdEYXRhU291cmNlID0galF1ZXJ5KFwiI2dyb3VwVHJlZVwiKS5kYXRhKFwia2VuZG9UcmVlVmlld1wiKS5kYXRhU291cmNlLnZpZXcoKTtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgKGVycikgPT4ge1xyXG5cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgKCkgPT4ge1xyXG5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICk7XHJcbiAgICB9XHJcbiAgICBHZXREYXRhRm9yU2VhcmNoKGV2ZW50OiBhbnkpOiBvYnNlcnZhYmxlIHtcclxuICAgICAgICBcclxuICAgICAgICAvL3RoaXMuU2VhcmNoVmFsID0galF1ZXJ5KFwiI1NlYXJjaHR4dFwiKS52YWwoKTtcclxuICAgICAgICAvL2FsZXJ0KGV2ZW50LmtleUNvZGUpO1xyXG4gICAgICAgIC8vaWYgKHRoaXMuU2VhcmNoVmFsICE9IHVuZGVmaW5lZCAmJiB0aGlzLlNlYXJjaFZhbCAhPSBcIlwiICYmIHRoaXMuU2VhcmNoVmFsICE9IG51bGwgJiYgZXZlbnQua2V5Q29kZSA9PSAxMykge1xyXG4gICAgICAgICAgICAvL2FsZXJ0KHRoaXMuYXV0b2NvbXBsZXRlU2VsZWN0ICsgXCIgXCIgKyB0aGlzLmF1dG9jb21wbGV0ZU5vUmVzdWx0cyk7XHJcbiAgICAgICAgLy8gICAgdGhpcy5FbnRlckNvdW50Kys7XHJcbiAgICAgICAgLy8gICAgaWYgKHRoaXMuRW50ZXJDb3VudCA+PSAyKSB7XHJcbiAgICAgICAgLy8gICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRDb21wbGV0ZVNlYXJjaCh0aGlzLlNlYXJjaFZhbCkuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgLy8gICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgIC8vICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgIC8vICAgICAgICAgICAgICAgIGFsZXJ0KHJlc3BvbnNlLkVyck1zZyk7XHJcbiAgICAgICAgLy8gICAgICAgICAgICB9XHJcbiAgICAgICAgLy8gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAvLyAgICAgICAgICAgICAgICB0aGlzLkN1c3RMaXN0ID0ge307XHJcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgdGhpcy5DdXN0TGlzdCA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLkRhdGEgIT0gbnVsbCAmJiByZXNwb25zZS5EYXRhICE9IHVuZGVmaW5lZCkge1xyXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICB0aGlzLmN1c3RTZWFyY2hEYXRhID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgalF1ZXJ5KFwiI0N1c3RNb2RhbFwiKS5tb2RhbChcInNob3dcIik7XHJcblxyXG4gICAgICAgIC8vICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8gICAgICAgICAgICB9XHJcbiAgICAgICAgLy8gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgIC8vICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIC8vICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgLy8gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICAvLyAgICAgICAgfSk7XHJcbiAgICAgICAgLy8gICAgICAgIHRoaXMuRW50ZXJDb3VudCA9IDA7XHJcbiAgICAgICAgLy8gICAgfVxyXG4gICAgICAgICAgICAgICBcclxuICAgICAgICAvL31cclxuICAgICAgICAvL3RoaXMuU2VhcmNoVmFsID0gXCJcIjtcclxuICAgIH1cclxuXHJcblxyXG4gICAgbmdPbkluaXQoKSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICAvL2Jvb3Rib3guYWxlcnQoXCJUaGlzIGlzIHRoZSBkZWZhdWx0IGFsZXJ0IVwiKTtcclxuICAgICAgICBpZiAobG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJsYW5nXCIpID09IFwiXCIpIHtcclxuICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJsYW5nXCIsIFwiZW5cIik7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICh0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZ2V0Q29va2llKFwibGFuZ1wiKSA9PSBcIlwiKSB7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2Uuc2V0Q29va2llKFwibGFuZ1wiLCBcImVuXCIsIDEwKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5Jc0NhbmNlbCA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMuc2hvd2hpZGVHcm91cHMoKTtcclxuICAgICAgICB0aGlzLklzRmlsZUFzdHh0U2hvdyA9IHRydWU7XHJcbiAgICAgICAgXHJcbiAgICAgICAgLy90aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCA9IC0xO1xyXG4gICAgICAgIFxyXG4gICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJJZCA+PSAwKSB7XHJcbiAgICAgICAgICAgIC8vdGhpcy5Jc0ZpbGVBc3R4dFNob3cgPSBmYWxzZTtcclxuICAgICAgICAgICAgdGhpcy5lZGl0Q3VzdERldCh0aGlzLm1vZGVsSW5wdXQpO1xyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgdGhpcy5TQVZFX0JUTl9URVhUID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9CVE5fVVBEQVRFO1xyXG4gICAgICAgICAgICAvL3RoaXMuQUREX05FV19DVVNUX1RFWFQgPSB0aGlzLlJFUy5DVVNUT01FUl9NQVNURVIuQVBQX0xCTF9VUERBVEVfQ1VTVDtcclxuICAgICAgICAgICAgLy90aGlzLkNTU1RFWFQgPSBcIm1kaS1jb250ZW50LWFkZFwiO1xyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3Nlcy5sZW5ndGggPT0gMCkge1xyXG4gICAgICAgICAgICAgICAgdmFyIGVtcGlkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJlbXBsb3llZWlkXCIpO1xyXG5cclxuICAgICAgICAgICAgICAgIHZhciBjY29kZSA9IHRoaXMuX3Jlc291cmNlU2VydmljZS5nZXRDb29raWUoZW1waWQgKyBcImNjb2RlXCIpO1xyXG4gICAgICAgICAgICAgICAgaWYgKGNjb2RlLmxlbmd0aCA+IDApXHJcbiAgICAgICAgICAgICAgICAgICAgY2NvZGUgPSBjY29kZS5zdWJzdHJpbmcoMSwgY2NvZGUubGVuZ3RoKTtcclxuICAgICAgICAgICAgICAgIHZhciBhZGlkID0gXCJcIjtcclxuICAgICAgICAgICAgICAgIHZhciBjb21wdGV4dCA9IFwiSG9tZVwiO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5Db21wYW55ICE9IFwiXCIgJiYgdGhpcy5tb2RlbElucHV0LkNvbXBhbnkgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dC5Db21wYW55ICE9IG51bGwpIHtcclxuICAgICAgICAgICAgICAgICAgICBjb21wdGV4dCA9IFwiV29ya1wiO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5fQWRkcmVzc1R5cGVzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuVGV4dCA9PSBjb21wdGV4dCkge1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgYWRpZCA9IHRoaXMuVmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJBZGRyZXNzZXMgPSBbeyBTdHJlZXQ6IFwiXCIsIFN0cmVldDI6IFwiXCIsIENpdHlOYW1lOiBcIlwiLCBaaXA6IFwiXCIsIENvdW50cnlDb2RlOiBjY29kZSwgU3RhdGVJZDogXCJcIiwgQWRkcmVzc1R5cGVJZDogYWRpZCwgRm9yRGVsaXZlcnk6IGZhbHNlLCBNYWluQWRkcmVzczogZmFsc2UsIE1haW5PcmRlcjogXCJNYWluQWRkcjFcIiwgRGVsdnJ5T3JkZXI6IFwiRGVsdnJ5MVwiIH1dO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRoaXMuQ3VzdElkVGV4dCA9IFwiKCBcIiArIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lcklkICsgXCIgKVwiXHJcbiAgICAgICAgICAgIHRoaXMuSXNGaWxlQXN0eHRTaG93ID0gZmFsc2U7XHJcbiAgICAgICAgICAgIC8vdGhpcy5IaWRlU2hvd0ZpbGVBc3R4dCgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLkxhbmcgPSB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZ2V0Q29va2llKFwibGFuZ1wiKTtcclxuICAgICAgICBpZiAodGhpcy5MYW5nLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgdGhpcy5MYW5nID0gdGhpcy5MYW5nLnN1YnN0cmluZygxLCB0aGlzLkxhbmcubGVuZ3RoKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5IaWRlU2hvd0ZpbGVBc3R4dCgpO1xyXG4gICAgICAgLy90aGlzLlJFUyA9IGpRdWVyeS5wYXJzZUpTT04odGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkdldExhbmdSZXModGhpcy5Gb3JtdHlwZSwgdGhpcy5MYW5nKSkuRGF0YTsgLy9qUXVlcnkucGFyc2VKU09OKGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwibGFuZ3Jlc291cmNlXCIpKTtcclxuICAgICAgICBcclxuICAgICAgICBpZiAodGhpcy5MYW5nID09IFwiaGVcIikge1xyXG4gICAgICAgICAgICB0aGlzLktlbmRvUlRMQ1NTID0gXCJrLXJ0bFwiO1xyXG4gICAgICAgICAgICB0aGlzLkNIQU5HRURJUiA9IFwicnRsbW9kYWxcIjtcclxuICAgICAgICAgICAgdGhpcy5DaGFuZ2VEaWFsb2cgPSBcImlucHV0X3JpZ2h0XCI7XHJcbiAgICAgICAgICAgIC8valF1ZXJ5KFwiLmJvb3Rib3gtY2xvc2UtYnV0dG9uXCIpLmNzcyhcImZsb2F0XCIsIFwibGVmdCFpbXBvcnRhbnRcIik7XHJcbiAgICAgICAgICAgIC8valF1ZXJ5KFwiLm1vZGFsLWZvb3RlciBidXR0b246YmVmb3JlXCIpLmNzcyhcImZsb2F0XCIsIFwibGVmdCFpbXBvcnRhbnRcIik7XHJcbiAgICAgICAgICAgIC8valF1ZXJ5KFwiLm1vZGFsLWZvb3RlciBidXR0b246YWZ0ZXJcIikuY3NzKFwiZmxvYXRcIiwgXCJsZWZ0IWltcG9ydGFudFwiKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuQ0hBTkdFRElSID0gXCJsdHJtb2RhbFwiO1xyXG4gICAgICAgICAgICB0aGlzLkNoYW5nZURpYWxvZyA9IFwiaW5wdXRfbGVmdFwiO1xyXG4gICAgICAgIH1cclxuXHJcblxyXG4gICAgICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLkdldExhbmdSZXModGhpcy5Gb3JtdHlwZSwgdGhpcy5MYW5nKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICB0aGlzLlJFUyA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgIHRoaXMuU2hvd01vcmVUZXh0ID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9MTktfTEJMX01PUkU7XHJcbiAgICAgICAgICAgICAgIHRoaXMuR3JvdXBUZXh0ID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9MQkxfU0hPV0dST1VQUztcclxuICAgICAgICAgICAgICAgdGhpcy5TQVZFX0JUTl9URVhUID0gdGhpcy5SRVMuQ1VTVE9NRVJfTUFTVEVSLkFQUF9CVE5fU0FWRTtcclxuICAgICAgICAgICAgICAgdGhpcy5BRERfTkVXX0NVU1RfVEVYVCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfTEJMX05FV19DVVNUO1xyXG4gICAgICAgICAgICAgICB0aGlzLkZJTEVBU19CVE5fVEVYVCA9IHRoaXMuUkVTLkNVU1RPTUVSX01BU1RFUi5BUFBfQlROX0ZJTEVBUztcclxuICAgICAgICAgICAgICAgLy9hbGVydCh0aGlzLlJFUyk7XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgfSk7XHJcbiAgICAgICAvL3RoaXMuU2hvd01vcmVUZXh0ID0gXCJNb3JlXCI7XHJcbiAgICAgICBcclxuICAgICAgIC8vLy9DaXRpZXNcclxuICAgICAgIHZhciBDb3VudHJ5Q29kZSA9IHRoaXMuQWRkcmVzcy5Db3VudHJ5Q29kZTtcclxuICAgICAgIHZhciBTdGF0ZU5hbWUgPSB0aGlzLkFkZHJlc3MuU3RhdGVJZDtcclxuICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRDaXRpZXMoQ291bnRyeUNvZGUsIFN0YXRlTmFtZSkuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZywgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICB9XHJcbiAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgIHZhciB0eXBlYWhlYWRTb3VyY2UgPSBbXTtcclxuICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2gocmVzcG9uc2UuRGF0YSwgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgICAgdmFyIG5ld3RlbXAgPSB7fTtcclxuICAgICAgICAgICAgICAgICAgIG5ld3RlbXAuaWQgPSB0aGlzLlZhbHVlO1xyXG4gICAgICAgICAgICAgICAgICAgbmV3dGVtcC5uYW1lID0gdGhpcy5UZXh0O1xyXG4gICAgICAgICAgICAgICAgICAgdHlwZWFoZWFkU291cmNlLnB1c2gobmV3dGVtcCk7XHJcbiAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICB0aGlzLl9DaXRpZXMgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICBqUXVlcnkoJyNDaXR5JykudHlwZWFoZWFkKHtcclxuICAgICAgICAgICAgICAgICAgIC8vZGF0YTogdGhpcy5fQ2l0aWVzLFxyXG4gICAgICAgICAgICAgICAgICAgc291cmNlOiB0eXBlYWhlYWRTb3VyY2UsXHJcbiAgICAgICAgICAgICAgICAgICAvL2Rpc3BsYXk6IFwidGV4dFwiLFxyXG4gICAgICAgICAgICAgICAgICAgZGF0YVR5cGU6IFwiSlNPTlwiLFxyXG4gICAgICAgICAgICAgICAgICAgLy9oaW50OiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgLy9oaWdobGlnaHQ6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAvL21pbkxlbmd0aDogMSxcclxuICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgfSk7XHJcblxyXG4gICAgICAgXHJcbiAgICAgICBcclxuICAgICAgICAgIFxyXG5cclxuXHJcbiAgICAgICAgdGhpcy5sYW5ndWFnZUFycmF5ID0gdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLkdldEF2YWlsYWJsZUxhbmd1YWdlcygpO1xyXG4gICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRDdXN0b21lclR5cGVzKCkuc3Vic2NyaWJlKHJlc3A9PiB7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICB2YXIgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3ApO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fQ3VzdFR5cGVzID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJUeXBlID09IFwiXCIgfHwgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyVHlwZSA9PSB1bmRlZmluZWQgfHwgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyVHlwZSA9PSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIEN1c3R0eXBlSWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5fQ3VzdFR5cGVzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEN1c3R0eXBlSWQgPSB0aGlzLlZhbHVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyVHlwZSA9IEN1c3R0eXBlSWQ7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIFxyXG4gICAgICAgIC8vLy9Tb3VyY2VzXHJcbiAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkdldFNvdXJjZXMoKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX1NvdXJjZXMgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5DYW1lRnJvbUN1c3RvbWVyID09IFwiXCIgfHwgdGhpcy5tb2RlbElucHV0LkNhbWVGcm9tQ3VzdG9tZXIgPT0gdW5kZWZpbmVkIHx8IHRoaXMubW9kZWxJbnB1dC5DYW1lRnJvbUN1c3RvbWVyID09IG51bGwpIHtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgU291cmNlO1xyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMuX1NvdXJjZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgU291cmNlID0gdGhpcy5WYWx1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DYW1lRnJvbUN1c3RvbWVyID0gU291cmNlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICAvL0dldEVtcGxveWVlc1xyXG4gICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRFbXBsb3llZXMoKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZywgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9FbXBsb3llZXMgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5lbXBsb3llZWlkID09IFwiXCIgfHwgdGhpcy5tb2RlbElucHV0LmVtcGxveWVlaWQgPT0gdW5kZWZpbmVkIHx8IHRoaXMubW9kZWxJbnB1dC5lbXBsb3llZWlkID09IG51bGwpIHtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgZW1waWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5fRW1wbG95ZWVzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGVtcGlkID0gdGhpcy5WYWx1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5lbXBsb3llZWlkID0gZW1waWQ7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgLy9HZXRTdWZmaXhlc1xyXG4gICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRTdWZmaXhlcygpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX1N1ZmZpeGVzID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuICAgICAgICAvL0dldFBob25lVHlwZXNcclxuICAgICAgICB0aGlzLl9jdXN0b21lclNlcnZpY2UuR2V0UGhvbmVUeXBlcygpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLCBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX1Bob25lVHlwZXMgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgdmFyIHBoaWQgPSBcIlwiO1xyXG4gICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5fUGhvbmVUeXBlcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLlRleHQgPT0gXCJDZWxsUGhvbmVcIikge1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgcGhpZCA9IHRoaXMuVmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lc1swXS5QaG9uZVR5cGVJZCA9IHBoaWQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgfSk7XHJcblxyXG5cclxuICAgICAgICB2YXIgZXB1Ymxpc2ggPSAwO1xyXG4gICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJQaG9uZXMubGVuZ3RoID09IDApIHtcclxuICAgICAgICAgICAgdmFyIHBoaWQgPSBcIlwiO1xyXG5cclxuICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5fUGhvbmVUeXBlcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuVGV4dCA9PSBcIkNlbGxQaG9uZVwiKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHBoaWQgPSB0aGlzLlZhbHVlO1xyXG4gICAgICAgICAgICAgICAgICAgIGVwdWJsaXNoID0gMTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzID0gW3sgUGhvbmVUeXBlSWQ6IHBoaWQsIFByZWZpeDogXCJcIiwgQXJlYTogXCJcIiwgUGhvbmU6IFwiXCIsIElzU21zOiBlcHVibGlzaCwgQ29tbWVudHM6IFwiXCIsIHBocHVibGlzaDogZXB1Ymxpc2gsIFNNU09yZGVyOiBcIlNNUzFcIiwgUHVibGlzaE9yZGVyOlwiUHViMVwiIH1dO1xyXG4gICAgICAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzLmxlbmd0aCA9PSAwKSB7XHJcbiAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlscyA9IFt7IEVtYWlsOiBcIlwiLCBFbWFpbE5hbWU6IHRoaXMubW9kZWxJbnB1dC5GaWxlQXMsIE5ld3NsZXR0ZXJlOiBmYWxzZSwgcHVibGlzaDogZXB1Ymxpc2gsIE5ld3NPcmRlcjogXCJOZXdzMVwiLCBFUHVibGlzaE9yZGVyOlwiRVB1YjFcIiB9XVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy9HZXRBZGRyZXNzVHlwZXNcclxuICAgICAgICB0aGlzLl9jdXN0b21lclNlcnZpY2UuR2V0QWRkcmVzc1R5cGVzKCkuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fQWRkcmVzc1R5cGVzID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICB2YXIgYWRpZCA9IFwiXCI7XHJcbiAgICAgICAgICAgICAgICBqUXVlcnkuZWFjaCh0aGlzLl9BZGRyZXNzVHlwZXMsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5UZXh0ID09IFwiSG9tZVwiKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhZGlkID0gdGhpcy5WYWx1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3Nlc1swXS5BZGRyZXNzVHlwZUlkID0gYWRpZDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuICAgICAgICAvL0dyb3Vwc1xyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRHcm91cHMoKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZywgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9Hcm91cHMgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIC8vLy9Db3VudHJpZXNcclxuICAgICAgICBcclxuICAgICAgICB0aGlzLl9jdXN0b21lclNlcnZpY2UuR2V0Q291bnRyaWVzKCkuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fQ291bnRyaWVzID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuICAgICAgICAvLy8vU3RhdGVzXHJcbiAgICAgICAgdmFyIENvdW50cnlDb2RlPSB0aGlzLkFkZHJlc3MuQ291bnRyeUNvZGU7XHJcbiAgICAgICAgdGhpcy5fY3VzdG9tZXJTZXJ2aWNlLkdldFN0YXRlcyhDb3VudHJ5Q29kZSkuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fU3RhdGVzID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuICAgICAgICBcclxuICAgICAgICBcclxuICAgICAgICAvL1RyZWUgR3JvdXBcclxuXHJcbiAgICAgICAgLy90aGlzLmJpbmRHcm91cFRyZWUodGhpcy5Jc1Nob3dBbGwpO1xyXG4gICAgICAgIHRoaXMuX2N1c3RvbWVyU2VydmljZS5HZXRHZW5lcmFsR3JvdXBzKHRoaXMuSXNTaG93QWxsKS5zdWJzY3JpYmUoXHJcbiAgICAgICAgICAgIChkYXRhKSA9PiB7XHJcbiAgICAgICAgICAgICAgIC8vIGRlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuSXNTaG93QWxsID09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5KFwiI2dyb3VwVHJlZVwiKS5odG1sKFwiTG9kaW5nLi4uXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciByZXMgPSBqUXVlcnkucGFyc2VKU09OKGRhdGEpLkRhdGFcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkoXCIjZ3JvdXBUcmVlXCIpLmtlbmRvVHJlZVZpZXcoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsb2FkT25EZW1hbmQ6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrYm94ZXM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrQ2hpbGRyZW46IHRydWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9jaGVjazogdGhpcy5vbkdyb3VwU2VsZWN0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkYXRhU291cmNlOiByZXNcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIGdycGlkcyA9IFwiXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5tb2RlbElucHV0LkN1c3RvbWVyR3JvdXBzLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGdycGlkcyArPSB0aGlzLkN1c3RvbWVyR2VuZXJhbEdyb3VwSWQgKyBcIjtcIjtcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoZ3JwaWRzLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgS2VuZG9fdXRpbGl0eS5jaGVja2luZ05vZGVJZHMoalF1ZXJ5KFwiI2dyb3VwVHJlZVwiKS5kYXRhKFwia2VuZG9UcmVlVmlld1wiKS5kYXRhU291cmNlLnZpZXcoKSwgZ3JwaWRzLnN1YnN0cmluZygwLCBncnBpZHMubGVuZ3RoIC0gMSkpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5KFwiI2dyb3VwVHJlZTFcIikuaHRtbChcIkxvZGluZy4uLlwiKTtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgcmVzID0galF1ZXJ5LnBhcnNlSlNPTihkYXRhKS5EYXRhXHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5KFwiI2dyb3VwVHJlZTFcIikua2VuZG9UcmVlVmlldyh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRPbkRlbWFuZDogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tib3hlczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tDaGlsZHJlbjogdHJ1ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2NoZWNrOiB0aGlzLm9uR3JvdXBTZWxlY3QsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhdGFTb3VyY2U6IHJlc1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBncnBpZHMgPSBcIlwiO1xyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckdyb3VwcywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBncnBpZHMgKz0gdGhpcy5DdXN0b21lckdlbmVyYWxHcm91cElkICsgXCI7XCI7XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGdycGlkcy5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEtlbmRvX3V0aWxpdHkuY2hlY2tpbmdOb2RlSWRzKGpRdWVyeShcIiNncm91cFRyZWUxXCIpLmRhdGEoXCJrZW5kb1RyZWVWaWV3XCIpLmRhdGFTb3VyY2UudmlldygpLCBncnBpZHMuc3Vic3RyaW5nKDAsIGdycGlkcy5sZW5ndGggLSAxKSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIChlcnIpID0+IHtcclxuXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICgpID0+IHtcclxuXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICApO1xyXG4gICAgICAgIFxyXG4gICAgICAgIC8vYWxlcnQobW9tZW50KCkuZm9ybWF0KCdEIE1NTSBZWVlZJykpOyAgICAgICBcclxuICAgICAgIC8vIHRoaXMuYmFzZVVybCArIFwiRHJvcGRvd24vQmluZEF1dG9Db21wbGV0ZVNyY2hcIlxyXG4gICAgICAgIHZhciBTcmNoRGF0YSA9IG51bGw7XHJcbiAgICAgICAgICAgXHJcbiAgICAgICAgLy9hbGVydCgnSGknKTtcclxuICAgICAgICBqUXVlcnkoXCIjRW1haWxUYWJsZSB0Ym9keSB0ciB0ZCBhW25hbWU9ZGVsRWJ0bl1cIikubm90KFwiOmxhc3RcIikuaGlkZSgpO1xyXG4gICAgICAgIGpRdWVyeShcIiNFbWFpbFRhYmxlIHRib2R5IHRyIGFbbmFtZT1hZGRFYnRuXVwiKS5ub3QoXCI6bGFzdFwiKS5zaG93KCk7XHJcbiAgICAgICAgLy8kKCcubW9kYWwnKS5tb2RhbCgpO1xyXG4gICAgICAgIFxyXG4gICAgfVxyXG59XHJcbiJdfQ==
