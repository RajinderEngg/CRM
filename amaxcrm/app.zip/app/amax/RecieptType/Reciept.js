System.register(["angular2/core", 'angular2/common', "../../services/ResourceService", "angular2/router", "../../services/RecieptService"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, common_1, ResourceService_1, router_1, RecieptService_1;
    var AmaxReciept;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (ResourceService_1_1) {
                ResourceService_1 = ResourceService_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (RecieptService_1_1) {
                RecieptService_1 = RecieptService_1_1;
            }],
        execute: function() {
            AmaxReciept = (function () {
                // @ViewChild('RTLDiv') private myScrollContainer: ElementRef;
                function AmaxReciept(_resourceService, _RecieptService, _routeParams) {
                    this._resourceService = _resourceService;
                    this._RecieptService = _RecieptService;
                    this._routeParams = _routeParams;
                    this.RES = {};
                    this.Formtype = "SCREEN_RECIEPTTYPE";
                    this.Lang = "";
                    this._RecieptTypeList = [];
                    this._RecieptThnksLettersList = [];
                    this.ReceiptId = -1;
                    this.ReceiptName = "";
                    this.MsgClass = "text-primary";
                    this.modelInput = {};
                    this.ChangeDialog = "";
                    this.CHANGEDIR = "";
                    this.RES.SCREEN_RECIEPTTYPE = {};
                    this.ReceiptName = "";
                    this.modelInput = {};
                    //this.baseUrl = "http://localhost:3000/#/";
                    //debugger;
                    this.baseUrl = _resourceService.AppUrl;
                    this.ReceiptId = _routeParams.params.Id;
                }
                AmaxReciept.prototype.bindReceiptThnksLetterList = function () {
                    var _this = this;
                    this._RecieptService.GetRecieptThnksLettersList(this.ReceiptId).subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._RecieptThnksLettersList = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                //app.controller('TestCtrl', function($scope, $location, $anchorScroll) {
                AmaxReciept.prototype.ViewTemplates = function (ReceiptObj) {
                    //debugger;
                    this.ReceiptId = ReceiptObj.RecieptTypeId;
                    this.ReceiptName = ReceiptObj.RecieptNameEng + " | " + ReceiptObj.RecieptName;
                    this.bindReceiptThnksLetterList();
                    var dist = jQuery('#RTLDiv').offset().top - jQuery('#RTDiv').offset().top;
                    window.scrollTo(0, dist + 10);
                    //var response = this.baseUrl + "/ReceiptType/#RTLDiv";
                    //alert(response);
                    //document.location = response;
                    //$location.hash('RTLDiv');
                    //$anchorScroll();
                    //this.myScrollContainer.nativeElement.scrollTop = this.myScrollContainer.nativeElement.scrollHeight;
                };
                //}
                AmaxReciept.prototype.deleteReceiptThnksLetter = function (RTLObj) {
                    var _this = this;
                    if (confirm("Do you want to delete")) {
                        this._RecieptService.DeleteReceiptThnksLetter(RTLObj.ThanksLetterId).subscribe(function (resp) {
                            //debugger;
                            var response = jQuery.parseJSON(resp);
                            if (response.IsError == true) {
                                bootbox.alert({
                                    message: response.ErrMsg,
                                    className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                            else {
                                //this.MsgClass = "text-success";
                                //this._RecieptTypeList = response.Data;
                                var index = 0;
                                jQuery.each(_this._RecieptThnksLettersList, function () {
                                    if (this == RTLObj) {
                                        return false;
                                    }
                                    index = index + 1;
                                });
                                _this._RecieptThnksLettersList.splice(index, 1);
                                bootbox.alert({
                                    message: response.ErrMsg,
                                    className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                        }, function (error) {
                            console.log(error);
                        }, function () {
                            console.log("CallCompleted");
                        });
                    }
                };
                AmaxReciept.prototype.AddRTLScreen = function () {
                    //if (confirm("Do you want to add new")) {
                    var response = this.baseUrl + "ReceiptTemplate/Add/0";
                    //alert(response);
                    document.location = response;
                    //}
                };
                AmaxReciept.prototype.EditTemplate = function (RcptThnksLtrObj) {
                    var response = this.baseUrl + "Template/Edit/" + RcptThnksLtrObj.ThanksLetterId + "/Rec";
                    //alert(response);
                    document.location = response;
                };
                AmaxReciept.prototype.EditReceiptThnksLetter = function (RcptThnksLtrObj) {
                    var response = this.baseUrl + "ReceiptTemplate/Add/" + RcptThnksLtrObj.ThanksLetterId;
                    //alert(response);
                    document.location = response;
                };
                AmaxReciept.prototype.ngOnInit = function () {
                    var _this = this;
                    this.Lang = localStorage.getItem("lang");
                    this._resourceService.GetLangRes(this.Formtype, this.Lang).subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.RES = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    this._RecieptService.GetRecieptTypeList().subscribe(function (resp) {
                        //debugger;
                        var response = jQuery.parseJSON(resp);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._RecieptTypeList = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    if (this.ReceiptId != 0) {
                        this.bindReceiptThnksLetterList();
                    }
                };
                AmaxReciept.$inject = ['$scope', '$location', '$anchorScroll'];
                AmaxReciept = __decorate([
                    core_1.Component({
                        templateUrl: './app/amax/RecieptType/templates/RecieptType.html',
                        directives: [common_1.NgSwitch, common_1.NgSwitchWhen, common_1.NgSwitchDefault],
                        providers: [RecieptService_1.RecieptService, ResourceService_1.ResourceService]
                    }), 
                    __metadata('design:paramtypes', [ResourceService_1.ResourceService, RecieptService_1.RecieptService, router_1.RouteParams])
                ], AmaxReciept);
                return AmaxReciept;
            }());
            exports_1("AmaxReciept", AmaxReciept);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFtYXgvUmVjaWVwdFR5cGUvUmVjaWVwdC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztZQWlCQTtnQkFjRyw4REFBOEQ7Z0JBQzdELHFCQUFvQixnQkFBaUMsRUFBVSxlQUErQixFQUFVLFlBQXlCO29CQUE3RyxxQkFBZ0IsR0FBaEIsZ0JBQWdCLENBQWlCO29CQUFVLG9CQUFlLEdBQWYsZUFBZSxDQUFnQjtvQkFBVSxpQkFBWSxHQUFaLFlBQVksQ0FBYTtvQkFiakksUUFBRyxHQUFXLEVBQUUsQ0FBQztvQkFDakIsYUFBUSxHQUFXLG9CQUFvQixDQUFDO29CQUN4QyxTQUFJLEdBQVcsRUFBRSxDQUFDO29CQUNsQixxQkFBZ0IsR0FBRyxFQUFFLENBQUM7b0JBQ3RCLDZCQUF3QixHQUFHLEVBQUUsQ0FBQztvQkFDOUIsY0FBUyxHQUFXLENBQUMsQ0FBQyxDQUFDO29CQUN2QixnQkFBVyxHQUFXLEVBQUUsQ0FBQztvQkFDekIsYUFBUSxHQUFXLGNBQWMsQ0FBQztvQkFDbEMsZUFBVSxHQUFXLEVBQUUsQ0FBQztvQkFDeEIsaUJBQVksR0FBVyxFQUFFLENBQUM7b0JBQzFCLGNBQVMsR0FBVyxFQUFFLENBQUM7b0JBS25CLElBQUksQ0FBQyxHQUFHLENBQUMsa0JBQWtCLEdBQUcsRUFBRSxDQUFDO29CQUNqQyxJQUFJLENBQUMsV0FBVyxHQUFHLEVBQUUsQ0FBQztvQkFDdEIsSUFBSSxDQUFDLFVBQVUsR0FBRyxFQUFFLENBQUM7b0JBQ3JCLDRDQUE0QztvQkFDNUMsV0FBVztvQkFDWCxJQUFJLENBQUMsT0FBTyxHQUFHLGdCQUFnQixDQUFDLE1BQU0sQ0FBQztvQkFDdkMsSUFBSSxDQUFDLFNBQVMsR0FBRyxZQUFZLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztnQkFDNUMsQ0FBQztnQkFFRCxnREFBMEIsR0FBMUI7b0JBQUEsaUJBeUJDO29CQXhCRyxJQUFJLENBQUMsZUFBZSxDQUFDLDBCQUEwQixDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUMxRSxXQUFXO3dCQUNYLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLHdCQUF3QixHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7d0JBRWxELENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7Z0JBQ1AsQ0FBQztnQkFDRCx5RUFBeUU7Z0JBQ3JFLG1DQUFhLEdBQWIsVUFBYyxVQUFVO29CQUNwQixXQUFXO29CQUNYLElBQUksQ0FBQyxTQUFTLEdBQUcsVUFBVSxDQUFDLGFBQWEsQ0FBQztvQkFDMUMsSUFBSSxDQUFDLFdBQVcsR0FBRyxVQUFVLENBQUMsY0FBYyxHQUFHLEtBQUssR0FBRyxVQUFVLENBQUMsV0FBVyxDQUFDO29CQUM5RSxJQUFJLENBQUMsMEJBQTBCLEVBQUUsQ0FBQztvQkFDbEMsSUFBSSxJQUFJLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDLEdBQUcsR0FBRyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsR0FBRyxDQUFDO29CQUUxRSxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRSxJQUFJLEdBQUMsRUFBRSxDQUFDLENBQUM7b0JBQzVCLHVEQUF1RDtvQkFDdkQsa0JBQWtCO29CQUNsQiwrQkFBK0I7b0JBQy9CLDJCQUEyQjtvQkFDM0Isa0JBQWtCO29CQUNsQixxR0FBcUc7Z0JBRXpHLENBQUM7Z0JBQ0wsR0FBRztnQkFDSCw4Q0FBd0IsR0FBeEIsVUFBeUIsTUFBTTtvQkFBL0IsaUJBOENDO29CQTdDRyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ25DLElBQUksQ0FBQyxlQUFlLENBQUMsd0JBQXdCLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7NEJBQy9FLFdBQVc7NEJBQ1gsSUFBSSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzs0QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO2dDQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO29DQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtvQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO29DQUM1QixPQUFPLEVBQUU7d0NBQ0wsRUFBRSxFQUFFOzRDQUNBLGNBQWM7NENBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3lDQUM1QjtxQ0FDSjtpQ0FDSixDQUFDLENBQUM7NEJBRVAsQ0FBQzs0QkFDRCxJQUFJLENBQUMsQ0FBQztnQ0FDRixpQ0FBaUM7Z0NBQ2pDLHdDQUF3QztnQ0FDeEMsSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO2dDQUNkLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLHdCQUF3QixFQUFFO29DQUN2QyxFQUFFLENBQUMsQ0FBQyxJQUFJLElBQUksTUFBTSxDQUFDLENBQUMsQ0FBQzt3Q0FDakIsTUFBTSxDQUFDLEtBQUssQ0FBQTtvQ0FDaEIsQ0FBQztvQ0FDRCxLQUFLLEdBQUcsS0FBSyxHQUFHLENBQUMsQ0FBQztnQ0FDdEIsQ0FBQyxDQUFDLENBQUM7Z0NBQ0gsS0FBSSxDQUFDLHdCQUF3QixDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0NBQy9DLE9BQU8sQ0FBQyxLQUFLLENBQUM7b0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO29DQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7b0NBQzVCLE9BQU8sRUFBRTt3Q0FDTCxFQUFFLEVBQUU7NENBQ0EsY0FBYzs0Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7eUNBQzVCO3FDQUNKO2lDQUNKLENBQUMsQ0FBQzs0QkFDUCxDQUFDO3dCQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7NEJBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQzt3QkFDdkIsQ0FBQyxFQUFFOzRCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7d0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUNQLENBQUM7Z0JBQ0wsQ0FBQztnQkFDRCxrQ0FBWSxHQUFaO29CQUNJLDBDQUEwQztvQkFFdEMsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLE9BQU8sR0FBRSx1QkFBdUIsQ0FBQztvQkFDckQsa0JBQWtCO29CQUNsQixRQUFRLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQztvQkFFakMsR0FBRztnQkFDUCxDQUFDO2dCQUNELGtDQUFZLEdBQVosVUFBYSxlQUFlO29CQUN4QixJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsT0FBTyxHQUFHLGdCQUFnQixHQUFHLGVBQWUsQ0FBQyxjQUFjLEdBQUMsTUFBTSxDQUFDO29CQUN2RixrQkFBa0I7b0JBQ2xCLFFBQVEsQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFDO2dCQUNqQyxDQUFDO2dCQUNELDRDQUFzQixHQUF0QixVQUF1QixlQUFlO29CQUNsQyxJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsT0FBTyxHQUFHLHNCQUFzQixHQUFHLGVBQWUsQ0FBQyxjQUFjLENBQUM7b0JBQ3RGLGtCQUFrQjtvQkFDbEIsUUFBUSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUM7Z0JBQ2pDLENBQUM7Z0JBQ0QsOEJBQVEsR0FBUjtvQkFBQSxpQkFxREM7b0JBcERHLElBQUksQ0FBQyxJQUFJLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDekMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUV6RSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtnQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUM1QixPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsR0FBRyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7d0JBQzdCLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7b0JBRUgsSUFBSSxDQUFDLGVBQWUsQ0FBQyxrQkFBa0IsRUFBRSxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQ3BELFdBQVc7d0JBQ1gsSUFBSSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtnQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUM1QixPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsZ0JBQWdCLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzt3QkFFMUMsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFDSCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ3RCLElBQUksQ0FBQywwQkFBMEIsRUFBRSxDQUFDO29CQUN0QyxDQUFDO2dCQUNMLENBQUM7Z0JBaExNLG1CQUFPLEdBQUcsQ0FBQyxRQUFRLEVBQUUsV0FBVyxFQUFFLGVBQWUsQ0FBQyxDQUFDO2dCQXBCOUQ7b0JBQUMsZ0JBQVMsQ0FBQzt3QkFFUCxXQUFXLEVBQUUsbURBQW1EO3dCQUNoRSxVQUFVLEVBQUUsQ0FBQyxpQkFBUSxFQUFFLHFCQUFZLEVBQUUsd0JBQWUsQ0FBQzt3QkFDckQsU0FBUyxFQUFFLENBQUMsK0JBQWMsRUFBRSxpQ0FBZSxDQUFDO3FCQUMvQyxDQUFDOzsrQkFBQTtnQkFnTUYsa0JBQUM7WUFBRCxDQTlMQSxBQThMQyxJQUFBO1lBOUxELHFDQThMQyxDQUFBIiwiZmlsZSI6ImFtYXgvUmVjaWVwdFR5cGUvUmVjaWVwdC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7Q29tcG9uZW50LCBPdXRwdXQsIElucHV0LCBFdmVudEVtaXR0ZXIsIE9uSW5pdH0gZnJvbSBcImFuZ3VsYXIyL2NvcmVcIjtcclxuaW1wb3J0IHtOZ1N3aXRjaCwgTmdTd2l0Y2hXaGVuLCBOZ1N3aXRjaERlZmF1bHR9IGZyb20gJ2FuZ3VsYXIyL2NvbW1vbidcclxuaW1wb3J0IHtSZXNvdXJjZVNlcnZpY2V9IGZyb20gXCIuLi8uLi9zZXJ2aWNlcy9SZXNvdXJjZVNlcnZpY2VcIjtcclxuaW1wb3J0IHtSb3V0ZVBhcmFtc30gZnJvbSBcImFuZ3VsYXIyL3JvdXRlclwiO1xyXG5pbXBvcnQge1JlY2llcHRTZXJ2aWNlfSBmcm9tIFwiLi4vLi4vc2VydmljZXMvUmVjaWVwdFNlcnZpY2VcIjtcclxuaW1wb3J0IHsganNvblEgfSBmcm9tICcuLi8uLi9qc29uUSc7XHJcbmltcG9ydCB7R3JvdXBGaWx0ZXJQaXBlLCBHcm91cFBhcmVuRmlsdGVyUGlwZSwgS2VuZG9fdXRpbGl0eX0gZnJvbSBcIi4uLy4uL2FtYXhVdGlsXCI7XHJcblxyXG5kZWNsYXJlIHZhciBqUXVlcnk7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuXHJcbiAgICB0ZW1wbGF0ZVVybDogJy4vYXBwL2FtYXgvUmVjaWVwdFR5cGUvdGVtcGxhdGVzL1JlY2llcHRUeXBlLmh0bWwnLFxyXG4gICAgZGlyZWN0aXZlczogW05nU3dpdGNoLCBOZ1N3aXRjaFdoZW4sIE5nU3dpdGNoRGVmYXVsdF0sXHJcbiAgICBwcm92aWRlcnM6IFtSZWNpZXB0U2VydmljZSwgUmVzb3VyY2VTZXJ2aWNlXVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEFtYXhSZWNpZXB0IGltcGxlbWVudHMgT25Jbml0IHtcclxuICAgIGJhc2VVcmw6IHN0cmluZztcclxuICAgIFJFUzogT2JqZWN0ID0ge307XHJcbiAgICBGb3JtdHlwZTogc3RyaW5nID0gXCJTQ1JFRU5fUkVDSUVQVFRZUEVcIjtcclxuICAgIExhbmc6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBfUmVjaWVwdFR5cGVMaXN0ID0gW107XHJcbiAgICBfUmVjaWVwdFRobmtzTGV0dGVyc0xpc3QgPSBbXTtcclxuICAgIFJlY2VpcHRJZDogbnVtYmVyID0gLTE7XHJcbiAgICBSZWNlaXB0TmFtZTogc3RyaW5nID0gXCJcIjtcclxuICAgIE1zZ0NsYXNzOiBzdHJpbmcgPSBcInRleHQtcHJpbWFyeVwiO1xyXG4gICAgbW9kZWxJbnB1dDogT2JqZWN0ID0ge307XHJcbiAgICBDaGFuZ2VEaWFsb2c6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBDSEFOR0VESVI6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBzdGF0aWMgJGluamVjdCA9IFsnJHNjb3BlJywgJyRsb2NhdGlvbicsICckYW5jaG9yU2Nyb2xsJ107XHJcbiAgIC8vIEBWaWV3Q2hpbGQoJ1JUTERpdicpIHByaXZhdGUgbXlTY3JvbGxDb250YWluZXI6IEVsZW1lbnRSZWY7XHJcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIF9yZXNvdXJjZVNlcnZpY2U6IFJlc291cmNlU2VydmljZSwgcHJpdmF0ZSBfUmVjaWVwdFNlcnZpY2U6IFJlY2llcHRTZXJ2aWNlLCBwcml2YXRlIF9yb3V0ZVBhcmFtczogUm91dGVQYXJhbXMpIHtcclxuICAgICAgICBcclxuICAgICAgICB0aGlzLlJFUy5TQ1JFRU5fUkVDSUVQVFRZUEUgPSB7fTtcclxuICAgICAgICB0aGlzLlJlY2VpcHROYW1lID0gXCJcIjtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQgPSB7fTtcclxuICAgICAgICAvL3RoaXMuYmFzZVVybCA9IFwiaHR0cDovL2xvY2FsaG9zdDozMDAwLyMvXCI7XHJcbiAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICB0aGlzLmJhc2VVcmwgPSBfcmVzb3VyY2VTZXJ2aWNlLkFwcFVybDtcclxuICAgICAgICB0aGlzLlJlY2VpcHRJZCA9IF9yb3V0ZVBhcmFtcy5wYXJhbXMuSWQ7XHJcbiAgICB9XHJcbiAgICBcclxuICAgIGJpbmRSZWNlaXB0VGhua3NMZXR0ZXJMaXN0KCkge1xyXG4gICAgICAgIHRoaXMuX1JlY2llcHRTZXJ2aWNlLkdldFJlY2llcHRUaG5rc0xldHRlcnNMaXN0KHRoaXMuUmVjZWlwdElkKS5zdWJzY3JpYmUocmVzcD0+IHtcclxuICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fUmVjaWVwdFRobmtzTGV0dGVyc0xpc3QgPSByZXNwb25zZS5EYXRhO1xyXG5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuICAgIC8vYXBwLmNvbnRyb2xsZXIoJ1Rlc3RDdHJsJywgZnVuY3Rpb24oJHNjb3BlLCAkbG9jYXRpb24sICRhbmNob3JTY3JvbGwpIHtcclxuICAgICAgICBWaWV3VGVtcGxhdGVzKFJlY2VpcHRPYmopIHtcclxuICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgdGhpcy5SZWNlaXB0SWQgPSBSZWNlaXB0T2JqLlJlY2llcHRUeXBlSWQ7XHJcbiAgICAgICAgICAgIHRoaXMuUmVjZWlwdE5hbWUgPSBSZWNlaXB0T2JqLlJlY2llcHROYW1lRW5nICsgXCIgfCBcIiArIFJlY2VpcHRPYmouUmVjaWVwdE5hbWU7XHJcbiAgICAgICAgICAgIHRoaXMuYmluZFJlY2VpcHRUaG5rc0xldHRlckxpc3QoKTsgXHJcbiAgICAgICAgICAgIHZhciBkaXN0ID0galF1ZXJ5KCcjUlRMRGl2Jykub2Zmc2V0KCkudG9wIC0galF1ZXJ5KCcjUlREaXYnKS5vZmZzZXQoKS50b3A7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICB3aW5kb3cuc2Nyb2xsVG8oMCwgZGlzdCsxMCk7XHJcbiAgICAgICAgICAgIC8vdmFyIHJlc3BvbnNlID0gdGhpcy5iYXNlVXJsICsgXCIvUmVjZWlwdFR5cGUvI1JUTERpdlwiO1xyXG4gICAgICAgICAgICAvL2FsZXJ0KHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgLy9kb2N1bWVudC5sb2NhdGlvbiA9IHJlc3BvbnNlO1xyXG4gICAgICAgICAgICAvLyRsb2NhdGlvbi5oYXNoKCdSVExEaXYnKTtcclxuICAgICAgICAgICAgLy8kYW5jaG9yU2Nyb2xsKCk7XHJcbiAgICAgICAgICAgIC8vdGhpcy5teVNjcm9sbENvbnRhaW5lci5uYXRpdmVFbGVtZW50LnNjcm9sbFRvcCA9IHRoaXMubXlTY3JvbGxDb250YWluZXIubmF0aXZlRWxlbWVudC5zY3JvbGxIZWlnaHQ7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgIH1cclxuICAgIC8vfVxyXG4gICAgZGVsZXRlUmVjZWlwdFRobmtzTGV0dGVyKFJUTE9iaikge1xyXG4gICAgICAgIGlmIChjb25maXJtKFwiRG8geW91IHdhbnQgdG8gZGVsZXRlXCIpKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX1JlY2llcHRTZXJ2aWNlLkRlbGV0ZVJlY2VpcHRUaG5rc0xldHRlcihSVExPYmouVGhhbmtzTGV0dGVySWQpLnN1YnNjcmliZShyZXNwPT4ge1xyXG4gICAgICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgIHZhciByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcCk7XHJcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vdGhpcy5Nc2dDbGFzcyA9IFwidGV4dC1kYW5nZXJcIjtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIC8vdGhpcy5Nc2dDbGFzcyA9IFwidGV4dC1zdWNjZXNzXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgLy90aGlzLl9SZWNpZXB0VHlwZUxpc3QgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBpbmRleCA9IDA7XHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5fUmVjaWVwdFRobmtzTGV0dGVyc0xpc3QsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMgPT0gUlRMT2JqKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpbmRleCA9IGluZGV4ICsgMTtcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9SZWNpZXB0VGhua3NMZXR0ZXJzTGlzdC5zcGxpY2UoaW5kZXgsIDEpO1xyXG4gICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBBZGRSVExTY3JlZW4oKSB7XHJcbiAgICAgICAgLy9pZiAoY29uZmlybShcIkRvIHlvdSB3YW50IHRvIGFkZCBuZXdcIikpIHtcclxuXHJcbiAgICAgICAgICAgIHZhciByZXNwb25zZSA9IHRoaXMuYmFzZVVybCArXCJSZWNlaXB0VGVtcGxhdGUvQWRkLzBcIjtcclxuICAgICAgICAgICAgLy9hbGVydChyZXNwb25zZSk7XHJcbiAgICAgICAgICAgIGRvY3VtZW50LmxvY2F0aW9uID0gcmVzcG9uc2U7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgIC8vfVxyXG4gICAgfVxyXG4gICAgRWRpdFRlbXBsYXRlKFJjcHRUaG5rc0x0ck9iaikge1xyXG4gICAgICAgIHZhciByZXNwb25zZSA9IHRoaXMuYmFzZVVybCArIFwiVGVtcGxhdGUvRWRpdC9cIiArIFJjcHRUaG5rc0x0ck9iai5UaGFua3NMZXR0ZXJJZCtcIi9SZWNcIjtcclxuICAgICAgICAvL2FsZXJ0KHJlc3BvbnNlKTtcclxuICAgICAgICBkb2N1bWVudC5sb2NhdGlvbiA9IHJlc3BvbnNlO1xyXG4gICAgfVxyXG4gICAgRWRpdFJlY2VpcHRUaG5rc0xldHRlcihSY3B0VGhua3NMdHJPYmopIHtcclxuICAgICAgICB2YXIgcmVzcG9uc2UgPSB0aGlzLmJhc2VVcmwgKyBcIlJlY2VpcHRUZW1wbGF0ZS9BZGQvXCIgKyBSY3B0VGhua3NMdHJPYmouVGhhbmtzTGV0dGVySWQ7XHJcbiAgICAgICAgLy9hbGVydChyZXNwb25zZSk7XHJcbiAgICAgICAgZG9jdW1lbnQubG9jYXRpb24gPSByZXNwb25zZTtcclxuICAgIH1cclxuICAgIG5nT25Jbml0KCkge1xyXG4gICAgICAgIHRoaXMuTGFuZyA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwibGFuZ1wiKTtcclxuICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuR2V0TGFuZ1Jlcyh0aGlzLkZvcm10eXBlLCB0aGlzLkxhbmcpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuUkVTID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgdGhpcy5fUmVjaWVwdFNlcnZpY2UuR2V0UmVjaWVwdFR5cGVMaXN0KCkuc3Vic2NyaWJlKHJlc3A9PiB7XHJcbiAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgIHZhciByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcCk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX1JlY2llcHRUeXBlTGlzdCA9IHJlc3BvbnNlLkRhdGE7XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGlmICh0aGlzLlJlY2VpcHRJZCAhPSAwKSB7XHJcbiAgICAgICAgICAgIHRoaXMuYmluZFJlY2VpcHRUaG5rc0xldHRlckxpc3QoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuIl19
