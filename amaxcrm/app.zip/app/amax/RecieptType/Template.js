System.register(["angular2/core", 'angular2/common', "../../services/ResourceService", "angular2/router", "../../services/RecieptService"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, common_1, ResourceService_1, router_1, RecieptService_1;
    var AmaxTemplate;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (ResourceService_1_1) {
                ResourceService_1 = ResourceService_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (RecieptService_1_1) {
                RecieptService_1 = RecieptService_1_1;
            }],
        execute: function() {
            //@NgModule({
            //    imports: [
            //        CKEditorModule
            //    ]
            //    //,declarations: [
            //    //    App,
            //    //],
            //    //bootstrap: [App]
            //})
            AmaxTemplate = (function () {
                function AmaxTemplate(_resourceService, _RecieptService, _routeParams) {
                    this._resourceService = _resourceService;
                    this._RecieptService = _RecieptService;
                    this._routeParams = _routeParams;
                    this.RES = {};
                    this.Formtype = "SCREEN_EDITTEMP";
                    this.Lang = "";
                    this.MsgClass = "text-primary";
                    this.modelInput = {};
                    this.Isbtndisable = "";
                    this.ShowLoader = false;
                    this.ShowMsg = false;
                    this.FPage = "";
                    this.Msg = "";
                    this.OrgId = "";
                    this.ChangeDialog = "";
                    this.CHANGEDIR = "";
                    this.RES.SCREEN_EDITTEMP = {};
                    this.modelInput = {};
                    //alert(_routeParams.params.Id);
                    this.modelInput.ThanksLetterId = _routeParams.params.Id;
                    this.FPage = _routeParams.params.FPage;
                    this.baseUrl = _resourceService.AppUrl;
                    //this.getRceiptThnksLetterDet();
                }
                AmaxTemplate.prototype.CancelBtn = function () {
                    //this.modelInput = {};
                    var _this = this;
                    //jQuery("#editor").val("");
                    //this.modelInput.MailBody = "";
                    var redresponse = this.baseUrl + "ReceiptTemplate/Add/" + this.modelInput.ThanksLetterId;
                    if (this.FPage == "Rec") {
                        if (this.modelInput.ThanksLetterId > 0) {
                            //alert('Hello');
                            this._RecieptService.GetRecieptThnksLetter(this.modelInput.ThanksLetterId).subscribe(function (response) {
                                console.log(response);
                                response = jQuery.parseJSON(response);
                                _this.Isbtndisable = "";
                                _this.ShowLoader = false;
                                if (response.IsError == true) {
                                    bootbox.alert({
                                        message: response.ErrMsg,
                                        className: _this.ChangeDialog,
                                        buttons: {
                                            ok: {
                                                //label: 'Ok',
                                                className: _this.CHANGEDIR
                                            }
                                        }
                                    });
                                }
                                else {
                                    if (response.Data.ReceiptId != undefined && response.Data.ReceiptId != "" && response.Data.ReceiptId != null) {
                                        redresponse = _this.baseUrl + "ReceiptType/" + response.Data.ReceiptId;
                                    }
                                    else {
                                        redresponse = _this.baseUrl + "ReceiptType/0";
                                    }
                                    document.location = redresponse;
                                }
                                _this.ShowMsg = true;
                                _this.Msg = response.ErrMsg;
                            }, function (error) { return console.log(error); }, function () { return console.log("Save Call Compleated"); });
                        }
                    }
                    else {
                        document.location = redresponse;
                    }
                };
                AmaxTemplate.prototype.saveTemplateData = function () {
                    var _this = this;
                    if (this.modelInput.ThanksLetterId > 0) {
                        this.Isbtndisable = "disabled";
                        this.ShowLoader = true;
                        //this.modelInput.ReceiptId = parseInt(this.modelInput.ReceiptId);
                        this.modelInput.MailBody = jQuery("#editor").val();
                        var jdata = JSON.stringify(this.modelInput);
                        console.log(jdata);
                        this._RecieptService.SaveTemplate(this.modelInput.ThanksLetterId, this.modelInput.MailBody).subscribe(function (response) {
                            console.log(response);
                            response = jQuery.parseJSON(response);
                            _this.Isbtndisable = "";
                            _this.ShowLoader = false;
                            if (response.IsError == true) {
                                //alert(response.ErrMsg);
                                _this.MsgClass = "text-danger";
                            }
                            else {
                                //alert(response.ErrMsg);
                                // debugger;
                                var redresponse = _this.baseUrl + "ReceiptTemplate/Add/" + _this.modelInput.ThanksLetterId;
                                if (_this.FPage == "Rec") {
                                    if (_this.modelInput.ThanksLetterId > 0) {
                                        _this._RecieptService.GetRecieptThnksLetter(_this.modelInput.ThanksLetterId).subscribe(function (response) {
                                            console.log(response);
                                            response = jQuery.parseJSON(response);
                                            _this.Isbtndisable = "";
                                            _this.ShowLoader = false;
                                            if (response.IsError == true) {
                                                bootbox.alert({
                                                    message: response.ErrMsg,
                                                    className: _this.ChangeDialog,
                                                    buttons: {
                                                        ok: {
                                                            //label: 'Ok',
                                                            className: _this.CHANGEDIR
                                                        }
                                                    }
                                                });
                                            }
                                            else {
                                                if (response.Data.ReceiptId != undefined && response.Data.ReceiptId != "" && response.Data.ReceiptId != null) {
                                                    redresponse = _this.baseUrl + "ReceiptType/" + response.Data.ReceiptId;
                                                }
                                                else {
                                                    redresponse = _this.baseUrl + "ReceiptType/0";
                                                }
                                                document.location = redresponse;
                                            }
                                            _this.ShowMsg = true;
                                            _this.Msg = response.ErrMsg;
                                        }, function (error) { return console.log(error); }, function () { return console.log("Save Call Compleated"); });
                                    }
                                }
                                else {
                                    document.location = redresponse;
                                }
                                _this.MsgClass = "text-success";
                                //this.modelInput = {};
                                jQuery("#editor").val("");
                                _this.modelInput.MailBody = "";
                            }
                            _this.ShowMsg = true;
                            _this.Msg = response.ErrMsg;
                        }, function (error) { return console.log(error); }, function () { return console.log("Save Call Compleated"); });
                    }
                };
                AmaxTemplate.prototype.ngOnInit = function () {
                    var _this = this;
                    this.Lang = localStorage.getItem("lang");
                    this.OrgId = localStorage.getItem("OrgId");
                    if (this.modelInput.ThanksLetterId > 0) {
                        this._RecieptService.GetTemplate(this.modelInput.ThanksLetterId).subscribe(function (response) {
                            //debugger;
                            response = jQuery.parseJSON(response);
                            if (response.IsError == true) {
                                bootbox.alert({
                                    message: response.ErrMsg,
                                    className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        }
                                    }
                                });
                                jQuery("#editor").val("");
                                jQuery('#editor').ckeditor(function () {
                                });
                            }
                            else {
                                //this.modelInput.ThanksLetterNameEng = response.Data.ThanksLetterNameEng;
                                _this.modelInput.MailBody = response.Data;
                                //if (this.modelInput.MailBody != undefined && this.modelInput.MailBody != null) {
                                jQuery("#editor").val(_this.modelInput.MailBody);
                                jQuery('#editor').ckeditor(function () {
                                });
                            }
                        }, function (error) {
                            console.log(error);
                        }, function () {
                            console.log("CallCompleted");
                        });
                    }
                    else {
                        jQuery("#editor").val("");
                        jQuery('#editor').ckeditor(function () {
                        });
                    }
                    this._resourceService.GetLangRes(this.Formtype, this.Lang).subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.RES = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxTemplate.$inject = ['$scope', '$http', '$templateCache'];
                AmaxTemplate = __decorate([
                    core_1.Component({
                        templateUrl: './app/amax/RecieptType/templates/Template.html',
                        directives: [common_1.NgSwitch, common_1.NgSwitchWhen, common_1.NgSwitchDefault],
                        providers: [RecieptService_1.RecieptService, ResourceService_1.ResourceService]
                    }), 
                    __metadata('design:paramtypes', [ResourceService_1.ResourceService, RecieptService_1.RecieptService, router_1.RouteParams])
                ], AmaxTemplate);
                return AmaxTemplate;
            }());
            exports_1("AmaxTemplate", AmaxTemplate);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFtYXgvUmVjaWVwdFR5cGUvVGVtcGxhdGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7WUFhQSxhQUFhO1lBQ2IsZ0JBQWdCO1lBQ2hCLHdCQUF3QjtZQUN4QixPQUFPO1lBQ1Asd0JBQXdCO1lBQ3hCLGdCQUFnQjtZQUNoQixVQUFVO1lBQ1Ysd0JBQXdCO1lBQ3hCLElBQUk7WUFRSjtnQkFnQkksc0JBQW9CLGdCQUFpQyxFQUFVLGVBQStCLEVBQ2xGLFlBQXlCO29CQURqQixxQkFBZ0IsR0FBaEIsZ0JBQWdCLENBQWlCO29CQUFVLG9CQUFlLEdBQWYsZUFBZSxDQUFnQjtvQkFDbEYsaUJBQVksR0FBWixZQUFZLENBQWE7b0JBaEJyQyxRQUFHLEdBQVcsRUFBRSxDQUFDO29CQUNqQixhQUFRLEdBQVcsaUJBQWlCLENBQUM7b0JBQ3JDLFNBQUksR0FBVyxFQUFFLENBQUM7b0JBQ2xCLGFBQVEsR0FBVyxjQUFjLENBQUM7b0JBQ2xDLGVBQVUsR0FBVyxFQUFFLENBQUM7b0JBQ3hCLGlCQUFZLEdBQVcsRUFBRSxDQUFDO29CQUMxQixlQUFVLEdBQVksS0FBSyxDQUFDO29CQUM1QixZQUFPLEdBQVksS0FBSyxDQUFDO29CQUN6QixVQUFLLEdBQVMsRUFBRSxDQUFDO29CQUNqQixRQUFHLEdBQVcsRUFBRSxDQUFDO29CQUNqQixVQUFLLEdBQVcsRUFBRSxDQUFDO29CQUVuQixpQkFBWSxHQUFXLEVBQUUsQ0FBQztvQkFDMUIsY0FBUyxHQUFXLEVBQUUsQ0FBQztvQkFLbkIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLEdBQUcsRUFBRSxDQUFDO29CQUU5QixJQUFJLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztvQkFFckIsZ0NBQWdDO29CQUNoQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxZQUFZLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztvQkFDeEQsSUFBSSxDQUFDLEtBQUssR0FBRyxZQUFZLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztvQkFDdkMsSUFBSSxDQUFDLE9BQU8sR0FBRyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUM7b0JBQ3ZDLGlDQUFpQztnQkFDckMsQ0FBQztnQkFDRCxnQ0FBUyxHQUFUO29CQUNJLHVCQUF1QjtvQkFEM0IsaUJBbURDO29CQWhERyw0QkFBNEI7b0JBRTVCLGdDQUFnQztvQkFDaEMsSUFBSSxXQUFXLEdBQUcsSUFBSSxDQUFDLE9BQU8sR0FBRyxzQkFBc0IsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQztvQkFDekYsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDO3dCQUN0QixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDOzRCQUVyQyxpQkFBaUI7NEJBQ2pCLElBQUksQ0FBQyxlQUFlLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO2dDQUN6RixPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dDQUN0QixRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQztnQ0FDdEMsS0FBSSxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUM7Z0NBQ3ZCLEtBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO2dDQUV4QixFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7b0NBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7d0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO3dDQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7d0NBQzVCLE9BQU8sRUFBRTs0Q0FDTCxFQUFFLEVBQUU7Z0RBQ0EsY0FBYztnREFDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7NkNBQzVCO3lDQUNKO3FDQUNKLENBQUMsQ0FBQztnQ0FDUCxDQUFDO2dDQUNELElBQUksQ0FBQyxDQUFDO29DQUNGLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsU0FBUyxJQUFJLFNBQVMsSUFBSSxRQUFRLENBQUMsSUFBSSxDQUFDLFNBQVMsSUFBSSxFQUFFLElBQUksUUFBUSxDQUFDLElBQUksQ0FBQyxTQUFTLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzt3Q0FDM0csV0FBVyxHQUFHLEtBQUksQ0FBQyxPQUFPLEdBQUcsY0FBYyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDO29DQUMxRSxDQUFDO29DQUNELElBQUksQ0FBQyxDQUFDO3dDQUNGLFdBQVcsR0FBRyxLQUFJLENBQUMsT0FBTyxHQUFHLGVBQWUsQ0FBQztvQ0FDakQsQ0FBQztvQ0FDRCxRQUFRLENBQUMsUUFBUSxHQUFHLFdBQVcsQ0FBQztnQ0FFcEMsQ0FBQztnQ0FDRCxLQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQztnQ0FDcEIsS0FBSSxDQUFDLEdBQUcsR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDOzRCQUMvQixDQUFDLEVBQ0csVUFBQSxLQUFLLElBQUcsT0FBQSxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxFQUFsQixDQUFrQixFQUMxQixjQUFNLE9BQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQkFBc0IsQ0FBQyxFQUFuQyxDQUFtQyxDQUM1QyxDQUFDO3dCQUVOLENBQUM7b0JBQ0wsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixRQUFRLENBQUMsUUFBUSxHQUFHLFdBQVcsQ0FBQztvQkFDcEMsQ0FBQztnQkFDTCxDQUFDO2dCQUNELHVDQUFnQixHQUFoQjtvQkFBQSxpQkFvRkM7b0JBbkZHLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ3JDLElBQUksQ0FBQyxZQUFZLEdBQUcsVUFBVSxDQUFDO3dCQUMvQixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQzt3QkFDdkIsa0VBQWtFO3dCQUNsRSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUM7d0JBQ25ELElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO3dCQUM1QyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFBO3dCQUNsQixJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7NEJBQzFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUM7NEJBQ3RCLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDOzRCQUN0QyxLQUFJLENBQUMsWUFBWSxHQUFHLEVBQUUsQ0FBQzs0QkFDdkIsS0FBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7NEJBRXhCLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQztnQ0FDM0IseUJBQXlCO2dDQUN6QixLQUFJLENBQUMsUUFBUSxHQUFHLGFBQWEsQ0FBQzs0QkFDbEMsQ0FBQzs0QkFDRCxJQUFJLENBQUMsQ0FBQztnQ0FDRix5QkFBeUI7Z0NBQ3pCLFlBQVk7Z0NBRVosSUFBSSxXQUFXLEdBQUcsS0FBSSxDQUFDLE9BQU8sR0FBRyxzQkFBc0IsR0FBRyxLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQztnQ0FDekYsRUFBRSxDQUFDLENBQUMsS0FBSSxDQUFDLEtBQUssSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDO29DQUN0QixFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dDQUdyQyxLQUFJLENBQUMsZUFBZSxDQUFDLHFCQUFxQixDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTs0Q0FDekYsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQzs0Q0FDdEIsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7NENBQ3RDLEtBQUksQ0FBQyxZQUFZLEdBQUcsRUFBRSxDQUFDOzRDQUN2QixLQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQzs0Q0FFeEIsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO2dEQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO29EQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtvREFDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO29EQUM1QixPQUFPLEVBQUU7d0RBQ0wsRUFBRSxFQUFFOzREQUNBLGNBQWM7NERBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3lEQUM1QjtxREFDSjtpREFDSixDQUFDLENBQUM7NENBQ1AsQ0FBQzs0Q0FDRCxJQUFJLENBQUMsQ0FBQztnREFDRixFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFNBQVMsSUFBSSxTQUFTLElBQUksUUFBUSxDQUFDLElBQUksQ0FBQyxTQUFTLElBQUksRUFBRSxJQUFJLFFBQVEsQ0FBQyxJQUFJLENBQUMsU0FBUyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7b0RBQzNHLFdBQVcsR0FBRyxLQUFJLENBQUMsT0FBTyxHQUFHLGNBQWMsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQztnREFDMUUsQ0FBQztnREFDRCxJQUFJLENBQUMsQ0FBQztvREFDRixXQUFXLEdBQUcsS0FBSSxDQUFDLE9BQU8sR0FBRyxlQUFlLENBQUM7Z0RBQ2pELENBQUM7Z0RBQ0QsUUFBUSxDQUFDLFFBQVEsR0FBRyxXQUFXLENBQUM7NENBQ3BDLENBQUM7NENBQ0QsS0FBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7NENBQ3BCLEtBQUksQ0FBQyxHQUFHLEdBQUcsUUFBUSxDQUFDLE1BQU0sQ0FBQzt3Q0FDL0IsQ0FBQyxFQUNHLFVBQUEsS0FBSyxJQUFHLE9BQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBbEIsQ0FBa0IsRUFDMUIsY0FBTSxPQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsc0JBQXNCLENBQUMsRUFBbkMsQ0FBbUMsQ0FDNUMsQ0FBQztvQ0FFTixDQUFDO2dDQUNMLENBQUM7Z0NBQ0QsSUFBSSxDQUFDLENBQUM7b0NBQ0YsUUFBUSxDQUFDLFFBQVEsR0FBRyxXQUFXLENBQUM7Z0NBQ3BDLENBQUM7Z0NBR0QsS0FBSSxDQUFDLFFBQVEsR0FBRyxjQUFjLENBQUM7Z0NBSS9CLHVCQUF1QjtnQ0FFdkIsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQztnQ0FDMUIsS0FBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDOzRCQUNsQyxDQUFDOzRCQUNELEtBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDOzRCQUNwQixLQUFJLENBQUMsR0FBRyxHQUFHLFFBQVEsQ0FBQyxNQUFNLENBQUM7d0JBQy9CLENBQUMsRUFDRyxVQUFBLEtBQUssSUFBRyxPQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEVBQWxCLENBQWtCLEVBQzFCLGNBQU0sT0FBQSxPQUFPLENBQUMsR0FBRyxDQUFDLHNCQUFzQixDQUFDLEVBQW5DLENBQW1DLENBQzVDLENBQUM7b0JBQ04sQ0FBQztnQkFDTCxDQUFDO2dCQUNELCtCQUFRLEdBQVI7b0JBQUEsaUJBcUZDO29CQW5GRyxJQUFJLENBQUMsSUFBSSxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQ3pDLElBQUksQ0FBQyxLQUFLLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQztvQkFHM0MsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDckMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFROzRCQUMvRSxXQUFXOzRCQUNYLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDOzRCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7Z0NBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7b0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO29DQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7b0NBQzVCLE9BQU8sRUFBRTt3Q0FDTCxFQUFFLEVBQUU7NENBQ0EsY0FBYzs0Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7eUNBQzVCO3FDQUNKO2lDQUNKLENBQUMsQ0FBQztnQ0FDSCxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDO2dDQUMxQixNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsUUFBUSxDQUFDO2dDQUUzQixDQUFDLENBQUMsQ0FBQzs0QkFDUCxDQUFDOzRCQUNELElBQUksQ0FBQyxDQUFDO2dDQUNGLDBFQUEwRTtnQ0FFMUUsS0FBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQztnQ0FDekMsa0ZBQWtGO2dDQUNsRixNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7Z0NBQzVDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxRQUFRLENBQUM7Z0NBRTNCLENBQUMsQ0FBQyxDQUFDOzRCQUdmLENBQUM7d0JBQUEsQ0FBQSxBQUFDLEVBQUMsVUFBQSxLQUFLOzRCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7d0JBQ3ZCLENBQUMsRUFBRTs0QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO3dCQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFDUCxDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUNGLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUM7d0JBRTFCLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxRQUFRLENBQUM7d0JBRTNCLENBQUMsQ0FBQyxDQUFDO29CQUNQLENBQUM7b0JBR0QsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUV6RSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtnQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUM1QixPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsR0FBRyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7d0JBTzdCLENBQUM7b0JBQ0wsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7Z0JBS1AsQ0FBQztnQkE1T00sb0JBQU8sR0FBRyxDQUFDLFFBQVEsRUFBRSxPQUFPLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQztnQkF0QjNEO29CQUFDLGdCQUFTLENBQUM7d0JBRVAsV0FBVyxFQUFFLGdEQUFnRDt3QkFDN0QsVUFBVSxFQUFFLENBQUMsaUJBQVEsRUFBRSxxQkFBWSxFQUFFLHdCQUFlLENBQUM7d0JBQ3JELFNBQVMsRUFBRSxDQUFDLCtCQUFjLEVBQUUsaUNBQWUsQ0FBQztxQkFDL0MsQ0FBQzs7Z0NBQUE7Z0JBOFBGLG1CQUFDO1lBQUQsQ0E1UEEsQUE0UEMsSUFBQTtZQTVQRCx1Q0E0UEMsQ0FBQSIsImZpbGUiOiJhbWF4L1JlY2llcHRUeXBlL1RlbXBsYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiLy9pbXBvcnQge05nTW9kdWxlfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuLy9pbXBvcnQge0Zvcm1zTW9kdWxlfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XHJcbmltcG9ydCB7Q29tcG9uZW50LCBPdXRwdXQsIElucHV0LCBFdmVudEVtaXR0ZXIsIE9uSW5pdH0gZnJvbSBcImFuZ3VsYXIyL2NvcmVcIjtcclxuaW1wb3J0IHtOZ1N3aXRjaCwgTmdTd2l0Y2hXaGVuLCBOZ1N3aXRjaERlZmF1bHR9IGZyb20gJ2FuZ3VsYXIyL2NvbW1vbidcclxuaW1wb3J0IHtSZXNvdXJjZVNlcnZpY2V9IGZyb20gXCIuLi8uLi9zZXJ2aWNlcy9SZXNvdXJjZVNlcnZpY2VcIjtcclxuaW1wb3J0IHtSb3V0ZVBhcmFtc30gZnJvbSBcImFuZ3VsYXIyL3JvdXRlclwiO1xyXG5pbXBvcnQge1JlY2llcHRTZXJ2aWNlfSBmcm9tIFwiLi4vLi4vc2VydmljZXMvUmVjaWVwdFNlcnZpY2VcIjtcclxuaW1wb3J0IHsganNvblEgfSBmcm9tICcuLi8uLi9qc29uUSc7XHJcbmltcG9ydCB7R3JvdXBGaWx0ZXJQaXBlLCBHcm91cFBhcmVuRmlsdGVyUGlwZSwgS2VuZG9fdXRpbGl0eX0gZnJvbSBcIi4uLy4uL2FtYXhVdGlsXCI7XHJcbi8vaW1wb3J0IHtDS0VkaXRvck1vZHVsZX0gZnJvbSAnbmcyLWNrZWRpdG9yJztcclxuXHJcbmRlY2xhcmUgdmFyIGpRdWVyeTtcclxuZGVjbGFyZSB2YXIgQ0tFRElUT1I7XHJcbi8vQE5nTW9kdWxlKHtcclxuLy8gICAgaW1wb3J0czogW1xyXG4vLyAgICAgICAgQ0tFZGl0b3JNb2R1bGVcclxuLy8gICAgXVxyXG4vLyAgICAvLyxkZWNsYXJhdGlvbnM6IFtcclxuLy8gICAgLy8gICAgQXBwLFxyXG4vLyAgICAvL10sXHJcbi8vICAgIC8vYm9vdHN0cmFwOiBbQXBwXVxyXG4vL30pXHJcbkBDb21wb25lbnQoe1xyXG5cclxuICAgIHRlbXBsYXRlVXJsOiAnLi9hcHAvYW1heC9SZWNpZXB0VHlwZS90ZW1wbGF0ZXMvVGVtcGxhdGUuaHRtbCcsXHJcbiAgICBkaXJlY3RpdmVzOiBbTmdTd2l0Y2gsIE5nU3dpdGNoV2hlbiwgTmdTd2l0Y2hEZWZhdWx0XSxcclxuICAgIHByb3ZpZGVyczogW1JlY2llcHRTZXJ2aWNlLCBSZXNvdXJjZVNlcnZpY2VdXHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgQW1heFRlbXBsYXRlIGltcGxlbWVudHMgT25Jbml0IHtcclxuICAgIFJFUzogT2JqZWN0ID0ge307XHJcbiAgICBGb3JtdHlwZTogc3RyaW5nID0gXCJTQ1JFRU5fRURJVFRFTVBcIjtcclxuICAgIExhbmc6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBNc2dDbGFzczogc3RyaW5nID0gXCJ0ZXh0LXByaW1hcnlcIjtcclxuICAgIG1vZGVsSW5wdXQ6IE9iamVjdCA9IHt9O1xyXG4gICAgSXNidG5kaXNhYmxlOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgU2hvd0xvYWRlcjogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgU2hvd01zZzogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgRlBhZ2U6IHN0cmluZz1cIlwiO1xyXG4gICAgTXNnOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgT3JnSWQ6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBiYXNlVXJsOiBzdHJpbmc7XHJcbiAgICBDaGFuZ2VEaWFsb2c6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBDSEFOR0VESVI6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBzdGF0aWMgJGluamVjdCA9IFsnJHNjb3BlJywgJyRodHRwJywgJyR0ZW1wbGF0ZUNhY2hlJ107XHJcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIF9yZXNvdXJjZVNlcnZpY2U6IFJlc291cmNlU2VydmljZSwgcHJpdmF0ZSBfUmVjaWVwdFNlcnZpY2U6IFJlY2llcHRTZXJ2aWNlLFxyXG4gICAgICAgIHByaXZhdGUgX3JvdXRlUGFyYW1zOiBSb3V0ZVBhcmFtcykge1xyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMuUkVTLlNDUkVFTl9FRElUVEVNUCA9IHt9O1xyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dCA9IHt9O1xyXG4gICAgICAgIFxyXG4gICAgICAgIC8vYWxlcnQoX3JvdXRlUGFyYW1zLnBhcmFtcy5JZCk7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LlRoYW5rc0xldHRlcklkID0gX3JvdXRlUGFyYW1zLnBhcmFtcy5JZDtcclxuICAgICAgICB0aGlzLkZQYWdlID0gX3JvdXRlUGFyYW1zLnBhcmFtcy5GUGFnZTtcclxuICAgICAgICB0aGlzLmJhc2VVcmwgPSBfcmVzb3VyY2VTZXJ2aWNlLkFwcFVybDtcclxuICAgICAgICAvL3RoaXMuZ2V0UmNlaXB0VGhua3NMZXR0ZXJEZXQoKTtcclxuICAgIH1cclxuICAgIENhbmNlbEJ0bigpIHtcclxuICAgICAgICAvL3RoaXMubW9kZWxJbnB1dCA9IHt9O1xyXG5cclxuICAgICAgICAvL2pRdWVyeShcIiNlZGl0b3JcIikudmFsKFwiXCIpO1xyXG5cclxuICAgICAgICAvL3RoaXMubW9kZWxJbnB1dC5NYWlsQm9keSA9IFwiXCI7XHJcbiAgICAgICAgdmFyIHJlZHJlc3BvbnNlID0gdGhpcy5iYXNlVXJsICsgXCJSZWNlaXB0VGVtcGxhdGUvQWRkL1wiICsgdGhpcy5tb2RlbElucHV0LlRoYW5rc0xldHRlcklkO1xyXG4gICAgICAgIGlmICh0aGlzLkZQYWdlID09IFwiUmVjXCIpIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5UaGFua3NMZXR0ZXJJZCA+IDApIHtcclxuXHJcbiAgICAgICAgICAgICAgICAvL2FsZXJ0KCdIZWxsbycpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fUmVjaWVwdFNlcnZpY2UuR2V0UmVjaWVwdFRobmtzTGV0dGVyKHRoaXMubW9kZWxJbnB1dC5UaGFua3NMZXR0ZXJJZCkuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuSXNidG5kaXNhYmxlID0gXCJcIjtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLlNob3dMb2FkZXIgPSBmYWxzZTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuRGF0YS5SZWNlaXB0SWQgIT0gdW5kZWZpbmVkICYmIHJlc3BvbnNlLkRhdGEuUmVjZWlwdElkICE9IFwiXCIgJiYgcmVzcG9uc2UuRGF0YS5SZWNlaXB0SWQgIT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVkcmVzcG9uc2UgPSB0aGlzLmJhc2VVcmwgKyBcIlJlY2VpcHRUeXBlL1wiICsgcmVzcG9uc2UuRGF0YS5SZWNlaXB0SWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWRyZXNwb25zZSA9IHRoaXMuYmFzZVVybCArIFwiUmVjZWlwdFR5cGUvMFwiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRvY3VtZW50LmxvY2F0aW9uID0gcmVkcmVzcG9uc2U7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB0aGlzLlNob3dNc2cgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuTXNnID0gcmVzcG9uc2UuRXJyTXNnO1xyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICBlcnJvcj0+IGNvbnNvbGUubG9nKGVycm9yKSxcclxuICAgICAgICAgICAgICAgICAgICAoKSA9PiBjb25zb2xlLmxvZyhcIlNhdmUgQ2FsbCBDb21wbGVhdGVkXCIpXHJcbiAgICAgICAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgZG9jdW1lbnQubG9jYXRpb24gPSByZWRyZXNwb25zZTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBzYXZlVGVtcGxhdGVEYXRhKCkge1xyXG4gICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuVGhhbmtzTGV0dGVySWQgPiAwKSB7XHJcbiAgICAgICAgICAgIHRoaXMuSXNidG5kaXNhYmxlID0gXCJkaXNhYmxlZFwiO1xyXG4gICAgICAgICAgICB0aGlzLlNob3dMb2FkZXIgPSB0cnVlO1xyXG4gICAgICAgICAgICAvL3RoaXMubW9kZWxJbnB1dC5SZWNlaXB0SWQgPSBwYXJzZUludCh0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdElkKTtcclxuICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0Lk1haWxCb2R5ID0galF1ZXJ5KFwiI2VkaXRvclwiKS52YWwoKTtcclxuICAgICAgICAgICAgdmFyIGpkYXRhID0gSlNPTi5zdHJpbmdpZnkodGhpcy5tb2RlbElucHV0KTtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coamRhdGEpXHJcbiAgICAgICAgICAgIHRoaXMuX1JlY2llcHRTZXJ2aWNlLlNhdmVUZW1wbGF0ZSh0aGlzLm1vZGVsSW5wdXQuVGhhbmtzTGV0dGVySWQsIHRoaXMubW9kZWxJbnB1dC5NYWlsQm9keSkuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2cocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuSXNidG5kaXNhYmxlID0gXCJcIjtcclxuICAgICAgICAgICAgICAgIHRoaXMuU2hvd0xvYWRlciA9IGZhbHNlO1xyXG5cclxuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAvL2FsZXJ0KHJlc3BvbnNlLkVyck1zZyk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5Nc2dDbGFzcyA9IFwidGV4dC1kYW5nZXJcIjtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIC8vYWxlcnQocmVzcG9uc2UuRXJyTXNnKTtcclxuICAgICAgICAgICAgICAgICAgICAvLyBkZWJ1Z2dlcjtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIHJlZHJlc3BvbnNlID0gdGhpcy5iYXNlVXJsICsgXCJSZWNlaXB0VGVtcGxhdGUvQWRkL1wiICsgdGhpcy5tb2RlbElucHV0LlRoYW5rc0xldHRlcklkO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLkZQYWdlID09IFwiUmVjXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5UaGFua3NMZXR0ZXJJZCA+IDApIHtcclxuXHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fUmVjaWVwdFNlcnZpY2UuR2V0UmVjaWVwdFRobmtzTGV0dGVyKHRoaXMubW9kZWxJbnB1dC5UaGFua3NMZXR0ZXJJZCkuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuSXNidG5kaXNhYmxlID0gXCJcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLlNob3dMb2FkZXIgPSBmYWxzZTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuRGF0YS5SZWNlaXB0SWQgIT0gdW5kZWZpbmVkICYmIHJlc3BvbnNlLkRhdGEuUmVjZWlwdElkICE9IFwiXCIgJiYgcmVzcG9uc2UuRGF0YS5SZWNlaXB0SWQgIT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVkcmVzcG9uc2UgPSB0aGlzLmJhc2VVcmwgKyBcIlJlY2VpcHRUeXBlL1wiICsgcmVzcG9uc2UuRGF0YS5SZWNlaXB0SWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWRyZXNwb25zZSA9IHRoaXMuYmFzZVVybCArIFwiUmVjZWlwdFR5cGUvMFwiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRvY3VtZW50LmxvY2F0aW9uID0gcmVkcmVzcG9uc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuU2hvd01zZyA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5Nc2cgPSByZXNwb25zZS5FcnJNc2c7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVycm9yPT4gY29uc29sZS5sb2coZXJyb3IpLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICgpID0+IGNvbnNvbGUubG9nKFwiU2F2ZSBDYWxsIENvbXBsZWF0ZWRcIilcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBkb2N1bWVudC5sb2NhdGlvbiA9IHJlZHJlc3BvbnNlO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuXHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuTXNnQ2xhc3MgPSBcInRleHQtc3VjY2Vzc1wiO1xyXG5cclxuXHJcblxyXG4gICAgICAgICAgICAgICAgICAgIC8vdGhpcy5tb2RlbElucHV0ID0ge307XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeShcIiNlZGl0b3JcIikudmFsKFwiXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dC5NYWlsQm9keSA9IFwiXCI7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB0aGlzLlNob3dNc2cgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5Nc2cgPSByZXNwb25zZS5FcnJNc2c7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICBlcnJvcj0+IGNvbnNvbGUubG9nKGVycm9yKSxcclxuICAgICAgICAgICAgICAgICgpID0+IGNvbnNvbGUubG9nKFwiU2F2ZSBDYWxsIENvbXBsZWF0ZWRcIilcclxuICAgICAgICAgICAgKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBuZ09uSW5pdCgpIHtcclxuICAgICAgICBcclxuICAgICAgICB0aGlzLkxhbmcgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImxhbmdcIik7XHJcbiAgICAgICAgdGhpcy5PcmdJZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiT3JnSWRcIik7XHJcblxyXG4gICAgICAgIFxyXG4gICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuVGhhbmtzTGV0dGVySWQgPiAwKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX1JlY2llcHRTZXJ2aWNlLkdldFRlbXBsYXRlKHRoaXMubW9kZWxJbnB1dC5UaGFua3NMZXR0ZXJJZCkuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeShcIiNlZGl0b3JcIikudmFsKFwiXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeSgnI2VkaXRvcicpLmNrZWRpdG9yKGZ1bmN0aW9uICgpIHtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAvL3RoaXMubW9kZWxJbnB1dC5UaGFua3NMZXR0ZXJOYW1lRW5nID0gcmVzcG9uc2UuRGF0YS5UaGFua3NMZXR0ZXJOYW1lRW5nO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm1vZGVsSW5wdXQuTWFpbEJvZHkgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vaWYgKHRoaXMubW9kZWxJbnB1dC5NYWlsQm9keSAhPSB1bmRlZmluZWQgJiYgdGhpcy5tb2RlbElucHV0Lk1haWxCb2R5ICE9IG51bGwpIHtcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkoXCIjZWRpdG9yXCIpLnZhbCh0aGlzLm1vZGVsSW5wdXQuTWFpbEJvZHkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBqUXVlcnkoJyNlZGl0b3InKS5ja2VkaXRvcihmdW5jdGlvbiAoKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgIC8vIH1cclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIGpRdWVyeShcIiNlZGl0b3JcIikudmFsKFwiXCIpO1xyXG5cclxuICAgICAgICAgICAgalF1ZXJ5KCcjZWRpdG9yJykuY2tlZGl0b3IoZnVuY3Rpb24gKCkge1xyXG5cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG5cclxuICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuR2V0TGFuZ1Jlcyh0aGlzLkZvcm10eXBlLCB0aGlzLkxhbmcpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuXHJcbiAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuUkVTID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgIC8vaWYgKHRoaXMubW9kZWxJbnB1dC5UaGFua3NMZXR0ZXJJZCAhPSAwKSB7XHJcbiAgICAgICAgICAgICAgICAvLyAgICB0aGlzLlNBVkVfQlROX1RFWFQgPSB0aGlzLlJFUy5TQ1JFRU5fQUREUkVDSUVQVFRFTVAuQVBQX0JUTl9VUERBVEU7XHJcbiAgICAgICAgICAgICAgICAvL31cclxuICAgICAgICAgICAgICAgIC8vZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAvLyAgICB0aGlzLlNBVkVfQlROX1RFWFQgPSB0aGlzLlJFUy5TQ1JFRU5fQUREUkVDSUVQVFRFTVAuQVBQX0JUTl9TQVZFO1xyXG4gICAgICAgICAgICAgICAgLy99XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvcj0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDYWxsQ29tcGxldGVkXCIpXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgXHJcblxyXG4gICAgICAgIFxyXG4gICAgICAgIFxyXG4gICAgfVxyXG59XHJcbiJdfQ==
