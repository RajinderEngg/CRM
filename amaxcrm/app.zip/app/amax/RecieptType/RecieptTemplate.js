System.register(["angular2/core", 'angular2/common', "../../services/ResourceService", "angular2/router", "../../services/RecieptService"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, common_1, ResourceService_1, router_1, RecieptService_1;
    var AmaxRecieptTemplate;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (ResourceService_1_1) {
                ResourceService_1 = ResourceService_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (RecieptService_1_1) {
                RecieptService_1 = RecieptService_1_1;
            }],
        execute: function() {
            //@NgModule({
            //    imports: [
            //        CKEditorModule
            //    ]
            //    //,declarations: [
            //    //    App,
            //    //],
            //    //bootstrap: [App]
            //})
            AmaxRecieptTemplate = (function () {
                function AmaxRecieptTemplate(_resourceService, _RecieptService, _routeParams) {
                    this._resourceService = _resourceService;
                    this._RecieptService = _RecieptService;
                    this._routeParams = _routeParams;
                    this.RES = {};
                    this.Formtype = "SCREEN_ADDRECIEPTTEMP";
                    this.Lang = "";
                    this._ReceiptTypes = [];
                    this._RecieptThnksLettersList = [];
                    this.ReceiptId = -1;
                    this.ReceiptName = "";
                    this.MsgClass = "text-primary";
                    this.modelInput = {};
                    this.editmodelInput = {};
                    this.Isbtndisable = "";
                    this.ShowLoader = false;
                    this.ShowMsg = false;
                    this.content = "";
                    this.Msg = "";
                    this.baseUrl = "";
                    this.ChangeDialog = "";
                    this.CHANGEDIR = "";
                    this.RES.SCREEN_ADDRECIEPTTEMP = {};
                    this.ReceiptName = "";
                    this.modelInput = {};
                    this.modelInput.ReceiptId = "";
                    this.modelInput.ThanksLetterNameEng = "";
                    this.content = "";
                    //alert(_routeParams.params.Id);
                    this.modelInput.ThanksLetterId = _routeParams.params.Id;
                    this.baseUrl = _resourceService.AppUrl;
                    //this.getRceiptThnksLetterDet();
                }
                AmaxRecieptTemplate.prototype.EditTemplate = function () {
                    var response = this.baseUrl + "Template/Edit/" + this.modelInput.ThanksLetterId + "/RecTemp";
                    document.location = response;
                };
                AmaxRecieptTemplate.prototype.CancelRecTemplate = function () {
                    var response = this.baseUrl + "ReceiptTemplate/Add/0";
                    document.location = response;
                };
                AmaxRecieptTemplate.prototype.CancelBtn = function () {
                    //this.modelInput = {};
                    //jQuery("#editor").val("");
                    //this.modelInput.ReceiptId = ""; 
                    //this.modelInput.ThanksLetterNameEng = "";
                    //this.modelInput.ThanksLetterName = "";
                    //this.modelInput.MailSubj = "";
                    //this.modelInput.MailBody = "";
                    var response = this.baseUrl + "ReceiptType/0";
                    if (this.modelInput.ReceiptId != "" && this.modelInput.ReceiptId != undefined && this.modelInput.ReceiptId != null) {
                        response = this.baseUrl + "ReceiptType/" + this.modelInput.ReceiptId;
                    }
                    document.location = response;
                };
                AmaxRecieptTemplate.prototype.getRceiptThnksLetterDet = function () {
                    var _this = this;
                    if (this.modelInput.ThanksLetterId != 0) {
                        this._RecieptService.GetRecieptThnksLetter(this.modelInput.ThanksLetterId).subscribe(function (response) {
                            //debugger;
                            response = jQuery.parseJSON(response);
                            if (response.IsError == true) {
                                bootbox.alert({
                                    message: response.ErrMsg,
                                    className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                            else {
                                //this.modelInput.ThanksLetterNameEng = response.Data.ThanksLetterNameEng;
                                _this.modelInput = response.Data;
                            }
                        }, function (error) {
                            console.log(error);
                        }, function () {
                            console.log("CallCompleted");
                        });
                    }
                };
                AmaxRecieptTemplate.prototype.saveReceiptTemplateData = function () {
                    var _this = this;
                    //debugger;
                    this.Isbtndisable = "disabled";
                    this.ShowLoader = true;
                    //this.modelInput.ReceiptId = parseInt(this.modelInput.ReceiptId);
                    this.modelInput.MailBody = jQuery("#editor").val();
                    var jdata = JSON.stringify(this.modelInput);
                    console.log(jdata);
                    this._RecieptService.AddReceiptThnksLetter(jdata).subscribe(function (response) {
                        console.log(response);
                        response = jQuery.parseJSON(response);
                        _this.Isbtndisable = "";
                        _this.ShowLoader = false;
                        if (response.IsError == true) {
                            //alert(response.ErrMsg);
                            _this.MsgClass = "text-danger";
                        }
                        else {
                            //alert(response.ErrMsg);
                            // debugger;
                            //this.MsgClass = "text-success";
                            //this.SAVE_BTN_TEXT = this.RES.SCREEN_ADDRECIEPTTEMP.APP_BTN_SAVE;
                            //this.modelInput = {};
                            //jQuery("#editor").val("");
                            //this.modelInput.ReceiptId = ""; 
                            //this.CancelRecTemplate();
                            var response = _this.baseUrl + "ReceiptType/0";
                            if (_this.modelInput.ReceiptId != "" && _this.modelInput.ReceiptId != undefined && _this.modelInput.ReceiptId != null) {
                                response = _this.baseUrl + "ReceiptType/" + _this.modelInput.ReceiptId;
                            }
                            document.location = response;
                        }
                        _this.ShowMsg = true;
                        _this.Msg = response.ErrMsg;
                    }, function (error) { return console.log(error); }, function () { return console.log("Save Call Compleated"); });
                };
                AmaxRecieptTemplate.prototype.ngOnInit = function () {
                    var _this = this;
                    this.Lang = localStorage.getItem("lang");
                    //this.getRceiptThnksLetterDet();
                    //this.editmodelInput.ThanksLetterNameEng = "Hello";
                    //this.modelInput.ThanksLetterNameEng = this.editmodelInput.ThanksLetterNameEng;
                    this._resourceService.GetLangRes(this.Formtype, this.Lang).subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.RES = response.Data;
                            if (_this.modelInput.ThanksLetterId != 0) {
                                _this.SAVE_BTN_TEXT = _this.RES.SCREEN_ADDRECIEPTTEMP.APP_BTN_UPDATE;
                            }
                            else {
                                _this.SAVE_BTN_TEXT = _this.RES.SCREEN_ADDRECIEPTTEMP.APP_BTN_SAVE;
                            }
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    if (this.modelInput.ThanksLetterId != 0) {
                        this._RecieptService.GetRecieptThnksLetter(this.modelInput.ThanksLetterId).subscribe(function (response) {
                            // debugger;
                            response = jQuery.parseJSON(response);
                            if (response.IsError == true) {
                                bootbox.alert({
                                    message: response.ErrMsg,
                                    className: _this.ChangeDialog,
                                    buttons: {
                                        ok: {
                                            //label: 'Ok',
                                            className: _this.CHANGEDIR
                                        }
                                    }
                                });
                            }
                            else {
                                //this.modelInput = {};
                                _this.modelInput = response.Data;
                                jQuery("#editor").val(_this.modelInput.MailBody);
                                jQuery("#EditTemp").show();
                                jQuery('#editor').ckeditor(function () {
                                });
                            }
                        }, function (error) {
                            console.log(error);
                        }, function () {
                            console.log("CallCompleted");
                        });
                    }
                    else {
                        jQuery("#editor").val("");
                        jQuery("#EditTemp").hide();
                        jQuery('#editor').ckeditor(function () {
                        });
                    }
                    //this.modelInput.ThanksLetterNameEng = this.editmodelInput.ThanksLetterNameEng;
                    this._RecieptService.BindRecieptType().subscribe(function (response) {
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this._ReceiptTypes = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxRecieptTemplate.$inject = ['$scope', '$http', '$templateCache'];
                AmaxRecieptTemplate = __decorate([
                    core_1.Component({
                        templateUrl: './app/amax/RecieptType/templates/RecieptTemplate.html',
                        directives: [common_1.NgSwitch, common_1.NgSwitchWhen, common_1.NgSwitchDefault],
                        providers: [RecieptService_1.RecieptService, ResourceService_1.ResourceService]
                    }), 
                    __metadata('design:paramtypes', [ResourceService_1.ResourceService, RecieptService_1.RecieptService, router_1.RouteParams])
                ], AmaxRecieptTemplate);
                return AmaxRecieptTemplate;
            }());
            exports_1("AmaxRecieptTemplate", AmaxRecieptTemplate);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFtYXgvUmVjaWVwdFR5cGUvUmVjaWVwdFRlbXBsYXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1lBWUEsYUFBYTtZQUNiLGdCQUFnQjtZQUNoQix3QkFBd0I7WUFDeEIsT0FBTztZQUNQLHdCQUF3QjtZQUN4QixnQkFBZ0I7WUFDaEIsVUFBVTtZQUNWLHdCQUF3QjtZQUN4QixJQUFJO1lBUUo7Z0JBcUJJLDZCQUFvQixnQkFBaUMsRUFBVSxlQUErQixFQUNsRixZQUF5QjtvQkFEakIscUJBQWdCLEdBQWhCLGdCQUFnQixDQUFpQjtvQkFBVSxvQkFBZSxHQUFmLGVBQWUsQ0FBZ0I7b0JBQ2xGLGlCQUFZLEdBQVosWUFBWSxDQUFhO29CQXJCckMsUUFBRyxHQUFXLEVBQUUsQ0FBQztvQkFDakIsYUFBUSxHQUFXLHVCQUF1QixDQUFDO29CQUMzQyxTQUFJLEdBQVcsRUFBRSxDQUFDO29CQUNsQixrQkFBYSxHQUFHLEVBQUUsQ0FBQztvQkFDbkIsNkJBQXdCLEdBQUcsRUFBRSxDQUFDO29CQUM5QixjQUFTLEdBQVcsQ0FBQyxDQUFDLENBQUM7b0JBQ3ZCLGdCQUFXLEdBQVcsRUFBRSxDQUFDO29CQUN6QixhQUFRLEdBQVcsY0FBYyxDQUFDO29CQUNsQyxlQUFVLEdBQVcsRUFBRSxDQUFDO29CQUN4QixtQkFBYyxHQUFXLEVBQUUsQ0FBQztvQkFFNUIsaUJBQVksR0FBVyxFQUFFLENBQUM7b0JBQzFCLGVBQVUsR0FBWSxLQUFLLENBQUM7b0JBQzVCLFlBQU8sR0FBWSxLQUFLLENBQUM7b0JBQ3pCLFlBQU8sR0FBVyxFQUFFLENBQUM7b0JBQ3JCLFFBQUcsR0FBVyxFQUFFLENBQUM7b0JBQ2pCLFlBQU8sR0FBVyxFQUFFLENBQUM7b0JBQ3JCLGlCQUFZLEdBQVcsRUFBRSxDQUFDO29CQUMxQixjQUFTLEdBQVcsRUFBRSxDQUFDO29CQUtuQixJQUFJLENBQUMsR0FBRyxDQUFDLHFCQUFxQixHQUFHLEVBQUUsQ0FBQztvQkFDcEMsSUFBSSxDQUFDLFdBQVcsR0FBRyxFQUFFLENBQUM7b0JBQ3RCLElBQUksQ0FBQyxVQUFVLEdBQUcsRUFBRSxDQUFDO29CQUNyQixJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsR0FBRyxFQUFFLENBQUM7b0JBQy9CLElBQUksQ0FBQyxVQUFVLENBQUMsbUJBQW1CLEdBQUcsRUFBRSxDQUFDO29CQUN6QyxJQUFJLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztvQkFDbEIsZ0NBQWdDO29CQUNoQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxZQUFZLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztvQkFDeEQsSUFBSSxDQUFDLE9BQU8sR0FBRyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUM7b0JBQ3ZDLGlDQUFpQztnQkFDckMsQ0FBQztnQkFDRCwwQ0FBWSxHQUFaO29CQUVJLElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxPQUFPLEdBQUcsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUMsVUFBVSxDQUFDO29CQUUzRixRQUFRLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQztnQkFDakMsQ0FBQztnQkFDRCwrQ0FBaUIsR0FBakI7b0JBQ0ksSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLE9BQU8sR0FBRyx1QkFBdUIsQ0FBQztvQkFFdEQsUUFBUSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUM7Z0JBQ2pDLENBQUM7Z0JBQ0QsdUNBQVMsR0FBVDtvQkFDSSx1QkFBdUI7b0JBRXZCLDRCQUE0QjtvQkFFNUIsa0NBQWtDO29CQUNsQywyQ0FBMkM7b0JBQzNDLHdDQUF3QztvQkFDeEMsZ0NBQWdDO29CQUNoQyxnQ0FBZ0M7b0JBQ2hDLElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxPQUFPLEdBQUcsZUFBZSxDQUFDO29CQUM5QyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7d0JBQ2pILFFBQVEsR0FBRyxJQUFJLENBQUMsT0FBTyxHQUFHLGNBQWMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQztvQkFDekUsQ0FBQztvQkFDRCxRQUFRLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQztnQkFDakMsQ0FBQztnQkFDRCxxREFBdUIsR0FBdkI7b0JBQUEsaUJBNEJDO29CQTNCRyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUN0QyxJQUFJLENBQUMsZUFBZSxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTs0QkFDekYsV0FBVzs0QkFDWCxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzs0QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO2dDQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO29DQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtvQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO29DQUM1QixPQUFPLEVBQUU7d0NBQ0wsRUFBRSxFQUFFOzRDQUNBLGNBQWM7NENBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3lDQUM1QjtxQ0FDSjtpQ0FDSixDQUFDLENBQUM7NEJBQ1AsQ0FBQzs0QkFDRCxJQUFJLENBQUMsQ0FBQztnQ0FDRiwwRUFBMEU7Z0NBRTFFLEtBQUksQ0FBQyxVQUFVLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzs0QkFDcEMsQ0FBQzt3QkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLOzRCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7d0JBQ3ZCLENBQUMsRUFBRTs0QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO3dCQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFDUCxDQUFDO2dCQUNMLENBQUM7Z0JBQ0QscURBQXVCLEdBQXZCO29CQUFBLGlCQWdEQztvQkEvQ0csV0FBVztvQkFDWCxJQUFJLENBQUMsWUFBWSxHQUFHLFVBQVUsQ0FBQztvQkFDL0IsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7b0JBQ3ZCLGtFQUFrRTtvQkFDbEUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDO29CQUNuRCxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztvQkFDNUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQTtvQkFDbEIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxxQkFBcUIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUNoRSxPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUN0QixRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDdEMsS0FBSSxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUM7d0JBQ3ZCLEtBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO3dCQUV4QixFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLHlCQUF5Qjs0QkFDekIsS0FBSSxDQUFDLFFBQVEsR0FBRyxhQUFhLENBQUM7d0JBQ2xDLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YseUJBQXlCOzRCQUMxQixZQUFZOzRCQUNYLGlDQUFpQzs0QkFFakMsbUVBQW1FOzRCQUduRSx1QkFBdUI7NEJBRXZCLDRCQUE0Qjs0QkFFNUIsa0NBQWtDOzRCQUlsQywyQkFBMkI7NEJBQzNCLElBQUksUUFBUSxHQUFHLEtBQUksQ0FBQyxPQUFPLEdBQUcsZUFBZSxDQUFDOzRCQUM5QyxFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsSUFBSSxFQUFFLElBQUksS0FBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLElBQUksU0FBUyxJQUFJLEtBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7Z0NBQ2pILFFBQVEsR0FBRyxLQUFJLENBQUMsT0FBTyxHQUFHLGNBQWMsR0FBRyxLQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQzs0QkFDekUsQ0FBQzs0QkFDRCxRQUFRLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQzt3QkFDakMsQ0FBQzt3QkFDRCxLQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQzt3QkFDcEIsS0FBSSxDQUFDLEdBQUcsR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDO29CQUMvQixDQUFDLEVBQ0csVUFBQSxLQUFLLElBQUcsT0FBQSxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxFQUFsQixDQUFrQixFQUMxQixjQUFNLE9BQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQkFBc0IsQ0FBQyxFQUFuQyxDQUFtQyxDQUM1QyxDQUFDO2dCQUVOLENBQUM7Z0JBQ0Qsc0NBQVEsR0FBUjtvQkFBQSxpQkFzR0M7b0JBcEdHLElBQUksQ0FBQyxJQUFJLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDekMsaUNBQWlDO29CQUNqQyxvREFBb0Q7b0JBQ3BELGdGQUFnRjtvQkFDaEYsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUV6RSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtnQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUM1QixPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsR0FBRyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7NEJBQ3pCLEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQ3RDLEtBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSSxDQUFDLEdBQUcsQ0FBQyxxQkFBcUIsQ0FBQyxjQUFjLENBQUM7NEJBQ3ZFLENBQUM7NEJBQ0QsSUFBSSxDQUFDLENBQUM7Z0NBQ0YsS0FBSSxDQUFDLGFBQWEsR0FBRyxLQUFJLENBQUMsR0FBRyxDQUFDLHFCQUFxQixDQUFDLFlBQVksQ0FBQzs0QkFDckUsQ0FBQzt3QkFDTCxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQUNILEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ3RDLElBQUksQ0FBQyxlQUFlLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFROzRCQUMxRixZQUFZOzRCQUNYLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDOzRCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7Z0NBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7b0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO29DQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7b0NBQzVCLE9BQU8sRUFBRTt3Q0FDTCxFQUFFLEVBQUU7NENBQ0EsY0FBYzs0Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7eUNBQzVCO3FDQUNKO2lDQUNKLENBQUMsQ0FBQzs0QkFDUCxDQUFDOzRCQUNELElBQUksQ0FBQyxDQUFDO2dDQUNGLHVCQUF1QjtnQ0FDdkIsS0FBSSxDQUFDLFVBQVUsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO2dDQUNoQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7Z0NBQ2hELE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQ0FDM0IsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztnQ0FFM0IsQ0FBQyxDQUFDLENBQUM7NEJBR1AsQ0FBQzt3QkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLOzRCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7d0JBQ3ZCLENBQUMsRUFBRTs0QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO3dCQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFDUCxDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUNGLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUM7d0JBQzFCLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQzt3QkFDM0IsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFFBQVEsQ0FBQzt3QkFFM0IsQ0FBQyxDQUFDLENBQUM7b0JBQ1AsQ0FBQztvQkFDRCxnRkFBZ0Y7b0JBQ2hGLElBQUksQ0FBQyxlQUFlLENBQUMsZUFBZSxFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTt3QkFFckQsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLGFBQWEsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO3dCQUN2QyxDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO2dCQUlQLENBQUM7Z0JBOU5NLDJCQUFPLEdBQUcsQ0FBQyxRQUFRLEVBQUUsT0FBTyxFQUFFLGdCQUFnQixDQUFDLENBQUM7Z0JBM0IzRDtvQkFBQyxnQkFBUyxDQUFDO3dCQUVQLFdBQVcsRUFBRSx1REFBdUQ7d0JBQ3BFLFVBQVUsRUFBRSxDQUFDLGlCQUFRLEVBQUUscUJBQVksRUFBRSx3QkFBZSxDQUFDO3dCQUNyRCxTQUFTLEVBQUUsQ0FBQywrQkFBYyxFQUFFLGlDQUFlLENBQUM7cUJBQy9DLENBQUM7O3VDQUFBO2dCQXFQRiwwQkFBQztZQUFELENBblBBLEFBbVBDLElBQUE7WUFuUEQscURBbVBDLENBQUEiLCJmaWxlIjoiYW1heC9SZWNpZXB0VHlwZS9SZWNpZXB0VGVtcGxhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyIvL2ltcG9ydCB7TmdNb2R1bGV9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG4vL2ltcG9ydCB7Rm9ybXNNb2R1bGV9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcclxuaW1wb3J0IHtDb21wb25lbnQsIE91dHB1dCwgSW5wdXQsIEV2ZW50RW1pdHRlciwgT25Jbml0fSBmcm9tIFwiYW5ndWxhcjIvY29yZVwiO1xyXG5pbXBvcnQge05nU3dpdGNoLCBOZ1N3aXRjaFdoZW4sIE5nU3dpdGNoRGVmYXVsdH0gZnJvbSAnYW5ndWxhcjIvY29tbW9uJ1xyXG5pbXBvcnQge1Jlc291cmNlU2VydmljZX0gZnJvbSBcIi4uLy4uL3NlcnZpY2VzL1Jlc291cmNlU2VydmljZVwiO1xyXG5pbXBvcnQge1JvdXRlUGFyYW1zfSBmcm9tIFwiYW5ndWxhcjIvcm91dGVyXCI7XHJcbmltcG9ydCB7UmVjaWVwdFNlcnZpY2V9IGZyb20gXCIuLi8uLi9zZXJ2aWNlcy9SZWNpZXB0U2VydmljZVwiO1xyXG5pbXBvcnQgeyBqc29uUSB9IGZyb20gJy4uLy4uL2pzb25RJztcclxuaW1wb3J0IHtHcm91cEZpbHRlclBpcGUsIEdyb3VwUGFyZW5GaWx0ZXJQaXBlLCBLZW5kb191dGlsaXR5fSBmcm9tIFwiLi4vLi4vYW1heFV0aWxcIjtcclxuLy9pbXBvcnQge0NLRWRpdG9yTW9kdWxlfSBmcm9tICduZzItY2tlZGl0b3InO1xyXG5cclxuZGVjbGFyZSB2YXIgalF1ZXJ5O1xyXG4vL0BOZ01vZHVsZSh7XHJcbi8vICAgIGltcG9ydHM6IFtcclxuLy8gICAgICAgIENLRWRpdG9yTW9kdWxlXHJcbi8vICAgIF1cclxuLy8gICAgLy8sZGVjbGFyYXRpb25zOiBbXHJcbi8vICAgIC8vICAgIEFwcCxcclxuLy8gICAgLy9dLFxyXG4vLyAgICAvL2Jvb3RzdHJhcDogW0FwcF1cclxuLy99KVxyXG5AQ29tcG9uZW50KHtcclxuXHJcbiAgICB0ZW1wbGF0ZVVybDogJy4vYXBwL2FtYXgvUmVjaWVwdFR5cGUvdGVtcGxhdGVzL1JlY2llcHRUZW1wbGF0ZS5odG1sJyxcclxuICAgIGRpcmVjdGl2ZXM6IFtOZ1N3aXRjaCwgTmdTd2l0Y2hXaGVuLCBOZ1N3aXRjaERlZmF1bHRdLFxyXG4gICAgcHJvdmlkZXJzOiBbUmVjaWVwdFNlcnZpY2UsIFJlc291cmNlU2VydmljZV1cclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBBbWF4UmVjaWVwdFRlbXBsYXRlIGltcGxlbWVudHMgT25Jbml0IHtcclxuICAgIFJFUzogT2JqZWN0ID0ge307XHJcbiAgICBGb3JtdHlwZTogc3RyaW5nID0gXCJTQ1JFRU5fQUREUkVDSUVQVFRFTVBcIjtcclxuICAgIExhbmc6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBfUmVjZWlwdFR5cGVzID0gW107XHJcbiAgICBfUmVjaWVwdFRobmtzTGV0dGVyc0xpc3QgPSBbXTtcclxuICAgIFJlY2VpcHRJZDogbnVtYmVyID0gLTE7XHJcbiAgICBSZWNlaXB0TmFtZTogc3RyaW5nID0gXCJcIjtcclxuICAgIE1zZ0NsYXNzOiBzdHJpbmcgPSBcInRleHQtcHJpbWFyeVwiO1xyXG4gICAgbW9kZWxJbnB1dDogT2JqZWN0ID0ge307XHJcbiAgICBlZGl0bW9kZWxJbnB1dDogT2JqZWN0ID0ge307XHJcbiAgICBTQVZFX0JUTl9URVhUOiBzdHJpbmc7XHJcbiAgICBJc2J0bmRpc2FibGU6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBTaG93TG9hZGVyOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBTaG93TXNnOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBjb250ZW50OiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgTXNnOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgYmFzZVVybDogc3RyaW5nID0gXCJcIjtcclxuICAgIENoYW5nZURpYWxvZzogc3RyaW5nID0gXCJcIjtcclxuICAgIENIQU5HRURJUjogc3RyaW5nID0gXCJcIjtcclxuICAgIHN0YXRpYyAkaW5qZWN0ID0gWyckc2NvcGUnLCAnJGh0dHAnLCAnJHRlbXBsYXRlQ2FjaGUnXTtcclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgX3Jlc291cmNlU2VydmljZTogUmVzb3VyY2VTZXJ2aWNlLCBwcml2YXRlIF9SZWNpZXB0U2VydmljZTogUmVjaWVwdFNlcnZpY2UsXHJcbiAgICAgICAgcHJpdmF0ZSBfcm91dGVQYXJhbXM6IFJvdXRlUGFyYW1zKSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5SRVMuU0NSRUVOX0FERFJFQ0lFUFRURU1QID0ge307XHJcbiAgICAgICAgdGhpcy5SZWNlaXB0TmFtZSA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0ID0ge307XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LlJlY2VpcHRJZCA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LlRoYW5rc0xldHRlck5hbWVFbmcgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMuY29udGVudCA9IFwiXCI7XHJcbiAgICAgICAgLy9hbGVydChfcm91dGVQYXJhbXMucGFyYW1zLklkKTtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuVGhhbmtzTGV0dGVySWQgPSBfcm91dGVQYXJhbXMucGFyYW1zLklkO1xyXG4gICAgICAgIHRoaXMuYmFzZVVybCA9IF9yZXNvdXJjZVNlcnZpY2UuQXBwVXJsO1xyXG4gICAgICAgIC8vdGhpcy5nZXRSY2VpcHRUaG5rc0xldHRlckRldCgpO1xyXG4gICAgfVxyXG4gICAgRWRpdFRlbXBsYXRlKCkge1xyXG4gICAgICBcclxuICAgICAgICB2YXIgcmVzcG9uc2UgPSB0aGlzLmJhc2VVcmwgKyBcIlRlbXBsYXRlL0VkaXQvXCIgKyB0aGlzLm1vZGVsSW5wdXQuVGhhbmtzTGV0dGVySWQrXCIvUmVjVGVtcFwiO1xyXG4gICAgICAgIFxyXG4gICAgICAgIGRvY3VtZW50LmxvY2F0aW9uID0gcmVzcG9uc2U7XHJcbiAgICB9XHJcbiAgICBDYW5jZWxSZWNUZW1wbGF0ZSgpIHtcclxuICAgICAgICB2YXIgcmVzcG9uc2UgPSB0aGlzLmJhc2VVcmwgKyBcIlJlY2VpcHRUZW1wbGF0ZS9BZGQvMFwiO1xyXG4gICAgICAgIFxyXG4gICAgICAgIGRvY3VtZW50LmxvY2F0aW9uID0gcmVzcG9uc2U7XHJcbiAgICB9XHJcbiAgICBDYW5jZWxCdG4oKSB7XHJcbiAgICAgICAgLy90aGlzLm1vZGVsSW5wdXQgPSB7fTtcclxuXHJcbiAgICAgICAgLy9qUXVlcnkoXCIjZWRpdG9yXCIpLnZhbChcIlwiKTtcclxuXHJcbiAgICAgICAgLy90aGlzLm1vZGVsSW5wdXQuUmVjZWlwdElkID0gXCJcIjsgXHJcbiAgICAgICAgLy90aGlzLm1vZGVsSW5wdXQuVGhhbmtzTGV0dGVyTmFtZUVuZyA9IFwiXCI7XHJcbiAgICAgICAgLy90aGlzLm1vZGVsSW5wdXQuVGhhbmtzTGV0dGVyTmFtZSA9IFwiXCI7XHJcbiAgICAgICAgLy90aGlzLm1vZGVsSW5wdXQuTWFpbFN1YmogPSBcIlwiO1xyXG4gICAgICAgIC8vdGhpcy5tb2RlbElucHV0Lk1haWxCb2R5ID0gXCJcIjtcclxuICAgICAgICB2YXIgcmVzcG9uc2UgPSB0aGlzLmJhc2VVcmwgKyBcIlJlY2VpcHRUeXBlLzBcIjtcclxuICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LlJlY2VpcHRJZCAhPSBcIlwiICYmIHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0SWQgIT0gdW5kZWZpbmVkICYmIHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0SWQgIT0gbnVsbCkge1xyXG4gICAgICAgICAgICByZXNwb25zZSA9IHRoaXMuYmFzZVVybCArIFwiUmVjZWlwdFR5cGUvXCIgKyB0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdElkO1xyXG4gICAgICAgIH1cclxuICAgICAgICBkb2N1bWVudC5sb2NhdGlvbiA9IHJlc3BvbnNlO1xyXG4gICAgfVxyXG4gICAgZ2V0UmNlaXB0VGhua3NMZXR0ZXJEZXQoKSB7XHJcbiAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5UaGFua3NMZXR0ZXJJZCAhPSAwKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX1JlY2llcHRTZXJ2aWNlLkdldFJlY2llcHRUaG5rc0xldHRlcih0aGlzLm1vZGVsSW5wdXQuVGhhbmtzTGV0dGVySWQpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAgICAgIC8vZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIC8vdGhpcy5tb2RlbElucHV0LlRoYW5rc0xldHRlck5hbWVFbmcgPSByZXNwb25zZS5EYXRhLlRoYW5rc0xldHRlck5hbWVFbmc7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dCA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgc2F2ZVJlY2VpcHRUZW1wbGF0ZURhdGEoKSB7XHJcbiAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICB0aGlzLklzYnRuZGlzYWJsZSA9IFwiZGlzYWJsZWRcIjtcclxuICAgICAgICB0aGlzLlNob3dMb2FkZXIgPSB0cnVlO1xyXG4gICAgICAgIC8vdGhpcy5tb2RlbElucHV0LlJlY2VpcHRJZCA9IHBhcnNlSW50KHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0SWQpO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5NYWlsQm9keSA9IGpRdWVyeShcIiNlZGl0b3JcIikudmFsKCk7XHJcbiAgICAgICAgdmFyIGpkYXRhID0gSlNPTi5zdHJpbmdpZnkodGhpcy5tb2RlbElucHV0KTtcclxuICAgICAgICBjb25zb2xlLmxvZyhqZGF0YSlcclxuICAgICAgICB0aGlzLl9SZWNpZXB0U2VydmljZS5BZGRSZWNlaXB0VGhua3NMZXR0ZXIoamRhdGEpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2cocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICB0aGlzLklzYnRuZGlzYWJsZSA9IFwiXCI7XHJcbiAgICAgICAgICAgIHRoaXMuU2hvd0xvYWRlciA9IGZhbHNlO1xyXG5cclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgLy9hbGVydChyZXNwb25zZS5FcnJNc2cpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5Nc2dDbGFzcyA9IFwidGV4dC1kYW5nZXJcIjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIC8vYWxlcnQocmVzcG9uc2UuRXJyTXNnKTtcclxuICAgICAgICAgICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgICAvL3RoaXMuTXNnQ2xhc3MgPSBcInRleHQtc3VjY2Vzc1wiO1xyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAvL3RoaXMuU0FWRV9CVE5fVEVYVCA9IHRoaXMuUkVTLlNDUkVFTl9BRERSRUNJRVBUVEVNUC5BUFBfQlROX1NBVkU7XHJcblxyXG5cclxuICAgICAgICAgICAgICAgIC8vdGhpcy5tb2RlbElucHV0ID0ge307XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIC8valF1ZXJ5KFwiI2VkaXRvclwiKS52YWwoXCJcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAvL3RoaXMubW9kZWxJbnB1dC5SZWNlaXB0SWQgPSBcIlwiOyBcclxuXHJcblxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAvL3RoaXMuQ2FuY2VsUmVjVGVtcGxhdGUoKTtcclxuICAgICAgICAgICAgICAgIHZhciByZXNwb25zZSA9IHRoaXMuYmFzZVVybCArIFwiUmVjZWlwdFR5cGUvMFwiO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMubW9kZWxJbnB1dC5SZWNlaXB0SWQgIT0gXCJcIiAmJiB0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdElkICE9IHVuZGVmaW5lZCAmJiB0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdElkICE9IG51bGwpIHtcclxuICAgICAgICAgICAgICAgICAgICByZXNwb25zZSA9IHRoaXMuYmFzZVVybCArIFwiUmVjZWlwdFR5cGUvXCIgKyB0aGlzLm1vZGVsSW5wdXQuUmVjZWlwdElkO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZG9jdW1lbnQubG9jYXRpb24gPSByZXNwb25zZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0aGlzLlNob3dNc2cgPSB0cnVlO1xyXG4gICAgICAgICAgICB0aGlzLk1zZyA9IHJlc3BvbnNlLkVyck1zZztcclxuICAgICAgICB9LFxyXG4gICAgICAgICAgICBlcnJvcj0+IGNvbnNvbGUubG9nKGVycm9yKSxcclxuICAgICAgICAgICAgKCkgPT4gY29uc29sZS5sb2coXCJTYXZlIENhbGwgQ29tcGxlYXRlZFwiKVxyXG4gICAgICAgICk7XHJcblxyXG4gICAgfVxyXG4gICAgbmdPbkluaXQoKSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5MYW5nID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJsYW5nXCIpO1xyXG4gICAgICAgIC8vdGhpcy5nZXRSY2VpcHRUaG5rc0xldHRlckRldCgpO1xyXG4gICAgICAgIC8vdGhpcy5lZGl0bW9kZWxJbnB1dC5UaGFua3NMZXR0ZXJOYW1lRW5nID0gXCJIZWxsb1wiO1xyXG4gICAgICAgIC8vdGhpcy5tb2RlbElucHV0LlRoYW5rc0xldHRlck5hbWVFbmcgPSB0aGlzLmVkaXRtb2RlbElucHV0LlRoYW5rc0xldHRlck5hbWVFbmc7XHJcbiAgICAgICAgdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLkdldExhbmdSZXModGhpcy5Gb3JtdHlwZSwgdGhpcy5MYW5nKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcblxyXG4gICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuSXNFcnJvciA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNoYW5nZURpYWxvZyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2xhYmVsOiAnT2snLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLlJFUyA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5tb2RlbElucHV0LlRoYW5rc0xldHRlcklkICE9IDApIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLlNBVkVfQlROX1RFWFQgPSB0aGlzLlJFUy5TQ1JFRU5fQUREUkVDSUVQVFRFTVAuQVBQX0JUTl9VUERBVEU7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLlNBVkVfQlROX1RFWFQgPSB0aGlzLlJFUy5TQ1JFRU5fQUREUkVDSUVQVFRFTVAuQVBQX0JUTl9TQVZFO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGlmICh0aGlzLm1vZGVsSW5wdXQuVGhhbmtzTGV0dGVySWQgIT0gMCkge1xyXG4gICAgICAgICAgICB0aGlzLl9SZWNpZXB0U2VydmljZS5HZXRSZWNpZXB0VGhua3NMZXR0ZXIodGhpcy5tb2RlbElucHV0LlRoYW5rc0xldHRlcklkKS5zdWJzY3JpYmUocmVzcG9uc2U9PiB7XHJcbiAgICAgICAgICAgICAgIC8vIGRlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAvL3RoaXMubW9kZWxJbnB1dCA9IHt9O1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dCA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICAgICAgalF1ZXJ5KFwiI2VkaXRvclwiKS52YWwodGhpcy5tb2RlbElucHV0Lk1haWxCb2R5KTtcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkoXCIjRWRpdFRlbXBcIikuc2hvdygpO1xyXG4gICAgICAgICAgICAgICAgICAgIGpRdWVyeSgnI2VkaXRvcicpLmNrZWRpdG9yKGZ1bmN0aW9uICgpIHtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gdGhpcy5lZGl0bW9kZWxJbnB1dC5UaGFua3NMZXR0ZXJJZCA9IHJlc3BvbnNlLkRhdGEuVGhhbmtzTGV0dGVySWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gYWxlcnQodGhpcy5lZGl0bW9kZWxJbnB1dC5UaGFua3NMZXR0ZXJJZCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBqUXVlcnkoXCIjZWRpdG9yXCIpLnZhbChcIlwiKTtcclxuICAgICAgICAgICAgalF1ZXJ5KFwiI0VkaXRUZW1wXCIpLmhpZGUoKTtcclxuICAgICAgICAgICAgalF1ZXJ5KCcjZWRpdG9yJykuY2tlZGl0b3IoZnVuY3Rpb24gKCkge1xyXG5cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vdGhpcy5tb2RlbElucHV0LlRoYW5rc0xldHRlck5hbWVFbmcgPSB0aGlzLmVkaXRtb2RlbElucHV0LlRoYW5rc0xldHRlck5hbWVFbmc7XHJcbiAgICAgICAgdGhpcy5fUmVjaWVwdFNlcnZpY2UuQmluZFJlY2llcHRUeXBlKCkuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fUmVjZWlwdFR5cGVzID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgXHJcbiAgICAgICAgXHJcbiAgICB9XHJcbn1cclxuIl19
