System.register(["angular2/core", "../../services/AmaxService", "angular2/router"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, AmaxService_1, router_1;
    var AmaxReport;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (AmaxService_1_1) {
                AmaxService_1 = AmaxService_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            }],
        execute: function() {
            AmaxReport = (function () {
                function AmaxReport(_amaxService, _routeParams) {
                    this._amaxService = _amaxService;
                    this._routeParams = _routeParams;
                }
                AmaxReport.prototype.redirectTo = function (location) {
                    alert(location);
                };
                AmaxReport.prototype.ngOnInit = function () {
                    var rpt = this._routeParams.get('rpt');
                    if (rpt) {
                        switch (rpt) {
                            case "Accounts":
                                this.ReportName = "Accounts";
                                this.ReportData = this._amaxService.GetReport(rpt, {});
                                this.ReportData.subscribe(function (data) {
                                    jQuery("#formReport").kendoGrid({
                                        dataSource: {
                                            data: data[0]
                                        },
                                        height: 350,
                                        columns: [
                                            {
                                                template: "<div (click)='redirectTo(\"form?frm=Accounts\")'>#: AccountName #</div></a>",
                                                field: "AccountName",
                                                title: "Account Name"
                                            },
                                            {
                                                template: "<div>#: AccountTypeName # ( #: AccountTpeNameEng # )</div>",
                                                field: "AccountTypeName",
                                                title: "Account Type"
                                            },
                                            {
                                                template: "<div>#: AccountDetail #</div>",
                                                field: "AccountDetail",
                                                title: "Account Detail"
                                            }
                                        ]
                                    });
                                });
                                break;
                            case "AccountType":
                                this.ReportName = "Accounts Types";
                                this.ReportData = this._amaxService.GetReport(rpt, {});
                                this.ReportData.subscribe(function (data) {
                                    console.log("1. Hello World");
                                    console.log("2. Hello World");
                                    console.log("3. Hello World");
                                    console.log(data);
                                    jQuery("#formReport").kendoGrid({
                                        dataSource: {
                                            data: data[0]
                                        },
                                        height: 350,
                                        selectable: "multiple",
                                        columns: [
                                            {
                                                template: "<div href=''>#: AccountTypeName # ( #: AccountTpeNameEng # )</div>",
                                                field: "AccountTypeName",
                                                title: "Account Type"
                                            }
                                        ]
                                    });
                                });
                                break;
                        }
                    }
                };
                AmaxReport = __decorate([
                    core_1.Component({
                        template: "\n        <h1>{{ReportName}}</h1>\n        \n        <div id=\"formReport\">\n        </div>\n    ",
                        directives: [router_1.ROUTER_DIRECTIVES],
                        providers: [AmaxService_1.AmaxService]
                    }), 
                    __metadata('design:paramtypes', [AmaxService_1.AmaxService, router_1.RouteParams])
                ], AmaxReport);
                return AmaxReport;
            }());
            exports_1("AmaxReport", AmaxReport);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFtYXgvcmVwb3J0cy9hbWF4UmVwb3J0cy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztZQWlCQTtnQkFJSSxvQkFBb0IsWUFBd0IsRUFBVSxZQUF3QjtvQkFBMUQsaUJBQVksR0FBWixZQUFZLENBQVk7b0JBQVUsaUJBQVksR0FBWixZQUFZLENBQVk7Z0JBQzlFLENBQUM7Z0JBQ0QsK0JBQVUsR0FBVixVQUFXLFFBQWU7b0JBQ3RCLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQztnQkFDcEIsQ0FBQztnQkFDRCw2QkFBUSxHQUFSO29CQUNJLElBQUksR0FBRyxHQUFFLElBQUksQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN0QyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO3dCQUNOLE1BQU0sQ0FBQSxDQUFDLEdBQUcsQ0FBQyxDQUFBLENBQUM7NEJBQ1IsS0FBSyxVQUFVO2dDQUNYLElBQUksQ0FBQyxVQUFVLEdBQUcsVUFBVSxDQUFDO2dDQUM3QixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsQ0FBQztnQ0FFdkQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO29DQUMxQixNQUFNLENBQUMsYUFBYSxDQUFDLENBQUMsU0FBUyxDQUFDO3dDQUM1QixVQUFVLEVBQUU7NENBQ1IsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUM7eUNBQ2hCO3dDQUNELE1BQU0sRUFBQyxHQUFHO3dDQUNWLE9BQU8sRUFBQzs0Q0FDSjtnREFDSSxRQUFRLEVBQUUsNkVBQTZFO2dEQUN2RixLQUFLLEVBQUUsYUFBYTtnREFDcEIsS0FBSyxFQUFFLGNBQWM7NkNBQ3hCOzRDQUNEO2dEQUNJLFFBQVEsRUFBRSw0REFBNEQ7Z0RBQ3RFLEtBQUssRUFBRSxpQkFBaUI7Z0RBQ3hCLEtBQUssRUFBRSxjQUFjOzZDQUN4Qjs0Q0FDRDtnREFDSSxRQUFRLEVBQUMsK0JBQStCO2dEQUN4QyxLQUFLLEVBQUMsZUFBZTtnREFDckIsS0FBSyxFQUFDLGdCQUFnQjs2Q0FDekI7eUNBQ0o7cUNBQ0osQ0FBQyxDQUFDO2dDQUNQLENBQUMsQ0FBQyxDQUFDO2dDQUNILEtBQUssQ0FBQzs0QkFDVixLQUFLLGFBQWE7Z0NBQ2QsSUFBSSxDQUFDLFVBQVUsR0FBRyxnQkFBZ0IsQ0FBQztnQ0FDbkMsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLENBQUE7Z0NBRXRELElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTtvQ0FDMUIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO29DQUM5QixPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDLENBQUM7b0NBQzlCLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztvQ0FDOUIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztvQ0FFbEIsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDLFNBQVMsQ0FBQzt3Q0FDNUIsVUFBVSxFQUFFOzRDQUNSLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDO3lDQUNoQjt3Q0FDRCxNQUFNLEVBQUMsR0FBRzt3Q0FDVixVQUFVLEVBQUMsVUFBVTt3Q0FDckIsT0FBTyxFQUFDOzRDQUNKO2dEQUNJLFFBQVEsRUFBRSxvRUFBb0U7Z0RBQzlFLEtBQUssRUFBRSxpQkFBaUI7Z0RBQ3hCLEtBQUssRUFBRSxjQUFjOzZDQUN4Qjt5Q0FDSjtxQ0FDSixDQUFDLENBQUM7Z0NBQ1AsQ0FBQyxDQUFDLENBQUM7Z0NBQ0gsS0FBSyxDQUFDO3dCQUNkLENBQUM7b0JBQ0wsQ0FBQztnQkFDTCxDQUFDO2dCQWpGTDtvQkFBQyxnQkFBUyxDQUFDO3dCQUNQLFFBQVEsRUFBRSxvR0FLVDt3QkFDRCxVQUFVLEVBQUMsQ0FBQywwQkFBaUIsQ0FBQzt3QkFDOUIsU0FBUyxFQUFFLENBQUMseUJBQVcsQ0FBQztxQkFDM0IsQ0FBQzs7OEJBQUE7Z0JBeUVGLGlCQUFDO1lBQUQsQ0F4RUEsQUF3RUMsSUFBQTtZQXhFRCxtQ0F3RUMsQ0FBQSIsImZpbGUiOiJhbWF4L3JlcG9ydHMvYW1heFJlcG9ydHMuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge0NvbXBvbmVudCwgT25Jbml0fSBmcm9tIFwiYW5ndWxhcjIvY29yZVwiO1xyXG5pbXBvcnQge09ic2VydmFibGV9IGZyb20gXCJyeGpzL09ic2VydmFibGVcIjtcclxuaW1wb3J0IHtBbWF4U2VydmljZX0gZnJvbSBcIi4uLy4uL3NlcnZpY2VzL0FtYXhTZXJ2aWNlXCI7XHJcbmltcG9ydCB7Um91dGVQYXJhbXMsIFJPVVRFUl9ESVJFQ1RJVkVTfSBmcm9tIFwiYW5ndWxhcjIvcm91dGVyXCI7XHJcblxyXG5kZWNsYXJlIHZhciBqUXVlcnk7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHRlbXBsYXRlOiBgXHJcbiAgICAgICAgPGgxPnt7UmVwb3J0TmFtZX19PC9oMT5cclxuICAgICAgICBcclxuICAgICAgICA8ZGl2IGlkPVwiZm9ybVJlcG9ydFwiPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgYCxcclxuICAgIGRpcmVjdGl2ZXM6W1JPVVRFUl9ESVJFQ1RJVkVTXSxcclxuICAgIHByb3ZpZGVyczogW0FtYXhTZXJ2aWNlXVxyXG59KVxyXG5leHBvcnQgY2xhc3MgQW1heFJlcG9ydCBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcbiAgICBSZXBvcnREYXRhOk9ic2VydmFibGU7XHJcbiAgICBSZXBvcnROYW1lOnN0cmluZztcclxuXHJcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIF9hbWF4U2VydmljZTpBbWF4U2VydmljZSwgcHJpdmF0ZSBfcm91dGVQYXJhbXM6Um91dGVQYXJhbXMpIHtcclxuICAgIH1cclxuICAgIHJlZGlyZWN0VG8obG9jYXRpb246c3RyaW5nKXtcclxuICAgICAgICBhbGVydChsb2NhdGlvbik7XHJcbiAgICB9XHJcbiAgICBuZ09uSW5pdCgpIHtcclxuICAgICAgICB2YXIgcnB0ID10aGlzLl9yb3V0ZVBhcmFtcy5nZXQoJ3JwdCcpO1xyXG4gICAgICAgIGlmIChycHQpIHtcclxuICAgICAgICAgICAgc3dpdGNoKHJwdCl7XHJcbiAgICAgICAgICAgICAgICBjYXNlIFwiQWNjb3VudHNcIjpcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLlJlcG9ydE5hbWUgPSBcIkFjY291bnRzXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5SZXBvcnREYXRhID0gdGhpcy5fYW1heFNlcnZpY2UuR2V0UmVwb3J0KHJwdCwge30pO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICB0aGlzLlJlcG9ydERhdGEuc3Vic2NyaWJlKGRhdGE9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGpRdWVyeShcIiNmb3JtUmVwb3J0XCIpLmtlbmRvR3JpZCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhU291cmNlOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YTogZGF0YVswXVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDozNTAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zOltcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlOiBcIjxkaXYgKGNsaWNrKT0ncmVkaXJlY3RUbyhcXFwiZm9ybT9mcm09QWNjb3VudHNcXFwiKSc+IzogQWNjb3VudE5hbWUgIzwvZGl2PjwvYT5cIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZmllbGQ6IFwiQWNjb3VudE5hbWVcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU6IFwiQWNjb3VudCBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGU6IFwiPGRpdj4jOiBBY2NvdW50VHlwZU5hbWUgIyAoICM6IEFjY291bnRUcGVOYW1lRW5nICMgKTwvZGl2PlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaWVsZDogXCJBY2NvdW50VHlwZU5hbWVcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU6IFwiQWNjb3VudCBUeXBlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGU6XCI8ZGl2PiM6IEFjY291bnREZXRhaWwgIzwvZGl2PlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaWVsZDpcIkFjY291bnREZXRhaWxcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU6XCJBY2NvdW50IERldGFpbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIGNhc2UgXCJBY2NvdW50VHlwZVwiOlxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuUmVwb3J0TmFtZSA9IFwiQWNjb3VudHMgVHlwZXNcIjtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLlJlcG9ydERhdGEgPSB0aGlzLl9hbWF4U2VydmljZS5HZXRSZXBvcnQocnB0LCB7fSlcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5SZXBvcnREYXRhLnN1YnNjcmliZShkYXRhPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIjEuIEhlbGxvIFdvcmxkXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIjIuIEhlbGxvIFdvcmxkXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIjMuIEhlbGxvIFdvcmxkXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhkYXRhKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGpRdWVyeShcIiNmb3JtUmVwb3J0XCIpLmtlbmRvR3JpZCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhU291cmNlOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YTogZGF0YVswXVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDozNTAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RhYmxlOlwibXVsdGlwbGVcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbnM6W1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGU6IFwiPGRpdiBocmVmPScnPiM6IEFjY291bnRUeXBlTmFtZSAjICggIzogQWNjb3VudFRwZU5hbWVFbmcgIyApPC9kaXY+XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpZWxkOiBcIkFjY291bnRUeXBlTmFtZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogXCJBY2NvdW50IFR5cGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuIl19
