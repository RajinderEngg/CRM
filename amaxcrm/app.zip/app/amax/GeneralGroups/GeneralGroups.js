System.register(['angular2/common', "angular2/router", "angular2/core", "../../services/AmaxCrmSyinc", "../../services/ResourceService", "../../services/AmaxService", "../../services/GeneralGroupsService", "../../amaxUtil"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var common_1, router_1, core_1, AmaxCrmSyinc_1, ResourceService_1, AmaxService_1, GeneralGroupsService_1, amaxUtil_1;
    var AmaxGeneralGroups;
    return {
        setters:[
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (AmaxCrmSyinc_1_1) {
                AmaxCrmSyinc_1 = AmaxCrmSyinc_1_1;
            },
            function (ResourceService_1_1) {
                ResourceService_1 = ResourceService_1_1;
            },
            function (AmaxService_1_1) {
                AmaxService_1 = AmaxService_1_1;
            },
            function (GeneralGroupsService_1_1) {
                GeneralGroupsService_1 = GeneralGroupsService_1_1;
            },
            function (amaxUtil_1_1) {
                amaxUtil_1 = amaxUtil_1_1;
            }],
        execute: function() {
            AmaxGeneralGroups = (function () {
                function AmaxGeneralGroups(_resourceService, _routeParams, _amaxService, _GeneralGroupsService) {
                    this._resourceService = _resourceService;
                    this._routeParams = _routeParams;
                    this._amaxService = _amaxService;
                    this._GeneralGroupsService = _GeneralGroupsService;
                    this.modelInput = {};
                    this.custSearchData = [];
                    this.RES = {};
                    this.Formtype = "GENERAL_GROUP";
                    this.Lang = "";
                    this.ShowMoreText = "More";
                    this.ShowLoader = false;
                    this.ShowMsg = false;
                    this.GroupText = "Show Groups";
                    this.Msg = "";
                    this.MsgClass = "text-primary";
                    this.Isbtndisable = "";
                    this.GroupIds = "";
                    this.KendoRTLCSS = "";
                    this._Groups = [];
                    this.ChangeDialog = "";
                    this.CHANGEDIR = "";
                    this.modelInput.CustomerAddresses = [];
                    this.modelInput.CustomerPhones = [];
                    this.modelInput.CustomerEmails = [];
                    this.modelInput.CustomerGroups = [];
                    this.modelInput.employeeid = "";
                    this.modelInput.CustomerType = "";
                    this.modelInput.CameFromCustomer = "";
                    this.modelInput.Safixid = "";
                    this.modelInput.Gender = "0";
                    this.RES.GENERAL_GROUP = {};
                    this.Formtype = "GENERAL_GROUP";
                    this.GroupIds = "";
                    this.baseUrl = _resourceService.AppUrl;
                }
                AmaxGeneralGroups.prototype.SetdefaultPage = function () {
                    this.modelInput = {};
                    this.Formtype = "GENERAL_GROUP";
                    this.GroupIds = "";
                    this.ShowMsg = false;
                    this.Msg = "";
                };
                AmaxGeneralGroups.prototype.GetCustData = function () {
                    var _this = this;
                    this.GroupIds = "";
                    var _CheckedGroups = [];
                    // debugger;
                    amaxUtil_1.Kendo_utility.checkedNodeIds(jQuery("#groupTree").data("kendoTreeView").dataSource.view(), _CheckedGroups);
                    for (var i = 0; i < _CheckedGroups.length; i++) {
                        this.GroupIds = this.GroupIds + _CheckedGroups[i] + ",";
                    }
                    //alert(this.GroupIds);
                    if (this.GroupIds.length > 0) {
                        this.GroupIds = this.GroupIds.substring(0, this.GroupIds.length - 1);
                        /////////////////Creating Cache///////////////////
                        this._resourceService.setCookie("GeneralGroup_Cache", this.GroupIds, 10);
                    }
                    this._GeneralGroupsService.GetCompleteCustDet(this.GroupIds).subscribe(function (response) {
                        //debugger;
                        _this.Isbtndisable = "disabled";
                        _this.ShowLoader = true;
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.modelInput = response.Data;
                            var burl = _this.baseUrl;
                            jQuery.each(_this.modelInput, function () {
                                this.BUrl = burl + "Customer/Add/";
                            });
                            var dataSource = _this.modelInput;
                            jQuery("#grid").kendoGrid({
                                dataSource: dataSource,
                                pageable: {
                                    pageSizes: true,
                                    buttonCount: 5,
                                    pageSize: 20
                                },
                                sortable: true,
                                scrolleble: true,
                                selectable: true,
                                height: 400,
                                columns: [
                                    {
                                        field: "CustomerId", title: _this.RES.GENERAL_GROUP.KENDOGRID_CUSTID,
                                        //template: '<a href="#=CustomerId#">#:CustomerId#</a>' http://c.amax.co.il/#/Customer/Add/
                                        template: function (dataItem) {
                                            return "<a href='" + kendo.htmlEncode(dataItem.BUrl) + kendo.htmlEncode(dataItem.CustomerId) + "'>" + kendo.htmlEncode(dataItem.CustomerId) + "</a>";
                                        }
                                    },
                                    { field: "FileAs", title: _this.RES.GENERAL_GROUP.KENDOGRID_FILEAS }
                                ],
                            });
                        }
                        _this.Isbtndisable = "";
                        _this.ShowLoader = false;
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxGeneralGroups.prototype.ngOnInit = function () {
                    var _this = this;
                    this.Lang = localStorage.getItem("lang");
                    this.SetdefaultPage();
                    if (this.Lang == "he") {
                        this.KendoRTLCSS = "k-rtl";
                    }
                    else {
                        this.KendoRTLCSS = "";
                    }
                    this._resourceService.GetLangRes(this.Formtype, this.Lang).subscribe(function (response) {
                        //debugger; 
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.RES = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //Tree Group
                    this._amaxService.GetGeneralGroupTree().subscribe(function (data) {
                        var res = jQuery.parseJSON(data);
                        jQuery("#groupTree").kendoTreeView({
                            loadOnDemand: true,
                            checkboxes: {},
                            check: function (e) {
                                this.expandRoot = e.node;
                                this.expand(jQuery(this.expandRoot).find(".k-item").addBack());
                            },
                            dataSource: res.Data.kendoTree
                        });
                        var dataSource = null;
                        jQuery("#grid").kendoGrid({
                            dataSource: dataSource,
                            pageable: {
                                pageSizes: true,
                                buttonCount: 5,
                                pageSize: 20
                            },
                            sortable: true,
                            scrolleble: true,
                            selectable: true,
                            height: 400,
                            columns: [
                                {
                                    field: "CustomerId", title: _this.RES.GENERAL_GROUP.KENDOGRID_CUSTID,
                                    template: "<a>#:CustomerId#</a>"
                                },
                                { field: "FileAs", title: _this.RES.GENERAL_GROUP.KENDOGRID_FILEAS }
                            ],
                        });
                        // debugger;
                        var jdata = _this._resourceService.getCookie("GeneralGroup_Cache");
                        if (jdata != undefined && jdata != undefined && jdata != "") {
                            jdata = jdata.substring(1, jdata.length);
                            _this.GroupIds = jdata;
                            var grpids = _this.GroupIds.split(',');
                            var bindgrps = "";
                            for (var i = 0; i < grpids.length; i++) {
                                bindgrps += grpids[i] + ";";
                            }
                            amaxUtil_1.Kendo_utility.checkingNodeIds(jQuery("#groupTree").data("kendoTreeView").dataSource.view(), bindgrps.substring(0, bindgrps.length - 1));
                            _this.GetCustData();
                        }
                    }, function (err) {
                    }, function () {
                    });
                };
                AmaxGeneralGroups = __decorate([
                    core_1.Component({
                        templateUrl: './app/amax/GeneralGroups/templates/GeneralGroups.html',
                        directives: [common_1.NgSwitch, common_1.NgSwitchWhen, common_1.NgSwitchDefault],
                        providers: [AmaxService_1.AmaxService, AmaxCrmSyinc_1.AmaxCrmSyinc, ResourceService_1.ResourceService, GeneralGroupsService_1.GeneralGroupsService]
                    }), 
                    __metadata('design:paramtypes', [ResourceService_1.ResourceService, router_1.RouteParams, AmaxService_1.AmaxService, GeneralGroupsService_1.GeneralGroupsService])
                ], AmaxGeneralGroups);
                return AmaxGeneralGroups;
            }());
            exports_1("AmaxGeneralGroups", AmaxGeneralGroups);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFtYXgvR2VuZXJhbEdyb3Vwcy9HZW5lcmFsR3JvdXBzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1lBZ0JBO2dCQXNCSSwyQkFBb0IsZ0JBQWlDLEVBQVUsWUFBeUIsRUFBVSxZQUF5QixFQUFVLHFCQUEyQztvQkFBNUoscUJBQWdCLEdBQWhCLGdCQUFnQixDQUFpQjtvQkFBVSxpQkFBWSxHQUFaLFlBQVksQ0FBYTtvQkFBVSxpQkFBWSxHQUFaLFlBQVksQ0FBYTtvQkFBVSwwQkFBcUIsR0FBckIscUJBQXFCLENBQXNCO29CQXJCaEwsZUFBVSxHQUFHLEVBQUUsQ0FBQztvQkFDaEIsbUJBQWMsR0FBVyxFQUFFLENBQUM7b0JBQzVCLFFBQUcsR0FBVyxFQUFFLENBQUM7b0JBQ2pCLGFBQVEsR0FBVSxlQUFlLENBQUM7b0JBQ2xDLFNBQUksR0FBUyxFQUFFLENBQUM7b0JBQ2hCLGlCQUFZLEdBQVcsTUFBTSxDQUFDO29CQUU5QixlQUFVLEdBQVksS0FBSyxDQUFDO29CQUM1QixZQUFPLEdBQVksS0FBSyxDQUFDO29CQUN6QixjQUFTLEdBQVMsYUFBYSxDQUFDO29CQUNoQyxRQUFHLEdBQVcsRUFBRSxDQUFDO29CQUNqQixhQUFRLEdBQVcsY0FBYyxDQUFDO29CQUNsQyxpQkFBWSxHQUFXLEVBQUUsQ0FBQztvQkFDMUIsYUFBUSxHQUFXLEVBQUUsQ0FBQztvQkFFdEIsZ0JBQVcsR0FBVyxFQUFFLENBQUM7b0JBQ3pCLFlBQU8sR0FBRyxFQUFFLENBQUM7b0JBQ2IsaUJBQVksR0FBVyxFQUFFLENBQUM7b0JBQzFCLGNBQVMsR0FBVyxFQUFFLENBQUM7b0JBS25CLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLEdBQUcsRUFBRSxDQUFDO29CQUN2QyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxFQUFFLENBQUM7b0JBQ3BDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLEVBQUUsQ0FBQztvQkFDcEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDO29CQUVwQyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBRyxFQUFFLENBQUM7b0JBQ2hDLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxHQUFHLEVBQUUsQ0FBQztvQkFDbEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsR0FBRyxFQUFFLENBQUM7b0JBQ3RDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztvQkFDN0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsR0FBRyxDQUFDO29CQUM3QixJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsR0FBRyxFQUFFLENBQUM7b0JBQzVCLElBQUksQ0FBQyxRQUFRLEdBQUcsZUFBZSxDQUFDO29CQUNoQyxJQUFJLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQztvQkFDbkIsSUFBSSxDQUFDLE9BQU8sR0FBRyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUM7Z0JBSzNDLENBQUM7Z0JBS0QsMENBQWMsR0FBZDtvQkFJSSxJQUFJLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztvQkFFckIsSUFBSSxDQUFDLFFBQVEsR0FBRyxlQUFlLENBQUM7b0JBQ2hDLElBQUksQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDO29CQUtuQixJQUFJLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQztvQkFDckIsSUFBSSxDQUFDLEdBQUcsR0FBRyxFQUFFLENBQUM7Z0JBQ2xCLENBQUM7Z0JBSUQsdUNBQVcsR0FBWDtvQkFBQSxpQkE2RUM7b0JBM0VHLElBQUksQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDO29CQUNuQixJQUFJLGNBQWMsR0FBRyxFQUFFLENBQUM7b0JBRXpCLFlBQVk7b0JBQ1gsd0JBQWEsQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLEVBQUUsY0FBYyxDQUFDLENBQUM7b0JBQzNHLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsY0FBYyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDO3dCQUM3QyxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxRQUFRLEdBQUcsY0FBYyxDQUFDLENBQUMsQ0FBQyxHQUFDLEdBQUcsQ0FBQztvQkFDMUQsQ0FBQztvQkFHRCx1QkFBdUI7b0JBQ3ZCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQzNCLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDO3dCQUNyRSxrREFBa0Q7d0JBRWxELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsb0JBQW9CLEVBQUUsSUFBSSxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQztvQkFDN0UsQ0FBQztvQkFDRCxJQUFJLENBQUMscUJBQXFCLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7d0JBQzNFLFdBQVc7d0JBQ1gsS0FBSSxDQUFDLFlBQVksR0FBRyxVQUFVLENBQUM7d0JBQy9CLEtBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO3dCQUN2QixRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDdEMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDO2dDQUNWLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtnQ0FDeEIsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZO2dDQUM1QixPQUFPLEVBQUU7b0NBQ0wsRUFBRSxFQUFFO3dDQUNBLGNBQWM7d0NBQ2QsU0FBUyxFQUFFLEtBQUksQ0FBQyxTQUFTO3FDQUM1QjtpQ0FDSjs2QkFDSixDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFDRCxJQUFJLENBQUMsQ0FBQzs0QkFDRixLQUFJLENBQUMsVUFBVSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7NEJBQ2hDLElBQUksSUFBSSxHQUFHLEtBQUksQ0FBQyxPQUFPLENBQUM7NEJBQ3hCLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLFVBQVUsRUFBRTtnQ0FDekIsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLEdBQUMsZUFBZSxDQUFDOzRCQUNyQyxDQUFDLENBQUMsQ0FBQzs0QkFFSCxJQUFJLFVBQVUsR0FBRyxLQUFJLENBQUMsVUFBVSxDQUFDOzRCQUNqQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDO2dDQUN0QixVQUFVLEVBQUUsVUFBVTtnQ0FDdEIsUUFBUSxFQUFFO29DQUNOLFNBQVMsRUFBRSxJQUFJO29DQUNmLFdBQVcsRUFBRSxDQUFDO29DQUNkLFFBQVEsRUFBRSxFQUFFO2lDQUNmO2dDQUNELFFBQVEsRUFBRSxJQUFJO2dDQUNkLFVBQVUsRUFBRSxJQUFJO2dDQUNoQixVQUFVLEVBQUUsSUFBSTtnQ0FDaEIsTUFBTSxFQUFFLEdBQUc7Z0NBRVgsT0FBTyxFQUFFO29DQUNMO3dDQUNJLEtBQUssRUFBRSxZQUFZLEVBQUUsS0FBSyxFQUFFLEtBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLGdCQUFnQjt3Q0FDbkUsMkZBQTJGO3dDQUMzRixRQUFRLEVBQUUsVUFBVSxRQUFROzRDQUN4QixNQUFNLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFFLEtBQUssQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxHQUFHLElBQUksR0FBRyxLQUFLLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsR0FBRyxNQUFNLENBQUM7d0NBQ3hKLENBQUM7cUNBQ0o7b0NBQ0QsRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLEtBQUssRUFBRSxLQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsRUFBRTtpQ0FFdEU7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsS0FBSSxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUM7d0JBQ3ZCLEtBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO29CQUM1QixDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztnQkFFUCxDQUFDO2dCQUNELG9DQUFRLEdBQVI7b0JBQUEsaUJBbUhDO29CQTdHRyxJQUFJLENBQUMsSUFBSSxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQ3pDLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztvQkFLdEIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO3dCQUNwQixJQUFJLENBQUMsV0FBVyxHQUFHLE9BQU8sQ0FBQztvQkFDL0IsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixJQUFJLENBQUMsV0FBVyxHQUFHLEVBQUUsQ0FBQztvQkFDMUIsQ0FBQztvQkFFRixJQUFJLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7d0JBQ3pFLFlBQVk7d0JBQ1osUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLEdBQUcsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO3dCQUM3QixDQUFDO29CQUNMLENBQUMsRUFBRSxVQUFBLEtBQUs7d0JBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFO3dCQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7b0JBQ2hDLENBQUMsQ0FBQyxDQUFDO29CQU1GLFlBQVk7b0JBR2IsSUFBSSxDQUFDLFlBQVksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDLFNBQVMsQ0FFN0MsVUFBQyxJQUFJO3dCQUNELElBQUksR0FBRyxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBRWpDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxhQUFhLENBQUM7NEJBQy9CLFlBQVksRUFBRSxJQUFJOzRCQUNsQixVQUFVLEVBQUUsRUFFWDs0QkFDRCxLQUFLLEVBQUUsVUFBVSxDQUFDO2dDQUNkLElBQUksQ0FBQyxVQUFVLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztnQ0FFekIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDOzRCQUNuRSxDQUFDOzRCQUNELFVBQVUsRUFBRSxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVM7eUJBQ2pDLENBQUMsQ0FBQzt3QkFDSCxJQUFJLFVBQVUsR0FBRyxJQUFJLENBQUM7d0JBQ3RCLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUM7NEJBQ3RCLFVBQVUsRUFBRSxVQUFVOzRCQUN0QixRQUFRLEVBQUU7Z0NBQ04sU0FBUyxFQUFFLElBQUk7Z0NBQ2YsV0FBVyxFQUFFLENBQUM7Z0NBQ2QsUUFBUSxFQUFFLEVBQUU7NkJBQ2Y7NEJBQ0QsUUFBUSxFQUFFLElBQUk7NEJBQ2QsVUFBVSxFQUFFLElBQUk7NEJBQ2hCLFVBQVUsRUFBRSxJQUFJOzRCQUNoQixNQUFNLEVBQUUsR0FBRzs0QkFDWCxPQUFPLEVBQUU7Z0NBQ0w7b0NBQ0ksS0FBSyxFQUFFLFlBQVksRUFBRSxLQUFLLEVBQUUsS0FBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsZ0JBQWdCO29DQUNuRSxRQUFRLEVBQUUsc0JBQXNCO2lDQUNuQztnQ0FDRCxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsS0FBSyxFQUFFLEtBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLGdCQUFnQixFQUFHOzZCQUV2RTt5QkFDSixDQUFDLENBQUM7d0JBRUosWUFBWTt3QkFDWCxJQUFJLEtBQUssR0FBRyxLQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLG9CQUFvQixDQUFDLENBQUM7d0JBQ2xFLEVBQUUsQ0FBQyxDQUFDLEtBQUssSUFBSSxTQUFTLElBQUksS0FBSyxJQUFJLFNBQVMsSUFBSSxLQUFLLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQzs0QkFDMUQsS0FBSyxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQzs0QkFDekMsS0FBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7NEJBQ3RCLElBQUksTUFBTSxHQUFHLEtBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDOzRCQUN0QyxJQUFJLFFBQVEsR0FBRyxFQUFFLENBQUM7NEJBQ2xCLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDO2dDQUNyQyxRQUFRLElBQUksTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQzs0QkFDaEMsQ0FBQzs0QkFDRCx3QkFBYSxDQUFDLGVBQWUsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsRUFBRSxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7NEJBQ3hJLEtBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQzt3QkFDdkIsQ0FBQztvQkFFTCxDQUFDLEVBQ0QsVUFBQyxHQUFHO29CQUVKLENBQUMsRUFDRDtvQkFFQSxDQUFDLENBRUosQ0FBQztnQkFJTCxDQUFDO2dCQXhRTDtvQkFBQyxnQkFBUyxDQUFDO3dCQUVQLFdBQVcsRUFBRSx1REFBdUQ7d0JBQ3BFLFVBQVUsRUFBRSxDQUFDLGlCQUFRLEVBQUUscUJBQVksRUFBRSx3QkFBZSxDQUFDO3dCQUNyRCxTQUFTLEVBQUUsQ0FBQyx5QkFBVyxFQUFFLDJCQUFZLEVBQUUsaUNBQWUsRUFBRSwyQ0FBb0IsQ0FBQztxQkFDaEYsQ0FBQzs7cUNBQUE7Z0JBb1FGLHdCQUFDO1lBQUQsQ0FuUUEsQUFtUUMsSUFBQTtZQW5RRCxpREFtUUMsQ0FBQSIsImZpbGUiOiJhbWF4L0dlbmVyYWxHcm91cHMvR2VuZXJhbEdyb3Vwcy5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7TmdTd2l0Y2gsIE5nU3dpdGNoV2hlbiwgTmdTd2l0Y2hEZWZhdWx0LCBDT1JFX0RJUkVDVElWRVMsIEZPUk1fRElSRUNUSVZFU30gZnJvbSAnYW5ndWxhcjIvY29tbW9uJ1xyXG5pbXBvcnQge1JvdXRlUGFyYW1zfSBmcm9tIFwiYW5ndWxhcjIvcm91dGVyXCI7XHJcbmltcG9ydCB7Q29tcG9uZW50LCBPdXRwdXQsIElucHV0LCBFdmVudEVtaXR0ZXIsIE9uSW5pdH0gZnJvbSBcImFuZ3VsYXIyL2NvcmVcIjtcclxuaW1wb3J0IHtBbWF4Q3JtU3lpbmN9IGZyb20gXCIuLi8uLi9zZXJ2aWNlcy9BbWF4Q3JtU3lpbmNcIjtcclxuaW1wb3J0IHtSZXNvdXJjZVNlcnZpY2V9IGZyb20gXCIuLi8uLi9zZXJ2aWNlcy9SZXNvdXJjZVNlcnZpY2VcIjtcclxuaW1wb3J0IHtBbWF4U2VydmljZX0gZnJvbSBcIi4uLy4uL3NlcnZpY2VzL0FtYXhTZXJ2aWNlXCI7XHJcbmltcG9ydCB7R2VuZXJhbEdyb3Vwc1NlcnZpY2V9IGZyb20gXCIuLi8uLi9zZXJ2aWNlcy9HZW5lcmFsR3JvdXBzU2VydmljZVwiO1xyXG5pbXBvcnQgeyBqc29uUSB9IGZyb20gJy4uLy4uL2pzb25RJztcclxuaW1wb3J0IHtHcm91cEZpbHRlclBpcGUsIEdyb3VwUGFyZW5GaWx0ZXJQaXBlLCBLZW5kb191dGlsaXR5fSBmcm9tIFwiLi4vLi4vYW1heFV0aWxcIjtcclxuZGVjbGFyZSB2YXIgalF1ZXJ5O1xyXG5AQ29tcG9uZW50KHtcclxuXHJcbiAgICB0ZW1wbGF0ZVVybDogJy4vYXBwL2FtYXgvR2VuZXJhbEdyb3Vwcy90ZW1wbGF0ZXMvR2VuZXJhbEdyb3Vwcy5odG1sJyxcclxuICAgIGRpcmVjdGl2ZXM6IFtOZ1N3aXRjaCwgTmdTd2l0Y2hXaGVuLCBOZ1N3aXRjaERlZmF1bHRdLFxyXG4gICAgcHJvdmlkZXJzOiBbQW1heFNlcnZpY2UsIEFtYXhDcm1TeWluYywgUmVzb3VyY2VTZXJ2aWNlLCBHZW5lcmFsR3JvdXBzU2VydmljZV1cclxufSlcclxuZXhwb3J0IGNsYXNzIEFtYXhHZW5lcmFsR3JvdXBzIGltcGxlbWVudHMgT25Jbml0IHtcclxuICAgIG1vZGVsSW5wdXQgPSB7fTtcclxuICAgIGN1c3RTZWFyY2hEYXRhOiBPYmplY3QgPSBbXTtcclxuICAgIFJFUzogT2JqZWN0ID0ge307XHJcbiAgICBGb3JtdHlwZTogc3RyaW5nID1cIkdFTkVSQUxfR1JPVVBcIjtcclxuICAgIExhbmc6IHN0cmluZz1cIlwiO1xyXG4gICAgU2hvd01vcmVUZXh0OiBzdHJpbmcgPSBcIk1vcmVcIjtcclxuXHJcbiAgICBTaG93TG9hZGVyOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBTaG93TXNnOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBHcm91cFRleHQ6IHN0cmluZz1cIlNob3cgR3JvdXBzXCI7XHJcbiAgICBNc2c6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBNc2dDbGFzczogc3RyaW5nID0gXCJ0ZXh0LXByaW1hcnlcIjtcclxuICAgIElzYnRuZGlzYWJsZTogc3RyaW5nID0gXCJcIjtcclxuICAgIEdyb3VwSWRzOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgYmFzZVVybDogc3RyaW5nO1xyXG4gICAgS2VuZG9SVExDU1M6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBfR3JvdXBzID0gW107XHJcbiAgICBDaGFuZ2VEaWFsb2c6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBDSEFOR0VESVI6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBcclxuXHJcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIF9yZXNvdXJjZVNlcnZpY2U6IFJlc291cmNlU2VydmljZSwgcHJpdmF0ZSBfcm91dGVQYXJhbXM6IFJvdXRlUGFyYW1zLCBwcml2YXRlIF9hbWF4U2VydmljZTogQW1heFNlcnZpY2UsIHByaXZhdGUgX0dlbmVyYWxHcm91cHNTZXJ2aWNlOiBHZW5lcmFsR3JvdXBzU2VydmljZSkge1xyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckFkZHJlc3NlcyA9IFtdO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclBob25lcyA9IFtdO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckVtYWlscyA9IFtdO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lckdyb3VwcyA9IFtdO1xyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5lbXBsb3llZWlkID0gXCJcIjtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ3VzdG9tZXJUeXBlID0gXCJcIjtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuQ2FtZUZyb21DdXN0b21lciA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LlNhZml4aWQgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5HZW5kZXIgPSBcIjBcIjtcclxuICAgICAgICB0aGlzLlJFUy5HRU5FUkFMX0dST1VQID0ge307XHJcbiAgICAgICAgdGhpcy5Gb3JtdHlwZSA9IFwiR0VORVJBTF9HUk9VUFwiO1xyXG4gICAgICAgIHRoaXMuR3JvdXBJZHMgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMuYmFzZVVybCA9IF9yZXNvdXJjZVNlcnZpY2UuQXBwVXJsO1xyXG4gICAgIFxyXG5cclxuICAgICAgIFxyXG4gICAgICAgIFxyXG4gICAgfVxyXG4gICAgcHJpdmF0ZSBfY2FjaGVkUmVzdWx0OiBhbnk7XHJcbiAgICBwcml2YXRlIF9wcmV2aW91c0NvbnRleHQ6IGFueTtcclxuICAgIFxyXG4gICBcclxuICAgIFNldGRlZmF1bHRQYWdlKCk6IG9ic2VydmF2YmxlIHtcclxuICAgICAgIFxyXG4gICAgICAgIFxyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dCA9IHt9O1xyXG5cclxuICAgICAgICB0aGlzLkZvcm10eXBlID0gXCJHRU5FUkFMX0dST1VQXCI7XHJcbiAgICAgICAgdGhpcy5Hcm91cElkcyA9IFwiXCI7XHJcblxyXG4gICAgICAgXHJcblxyXG4gICAgICAgXHJcbiAgICAgICAgdGhpcy5TaG93TXNnID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5Nc2cgPSBcIlwiO1xyXG4gICAgfVxyXG4gICAgXHJcbiAgIFxyXG5cclxuICAgIEdldEN1c3REYXRhKCk6IHZvaWQge1xyXG4gICAgICAgXHJcbiAgICAgICAgdGhpcy5Hcm91cElkcyA9IFwiXCI7XHJcbiAgICAgICAgdmFyIF9DaGVja2VkR3JvdXBzID0gW107XHJcbiAgICAgICAgXHJcbiAgICAgICAvLyBkZWJ1Z2dlcjtcclxuICAgICAgICBLZW5kb191dGlsaXR5LmNoZWNrZWROb2RlSWRzKGpRdWVyeShcIiNncm91cFRyZWVcIikuZGF0YShcImtlbmRvVHJlZVZpZXdcIikuZGF0YVNvdXJjZS52aWV3KCksIF9DaGVja2VkR3JvdXBzKTtcclxuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IF9DaGVja2VkR3JvdXBzLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIHRoaXMuR3JvdXBJZHMgPSB0aGlzLkdyb3VwSWRzKyAgX0NoZWNrZWRHcm91cHNbaV0rXCIsXCI7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBcclxuICAgICAgICAvL2FsZXJ0KHRoaXMuR3JvdXBJZHMpO1xyXG4gICAgICAgIGlmICh0aGlzLkdyb3VwSWRzLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgdGhpcy5Hcm91cElkcyA9IHRoaXMuR3JvdXBJZHMuc3Vic3RyaW5nKDAsIHRoaXMuR3JvdXBJZHMubGVuZ3RoIC0gMSk7XHJcbiAgICAgICAgICAgIC8vLy8vLy8vLy8vLy8vLy8vQ3JlYXRpbmcgQ2FjaGUvLy8vLy8vLy8vLy8vLy8vLy8vXHJcblxyXG4gICAgICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2Uuc2V0Q29va2llKFwiR2VuZXJhbEdyb3VwX0NhY2hlXCIsIHRoaXMuR3JvdXBJZHMsIDEwKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5fR2VuZXJhbEdyb3Vwc1NlcnZpY2UuR2V0Q29tcGxldGVDdXN0RGV0KHRoaXMuR3JvdXBJZHMpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAgLy9kZWJ1Z2dlcjtcclxuICAgICAgICAgICAgdGhpcy5Jc2J0bmRpc2FibGUgPSBcImRpc2FibGVkXCI7XHJcbiAgICAgICAgICAgIHRoaXMuU2hvd0xvYWRlciA9IHRydWU7XHJcbiAgICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGJvb3Rib3guYWxlcnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ0hBTkdFRElSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxJbnB1dCA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgICAgICB2YXIgYnVybCA9IHRoaXMuYmFzZVVybDtcclxuICAgICAgICAgICAgICAgIGpRdWVyeS5lYWNoKHRoaXMubW9kZWxJbnB1dCwgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuQlVybCA9IGJ1cmwrXCJDdXN0b21lci9BZGQvXCI7XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgICAgICB2YXIgZGF0YVNvdXJjZSA9IHRoaXMubW9kZWxJbnB1dDtcclxuICAgICAgICAgICAgICAgIGpRdWVyeShcIiNncmlkXCIpLmtlbmRvR3JpZCh7XHJcbiAgICAgICAgICAgICAgICAgICAgZGF0YVNvdXJjZTogZGF0YVNvdXJjZSxcclxuICAgICAgICAgICAgICAgICAgICBwYWdlYWJsZToge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYWdlU2l6ZXM6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbkNvdW50OiA1LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYWdlU2l6ZTogMjBcclxuICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgIHNvcnRhYmxlOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgIHNjcm9sbGVibGU6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgc2VsZWN0YWJsZTogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IDQwMCxcclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICBjb2x1bW5zOiBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpZWxkOiBcIkN1c3RvbWVySWRcIiwgdGl0bGU6IHRoaXMuUkVTLkdFTkVSQUxfR1JPVVAuS0VORE9HUklEX0NVU1RJRCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vdGVtcGxhdGU6ICc8YSBocmVmPVwiIz1DdXN0b21lcklkI1wiPiM6Q3VzdG9tZXJJZCM8L2E+JyBodHRwOi8vYy5hbWF4LmNvLmlsLyMvQ3VzdG9tZXIvQWRkL1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGU6IGZ1bmN0aW9uIChkYXRhSXRlbSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBcIjxhIGhyZWY9J1wiICsga2VuZG8uaHRtbEVuY29kZShkYXRhSXRlbS5CVXJsKSsga2VuZG8uaHRtbEVuY29kZShkYXRhSXRlbS5DdXN0b21lcklkKSArIFwiJz5cIiArIGtlbmRvLmh0bWxFbmNvZGUoZGF0YUl0ZW0uQ3VzdG9tZXJJZCkgKyBcIjwvYT5cIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgeyBmaWVsZDogXCJGaWxlQXNcIiwgdGl0bGU6IHRoaXMuUkVTLkdFTkVSQUxfR1JPVVAuS0VORE9HUklEX0ZJTEVBUyB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0aGlzLklzYnRuZGlzYWJsZSA9IFwiXCI7XHJcbiAgICAgICAgICAgIHRoaXMuU2hvd0xvYWRlciA9IGZhbHNlO1xyXG4gICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgICB9KTtcclxuICAgICAgICBcclxuICAgIH1cclxuICAgIG5nT25Jbml0KCkge1xyXG4gICAgICAgXHJcbiAgICAgICAgXHJcblxyXG4gICAgICAgIFxyXG5cclxuICAgICAgICB0aGlzLkxhbmcgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImxhbmdcIik7XHJcbiAgICAgICAgdGhpcy5TZXRkZWZhdWx0UGFnZSgpO1xyXG4gICAgICBcclxuXHJcbiAgICAgICBcclxuXHJcbiAgICAgICAgaWYgKHRoaXMuTGFuZyA9PSBcImhlXCIpIHtcclxuICAgICAgICAgICAgdGhpcy5LZW5kb1JUTENTUyA9IFwiay1ydGxcIjtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuS2VuZG9SVExDU1MgPSBcIlwiO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuR2V0TGFuZ1Jlcyh0aGlzLkZvcm10eXBlLCB0aGlzLkxhbmcpLnN1YnNjcmliZShyZXNwb25zZT0+IHtcclxuICAgICAgICAgICAvL2RlYnVnZ2VyOyBcclxuICAgICAgICAgICByZXNwb25zZSA9IGpRdWVyeS5wYXJzZUpTT04ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgIGlmIChyZXNwb25zZS5Jc0Vycm9yID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5FcnJNc2csXHJcbiAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6IHRoaXMuQ2hhbmdlRGlhbG9nLFxyXG4gICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgIG9rOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vbGFiZWw6ICdPaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgIH1cclxuICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgdGhpcy5SRVMgPSByZXNwb25zZS5EYXRhO1xyXG4gICAgICAgICAgIH1cclxuICAgICAgIH0sIGVycm9yPT4ge1xyXG4gICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbGxDb21wbGV0ZWRcIilcclxuICAgICAgIH0pO1xyXG4gICAgICAgXHJcbiAgICAgICAgXHJcbiAgICAgICAgXHJcbiAgICAgICAgXHJcbiAgICAgICAgXHJcbiAgICAgICAgLy9UcmVlIEdyb3VwXHJcbiAgICAgICAgXHJcblxyXG4gICAgICAgdGhpcy5fYW1heFNlcnZpY2UuR2V0R2VuZXJhbEdyb3VwVHJlZSgpLnN1YnNjcmliZShcclxuXHJcbiAgICAgICAgICAgKGRhdGEpID0+IHtcclxuICAgICAgICAgICAgICAgdmFyIHJlcyA9IGpRdWVyeS5wYXJzZUpTT04oZGF0YSk7XHJcblxyXG4gICAgICAgICAgICAgICBqUXVlcnkoXCIjZ3JvdXBUcmVlXCIpLmtlbmRvVHJlZVZpZXcoe1xyXG4gICAgICAgICAgICAgICAgICAgbG9hZE9uRGVtYW5kOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgY2hlY2tib3hlczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgIC8vY2hlY2tDaGlsZHJlbjogdHJ1ZVxyXG4gICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgIGNoZWNrOiBmdW5jdGlvbiAoZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZXhwYW5kUm9vdCA9IGUubm9kZTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5leHBhbmQoalF1ZXJ5KHRoaXMuZXhwYW5kUm9vdCkuZmluZChcIi5rLWl0ZW1cIikuYWRkQmFjaygpKTtcclxuICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICBkYXRhU291cmNlOiByZXMuRGF0YS5rZW5kb1RyZWVcclxuICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgIHZhciBkYXRhU291cmNlID0gbnVsbDtcclxuICAgICAgICAgICAgICAgalF1ZXJ5KFwiI2dyaWRcIikua2VuZG9HcmlkKHtcclxuICAgICAgICAgICAgICAgICAgIGRhdGFTb3VyY2U6IGRhdGFTb3VyY2UsXHJcbiAgICAgICAgICAgICAgICAgICBwYWdlYWJsZToge1xyXG4gICAgICAgICAgICAgICAgICAgICAgIHBhZ2VTaXplczogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICBidXR0b25Db3VudDogNSxcclxuICAgICAgICAgICAgICAgICAgICAgICBwYWdlU2l6ZTogMjBcclxuICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICBzb3J0YWJsZTogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgIHNjcm9sbGVibGU6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICBzZWxlY3RhYmxlOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgaGVpZ2h0OiA0MDAsXHJcbiAgICAgICAgICAgICAgICAgICBjb2x1bW5zOiBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBmaWVsZDogXCJDdXN0b21lcklkXCIsIHRpdGxlOiB0aGlzLlJFUy5HRU5FUkFMX0dST1VQLktFTkRPR1JJRF9DVVNUSUQgLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZTogXCI8YT4jOkN1c3RvbWVySWQjPC9hPlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICB7IGZpZWxkOiBcIkZpbGVBc1wiLCB0aXRsZTogdGhpcy5SRVMuR0VORVJBTF9HUk9VUC5LRU5ET0dSSURfRklMRUFTICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICAgIC8vIGRlYnVnZ2VyO1xyXG4gICAgICAgICAgICAgICB2YXIgamRhdGEgPSB0aGlzLl9yZXNvdXJjZVNlcnZpY2UuZ2V0Q29va2llKFwiR2VuZXJhbEdyb3VwX0NhY2hlXCIpO1xyXG4gICAgICAgICAgICAgICBpZiAoamRhdGEgIT0gdW5kZWZpbmVkICYmIGpkYXRhICE9IHVuZGVmaW5lZCAmJiBqZGF0YSAhPSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICBqZGF0YSA9IGpkYXRhLnN1YnN0cmluZygxLCBqZGF0YS5sZW5ndGgpO1xyXG4gICAgICAgICAgICAgICAgICAgdGhpcy5Hcm91cElkcyA9IGpkYXRhO1xyXG4gICAgICAgICAgICAgICAgICAgdmFyIGdycGlkcyA9IHRoaXMuR3JvdXBJZHMuc3BsaXQoJywnKTtcclxuICAgICAgICAgICAgICAgICAgIHZhciBiaW5kZ3JwcyA9IFwiXCI7XHJcbiAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGdycGlkcy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgIGJpbmRncnBzICs9IGdycGlkc1tpXSArIFwiO1wiO1xyXG4gICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgS2VuZG9fdXRpbGl0eS5jaGVja2luZ05vZGVJZHMoalF1ZXJ5KFwiI2dyb3VwVHJlZVwiKS5kYXRhKFwia2VuZG9UcmVlVmlld1wiKS5kYXRhU291cmNlLnZpZXcoKSwgYmluZGdycHMuc3Vic3RyaW5nKDAsIGJpbmRncnBzLmxlbmd0aCAtIDEpKTtcclxuICAgICAgICAgICAgICAgICAgIHRoaXMuR2V0Q3VzdERhdGEoKTtcclxuICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICB9LFxyXG4gICAgICAgICAgIChlcnIpID0+IHtcclxuXHJcbiAgICAgICAgICAgfSxcclxuICAgICAgICAgICAoKSA9PiB7XHJcblxyXG4gICAgICAgICAgIH1cclxuXHJcbiAgICAgICApO1xyXG4gICAgICAgXHJcbiAgICAgICBcclxuXHJcbiAgICB9XHJcbn1cclxuIl19
