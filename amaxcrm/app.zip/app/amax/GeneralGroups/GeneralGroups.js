System.register(['angular2/common', "angular2/router", "angular2/core", "../../services/AmaxCrmSyinc", "../../services/ResourceService", "../../services/AmaxService", "../../services/GeneralGroupsService", "../../amaxUtil"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var common_1, router_1, core_1, AmaxCrmSyinc_1, ResourceService_1, AmaxService_1, GeneralGroupsService_1, amaxUtil_1;
    var AmaxGeneralGroups;
    return {
        setters:[
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (AmaxCrmSyinc_1_1) {
                AmaxCrmSyinc_1 = AmaxCrmSyinc_1_1;
            },
            function (ResourceService_1_1) {
                ResourceService_1 = ResourceService_1_1;
            },
            function (AmaxService_1_1) {
                AmaxService_1 = AmaxService_1_1;
            },
            function (GeneralGroupsService_1_1) {
                GeneralGroupsService_1 = GeneralGroupsService_1_1;
            },
            function (amaxUtil_1_1) {
                amaxUtil_1 = amaxUtil_1_1;
            }],
        execute: function() {
            AmaxGeneralGroups = (function () {
                function AmaxGeneralGroups(_resourceService, _routeParams, _amaxService, _GeneralGroupsService) {
                    this._resourceService = _resourceService;
                    this._routeParams = _routeParams;
                    this._amaxService = _amaxService;
                    this._GeneralGroupsService = _GeneralGroupsService;
                    this.modelInput = {};
                    this.custSearchData = [];
                    this.RES = {};
                    this.Formtype = "GENERAL_GROUP";
                    this.Lang = "";
                    this.ShowMoreText = "More";
                    this.ShowLoader = false;
                    this.ShowMsg = false;
                    this.GroupText = "Show Groups";
                    this.Msg = "";
                    this.MsgClass = "text-primary";
                    this.Isbtndisable = "";
                    this.GroupIds = "";
                    this.KendoRTLCSS = "";
                    this._Groups = [];
                    this.ChangeDialog = "";
                    this.CHANGEDIR = "";
                    this.modelInput.CustomerAddresses = [];
                    this.modelInput.CustomerPhones = [];
                    this.modelInput.CustomerEmails = [];
                    this.modelInput.CustomerGroups = [];
                    this.modelInput.employeeid = "";
                    this.modelInput.CustomerType = "";
                    this.modelInput.CameFromCustomer = "";
                    this.modelInput.Safixid = "";
                    this.modelInput.Gender = "0";
                    this.RES.GENERAL_GROUP = {};
                    this.Formtype = "GENERAL_GROUP";
                    this.GroupIds = "";
                    this.baseUrl = _resourceService.AppUrl;
                }
                AmaxGeneralGroups.prototype.SetdefaultPage = function () {
                    this.modelInput = {};
                    this.Formtype = "GENERAL_GROUP";
                    this.GroupIds = "";
                    this.ShowMsg = false;
                    this.Msg = "";
                };
                AmaxGeneralGroups.prototype.GetCustData = function () {
                    var _this = this;
                    this.GroupIds = "";
                    var _CheckedGroups = [];
                    // debugger;
                    amaxUtil_1.Kendo_utility.checkedNodeIds(jQuery("#groupTree").data("kendoTreeView").dataSource.view(), _CheckedGroups);
                    for (var i = 0; i < _CheckedGroups.length; i++) {
                        this.GroupIds = this.GroupIds + _CheckedGroups[i] + ",";
                    }
                    //alert(this.GroupIds);
                    if (this.GroupIds.length > 0) {
                        this.GroupIds = this.GroupIds.substring(0, this.GroupIds.length - 1);
                        /////////////////Creating Cache///////////////////
                        var EmpId = localStorage.getItem("employeeid");
                        var OrgId = localStorage.getItem(EmpId + "_OrgId");
                        this._resourceService.setCookie(EmpId + "_" + OrgId + "_GeneralGroup_Cache", this.GroupIds, 10);
                    }
                    this._GeneralGroupsService.GetCompleteCustDet(this.GroupIds).subscribe(function (response) {
                        //debugger;
                        _this.Isbtndisable = "disabled";
                        _this.ShowLoader = true;
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.modelInput = response.Data;
                            var burl = _this.baseUrl;
                            jQuery.each(_this.modelInput, function () {
                                this.BUrl = burl + "Customer/Add/";
                            });
                            var dataSource = _this.modelInput;
                            jQuery("#grid").kendoGrid({
                                dataSource: dataSource,
                                pageable: {
                                    pageSizes: true,
                                    buttonCount: 5,
                                    pageSize: 20
                                },
                                sortable: true,
                                scrolleble: true,
                                selectable: true,
                                height: 400,
                                columns: [
                                    {
                                        field: "CustomerId", title: _this.RES.GENERAL_GROUP.KENDOGRID_CUSTID,
                                        //template: '<a href="#=CustomerId#">#:CustomerId#</a>' http://c.amax.co.il/#/Customer/Add/
                                        template: function (dataItem) {
                                            return "<a href='" + kendo.htmlEncode(dataItem.BUrl) + kendo.htmlEncode(dataItem.CustomerId) + "'>" + kendo.htmlEncode(dataItem.CustomerId) + "</a>";
                                        }
                                    },
                                    { field: "FileAs", title: _this.RES.GENERAL_GROUP.KENDOGRID_FILEAS }
                                ],
                            });
                        }
                        _this.Isbtndisable = "";
                        _this.ShowLoader = false;
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                };
                AmaxGeneralGroups.prototype.ngOnInit = function () {
                    var _this = this;
                    this.Lang = localStorage.getItem("lang");
                    this.SetdefaultPage();
                    if (this.Lang == "he") {
                        this.KendoRTLCSS = "k-rtl";
                    }
                    else {
                        this.KendoRTLCSS = "";
                    }
                    this._resourceService.GetLangRes(this.Formtype, this.Lang).subscribe(function (response) {
                        //debugger; 
                        response = jQuery.parseJSON(response);
                        if (response.IsError == true) {
                            bootbox.alert({
                                message: response.ErrMsg,
                                className: _this.ChangeDialog,
                                buttons: {
                                    ok: {
                                        //label: 'Ok',
                                        className: _this.CHANGEDIR
                                    }
                                }
                            });
                        }
                        else {
                            _this.RES = response.Data;
                        }
                    }, function (error) {
                        console.log(error);
                    }, function () {
                        console.log("CallCompleted");
                    });
                    //Tree Group
                    this._amaxService.GetGeneralGroupTree().subscribe(function (data) {
                        var res = jQuery.parseJSON(data);
                        jQuery("#groupTree").kendoTreeView({
                            loadOnDemand: true,
                            checkboxes: {},
                            check: function (e) {
                                this.expandRoot = e.node;
                                this.expand(jQuery(this.expandRoot).find(".k-item").addBack());
                            },
                            dataSource: res.Data.kendoTree
                        });
                        var dataSource = null;
                        jQuery("#grid").kendoGrid({
                            dataSource: dataSource,
                            pageable: {
                                pageSizes: true,
                                buttonCount: 5,
                                pageSize: 20
                            },
                            sortable: true,
                            scrolleble: true,
                            selectable: true,
                            height: 400,
                            columns: [
                                {
                                    field: "CustomerId", title: _this.RES.GENERAL_GROUP.KENDOGRID_CUSTID,
                                    template: "<a>#:CustomerId#</a>"
                                },
                                { field: "FileAs", title: _this.RES.GENERAL_GROUP.KENDOGRID_FILEAS }
                            ],
                        });
                        // debugger;
                        var EmpId = localStorage.getItem("employeeid");
                        var OrgId = localStorage.getItem(EmpId + "_OrgId");
                        var jdata = _this._resourceService.getCookie(EmpId + "_" + OrgId + "_GeneralGroup_Cache");
                        if (jdata != undefined && jdata != undefined && jdata != "") {
                            jdata = jdata.substring(1, jdata.length);
                            _this.GroupIds = jdata;
                            var grpids = _this.GroupIds.split(',');
                            var bindgrps = "";
                            for (var i = 0; i < grpids.length; i++) {
                                bindgrps += grpids[i] + ";";
                            }
                            amaxUtil_1.Kendo_utility.checkingNodeIds(jQuery("#groupTree").data("kendoTreeView").dataSource.view(), bindgrps.substring(0, bindgrps.length - 1));
                            _this.GetCustData();
                        }
                    }, function (err) {
                    }, function () {
                    });
                };
                AmaxGeneralGroups = __decorate([
                    core_1.Component({
                        templateUrl: './app/amax/GeneralGroups/templates/GeneralGroups.html',
                        directives: [common_1.NgSwitch, common_1.NgSwitchWhen, common_1.NgSwitchDefault],
                        providers: [AmaxService_1.AmaxService, AmaxCrmSyinc_1.AmaxCrmSyinc, ResourceService_1.ResourceService, GeneralGroupsService_1.GeneralGroupsService]
                    }), 
                    __metadata('design:paramtypes', [ResourceService_1.ResourceService, router_1.RouteParams, AmaxService_1.AmaxService, GeneralGroupsService_1.GeneralGroupsService])
                ], AmaxGeneralGroups);
                return AmaxGeneralGroups;
            }());
            exports_1("AmaxGeneralGroups", AmaxGeneralGroups);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFtYXgvR2VuZXJhbEdyb3Vwcy9HZW5lcmFsR3JvdXBzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1lBZ0JBO2dCQXNCSSwyQkFBb0IsZ0JBQWlDLEVBQVUsWUFBeUIsRUFBVSxZQUF5QixFQUFVLHFCQUEyQztvQkFBNUoscUJBQWdCLEdBQWhCLGdCQUFnQixDQUFpQjtvQkFBVSxpQkFBWSxHQUFaLFlBQVksQ0FBYTtvQkFBVSxpQkFBWSxHQUFaLFlBQVksQ0FBYTtvQkFBVSwwQkFBcUIsR0FBckIscUJBQXFCLENBQXNCO29CQXJCaEwsZUFBVSxHQUFHLEVBQUUsQ0FBQztvQkFDaEIsbUJBQWMsR0FBVyxFQUFFLENBQUM7b0JBQzVCLFFBQUcsR0FBVyxFQUFFLENBQUM7b0JBQ2pCLGFBQVEsR0FBVSxlQUFlLENBQUM7b0JBQ2xDLFNBQUksR0FBUyxFQUFFLENBQUM7b0JBQ2hCLGlCQUFZLEdBQVcsTUFBTSxDQUFDO29CQUU5QixlQUFVLEdBQVksS0FBSyxDQUFDO29CQUM1QixZQUFPLEdBQVksS0FBSyxDQUFDO29CQUN6QixjQUFTLEdBQVMsYUFBYSxDQUFDO29CQUNoQyxRQUFHLEdBQVcsRUFBRSxDQUFDO29CQUNqQixhQUFRLEdBQVcsY0FBYyxDQUFDO29CQUNsQyxpQkFBWSxHQUFXLEVBQUUsQ0FBQztvQkFDMUIsYUFBUSxHQUFXLEVBQUUsQ0FBQztvQkFFdEIsZ0JBQVcsR0FBVyxFQUFFLENBQUM7b0JBQ3pCLFlBQU8sR0FBRyxFQUFFLENBQUM7b0JBQ2IsaUJBQVksR0FBVyxFQUFFLENBQUM7b0JBQzFCLGNBQVMsR0FBVyxFQUFFLENBQUM7b0JBS25CLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLEdBQUcsRUFBRSxDQUFDO29CQUN2QyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxFQUFFLENBQUM7b0JBQ3BDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLEVBQUUsQ0FBQztvQkFDcEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDO29CQUVwQyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBRyxFQUFFLENBQUM7b0JBQ2hDLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxHQUFHLEVBQUUsQ0FBQztvQkFDbEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsR0FBRyxFQUFFLENBQUM7b0JBQ3RDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztvQkFDN0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsR0FBRyxDQUFDO29CQUM3QixJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsR0FBRyxFQUFFLENBQUM7b0JBQzVCLElBQUksQ0FBQyxRQUFRLEdBQUcsZUFBZSxDQUFDO29CQUNoQyxJQUFJLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQztvQkFDbkIsSUFBSSxDQUFDLE9BQU8sR0FBRyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUM7Z0JBSzNDLENBQUM7Z0JBS0QsMENBQWMsR0FBZDtvQkFJSSxJQUFJLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztvQkFFckIsSUFBSSxDQUFDLFFBQVEsR0FBRyxlQUFlLENBQUM7b0JBQ2hDLElBQUksQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDO29CQUtuQixJQUFJLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQztvQkFDckIsSUFBSSxDQUFDLEdBQUcsR0FBRyxFQUFFLENBQUM7Z0JBQ2xCLENBQUM7Z0JBSUQsdUNBQVcsR0FBWDtvQkFBQSxpQkE4RUM7b0JBNUVHLElBQUksQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDO29CQUNuQixJQUFJLGNBQWMsR0FBRyxFQUFFLENBQUM7b0JBRXpCLFlBQVk7b0JBQ1gsd0JBQWEsQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLEVBQUUsY0FBYyxDQUFDLENBQUM7b0JBQzNHLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsY0FBYyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDO3dCQUM3QyxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxRQUFRLEdBQUcsY0FBYyxDQUFDLENBQUMsQ0FBQyxHQUFDLEdBQUcsQ0FBQztvQkFDMUQsQ0FBQztvQkFHRCx1QkFBdUI7b0JBQ3ZCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQzNCLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDO3dCQUNyRSxrREFBa0Q7d0JBQ2xELElBQUksS0FBSyxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUM7d0JBQy9DLElBQUksS0FBSyxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsS0FBSyxHQUFHLFFBQVEsQ0FBQyxDQUFDO3dCQUNuRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxHQUFHLEdBQUcsS0FBSyxHQUFDLHFCQUFxQixFQUFFLElBQUksQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUM7b0JBQ2xHLENBQUM7b0JBQ0QsSUFBSSxDQUFDLHFCQUFxQixDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUMzRSxXQUFXO3dCQUNYLEtBQUksQ0FBQyxZQUFZLEdBQUcsVUFBVSxDQUFDO3dCQUMvQixLQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQzt3QkFDdkIsUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQ3RDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQztnQ0FDVixPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07Z0NBQ3hCLFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWTtnQ0FDNUIsT0FBTyxFQUFFO29DQUNMLEVBQUUsRUFBRTt3Q0FDQSxjQUFjO3dDQUNkLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUztxQ0FDNUI7aUNBQ0o7NkJBQ0osQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLENBQUM7NEJBQ0YsS0FBSSxDQUFDLFVBQVUsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDOzRCQUNoQyxJQUFJLElBQUksR0FBRyxLQUFJLENBQUMsT0FBTyxDQUFDOzRCQUN4QixNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUksQ0FBQyxVQUFVLEVBQUU7Z0NBQ3pCLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxHQUFDLGVBQWUsQ0FBQzs0QkFDckMsQ0FBQyxDQUFDLENBQUM7NEJBRUgsSUFBSSxVQUFVLEdBQUcsS0FBSSxDQUFDLFVBQVUsQ0FBQzs0QkFDakMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQztnQ0FDdEIsVUFBVSxFQUFFLFVBQVU7Z0NBQ3RCLFFBQVEsRUFBRTtvQ0FDTixTQUFTLEVBQUUsSUFBSTtvQ0FDZixXQUFXLEVBQUUsQ0FBQztvQ0FDZCxRQUFRLEVBQUUsRUFBRTtpQ0FDZjtnQ0FDRCxRQUFRLEVBQUUsSUFBSTtnQ0FDZCxVQUFVLEVBQUUsSUFBSTtnQ0FDaEIsVUFBVSxFQUFFLElBQUk7Z0NBQ2hCLE1BQU0sRUFBRSxHQUFHO2dDQUVYLE9BQU8sRUFBRTtvQ0FDTDt3Q0FDSSxLQUFLLEVBQUUsWUFBWSxFQUFFLEtBQUssRUFBRSxLQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0I7d0NBQ25FLDJGQUEyRjt3Q0FDM0YsUUFBUSxFQUFFLFVBQVUsUUFBUTs0Q0FDeEIsTUFBTSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRSxLQUFLLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsR0FBRyxJQUFJLEdBQUcsS0FBSyxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLEdBQUcsTUFBTSxDQUFDO3dDQUN4SixDQUFDO3FDQUNKO29DQUNELEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRSxLQUFLLEVBQUUsS0FBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsZ0JBQWdCLEVBQUU7aUNBRXRFOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELEtBQUksQ0FBQyxZQUFZLEdBQUcsRUFBRSxDQUFDO3dCQUN2QixLQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztvQkFDNUIsQ0FBQyxFQUFFLFVBQUEsS0FBSzt3QkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2QixDQUFDLEVBQUU7d0JBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtvQkFDaEMsQ0FBQyxDQUFDLENBQUM7Z0JBRVAsQ0FBQztnQkFDRCxvQ0FBUSxHQUFSO29CQUFBLGlCQXFIQztvQkEvR0csSUFBSSxDQUFDLElBQUksR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUN6QyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7b0JBS3RCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQzt3QkFDcEIsSUFBSSxDQUFDLFdBQVcsR0FBRyxPQUFPLENBQUM7b0JBQy9CLENBQUM7b0JBQ0QsSUFBSSxDQUFDLENBQUM7d0JBQ0YsSUFBSSxDQUFDLFdBQVcsR0FBRyxFQUFFLENBQUM7b0JBQzFCLENBQUM7b0JBRUYsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUN6RSxZQUFZO3dCQUNaLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUN0QyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0NBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO2dDQUN4QixTQUFTLEVBQUUsS0FBSSxDQUFDLFlBQVk7Z0NBQzVCLE9BQU8sRUFBRTtvQ0FDTCxFQUFFLEVBQUU7d0NBQ0EsY0FBYzt3Q0FDZCxTQUFTLEVBQUUsS0FBSSxDQUFDLFNBQVM7cUNBQzVCO2lDQUNKOzZCQUNKLENBQUMsQ0FBQzt3QkFDUCxDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEtBQUksQ0FBQyxHQUFHLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQzt3QkFDN0IsQ0FBQztvQkFDTCxDQUFDLEVBQUUsVUFBQSxLQUFLO3dCQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZCLENBQUMsRUFBRTt3QkFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO29CQUNoQyxDQUFDLENBQUMsQ0FBQztvQkFNRixZQUFZO29CQUdiLElBQUksQ0FBQyxZQUFZLENBQUMsbUJBQW1CLEVBQUUsQ0FBQyxTQUFTLENBRTdDLFVBQUMsSUFBSTt3QkFDRCxJQUFJLEdBQUcsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUVqQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsYUFBYSxDQUFDOzRCQUMvQixZQUFZLEVBQUUsSUFBSTs0QkFDbEIsVUFBVSxFQUFFLEVBRVg7NEJBQ0QsS0FBSyxFQUFFLFVBQVUsQ0FBQztnQ0FDZCxJQUFJLENBQUMsVUFBVSxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0NBRXpCLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQzs0QkFDbkUsQ0FBQzs0QkFDRCxVQUFVLEVBQUUsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTO3lCQUNqQyxDQUFDLENBQUM7d0JBQ0gsSUFBSSxVQUFVLEdBQUcsSUFBSSxDQUFDO3dCQUN0QixNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDOzRCQUN0QixVQUFVLEVBQUUsVUFBVTs0QkFDdEIsUUFBUSxFQUFFO2dDQUNOLFNBQVMsRUFBRSxJQUFJO2dDQUNmLFdBQVcsRUFBRSxDQUFDO2dDQUNkLFFBQVEsRUFBRSxFQUFFOzZCQUNmOzRCQUNELFFBQVEsRUFBRSxJQUFJOzRCQUNkLFVBQVUsRUFBRSxJQUFJOzRCQUNoQixVQUFVLEVBQUUsSUFBSTs0QkFDaEIsTUFBTSxFQUFFLEdBQUc7NEJBQ1gsT0FBTyxFQUFFO2dDQUNMO29DQUNJLEtBQUssRUFBRSxZQUFZLEVBQUUsS0FBSyxFQUFFLEtBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLGdCQUFnQjtvQ0FDbkUsUUFBUSxFQUFFLHNCQUFzQjtpQ0FDbkM7Z0NBQ0QsRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLEtBQUssRUFBRSxLQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsRUFBRzs2QkFFdkU7eUJBQ0osQ0FBQyxDQUFDO3dCQUVKLFlBQVk7d0JBQ1gsSUFBSSxLQUFLLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQzt3QkFDL0MsSUFBSSxLQUFLLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEdBQUcsUUFBUSxDQUFDLENBQUM7d0JBQ25ELElBQUksS0FBSyxHQUFHLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLEdBQUcsR0FBRyxLQUFLLEdBQUMscUJBQXFCLENBQUMsQ0FBQzt3QkFDdkYsRUFBRSxDQUFDLENBQUMsS0FBSyxJQUFJLFNBQVMsSUFBSSxLQUFLLElBQUksU0FBUyxJQUFJLEtBQUssSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDOzRCQUMxRCxLQUFLLEdBQUcsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDOzRCQUN6QyxLQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQzs0QkFDdEIsSUFBSSxNQUFNLEdBQUcsS0FBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7NEJBQ3RDLElBQUksUUFBUSxHQUFHLEVBQUUsQ0FBQzs0QkFDbEIsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUM7Z0NBQ3JDLFFBQVEsSUFBSSxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDOzRCQUNoQyxDQUFDOzRCQUNELHdCQUFhLENBQUMsZUFBZSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxFQUFFLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQzs0QkFDeEksS0FBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO3dCQUN2QixDQUFDO29CQUVMLENBQUMsRUFDRCxVQUFDLEdBQUc7b0JBRUosQ0FBQyxFQUNEO29CQUVBLENBQUMsQ0FFSixDQUFDO2dCQUlMLENBQUM7Z0JBM1FMO29CQUFDLGdCQUFTLENBQUM7d0JBRVAsV0FBVyxFQUFFLHVEQUF1RDt3QkFDcEUsVUFBVSxFQUFFLENBQUMsaUJBQVEsRUFBRSxxQkFBWSxFQUFFLHdCQUFlLENBQUM7d0JBQ3JELFNBQVMsRUFBRSxDQUFDLHlCQUFXLEVBQUUsMkJBQVksRUFBRSxpQ0FBZSxFQUFFLDJDQUFvQixDQUFDO3FCQUNoRixDQUFDOztxQ0FBQTtnQkF1UUYsd0JBQUM7WUFBRCxDQXRRQSxBQXNRQyxJQUFBO1lBdFFELGlEQXNRQyxDQUFBIiwiZmlsZSI6ImFtYXgvR2VuZXJhbEdyb3Vwcy9HZW5lcmFsR3JvdXBzLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtOZ1N3aXRjaCwgTmdTd2l0Y2hXaGVuLCBOZ1N3aXRjaERlZmF1bHQsIENPUkVfRElSRUNUSVZFUywgRk9STV9ESVJFQ1RJVkVTfSBmcm9tICdhbmd1bGFyMi9jb21tb24nXHJcbmltcG9ydCB7Um91dGVQYXJhbXN9IGZyb20gXCJhbmd1bGFyMi9yb3V0ZXJcIjtcclxuaW1wb3J0IHtDb21wb25lbnQsIE91dHB1dCwgSW5wdXQsIEV2ZW50RW1pdHRlciwgT25Jbml0fSBmcm9tIFwiYW5ndWxhcjIvY29yZVwiO1xyXG5pbXBvcnQge0FtYXhDcm1TeWluY30gZnJvbSBcIi4uLy4uL3NlcnZpY2VzL0FtYXhDcm1TeWluY1wiO1xyXG5pbXBvcnQge1Jlc291cmNlU2VydmljZX0gZnJvbSBcIi4uLy4uL3NlcnZpY2VzL1Jlc291cmNlU2VydmljZVwiO1xyXG5pbXBvcnQge0FtYXhTZXJ2aWNlfSBmcm9tIFwiLi4vLi4vc2VydmljZXMvQW1heFNlcnZpY2VcIjtcclxuaW1wb3J0IHtHZW5lcmFsR3JvdXBzU2VydmljZX0gZnJvbSBcIi4uLy4uL3NlcnZpY2VzL0dlbmVyYWxHcm91cHNTZXJ2aWNlXCI7XHJcbmltcG9ydCB7IGpzb25RIH0gZnJvbSAnLi4vLi4vanNvblEnO1xyXG5pbXBvcnQge0dyb3VwRmlsdGVyUGlwZSwgR3JvdXBQYXJlbkZpbHRlclBpcGUsIEtlbmRvX3V0aWxpdHl9IGZyb20gXCIuLi8uLi9hbWF4VXRpbFwiO1xyXG5kZWNsYXJlIHZhciBqUXVlcnk7XHJcbkBDb21wb25lbnQoe1xyXG5cclxuICAgIHRlbXBsYXRlVXJsOiAnLi9hcHAvYW1heC9HZW5lcmFsR3JvdXBzL3RlbXBsYXRlcy9HZW5lcmFsR3JvdXBzLmh0bWwnLFxyXG4gICAgZGlyZWN0aXZlczogW05nU3dpdGNoLCBOZ1N3aXRjaFdoZW4sIE5nU3dpdGNoRGVmYXVsdF0sXHJcbiAgICBwcm92aWRlcnM6IFtBbWF4U2VydmljZSwgQW1heENybVN5aW5jLCBSZXNvdXJjZVNlcnZpY2UsIEdlbmVyYWxHcm91cHNTZXJ2aWNlXVxyXG59KVxyXG5leHBvcnQgY2xhc3MgQW1heEdlbmVyYWxHcm91cHMgaW1wbGVtZW50cyBPbkluaXQge1xyXG4gICAgbW9kZWxJbnB1dCA9IHt9O1xyXG4gICAgY3VzdFNlYXJjaERhdGE6IE9iamVjdCA9IFtdO1xyXG4gICAgUkVTOiBPYmplY3QgPSB7fTtcclxuICAgIEZvcm10eXBlOiBzdHJpbmcgPVwiR0VORVJBTF9HUk9VUFwiO1xyXG4gICAgTGFuZzogc3RyaW5nPVwiXCI7XHJcbiAgICBTaG93TW9yZVRleHQ6IHN0cmluZyA9IFwiTW9yZVwiO1xyXG5cclxuICAgIFNob3dMb2FkZXI6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIFNob3dNc2c6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIEdyb3VwVGV4dDogc3RyaW5nPVwiU2hvdyBHcm91cHNcIjtcclxuICAgIE1zZzogc3RyaW5nID0gXCJcIjtcclxuICAgIE1zZ0NsYXNzOiBzdHJpbmcgPSBcInRleHQtcHJpbWFyeVwiO1xyXG4gICAgSXNidG5kaXNhYmxlOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgR3JvdXBJZHM6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBiYXNlVXJsOiBzdHJpbmc7XHJcbiAgICBLZW5kb1JUTENTUzogc3RyaW5nID0gXCJcIjtcclxuICAgIF9Hcm91cHMgPSBbXTtcclxuICAgIENoYW5nZURpYWxvZzogc3RyaW5nID0gXCJcIjtcclxuICAgIENIQU5HRURJUjogc3RyaW5nID0gXCJcIjtcclxuICAgIFxyXG5cclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgX3Jlc291cmNlU2VydmljZTogUmVzb3VyY2VTZXJ2aWNlLCBwcml2YXRlIF9yb3V0ZVBhcmFtczogUm91dGVQYXJhbXMsIHByaXZhdGUgX2FtYXhTZXJ2aWNlOiBBbWF4U2VydmljZSwgcHJpdmF0ZSBfR2VuZXJhbEdyb3Vwc1NlcnZpY2U6IEdlbmVyYWxHcm91cHNTZXJ2aWNlKSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyQWRkcmVzc2VzID0gW107XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyUGhvbmVzID0gW107XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyRW1haWxzID0gW107XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkN1c3RvbWVyR3JvdXBzID0gW107XHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LmVtcGxveWVlaWQgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DdXN0b21lclR5cGUgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMubW9kZWxJbnB1dC5DYW1lRnJvbUN1c3RvbWVyID0gXCJcIjtcclxuICAgICAgICB0aGlzLm1vZGVsSW5wdXQuU2FmaXhpZCA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0LkdlbmRlciA9IFwiMFwiO1xyXG4gICAgICAgIHRoaXMuUkVTLkdFTkVSQUxfR1JPVVAgPSB7fTtcclxuICAgICAgICB0aGlzLkZvcm10eXBlID0gXCJHRU5FUkFMX0dST1VQXCI7XHJcbiAgICAgICAgdGhpcy5Hcm91cElkcyA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5iYXNlVXJsID0gX3Jlc291cmNlU2VydmljZS5BcHBVcmw7XHJcbiAgICAgXHJcblxyXG4gICAgICAgXHJcbiAgICAgICAgXHJcbiAgICB9XHJcbiAgICBwcml2YXRlIF9jYWNoZWRSZXN1bHQ6IGFueTtcclxuICAgIHByaXZhdGUgX3ByZXZpb3VzQ29udGV4dDogYW55O1xyXG4gICAgXHJcbiAgIFxyXG4gICAgU2V0ZGVmYXVsdFBhZ2UoKTogb2JzZXJ2YXZibGUge1xyXG4gICAgICAgXHJcbiAgICAgICAgXHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5tb2RlbElucHV0ID0ge307XHJcblxyXG4gICAgICAgIHRoaXMuRm9ybXR5cGUgPSBcIkdFTkVSQUxfR1JPVVBcIjtcclxuICAgICAgICB0aGlzLkdyb3VwSWRzID0gXCJcIjtcclxuXHJcbiAgICAgICBcclxuXHJcbiAgICAgICBcclxuICAgICAgICB0aGlzLlNob3dNc2cgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLk1zZyA9IFwiXCI7XHJcbiAgICB9XHJcbiAgICBcclxuICAgXHJcblxyXG4gICAgR2V0Q3VzdERhdGEoKTogdm9pZCB7XHJcbiAgICAgICBcclxuICAgICAgICB0aGlzLkdyb3VwSWRzID0gXCJcIjtcclxuICAgICAgICB2YXIgX0NoZWNrZWRHcm91cHMgPSBbXTtcclxuICAgICAgICBcclxuICAgICAgIC8vIGRlYnVnZ2VyO1xyXG4gICAgICAgIEtlbmRvX3V0aWxpdHkuY2hlY2tlZE5vZGVJZHMoalF1ZXJ5KFwiI2dyb3VwVHJlZVwiKS5kYXRhKFwia2VuZG9UcmVlVmlld1wiKS5kYXRhU291cmNlLnZpZXcoKSwgX0NoZWNrZWRHcm91cHMpO1xyXG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgX0NoZWNrZWRHcm91cHMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgdGhpcy5Hcm91cElkcyA9IHRoaXMuR3JvdXBJZHMrICBfQ2hlY2tlZEdyb3Vwc1tpXStcIixcIjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIFxyXG4gICAgICAgIC8vYWxlcnQodGhpcy5Hcm91cElkcyk7XHJcbiAgICAgICAgaWYgKHRoaXMuR3JvdXBJZHMubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICB0aGlzLkdyb3VwSWRzID0gdGhpcy5Hcm91cElkcy5zdWJzdHJpbmcoMCwgdGhpcy5Hcm91cElkcy5sZW5ndGggLSAxKTtcclxuICAgICAgICAgICAgLy8vLy8vLy8vLy8vLy8vLy9DcmVhdGluZyBDYWNoZS8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgICAgICAgICAgdmFyIEVtcElkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJlbXBsb3llZWlkXCIpO1xyXG4gICAgICAgICAgICB2YXIgT3JnSWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShFbXBJZCArIFwiX09yZ0lkXCIpO1xyXG4gICAgICAgICAgICB0aGlzLl9yZXNvdXJjZVNlcnZpY2Uuc2V0Q29va2llKEVtcElkICsgXCJfXCIgKyBPcmdJZCtcIl9HZW5lcmFsR3JvdXBfQ2FjaGVcIiwgdGhpcy5Hcm91cElkcywgMTApO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLl9HZW5lcmFsR3JvdXBzU2VydmljZS5HZXRDb21wbGV0ZUN1c3REZXQodGhpcy5Hcm91cElkcykuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgICAvL2RlYnVnZ2VyO1xyXG4gICAgICAgICAgICB0aGlzLklzYnRuZGlzYWJsZSA9IFwiZGlzYWJsZWRcIjtcclxuICAgICAgICAgICAgdGhpcy5TaG93TG9hZGVyID0gdHJ1ZTtcclxuICAgICAgICAgICAgcmVzcG9uc2UgPSBqUXVlcnkucGFyc2VKU09OKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgYm9vdGJveC5hbGVydCh7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuRXJyTXNnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DSEFOR0VESVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbElucHV0ID0gcmVzcG9uc2UuRGF0YTtcclxuICAgICAgICAgICAgICAgIHZhciBidXJsID0gdGhpcy5iYXNlVXJsO1xyXG4gICAgICAgICAgICAgICAgalF1ZXJ5LmVhY2godGhpcy5tb2RlbElucHV0LCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5CVXJsID0gYnVybCtcIkN1c3RvbWVyL0FkZC9cIjtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgICAgIHZhciBkYXRhU291cmNlID0gdGhpcy5tb2RlbElucHV0O1xyXG4gICAgICAgICAgICAgICAgalF1ZXJ5KFwiI2dyaWRcIikua2VuZG9HcmlkKHtcclxuICAgICAgICAgICAgICAgICAgICBkYXRhU291cmNlOiBkYXRhU291cmNlLFxyXG4gICAgICAgICAgICAgICAgICAgIHBhZ2VhYmxlOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhZ2VTaXplczogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uQ291bnQ6IDUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhZ2VTaXplOiAyMFxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgc29ydGFibGU6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgc2Nyb2xsZWJsZTogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICBzZWxlY3RhYmxlOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgIGhlaWdodDogNDAwLFxyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIGNvbHVtbnM6IFtcclxuICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZmllbGQ6IFwiQ3VzdG9tZXJJZFwiLCB0aXRsZTogdGhpcy5SRVMuR0VORVJBTF9HUk9VUC5LRU5ET0dSSURfQ1VTVElELFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy90ZW1wbGF0ZTogJzxhIGhyZWY9XCIjPUN1c3RvbWVySWQjXCI+IzpDdXN0b21lcklkIzwvYT4nIGh0dHA6Ly9jLmFtYXguY28uaWwvIy9DdXN0b21lci9BZGQvXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZTogZnVuY3Rpb24gKGRhdGFJdGVtKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFwiPGEgaHJlZj0nXCIgKyBrZW5kby5odG1sRW5jb2RlKGRhdGFJdGVtLkJVcmwpKyBrZW5kby5odG1sRW5jb2RlKGRhdGFJdGVtLkN1c3RvbWVySWQpICsgXCInPlwiICsga2VuZG8uaHRtbEVuY29kZShkYXRhSXRlbS5DdXN0b21lcklkKSArIFwiPC9hPlwiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7IGZpZWxkOiBcIkZpbGVBc1wiLCB0aXRsZTogdGhpcy5SRVMuR0VORVJBTF9HUk9VUC5LRU5ET0dSSURfRklMRUFTIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRoaXMuSXNidG5kaXNhYmxlID0gXCJcIjtcclxuICAgICAgICAgICAgdGhpcy5TaG93TG9hZGVyID0gZmFsc2U7XHJcbiAgICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIFxyXG4gICAgfVxyXG4gICAgbmdPbkluaXQoKSB7XHJcbiAgICAgICBcclxuICAgICAgICBcclxuXHJcbiAgICAgICAgXHJcblxyXG4gICAgICAgIHRoaXMuTGFuZyA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwibGFuZ1wiKTtcclxuICAgICAgICB0aGlzLlNldGRlZmF1bHRQYWdlKCk7XHJcbiAgICAgIFxyXG5cclxuICAgICAgIFxyXG5cclxuICAgICAgICBpZiAodGhpcy5MYW5nID09IFwiaGVcIikge1xyXG4gICAgICAgICAgICB0aGlzLktlbmRvUlRMQ1NTID0gXCJrLXJ0bFwiO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5LZW5kb1JUTENTUyA9IFwiXCI7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgIHRoaXMuX3Jlc291cmNlU2VydmljZS5HZXRMYW5nUmVzKHRoaXMuRm9ybXR5cGUsIHRoaXMuTGFuZykuc3Vic2NyaWJlKHJlc3BvbnNlPT4ge1xyXG4gICAgICAgICAgIC8vZGVidWdnZXI7IFxyXG4gICAgICAgICAgIHJlc3BvbnNlID0galF1ZXJ5LnBhcnNlSlNPTihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgaWYgKHJlc3BvbnNlLklzRXJyb3IgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICBib290Ym94LmFsZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLkVyck1zZyxcclxuICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5DaGFuZ2VEaWFsb2csXHJcbiAgICAgICAgICAgICAgICAgICBidXR0b25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgb2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9sYWJlbDogJ09rJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLkNIQU5HRURJUlxyXG4gICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICB0aGlzLlJFUyA9IHJlc3BvbnNlLkRhdGE7XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgfSwgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2FsbENvbXBsZXRlZFwiKVxyXG4gICAgICAgfSk7XHJcbiAgICAgICBcclxuICAgICAgICBcclxuICAgICAgICBcclxuICAgICAgICBcclxuICAgICAgICBcclxuICAgICAgICAvL1RyZWUgR3JvdXBcclxuICAgICAgICBcclxuXHJcbiAgICAgICB0aGlzLl9hbWF4U2VydmljZS5HZXRHZW5lcmFsR3JvdXBUcmVlKCkuc3Vic2NyaWJlKFxyXG5cclxuICAgICAgICAgICAoZGF0YSkgPT4ge1xyXG4gICAgICAgICAgICAgICB2YXIgcmVzID0galF1ZXJ5LnBhcnNlSlNPTihkYXRhKTtcclxuXHJcbiAgICAgICAgICAgICAgIGpRdWVyeShcIiNncm91cFRyZWVcIikua2VuZG9UcmVlVmlldyh7XHJcbiAgICAgICAgICAgICAgICAgICBsb2FkT25EZW1hbmQ6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICBjaGVja2JveGVzOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgLy9jaGVja0NoaWxkcmVuOiB0cnVlXHJcbiAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgY2hlY2s6IGZ1bmN0aW9uIChlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5leHBhbmRSb290ID0gZS5ub2RlO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmV4cGFuZChqUXVlcnkodGhpcy5leHBhbmRSb290KS5maW5kKFwiLmstaXRlbVwiKS5hZGRCYWNrKCkpO1xyXG4gICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgIGRhdGFTb3VyY2U6IHJlcy5EYXRhLmtlbmRvVHJlZVxyXG4gICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgdmFyIGRhdGFTb3VyY2UgPSBudWxsO1xyXG4gICAgICAgICAgICAgICBqUXVlcnkoXCIjZ3JpZFwiKS5rZW5kb0dyaWQoe1xyXG4gICAgICAgICAgICAgICAgICAgZGF0YVNvdXJjZTogZGF0YVNvdXJjZSxcclxuICAgICAgICAgICAgICAgICAgIHBhZ2VhYmxlOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgcGFnZVNpemVzOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbkNvdW50OiA1LFxyXG4gICAgICAgICAgICAgICAgICAgICAgIHBhZ2VTaXplOiAyMFxyXG4gICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgIHNvcnRhYmxlOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgc2Nyb2xsZWJsZTogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgIHNlbGVjdGFibGU6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IDQwMCxcclxuICAgICAgICAgICAgICAgICAgIGNvbHVtbnM6IFtcclxuICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpZWxkOiBcIkN1c3RvbWVySWRcIiwgdGl0bGU6IHRoaXMuUkVTLkdFTkVSQUxfR1JPVVAuS0VORE9HUklEX0NVU1RJRCAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlOiBcIjxhPiM6Q3VzdG9tZXJJZCM8L2E+XCJcclxuICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgIHsgZmllbGQ6IFwiRmlsZUFzXCIsIHRpdGxlOiB0aGlzLlJFUy5HRU5FUkFMX0dST1VQLktFTkRPR1JJRF9GSUxFQVMgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgICAgLy8gZGVidWdnZXI7XHJcbiAgICAgICAgICAgICAgIHZhciBFbXBJZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiZW1wbG95ZWVpZFwiKTtcclxuICAgICAgICAgICAgICAgdmFyIE9yZ0lkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oRW1wSWQgKyBcIl9PcmdJZFwiKTtcclxuICAgICAgICAgICAgICAgdmFyIGpkYXRhID0gdGhpcy5fcmVzb3VyY2VTZXJ2aWNlLmdldENvb2tpZShFbXBJZCArIFwiX1wiICsgT3JnSWQrXCJfR2VuZXJhbEdyb3VwX0NhY2hlXCIpO1xyXG4gICAgICAgICAgICAgICBpZiAoamRhdGEgIT0gdW5kZWZpbmVkICYmIGpkYXRhICE9IHVuZGVmaW5lZCAmJiBqZGF0YSAhPSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICBqZGF0YSA9IGpkYXRhLnN1YnN0cmluZygxLCBqZGF0YS5sZW5ndGgpO1xyXG4gICAgICAgICAgICAgICAgICAgdGhpcy5Hcm91cElkcyA9IGpkYXRhO1xyXG4gICAgICAgICAgICAgICAgICAgdmFyIGdycGlkcyA9IHRoaXMuR3JvdXBJZHMuc3BsaXQoJywnKTtcclxuICAgICAgICAgICAgICAgICAgIHZhciBiaW5kZ3JwcyA9IFwiXCI7XHJcbiAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGdycGlkcy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgIGJpbmRncnBzICs9IGdycGlkc1tpXSArIFwiO1wiO1xyXG4gICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgS2VuZG9fdXRpbGl0eS5jaGVja2luZ05vZGVJZHMoalF1ZXJ5KFwiI2dyb3VwVHJlZVwiKS5kYXRhKFwia2VuZG9UcmVlVmlld1wiKS5kYXRhU291cmNlLnZpZXcoKSwgYmluZGdycHMuc3Vic3RyaW5nKDAsIGJpbmRncnBzLmxlbmd0aCAtIDEpKTtcclxuICAgICAgICAgICAgICAgICAgIHRoaXMuR2V0Q3VzdERhdGEoKTtcclxuICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICB9LFxyXG4gICAgICAgICAgIChlcnIpID0+IHtcclxuXHJcbiAgICAgICAgICAgfSxcclxuICAgICAgICAgICAoKSA9PiB7XHJcblxyXG4gICAgICAgICAgIH1cclxuXHJcbiAgICAgICApO1xyXG4gICAgICAgXHJcbiAgICAgICBcclxuXHJcbiAgICB9XHJcbn1cclxuIl19
