System.register(["angular2/core", "../../amaxUtil"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, amaxUtil_1;
    var defaultComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (amaxUtil_1_1) {
                amaxUtil_1 = amaxUtil_1_1;
            }],
        execute: function() {
            defaultComponent = (function () {
                function defaultComponent() {
                    //document.addEventListener('myCustomeEvt',this.onMyCustomeEvt);
                    amaxUtil_1.onEvent.listenEvent('myCustomeEvt', this.onMyCustomeEvt);
                }
                defaultComponent.prototype.onMyCustomeEvt = function (a) {
                    console.log(arguments.length);
                    console.log(a.evtData);
                };
                defaultComponent.prototype.ngOnDestroy = function () {
                    //document.removeEventListener('myCustomeEvt',this.onMyCustomeEvt);
                    amaxUtil_1.onEvent.removeEvtListner('myCustomeEvt', this.onMyCustomeEvt);
                };
                defaultComponent = __decorate([
                    core_1.Component({
                        template: "\n        <h1>Default Component</h1>\n        \n    "
                    }), 
                    __metadata('design:paramtypes', [])
                ], defaultComponent);
                return defaultComponent;
            }());
            exports_1("defaultComponent", defaultComponent);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFtYXgvcXVpY2thY2Nlc3MvZGVmYXVsdC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztZQVFBO2dCQUNJO29CQUNJLGdFQUFnRTtvQkFDaEUsa0JBQU8sQ0FBQyxXQUFXLENBQUMsY0FBYyxFQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQztnQkFDNUQsQ0FBQztnQkFDRCx5Q0FBYyxHQUFkLFVBQWUsQ0FBSztvQkFDaEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQzlCLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUMzQixDQUFDO2dCQUVELHNDQUFXLEdBQVg7b0JBQ0ksbUVBQW1FO29CQUNuRSxrQkFBTyxDQUFDLGdCQUFnQixDQUFDLGNBQWMsRUFBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7Z0JBQ2pFLENBQUM7Z0JBbkJMO29CQUFDLGdCQUFTLENBQUM7d0JBQ1AsUUFBUSxFQUFDLHNEQUdSO3FCQUNKLENBQUM7O29DQUFBO2dCQWVGLHVCQUFDO1lBQUQsQ0FkQSxBQWNDLElBQUE7WUFkRCwrQ0FjQyxDQUFBIiwiZmlsZSI6ImFtYXgvcXVpY2thY2Nlc3MvZGVmYXVsdC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7Q29tcG9uZW50LCBPbkRlc3Ryb3l9IGZyb20gXCJhbmd1bGFyMi9jb3JlXCI7XHJcbmltcG9ydCB7b25FdmVudH0gZnJvbSBcIi4uLy4uL2FtYXhVdGlsXCI7XHJcbkBDb21wb25lbnQoe1xyXG4gICAgdGVtcGxhdGU6YFxyXG4gICAgICAgIDxoMT5EZWZhdWx0IENvbXBvbmVudDwvaDE+XHJcbiAgICAgICAgXHJcbiAgICBgXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBkZWZhdWx0Q29tcG9uZW50IGltcGxlbWVudHMgT25EZXN0cm95e1xyXG4gICAgY29uc3RydWN0b3IoKXtcclxuICAgICAgICAvL2RvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ215Q3VzdG9tZUV2dCcsdGhpcy5vbk15Q3VzdG9tZUV2dCk7XHJcbiAgICAgICAgb25FdmVudC5saXN0ZW5FdmVudCgnbXlDdXN0b21lRXZ0Jyx0aGlzLm9uTXlDdXN0b21lRXZ0KTtcclxuICAgIH1cclxuICAgIG9uTXlDdXN0b21lRXZ0KGE6YW55KXtcclxuICAgICAgICBjb25zb2xlLmxvZyhhcmd1bWVudHMubGVuZ3RoKTtcclxuICAgICAgICBjb25zb2xlLmxvZyhhLmV2dERhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25EZXN0cm95KCkge1xyXG4gICAgICAgIC8vZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcignbXlDdXN0b21lRXZ0Jyx0aGlzLm9uTXlDdXN0b21lRXZ0KTtcclxuICAgICAgICBvbkV2ZW50LnJlbW92ZUV2dExpc3RuZXIoJ215Q3VzdG9tZUV2dCcsdGhpcy5vbk15Q3VzdG9tZUV2dCk7XHJcbiAgICB9XHJcbn0iXX0=
