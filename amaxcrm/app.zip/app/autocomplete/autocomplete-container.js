System.register(['angular2/core', 'angular2/common', './autocomplete.component', './options.class', './position'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, common_1, autocomplete_component_1, options_class_1, position_1;
    var AutocompleteContainer;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (autocomplete_component_1_1) {
                autocomplete_component_1 = autocomplete_component_1_1;
            },
            function (options_class_1_1) {
                options_class_1 = options_class_1_1;
            },
            function (position_1_1) {
                position_1 = position_1_1;
            }],
        execute: function() {
            AutocompleteContainer = (function () {
                function AutocompleteContainer(element, options) {
                    this.element = element;
                    this._matches = [];
                    Object.assign(this, options);
                }
                Object.defineProperty(AutocompleteContainer.prototype, "matches", {
                    get: function () {
                        return this._matches;
                    },
                    set: function (value) {
                        this._matches = value;
                        if (this._matches.length > 0) {
                            this._active = this._matches[0];
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(AutocompleteContainer.prototype, "field", {
                    set: function (value) {
                        this._field = value;
                    },
                    enumerable: true,
                    configurable: true
                });
                AutocompleteContainer.prototype.position = function (hostEl) {
                    this.display = 'block';
                    this.top = '0px';
                    this.left = '0px';
                    var p = position_1.positionService
                        .positionElements(hostEl.nativeElement, this.element.nativeElement.children[0], this.placement, false);
                    this.top = p.top + 'px';
                    this.left = p.left + 'px';
                };
                AutocompleteContainer.prototype.selectActiveMatch = function () {
                    this.selectMatch(this._active);
                };
                AutocompleteContainer.prototype.prevActiveMatch = function () {
                    var index = this.matches.indexOf(this._active);
                    this._active = this.matches[index - 1 < 0 ? this.matches.length - 1 : index - 1];
                };
                AutocompleteContainer.prototype.nextActiveMatch = function () {
                    var index = this.matches.indexOf(this._active);
                    this._active = this.matches[index + 1 > this.matches.length - 1 ? 0 : index + 1];
                };
                AutocompleteContainer.prototype.selectActive = function (value) {
                    this._active = value;
                };
                AutocompleteContainer.prototype.isActive = function (value) {
                    return this._active === value;
                };
                AutocompleteContainer.prototype.selectMatch = function (value, e) {
                    if (e === void 0) { e = null; }
                    if (e) {
                        e.stopPropagation();
                        e.preventDefault();
                    }
                    this.parent.changeModel(value);
                    this.parent.autocompleteOnSelect.emit({
                        item: value
                    });
                    return false;
                };
                AutocompleteContainer.prototype.hightlight = function (item, query) {
                    var itemStr = (typeof item === 'object' && this._field ? item[this._field] : item).toString();
                    //let itemStrHelper:string = (this.parent.autocompleteLatinize ? AutocompleteUtils.latinize(itemStr) : itemStr).toLowerCase();
                    var itemStrHelper = itemStr.toLowerCase();
                    var startIdx;
                    var tokenLen;
                    if (typeof query === 'object') {
                        var queryLen = query.length;
                        for (var i = 0; i < queryLen; i += 1) {
                            startIdx = itemStrHelper.indexOf(query[i]);
                            tokenLen = query[i].length;
                            if (startIdx >= 0 && tokenLen > 0) {
                                itemStr = itemStr.substring(0, startIdx) + '<strong>' + itemStr.substring(startIdx, startIdx + tokenLen) + '</strong>' + itemStr.substring(startIdx + tokenLen);
                                itemStrHelper = itemStrHelper.substring(0, startIdx) + '        ' + ' '.repeat(tokenLen) + '         ' + itemStrHelper.substring(startIdx + tokenLen);
                            }
                        }
                    }
                    else if (query) {
                        startIdx = itemStrHelper.indexOf(query);
                        tokenLen = query.length;
                        if (startIdx >= 0 && tokenLen > 0) {
                            itemStr = itemStr.substring(0, startIdx) + '<strong>' + itemStr.substring(startIdx, startIdx + tokenLen) + '</strong>' + itemStr.substring(startIdx + tokenLen);
                        }
                    }
                    return itemStr;
                };
                AutocompleteContainer = __decorate([
                    core_1.Component({
                        selector: 'autocomplete-container',
                        directives: [common_1.CORE_DIRECTIVES],
                        template: "\n                  <ul class=\"dropdown-menu\"\n                      [ngStyle]=\"{top: top, left: left, display: display}\"\n                      style=\"display: block;\">\n                    <li *ngFor=\"#match of matches\"\n                        [class.active]=\"isActive(match)\"\n                        (mouseenter)=\"selectActive(match)\">\n                        <a href=\"#\" (click)=\"selectMatch(match, $event)\" tabindex=\"-1\" [innerHtml]=\"hightlight(match, query)\"></a>\n                    </li>\n                  </ul>\n              ",
                        encapsulation: core_1.ViewEncapsulation.None,
                        providers: [core_1.ElementRef, autocomplete_component_1.Autocomplete]
                    }), 
                    __metadata('design:paramtypes', [core_1.ElementRef, options_class_1.AutocompleteOptions])
                ], AutocompleteContainer);
                return AutocompleteContainer;
            }());
            exports_1("AutocompleteContainer", AutocompleteContainer);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImF1dG9jb21wbGV0ZS9hdXRvY29tcGxldGUtY29udGFpbmVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1lBNEJBO2dCQVdJLCtCQUFtQixPQUFrQixFQUFFLE9BQTJCO29CQUEvQyxZQUFPLEdBQVAsT0FBTyxDQUFXO29CQVI3QixhQUFRLEdBQWMsRUFBRSxDQUFDO29CQVM3QixNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsQ0FBQztnQkFDakMsQ0FBQztnQkFFRCxzQkFBVywwQ0FBTzt5QkFBbEI7d0JBQ0ksTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUM7b0JBQ3pCLENBQUM7eUJBRUQsVUFBbUIsS0FBbUI7d0JBQ2xDLElBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO3dCQUV0QixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDOzRCQUMzQixJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ3BDLENBQUM7b0JBQ0wsQ0FBQzs7O21CQVJBO2dCQVVELHNCQUFXLHdDQUFLO3lCQUFoQixVQUFpQixLQUFZO3dCQUN6QixJQUFJLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztvQkFDeEIsQ0FBQzs7O21CQUFBO2dCQUVNLHdDQUFRLEdBQWYsVUFBZ0IsTUFBaUI7b0JBQzdCLElBQUksQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDO29CQUN2QixJQUFJLENBQUMsR0FBRyxHQUFHLEtBQUssQ0FBQztvQkFDakIsSUFBSSxDQUFDLElBQUksR0FBRyxLQUFLLENBQUM7b0JBQ2xCLElBQUksQ0FBQyxHQUFHLDBCQUFlO3lCQUNsQixnQkFBZ0IsQ0FBQyxNQUFNLENBQUMsYUFBYSxFQUNsQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQ3RDLElBQUksQ0FBQyxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUM7b0JBQy9CLElBQUksQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUM7b0JBQ3hCLElBQUksQ0FBQyxJQUFJLEdBQUcsQ0FBQyxDQUFDLElBQUksR0FBRyxJQUFJLENBQUM7Z0JBQzlCLENBQUM7Z0JBRU0saURBQWlCLEdBQXhCO29CQUNJLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUNuQyxDQUFDO2dCQUVNLCtDQUFlLEdBQXRCO29CQUNJLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztvQkFDL0MsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxHQUFHLENBQUMsR0FBRyxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUM7Z0JBQ3JGLENBQUM7Z0JBRU0sK0NBQWUsR0FBdEI7b0JBQ0ksSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO29CQUMvQyxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQztnQkFDckYsQ0FBQztnQkFFTyw0Q0FBWSxHQUFwQixVQUFxQixLQUFTO29CQUMxQixJQUFJLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQztnQkFDekIsQ0FBQztnQkFFTyx3Q0FBUSxHQUFoQixVQUFpQixLQUFTO29CQUN0QixNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sS0FBSyxLQUFLLENBQUM7Z0JBQ2xDLENBQUM7Z0JBRU8sMkNBQVcsR0FBbkIsVUFBb0IsS0FBUyxFQUFFLENBQWM7b0JBQWQsaUJBQWMsR0FBZCxRQUFjO29CQUN6QyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUNKLENBQUMsQ0FBQyxlQUFlLEVBQUUsQ0FBQzt3QkFDcEIsQ0FBQyxDQUFDLGNBQWMsRUFBRSxDQUFDO29CQUN2QixDQUFDO29CQUVELElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUMvQixJQUFJLENBQUMsTUFBTSxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQzt3QkFDbEMsSUFBSSxFQUFFLEtBQUs7cUJBQ2QsQ0FBQyxDQUFDO29CQUNILE1BQU0sQ0FBQyxLQUFLLENBQUM7Z0JBQ2pCLENBQUM7Z0JBRU8sMENBQVUsR0FBbEIsVUFBbUIsSUFBUSxFQUFFLEtBQVk7b0JBQ3JDLElBQUksT0FBTyxHQUFVLENBQUMsT0FBTyxJQUFJLEtBQUssUUFBUSxJQUFJLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQztvQkFDckcsOEhBQThIO29CQUM5SCxJQUFJLGFBQWEsR0FBUyxPQUFPLENBQUMsV0FBVyxFQUFFLENBQUM7b0JBQ2hELElBQUksUUFBZSxDQUFDO29CQUNwQixJQUFJLFFBQWUsQ0FBQztvQkFFcEIsRUFBRSxDQUFDLENBQUMsT0FBTyxLQUFLLEtBQUssUUFBUSxDQUFDLENBQUMsQ0FBQzt3QkFDNUIsSUFBSSxRQUFRLEdBQVUsS0FBSyxDQUFDLE1BQU0sQ0FBQzt3QkFDbkMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxRQUFRLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDOzRCQUNuQyxRQUFRLEdBQUcsYUFBYSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs0QkFDM0MsUUFBUSxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7NEJBQzNCLEVBQUUsQ0FBQyxDQUFDLFFBQVEsSUFBSSxDQUFDLElBQUksUUFBUSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQ2hDLE9BQU8sR0FBRyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxRQUFRLENBQUMsR0FBRyxVQUFVLEdBQUcsT0FBTyxDQUFDLFNBQVMsQ0FBQyxRQUFRLEVBQUUsUUFBUSxHQUFHLFFBQVEsQ0FBQyxHQUFHLFdBQVcsR0FBRyxPQUFPLENBQUMsU0FBUyxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUMsQ0FBQztnQ0FDaEssYUFBYSxHQUFHLGFBQWEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxHQUFHLFVBQVUsR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxHQUFHLFdBQVcsR0FBRyxhQUFhLENBQUMsU0FBUyxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUMsQ0FBQzs0QkFDMUosQ0FBQzt3QkFDTCxDQUFDO29CQUNMLENBQUM7b0JBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7d0JBQ2YsUUFBUSxHQUFHLGFBQWEsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7d0JBQ3hDLFFBQVEsR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDO3dCQUN4QixFQUFFLENBQUMsQ0FBQyxRQUFRLElBQUksQ0FBQyxJQUFJLFFBQVEsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDOzRCQUNoQyxPQUFPLEdBQUcsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsUUFBUSxDQUFDLEdBQUcsVUFBVSxHQUFHLE9BQU8sQ0FBQyxTQUFTLENBQUMsUUFBUSxFQUFFLFFBQVEsR0FBRyxRQUFRLENBQUMsR0FBRyxXQUFXLEdBQUcsT0FBTyxDQUFDLFNBQVMsQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFDLENBQUM7d0JBQ3BLLENBQUM7b0JBQ0wsQ0FBQztvQkFFRCxNQUFNLENBQUMsT0FBTyxDQUFDO2dCQUNuQixDQUFDO2dCQTFITDtvQkFBQyxnQkFBUyxDQUFDO3dCQUNQLFFBQVEsRUFBRSx3QkFBd0I7d0JBQ2xDLFVBQVUsRUFBRSxDQUFDLHdCQUFlLENBQUM7d0JBQzdCLFFBQVEsRUFBRSxrakJBVUM7d0JBRVgsYUFBYSxFQUFFLHdCQUFpQixDQUFDLElBQUk7d0JBQ3JDLFNBQVMsRUFBRSxDQUFDLGlCQUFVLEVBQUUscUNBQVksQ0FBQztxQkFDeEMsQ0FBQzs7eUNBQUE7Z0JBMEdGLDRCQUFDO1lBQUQsQ0F6R0EsQUF5R0MsSUFBQTtZQXpHRCx5REF5R0MsQ0FBQSIsImZpbGUiOiJhdXRvY29tcGxldGUvYXV0b2NvbXBsZXRlLWNvbnRhaW5lci5qcyIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxyXG4gKiBib290c3RyYXBcclxuICovXHJcbmltcG9ydCB7Q29tcG9uZW50LCBFbGVtZW50UmVmLCBWaWV3RW5jYXBzdWxhdGlvbn0gZnJvbSAnYW5ndWxhcjIvY29yZSc7XHJcbmltcG9ydCB7Q09SRV9ESVJFQ1RJVkVTfSBmcm9tICdhbmd1bGFyMi9jb21tb24nO1xyXG5pbXBvcnQge0F1dG9jb21wbGV0ZX0gZnJvbSAnLi9hdXRvY29tcGxldGUuY29tcG9uZW50JztcclxuaW1wb3J0IHtBdXRvY29tcGxldGVPcHRpb25zfSBmcm9tICcuL29wdGlvbnMuY2xhc3MnO1xyXG5pbXBvcnQge3Bvc2l0aW9uU2VydmljZX0gZnJvbSAnLi9wb3NpdGlvbic7XHJcblxyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ2F1dG9jb21wbGV0ZS1jb250YWluZXInLFxyXG4gICAgZGlyZWN0aXZlczogW0NPUkVfRElSRUNUSVZFU10sXHJcbiAgICB0ZW1wbGF0ZTogYFxyXG4gICAgICAgICAgICAgICAgICA8dWwgY2xhc3M9XCJkcm9wZG93bi1tZW51XCJcclxuICAgICAgICAgICAgICAgICAgICAgIFtuZ1N0eWxlXT1cInt0b3A6IHRvcCwgbGVmdDogbGVmdCwgZGlzcGxheTogZGlzcGxheX1cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgc3R5bGU9XCJkaXNwbGF5OiBibG9jaztcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGkgKm5nRm9yPVwiI21hdGNoIG9mIG1hdGNoZXNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBbY2xhc3MuYWN0aXZlXT1cImlzQWN0aXZlKG1hdGNoKVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIChtb3VzZWVudGVyKT1cInNlbGVjdEFjdGl2ZShtYXRjaClcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGEgaHJlZj1cIiNcIiAoY2xpY2spPVwic2VsZWN0TWF0Y2gobWF0Y2gsICRldmVudClcIiB0YWJpbmRleD1cIi0xXCIgW2lubmVySHRtbF09XCJoaWdodGxpZ2h0KG1hdGNoLCBxdWVyeSlcIj48L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgICAgPC91bD5cclxuICAgICAgICAgICAgICBgLFxyXG5cclxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXHJcbiAgICBwcm92aWRlcnM6IFtFbGVtZW50UmVmLCBBdXRvY29tcGxldGVdXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBBdXRvY29tcGxldGVDb250YWluZXIge1xyXG4gICAgcHVibGljIHBhcmVudDpBdXRvY29tcGxldGU7XHJcbiAgICBwdWJsaWMgcXVlcnk6YW55O1xyXG4gICAgcHJpdmF0ZSBfbWF0Y2hlczpBcnJheTxhbnk+ID0gW107XHJcbiAgICBwcml2YXRlIF9maWVsZDpzdHJpbmc7XHJcbiAgICBwcml2YXRlIF9hY3RpdmU6YW55O1xyXG4gICAgcHJpdmF0ZSB0b3A6c3RyaW5nO1xyXG4gICAgcHJpdmF0ZSBsZWZ0OnN0cmluZztcclxuICAgIHByaXZhdGUgZGlzcGxheTpzdHJpbmc7XHJcbiAgICBwcml2YXRlIHBsYWNlbWVudDpzdHJpbmc7XHJcblxyXG4gICAgY29uc3RydWN0b3IocHVibGljIGVsZW1lbnQ6RWxlbWVudFJlZiwgb3B0aW9uczpBdXRvY29tcGxldGVPcHRpb25zKSB7XHJcbiAgICAgICAgT2JqZWN0LmFzc2lnbih0aGlzLCBvcHRpb25zKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2V0IG1hdGNoZXMoKTpBcnJheTxzdHJpbmc+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fbWF0Y2hlcztcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc2V0IG1hdGNoZXModmFsdWU6QXJyYXk8c3RyaW5nPikge1xyXG4gICAgICAgIHRoaXMuX21hdGNoZXMgPSB2YWx1ZTtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMuX21hdGNoZXMubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICB0aGlzLl9hY3RpdmUgPSB0aGlzLl9tYXRjaGVzWzBdO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc2V0IGZpZWxkKHZhbHVlOnN0cmluZykge1xyXG4gICAgICAgIHRoaXMuX2ZpZWxkID0gdmFsdWU7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHBvc2l0aW9uKGhvc3RFbDpFbGVtZW50UmVmKSB7XHJcbiAgICAgICAgdGhpcy5kaXNwbGF5ID0gJ2Jsb2NrJztcclxuICAgICAgICB0aGlzLnRvcCA9ICcwcHgnO1xyXG4gICAgICAgIHRoaXMubGVmdCA9ICcwcHgnO1xyXG4gICAgICAgIGxldCBwID0gcG9zaXRpb25TZXJ2aWNlXHJcbiAgICAgICAgICAgIC5wb3NpdGlvbkVsZW1lbnRzKGhvc3RFbC5uYXRpdmVFbGVtZW50LFxyXG4gICAgICAgICAgICAgICAgdGhpcy5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQuY2hpbGRyZW5bMF0sXHJcbiAgICAgICAgICAgICAgICB0aGlzLnBsYWNlbWVudCwgZmFsc2UpO1xyXG4gICAgICAgIHRoaXMudG9wID0gcC50b3AgKyAncHgnO1xyXG4gICAgICAgIHRoaXMubGVmdCA9IHAubGVmdCArICdweCc7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHNlbGVjdEFjdGl2ZU1hdGNoKCkge1xyXG4gICAgICAgIHRoaXMuc2VsZWN0TWF0Y2godGhpcy5fYWN0aXZlKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgcHJldkFjdGl2ZU1hdGNoKCkge1xyXG4gICAgICAgIGxldCBpbmRleCA9IHRoaXMubWF0Y2hlcy5pbmRleE9mKHRoaXMuX2FjdGl2ZSk7XHJcbiAgICAgICAgdGhpcy5fYWN0aXZlID0gdGhpcy5tYXRjaGVzW2luZGV4IC0gMSA8IDAgPyB0aGlzLm1hdGNoZXMubGVuZ3RoIC0gMSA6IGluZGV4IC0gMV07XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIG5leHRBY3RpdmVNYXRjaCgpIHtcclxuICAgICAgICBsZXQgaW5kZXggPSB0aGlzLm1hdGNoZXMuaW5kZXhPZih0aGlzLl9hY3RpdmUpO1xyXG4gICAgICAgIHRoaXMuX2FjdGl2ZSA9IHRoaXMubWF0Y2hlc1tpbmRleCArIDEgPiB0aGlzLm1hdGNoZXMubGVuZ3RoIC0gMSA/IDAgOiBpbmRleCArIDFdO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgc2VsZWN0QWN0aXZlKHZhbHVlOmFueSkge1xyXG4gICAgICAgIHRoaXMuX2FjdGl2ZSA9IHZhbHVlO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgaXNBY3RpdmUodmFsdWU6YW55KTpib29sZWFuIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fYWN0aXZlID09PSB2YWx1ZTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIHNlbGVjdE1hdGNoKHZhbHVlOmFueSwgZTpFdmVudCA9IG51bGwpIHtcclxuICAgICAgICBpZiAoZSkge1xyXG4gICAgICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xyXG4gICAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLnBhcmVudC5jaGFuZ2VNb2RlbCh2YWx1ZSk7XHJcbiAgICAgICAgdGhpcy5wYXJlbnQuYXV0b2NvbXBsZXRlT25TZWxlY3QuZW1pdCh7XHJcbiAgICAgICAgICAgIGl0ZW06IHZhbHVlXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgaGlnaHRsaWdodChpdGVtOmFueSwgcXVlcnk6c3RyaW5nKSB7XHJcbiAgICAgICAgbGV0IGl0ZW1TdHI6c3RyaW5nID0gKHR5cGVvZiBpdGVtID09PSAnb2JqZWN0JyAmJiB0aGlzLl9maWVsZCA/IGl0ZW1bdGhpcy5fZmllbGRdIDogaXRlbSkudG9TdHJpbmcoKTtcclxuICAgICAgICAvL2xldCBpdGVtU3RySGVscGVyOnN0cmluZyA9ICh0aGlzLnBhcmVudC5hdXRvY29tcGxldGVMYXRpbml6ZSA/IEF1dG9jb21wbGV0ZVV0aWxzLmxhdGluaXplKGl0ZW1TdHIpIDogaXRlbVN0cikudG9Mb3dlckNhc2UoKTtcclxuICAgICAgICBsZXQgaXRlbVN0ckhlbHBlcjpzdHJpbmcgPWl0ZW1TdHIudG9Mb3dlckNhc2UoKTtcclxuICAgICAgICBsZXQgc3RhcnRJZHg6bnVtYmVyO1xyXG4gICAgICAgIGxldCB0b2tlbkxlbjpudW1iZXI7XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgcXVlcnkgPT09ICdvYmplY3QnKSB7XHJcbiAgICAgICAgICAgIGxldCBxdWVyeUxlbjpudW1iZXIgPSBxdWVyeS5sZW5ndGg7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcXVlcnlMZW47IGkgKz0gMSkge1xyXG4gICAgICAgICAgICAgICAgc3RhcnRJZHggPSBpdGVtU3RySGVscGVyLmluZGV4T2YocXVlcnlbaV0pO1xyXG4gICAgICAgICAgICAgICAgdG9rZW5MZW4gPSBxdWVyeVtpXS5sZW5ndGg7XHJcbiAgICAgICAgICAgICAgICBpZiAoc3RhcnRJZHggPj0gMCAmJiB0b2tlbkxlbiA+IDApIHtcclxuICAgICAgICAgICAgICAgICAgICBpdGVtU3RyID0gaXRlbVN0ci5zdWJzdHJpbmcoMCwgc3RhcnRJZHgpICsgJzxzdHJvbmc+JyArIGl0ZW1TdHIuc3Vic3RyaW5nKHN0YXJ0SWR4LCBzdGFydElkeCArIHRva2VuTGVuKSArICc8L3N0cm9uZz4nICsgaXRlbVN0ci5zdWJzdHJpbmcoc3RhcnRJZHggKyB0b2tlbkxlbik7XHJcbiAgICAgICAgICAgICAgICAgICAgaXRlbVN0ckhlbHBlciA9IGl0ZW1TdHJIZWxwZXIuc3Vic3RyaW5nKDAsIHN0YXJ0SWR4KSArICcgICAgICAgICcgKyAnICcucmVwZWF0KHRva2VuTGVuKSArICcgICAgICAgICAnICsgaXRlbVN0ckhlbHBlci5zdWJzdHJpbmcoc3RhcnRJZHggKyB0b2tlbkxlbik7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2UgaWYgKHF1ZXJ5KSB7XHJcbiAgICAgICAgICAgIHN0YXJ0SWR4ID0gaXRlbVN0ckhlbHBlci5pbmRleE9mKHF1ZXJ5KTtcclxuICAgICAgICAgICAgdG9rZW5MZW4gPSBxdWVyeS5sZW5ndGg7XHJcbiAgICAgICAgICAgIGlmIChzdGFydElkeCA+PSAwICYmIHRva2VuTGVuID4gMCkge1xyXG4gICAgICAgICAgICAgICAgaXRlbVN0ciA9IGl0ZW1TdHIuc3Vic3RyaW5nKDAsIHN0YXJ0SWR4KSArICc8c3Ryb25nPicgKyBpdGVtU3RyLnN1YnN0cmluZyhzdGFydElkeCwgc3RhcnRJZHggKyB0b2tlbkxlbikgKyAnPC9zdHJvbmc+JyArIGl0ZW1TdHIuc3Vic3RyaW5nKHN0YXJ0SWR4ICsgdG9rZW5MZW4pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gaXRlbVN0cjtcclxuICAgIH1cclxufVxyXG4iXX0=
