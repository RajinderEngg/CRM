/**
 * Created by Tareq Boulakjar. from angulartypescript.com
 */
System.register(['angular2/core', 'angular2/common', './autocomplete-container', './autocomplete.component'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, common_1, autocomplete_container_1, autocomplete_component_1;
    var AUTOCOMPLETE_DIRECTIVES, Angular2Autocomplete;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (autocomplete_container_1_1) {
                autocomplete_container_1 = autocomplete_container_1_1;
            },
            function (autocomplete_component_1_1) {
                autocomplete_component_1 = autocomplete_component_1_1;
            }],
        execute: function() {
            exports_1("AUTOCOMPLETE_DIRECTIVES", AUTOCOMPLETE_DIRECTIVES = [autocomplete_component_1.Autocomplete, autocomplete_container_1.AutocompleteContainer]);
            /*Angular 2 Autocomplete Example*/
            Angular2Autocomplete = (function () {
                function Angular2Autocomplete() {
                    this.selectedCar = '';
                    this.asyncSelectedCar = '';
                    this.autocompleteLoading = false;
                    this.autocompleteNoResults = false;
                    this.carsExample1 = ['BMW', 'Audi', 'Mercedes', 'Porsche', 'Volkswagen', 'Opel', 'Maserati', 'Volkswagen', 'BMW Serie 1', 'BMW Serie 2'];
                    this.carsExample2 = [
                        { id: 1, name: 'BMW' },
                        { id: 2, name: 'Audi' },
                        { id: 3, name: 'Mercedes' },
                        { id: 4, name: 'Porsche' },
                        { id: 5, name: 'Volkswagen' },
                        { id: 6, name: 'Opel' },
                        { id: 7, name: 'Maserati' },
                        { id: 8, name: 'Volkswagen' },
                        { id: 9, name: 'BMW Serie 1' },
                        { id: 10, name: 'BMW Serie 2' },
                    ];
                }
                Angular2Autocomplete.prototype.getCurrentContext = function () {
                    return this;
                };
                Angular2Autocomplete.prototype.getAsyncData = function (context) {
                    if (this._previousContext === context) {
                        return this._cachedResult;
                    }
                    this._previousContext = context;
                    var f = function () {
                        var p = new Promise(function (resolve) {
                            setTimeout(function () {
                                var query = new RegExp(context.asyncSelectedCar, 'ig');
                                return resolve(context.carsExample1.filter(function (state) {
                                    return query.test(state);
                                }));
                            }, 500);
                        });
                        return p;
                    };
                    this._cachedResult = f;
                    return this._cachedResult;
                };
                Angular2Autocomplete.prototype.changeAutocompleteLoading = function (e) {
                    this.autocompleteLoading = e;
                };
                Angular2Autocomplete.prototype.changeAutocompleteNoResults = function (e) {
                    this.autocompleteNoResults = e;
                };
                Angular2Autocomplete.prototype.autocompleteOnSelect = function (e) {
                    console.log("Selected value: " + e.item);
                };
                Angular2Autocomplete = __decorate([
                    core_1.Component({
                        selector: 'my-app',
                        template: "\n                <div class='container-fluid'>\n                    <h3>Angular 2 Autocomplete Example</h3>\n                    <h4>The Selected Car: {{selectedCar}}</h4>\n                    <input [(ngModel)]=\"selectedCar\"\n                           [autocomplete]=\"carsExample2\"\n                           (autocompleteOnSelect)=\"autocompleteOnSelect($event)\"\n                           [autocompleteOptionField]=\"'name'\"\n                           class=\"form-control\">\n\n                    <h3>Asynchronous results</h3>\n                    <h4>Model: {{asyncSelectedCar}}</h4>\n                    <input [(ngModel)]=\"asyncSelectedCar\"\n                           [autocomplete]=\"getAsyncData(getCurrentContext())\"\n                           (autocompleteLoading)=\"changeAutocompleteLoading($event)\"\n                           (autocompleteNoResults)=\"changeAutocompleteNoResults($event)\"\n                           (autocompleteOnSelect)=\"autocompleteOnSelect($event)\"\n                           [autocompleteOptionsLimit]=\"7\"\n                           placeholder=\"Locations loaded with timeout\"\n                           class=\"form-control\">\n                    <div [hidden]=\"autocompleteLoading!==true\">\n                        <i class=\"glyphicon glyphicon-refresh ng-hide\" style=\"\"></i>\n                    </div>\n                    <div [hidden]=\"autocompleteNoResults!==true\" class=\"\" style=\"\">\n                        <i class=\"glyphicon glyphicon-remove\"></i> Empty Query !\n                    </div>\n                </div>\n               ",
                        directives: [AUTOCOMPLETE_DIRECTIVES, common_1.CORE_DIRECTIVES, common_1.FORM_DIRECTIVES],
                    }), 
                    __metadata('design:paramtypes', [])
                ], Angular2Autocomplete);
                return Angular2Autocomplete;
            }());
            exports_1("Angular2Autocomplete", Angular2Autocomplete);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImF1dG9jb21wbGV0ZS9hdXRvY29tcGxldGUtZXhhbXBsZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7R0FFRzs7Ozs7Ozs7Ozs7Ozs7UUFNVSx1QkFBdUI7Ozs7Ozs7Ozs7Ozs7Ozs7WUFBdkIscUNBQUEsdUJBQXVCLEdBQUcsQ0FBQyxxQ0FBWSxFQUFFLDhDQUFxQixDQUFDLENBQUEsQ0FBQztZQUc3RSxrQ0FBa0M7WUFrQ2xDO2dCQUFBO29CQUNZLGdCQUFXLEdBQVUsRUFBRSxDQUFDO29CQUN4QixxQkFBZ0IsR0FBVSxFQUFFLENBQUM7b0JBQzdCLHdCQUFtQixHQUFXLEtBQUssQ0FBQztvQkFDcEMsMEJBQXFCLEdBQVcsS0FBSyxDQUFDO29CQUN0QyxpQkFBWSxHQUFpQixDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUMsVUFBVSxFQUFDLFNBQVMsRUFBQyxZQUFZLEVBQUMsTUFBTSxFQUFDLFVBQVUsRUFBQyxZQUFZLEVBQUMsYUFBYSxFQUFDLGFBQWEsQ0FBQyxDQUFDO29CQUMxSSxpQkFBWSxHQUFjO3dCQUM5QixFQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBQzt3QkFDcEIsRUFBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUM7d0JBQ3JCLEVBQUMsRUFBRSxFQUFFLENBQUMsRUFBRSxJQUFJLEVBQUUsVUFBVSxFQUFDO3dCQUN6QixFQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBQzt3QkFDeEIsRUFBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFLElBQUksRUFBRSxZQUFZLEVBQUM7d0JBQzNCLEVBQUMsRUFBRSxFQUFFLENBQUMsRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFDO3dCQUNyQixFQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUUsSUFBSSxFQUFFLFVBQVUsRUFBQzt3QkFDekIsRUFBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFLElBQUksRUFBRSxZQUFZLEVBQUM7d0JBQzNCLEVBQUMsRUFBRSxFQUFFLENBQUMsRUFBRSxJQUFJLEVBQUUsYUFBYSxFQUFDO3dCQUM1QixFQUFDLEVBQUUsRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLGFBQWEsRUFBQztxQkFDaEMsQ0FBQztnQkEwQ04sQ0FBQztnQkF2Q1csZ0RBQWlCLEdBQXpCO29CQUNJLE1BQU0sQ0FBQyxJQUFJLENBQUM7Z0JBQ2hCLENBQUM7Z0JBS08sMkNBQVksR0FBcEIsVUFBcUIsT0FBVztvQkFDNUIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixLQUFLLE9BQU8sQ0FBQyxDQUFDLENBQUM7d0JBQ3BDLE1BQU0sQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDO29CQUM5QixDQUFDO29CQUVELElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxPQUFPLENBQUM7b0JBQ2hDLElBQUksQ0FBQyxHQUFZO3dCQUNiLElBQUksQ0FBQyxHQUFxQixJQUFJLE9BQU8sQ0FBQyxVQUFDLE9BQWdCOzRCQUNuRCxVQUFVLENBQUM7Z0NBQ1AsSUFBSSxLQUFLLEdBQUcsSUFBSSxNQUFNLENBQUMsT0FBTyxDQUFDLGdCQUFnQixFQUFFLElBQUksQ0FBQyxDQUFDO2dDQUN2RCxNQUFNLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLFVBQUMsS0FBUztvQ0FDakQsTUFBTSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7Z0NBQzdCLENBQUMsQ0FBQyxDQUFDLENBQUM7NEJBQ1IsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO3dCQUNaLENBQUMsQ0FBQyxDQUFDO3dCQUNILE1BQU0sQ0FBQyxDQUFDLENBQUM7b0JBQ2IsQ0FBQyxDQUFDO29CQUNGLElBQUksQ0FBQyxhQUFhLEdBQUcsQ0FBQyxDQUFDO29CQUN2QixNQUFNLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQztnQkFDOUIsQ0FBQztnQkFFTyx3REFBeUIsR0FBakMsVUFBa0MsQ0FBUztvQkFDdkMsSUFBSSxDQUFDLG1CQUFtQixHQUFHLENBQUMsQ0FBQztnQkFDakMsQ0FBQztnQkFFTywwREFBMkIsR0FBbkMsVUFBb0MsQ0FBUztvQkFDekMsSUFBSSxDQUFDLHFCQUFxQixHQUFHLENBQUMsQ0FBQztnQkFDbkMsQ0FBQztnQkFFTyxtREFBb0IsR0FBNUIsVUFBNkIsQ0FBSztvQkFDOUIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxxQkFBbUIsQ0FBQyxDQUFDLElBQU0sQ0FBQyxDQUFDO2dCQUM3QyxDQUFDO2dCQTNGTDtvQkFBQyxnQkFBUyxDQUFDO3dCQUNQLFFBQVEsRUFBRSxRQUFRO3dCQUVsQixRQUFRLEVBQUMsd2xEQTJCRzt3QkFDWixVQUFVLEVBQUUsQ0FBQyx1QkFBdUIsRUFBRSx3QkFBZSxFQUFFLHdCQUFlLENBQUM7cUJBQzFFLENBQUM7O3dDQUFBO2dCQTRERiwyQkFBQztZQUFELENBM0RBLEFBMkRDLElBQUE7WUEzREQsdURBMkRDLENBQUEiLCJmaWxlIjoiYXV0b2NvbXBsZXRlL2F1dG9jb21wbGV0ZS1leGFtcGxlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXHJcbiAqIENyZWF0ZWQgYnkgVGFyZXEgQm91bGFramFyLiBmcm9tIGFuZ3VsYXJ0eXBlc2NyaXB0LmNvbVxyXG4gKi9cclxuXHJcbmltcG9ydCB7Q29tcG9uZW50LCBFbGVtZW50UmVmLCBWaWV3RW5jYXBzdWxhdGlvbn0gZnJvbSAnYW5ndWxhcjIvY29yZSc7XHJcbmltcG9ydCB7Q09SRV9ESVJFQ1RJVkVTLCBGT1JNX0RJUkVDVElWRVN9IGZyb20gJ2FuZ3VsYXIyL2NvbW1vbic7XHJcbmltcG9ydCB7QXV0b2NvbXBsZXRlQ29udGFpbmVyfSBmcm9tICcuL2F1dG9jb21wbGV0ZS1jb250YWluZXInO1xyXG5pbXBvcnQge0F1dG9jb21wbGV0ZX0gZnJvbSAnLi9hdXRvY29tcGxldGUuY29tcG9uZW50JztcclxuZXhwb3J0IGNvbnN0IEFVVE9DT01QTEVURV9ESVJFQ1RJVkVTID0gW0F1dG9jb21wbGV0ZSwgQXV0b2NvbXBsZXRlQ29udGFpbmVyXTtcclxuXHJcblxyXG4vKkFuZ3VsYXIgMiBBdXRvY29tcGxldGUgRXhhbXBsZSovXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdteS1hcHAnLFxyXG5cclxuICAgIHRlbXBsYXRlOmBcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9J2NvbnRhaW5lci1mbHVpZCc+XHJcbiAgICAgICAgICAgICAgICAgICAgPGgzPkFuZ3VsYXIgMiBBdXRvY29tcGxldGUgRXhhbXBsZTwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgPGg0PlRoZSBTZWxlY3RlZCBDYXI6IHt7c2VsZWN0ZWRDYXJ9fTwvaDQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0IFsobmdNb2RlbCldPVwic2VsZWN0ZWRDYXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBbYXV0b2NvbXBsZXRlXT1cImNhcnNFeGFtcGxlMlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIChhdXRvY29tcGxldGVPblNlbGVjdCk9XCJhdXRvY29tcGxldGVPblNlbGVjdCgkZXZlbnQpXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgW2F1dG9jb21wbGV0ZU9wdGlvbkZpZWxkXT1cIiduYW1lJ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzPVwiZm9ybS1jb250cm9sXCI+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxoMz5Bc3luY2hyb25vdXMgcmVzdWx0czwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgPGg0Pk1vZGVsOiB7e2FzeW5jU2VsZWN0ZWRDYXJ9fTwvaDQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0IFsobmdNb2RlbCldPVwiYXN5bmNTZWxlY3RlZENhclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIFthdXRvY29tcGxldGVdPVwiZ2V0QXN5bmNEYXRhKGdldEN1cnJlbnRDb250ZXh0KCkpXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgKGF1dG9jb21wbGV0ZUxvYWRpbmcpPVwiY2hhbmdlQXV0b2NvbXBsZXRlTG9hZGluZygkZXZlbnQpXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgKGF1dG9jb21wbGV0ZU5vUmVzdWx0cyk9XCJjaGFuZ2VBdXRvY29tcGxldGVOb1Jlc3VsdHMoJGV2ZW50KVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIChhdXRvY29tcGxldGVPblNlbGVjdCk9XCJhdXRvY29tcGxldGVPblNlbGVjdCgkZXZlbnQpXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgW2F1dG9jb21wbGV0ZU9wdGlvbnNMaW1pdF09XCI3XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJMb2NhdGlvbnMgbG9hZGVkIHdpdGggdGltZW91dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzPVwiZm9ybS1jb250cm9sXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBbaGlkZGVuXT1cImF1dG9jb21wbGV0ZUxvYWRpbmchPT10cnVlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpIGNsYXNzPVwiZ2x5cGhpY29uIGdseXBoaWNvbi1yZWZyZXNoIG5nLWhpZGVcIiBzdHlsZT1cIlwiPjwvaT5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IFtoaWRkZW5dPVwiYXV0b2NvbXBsZXRlTm9SZXN1bHRzIT09dHJ1ZVwiIGNsYXNzPVwiXCIgc3R5bGU9XCJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGkgY2xhc3M9XCJnbHlwaGljb24gZ2x5cGhpY29uLXJlbW92ZVwiPjwvaT4gRW1wdHkgUXVlcnkgIVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgIGAsXHJcbiAgICBkaXJlY3RpdmVzOiBbQVVUT0NPTVBMRVRFX0RJUkVDVElWRVMsIENPUkVfRElSRUNUSVZFUywgRk9STV9ESVJFQ1RJVkVTXSxcclxufSlcclxuZXhwb3J0IGNsYXNzIEFuZ3VsYXIyQXV0b2NvbXBsZXRlIHtcclxuICAgIHByaXZhdGUgc2VsZWN0ZWRDYXI6c3RyaW5nID0gJyc7XHJcbiAgICBwcml2YXRlIGFzeW5jU2VsZWN0ZWRDYXI6c3RyaW5nID0gJyc7XHJcbiAgICBwcml2YXRlIGF1dG9jb21wbGV0ZUxvYWRpbmc6Ym9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHJpdmF0ZSBhdXRvY29tcGxldGVOb1Jlc3VsdHM6Ym9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHJpdmF0ZSBjYXJzRXhhbXBsZTE6QXJyYXk8c3RyaW5nPiA9IFsnQk1XJywgJ0F1ZGknLCdNZXJjZWRlcycsJ1BvcnNjaGUnLCdWb2xrc3dhZ2VuJywnT3BlbCcsJ01hc2VyYXRpJywnVm9sa3N3YWdlbicsJ0JNVyBTZXJpZSAxJywnQk1XIFNlcmllIDInXTtcclxuICAgIHByaXZhdGUgY2Fyc0V4YW1wbGUyOkFycmF5PGFueT4gPSBbXHJcbiAgICAgICAge2lkOiAxLCBuYW1lOiAnQk1XJ30sXHJcbiAgICAgICAge2lkOiAyLCBuYW1lOiAnQXVkaSd9LFxyXG4gICAgICAgIHtpZDogMywgbmFtZTogJ01lcmNlZGVzJ30sXHJcbiAgICAgICAge2lkOiA0LCBuYW1lOiAnUG9yc2NoZSd9LFxyXG4gICAgICAgIHtpZDogNSwgbmFtZTogJ1ZvbGtzd2FnZW4nfSxcclxuICAgICAgICB7aWQ6IDYsIG5hbWU6ICdPcGVsJ30sXHJcbiAgICAgICAge2lkOiA3LCBuYW1lOiAnTWFzZXJhdGknfSxcclxuICAgICAgICB7aWQ6IDgsIG5hbWU6ICdWb2xrc3dhZ2VuJ30sXHJcbiAgICAgICAge2lkOiA5LCBuYW1lOiAnQk1XIFNlcmllIDEnfSxcclxuICAgICAgICB7aWQ6IDEwLCBuYW1lOiAnQk1XIFNlcmllIDInfSxcclxuICAgIF07XHJcblxyXG5cclxuICAgIHByaXZhdGUgZ2V0Q3VycmVudENvbnRleHQoKSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXM7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2FjaGVkUmVzdWx0OmFueTtcclxuICAgIHByaXZhdGUgX3ByZXZpb3VzQ29udGV4dDphbnk7XHJcblxyXG4gICAgcHJpdmF0ZSBnZXRBc3luY0RhdGEoY29udGV4dDphbnkpOkZ1bmN0aW9uIHtcclxuICAgICAgICBpZiAodGhpcy5fcHJldmlvdXNDb250ZXh0ID09PSBjb250ZXh0KSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9jYWNoZWRSZXN1bHQ7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLl9wcmV2aW91c0NvbnRleHQgPSBjb250ZXh0O1xyXG4gICAgICAgIGxldCBmOkZ1bmN0aW9uID0gZnVuY3Rpb24gKCk6UHJvbWlzZTxzdHJpbmdbXT4ge1xyXG4gICAgICAgICAgICBsZXQgcDpQcm9taXNlPHN0cmluZ1tdPiA9IG5ldyBQcm9taXNlKChyZXNvbHZlOkZ1bmN0aW9uKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgcXVlcnkgPSBuZXcgUmVnRXhwKGNvbnRleHQuYXN5bmNTZWxlY3RlZENhciwgJ2lnJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlc29sdmUoY29udGV4dC5jYXJzRXhhbXBsZTEuZmlsdGVyKChzdGF0ZTphbnkpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHF1ZXJ5LnRlc3Qoc3RhdGUpO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pKTtcclxuICAgICAgICAgICAgICAgIH0sIDUwMCk7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICByZXR1cm4gcDtcclxuICAgICAgICB9O1xyXG4gICAgICAgIHRoaXMuX2NhY2hlZFJlc3VsdCA9IGY7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2NhY2hlZFJlc3VsdDtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIGNoYW5nZUF1dG9jb21wbGV0ZUxvYWRpbmcoZTpib29sZWFuKSB7XHJcbiAgICAgICAgdGhpcy5hdXRvY29tcGxldGVMb2FkaW5nID0gZTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIGNoYW5nZUF1dG9jb21wbGV0ZU5vUmVzdWx0cyhlOmJvb2xlYW4pIHtcclxuICAgICAgICB0aGlzLmF1dG9jb21wbGV0ZU5vUmVzdWx0cyA9IGU7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBhdXRvY29tcGxldGVPblNlbGVjdChlOmFueSkge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGBTZWxlY3RlZCB2YWx1ZTogJHtlLml0ZW19YCk7XHJcbiAgICB9XHJcbn0iXX0=
