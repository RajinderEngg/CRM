System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var AutocompleteOptions;
    return {
        setters:[],
        execute: function() {
            AutocompleteOptions = (function () {
                function AutocompleteOptions(options) {
                    Object.assign(this, options);
                }
                return AutocompleteOptions;
            }());
            exports_1("AutocompleteOptions", AutocompleteOptions);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImF1dG9jb21wbGV0ZS9vcHRpb25zLmNsYXNzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7WUFBQTtnQkFJSSw2QkFBWSxPQUEyQjtvQkFDbkMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQUM7Z0JBQ2pDLENBQUM7Z0JBQ0wsMEJBQUM7WUFBRCxDQVBBLEFBT0MsSUFBQTtZQVBELHFEQU9DLENBQUEiLCJmaWxlIjoiYXV0b2NvbXBsZXRlL29wdGlvbnMuY2xhc3MuanMiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgY2xhc3MgQXV0b2NvbXBsZXRlT3B0aW9ucyB7XHJcbiAgICBwdWJsaWMgcGxhY2VtZW50OnN0cmluZztcclxuICAgIHB1YmxpYyBhbmltYXRpb246Ym9vbGVhbjtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihvcHRpb25zOkF1dG9jb21wbGV0ZU9wdGlvbnMpIHtcclxuICAgICAgICBPYmplY3QuYXNzaWduKHRoaXMsIG9wdGlvbnMpO1xyXG4gICAgfVxyXG59Il19
