System.register(['angular2/platform/browser', './autocomplete-example'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var browser_1, autocomplete_example_1;
    return {
        setters:[
            function (browser_1_1) {
                browser_1 = browser_1_1;
            },
            function (autocomplete_example_1_1) {
                autocomplete_example_1 = autocomplete_example_1_1;
            }],
        execute: function() {
            browser_1.bootstrap(autocomplete_example_1.Angular2Autocomplete);
        }
    }
});
/*
Copyright 2016 angulartypescript.com. All Rights Reserved.
Everyone can use this source code; don’t forget to indicate the source please:
http://www.angulartypescript.com/
*/

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImF1dG9jb21wbGV0ZS9tYWluLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7WUFNQSxtQkFBUyxDQUFDLDJDQUFvQixDQUFDLENBQUM7Ozs7QUFHaEM7Ozs7RUFJRSIsImZpbGUiOiJhdXRvY29tcGxldGUvbWFpbi5qcyIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxyXG4gKiBDcmVhdGVkIGJ5IFRhcmVxIEJvdWxha2phci4gZnJvbSBhbmd1bGFydHlwZXNjcmlwdC5jb21cclxuICovXHJcbmltcG9ydCB7Ym9vdHN0cmFwfSAgZnJvbSAnYW5ndWxhcjIvcGxhdGZvcm0vYnJvd3Nlcic7XHJcbmltcG9ydCB7QW5ndWxhcjJBdXRvY29tcGxldGV9IGZyb20gJy4vYXV0b2NvbXBsZXRlLWV4YW1wbGUnO1xyXG5cclxuYm9vdHN0cmFwKEFuZ3VsYXIyQXV0b2NvbXBsZXRlKTtcclxuXHJcblxyXG4vKlxyXG5Db3B5cmlnaHQgMjAxNiBhbmd1bGFydHlwZXNjcmlwdC5jb20uIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXHJcbkV2ZXJ5b25lIGNhbiB1c2UgdGhpcyBzb3VyY2UgY29kZTsgZG9u4oCZdCBmb3JnZXQgdG8gaW5kaWNhdGUgdGhlIHNvdXJjZSBwbGVhc2U6XHJcbmh0dHA6Ly93d3cuYW5ndWxhcnR5cGVzY3JpcHQuY29tLyBcclxuKi9cclxuIl19
