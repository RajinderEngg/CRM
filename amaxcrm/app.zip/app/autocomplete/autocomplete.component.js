System.register(['angular2/core', 'angular2/common', './sanitize', './autocomplete-container', './options.class'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, core_2, common_1, sanitize_1, autocomplete_container_1, options_class_1;
    var Autocomplete;
    function setProperty(renderer, elementRef, propName, propValue) {
        renderer.setElementProperty(elementRef.nativeElement, propName, propValue);
    }
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
                core_2 = core_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (sanitize_1_1) {
                sanitize_1 = sanitize_1_1;
            },
            function (autocomplete_container_1_1) {
                autocomplete_container_1 = autocomplete_container_1_1;
            },
            function (options_class_1_1) {
                options_class_1 = options_class_1_1;
            }],
        execute: function() {
            Autocomplete = (function () {
                function Autocomplete(cd, element, renderer, loader) {
                    this.cd = cd;
                    this.element = element;
                    this.renderer = renderer;
                    this.loader = loader;
                    this.autocompleteLoading = new core_2.EventEmitter();
                    this.autocompleteNoResults = new core_2.EventEmitter();
                    this.autocompleteOnSelect = new core_2.EventEmitter();
                    this.autocompleteAsync = null;
                    this.autocompleteLatinize = true;
                    this.autocompleteSingleWords = true;
                    this.autocompleteWordDelimiters = ' ';
                    this.autocompletePhraseDelimiters = '\'"';
                    this._matches = [];
                    this.placement = 'bottom-left';
                }
                Object.defineProperty(Autocomplete.prototype, "matches", {
                    get: function () {
                        return this._matches;
                    },
                    enumerable: true,
                    configurable: true
                });
                Autocomplete.prototype.debounce = function (func, wait) {
                    var timeout;
                    var args;
                    var timestamp;
                    var waitOriginal = wait;
                    return function () {
                        // save details of latest call
                        args = [].slice.call(arguments, 0);
                        timestamp = Date.now();
                        // this trick is about implementing of 'autocompleteWaitMs'
                        // in this case we have adaptive 'wait' parameter
                        // we should use standard 'wait'('waitOriginal') in case of
                        // popup is opened, otherwise - 'autocompleteWaitMs' parameter
                        wait = this.container ? waitOriginal : this.autocompleteWaitMs;
                        // this is where the magic happens
                        var later = function () {
                            // how long ago was the last call
                            var last = Date.now() - timestamp;
                            // if the latest call was less that the wait period ago
                            // then we reset the timeout to wait for the difference
                            if (last < wait) {
                                timeout = setTimeout(later, wait - last);
                            }
                            else {
                                timeout = null;
                                func.apply(this, args);
                            }
                        };
                        // we only need to set the timer now if one isn't already running
                        if (!timeout) {
                            timeout = setTimeout(later, wait);
                        }
                    };
                };
                Autocomplete.prototype.processMatches = function () {
                    this._matches = [];
                    if (this.cd.model.toString().length >= this.autocompleteMinLength) {
                        // If singleWords, break model here to not be doing extra work on each iteration
                        var normalizedQuery = (this.autocompleteLatinize ? sanitize_1.AutocompleteUtils.latinize(this.cd.model) : this.cd.model).toString().toLowerCase();
                        normalizedQuery = this.autocompleteSingleWords ? sanitize_1.AutocompleteUtils.tokenize(normalizedQuery, this.autocompleteWordDelimiters, this.autocompletePhraseDelimiters) : normalizedQuery;
                        if (this.autocomplete != undefined) {
                            for (var i = 0; i < this.autocomplete.length; i++) {
                                var match = void 0;
                                if (typeof this.autocomplete[i] === 'object' &&
                                    this.autocomplete[i][this.autocompleteOptionField]) {
                                    match = this.autocompleteLatinize ? sanitize_1.AutocompleteUtils.latinize(this.autocomplete[i][this.autocompleteOptionField].toString()) : this.autocomplete[i][this.autocompleteOptionField].toString();
                                }
                                if (typeof this.autocomplete[i] === 'string') {
                                    match = this.autocompleteLatinize ? sanitize_1.AutocompleteUtils.latinize(this.autocomplete[i].toString()) : this.autocomplete[i].toString();
                                }
                                if (!match) {
                                    console.log('Invalid match type', typeof this.autocomplete[i], this.autocompleteOptionField);
                                    continue;
                                }
                                if (this.testMatch(match.toLowerCase(), normalizedQuery)) {
                                    this._matches.push(this.autocomplete[i]);
                                    if (this._matches.length > this.autocompleteOptionsLimit - 1) {
                                        break;
                                    }
                                }
                            }
                        }
                    }
                };
                Autocomplete.prototype.testMatch = function (match, test) {
                    var spaceLength;
                    if (typeof test === 'object') {
                        spaceLength = test.length;
                        for (var i = 0; i < spaceLength; i += 1) {
                            if (test[i].length > 0 && match.indexOf(test[i]) < 0) {
                                return false;
                            }
                        }
                        return true;
                    }
                    else {
                        return match.indexOf(test) >= 0;
                    }
                };
                Autocomplete.prototype.finalizeAsyncCall = function () {
                    this.autocompleteLoading.emit(false);
                    this.autocompleteNoResults.emit(this.cd.model.toString().length >=
                        this.autocompleteMinLength && this.matches.length <= 0);
                    if (this.cd.model.toString().length <= 0 || this._matches.length <= 0) {
                        this.hide();
                        return;
                    }
                    if (this.container && this._matches.length > 0) {
                        // This improves the speedas it won't have to be done for each list item
                        var normalizedQuery = (this.autocompleteLatinize ? sanitize_1.AutocompleteUtils.latinize(this.cd.model) : this.cd.model).toString().toLowerCase();
                        this.container.query = this.autocompleteSingleWords ? sanitize_1.AutocompleteUtils.tokenize(normalizedQuery, this.autocompleteWordDelimiters, this.autocompletePhraseDelimiters) : normalizedQuery;
                        this.container.matches = this._matches;
                    }
                    if (!this.container && this._matches.length > 0) {
                        this.show(this._matches);
                    }
                };
                Autocomplete.prototype.ngOnInit = function () {
                    var _this = this;
                    // this.autocompleteMinLength = 3;
                    this.autocompleteOptionsLimit = this.autocompleteOptionsLimit || 20;
                    this.autocompleteMinLength = this.autocompleteMinLength || 1;
                    this.autocompleteWaitMs = this.autocompleteWaitMs || 0;
                    // async should be false in case of array
                    if (this.autocompleteAsync === null && typeof this.autocomplete !== 'function') {
                        this.autocompleteAsync = false;
                    }
                    // async should be true for any case of function
                    if (typeof this.autocomplete === 'function') {
                        this.autocompleteAsync = true;
                    }
                    if (this.autocompleteAsync === true) {
                        debugger;
                        this.debouncer = this.debounce(function () {
                            if (typeof _this.autocomplete === 'function') {
                                _this.autocomplete().then(function (matches) {
                                    _this._matches = [];
                                    if (_this.cd.model.toString().length >= _this.autocompleteMinLength) {
                                        for (var i = 0; i < matches.length; i++) {
                                            _this._matches.push(matches[i]);
                                            if (_this._matches.length > _this.autocompleteOptionsLimit - 1) {
                                                break;
                                            }
                                        }
                                    }
                                    _this.finalizeAsyncCall();
                                });
                            }
                            // source is array
                            if (typeof _this.autocomplete === 'object' && _this.autocomplete.length) {
                                _this.processMatches();
                                _this.finalizeAsyncCall();
                            }
                        }, 100);
                    }
                };
                Autocomplete.prototype.onChange = function (e) {
                    if (this.container) {
                        // esc
                        if (e.keyCode === 27) {
                            this.hide();
                            return;
                        }
                        // up
                        if (e.keyCode === 38) {
                            this.container.prevActiveMatch();
                            return;
                        }
                        // down
                        if (e.keyCode === 40) {
                            this.container.nextActiveMatch();
                            return;
                        }
                        // enter
                        if (e.keyCode === 13) {
                            this.container.selectActiveMatch();
                            return;
                        }
                    }
                    this.autocompleteLoading.emit(true);
                    if (this.autocompleteAsync === true) {
                        this.debouncer();
                    }
                    if (this.autocompleteAsync === false) {
                        this.processMatches();
                        this.finalizeAsyncCall();
                    }
                };
                Autocomplete.prototype.changeModel = function (value) {
                    var valueStr = ((typeof value === 'object' && this.autocompleteOptionField) ? value[this.autocompleteOptionField] : value).toString();
                    this.cd.viewToModelUpdate(valueStr);
                    setProperty(this.renderer, this.element, 'value', valueStr);
                    this.hide();
                };
                Autocomplete.prototype.show = function (matches) {
                    var _this = this;
                    var options = new options_class_1.AutocompleteOptions({
                        placement: this.placement,
                        animation: false
                    });
                    var binding = core_2.Injector.resolve([
                        new core_2.Provider(options_class_1.AutocompleteOptions, { useValue: options })
                    ]);
                    this.popup = this.loader
                        .loadNextToLocation(autocomplete_container_1.AutocompleteContainer, this.element, binding)
                        .then(function (componentRef) {
                        componentRef.instance.position(_this.element);
                        _this.container = componentRef.instance;
                        _this.container.parent = _this;
                        // This improves the speedas it won't have to be done for each list item
                        var normalizedQuery = (_this.autocompleteLatinize ? sanitize_1.AutocompleteUtils.latinize(_this.cd.model) : _this.cd.model).toString().toLowerCase();
                        _this.container.query = _this.autocompleteSingleWords ? sanitize_1.AutocompleteUtils.tokenize(normalizedQuery, _this.autocompleteWordDelimiters, _this.autocompletePhraseDelimiters) : normalizedQuery;
                        _this.container.matches = matches;
                        _this.container.field = _this.autocompleteOptionField;
                        _this.element.nativeElement.focus();
                        return componentRef;
                    });
                };
                Autocomplete.prototype.hide = function () {
                    var _this = this;
                    if (this.container) {
                        this.popup.then(function (componentRef) {
                            componentRef.dispose();
                            _this.container = null;
                            return componentRef;
                        });
                    }
                };
                __decorate([
                    core_2.Output(), 
                    __metadata('design:type', core_2.EventEmitter)
                ], Autocomplete.prototype, "autocompleteLoading", void 0);
                __decorate([
                    core_2.Output(), 
                    __metadata('design:type', core_2.EventEmitter)
                ], Autocomplete.prototype, "autocompleteNoResults", void 0);
                __decorate([
                    core_2.Output(), 
                    __metadata('design:type', core_2.EventEmitter)
                ], Autocomplete.prototype, "autocompleteOnSelect", void 0);
                __decorate([
                    core_2.Input(), 
                    __metadata('design:type', Object)
                ], Autocomplete.prototype, "autocomplete", void 0);
                __decorate([
                    core_2.Input(), 
                    __metadata('design:type', Number)
                ], Autocomplete.prototype, "autocompleteMinLength", void 0);
                __decorate([
                    core_2.Input(), 
                    __metadata('design:type', Number)
                ], Autocomplete.prototype, "autocompleteWaitMs", void 0);
                __decorate([
                    core_2.Input(), 
                    __metadata('design:type', Number)
                ], Autocomplete.prototype, "autocompleteOptionsLimit", void 0);
                __decorate([
                    core_2.Input(), 
                    __metadata('design:type', String)
                ], Autocomplete.prototype, "autocompleteOptionField", void 0);
                __decorate([
                    core_2.Input(), 
                    __metadata('design:type', Boolean)
                ], Autocomplete.prototype, "autocompleteAsync", void 0);
                __decorate([
                    core_2.Input(), 
                    __metadata('design:type', Boolean)
                ], Autocomplete.prototype, "autocompleteLatinize", void 0);
                __decorate([
                    core_2.Input(), 
                    __metadata('design:type', Boolean)
                ], Autocomplete.prototype, "autocompleteSingleWords", void 0);
                __decorate([
                    core_2.Input(), 
                    __metadata('design:type', String)
                ], Autocomplete.prototype, "autocompleteWordDelimiters", void 0);
                __decorate([
                    core_2.Input(), 
                    __metadata('design:type', String)
                ], Autocomplete.prototype, "autocompletePhraseDelimiters", void 0);
                __decorate([
                    core_2.HostListener('keyup', ['$event']), 
                    __metadata('design:type', Function), 
                    __metadata('design:paramtypes', [KeyboardEvent]), 
                    __metadata('design:returntype', void 0)
                ], Autocomplete.prototype, "onChange", null);
                Autocomplete = __decorate([
                    core_2.Directive({
                        selector: 'autocomplete[ngModel], [ngModel][autocomplete]'
                    }), 
                    __metadata('design:paramtypes', [common_1.NgModel, core_1.ElementRef, core_2.Renderer, core_2.DynamicComponentLoader])
                ], Autocomplete);
                return Autocomplete;
            }());
            exports_1("Autocomplete", Autocomplete);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImF1dG9jb21wbGV0ZS9hdXRvY29tcGxldGUuY29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7O0lBYUEscUJBQXFCLFFBQWlCLEVBQUUsVUFBcUIsRUFBRSxRQUFlLEVBQUUsU0FBYTtRQUN6RixRQUFRLENBQUMsa0JBQWtCLENBQUMsVUFBVSxDQUFDLGFBQWEsRUFBRSxRQUFRLEVBQUUsU0FBUyxDQUFDLENBQUM7SUFDL0UsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7WUFhRDtnQkF5Qkksc0JBQW9CLEVBQVUsRUFDVixPQUFrQixFQUNsQixRQUFpQixFQUNqQixNQUE2QjtvQkFIN0IsT0FBRSxHQUFGLEVBQUUsQ0FBUTtvQkFDVixZQUFPLEdBQVAsT0FBTyxDQUFXO29CQUNsQixhQUFRLEdBQVIsUUFBUSxDQUFTO29CQUNqQixXQUFNLEdBQU4sTUFBTSxDQUF1QjtvQkEzQmhDLHdCQUFtQixHQUF5QixJQUFJLG1CQUFZLEVBQUUsQ0FBQztvQkFDL0QsMEJBQXFCLEdBQXlCLElBQUksbUJBQVksRUFBRSxDQUFDO29CQUNqRSx5QkFBb0IsR0FBNkIsSUFBSSxtQkFBWSxFQUFFLENBQUM7b0JBT3JFLHNCQUFpQixHQUFXLElBQUksQ0FBQztvQkFDakMseUJBQW9CLEdBQVcsSUFBSSxDQUFDO29CQUNwQyw0QkFBdUIsR0FBVyxJQUFJLENBQUM7b0JBQ3ZDLCtCQUEwQixHQUFVLEdBQUcsQ0FBQztvQkFDeEMsaUNBQTRCLEdBQVUsS0FBSyxDQUFDO29CQU9wRCxhQUFRLEdBQWMsRUFBRSxDQUFDO29CQUN6QixjQUFTLEdBQVUsYUFBYSxDQUFDO2dCQU96QyxDQUFDO2dCQUVELHNCQUFXLGlDQUFPO3lCQUFsQjt3QkFDSSxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQztvQkFDekIsQ0FBQzs7O21CQUFBO2dCQUVPLCtCQUFRLEdBQWhCLFVBQWlCLElBQWEsRUFBRSxJQUFXO29CQUN2QyxJQUFJLE9BQVcsQ0FBQztvQkFDaEIsSUFBSSxJQUFlLENBQUM7b0JBQ3BCLElBQUksU0FBZ0IsQ0FBQztvQkFDckIsSUFBSSxZQUFZLEdBQVUsSUFBSSxDQUFDO29CQUUvQixNQUFNLENBQUM7d0JBQ0gsOEJBQThCO3dCQUM5QixJQUFJLEdBQUcsRUFBRSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxDQUFDO3dCQUNuQyxTQUFTLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO3dCQUV2QiwyREFBMkQ7d0JBQzNELGlEQUFpRDt3QkFDakQsMkRBQTJEO3dCQUMzRCw4REFBOEQ7d0JBQzlELElBQUksR0FBRyxJQUFJLENBQUMsU0FBUyxHQUFHLFlBQVksR0FBRyxJQUFJLENBQUMsa0JBQWtCLENBQUM7d0JBRS9ELGtDQUFrQzt3QkFDbEMsSUFBSSxLQUFLLEdBQUc7NEJBRVIsaUNBQWlDOzRCQUNqQyxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLEdBQUcsU0FBUyxDQUFDOzRCQUVsQyx1REFBdUQ7NEJBQ3ZELHVEQUF1RDs0QkFDdkQsRUFBRSxDQUFDLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUM7Z0NBQ2QsT0FBTyxHQUFHLFVBQVUsQ0FBQyxLQUFLLEVBQUUsSUFBSSxHQUFHLElBQUksQ0FBQyxDQUFDOzRCQUU3QyxDQUFDOzRCQUFDLElBQUksQ0FBQyxDQUFDO2dDQUNKLE9BQU8sR0FBRyxJQUFJLENBQUM7Z0NBQ2YsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7NEJBQzNCLENBQUM7d0JBQ0wsQ0FBQyxDQUFDO3dCQUVGLGlFQUFpRTt3QkFDakUsRUFBRSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDOzRCQUNYLE9BQU8sR0FBRyxVQUFVLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxDQUFDO3dCQUN0QyxDQUFDO29CQUNMLENBQUMsQ0FBQztnQkFDTixDQUFDO2dCQUVPLHFDQUFjLEdBQXRCO29CQUNJLElBQUksQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDO29CQUNuQixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQyxNQUFNLElBQUksSUFBSSxDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQzt3QkFDaEUsZ0ZBQWdGO3dCQUNoRixJQUFJLGVBQWUsR0FBRyxDQUFDLElBQUksQ0FBQyxvQkFBb0IsR0FBRyw0QkFBaUIsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsRUFBRSxDQUFDLFdBQVcsRUFBRSxDQUFDO3dCQUN2SSxlQUFlLEdBQUcsSUFBSSxDQUFDLHVCQUF1QixHQUFHLDRCQUFpQixDQUFDLFFBQVEsQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDLDBCQUEwQixFQUFFLElBQUksQ0FBQyw0QkFBNEIsQ0FBQyxHQUFHLGVBQWUsQ0FBQzt3QkFFbkwsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFlBQVksSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDOzRCQUNqQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUM7Z0NBQ2hELElBQUksS0FBSyxTQUFRLENBQUM7Z0NBRWxCLEVBQUUsQ0FBQyxDQUFDLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsS0FBSyxRQUFRO29DQUN4QyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQ0FDckQsS0FBSyxHQUFHLElBQUksQ0FBQyxvQkFBb0IsR0FBRyw0QkFBaUIsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLENBQUMsUUFBUSxFQUFFLENBQUM7Z0NBQ2xNLENBQUM7Z0NBRUQsRUFBRSxDQUFDLENBQUMsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxLQUFLLFFBQVEsQ0FBQyxDQUFDLENBQUM7b0NBQzNDLEtBQUssR0FBRyxJQUFJLENBQUMsb0JBQW9CLEdBQUcsNEJBQWlCLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRSxDQUFDO2dDQUN0SSxDQUFDO2dDQUVELEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztvQ0FDVCxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixFQUFFLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsdUJBQXVCLENBQUMsQ0FBQztvQ0FDN0YsUUFBUSxDQUFDO2dDQUNiLENBQUM7Z0NBRUQsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsV0FBVyxFQUFFLEVBQUUsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDO29DQUN2RCxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7b0NBQ3pDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyx3QkFBd0IsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dDQUMzRCxLQUFLLENBQUM7b0NBQ1YsQ0FBQztnQ0FDTCxDQUFDOzRCQUNMLENBQUM7d0JBQ0wsQ0FBQztvQkFDTCxDQUFDO2dCQUNMLENBQUM7Z0JBRU8sZ0NBQVMsR0FBakIsVUFBa0IsS0FBWSxFQUFFLElBQVE7b0JBQ3BDLElBQUksV0FBa0IsQ0FBQztvQkFFdkIsRUFBRSxDQUFDLENBQUMsT0FBTyxJQUFJLEtBQUssUUFBUSxDQUFDLENBQUMsQ0FBQzt3QkFDM0IsV0FBVyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUM7d0JBQzFCLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsV0FBVyxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQzs0QkFDdEMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUNuRCxNQUFNLENBQUMsS0FBSyxDQUFDOzRCQUNqQixDQUFDO3dCQUNMLENBQUM7d0JBQ0QsTUFBTSxDQUFDLElBQUksQ0FBQztvQkFDaEIsQ0FBQztvQkFBQyxJQUFJLENBQUMsQ0FBQzt3QkFDSixNQUFNLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBQ3BDLENBQUM7Z0JBQ0wsQ0FBQztnQkFFTyx3Q0FBaUIsR0FBekI7b0JBQ0ksSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDckMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQyxNQUFNO3dCQUMzRCxJQUFJLENBQUMscUJBQXFCLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUM7b0JBRTVELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLFFBQVEsRUFBRSxDQUFDLE1BQU0sSUFBSSxDQUFDLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDcEUsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO3dCQUNaLE1BQU0sQ0FBQztvQkFDWCxDQUFDO29CQUVELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDN0Msd0VBQXdFO3dCQUN4RSxJQUFJLGVBQWUsR0FBRyxDQUFDLElBQUksQ0FBQyxvQkFBb0IsR0FBRyw0QkFBaUIsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsRUFBRSxDQUFDLFdBQVcsRUFBRSxDQUFDO3dCQUN2SSxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsdUJBQXVCLEdBQUcsNEJBQWlCLENBQUMsUUFBUSxDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUMsMEJBQTBCLEVBQUUsSUFBSSxDQUFDLDRCQUE0QixDQUFDLEdBQUcsZUFBZSxDQUFDO3dCQUN4TCxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDO29CQUMzQyxDQUFDO29CQUVELEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUM5QyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFDN0IsQ0FBQztnQkFDTCxDQUFDO2dCQUVELCtCQUFRLEdBQVI7b0JBQUEsaUJBMENDO29CQXpDRSxrQ0FBa0M7b0JBQ2pDLElBQUksQ0FBQyx3QkFBd0IsR0FBRyxJQUFJLENBQUMsd0JBQXdCLElBQUksRUFBRSxDQUFDO29CQUNwRSxJQUFJLENBQUMscUJBQXFCLEdBQUcsSUFBSSxDQUFDLHFCQUFxQixJQUFJLENBQUMsQ0FBQztvQkFDN0QsSUFBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQyxrQkFBa0IsSUFBSSxDQUFDLENBQUM7b0JBRXZELHlDQUF5QztvQkFDekMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLGlCQUFpQixLQUFLLElBQUksSUFBSSxPQUFPLElBQUksQ0FBQyxZQUFZLEtBQUssVUFBVSxDQUFDLENBQUMsQ0FBQzt3QkFDN0UsSUFBSSxDQUFDLGlCQUFpQixHQUFHLEtBQUssQ0FBQztvQkFDbkMsQ0FBQztvQkFFRCxnREFBZ0Q7b0JBQ2hELEVBQUUsQ0FBQyxDQUFDLE9BQU8sSUFBSSxDQUFDLFlBQVksS0FBSyxVQUFVLENBQUMsQ0FBQyxDQUFDO3dCQUMxQyxJQUFJLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDO29CQUNsQyxDQUFDO29CQUVELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDO3dCQUNsQyxRQUFRLENBQUM7d0JBQ1QsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDOzRCQUMzQixFQUFFLENBQUMsQ0FBQyxPQUFPLEtBQUksQ0FBQyxZQUFZLEtBQUssVUFBVSxDQUFDLENBQUMsQ0FBQztnQ0FDMUMsS0FBSSxDQUFDLFlBQVksRUFBRSxDQUFDLElBQUksQ0FBQyxVQUFDLE9BQWE7b0NBQ25DLEtBQUksQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDO29DQUNuQixFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQyxNQUFNLElBQUksS0FBSSxDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQzt3Q0FDaEUsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxPQUFPLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUM7NENBQ3RDLEtBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOzRDQUMvQixFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxLQUFJLENBQUMsd0JBQXdCLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztnREFDM0QsS0FBSyxDQUFDOzRDQUNWLENBQUM7d0NBQ0wsQ0FBQztvQ0FDTCxDQUFDO29DQUVELEtBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO2dDQUM3QixDQUFDLENBQUMsQ0FBQzs0QkFDUCxDQUFDOzRCQUVELGtCQUFrQjs0QkFDbEIsRUFBRSxDQUFDLENBQUMsT0FBTyxLQUFJLENBQUMsWUFBWSxLQUFLLFFBQVEsSUFBSSxLQUFJLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7Z0NBQ3BFLEtBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztnQ0FDdEIsS0FBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7NEJBQzdCLENBQUM7d0JBQ0wsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO29CQUNaLENBQUM7Z0JBQ0wsQ0FBQztnQkFHRCwrQkFBUSxHQUFSLFVBQVMsQ0FBZTtvQkFDcEIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7d0JBQ2pCLE1BQU07d0JBQ04sRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDOzRCQUNuQixJQUFJLENBQUMsSUFBSSxFQUFFLENBQUM7NEJBQ1osTUFBTSxDQUFDO3dCQUNYLENBQUM7d0JBRUQsS0FBSzt3QkFDTCxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUM7NEJBQ25CLElBQUksQ0FBQyxTQUFTLENBQUMsZUFBZSxFQUFFLENBQUM7NEJBQ2pDLE1BQU0sQ0FBQzt3QkFDWCxDQUFDO3dCQUVELE9BQU87d0JBQ1AsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDOzRCQUNuQixJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWUsRUFBRSxDQUFDOzRCQUNqQyxNQUFNLENBQUM7d0JBQ1gsQ0FBQzt3QkFFRCxRQUFRO3dCQUNSLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQzs0QkFDbkIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxpQkFBaUIsRUFBRSxDQUFDOzRCQUNuQyxNQUFNLENBQUM7d0JBQ1gsQ0FBQztvQkFDTCxDQUFDO29CQUVELElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBRXBDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDO3dCQUNsQyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7b0JBQ3JCLENBQUM7b0JBRUQsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLGlCQUFpQixLQUFLLEtBQUssQ0FBQyxDQUFDLENBQUM7d0JBQ25DLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQzt3QkFDdEIsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7b0JBQzdCLENBQUM7Z0JBQ0wsQ0FBQztnQkFFTSxrQ0FBVyxHQUFsQixVQUFtQixLQUFTO29CQUN4QixJQUFJLFFBQVEsR0FBVSxDQUFDLENBQUMsT0FBTyxLQUFLLEtBQUssUUFBUSxJQUFJLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsR0FBRyxLQUFLLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQztvQkFDN0ksSUFBSSxDQUFDLEVBQUUsQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFDcEMsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLE9BQU8sRUFBRSxPQUFPLEVBQUUsUUFBUSxDQUFDLENBQUM7b0JBQzVELElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDaEIsQ0FBQztnQkFFRCwyQkFBSSxHQUFKLFVBQUssT0FBa0I7b0JBQXZCLGlCQXlCQztvQkF4QkcsSUFBSSxPQUFPLEdBQUcsSUFBSSxtQ0FBbUIsQ0FBQzt3QkFDbEMsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO3dCQUN6QixTQUFTLEVBQUUsS0FBSztxQkFDbkIsQ0FBQyxDQUFDO29CQUVILElBQUksT0FBTyxHQUFHLGVBQVEsQ0FBQyxPQUFPLENBQUM7d0JBQzNCLElBQUksZUFBUSxDQUFDLG1DQUFtQixFQUFFLEVBQUMsUUFBUSxFQUFFLE9BQU8sRUFBQyxDQUFDO3FCQUN6RCxDQUFDLENBQUM7b0JBR0gsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsTUFBTTt5QkFDbkIsa0JBQWtCLENBQUMsOENBQXFCLEVBQUUsSUFBSSxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUM7eUJBQ2hFLElBQUksQ0FBQyxVQUFDLFlBQXlCO3dCQUM1QixZQUFZLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxLQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7d0JBQzdDLEtBQUksQ0FBQyxTQUFTLEdBQUcsWUFBWSxDQUFDLFFBQVEsQ0FBQzt3QkFDdkMsS0FBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEdBQUcsS0FBSSxDQUFDO3dCQUM3Qix3RUFBd0U7d0JBQ3hFLElBQUksZUFBZSxHQUFHLENBQUMsS0FBSSxDQUFDLG9CQUFvQixHQUFHLDRCQUFpQixDQUFDLFFBQVEsQ0FBQyxLQUFJLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLEtBQUksQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUMsV0FBVyxFQUFFLENBQUM7d0JBQ3ZJLEtBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLEtBQUksQ0FBQyx1QkFBdUIsR0FBRyw0QkFBaUIsQ0FBQyxRQUFRLENBQUMsZUFBZSxFQUFFLEtBQUksQ0FBQywwQkFBMEIsRUFBRSxLQUFJLENBQUMsNEJBQTRCLENBQUMsR0FBRyxlQUFlLENBQUM7d0JBQ3hMLEtBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQzt3QkFDakMsS0FBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsS0FBSSxDQUFDLHVCQUF1QixDQUFDO3dCQUNwRCxLQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxLQUFLLEVBQUUsQ0FBQzt3QkFDbkMsTUFBTSxDQUFDLFlBQVksQ0FBQztvQkFDeEIsQ0FBQyxDQUFDLENBQUM7Z0JBQ1gsQ0FBQztnQkFFRCwyQkFBSSxHQUFKO29CQUFBLGlCQVFDO29CQVBHLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO3dCQUNqQixJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxVQUFDLFlBQXlCOzRCQUN0QyxZQUFZLENBQUMsT0FBTyxFQUFFLENBQUM7NEJBQ3ZCLEtBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDOzRCQUN0QixNQUFNLENBQUMsWUFBWSxDQUFDO3dCQUN4QixDQUFDLENBQUMsQ0FBQztvQkFDUCxDQUFDO2dCQUNMLENBQUM7Z0JBblJEO29CQUFDLGFBQU0sRUFBRTs7eUVBQUE7Z0JBQ1Q7b0JBQUMsYUFBTSxFQUFFOzsyRUFBQTtnQkFDVDtvQkFBQyxhQUFNLEVBQUU7OzBFQUFBO2dCQUVUO29CQUFDLFlBQUssRUFBRTs7a0VBQUE7Z0JBQ1I7b0JBQUMsWUFBSyxFQUFFOzsyRUFBQTtnQkFDUjtvQkFBQyxZQUFLLEVBQUU7O3dFQUFBO2dCQUNSO29CQUFDLFlBQUssRUFBRTs7OEVBQUE7Z0JBQ1I7b0JBQUMsWUFBSyxFQUFFOzs2RUFBQTtnQkFDUjtvQkFBQyxZQUFLLEVBQUU7O3VFQUFBO2dCQUNSO29CQUFDLFlBQUssRUFBRTs7MEVBQUE7Z0JBQ1I7b0JBQUMsWUFBSyxFQUFFOzs2RUFBQTtnQkFDUjtvQkFBQyxZQUFLLEVBQUU7O2dGQUFBO2dCQUNSO29CQUFDLFlBQUssRUFBRTs7a0ZBQUE7Z0JBb0xSO29CQUFDLG1CQUFZLENBQUMsT0FBTyxFQUFFLENBQUMsUUFBUSxDQUFDLENBQUM7Ozs7NERBQUE7Z0JBck10QztvQkFBQyxnQkFBUyxDQUFDO3dCQUNQLFFBQVEsRUFBRSxnREFBZ0Q7cUJBQzdELENBQUM7O2dDQUFBO2dCQXNSRixtQkFBQztZQUFELENBclJBLEFBcVJDLElBQUE7WUFyUkQsdUNBcVJDLENBQUEiLCJmaWxlIjoiYXV0b2NvbXBsZXRlL2F1dG9jb21wbGV0ZS5jb21wb25lbnQuanMiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcclxuICogYm9vdHN0cmFwXHJcbiAqL1xyXG5pbXBvcnQge0NvbXBvbmVudCwgRWxlbWVudFJlZiwgVmlld0VuY2Fwc3VsYXRpb259IGZyb20gJ2FuZ3VsYXIyL2NvcmUnO1xyXG5pbXBvcnQge0NPUkVfRElSRUNUSVZFU30gZnJvbSAnYW5ndWxhcjIvY29tbW9uJztcclxuaW1wb3J0IHtcclxuICAgIERpcmVjdGl2ZSwgSW5wdXQsIE91dHB1dCwgSG9zdExpc3RlbmVyLFxyXG4gICAgRXZlbnRFbWl0dGVyLCBPbkluaXQsXHJcbiAgICBFbGVtZW50UmVmLCBSZW5kZXJlcixcclxuICAgIER5bmFtaWNDb21wb25lbnRMb2FkZXIsIENvbXBvbmVudFJlZiwgUHJvdmlkZXIsIEluamVjdG9yXHJcbn0gZnJvbSAnYW5ndWxhcjIvY29yZSc7XHJcbmltcG9ydCB7TmdNb2RlbH1mcm9tICdhbmd1bGFyMi9jb21tb24nO1xyXG5cclxuZnVuY3Rpb24gc2V0UHJvcGVydHkocmVuZGVyZXI6UmVuZGVyZXIsIGVsZW1lbnRSZWY6RWxlbWVudFJlZiwgcHJvcE5hbWU6c3RyaW5nLCBwcm9wVmFsdWU6YW55KSB7XHJcbiAgICByZW5kZXJlci5zZXRFbGVtZW50UHJvcGVydHkoZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LCBwcm9wTmFtZSwgcHJvcFZhbHVlKTtcclxufVxyXG5cclxuaW1wb3J0IHtwb3NpdGlvblNlcnZpY2V9IGZyb20gJy4vcG9zaXRpb24nO1xyXG5pbXBvcnQge0F1dG9jb21wbGV0ZVV0aWxzfSBmcm9tICcuL3Nhbml0aXplJztcclxuaW1wb3J0IHtBdXRvY29tcGxldGVDb250YWluZXJ9IGZyb20gJy4vYXV0b2NvbXBsZXRlLWNvbnRhaW5lcic7XHJcbmltcG9ydCB7QXV0b2NvbXBsZXRlT3B0aW9uc30gZnJvbSAnLi9vcHRpb25zLmNsYXNzJztcclxuXHJcblxyXG5cclxuXHJcbkBEaXJlY3RpdmUoe1xyXG4gICAgc2VsZWN0b3I6ICdhdXRvY29tcGxldGVbbmdNb2RlbF0sIFtuZ01vZGVsXVthdXRvY29tcGxldGVdJ1xyXG59KVxyXG5leHBvcnQgY2xhc3MgQXV0b2NvbXBsZXRlIGltcGxlbWVudHMgT25Jbml0IHtcclxuICAgIEBPdXRwdXQoKSBwdWJsaWMgYXV0b2NvbXBsZXRlTG9hZGluZzpFdmVudEVtaXR0ZXI8Ym9vbGVhbj4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcbiAgICBAT3V0cHV0KCkgcHVibGljIGF1dG9jb21wbGV0ZU5vUmVzdWx0czpFdmVudEVtaXR0ZXI8Ym9vbGVhbj4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcbiAgICBAT3V0cHV0KCkgcHVibGljIGF1dG9jb21wbGV0ZU9uU2VsZWN0OkV2ZW50RW1pdHRlcjx7aXRlbTogYW55fT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcblxyXG4gICAgQElucHV0KCkgcHVibGljIGF1dG9jb21wbGV0ZTphbnk7XHJcbiAgICBASW5wdXQoKSBwdWJsaWMgYXV0b2NvbXBsZXRlTWluTGVuZ3RoOm51bWJlcjtcclxuICAgIEBJbnB1dCgpIHB1YmxpYyBhdXRvY29tcGxldGVXYWl0TXM6bnVtYmVyO1xyXG4gICAgQElucHV0KCkgcHVibGljIGF1dG9jb21wbGV0ZU9wdGlvbnNMaW1pdDpudW1iZXI7XHJcbiAgICBASW5wdXQoKSBwdWJsaWMgYXV0b2NvbXBsZXRlT3B0aW9uRmllbGQ6c3RyaW5nO1xyXG4gICAgQElucHV0KCkgcHVibGljIGF1dG9jb21wbGV0ZUFzeW5jOmJvb2xlYW4gPSBudWxsO1xyXG4gICAgQElucHV0KCkgcHVibGljIGF1dG9jb21wbGV0ZUxhdGluaXplOmJvb2xlYW4gPSB0cnVlO1xyXG4gICAgQElucHV0KCkgcHVibGljIGF1dG9jb21wbGV0ZVNpbmdsZVdvcmRzOmJvb2xlYW4gPSB0cnVlO1xyXG4gICAgQElucHV0KCkgcHVibGljIGF1dG9jb21wbGV0ZVdvcmREZWxpbWl0ZXJzOnN0cmluZyA9ICcgJztcclxuICAgIEBJbnB1dCgpIHB1YmxpYyBhdXRvY29tcGxldGVQaHJhc2VEZWxpbWl0ZXJzOnN0cmluZyA9ICdcXCdcIic7XHJcblxyXG5cclxuXHJcbiAgICBwdWJsaWMgY29udGFpbmVyOkF1dG9jb21wbGV0ZUNvbnRhaW5lcjtcclxuXHJcbiAgICBwcml2YXRlIGRlYm91bmNlcjpGdW5jdGlvbjtcclxuICAgIHByaXZhdGUgX21hdGNoZXM6QXJyYXk8YW55PiA9IFtdO1xyXG4gICAgcHJpdmF0ZSBwbGFjZW1lbnQ6c3RyaW5nID0gJ2JvdHRvbS1sZWZ0JztcclxuICAgIHByaXZhdGUgcG9wdXA6UHJvbWlzZTxDb21wb25lbnRSZWY+O1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgY2Q6TmdNb2RlbCxcclxuICAgICAgICAgICAgICAgIHByaXZhdGUgZWxlbWVudDpFbGVtZW50UmVmLFxyXG4gICAgICAgICAgICAgICAgcHJpdmF0ZSByZW5kZXJlcjpSZW5kZXJlcixcclxuICAgICAgICAgICAgICAgIHByaXZhdGUgbG9hZGVyOkR5bmFtaWNDb21wb25lbnRMb2FkZXIpIHtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2V0IG1hdGNoZXMoKSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX21hdGNoZXM7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBkZWJvdW5jZShmdW5jOkZ1bmN0aW9uLCB3YWl0Om51bWJlcik6RnVuY3Rpb24ge1xyXG4gICAgICAgIGxldCB0aW1lb3V0OmFueTtcclxuICAgICAgICBsZXQgYXJnczpBcnJheTxhbnk+O1xyXG4gICAgICAgIGxldCB0aW1lc3RhbXA6bnVtYmVyO1xyXG4gICAgICAgIGxldCB3YWl0T3JpZ2luYWw6bnVtYmVyID0gd2FpdDtcclxuXHJcbiAgICAgICAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgLy8gc2F2ZSBkZXRhaWxzIG9mIGxhdGVzdCBjYWxsXHJcbiAgICAgICAgICAgIGFyZ3MgPSBbXS5zbGljZS5jYWxsKGFyZ3VtZW50cywgMCk7XHJcbiAgICAgICAgICAgIHRpbWVzdGFtcCA9IERhdGUubm93KCk7XHJcblxyXG4gICAgICAgICAgICAvLyB0aGlzIHRyaWNrIGlzIGFib3V0IGltcGxlbWVudGluZyBvZiAnYXV0b2NvbXBsZXRlV2FpdE1zJ1xyXG4gICAgICAgICAgICAvLyBpbiB0aGlzIGNhc2Ugd2UgaGF2ZSBhZGFwdGl2ZSAnd2FpdCcgcGFyYW1ldGVyXHJcbiAgICAgICAgICAgIC8vIHdlIHNob3VsZCB1c2Ugc3RhbmRhcmQgJ3dhaXQnKCd3YWl0T3JpZ2luYWwnKSBpbiBjYXNlIG9mXHJcbiAgICAgICAgICAgIC8vIHBvcHVwIGlzIG9wZW5lZCwgb3RoZXJ3aXNlIC0gJ2F1dG9jb21wbGV0ZVdhaXRNcycgcGFyYW1ldGVyXHJcbiAgICAgICAgICAgIHdhaXQgPSB0aGlzLmNvbnRhaW5lciA/IHdhaXRPcmlnaW5hbCA6IHRoaXMuYXV0b2NvbXBsZXRlV2FpdE1zO1xyXG5cclxuICAgICAgICAgICAgLy8gdGhpcyBpcyB3aGVyZSB0aGUgbWFnaWMgaGFwcGVuc1xyXG4gICAgICAgICAgICBsZXQgbGF0ZXIgPSBmdW5jdGlvbiAoKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgLy8gaG93IGxvbmcgYWdvIHdhcyB0aGUgbGFzdCBjYWxsXHJcbiAgICAgICAgICAgICAgICBsZXQgbGFzdCA9IERhdGUubm93KCkgLSB0aW1lc3RhbXA7XHJcblxyXG4gICAgICAgICAgICAgICAgLy8gaWYgdGhlIGxhdGVzdCBjYWxsIHdhcyBsZXNzIHRoYXQgdGhlIHdhaXQgcGVyaW9kIGFnb1xyXG4gICAgICAgICAgICAgICAgLy8gdGhlbiB3ZSByZXNldCB0aGUgdGltZW91dCB0byB3YWl0IGZvciB0aGUgZGlmZmVyZW5jZVxyXG4gICAgICAgICAgICAgICAgaWYgKGxhc3QgPCB3YWl0KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGltZW91dCA9IHNldFRpbWVvdXQobGF0ZXIsIHdhaXQgLSBsYXN0KTtcclxuICAgICAgICAgICAgICAgICAgICAvLyBvciBpZiBub3Qgd2UgY2FuIG51bGwgb3V0IHRoZSB0aW1lciBhbmQgcnVuIHRoZSBsYXRlc3RcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGltZW91dCA9IG51bGw7XHJcbiAgICAgICAgICAgICAgICAgICAgZnVuYy5hcHBseSh0aGlzLCBhcmdzKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIC8vIHdlIG9ubHkgbmVlZCB0byBzZXQgdGhlIHRpbWVyIG5vdyBpZiBvbmUgaXNuJ3QgYWxyZWFkeSBydW5uaW5nXHJcbiAgICAgICAgICAgIGlmICghdGltZW91dCkge1xyXG4gICAgICAgICAgICAgICAgdGltZW91dCA9IHNldFRpbWVvdXQobGF0ZXIsIHdhaXQpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIHByb2Nlc3NNYXRjaGVzKCkge1xyXG4gICAgICAgIHRoaXMuX21hdGNoZXMgPSBbXTtcclxuICAgICAgICBpZiAodGhpcy5jZC5tb2RlbC50b1N0cmluZygpLmxlbmd0aCA+PSB0aGlzLmF1dG9jb21wbGV0ZU1pbkxlbmd0aCkge1xyXG4gICAgICAgICAgICAvLyBJZiBzaW5nbGVXb3JkcywgYnJlYWsgbW9kZWwgaGVyZSB0byBub3QgYmUgZG9pbmcgZXh0cmEgd29yayBvbiBlYWNoIGl0ZXJhdGlvblxyXG4gICAgICAgICAgICBsZXQgbm9ybWFsaXplZFF1ZXJ5ID0gKHRoaXMuYXV0b2NvbXBsZXRlTGF0aW5pemUgPyBBdXRvY29tcGxldGVVdGlscy5sYXRpbml6ZSh0aGlzLmNkLm1vZGVsKSA6IHRoaXMuY2QubW9kZWwpLnRvU3RyaW5nKCkudG9Mb3dlckNhc2UoKTtcclxuICAgICAgICAgICAgbm9ybWFsaXplZFF1ZXJ5ID0gdGhpcy5hdXRvY29tcGxldGVTaW5nbGVXb3JkcyA/IEF1dG9jb21wbGV0ZVV0aWxzLnRva2VuaXplKG5vcm1hbGl6ZWRRdWVyeSwgdGhpcy5hdXRvY29tcGxldGVXb3JkRGVsaW1pdGVycywgdGhpcy5hdXRvY29tcGxldGVQaHJhc2VEZWxpbWl0ZXJzKSA6IG5vcm1hbGl6ZWRRdWVyeTtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIGlmICh0aGlzLmF1dG9jb21wbGV0ZSAhPSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGhpcy5hdXRvY29tcGxldGUubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgbWF0Y2g6IHN0cmluZztcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmF1dG9jb21wbGV0ZVtpXSA9PT0gJ29iamVjdCcgJiZcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5hdXRvY29tcGxldGVbaV1bdGhpcy5hdXRvY29tcGxldGVPcHRpb25GaWVsZF0pIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWF0Y2ggPSB0aGlzLmF1dG9jb21wbGV0ZUxhdGluaXplID8gQXV0b2NvbXBsZXRlVXRpbHMubGF0aW5pemUodGhpcy5hdXRvY29tcGxldGVbaV1bdGhpcy5hdXRvY29tcGxldGVPcHRpb25GaWVsZF0udG9TdHJpbmcoKSkgOiB0aGlzLmF1dG9jb21wbGV0ZVtpXVt0aGlzLmF1dG9jb21wbGV0ZU9wdGlvbkZpZWxkXS50b1N0cmluZygpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmF1dG9jb21wbGV0ZVtpXSA9PT0gJ3N0cmluZycpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWF0Y2ggPSB0aGlzLmF1dG9jb21wbGV0ZUxhdGluaXplID8gQXV0b2NvbXBsZXRlVXRpbHMubGF0aW5pemUodGhpcy5hdXRvY29tcGxldGVbaV0udG9TdHJpbmcoKSkgOiB0aGlzLmF1dG9jb21wbGV0ZVtpXS50b1N0cmluZygpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFtYXRjaCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnSW52YWxpZCBtYXRjaCB0eXBlJywgdHlwZW9mIHRoaXMuYXV0b2NvbXBsZXRlW2ldLCB0aGlzLmF1dG9jb21wbGV0ZU9wdGlvbkZpZWxkKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29udGludWU7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy50ZXN0TWF0Y2gobWF0Y2gudG9Mb3dlckNhc2UoKSwgbm9ybWFsaXplZFF1ZXJ5KSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9tYXRjaGVzLnB1c2godGhpcy5hdXRvY29tcGxldGVbaV0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5fbWF0Y2hlcy5sZW5ndGggPiB0aGlzLmF1dG9jb21wbGV0ZU9wdGlvbnNMaW1pdCAtIDEpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgdGVzdE1hdGNoKG1hdGNoOnN0cmluZywgdGVzdDphbnkpIHtcclxuICAgICAgICBsZXQgc3BhY2VMZW5ndGg6bnVtYmVyO1xyXG5cclxuICAgICAgICBpZiAodHlwZW9mIHRlc3QgPT09ICdvYmplY3QnKSB7XHJcbiAgICAgICAgICAgIHNwYWNlTGVuZ3RoID0gdGVzdC5sZW5ndGg7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgc3BhY2VMZW5ndGg7IGkgKz0gMSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRlc3RbaV0ubGVuZ3RoID4gMCAmJiBtYXRjaC5pbmRleE9mKHRlc3RbaV0pIDwgMCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICByZXR1cm4gbWF0Y2guaW5kZXhPZih0ZXN0KSA+PSAwO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIGZpbmFsaXplQXN5bmNDYWxsKCkge1xyXG4gICAgICAgIHRoaXMuYXV0b2NvbXBsZXRlTG9hZGluZy5lbWl0KGZhbHNlKTtcclxuICAgICAgICB0aGlzLmF1dG9jb21wbGV0ZU5vUmVzdWx0cy5lbWl0KHRoaXMuY2QubW9kZWwudG9TdHJpbmcoKS5sZW5ndGggPj1cclxuICAgICAgICAgICAgdGhpcy5hdXRvY29tcGxldGVNaW5MZW5ndGggJiYgdGhpcy5tYXRjaGVzLmxlbmd0aCA8PSAwKTtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMuY2QubW9kZWwudG9TdHJpbmcoKS5sZW5ndGggPD0gMCB8fCB0aGlzLl9tYXRjaGVzLmxlbmd0aCA8PSAwKSB7XHJcbiAgICAgICAgICAgIHRoaXMuaGlkZSgpO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAodGhpcy5jb250YWluZXIgJiYgdGhpcy5fbWF0Y2hlcy5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgIC8vIFRoaXMgaW1wcm92ZXMgdGhlIHNwZWVkYXMgaXQgd29uJ3QgaGF2ZSB0byBiZSBkb25lIGZvciBlYWNoIGxpc3QgaXRlbVxyXG4gICAgICAgICAgICBsZXQgbm9ybWFsaXplZFF1ZXJ5ID0gKHRoaXMuYXV0b2NvbXBsZXRlTGF0aW5pemUgPyBBdXRvY29tcGxldGVVdGlscy5sYXRpbml6ZSh0aGlzLmNkLm1vZGVsKSA6IHRoaXMuY2QubW9kZWwpLnRvU3RyaW5nKCkudG9Mb3dlckNhc2UoKTtcclxuICAgICAgICAgICAgdGhpcy5jb250YWluZXIucXVlcnkgPSB0aGlzLmF1dG9jb21wbGV0ZVNpbmdsZVdvcmRzID8gQXV0b2NvbXBsZXRlVXRpbHMudG9rZW5pemUobm9ybWFsaXplZFF1ZXJ5LCB0aGlzLmF1dG9jb21wbGV0ZVdvcmREZWxpbWl0ZXJzLCB0aGlzLmF1dG9jb21wbGV0ZVBocmFzZURlbGltaXRlcnMpIDogbm9ybWFsaXplZFF1ZXJ5O1xyXG4gICAgICAgICAgICB0aGlzLmNvbnRhaW5lci5tYXRjaGVzID0gdGhpcy5fbWF0Y2hlcztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICghdGhpcy5jb250YWluZXIgJiYgdGhpcy5fbWF0Y2hlcy5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgIHRoaXMuc2hvdyh0aGlzLl9tYXRjaGVzKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkluaXQoKSB7XHJcbiAgICAgICAvLyB0aGlzLmF1dG9jb21wbGV0ZU1pbkxlbmd0aCA9IDM7XHJcbiAgICAgICAgdGhpcy5hdXRvY29tcGxldGVPcHRpb25zTGltaXQgPSB0aGlzLmF1dG9jb21wbGV0ZU9wdGlvbnNMaW1pdCB8fCAyMDtcclxuICAgICAgICB0aGlzLmF1dG9jb21wbGV0ZU1pbkxlbmd0aCA9IHRoaXMuYXV0b2NvbXBsZXRlTWluTGVuZ3RoIHx8IDE7XHJcbiAgICAgICAgdGhpcy5hdXRvY29tcGxldGVXYWl0TXMgPSB0aGlzLmF1dG9jb21wbGV0ZVdhaXRNcyB8fCAwO1xyXG5cclxuICAgICAgICAvLyBhc3luYyBzaG91bGQgYmUgZmFsc2UgaW4gY2FzZSBvZiBhcnJheVxyXG4gICAgICAgIGlmICh0aGlzLmF1dG9jb21wbGV0ZUFzeW5jID09PSBudWxsICYmIHR5cGVvZiB0aGlzLmF1dG9jb21wbGV0ZSAhPT0gJ2Z1bmN0aW9uJykge1xyXG4gICAgICAgICAgICB0aGlzLmF1dG9jb21wbGV0ZUFzeW5jID0gZmFsc2U7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyBhc3luYyBzaG91bGQgYmUgdHJ1ZSBmb3IgYW55IGNhc2Ugb2YgZnVuY3Rpb25cclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuYXV0b2NvbXBsZXRlID09PSAnZnVuY3Rpb24nKSB7XHJcbiAgICAgICAgICAgIHRoaXMuYXV0b2NvbXBsZXRlQXN5bmMgPSB0cnVlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHRoaXMuYXV0b2NvbXBsZXRlQXN5bmMgPT09IHRydWUpIHtcclxuICAgICAgICAgICAgZGVidWdnZXI7XHJcbiAgICAgICAgICAgIHRoaXMuZGVib3VuY2VyID0gdGhpcy5kZWJvdW5jZSgoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIHRoaXMuYXV0b2NvbXBsZXRlID09PSAnZnVuY3Rpb24nKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hdXRvY29tcGxldGUoKS50aGVuKChtYXRjaGVzOmFueVtdKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX21hdGNoZXMgPSBbXTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuY2QubW9kZWwudG9TdHJpbmcoKS5sZW5ndGggPj0gdGhpcy5hdXRvY29tcGxldGVNaW5MZW5ndGgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbWF0Y2hlcy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX21hdGNoZXMucHVzaChtYXRjaGVzW2ldKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5fbWF0Y2hlcy5sZW5ndGggPiB0aGlzLmF1dG9jb21wbGV0ZU9wdGlvbnNMaW1pdCAtIDEpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmZpbmFsaXplQXN5bmNDYWxsKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgLy8gc291cmNlIGlzIGFycmF5XHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIHRoaXMuYXV0b2NvbXBsZXRlID09PSAnb2JqZWN0JyAmJiB0aGlzLmF1dG9jb21wbGV0ZS5sZW5ndGgpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnByb2Nlc3NNYXRjaGVzKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5maW5hbGl6ZUFzeW5jQ2FsbCgpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LCAxMDApO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBASG9zdExpc3RlbmVyKCdrZXl1cCcsIFsnJGV2ZW50J10pXHJcbiAgICBvbkNoYW5nZShlOktleWJvYXJkRXZlbnQpIHtcclxuICAgICAgICBpZiAodGhpcy5jb250YWluZXIpIHtcclxuICAgICAgICAgICAgLy8gZXNjXHJcbiAgICAgICAgICAgIGlmIChlLmtleUNvZGUgPT09IDI3KSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmhpZGUoKTtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLy8gdXBcclxuICAgICAgICAgICAgaWYgKGUua2V5Q29kZSA9PT0gMzgpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuY29udGFpbmVyLnByZXZBY3RpdmVNYXRjaCgpO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAvLyBkb3duXHJcbiAgICAgICAgICAgIGlmIChlLmtleUNvZGUgPT09IDQwKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNvbnRhaW5lci5uZXh0QWN0aXZlTWF0Y2goKTtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLy8gZW50ZXJcclxuICAgICAgICAgICAgaWYgKGUua2V5Q29kZSA9PT0gMTMpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuY29udGFpbmVyLnNlbGVjdEFjdGl2ZU1hdGNoKCk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMuYXV0b2NvbXBsZXRlTG9hZGluZy5lbWl0KHRydWUpO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5hdXRvY29tcGxldGVBc3luYyA9PT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICB0aGlzLmRlYm91bmNlcigpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHRoaXMuYXV0b2NvbXBsZXRlQXN5bmMgPT09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgIHRoaXMucHJvY2Vzc01hdGNoZXMoKTtcclxuICAgICAgICAgICAgdGhpcy5maW5hbGl6ZUFzeW5jQ2FsbCgpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgY2hhbmdlTW9kZWwodmFsdWU6YW55KSB7XHJcbiAgICAgICAgbGV0IHZhbHVlU3RyOnN0cmluZyA9ICgodHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJiB0aGlzLmF1dG9jb21wbGV0ZU9wdGlvbkZpZWxkKSA/IHZhbHVlW3RoaXMuYXV0b2NvbXBsZXRlT3B0aW9uRmllbGRdIDogdmFsdWUpLnRvU3RyaW5nKCk7XHJcbiAgICAgICAgdGhpcy5jZC52aWV3VG9Nb2RlbFVwZGF0ZSh2YWx1ZVN0cik7XHJcbiAgICAgICAgc2V0UHJvcGVydHkodGhpcy5yZW5kZXJlciwgdGhpcy5lbGVtZW50LCAndmFsdWUnLCB2YWx1ZVN0cik7XHJcbiAgICAgICAgdGhpcy5oaWRlKCk7XHJcbiAgICB9XHJcblxyXG4gICAgc2hvdyhtYXRjaGVzOkFycmF5PGFueT4pIHtcclxuICAgICAgICBsZXQgb3B0aW9ucyA9IG5ldyBBdXRvY29tcGxldGVPcHRpb25zKHtcclxuICAgICAgICAgICAgcGxhY2VtZW50OiB0aGlzLnBsYWNlbWVudCxcclxuICAgICAgICAgICAgYW5pbWF0aW9uOiBmYWxzZVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBsZXQgYmluZGluZyA9IEluamVjdG9yLnJlc29sdmUoW1xyXG4gICAgICAgICAgICBuZXcgUHJvdmlkZXIoQXV0b2NvbXBsZXRlT3B0aW9ucywge3VzZVZhbHVlOiBvcHRpb25zfSlcclxuICAgICAgICBdKTtcclxuXHJcblxyXG4gICAgICAgIHRoaXMucG9wdXAgPSB0aGlzLmxvYWRlclxyXG4gICAgICAgICAgICAubG9hZE5leHRUb0xvY2F0aW9uKEF1dG9jb21wbGV0ZUNvbnRhaW5lciwgdGhpcy5lbGVtZW50LCBiaW5kaW5nKVxyXG4gICAgICAgICAgICAudGhlbigoY29tcG9uZW50UmVmOkNvbXBvbmVudFJlZikgPT4ge1xyXG4gICAgICAgICAgICAgICAgY29tcG9uZW50UmVmLmluc3RhbmNlLnBvc2l0aW9uKHRoaXMuZWxlbWVudCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNvbnRhaW5lciA9IGNvbXBvbmVudFJlZi5pbnN0YW5jZTtcclxuICAgICAgICAgICAgICAgIHRoaXMuY29udGFpbmVyLnBhcmVudCA9IHRoaXM7XHJcbiAgICAgICAgICAgICAgICAvLyBUaGlzIGltcHJvdmVzIHRoZSBzcGVlZGFzIGl0IHdvbid0IGhhdmUgdG8gYmUgZG9uZSBmb3IgZWFjaCBsaXN0IGl0ZW1cclxuICAgICAgICAgICAgICAgIGxldCBub3JtYWxpemVkUXVlcnkgPSAodGhpcy5hdXRvY29tcGxldGVMYXRpbml6ZSA/IEF1dG9jb21wbGV0ZVV0aWxzLmxhdGluaXplKHRoaXMuY2QubW9kZWwpIDogdGhpcy5jZC5tb2RlbCkudG9TdHJpbmcoKS50b0xvd2VyQ2FzZSgpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jb250YWluZXIucXVlcnkgPSB0aGlzLmF1dG9jb21wbGV0ZVNpbmdsZVdvcmRzID8gQXV0b2NvbXBsZXRlVXRpbHMudG9rZW5pemUobm9ybWFsaXplZFF1ZXJ5LCB0aGlzLmF1dG9jb21wbGV0ZVdvcmREZWxpbWl0ZXJzLCB0aGlzLmF1dG9jb21wbGV0ZVBocmFzZURlbGltaXRlcnMpIDogbm9ybWFsaXplZFF1ZXJ5O1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jb250YWluZXIubWF0Y2hlcyA9IG1hdGNoZXM7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNvbnRhaW5lci5maWVsZCA9IHRoaXMuYXV0b2NvbXBsZXRlT3B0aW9uRmllbGQ7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmVsZW1lbnQubmF0aXZlRWxlbWVudC5mb2N1cygpO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGNvbXBvbmVudFJlZjtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgaGlkZSgpIHtcclxuICAgICAgICBpZiAodGhpcy5jb250YWluZXIpIHtcclxuICAgICAgICAgICAgdGhpcy5wb3B1cC50aGVuKChjb21wb25lbnRSZWY6Q29tcG9uZW50UmVmKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBjb21wb25lbnRSZWYuZGlzcG9zZSgpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jb250YWluZXIgPSBudWxsO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGNvbXBvbmVudFJlZjtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG5cclxuIl19
