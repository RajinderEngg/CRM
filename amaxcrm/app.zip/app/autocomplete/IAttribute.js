System.register(['angular2/core'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var __param = (this && this.__param) || function (paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    };
    var core_1;
    var NgTransclude;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            }],
        execute: function() {
            NgTransclude = (function () {
                function NgTransclude(viewRef) {
                    this.viewRef = viewRef;
                }
                Object.defineProperty(NgTransclude.prototype, "ngTransclude", {
                    get: function () {
                        return this._ngTransclude;
                    },
                    set: function (templateRef) {
                        this._ngTransclude = templateRef;
                        if (templateRef) {
                            this.viewRef.createEmbeddedView(templateRef);
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                NgTransclude = __decorate([
                    core_1.Directive({
                        selector: '[ngTransclude]',
                        properties: ['ngTransclude']
                    }),
                    __param(0, core_1.Inject(core_1.ViewContainerRef)), 
                    __metadata('design:paramtypes', [core_1.ViewContainerRef])
                ], NgTransclude);
                return NgTransclude;
            }());
            exports_1("NgTransclude", NgTransclude);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImF1dG9jb21wbGV0ZS9JQXR0cmlidXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1lBYUE7Z0JBY0ksc0JBQTZDLE9BQXdCO29CQUF4QixZQUFPLEdBQVAsT0FBTyxDQUFpQjtnQkFDckUsQ0FBQztnQkFaRCxzQkFBWSxzQ0FBWTt5QkFPeEI7d0JBQ0ksTUFBTSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUM7b0JBQzlCLENBQUM7eUJBVEQsVUFBeUIsV0FBdUI7d0JBQzVDLElBQUksQ0FBQyxhQUFhLEdBQUcsV0FBVyxDQUFDO3dCQUNqQyxFQUFFLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDOzRCQUNkLElBQUksQ0FBQyxPQUFPLENBQUMsa0JBQWtCLENBQUMsV0FBVyxDQUFDLENBQUM7d0JBQ2pELENBQUM7b0JBQ0wsQ0FBQzs7O21CQUFBO2dCQVpMO29CQUFDLGdCQUFTLENBQUM7d0JBQ1AsUUFBUSxFQUFFLGdCQUFnQjt3QkFDMUIsVUFBVSxFQUFFLENBQUMsY0FBYyxDQUFDO3FCQUMvQixDQUFDOytCQWVlLGFBQU0sQ0FBQyx1QkFBZ0IsQ0FBQzs7Z0NBZnZDO2dCQWlCRixtQkFBQztZQUFELENBaEJBLEFBZ0JDLElBQUE7WUFoQkQsdUNBZ0JDLENBQUEiLCJmaWxlIjoiYXV0b2NvbXBsZXRlL0lBdHRyaWJ1dGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcclxuICogYm9vdHN0cmFwXHJcbiAqL1xyXG5pbXBvcnQge0RpcmVjdGl2ZSwgVGVtcGxhdGVSZWYsIFZpZXdDb250YWluZXJSZWYsIEluamVjdH0gZnJvbSAnYW5ndWxhcjIvY29yZSc7XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIElBdHRyaWJ1dGUge1xyXG4gICAgW2tleTogc3RyaW5nXTogYW55O1xyXG59XHJcblxyXG5ARGlyZWN0aXZlKHtcclxuICAgIHNlbGVjdG9yOiAnW25nVHJhbnNjbHVkZV0nLFxyXG4gICAgcHJvcGVydGllczogWyduZ1RyYW5zY2x1ZGUnXVxyXG59KVxyXG5leHBvcnQgY2xhc3MgTmdUcmFuc2NsdWRlIHtcclxuICAgIHByaXZhdGUgX25nVHJhbnNjbHVkZTogVGVtcGxhdGVSZWY7XHJcblxyXG4gICAgcHJpdmF0ZSBzZXQgbmdUcmFuc2NsdWRlKHRlbXBsYXRlUmVmOlRlbXBsYXRlUmVmKSB7XHJcbiAgICAgICAgdGhpcy5fbmdUcmFuc2NsdWRlID0gdGVtcGxhdGVSZWY7XHJcbiAgICAgICAgaWYgKHRlbXBsYXRlUmVmKSB7XHJcbiAgICAgICAgICAgIHRoaXMudmlld1JlZi5jcmVhdGVFbWJlZGRlZFZpZXcodGVtcGxhdGVSZWYpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIGdldCBuZ1RyYW5zY2x1ZGUoKSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX25nVHJhbnNjbHVkZTtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdHJ1Y3RvcihASW5qZWN0KFZpZXdDb250YWluZXJSZWYpIHB1YmxpYyB2aWV3UmVmOlZpZXdDb250YWluZXJSZWYpIHtcclxuICAgIH1cclxufVxyXG4iXX0=
