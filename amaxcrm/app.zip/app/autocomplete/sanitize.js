System.register(['./latin-map'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var latin_map_1;
    var AutocompleteUtils;
    return {
        setters:[
            function (latin_map_1_1) {
                latin_map_1 = latin_map_1_1;
            }],
        execute: function() {
            AutocompleteUtils = (function () {
                function AutocompleteUtils() {
                }
                AutocompleteUtils.latinize = function (str) {
                    return str.replace(/[^A-Za-z0-9\[\] ]/g, function (a) {
                        return AutocompleteUtils.latinMap[a] || a;
                    });
                };
                AutocompleteUtils.escapeRegexp = function (queryToEscape) {
                    // Regex: capture the whole query string and replace it with the string that will be used to match
                    // the results, for example if the capture is 'a' the result will be \a
                    return queryToEscape.replace(/([.?*+^$[\]\\(){}|-])/g, '\\$1');
                };
                AutocompleteUtils.tokenize = function (str, wordRegexDelimiters, phraseRegexDelimiters) {
                    if (wordRegexDelimiters === void 0) { wordRegexDelimiters = ' '; }
                    if (phraseRegexDelimiters === void 0) { phraseRegexDelimiters = ''; }
                    var regexStr = '(?:[' + phraseRegexDelimiters + '])([^' + phraseRegexDelimiters + ']+)(?:[' + phraseRegexDelimiters + '])|([^' + wordRegexDelimiters + ']+)';
                    var preTokenized = str.split(new RegExp(regexStr, 'g'));
                    var result = [];
                    var preTokenizedLength = preTokenized.length;
                    var token;
                    var replacePhraseDelimiters = new RegExp('[' + phraseRegexDelimiters + ']+', 'g');
                    for (var i = 0; i < preTokenizedLength; i += 1) {
                        token = preTokenized[i];
                        if (token && token.length && token !== wordRegexDelimiters) {
                            result.push(token.replace(replacePhraseDelimiters, ''));
                        }
                    }
                    return result;
                };
                AutocompleteUtils.latinMap = latin_map_1.latinMap;
                return AutocompleteUtils;
            }());
            exports_1("AutocompleteUtils", AutocompleteUtils);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImF1dG9jb21wbGV0ZS9zYW5pdGl6ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztZQUNBO2dCQUFBO2dCQWdDQSxDQUFDO2dCQTdCaUIsMEJBQVEsR0FBdEIsVUFBdUIsR0FBVTtvQkFDN0IsTUFBTSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsb0JBQW9CLEVBQUUsVUFBVSxDQUFDO3dCQUNoRCxNQUFNLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFDOUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ1AsQ0FBQztnQkFFYSw4QkFBWSxHQUExQixVQUEyQixhQUFvQjtvQkFDM0Msa0dBQWtHO29CQUNsRyx1RUFBdUU7b0JBQ3ZFLE1BQU0sQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLHdCQUF3QixFQUFFLE1BQU0sQ0FBQyxDQUFDO2dCQUNuRSxDQUFDO2dCQUVhLDBCQUFRLEdBQXRCLFVBQXVCLEdBQVUsRUFBRSxtQkFBZ0MsRUFBRSxxQkFBaUM7b0JBQW5FLG1DQUFnQyxHQUFoQyx5QkFBZ0M7b0JBQUUscUNBQWlDLEdBQWpDLDBCQUFpQztvQkFDbEcsSUFBSSxRQUFRLEdBQVUsTUFBTSxHQUFHLHFCQUFxQixHQUFHLE9BQU8sR0FBRyxxQkFBcUIsR0FBRyxTQUFTLEdBQUcscUJBQXFCLEdBQUcsUUFBUSxHQUFHLG1CQUFtQixHQUFHLEtBQUssQ0FBQztvQkFDcEssSUFBSSxZQUFZLEdBQWlCLEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSSxNQUFNLENBQUMsUUFBUSxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUM7b0JBQ3RFLElBQUksTUFBTSxHQUFpQixFQUFFLENBQUM7b0JBQzlCLElBQUksa0JBQWtCLEdBQVUsWUFBWSxDQUFDLE1BQU0sQ0FBQztvQkFDcEQsSUFBSSxLQUFZLENBQUM7b0JBQ2pCLElBQUksdUJBQXVCLEdBQUcsSUFBSSxNQUFNLENBQUMsR0FBRyxHQUFHLHFCQUFxQixHQUFHLElBQUksRUFBRSxHQUFHLENBQUMsQ0FBQztvQkFFbEYsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxrQkFBa0IsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7d0JBQzdDLEtBQUssR0FBRyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ3hCLEVBQUUsQ0FBQyxDQUFDLEtBQUssSUFBSSxLQUFLLENBQUMsTUFBTSxJQUFJLEtBQUssS0FBSyxtQkFBbUIsQ0FBQyxDQUFDLENBQUM7NEJBQ3pELE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyx1QkFBdUIsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDO3dCQUM1RCxDQUFDO29CQUNMLENBQUM7b0JBRUQsTUFBTSxDQUFDLE1BQU0sQ0FBQztnQkFDbEIsQ0FBQztnQkE5Qk0sMEJBQVEsR0FBTyxvQkFBUSxDQUFDO2dCQStCbkMsd0JBQUM7WUFBRCxDQWhDQSxBQWdDQyxJQUFBO1lBaENELGlEQWdDQyxDQUFBIiwiZmlsZSI6ImF1dG9jb21wbGV0ZS9zYW5pdGl6ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGxhdGluTWFwIH0gZnJvbSAnLi9sYXRpbi1tYXAnO1xyXG5leHBvcnQgY2xhc3MgQXV0b2NvbXBsZXRlVXRpbHMge1xyXG4gICAgc3RhdGljIGxhdGluTWFwOmFueSA9IGxhdGluTWFwO1xyXG5cclxuICAgIHB1YmxpYyBzdGF0aWMgbGF0aW5pemUoc3RyOnN0cmluZykge1xyXG4gICAgICAgIHJldHVybiBzdHIucmVwbGFjZSgvW15BLVphLXowLTlcXFtcXF0gXS9nLCBmdW5jdGlvbiAoYSkge1xyXG4gICAgICAgICAgICByZXR1cm4gQXV0b2NvbXBsZXRlVXRpbHMubGF0aW5NYXBbYV0gfHwgYTtcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc3RhdGljIGVzY2FwZVJlZ2V4cChxdWVyeVRvRXNjYXBlOnN0cmluZykge1xyXG4gICAgICAgIC8vIFJlZ2V4OiBjYXB0dXJlIHRoZSB3aG9sZSBxdWVyeSBzdHJpbmcgYW5kIHJlcGxhY2UgaXQgd2l0aCB0aGUgc3RyaW5nIHRoYXQgd2lsbCBiZSB1c2VkIHRvIG1hdGNoXHJcbiAgICAgICAgLy8gdGhlIHJlc3VsdHMsIGZvciBleGFtcGxlIGlmIHRoZSBjYXB0dXJlIGlzICdhJyB0aGUgcmVzdWx0IHdpbGwgYmUgXFxhXHJcbiAgICAgICAgcmV0dXJuIHF1ZXJ5VG9Fc2NhcGUucmVwbGFjZSgvKFsuPyorXiRbXFxdXFxcXCgpe318LV0pL2csICdcXFxcJDEnKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc3RhdGljIHRva2VuaXplKHN0cjpzdHJpbmcsIHdvcmRSZWdleERlbGltaXRlcnM6c3RyaW5nID0gJyAnLCBwaHJhc2VSZWdleERlbGltaXRlcnM6c3RyaW5nID0gJycpOkFycmF5PHN0cmluZz4ge1xyXG4gICAgICAgIGxldCByZWdleFN0cjpzdHJpbmcgPSAnKD86WycgKyBwaHJhc2VSZWdleERlbGltaXRlcnMgKyAnXSkoW14nICsgcGhyYXNlUmVnZXhEZWxpbWl0ZXJzICsgJ10rKSg/OlsnICsgcGhyYXNlUmVnZXhEZWxpbWl0ZXJzICsgJ10pfChbXicgKyB3b3JkUmVnZXhEZWxpbWl0ZXJzICsgJ10rKSc7XHJcbiAgICAgICAgbGV0IHByZVRva2VuaXplZDpBcnJheTxzdHJpbmc+ID0gc3RyLnNwbGl0KG5ldyBSZWdFeHAocmVnZXhTdHIsICdnJykpO1xyXG4gICAgICAgIGxldCByZXN1bHQ6QXJyYXk8c3RyaW5nPiA9IFtdO1xyXG4gICAgICAgIGxldCBwcmVUb2tlbml6ZWRMZW5ndGg6bnVtYmVyID0gcHJlVG9rZW5pemVkLmxlbmd0aDtcclxuICAgICAgICBsZXQgdG9rZW46c3RyaW5nO1xyXG4gICAgICAgIGxldCByZXBsYWNlUGhyYXNlRGVsaW1pdGVycyA9IG5ldyBSZWdFeHAoJ1snICsgcGhyYXNlUmVnZXhEZWxpbWl0ZXJzICsgJ10rJywgJ2cnKTtcclxuXHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBwcmVUb2tlbml6ZWRMZW5ndGg7IGkgKz0gMSkge1xyXG4gICAgICAgICAgICB0b2tlbiA9IHByZVRva2VuaXplZFtpXTtcclxuICAgICAgICAgICAgaWYgKHRva2VuICYmIHRva2VuLmxlbmd0aCAmJiB0b2tlbiAhPT0gd29yZFJlZ2V4RGVsaW1pdGVycykge1xyXG4gICAgICAgICAgICAgICAgcmVzdWx0LnB1c2godG9rZW4ucmVwbGFjZShyZXBsYWNlUGhyYXNlRGVsaW1pdGVycywgJycpKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcclxuICAgIH1cclxufSJdfQ==
