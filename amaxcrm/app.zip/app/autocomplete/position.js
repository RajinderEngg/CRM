System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var PositionService, positionService;
    return {
        setters:[],
        execute: function() {
            PositionService = (function () {
                function PositionService() {
                }
                Object.defineProperty(PositionService.prototype, "window", {
                    get: function () {
                        return window;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(PositionService.prototype, "document", {
                    get: function () {
                        return window.document;
                    },
                    enumerable: true,
                    configurable: true
                });
                PositionService.prototype.getStyle = function (nativeEl, cssProp) {
                    // IE
                    if (nativeEl.currentStyle) {
                        return nativeEl.currentStyle[cssProp];
                    }
                    if (this.window.getComputedStyle) {
                        return this.window.getComputedStyle(nativeEl)[cssProp];
                    }
                    // finally try and get inline style
                    return nativeEl.style[cssProp];
                };
                /**
                 * Checks if a given element is statically positioned
                 * @param nativeEl - raw DOM element
                 */
                PositionService.prototype.isStaticPositioned = function (nativeEl) {
                    return (this.getStyle(nativeEl, 'position') || 'static') === 'static';
                };
                /**
                 * returns the closest, non-statically positioned parentOffset of a given element
                 * @param nativeEl
                 */
                PositionService.prototype.parentOffsetEl = function (nativeEl) {
                    var offsetParent = nativeEl.offsetParent || this.document;
                    while (offsetParent && offsetParent !== this.document &&
                        this.isStaticPositioned(offsetParent)) {
                        offsetParent = offsetParent.offsetParent;
                    }
                    return offsetParent || this.document;
                };
                ;
                /**
                 * Provides read-only equivalent of jQuery's position function:
                 * http://api.jquery.com/position/
                 */
                PositionService.prototype.position = function (nativeEl) {
                    var elBCR = this.offset(nativeEl);
                    var offsetParentBCR = { top: 0, left: 0 };
                    var offsetParentEl = this.parentOffsetEl(nativeEl);
                    if (offsetParentEl !== this.document) {
                        offsetParentBCR = this.offset(offsetParentEl);
                        offsetParentBCR.top += offsetParentEl.clientTop - offsetParentEl.scrollTop;
                        offsetParentBCR.left += offsetParentEl.clientLeft - offsetParentEl.scrollLeft;
                    }
                    var boundingClientRect = nativeEl.getBoundingClientRect();
                    return {
                        width: boundingClientRect.width || nativeEl.offsetWidth,
                        height: boundingClientRect.height || nativeEl.offsetHeight,
                        top: elBCR.top - offsetParentBCR.top,
                        left: elBCR.left - offsetParentBCR.left
                    };
                };
                /**
                 * Provides read-only equivalent of jQuery's offset function:
                 * http://api.jquery.com/offset/
                 */
                PositionService.prototype.offset = function (nativeEl) {
                    var boundingClientRect = nativeEl.getBoundingClientRect();
                    return {
                        width: boundingClientRect.width || nativeEl.offsetWidth,
                        height: boundingClientRect.height || nativeEl.offsetHeight,
                        top: boundingClientRect.top + (this.window.pageYOffset || this.document.documentElement.scrollTop),
                        left: boundingClientRect.left + (this.window.pageXOffset || this.document.documentElement.scrollLeft)
                    };
                };
                /**
                 * Provides coordinates for the targetEl in relation to hostEl
                 */
                PositionService.prototype.positionElements = function (hostEl, targetEl, positionStr, appendToBody) {
                    var positionStrParts = positionStr.split('-');
                    var pos0 = positionStrParts[0];
                    var pos1 = positionStrParts[1] || 'center';
                    var hostElPos = appendToBody ?
                        this.offset(hostEl) :
                        this.position(hostEl);
                    var targetElWidth = targetEl.offsetWidth;
                    var targetElHeight = targetEl.offsetHeight;
                    var shiftWidth = {
                        center: function () {
                            return hostElPos.left + hostElPos.width / 2 - targetElWidth / 2;
                        },
                        left: function () {
                            return hostElPos.left;
                        },
                        right: function () {
                            return hostElPos.left + hostElPos.width;
                        }
                    };
                    var shiftHeight = {
                        center: function () {
                            return hostElPos.top + hostElPos.height / 2 - targetElHeight / 2;
                        },
                        top: function () {
                            return hostElPos.top;
                        },
                        bottom: function () {
                            return hostElPos.top + hostElPos.height;
                        }
                    };
                    var targetElPos;
                    switch (pos0) {
                        case 'right':
                            targetElPos = {
                                top: shiftHeight[pos1](),
                                left: shiftWidth[pos0]()
                            };
                            break;
                        case 'left':
                            targetElPos = {
                                top: shiftHeight[pos1](),
                                left: hostElPos.left - targetElWidth
                            };
                            break;
                        case 'bottom':
                            targetElPos = {
                                top: shiftHeight[pos0](),
                                left: shiftWidth[pos1]()
                            };
                            break;
                        default:
                            targetElPos = {
                                top: hostElPos.top - targetElHeight,
                                left: shiftWidth[pos1]()
                            };
                            break;
                    }
                    return targetElPos;
                };
                return PositionService;
            }());
            exports_1("PositionService", PositionService);
            exports_1("positionService", positionService = new PositionService());
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImF1dG9jb21wbGV0ZS9wb3NpdGlvbi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7eUJBZ0thLGVBQWU7Ozs7WUF2SjVCO2dCQUFBO2dCQXFKQSxDQUFDO2dCQXBKRyxzQkFBWSxtQ0FBTTt5QkFBbEI7d0JBQ0ksTUFBTSxDQUFDLE1BQU0sQ0FBQztvQkFDbEIsQ0FBQzs7O21CQUFBO2dCQUVELHNCQUFZLHFDQUFRO3lCQUFwQjt3QkFDSSxNQUFNLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQztvQkFDM0IsQ0FBQzs7O21CQUFBO2dCQUVPLGtDQUFRLEdBQWhCLFVBQWlCLFFBQVksRUFBRSxPQUFjO29CQUN6QyxLQUFLO29CQUNMLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDO3dCQUN4QixNQUFNLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQztvQkFDMUMsQ0FBQztvQkFFRCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQzt3QkFDL0IsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7b0JBQzNELENBQUM7b0JBQ0QsbUNBQW1DO29CQUNuQyxNQUFNLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQztnQkFDbkMsQ0FBQztnQkFHRDs7O21CQUdHO2dCQUNLLDRDQUFrQixHQUExQixVQUEyQixRQUFZO29CQUNuQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRSxVQUFVLENBQUMsSUFBSSxRQUFRLENBQUUsS0FBSyxRQUFRLENBQUM7Z0JBQzNFLENBQUM7Z0JBR0Q7OzttQkFHRztnQkFDSyx3Q0FBYyxHQUF0QixVQUF1QixRQUFZO29CQUMvQixJQUFJLFlBQVksR0FBRyxRQUFRLENBQUMsWUFBWSxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUM7b0JBQzFELE9BQU8sWUFBWSxJQUFJLFlBQVksS0FBSyxJQUFJLENBQUMsUUFBUTt3QkFDckQsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUM7d0JBQ3BDLFlBQVksR0FBRyxZQUFZLENBQUMsWUFBWSxDQUFDO29CQUM3QyxDQUFDO29CQUNELE1BQU0sQ0FBQyxZQUFZLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQztnQkFDekMsQ0FBQzs7Z0JBRUQ7OzttQkFHRztnQkFDSSxrQ0FBUSxHQUFmLFVBQWdCLFFBQVk7b0JBQ3hCLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7b0JBQ2xDLElBQUksZUFBZSxHQUFHLEVBQUMsR0FBRyxFQUFFLENBQUMsRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFDLENBQUM7b0JBQ3hDLElBQUksY0FBYyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLENBQUM7b0JBQ25ELEVBQUUsQ0FBQyxDQUFDLGNBQWMsS0FBSyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQzt3QkFDbkMsZUFBZSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLENBQUM7d0JBQzlDLGVBQWUsQ0FBQyxHQUFHLElBQUksY0FBYyxDQUFDLFNBQVMsR0FBRyxjQUFjLENBQUMsU0FBUyxDQUFDO3dCQUMzRSxlQUFlLENBQUMsSUFBSSxJQUFJLGNBQWMsQ0FBQyxVQUFVLEdBQUcsY0FBYyxDQUFDLFVBQVUsQ0FBQztvQkFDbEYsQ0FBQztvQkFFRCxJQUFJLGtCQUFrQixHQUFHLFFBQVEsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO29CQUMxRCxNQUFNLENBQUM7d0JBQ0gsS0FBSyxFQUFFLGtCQUFrQixDQUFDLEtBQUssSUFBSSxRQUFRLENBQUMsV0FBVzt3QkFDdkQsTUFBTSxFQUFFLGtCQUFrQixDQUFDLE1BQU0sSUFBSSxRQUFRLENBQUMsWUFBWTt3QkFDMUQsR0FBRyxFQUFFLEtBQUssQ0FBQyxHQUFHLEdBQUcsZUFBZSxDQUFDLEdBQUc7d0JBQ3BDLElBQUksRUFBRSxLQUFLLENBQUMsSUFBSSxHQUFHLGVBQWUsQ0FBQyxJQUFJO3FCQUMxQyxDQUFDO2dCQUNOLENBQUM7Z0JBRUQ7OzttQkFHRztnQkFDSSxnQ0FBTSxHQUFiLFVBQWMsUUFBWTtvQkFDdEIsSUFBSSxrQkFBa0IsR0FBRyxRQUFRLENBQUMscUJBQXFCLEVBQUUsQ0FBQztvQkFDMUQsTUFBTSxDQUFDO3dCQUNILEtBQUssRUFBRSxrQkFBa0IsQ0FBQyxLQUFLLElBQUksUUFBUSxDQUFDLFdBQVc7d0JBQ3ZELE1BQU0sRUFBRSxrQkFBa0IsQ0FBQyxNQUFNLElBQUksUUFBUSxDQUFDLFlBQVk7d0JBQzFELEdBQUcsRUFBRSxrQkFBa0IsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLGVBQWUsQ0FBQyxTQUFTLENBQUM7d0JBQ2xHLElBQUksRUFBRSxrQkFBa0IsQ0FBQyxJQUFJLEdBQUcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLGVBQWUsQ0FBQyxVQUFVLENBQUM7cUJBQ3hHLENBQUM7Z0JBQ04sQ0FBQztnQkFFRDs7bUJBRUc7Z0JBQ0ksMENBQWdCLEdBQXZCLFVBQXdCLE1BQVUsRUFBRSxRQUFZLEVBQUUsV0FBZSxFQUFFLFlBQWdCO29CQUMvRSxJQUFJLGdCQUFnQixHQUFHLFdBQVcsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7b0JBQzlDLElBQUksSUFBSSxHQUFHLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUMvQixJQUFJLElBQUksR0FBRyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsSUFBSSxRQUFRLENBQUM7b0JBQzNDLElBQUksU0FBUyxHQUFHLFlBQVk7d0JBQ3hCLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO3dCQUNuQixJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUMxQixJQUFJLGFBQWEsR0FBRyxRQUFRLENBQUMsV0FBVyxDQUFDO29CQUN6QyxJQUFJLGNBQWMsR0FBRyxRQUFRLENBQUMsWUFBWSxDQUFDO29CQUUzQyxJQUFJLFVBQVUsR0FBYzt3QkFDeEIsTUFBTSxFQUFFOzRCQUNKLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxHQUFHLFNBQVMsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxHQUFHLGFBQWEsR0FBRyxDQUFDLENBQUM7d0JBQ3BFLENBQUM7d0JBQ0QsSUFBSSxFQUFFOzRCQUNGLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDO3dCQUMxQixDQUFDO3dCQUNELEtBQUssRUFBRTs0QkFDSCxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksR0FBRyxTQUFTLENBQUMsS0FBSyxDQUFDO3dCQUM1QyxDQUFDO3FCQUNKLENBQUM7b0JBRUYsSUFBSSxXQUFXLEdBQWM7d0JBQ3pCLE1BQU0sRUFBRTs0QkFDSixNQUFNLENBQUMsU0FBUyxDQUFDLEdBQUcsR0FBRyxTQUFTLENBQUMsTUFBTSxHQUFHLENBQUMsR0FBRyxjQUFjLEdBQUcsQ0FBQyxDQUFDO3dCQUNyRSxDQUFDO3dCQUNELEdBQUcsRUFBRTs0QkFDRCxNQUFNLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQzt3QkFDekIsQ0FBQzt3QkFDRCxNQUFNLEVBQUU7NEJBQ0osTUFBTSxDQUFDLFNBQVMsQ0FBQyxHQUFHLEdBQUcsU0FBUyxDQUFDLE1BQU0sQ0FBQzt3QkFDNUMsQ0FBQztxQkFDSixDQUFDO29CQUVGLElBQUksV0FBdUMsQ0FBQztvQkFDNUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQzt3QkFDWCxLQUFLLE9BQU87NEJBQ1IsV0FBVyxHQUFHO2dDQUNWLEdBQUcsRUFBRSxXQUFXLENBQUMsSUFBSSxDQUFDLEVBQUU7Z0NBQ3hCLElBQUksRUFBRSxVQUFVLENBQUMsSUFBSSxDQUFDLEVBQUU7NkJBQzNCLENBQUM7NEJBQ0YsS0FBSyxDQUFDO3dCQUNWLEtBQUssTUFBTTs0QkFDUCxXQUFXLEdBQUc7Z0NBQ1YsR0FBRyxFQUFFLFdBQVcsQ0FBQyxJQUFJLENBQUMsRUFBRTtnQ0FDeEIsSUFBSSxFQUFFLFNBQVMsQ0FBQyxJQUFJLEdBQUcsYUFBYTs2QkFDdkMsQ0FBQzs0QkFDRixLQUFLLENBQUM7d0JBQ1YsS0FBSyxRQUFROzRCQUNULFdBQVcsR0FBRztnQ0FDVixHQUFHLEVBQUUsV0FBVyxDQUFDLElBQUksQ0FBQyxFQUFFO2dDQUN4QixJQUFJLEVBQUUsVUFBVSxDQUFDLElBQUksQ0FBQyxFQUFFOzZCQUMzQixDQUFDOzRCQUNGLEtBQUssQ0FBQzt3QkFDVjs0QkFDSSxXQUFXLEdBQUc7Z0NBQ1YsR0FBRyxFQUFFLFNBQVMsQ0FBQyxHQUFHLEdBQUcsY0FBYztnQ0FDbkMsSUFBSSxFQUFFLFVBQVUsQ0FBQyxJQUFJLENBQUMsRUFBRTs2QkFDM0IsQ0FBQzs0QkFDRixLQUFLLENBQUM7b0JBQ2QsQ0FBQztvQkFFRCxNQUFNLENBQUMsV0FBVyxDQUFDO2dCQUN2QixDQUFDO2dCQUNMLHNCQUFDO1lBQUQsQ0FySkEsQUFxSkMsSUFBQTtZQXJKRCw2Q0FxSkMsQ0FBQTtZQUVZLDZCQUFBLGVBQWUsR0FBRyxJQUFJLGVBQWUsRUFBRSxDQUFBLENBQUMiLCJmaWxlIjoiYXV0b2NvbXBsZXRlL3Bvc2l0aW9uLmpzIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXHJcbiAqIGJvb3RzdHJhcFxyXG4gKi9cclxuaW1wb3J0IHtcclxuICAgIEluamVjdGFibGUsXHJcbiAgICBFbGVtZW50UmVmXHJcbn0gZnJvbSAnYW5ndWxhcjIvY29yZSc7XHJcbmltcG9ydCB7SUF0dHJpYnV0ZX0gZnJvbSAnLi9JQXR0cmlidXRlJztcclxuXHJcbmV4cG9ydCBjbGFzcyBQb3NpdGlvblNlcnZpY2Uge1xyXG4gICAgcHJpdmF0ZSBnZXQgd2luZG93KCk6YW55IHtcclxuICAgICAgICByZXR1cm4gd2luZG93O1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgZ2V0IGRvY3VtZW50KCk6YW55IHtcclxuICAgICAgICByZXR1cm4gd2luZG93LmRvY3VtZW50O1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgZ2V0U3R5bGUobmF0aXZlRWw6YW55LCBjc3NQcm9wOnN0cmluZyk6YW55IHtcclxuICAgICAgICAvLyBJRVxyXG4gICAgICAgIGlmIChuYXRpdmVFbC5jdXJyZW50U3R5bGUpIHtcclxuICAgICAgICAgICAgcmV0dXJuIG5hdGl2ZUVsLmN1cnJlbnRTdHlsZVtjc3NQcm9wXTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICh0aGlzLndpbmRvdy5nZXRDb21wdXRlZFN0eWxlKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLndpbmRvdy5nZXRDb21wdXRlZFN0eWxlKG5hdGl2ZUVsKVtjc3NQcm9wXTtcclxuICAgICAgICB9XHJcbiAgICAgICAgLy8gZmluYWxseSB0cnkgYW5kIGdldCBpbmxpbmUgc3R5bGVcclxuICAgICAgICByZXR1cm4gbmF0aXZlRWwuc3R5bGVbY3NzUHJvcF07XHJcbiAgICB9XHJcblxyXG5cclxuICAgIC8qKlxyXG4gICAgICogQ2hlY2tzIGlmIGEgZ2l2ZW4gZWxlbWVudCBpcyBzdGF0aWNhbGx5IHBvc2l0aW9uZWRcclxuICAgICAqIEBwYXJhbSBuYXRpdmVFbCAtIHJhdyBET00gZWxlbWVudFxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIGlzU3RhdGljUG9zaXRpb25lZChuYXRpdmVFbDphbnkpOmFueSB7XHJcbiAgICAgICAgcmV0dXJuICh0aGlzLmdldFN0eWxlKG5hdGl2ZUVsLCAncG9zaXRpb24nKSB8fCAnc3RhdGljJyApID09PSAnc3RhdGljJztcclxuICAgIH1cclxuXHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiByZXR1cm5zIHRoZSBjbG9zZXN0LCBub24tc3RhdGljYWxseSBwb3NpdGlvbmVkIHBhcmVudE9mZnNldCBvZiBhIGdpdmVuIGVsZW1lbnRcclxuICAgICAqIEBwYXJhbSBuYXRpdmVFbFxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIHBhcmVudE9mZnNldEVsKG5hdGl2ZUVsOmFueSkge1xyXG4gICAgICAgIGxldCBvZmZzZXRQYXJlbnQgPSBuYXRpdmVFbC5vZmZzZXRQYXJlbnQgfHwgdGhpcy5kb2N1bWVudDtcclxuICAgICAgICB3aGlsZSAob2Zmc2V0UGFyZW50ICYmIG9mZnNldFBhcmVudCAhPT0gdGhpcy5kb2N1bWVudCAmJlxyXG4gICAgICAgIHRoaXMuaXNTdGF0aWNQb3NpdGlvbmVkKG9mZnNldFBhcmVudCkpIHtcclxuICAgICAgICAgICAgb2Zmc2V0UGFyZW50ID0gb2Zmc2V0UGFyZW50Lm9mZnNldFBhcmVudDtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIG9mZnNldFBhcmVudCB8fCB0aGlzLmRvY3VtZW50O1xyXG4gICAgfTtcclxuXHJcbiAgICAvKipcclxuICAgICAqIFByb3ZpZGVzIHJlYWQtb25seSBlcXVpdmFsZW50IG9mIGpRdWVyeSdzIHBvc2l0aW9uIGZ1bmN0aW9uOlxyXG4gICAgICogaHR0cDovL2FwaS5qcXVlcnkuY29tL3Bvc2l0aW9uL1xyXG4gICAgICovXHJcbiAgICBwdWJsaWMgcG9zaXRpb24obmF0aXZlRWw6YW55KTp7d2lkdGg6IG51bWJlciwgaGVpZ2h0OiBudW1iZXIsIHRvcDogbnVtYmVyLCBsZWZ0OiBudW1iZXJ9IHtcclxuICAgICAgICBsZXQgZWxCQ1IgPSB0aGlzLm9mZnNldChuYXRpdmVFbCk7XHJcbiAgICAgICAgbGV0IG9mZnNldFBhcmVudEJDUiA9IHt0b3A6IDAsIGxlZnQ6IDB9O1xyXG4gICAgICAgIGxldCBvZmZzZXRQYXJlbnRFbCA9IHRoaXMucGFyZW50T2Zmc2V0RWwobmF0aXZlRWwpO1xyXG4gICAgICAgIGlmIChvZmZzZXRQYXJlbnRFbCAhPT0gdGhpcy5kb2N1bWVudCkge1xyXG4gICAgICAgICAgICBvZmZzZXRQYXJlbnRCQ1IgPSB0aGlzLm9mZnNldChvZmZzZXRQYXJlbnRFbCk7XHJcbiAgICAgICAgICAgIG9mZnNldFBhcmVudEJDUi50b3AgKz0gb2Zmc2V0UGFyZW50RWwuY2xpZW50VG9wIC0gb2Zmc2V0UGFyZW50RWwuc2Nyb2xsVG9wO1xyXG4gICAgICAgICAgICBvZmZzZXRQYXJlbnRCQ1IubGVmdCArPSBvZmZzZXRQYXJlbnRFbC5jbGllbnRMZWZ0IC0gb2Zmc2V0UGFyZW50RWwuc2Nyb2xsTGVmdDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCBib3VuZGluZ0NsaWVudFJlY3QgPSBuYXRpdmVFbC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICB3aWR0aDogYm91bmRpbmdDbGllbnRSZWN0LndpZHRoIHx8IG5hdGl2ZUVsLm9mZnNldFdpZHRoLFxyXG4gICAgICAgICAgICBoZWlnaHQ6IGJvdW5kaW5nQ2xpZW50UmVjdC5oZWlnaHQgfHwgbmF0aXZlRWwub2Zmc2V0SGVpZ2h0LFxyXG4gICAgICAgICAgICB0b3A6IGVsQkNSLnRvcCAtIG9mZnNldFBhcmVudEJDUi50b3AsXHJcbiAgICAgICAgICAgIGxlZnQ6IGVsQkNSLmxlZnQgLSBvZmZzZXRQYXJlbnRCQ1IubGVmdFxyXG4gICAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBQcm92aWRlcyByZWFkLW9ubHkgZXF1aXZhbGVudCBvZiBqUXVlcnkncyBvZmZzZXQgZnVuY3Rpb246XHJcbiAgICAgKiBodHRwOi8vYXBpLmpxdWVyeS5jb20vb2Zmc2V0L1xyXG4gICAgICovXHJcbiAgICBwdWJsaWMgb2Zmc2V0KG5hdGl2ZUVsOmFueSk6e3dpZHRoOiBudW1iZXIsIGhlaWdodDogbnVtYmVyLCB0b3A6IG51bWJlciwgbGVmdDogbnVtYmVyfSB7XHJcbiAgICAgICAgbGV0IGJvdW5kaW5nQ2xpZW50UmVjdCA9IG5hdGl2ZUVsLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIHdpZHRoOiBib3VuZGluZ0NsaWVudFJlY3Qud2lkdGggfHwgbmF0aXZlRWwub2Zmc2V0V2lkdGgsXHJcbiAgICAgICAgICAgIGhlaWdodDogYm91bmRpbmdDbGllbnRSZWN0LmhlaWdodCB8fCBuYXRpdmVFbC5vZmZzZXRIZWlnaHQsXHJcbiAgICAgICAgICAgIHRvcDogYm91bmRpbmdDbGllbnRSZWN0LnRvcCArICh0aGlzLndpbmRvdy5wYWdlWU9mZnNldCB8fCB0aGlzLmRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5zY3JvbGxUb3ApLFxyXG4gICAgICAgICAgICBsZWZ0OiBib3VuZGluZ0NsaWVudFJlY3QubGVmdCArICh0aGlzLndpbmRvdy5wYWdlWE9mZnNldCB8fCB0aGlzLmRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5zY3JvbGxMZWZ0KVxyXG4gICAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBQcm92aWRlcyBjb29yZGluYXRlcyBmb3IgdGhlIHRhcmdldEVsIGluIHJlbGF0aW9uIHRvIGhvc3RFbFxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgcG9zaXRpb25FbGVtZW50cyhob3N0RWw6YW55LCB0YXJnZXRFbDphbnksIHBvc2l0aW9uU3RyOmFueSwgYXBwZW5kVG9Cb2R5OmFueSk6e3RvcDogbnVtYmVyLCBsZWZ0OiBudW1iZXJ9IHtcclxuICAgICAgICBsZXQgcG9zaXRpb25TdHJQYXJ0cyA9IHBvc2l0aW9uU3RyLnNwbGl0KCctJyk7XHJcbiAgICAgICAgbGV0IHBvczAgPSBwb3NpdGlvblN0clBhcnRzWzBdO1xyXG4gICAgICAgIGxldCBwb3MxID0gcG9zaXRpb25TdHJQYXJ0c1sxXSB8fCAnY2VudGVyJztcclxuICAgICAgICBsZXQgaG9zdEVsUG9zID0gYXBwZW5kVG9Cb2R5ID9cclxuICAgICAgICAgICAgdGhpcy5vZmZzZXQoaG9zdEVsKSA6XHJcbiAgICAgICAgICAgIHRoaXMucG9zaXRpb24oaG9zdEVsKTtcclxuICAgICAgICBsZXQgdGFyZ2V0RWxXaWR0aCA9IHRhcmdldEVsLm9mZnNldFdpZHRoO1xyXG4gICAgICAgIGxldCB0YXJnZXRFbEhlaWdodCA9IHRhcmdldEVsLm9mZnNldEhlaWdodDtcclxuXHJcbiAgICAgICAgbGV0IHNoaWZ0V2lkdGg6SUF0dHJpYnV0ZSA9IHtcclxuICAgICAgICAgICAgY2VudGVyOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gaG9zdEVsUG9zLmxlZnQgKyBob3N0RWxQb3Mud2lkdGggLyAyIC0gdGFyZ2V0RWxXaWR0aCAvIDI7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGxlZnQ6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBob3N0RWxQb3MubGVmdDtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgcmlnaHQ6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBob3N0RWxQb3MubGVmdCArIGhvc3RFbFBvcy53aWR0aDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIGxldCBzaGlmdEhlaWdodDpJQXR0cmlidXRlID0ge1xyXG4gICAgICAgICAgICBjZW50ZXI6IGZ1bmN0aW9uICgpOm51bWJlciB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gaG9zdEVsUG9zLnRvcCArIGhvc3RFbFBvcy5oZWlnaHQgLyAyIC0gdGFyZ2V0RWxIZWlnaHQgLyAyO1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB0b3A6IGZ1bmN0aW9uICgpOm51bWJlciB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gaG9zdEVsUG9zLnRvcDtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgYm90dG9tOiBmdW5jdGlvbiAoKTpudW1iZXIge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGhvc3RFbFBvcy50b3AgKyBob3N0RWxQb3MuaGVpZ2h0O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgbGV0IHRhcmdldEVsUG9zOnt0b3A6IG51bWJlciwgbGVmdDogbnVtYmVyfTtcclxuICAgICAgICBzd2l0Y2ggKHBvczApIHtcclxuICAgICAgICAgICAgY2FzZSAncmlnaHQnOlxyXG4gICAgICAgICAgICAgICAgdGFyZ2V0RWxQb3MgPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdG9wOiBzaGlmdEhlaWdodFtwb3MxXSgpLFxyXG4gICAgICAgICAgICAgICAgICAgIGxlZnQ6IHNoaWZ0V2lkdGhbcG9zMF0oKVxyXG4gICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlICdsZWZ0JzpcclxuICAgICAgICAgICAgICAgIHRhcmdldEVsUG9zID0ge1xyXG4gICAgICAgICAgICAgICAgICAgIHRvcDogc2hpZnRIZWlnaHRbcG9zMV0oKSxcclxuICAgICAgICAgICAgICAgICAgICBsZWZ0OiBob3N0RWxQb3MubGVmdCAtIHRhcmdldEVsV2lkdGhcclxuICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgY2FzZSAnYm90dG9tJzpcclxuICAgICAgICAgICAgICAgIHRhcmdldEVsUG9zID0ge1xyXG4gICAgICAgICAgICAgICAgICAgIHRvcDogc2hpZnRIZWlnaHRbcG9zMF0oKSxcclxuICAgICAgICAgICAgICAgICAgICBsZWZ0OiBzaGlmdFdpZHRoW3BvczFdKClcclxuICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgIHRhcmdldEVsUG9zID0ge1xyXG4gICAgICAgICAgICAgICAgICAgIHRvcDogaG9zdEVsUG9zLnRvcCAtIHRhcmdldEVsSGVpZ2h0LFxyXG4gICAgICAgICAgICAgICAgICAgIGxlZnQ6IHNoaWZ0V2lkdGhbcG9zMV0oKVxyXG4gICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHRhcmdldEVsUG9zO1xyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgY29uc3QgcG9zaXRpb25TZXJ2aWNlID0gbmV3IFBvc2l0aW9uU2VydmljZSgpO1xyXG4iXX0=
