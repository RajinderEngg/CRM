System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var jsonQ;
    return {
        setters:[],
        execute: function() {
            jsonQ = (function () {
                function jsonQ(_TransationName, _SHash) {
                    this._TransationName = _TransationName;
                    this._SHash = _SHash;
                    this.jqlsArr = null;
                    this.jqlsObject = null;
                    this.jqlsObject = {
                        TransationName: _TransationName,
                        SHash: _SHash,
                        Jqls: []
                    };
                }
                jsonQ.prototype.addToList = function () {
                    if (this.jqlsArr != null) {
                        this.jqlsObject.Jqls.push(this.jqlsArr);
                        this.jqlsArr = null;
                        return true;
                    }
                    else
                        return false;
                };
                jsonQ.prototype.toJsonQObject = function () {
                    this.addToList();
                    return this.jqlsObject;
                };
                jsonQ.prototype.throwIfInvalidOperation = function (Operation) {
                    if (this.jqlsArr == null || this.jqlsArr["Type"] != Operation)
                        throw 'Invalid operation';
                };
                //For Insert Statement
                jsonQ.prototype.addNewInsert = function (TableName, PrimaryField, PKeyName) {
                    if (PKeyName === void 0) { PKeyName = ""; }
                    if (this.jqlsArr == null) {
                        this.jqlsArr = {
                            Type: 1,
                            Table: TableName,
                            PrimaryField: PrimaryField,
                            PKeyName: PKeyName,
                            Condictions: {},
                            Fields: {}
                        };
                        return true;
                    }
                    else
                        return false;
                };
                jsonQ.prototype.Insert = function (FieldName, Value) {
                    this.throwIfInvalidOperation(1);
                    this.jqlsArr["Fields"][FieldName] = {
                        Value: Value,
                        IsFkey: false
                    };
                };
                jsonQ.prototype.InsertForignKey = function (FieldName, Value) {
                    this.throwIfInvalidOperation(1);
                    this.jqlsArr["Fields"][FieldName] = {
                        Value: Value,
                        IsFkey: true
                    };
                };
                //For Update Statement
                jsonQ.prototype.addNewUpdate = function (TableName) {
                    throw 'Not Implemented';
                };
                jsonQ.prototype.Update = function (FieldName, Value) {
                    throw 'Not implemented';
                };
                //For select data fro server
                jsonQ.prototype.addNewSelect = function (TableName) {
                    if (this.jqlsArr == null) {
                        this.jqlsArr = {
                            Type: 6,
                            Table: TableName,
                            PrimaryField: "",
                            PKeyName: "",
                            Condictions: new Object(),
                            Fields: new Object()
                        };
                        return true;
                    }
                    else
                        return false;
                };
                jsonQ.prototype.select = function (FieldName, AsAlies) {
                    this.throwIfInvalidOperation(6);
                    this.jqlsArr["Fields"][FieldName] = {
                        Value: AsAlies || FieldName
                    };
                };
                jsonQ.prototype.Condiction = function (FieldName, AsAlies) {
                    this.throwIfInvalidOperation(6);
                    this.jqlsArr["Fields"][FieldName] = {
                        Value: AsAlies || FieldName
                    };
                };
                return jsonQ;
            }());
            exports_1("jsonQ", jsonQ);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImpzb25RLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7WUFBQTtnQkFJSSxlQUFvQixlQUFzQixFQUFTLE1BQWE7b0JBQTVDLG9CQUFlLEdBQWYsZUFBZSxDQUFPO29CQUFTLFdBQU0sR0FBTixNQUFNLENBQU87b0JBQzVELElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO29CQUNwQixJQUFJLENBQUMsVUFBVSxHQUFDLElBQUksQ0FBQztvQkFDckIsSUFBSSxDQUFDLFVBQVUsR0FBQzt3QkFDWixjQUFjLEVBQUUsZUFBZTt3QkFDL0IsS0FBSyxFQUFFLE1BQU07d0JBQ2IsSUFBSSxFQUFFLEVBQUU7cUJBQ1gsQ0FBQTtnQkFDTCxDQUFDO2dCQUVNLHlCQUFTLEdBQWhCO29CQUNJLEVBQUUsQ0FBQSxDQUFDLElBQUksQ0FBQyxPQUFPLElBQUUsSUFBSSxDQUFDLENBQUEsQ0FBQzt3QkFDbkIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQzt3QkFDeEMsSUFBSSxDQUFDLE9BQU8sR0FBQyxJQUFJLENBQUM7d0JBQ2xCLE1BQU0sQ0FBQyxJQUFJLENBQUM7b0JBQ2hCLENBQUM7b0JBQUEsSUFBSTt3QkFBQyxNQUFNLENBQUMsS0FBSyxDQUFDO2dCQUN2QixDQUFDO2dCQUNNLDZCQUFhLEdBQXBCO29CQUNJLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztvQkFDakIsTUFBTSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUM7Z0JBQzNCLENBQUM7Z0JBQ08sdUNBQXVCLEdBQS9CLFVBQWdDLFNBQWdCO29CQUM1QyxFQUFFLENBQUEsQ0FBQyxJQUFJLENBQUMsT0FBTyxJQUFFLElBQUksSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxJQUFFLFNBQVMsQ0FBQzt3QkFBQyxNQUFNLG1CQUFtQixDQUFDO2dCQUN4RixDQUFDO2dCQUdELHNCQUFzQjtnQkFDZiw0QkFBWSxHQUFuQixVQUFvQixTQUFnQixFQUFDLFlBQW1CLEVBQUMsUUFBa0I7b0JBQWxCLHdCQUFrQixHQUFsQixhQUFrQjtvQkFDdkUsRUFBRSxDQUFBLENBQUMsSUFBSSxDQUFDLE9BQU8sSUFBRSxJQUFJLENBQUMsQ0FBQSxDQUFDO3dCQUNuQixJQUFJLENBQUMsT0FBTyxHQUFHOzRCQUNYLElBQUksRUFBRSxDQUFDOzRCQUNQLEtBQUssRUFBRSxTQUFTOzRCQUNoQixZQUFZLEVBQUUsWUFBWTs0QkFDMUIsUUFBUSxFQUFFLFFBQVE7NEJBQ2xCLFdBQVcsRUFBRSxFQUFHOzRCQUNoQixNQUFNLEVBQUUsRUFBRzt5QkFDZCxDQUFBO3dCQUNELE1BQU0sQ0FBQyxJQUFJLENBQUM7b0JBQ2hCLENBQUM7b0JBQUEsSUFBSTt3QkFBQyxNQUFNLENBQUMsS0FBSyxDQUFDO2dCQUN2QixDQUFDO2dCQUNNLHNCQUFNLEdBQWIsVUFBYyxTQUFnQixFQUFDLEtBQVk7b0JBQ3ZDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDaEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBQzt3QkFDOUIsS0FBSyxFQUFFLEtBQUs7d0JBQ1osTUFBTSxFQUFFLEtBQUs7cUJBQ2hCLENBQUE7Z0JBQ0wsQ0FBQztnQkFDTSwrQkFBZSxHQUF0QixVQUF1QixTQUFnQixFQUFDLEtBQVk7b0JBQ2hELElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDaEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBQzt3QkFDOUIsS0FBSyxFQUFFLEtBQUs7d0JBQ1osTUFBTSxFQUFFLElBQUk7cUJBQ2YsQ0FBQTtnQkFDTCxDQUFDO2dCQUVELHNCQUFzQjtnQkFDZiw0QkFBWSxHQUFuQixVQUFvQixTQUFnQjtvQkFDaEMsTUFBTSxpQkFBaUIsQ0FBQztnQkFDNUIsQ0FBQztnQkFDTSxzQkFBTSxHQUFiLFVBQWMsU0FBZ0IsRUFBQyxLQUFZO29CQUN2QyxNQUFNLGlCQUFpQixDQUFDO2dCQUM1QixDQUFDO2dCQUdELDRCQUE0QjtnQkFDckIsNEJBQVksR0FBbkIsVUFBb0IsU0FBZ0I7b0JBQ2hDLEVBQUUsQ0FBQSxDQUFDLElBQUksQ0FBQyxPQUFPLElBQUUsSUFBSSxDQUFDLENBQUEsQ0FBQzt3QkFDbkIsSUFBSSxDQUFDLE9BQU8sR0FBRzs0QkFDWCxJQUFJLEVBQUUsQ0FBQzs0QkFDUCxLQUFLLEVBQUUsU0FBUzs0QkFDaEIsWUFBWSxFQUFFLEVBQUU7NEJBQ2hCLFFBQVEsRUFBRSxFQUFFOzRCQUNaLFdBQVcsRUFBRSxJQUFJLE1BQU0sRUFBRTs0QkFDekIsTUFBTSxFQUFFLElBQUksTUFBTSxFQUFFO3lCQUN2QixDQUFBO3dCQUNELE1BQU0sQ0FBQyxJQUFJLENBQUM7b0JBQ2hCLENBQUM7b0JBQUEsSUFBSTt3QkFBQyxNQUFNLENBQUMsS0FBSyxDQUFDO2dCQUN2QixDQUFDO2dCQUNNLHNCQUFNLEdBQWIsVUFBYyxTQUFnQixFQUFDLE9BQWM7b0JBQ3pDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDaEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBQzt3QkFDOUIsS0FBSyxFQUFFLE9BQU8sSUFBRSxTQUFTO3FCQUM1QixDQUFBO2dCQUNMLENBQUM7Z0JBQ00sMEJBQVUsR0FBakIsVUFBa0IsU0FBZ0IsRUFBQyxPQUFjO29CQUM3QyxJQUFJLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ2hDLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQUM7d0JBQzlCLEtBQUssRUFBRSxPQUFPLElBQUUsU0FBUztxQkFDNUIsQ0FBQTtnQkFDTCxDQUFDO2dCQUNMLFlBQUM7WUFBRCxDQTlGQSxBQThGQyxJQUFBO1lBRU8seUJBQUsiLCJmaWxlIjoianNvblEuanMiLCJzb3VyY2VzQ29udGVudCI6WyJjbGFzcyBqc29uUXtcclxuICAgIHByaXZhdGUganFsc0FycjpPYmplY3Q7XHJcbiAgICBwcml2YXRlIGpxbHNPYmplY3Q6YW55O1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgX1RyYW5zYXRpb25OYW1lOnN0cmluZyxwcml2YXRlIF9TSGFzaDpzdHJpbmcpe1xyXG4gICAgICAgIHRoaXMuanFsc0FyciA9IG51bGw7XHJcbiAgICAgICAgdGhpcy5qcWxzT2JqZWN0PW51bGw7XHJcbiAgICAgICAgdGhpcy5qcWxzT2JqZWN0PXtcclxuICAgICAgICAgICAgVHJhbnNhdGlvbk5hbWU6IF9UcmFuc2F0aW9uTmFtZSxcclxuICAgICAgICAgICAgU0hhc2g6IF9TSGFzaCxcclxuICAgICAgICAgICAgSnFsczogW11cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGFkZFRvTGlzdCgpe1xyXG4gICAgICAgIGlmKHRoaXMuanFsc0FyciE9bnVsbCl7XHJcbiAgICAgICAgICAgIHRoaXMuanFsc09iamVjdC5KcWxzLnB1c2godGhpcy5qcWxzQXJyKTtcclxuICAgICAgICAgICAgdGhpcy5qcWxzQXJyPW51bGw7XHJcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgICAgIH1lbHNlIHJldHVybiBmYWxzZTtcclxuICAgIH1cclxuICAgIHB1YmxpYyB0b0pzb25RT2JqZWN0KCk6YW55e1xyXG4gICAgICAgIHRoaXMuYWRkVG9MaXN0KCk7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuanFsc09iamVjdDtcclxuICAgIH1cclxuICAgIHByaXZhdGUgdGhyb3dJZkludmFsaWRPcGVyYXRpb24oT3BlcmF0aW9uOm51bWJlcil7XHJcbiAgICAgICAgaWYodGhpcy5qcWxzQXJyPT1udWxsIHx8IHRoaXMuanFsc0FycltcIlR5cGVcIl0hPU9wZXJhdGlvbikgdGhyb3cgJ0ludmFsaWQgb3BlcmF0aW9uJztcclxuICAgIH1cclxuXHJcblxyXG4gICAgLy9Gb3IgSW5zZXJ0IFN0YXRlbWVudFxyXG4gICAgcHVibGljIGFkZE5ld0luc2VydChUYWJsZU5hbWU6c3RyaW5nLFByaW1hcnlGaWVsZDpzdHJpbmcsUEtleU5hbWU6c3RyaW5nPVwiXCIpOmJvb2xlYW57XHJcbiAgICAgICAgaWYodGhpcy5qcWxzQXJyPT1udWxsKXtcclxuICAgICAgICAgICAgdGhpcy5qcWxzQXJyID0ge1xyXG4gICAgICAgICAgICAgICAgVHlwZTogMSxcclxuICAgICAgICAgICAgICAgIFRhYmxlOiBUYWJsZU5hbWUsXHJcbiAgICAgICAgICAgICAgICBQcmltYXJ5RmllbGQ6IFByaW1hcnlGaWVsZCxcclxuICAgICAgICAgICAgICAgIFBLZXlOYW1lOiBQS2V5TmFtZSxcclxuICAgICAgICAgICAgICAgIENvbmRpY3Rpb25zOiB7IH0sXHJcbiAgICAgICAgICAgICAgICBGaWVsZHM6IHsgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgICAgIH1lbHNlIHJldHVybiBmYWxzZTtcclxuICAgIH1cclxuICAgIHB1YmxpYyBJbnNlcnQoRmllbGROYW1lOnN0cmluZyxWYWx1ZTpzdHJpbmcpe1xyXG4gICAgICAgIHRoaXMudGhyb3dJZkludmFsaWRPcGVyYXRpb24oMSk7XHJcbiAgICAgICAgdGhpcy5qcWxzQXJyW1wiRmllbGRzXCJdW0ZpZWxkTmFtZV09e1xyXG4gICAgICAgICAgICBWYWx1ZTogVmFsdWUsXHJcbiAgICAgICAgICAgIElzRmtleTogZmFsc2VcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgSW5zZXJ0Rm9yaWduS2V5KEZpZWxkTmFtZTpzdHJpbmcsVmFsdWU6c3RyaW5nKXtcclxuICAgICAgICB0aGlzLnRocm93SWZJbnZhbGlkT3BlcmF0aW9uKDEpO1xyXG4gICAgICAgIHRoaXMuanFsc0FycltcIkZpZWxkc1wiXVtGaWVsZE5hbWVdPXtcclxuICAgICAgICAgICAgVmFsdWU6IFZhbHVlLFxyXG4gICAgICAgICAgICBJc0ZrZXk6IHRydWVcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy9Gb3IgVXBkYXRlIFN0YXRlbWVudFxyXG4gICAgcHVibGljIGFkZE5ld1VwZGF0ZShUYWJsZU5hbWU6c3RyaW5nKXtcclxuICAgICAgICB0aHJvdyAnTm90IEltcGxlbWVudGVkJztcclxuICAgIH1cclxuICAgIHB1YmxpYyBVcGRhdGUoRmllbGROYW1lOnN0cmluZyxWYWx1ZTpzdHJpbmcpe1xyXG4gICAgICAgIHRocm93ICdOb3QgaW1wbGVtZW50ZWQnO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICAvL0ZvciBzZWxlY3QgZGF0YSBmcm8gc2VydmVyXHJcbiAgICBwdWJsaWMgYWRkTmV3U2VsZWN0KFRhYmxlTmFtZTpzdHJpbmcpe1xyXG4gICAgICAgIGlmKHRoaXMuanFsc0Fycj09bnVsbCl7XHJcbiAgICAgICAgICAgIHRoaXMuanFsc0FyciA9IHtcclxuICAgICAgICAgICAgICAgIFR5cGU6IDYsXHJcbiAgICAgICAgICAgICAgICBUYWJsZTogVGFibGVOYW1lLFxyXG4gICAgICAgICAgICAgICAgUHJpbWFyeUZpZWxkOiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgUEtleU5hbWU6IFwiXCIsXHJcbiAgICAgICAgICAgICAgICBDb25kaWN0aW9uczogbmV3IE9iamVjdCgpLFxyXG4gICAgICAgICAgICAgICAgRmllbGRzOiBuZXcgT2JqZWN0KClcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgICAgICB9ZWxzZSByZXR1cm4gZmFsc2U7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgc2VsZWN0KEZpZWxkTmFtZTpzdHJpbmcsQXNBbGllczpzdHJpbmcpe1xyXG4gICAgICAgIHRoaXMudGhyb3dJZkludmFsaWRPcGVyYXRpb24oNik7XHJcbiAgICAgICAgdGhpcy5qcWxzQXJyW1wiRmllbGRzXCJdW0ZpZWxkTmFtZV09e1xyXG4gICAgICAgICAgICBWYWx1ZTogQXNBbGllc3x8RmllbGROYW1lXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgcHVibGljIENvbmRpY3Rpb24oRmllbGROYW1lOnN0cmluZyxBc0FsaWVzOnN0cmluZyl7XHJcbiAgICAgICAgdGhpcy50aHJvd0lmSW52YWxpZE9wZXJhdGlvbig2KTtcclxuICAgICAgICB0aGlzLmpxbHNBcnJbXCJGaWVsZHNcIl1bRmllbGROYW1lXT17XHJcbiAgICAgICAgICAgIFZhbHVlOiBBc0FsaWVzfHxGaWVsZE5hbWVcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbmV4cG9ydCB7anNvblF9Il19
