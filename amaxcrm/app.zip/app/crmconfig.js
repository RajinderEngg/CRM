System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var crmConfig, serviceConfig, LocalDict, SessionlDict;
    return {
        setters:[],
        execute: function() {
            crmConfig = {
                version: "1.0.0.22",
                minSvcVersion: "",
                minDbsVersion: "",
                falbackLanguage: "he"
            };
            serviceConfig = {
                serviceBaseUrl: "http://localhost/amaxweb/Api.svc/",
                serviceApiUrl: "http://localhost:57998/API/",
                AppUrl: "http://localhost:3000/#/",
                accesTokenStoreName: "XToken",
                accesTokenRequestHeader: "X-Token",
                accesTokenResponceHeader: "XToken",
                authenticationMode: "JWT-Token"
            };
            exports_1("LocalDict", LocalDict = {
                userCredential: "userCredential",
                selectedLanguage: "preferedLanguage",
                languageResource: "languageResource",
                SmsSettings: "smsSettings"
            });
            exports_1("SessionlDict", SessionlDict = {});
            if (window.location.href.indexOf("127.0.0.1") > -1)
                serviceConfig.serviceBaseUrl = "http://localhost:57998/Api.svc/";
            exports_1("serviceConfig", serviceConfig);
            exports_1("crmConfig", crmConfig);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNybWNvbmZpZy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7UUFBSSxTQUFTLEVBTVQsYUFBYSxFQVdOLFNBQVMsRUFPVCxZQUFZOzs7O1lBeEJuQixTQUFTLEdBQUc7Z0JBQ1osT0FBTyxFQUFFLFVBQVU7Z0JBQ25CLGFBQWEsRUFBRSxFQUFFO2dCQUNqQixhQUFhLEVBQUUsRUFBRTtnQkFDakIsZUFBZSxFQUFFLElBQUk7YUFDeEIsQ0FBQztZQUNFLGFBQWEsR0FBRztnQkFDaEIsY0FBYyxFQUFFLG1DQUFtQztnQkFDbkQsYUFBYSxFQUFFLDZCQUE2QjtnQkFDNUMsTUFBTSxFQUFFLDBCQUEwQjtnQkFDbEMsbUJBQW1CLEVBQUMsUUFBUTtnQkFDNUIsdUJBQXVCLEVBQUMsU0FBUztnQkFDakMsd0JBQXdCLEVBQUMsUUFBUTtnQkFHakMsa0JBQWtCLEVBQUMsV0FBVzthQUNqQyxDQUFBO1lBQ1UsdUJBQUEsU0FBUyxHQUFHO2dCQUNuQixjQUFjLEVBQUUsZ0JBQWdCO2dCQUNoQyxnQkFBZ0IsRUFBRSxrQkFBa0I7Z0JBQ3BDLGdCQUFnQixFQUFFLGtCQUFrQjtnQkFDcEMsV0FBVyxFQUFFLGFBQWE7YUFDN0IsQ0FBQSxDQUFBO1lBRVUsMEJBQUEsWUFBWSxHQUFHLEVBRXpCLENBQUEsQ0FBQTtZQUNELEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztnQkFDL0MsYUFBYSxDQUFDLGNBQWMsR0FBRSxpQ0FBaUMsQ0FBQztZQUVwRSx5Q0FBYTtZQUNiLGlDQUFTIiwiZmlsZSI6ImNybWNvbmZpZy5qcyIsInNvdXJjZXNDb250ZW50IjpbImxldCBjcm1Db25maWcgPSB7XHJcbiAgICB2ZXJzaW9uOiBcIjEuMC4wLjIyXCIsXHJcbiAgICBtaW5TdmNWZXJzaW9uOiBcIlwiLFxyXG4gICAgbWluRGJzVmVyc2lvbjogXCJcIixcclxuICAgIGZhbGJhY2tMYW5ndWFnZTogXCJoZVwiXHJcbn07XHJcbmxldCBzZXJ2aWNlQ29uZmlnID0ge1xyXG4gICAgc2VydmljZUJhc2VVcmw6IFwiaHR0cDovL2xvY2FsaG9zdC9hbWF4d2ViL0FwaS5zdmMvXCIsXHJcbiAgICBzZXJ2aWNlQXBpVXJsOiBcImh0dHA6Ly9sb2NhbGhvc3Q6NTc5OTgvQVBJL1wiLFxyXG4gICAgQXBwVXJsOiBcImh0dHA6Ly9sb2NhbGhvc3Q6MzAwMC8jL1wiLFxyXG4gICAgYWNjZXNUb2tlblN0b3JlTmFtZTpcIlhUb2tlblwiLFxyXG4gICAgYWNjZXNUb2tlblJlcXVlc3RIZWFkZXI6XCJYLVRva2VuXCIsXHJcbiAgICBhY2Nlc1Rva2VuUmVzcG9uY2VIZWFkZXI6XCJYVG9rZW5cIixcclxuICAgIFxyXG5cclxuICAgIGF1dGhlbnRpY2F0aW9uTW9kZTpcIkpXVC1Ub2tlblwiXHJcbn1cclxuZXhwb3J0IHZhciBMb2NhbERpY3QgPSB7XHJcbiAgICB1c2VyQ3JlZGVudGlhbDogXCJ1c2VyQ3JlZGVudGlhbFwiLFxyXG4gICAgc2VsZWN0ZWRMYW5ndWFnZTogXCJwcmVmZXJlZExhbmd1YWdlXCIsXHJcbiAgICBsYW5ndWFnZVJlc291cmNlOiBcImxhbmd1YWdlUmVzb3VyY2VcIixcclxuICAgIFNtc1NldHRpbmdzOiBcInNtc1NldHRpbmdzXCJcclxufVxyXG5cclxuZXhwb3J0IHZhciBTZXNzaW9ubERpY3QgPSB7XHJcblxyXG59XHJcbmlmICh3aW5kb3cubG9jYXRpb24uaHJlZi5pbmRleE9mKFwiMTI3LjAuMC4xXCIpID4gLTEpXHJcbiAgICBzZXJ2aWNlQ29uZmlnLnNlcnZpY2VCYXNlVXJsID1cImh0dHA6Ly9sb2NhbGhvc3Q6NTc5OTgvQXBpLnN2Yy9cIjtcclxuZXhwb3J0IHtcclxuc2VydmljZUNvbmZpZyxcclxuY3JtQ29uZmlnXHJcbn0iXX0=
