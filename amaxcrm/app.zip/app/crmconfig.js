System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var crmConfig, serviceConfig, LocalDict, SessionlDict;
    return {
        setters:[],
        execute: function() {
            crmConfig = {
                version: "1.0.0.22",
                minSvcVersion: "",
                minDbsVersion: "",
                falbackLanguage: "he"
            };
            serviceConfig = {
                serviceBaseUrl: "http://localhost/amaxweb/Api.svc/",
                ImageUrl: "http://localhost:57998/AmutotFiles/",
                serviceApiUrl: "http://localhost:57998/API/",
                AppUrl: "http://localhost:3000/#/",
                accesTokenStoreName: "XToken",
                accesTokenRequestHeader: "X-Token",
                accesTokenResponceHeader: "XToken",
                authenticationMode: "JWT-Token"
            };
            exports_1("LocalDict", LocalDict = {
                userCredential: "userCredential",
                selectedLanguage: "preferedLanguage",
                languageResource: "languageResource",
                SmsSettings: "smsSettings"
            });
            exports_1("SessionlDict", SessionlDict = {});
            if (window.location.href.indexOf("127.0.0.1") > -1)
                serviceConfig.serviceBaseUrl = "http://localhost:57998/Api.svc/";
            exports_1("serviceConfig", serviceConfig);
            exports_1("crmConfig", crmConfig);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNybWNvbmZpZy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7UUFBSSxTQUFTLEVBTVQsYUFBYSxFQVlOLFNBQVMsRUFPVCxZQUFZOzs7O1lBekJuQixTQUFTLEdBQUc7Z0JBQ1osT0FBTyxFQUFFLFVBQVU7Z0JBQ25CLGFBQWEsRUFBRSxFQUFFO2dCQUNqQixhQUFhLEVBQUUsRUFBRTtnQkFDakIsZUFBZSxFQUFFLElBQUk7YUFDeEIsQ0FBQztZQUNFLGFBQWEsR0FBRztnQkFDaEIsY0FBYyxFQUFFLG1DQUFtQztnQkFDbkQsUUFBUSxFQUFFLHFDQUFxQztnQkFDL0MsYUFBYSxFQUFFLDZCQUE2QjtnQkFDNUMsTUFBTSxFQUFFLDBCQUEwQjtnQkFDbEMsbUJBQW1CLEVBQUMsUUFBUTtnQkFDNUIsdUJBQXVCLEVBQUMsU0FBUztnQkFDakMsd0JBQXdCLEVBQUMsUUFBUTtnQkFHakMsa0JBQWtCLEVBQUMsV0FBVzthQUNqQyxDQUFBO1lBQ1UsdUJBQUEsU0FBUyxHQUFHO2dCQUNuQixjQUFjLEVBQUUsZ0JBQWdCO2dCQUNoQyxnQkFBZ0IsRUFBRSxrQkFBa0I7Z0JBQ3BDLGdCQUFnQixFQUFFLGtCQUFrQjtnQkFDcEMsV0FBVyxFQUFFLGFBQWE7YUFDN0IsQ0FBQSxDQUFBO1lBRVUsMEJBQUEsWUFBWSxHQUFHLEVBRXpCLENBQUEsQ0FBQTtZQUNELEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztnQkFDL0MsYUFBYSxDQUFDLGNBQWMsR0FBRSxpQ0FBaUMsQ0FBQztZQUVwRSx5Q0FBYTtZQUNiLGlDQUFTIiwiZmlsZSI6ImNybWNvbmZpZy5qcyIsInNvdXJjZXNDb250ZW50IjpbImxldCBjcm1Db25maWcgPSB7XHJcbiAgICB2ZXJzaW9uOiBcIjEuMC4wLjIyXCIsXHJcbiAgICBtaW5TdmNWZXJzaW9uOiBcIlwiLFxyXG4gICAgbWluRGJzVmVyc2lvbjogXCJcIixcclxuICAgIGZhbGJhY2tMYW5ndWFnZTogXCJoZVwiXHJcbn07XHJcbmxldCBzZXJ2aWNlQ29uZmlnID0ge1xyXG4gICAgc2VydmljZUJhc2VVcmw6IFwiaHR0cDovL2xvY2FsaG9zdC9hbWF4d2ViL0FwaS5zdmMvXCIsXHJcbiAgICBJbWFnZVVybDogXCJodHRwOi8vbG9jYWxob3N0OjU3OTk4L0FtdXRvdEZpbGVzL1wiLFxyXG4gICAgc2VydmljZUFwaVVybDogXCJodHRwOi8vbG9jYWxob3N0OjU3OTk4L0FQSS9cIixcclxuICAgIEFwcFVybDogXCJodHRwOi8vbG9jYWxob3N0OjMwMDAvIy9cIixcclxuICAgIGFjY2VzVG9rZW5TdG9yZU5hbWU6XCJYVG9rZW5cIixcclxuICAgIGFjY2VzVG9rZW5SZXF1ZXN0SGVhZGVyOlwiWC1Ub2tlblwiLFxyXG4gICAgYWNjZXNUb2tlblJlc3BvbmNlSGVhZGVyOlwiWFRva2VuXCIsXHJcbiAgICBcclxuXHJcbiAgICBhdXRoZW50aWNhdGlvbk1vZGU6XCJKV1QtVG9rZW5cIlxyXG59XHJcbmV4cG9ydCB2YXIgTG9jYWxEaWN0ID0ge1xyXG4gICAgdXNlckNyZWRlbnRpYWw6IFwidXNlckNyZWRlbnRpYWxcIixcclxuICAgIHNlbGVjdGVkTGFuZ3VhZ2U6IFwicHJlZmVyZWRMYW5ndWFnZVwiLFxyXG4gICAgbGFuZ3VhZ2VSZXNvdXJjZTogXCJsYW5ndWFnZVJlc291cmNlXCIsXHJcbiAgICBTbXNTZXR0aW5nczogXCJzbXNTZXR0aW5nc1wiXHJcbn1cclxuXHJcbmV4cG9ydCB2YXIgU2Vzc2lvbmxEaWN0ID0ge1xyXG5cclxufVxyXG5pZiAod2luZG93LmxvY2F0aW9uLmhyZWYuaW5kZXhPZihcIjEyNy4wLjAuMVwiKSA+IC0xKVxyXG4gICAgc2VydmljZUNvbmZpZy5zZXJ2aWNlQmFzZVVybCA9XCJodHRwOi8vbG9jYWxob3N0OjU3OTk4L0FwaS5zdmMvXCI7XHJcbmV4cG9ydCB7XHJcbnNlcnZpY2VDb25maWcsXHJcbmNybUNvbmZpZ1xyXG59Il19
