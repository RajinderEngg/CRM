System.register(["angular2/core"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1;
    var onEvent, crmEvent, Kendo_utility, GroupFilterPipe, GroupParenFilterPipe;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            }],
        execute: function() {
            onEvent = {
                riceEvent: function (evtName, eventData) {
                    var evt = new Event(evtName);
                    evt["evtData"] = eventData;
                    document.dispatchEvent(evt);
                    console.log(evtName + " event rice");
                },
                listenEvent: function (eventName, callback) {
                    console.log(eventName + " is binded");
                    document.addEventListener(eventName, callback);
                },
                removeEvtListner: function (eventName, callback) {
                    console.log(eventName + " is unbinde");
                    document.removeEventListener(eventName, callback);
                }
            };
            crmEvent = {
                breadcrumbChange: "crm.breadcrumb.change"
            };
            Kendo_utility = {
                checkingNodeIds: function (nodes, checkedNodes) {
                    var checkinnodes = checkedNodes.split(';');
                    for (var i = 0; i < nodes.length; i++) {
                        for (var j = 0; j < checkinnodes.length; j++) {
                            if (nodes[i].id == checkinnodes[j]) {
                                nodes[i].set("checked", true);
                            }
                        }
                        if (nodes[i].hasChildren) {
                            Kendo_utility.checkingNodeIds(nodes[i].children.view(), checkedNodes);
                        }
                    }
                },
                checkedNodeIds: function (nodes, checkedNodes) {
                    for (var i = 0; i < nodes.length; i++) {
                        //console.log(nodes[i]);
                        if (nodes[i].checked) {
                            checkedNodes.push(nodes[i].id);
                        }
                        if (nodes[i].hasChildren) {
                            Kendo_utility.checkedNodeIds(nodes[i].children.view(), checkedNodes);
                        }
                    }
                },
                checkedNodetexts: function (nodes, checkedNodes) {
                    for (var i = 0; i < nodes.length; i++) {
                        console.log(nodes[i].text);
                        if (nodes[i].checked) {
                            checkedNodes.push(nodes[i].text);
                        }
                        if (nodes[i].hasChildren) {
                            Kendo_utility.checkedNodeIds(nodes[i].children.view(), checkedNodes);
                        }
                    }
                },
                getTree: function (inptData, groupId) {
                    var x = inptData.filter(function (e) {
                        return e.GroupParenCategory == groupId && e.GroupId != 0;
                    });
                    var outputData = [];
                    for (var i = 0; i < x.length; i++) {
                        outputData.push({
                            id: x[i].GroupId,
                            text: x[i].GroupName,
                            expanded: false,
                            items: Kendo_utility.getTree(inptData, x[i].GroupId)
                        });
                    }
                    return outputData;
                }
            };
            //pipes start
            GroupFilterPipe = (function () {
                function GroupFilterPipe() {
                }
                GroupFilterPipe.prototype.transform = function (value, _a) {
                    var groupId = _a[0];
                    return value.filter(function (o) {
                        return o.GroupId == groupId;
                    });
                };
                GroupFilterPipe = __decorate([
                    core_1.Pipe({
                        name: 'filterbygroup'
                    }), 
                    __metadata('design:paramtypes', [])
                ], GroupFilterPipe);
                return GroupFilterPipe;
            }());
            GroupParenFilterPipe = (function () {
                function GroupParenFilterPipe() {
                }
                GroupParenFilterPipe.prototype.transform = function (value, _a) {
                    var parentgroupid = _a[0];
                    return value.filter(function (o) {
                        return o.GroupParenCategory == parentgroupid;
                    });
                };
                GroupParenFilterPipe = __decorate([
                    core_1.Pipe({
                        name: 'filterbygroupparent'
                    }), 
                    __metadata('design:paramtypes', [])
                ], GroupParenFilterPipe);
                return GroupParenFilterPipe;
            }());
            exports_1("onEvent", onEvent);
            exports_1("crmEvent", crmEvent);
            exports_1("GroupFilterPipe", GroupFilterPipe);
            exports_1("GroupParenFilterPipe", GroupParenFilterPipe);
            exports_1("Kendo_utility", Kendo_utility);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFtYXhVdGlsLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7UUFFSSxPQUFPLEVBbUJQLFFBQVEsRUFJUixhQUFhOzs7Ozs7O1lBdkJiLE9BQU8sR0FBRztnQkFDVixTQUFTLEVBQUUsVUFBQyxPQUFjLEVBQUUsU0FBYTtvQkFDckMsSUFBSSxHQUFHLEdBQUcsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7b0JBQzdCLEdBQUcsQ0FBQyxTQUFTLENBQUMsR0FBRyxTQUFTLENBQUM7b0JBQzNCLFFBQVEsQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLENBQUM7b0JBQzVCLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxHQUFFLGFBQWEsQ0FBQyxDQUFDO2dCQUN4QyxDQUFDO2dCQUVELFdBQVcsRUFBQyxVQUFDLFNBQWdCLEVBQUUsUUFBWTtvQkFDdkMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLEdBQUMsWUFBWSxDQUFDLENBQUM7b0JBQ3BDLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLEVBQUMsUUFBUSxDQUFDLENBQUM7Z0JBQ2xELENBQUM7Z0JBRUQsZ0JBQWdCLEVBQUMsVUFBQyxTQUFnQixFQUFFLFFBQVk7b0JBQzVDLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxHQUFDLGFBQWEsQ0FBQyxDQUFDO29CQUNyQyxRQUFRLENBQUMsbUJBQW1CLENBQUMsU0FBUyxFQUFDLFFBQVEsQ0FBQyxDQUFDO2dCQUNyRCxDQUFDO2FBQ0osQ0FBQztZQUVFLFFBQVEsR0FBQztnQkFDVCxnQkFBZ0IsRUFBQyx1QkFBdUI7YUFDM0MsQ0FBQTtZQUVHLGFBQWEsR0FBRztnQkFDaEIsZUFBZSxFQUFFLFVBQVUsS0FBSyxFQUFFLFlBQVk7b0JBRTFDLElBQUksWUFBWSxHQUFHLFlBQVksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7b0JBQzNDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDO3dCQUNwQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFlBQVksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQzs0QkFDM0MsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUNqQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQzs0QkFDbEMsQ0FBQzt3QkFDTCxDQUFDO3dCQUNELEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDOzRCQUV2QixhQUFhLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLEVBQUUsWUFBWSxDQUFDLENBQUM7d0JBQzFFLENBQUM7b0JBQ0wsQ0FBQztnQkFDTCxDQUFDO2dCQUNELGNBQWMsRUFBRSxVQUFVLEtBQUssRUFBRSxZQUFZO29CQUd6QyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQzt3QkFDcEMsd0JBQXdCO3dCQUN4QixFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQzs0QkFDbkIsWUFBWSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7d0JBQ25DLENBQUM7d0JBRUQsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7NEJBQ3ZCLGFBQWEsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsRUFBRSxZQUFZLENBQUMsQ0FBQzt3QkFDekUsQ0FBQztvQkFDTCxDQUFDO2dCQUNMLENBQUM7Z0JBQ0QsZ0JBQWdCLEVBQUUsVUFBVSxLQUFLLEVBQUUsWUFBWTtvQkFHM0MsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUM7d0JBQ3BDLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUMzQixFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQzs0QkFDbkIsWUFBWSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ3JDLENBQUM7d0JBRUQsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7NEJBQ3ZCLGFBQWEsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsRUFBRSxZQUFZLENBQUMsQ0FBQzt3QkFDekUsQ0FBQztvQkFDTCxDQUFDO2dCQUNMLENBQUM7Z0JBQ0QsT0FBTyxFQUFFLFVBQVUsUUFBUSxFQUFFLE9BQU87b0JBQ2hDLElBQUksQ0FBQyxHQUFHLFFBQVEsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDO3dCQUMvQixNQUFNLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixJQUFJLE9BQU8sSUFBSSxDQUFDLENBQUMsT0FBTyxJQUFJLENBQUMsQ0FBQztvQkFDN0QsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsSUFBSSxVQUFVLEdBQUcsRUFBRSxDQUFDO29CQUNwQixHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQzt3QkFDaEMsVUFBVSxDQUFDLElBQUksQ0FBQzs0QkFDWixFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU87NEJBQ2hCLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUzs0QkFDcEIsUUFBUSxFQUFFLEtBQUs7NEJBQ2YsS0FBSyxFQUFFLGFBQWEsQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7eUJBQ3ZELENBQUMsQ0FBQztvQkFDUCxDQUFDO29CQUNELE1BQU0sQ0FBQyxVQUFVLENBQUM7Z0JBQ3RCLENBQUM7YUFDSixDQUFBO1lBQ0QsYUFBYTtZQUliO2dCQUFBO2dCQU1BLENBQUM7Z0JBTEcsbUNBQVMsR0FBVCxVQUFVLEtBQUssRUFBQyxFQUFTO3dCQUFSLGVBQU87b0JBQ3BCLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLFVBQUMsQ0FBQzt3QkFDbEIsTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLElBQUksT0FBTyxDQUFDO29CQUNoQyxDQUFDLENBQUMsQ0FBQztnQkFDUCxDQUFDO2dCQVJMO29CQUFDLFdBQUksQ0FBQzt3QkFDRixJQUFJLEVBQUMsZUFBZTtxQkFDdkIsQ0FBQzs7bUNBQUE7Z0JBT0Ysc0JBQUM7WUFBRCxDQU5BLEFBTUMsSUFBQTtZQUlEO2dCQUFBO2dCQU1BLENBQUM7Z0JBTEcsd0NBQVMsR0FBVCxVQUFVLEtBQUssRUFBQyxFQUFlO3dCQUFkLHFCQUFhO29CQUMxQixNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxVQUFDLENBQUM7d0JBQ2xCLE1BQU0sQ0FBQyxDQUFDLENBQUMsa0JBQWtCLElBQUksYUFBYSxDQUFDO29CQUNqRCxDQUFDLENBQUMsQ0FBQztnQkFDUCxDQUFDO2dCQVJMO29CQUFDLFdBQUksQ0FBQzt3QkFDRixJQUFJLEVBQUMscUJBQXFCO3FCQUM3QixDQUFDOzt3Q0FBQTtnQkFPRiwyQkFBQztZQUFELENBTkEsQUFNQyxJQUFBO1lBS0csNkJBQU87WUFBRSwrQkFBUTtZQUFFLDZDQUFlO1lBQUMsdURBQW9CO1lBQUMseUNBQWEiLCJmaWxlIjoiYW1heFV0aWwuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1BpcGV9IGZyb20gXCJhbmd1bGFyMi9jb3JlXCI7XHJcblxyXG5sZXQgb25FdmVudCA9IHtcclxuICAgIHJpY2VFdmVudDogKGV2dE5hbWU6c3RyaW5nLCBldmVudERhdGE6YW55KT0+e1xyXG4gICAgICAgIHZhciBldnQgPSBuZXcgRXZlbnQoZXZ0TmFtZSk7XHJcbiAgICAgICAgZXZ0W1wiZXZ0RGF0YVwiXSA9IGV2ZW50RGF0YTtcclxuICAgICAgICBkb2N1bWVudC5kaXNwYXRjaEV2ZW50KGV2dCk7XHJcbiAgICAgICAgY29uc29sZS5sb2coZXZ0TmFtZSsgXCIgZXZlbnQgcmljZVwiKTtcclxuICAgIH0sXHJcblxyXG4gICAgbGlzdGVuRXZlbnQ6KGV2ZW50TmFtZTpzdHJpbmcsIGNhbGxiYWNrOmFueSk9PntcclxuICAgICAgICBjb25zb2xlLmxvZyhldmVudE5hbWUrXCIgaXMgYmluZGVkXCIpO1xyXG4gICAgICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoZXZlbnROYW1lLGNhbGxiYWNrKTtcclxuICAgIH0sXHJcblxyXG4gICAgcmVtb3ZlRXZ0TGlzdG5lcjooZXZlbnROYW1lOnN0cmluZywgY2FsbGJhY2s6YW55KT0+e1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGV2ZW50TmFtZStcIiBpcyB1bmJpbmRlXCIpO1xyXG4gICAgICAgIGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoZXZlbnROYW1lLGNhbGxiYWNrKTtcclxuICAgIH1cclxufTtcclxuXHJcbmxldCBjcm1FdmVudD17XHJcbiAgICBicmVhZGNydW1iQ2hhbmdlOlwiY3JtLmJyZWFkY3J1bWIuY2hhbmdlXCJcclxufVxyXG5cclxubGV0IEtlbmRvX3V0aWxpdHkgPSB7XHJcbiAgICBjaGVja2luZ05vZGVJZHM6IGZ1bmN0aW9uIChub2RlcywgY2hlY2tlZE5vZGVzKSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdmFyIGNoZWNraW5ub2RlcyA9IGNoZWNrZWROb2Rlcy5zcGxpdCgnOycpO1xyXG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgbm9kZXMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgZm9yICh2YXIgaiA9IDA7IGogPCBjaGVja2lubm9kZXMubGVuZ3RoOyBqKyspIHtcclxuICAgICAgICAgICAgICAgIGlmIChub2Rlc1tpXS5pZCA9PSBjaGVja2lubm9kZXNbal0pIHtcclxuICAgICAgICAgICAgICAgICAgICBub2Rlc1tpXS5zZXQoXCJjaGVja2VkXCIsIHRydWUpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChub2Rlc1tpXS5oYXNDaGlsZHJlbikge1xyXG5cclxuICAgICAgICAgICAgICAgIEtlbmRvX3V0aWxpdHkuY2hlY2tpbmdOb2RlSWRzKG5vZGVzW2ldLmNoaWxkcmVuLnZpZXcoKSwgY2hlY2tlZE5vZGVzKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICBjaGVja2VkTm9kZUlkczogZnVuY3Rpb24gKG5vZGVzLCBjaGVja2VkTm9kZXMpIHtcclxuICAgICAgICBcclxuICAgICAgICBcclxuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IG5vZGVzLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIC8vY29uc29sZS5sb2cobm9kZXNbaV0pO1xyXG4gICAgICAgICAgICBpZiAobm9kZXNbaV0uY2hlY2tlZCkge1xyXG4gICAgICAgICAgICAgICAgY2hlY2tlZE5vZGVzLnB1c2gobm9kZXNbaV0uaWQpO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBpZiAobm9kZXNbaV0uaGFzQ2hpbGRyZW4pIHtcclxuICAgICAgICAgICAgICAgIEtlbmRvX3V0aWxpdHkuY2hlY2tlZE5vZGVJZHMobm9kZXNbaV0uY2hpbGRyZW4udmlldygpLCBjaGVja2VkTm9kZXMpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIGNoZWNrZWROb2RldGV4dHM6IGZ1bmN0aW9uIChub2RlcywgY2hlY2tlZE5vZGVzKSB7XHJcblxyXG5cclxuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IG5vZGVzLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKG5vZGVzW2ldLnRleHQpO1xyXG4gICAgICAgICAgICBpZiAobm9kZXNbaV0uY2hlY2tlZCkge1xyXG4gICAgICAgICAgICAgICAgY2hlY2tlZE5vZGVzLnB1c2gobm9kZXNbaV0udGV4dCk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGlmIChub2Rlc1tpXS5oYXNDaGlsZHJlbikge1xyXG4gICAgICAgICAgICAgICAgS2VuZG9fdXRpbGl0eS5jaGVja2VkTm9kZUlkcyhub2Rlc1tpXS5jaGlsZHJlbi52aWV3KCksIGNoZWNrZWROb2Rlcyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgZ2V0VHJlZTogZnVuY3Rpb24gKGlucHREYXRhLCBncm91cElkKSB7XHJcbiAgICAgICAgdmFyIHggPSBpbnB0RGF0YS5maWx0ZXIoZnVuY3Rpb24gKGUpIHtcclxuICAgICAgICAgICAgcmV0dXJuIGUuR3JvdXBQYXJlbkNhdGVnb3J5ID09IGdyb3VwSWQgJiYgZS5Hcm91cElkICE9IDA7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgdmFyIG91dHB1dERhdGEgPSBbXTtcclxuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHgubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgb3V0cHV0RGF0YS5wdXNoKHtcclxuICAgICAgICAgICAgICAgIGlkOiB4W2ldLkdyb3VwSWQsXHJcbiAgICAgICAgICAgICAgICB0ZXh0OiB4W2ldLkdyb3VwTmFtZSxcclxuICAgICAgICAgICAgICAgIGV4cGFuZGVkOiBmYWxzZSxcclxuICAgICAgICAgICAgICAgIGl0ZW1zOiBLZW5kb191dGlsaXR5LmdldFRyZWUoaW5wdERhdGEsIHhbaV0uR3JvdXBJZClcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBvdXRwdXREYXRhO1xyXG4gICAgfVxyXG59XHJcbi8vcGlwZXMgc3RhcnRcclxuQFBpcGUoe1xyXG4gICAgbmFtZTonZmlsdGVyYnlncm91cCdcclxufSlcclxuY2xhc3MgR3JvdXBGaWx0ZXJQaXBle1xyXG4gICAgdHJhbnNmb3JtKHZhbHVlLFtncm91cElkXSl7XHJcbiAgICAgICAgcmV0dXJuIHZhbHVlLmZpbHRlcigobyk9PntcclxuICAgICAgICAgICAgcmV0dXJuIG8uR3JvdXBJZCA9PSBncm91cElkO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG59XHJcbkBQaXBlKHtcclxuICAgIG5hbWU6J2ZpbHRlcmJ5Z3JvdXBwYXJlbnQnXHJcbn0pXHJcbmNsYXNzIEdyb3VwUGFyZW5GaWx0ZXJQaXBle1xyXG4gICAgdHJhbnNmb3JtKHZhbHVlLFtwYXJlbnRncm91cGlkXSl7XHJcbiAgICAgICAgcmV0dXJuIHZhbHVlLmZpbHRlcigobyk9PntcclxuICAgICAgICAgICAgcmV0dXJuIG8uR3JvdXBQYXJlbkNhdGVnb3J5ID09IHBhcmVudGdyb3VwaWQ7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcbn1cclxuLy9waXBlcyBlbmRcclxuXHJcblxyXG5leHBvcnQge1xyXG4gICAgb25FdmVudCwgY3JtRXZlbnQsIEdyb3VwRmlsdGVyUGlwZSxHcm91cFBhcmVuRmlsdGVyUGlwZSxLZW5kb191dGlsaXR5XHJcbn0iXX0=
