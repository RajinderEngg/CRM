﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AmaxDataService.DataModel
{
    public class TerminalDetModel
    {
        public int AccountId { get; set; }
        public string AccountName { get; set; }
        public string AccountNameEng { get; set; }
        public string instituteCode { get; set; }
        public string instituteName { get; set; }
    }
}
