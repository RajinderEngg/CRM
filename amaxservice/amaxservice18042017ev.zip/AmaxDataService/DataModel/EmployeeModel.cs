﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AmaxDataService.DataModel
{
    public class EmployeeModel
    {
        public int employeeid { get; set; }
        public int eType { get; set; }
        public bool sysuser { get; set; }
        public string password { get; set; }
        public string fname { get; set; }
        public string lname { get; set; }
        //public string eId { get; set; }
        //public string dayBirth { get; set; }
        //public string address { get; set; }
        //public string numHouse { get; set; }
        //public string city { get; set; }
        //public string zipCode { get; set; }
        //public string phone1 { get; set; }
        //public string area1 { get; set; }
        //public int PhoneTypeId { get; set; }
        //public string phone2 { get; set; }

        //public string area2 { get; set; }
        //public int PhoneTypeId2 { get; set; }


        //public string comments { get; set; }

        //public string dayStart { get; set; }
        //public string dayEnd { get; set; }
        //public string email { get; set; }

        //public string phone3 { get; set; }
        //public string area3 { get; set; }



        //public int PhoneTypeId3 { get; set; }
        //public string phone4 { get; set; }
        //public string area4 { get; set; }



        //public int PhoneTypeId4 { get; set; }
        //public Nullable<int> sex { get; set; }
        public int authoType { get; set; }
        //public int SupportEmp { get; set; }
        //public int Branchid { get; set; }
        //public bool sysdata { get; set; }
        //public bool UseMobile { get; set; }
        //public int IsDigital { get; set; }


        //public int IsmanegerTele { get; set; }


        //public int IsTele { get; set; }
        //public int mugbal { get; set; }
        //public int DepartmentId { get; set; }
        //public string TimeZone { get; set; }
        //public string CRMPassword { get; set; }
        //public string SendMailPassword { get; set; }
    }
}
