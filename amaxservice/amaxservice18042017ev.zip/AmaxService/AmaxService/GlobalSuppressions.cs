﻿
// This file is used by Code Analysis to maintain SuppressMessage 
// attributes that are applied to this project.
// Project-level suppressions either have no target or are given 
// a specific target and scoped to a namespace, type, member, etc.

[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("General", "RCS1023:Format block.", Justification = "<Pending>", Scope = "member", Target = "~M:AmaxService.CrmService.GetTreeData(System.IO.Stream)~System.IO.Stream")]

