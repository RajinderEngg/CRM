﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AmaxDataService.DataModel
{
    public class CustomerGroupsGeneralSetModel
    {
        public int CustomerId { get; set; }
        public int CustomerGeneralGroupId { get; set; }
        //public int OperationNumber { get; set; }
        //public decimal MountToCharge { get; set; }
        //public int HokDonationTypeId { get; set; }
        //public int AccountID { get; set; }
        //public string KEVAStart { get; set; }
        //public string KEVAEnd { get; set; }
        //public string KEVANAME { get; set; }
        //public string SmallRemark { get; set; }
        //public string BankCode { get; set; }
        //public string AccountType { get; set; }
        //public string AccountNo { get; set; }
        //public string SnifNo { get; set; }
        //public string ShortComment { get; set; }
        //public string ID { get; set; }

        //public decimal MountToChargeUS { get; set; }
        //public int CreditCardId { get; set; }


        //public string TotalLeftToCharge { get; set; }

        //public string TotalMonthtoCharge { get; set; }
        //public string TotalChargedMonth { get; set; }
        //public string CurrencyId { get; set; }

        //public int EmployeeId { get; set; }
        //public int HokProjectId { get; set; }



        //public string KEVAJoinDate { get; set; }
        //public string KEVACancleDate { get; set; }
        //public int ChargeDay { get; set; }
        //public int Moved { get; set; }
        //public string JoinDate { get; set; }
        
        //public string n1 { get; set; }
        //public string n2 { get; set; }
        //public string n3 { get; set; }
        //public string n4 { get; set; }
        //public string n5 { get; set; }
        //public string n6 { get; set; }
        //public string n7 { get; set; }
        //public string n8 { get; set; }
        //public string n9 { get; set; }
        //public string n10 { get; set; }
        //public string n11 { get; set; }
        //public string n12 { get; set; }
        //public string n13 { get; set; }
        //public string n14 { get; set; }
        //public string n15 { get; set; }
        //public string n16 { get; set; }
        //public string n17 { get; set; }
        //public string n18 { get; set; }
        //public string n19 { get; set; }
        //public string n20 { get; set; }
    }
}
