﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AmaxDataService.DataModel
{
    public class ClientCameFromModel
    {
        public int id { get; set; }
        public string ClientCameFromName { get; set; }
    }
}
