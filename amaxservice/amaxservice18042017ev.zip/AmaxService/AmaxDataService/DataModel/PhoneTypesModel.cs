﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AmaxDataService.DataModel
{
    public class PhoneTypesModel
    {
        public int id { get; set; }
        public string contenteng { get; set; }
        public string contentHeb { get; set; }
        public int CellPhone { get; set; }
    }
}
