﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AmaxDataService.DataModel
{
    public class CustomerSafixModel
    {
        public int SafixId { get; set; }
        public string SafixEng { get; set; }
        public string Safix { get; set; }
    }
}
