﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AmaxDataService.DataModel
{
    public class CustomerAddressTypeModel
    {
        public int AddressTypeId { get; set; }
        public string AddressTypeName { get; set; }
        public string AddressTypeNameEng { get; set; }
    }
}
